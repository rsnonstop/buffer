# Noir 1.4.0 scripts only

Build and package Noir independently on native Rocky Linux 9 or ALT Server 10.4
x86_64. This small package contains the build/package/install/test scripts,
configuration, templates and required runtime instructions. Online build inputs
and native RPMs are acquired when the scripts run.

Extract this archive, enter its directory, and verify the package:

```bash
sha256sum --check --strict SHA256SUMS
make check
```

On each corresponding native system, as an ordinary user with sudo:

```bash
# Rocky Linux 9:
RULES_COMMIT=427754d45fd70f4ab360bd5b3ba39b666cc233a5 ./build-rocky9.sh all
# ALT Server 10.4, independently:
RULES_COMMIT=427754d45fd70f4ab360bd5b3ba39b666cc233a5 ./build-alt104.sh all
```

The all stage installs development prerequisites, downloads pinned sources and
Crystal, compiles native code, runs upstream and isolated smoke tests, then
creates binary and full offline-install bundles under out/rocky9 or out/alt104.
Keep the two native systems' work directories and outputs separate. WORK_ROOT
and OUT_ROOT can select separate absolute paths. Build entry points accept
bootstrap, fetch, build, test, binary and full phases; --help lists options.
After building, make-full-rocky9.sh or make-full-alt104.sh recreates a full bundle
from the existing verified binary staging tree and unchanged native RPM inventory.

Isolated smoke tests require either permitted user network namespaces or sudo
access to create a namespace and drop back to the ordinary builder account.
The optional scripts/lab-build.sh convenience runner uses existing root SSH access
and temporary exact-command namespace privileges; that runner was syntax-checked,
while native core phases were actually executed separately.

Install using install.sh inside a generated full bundle. The files in templates/
are packaging inputs and need the generated payload and manifest. Read
[the runtime instructions](docs/RUNTIME-README.md) for verification, ALT OS keyring
preparation, installation plans and application. Full runtime bundles require a
matching compatible base OS; they support offline installation, not a complete
offline source build. Native package-version and downgrade guards remain enabled.

Noir remains pinned to v1.4.0, Crystal to 1.21.0 with its recorded checksum.
Production uses -Dwithout_mt for the lab's native GC libraries; upstream tests
add --link-flags=-Wl,--no-export-dynamic. Noir source is unchanged. A newly generated
bundle needs new native installation evidence for its exact package baseline.

No prebuilt Noir binaries, RPM payloads, final bundles, source/compiler downloads,
build caches, historical logs or credentials are included. The separate complete
handoff package retains the delivered artifacts, detailed status and native receipts.
