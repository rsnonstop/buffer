#!/usr/bin/env bash
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
. "$HERE/profiles/versions.env"
target=${1:-}; stage=${2:-all}
if [[ "$target" == -h || "$target" == --help || "$stage" == --help ]]; then
    cat <<'EOF'
Usage: build-rocky9.sh [all|bootstrap|fetch|build|test|binary|full]
       build-alt104.sh [all|bootstrap|fetch|build|test|binary|full]
Run on the actual named distribution, as a normal user with sudo.
Environment:
  WORK_ROOT=/absolute/path      Default: <kit>/work (separate subdir per target)
  OUT_ROOT=/absolute/path       Default: <kit>/out
  RULES_COMMIT=<40 hex chars>   Optional first-fetch passive-rules revision
  RUN_UPSTREAM_TESTS=0|1        Default 1. A skip is explicitly recorded.
  SKIP_BOOTSTRAP=0|1            Default 0. Set 1 after an administrator bootstraps.
  REQUIRE_NETWORK_ISOLATION=1   Default 1. Use 0 only for diagnostic candidates.
  EXTRA_RUNTIME_PACKAGES="..."  Optional additional distro RPM package names
EOF
    exit 0
fi
check_target "$target"
case "$stage" in all|bootstrap|fetch|build|test|binary|full) ;; *) die "Unknown stage: $stage";; esac
[[ "$stage" == bootstrap ]] && { exec "$HERE/scripts/bootstrap.sh" "$target"; }
(( EUID != 0 )) || die 'Do not compile untrusted source as root. Run normally; bootstrap invokes sudo.'
# A privileged launcher may leave the ordinary builder in an unreadable cwd
# (for example /root). Crystal queries cwd even for --version.
cd -- "$HERE"
WORK_ROOT=${WORK_ROOT:-$HERE/work}; OUT_ROOT=${OUT_ROOT:-$HERE/out}
safe_work_path "$WORK_ROOT"; safe_work_path "$OUT_ROOT"
W=$WORK_ROOT/$target; OUT=$OUT_ROOT/$target
mkdir -p "$W" "$OUT"
# A per-target lock prevents concurrent cache/staging/output corruption.
need flock
exec 9>"$W/.build.lock"
flock -n 9 || die "Another build is using $W"
if [[ -e "$W/target" ]]; then
    [[ $(cat "$W/target") == "$target" ]] || die 'Workspace target mismatch.'
fi
printf '%s\n' "$target" > "$W/target"
mkdir -p "$W/logs" "$W/cache" "$W/downloads" "$W/metadata"
# ALT root login sessions can export a root-private TMPDIR through runuser.
mkdir -p "$W/tmp"
chmod 0700 "$W/tmp"
export TMPDIR=$W/tmp TMP=$W/tmp TEMP=$W/tmp
exec > >(tee -a "$W/logs/driver.log") 2>&1
trap 'log "Failed at line $LINENO (stage: $stage). See $W/logs."' ERR
SKIP_BOOTSTRAP=${SKIP_BOOTSTRAP:-0}
[[ "$SKIP_BOOTSTRAP" =~ ^[01]$ ]] || die 'SKIP_BOOTSTRAP must be 0 or 1.'
if [[ "$stage" == all && "$SKIP_BOOTSTRAP" == 0 ]]; then
    "$HERE/scripts/bootstrap.sh" "$target"
fi
for c in git curl tar sha256sum python3 gcc g++ make readelf ldd rpm; do need "$c"; done
TOOLCHAIN=$W/toolchain; SRC=$W/source
export CRYSTAL_CACHE_DIR=$W/cache/crystal
export SHARDS_CACHE_PATH=$W/cache/shards
export ALT_NATIVE_RPM_CACHE_DIR=${ALT_NATIVE_RPM_CACHE_DIR:-$W/cache/native-rpms}
export CRYSTAL_WORKERS=${CRYSTAL_WORKERS:-2}
# Critical: prevent the generic tarball's bundled libgc.a/libpaths from entering
# the native build. All system libraries must come from the target distribution.
export CRYSTAL_LIBRARY_PATH=''
export CRYSTAL_LIBRARY_RPATH=''
export CRYSTAL_OPTS=''
unset SHARDS_OVERRIDE CRYSTAL_PATH LD_LIBRARY_PATH LIBRARY_PATH CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH || true
export CC=/usr/bin/gcc CXX=/usr/bin/g++
export CFLAGS='-O2 -fPIC -march=x86-64 -mtune=generic'
export CXXFLAGS="$CFLAGS"
export PATH="$TOOLCHAIN/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export GIT_TERMINAL_PROMPT=0
export RUN_UPSTREAM_TESTS=${RUN_UPSTREAM_TESTS:-1}
export REQUIRE_NETWORK_ISOLATION=${REQUIRE_NETWORK_ISOLATION:-1}
[[ "$RUN_UPSTREAM_TESTS" =~ ^[01]$ && "$REQUIRE_NETWORK_ISOLATION" =~ ^[01]$ ]] || die 'Boolean build options must be 0 or 1.'
# Rocky 9 gc 8.0 and ALT p10 gc 7.6 lack the stack APIs required by
# Crystal 1.21's execution contexts. Upstream Noir supports the legacy fiber
# scheduler; use it so both builds link to the actual native GC library.
NATIVE_CRYSTAL_FLAGS=(-Dwithout_mt)

fetch() {
    archive=$W/downloads/$CRYSTAL_ARCHIVE
    if [[ ! -f "$archive" ]]; then
        curl --fail --location --retry 3 --proto '=https' --tlsv1.2 \
          "https://github.com/crystal-lang/crystal/releases/download/$CRYSTAL_VERSION/$CRYSTAL_ARCHIVE" \
          --output "$archive.part"
        mv -- "$archive.part" "$archive"
    fi
    [[ $(sha_file "$archive") == "$CRYSTAL_SHA256" ]] || die 'Crystal archive SHA-256 mismatch.'
    # Never reuse an unpacked compiler that might have been edited locally.
    rm -rf -- "$TOOLCHAIN"
    mkdir -p "$TOOLCHAIN"
    tar -xzf "$archive" -C "$TOOLCHAIN" --strip-components=1
    [[ $(crystal --version) == "Crystal $CRYSTAL_VERSION "* ]] || die 'Compiler version mismatch.'
    if [[ ! -d "$SRC/.git" ]]; then
        [[ ! -e "$SRC" ]] || die 'Existing source directory is not a Git clone.'
        git clone --depth 1 --branch "$NOIR_TAG" "$NOIR_REPO" "$SRC"
    fi
    [[ $(git -C "$SRC" rev-parse HEAD) == "$NOIR_COMMIT" ]] || die 'Noir source commit mismatch.'
    git -C "$SRC" diff --quiet && git -C "$SRC" diff --cached --quiet || die 'Tracked Noir source has local modifications.'
    if [[ -f "$SRC/.gitmodules" ]]; then
        git -C "$SRC" submodule update --init --recursive
    fi
    lock_before=$(sha_file "$SRC/shard.lock")
    (cd "$SRC" && shards install --production) 2>&1 | tee "$W/logs/shards-install.log"
    [[ $(sha_file "$SRC/shard.lock") == "$lock_before" ]] || die 'shard.lock changed during installation.'
    (cd "$SRC" && shards check --production)
    if [[ -f "$W/rules.commit" ]]; then
        rules_commit=$(cat "$W/rules.commit")
        [[ -z ${RULES_COMMIT:-} || "$RULES_COMMIT" == "$rules_commit" ]] || die 'RULES_COMMIT differs from the saved snapshot; use a new workspace.'
    elif [[ -n ${RULES_COMMIT:-} ]]; then
        rules_commit=$RULES_COMMIT
    else
        # Resolve once, store permanently. This is first-fetch trust, not a
        # hardcoded trusted signature or a preverified rules revision.
        rules_commit=$(git ls-remote "$RULES_REPO" HEAD | awk 'NR==1 {print $1}')
    fi
    [[ "$rules_commit" =~ ^[a-f0-9]{40}$ ]] || die 'Invalid passive-rules commit.'
    if [[ ! -d "$W/rules-source/.git" ]]; then
        git init "$W/rules-source"
        git -C "$W/rules-source" remote add origin "$RULES_REPO"
        git -C "$W/rules-source" fetch --depth 1 origin "$rules_commit"
        git -C "$W/rules-source" checkout --detach FETCH_HEAD
    fi
    [[ $(git -C "$W/rules-source" rev-parse HEAD) == "$rules_commit" ]] || die 'Rules checkout mismatch.'
    git -C "$W/rules-source" diff --quiet && git -C "$W/rules-source" diff --cached --quiet || die 'Rules source was edited.'
    printf '%s\n' "$rules_commit" > "$W/rules.commit"
    printf '%s\n' "$lock_before" > "$W/shard-lock.sha256"
    cp "$SRC/shard.lock" "$W/metadata/shard.lock"
    cp "$HERE/profiles/versions.env" "$W/metadata/versions.env.txt"
    cp "$W/rules.commit" "$W/metadata/rules.commit"
    python3 "$HERE/lib/input_audit.py" record --source "$SRC" --toolchain "$TOOLCHAIN" \
        --manifest "$W/metadata/input-files.json"
    log "Inputs fetched for $target. Source: $NOIR_COMMIT; rules: $rules_commit"
}

build() {
    [[ -x "$TOOLCHAIN/bin/crystal" && -d "$SRC/lib" ]] || die 'Run fetch first.'
    [[ $(git -C "$SRC" rev-parse HEAD) == "$NOIR_COMMIT" ]] || die 'Source revision mismatch.'
    git -C "$SRC" diff --quiet && git -C "$SRC" diff --cached --quiet || die 'Source modified.'
    [[ $(sha_file "$SRC/shard.lock") == "$(cat "$W/shard-lock.sha256")" ]] || die 'Lock file mismatch.'
    python3 "$HERE/lib/input_audit.py" check --source "$SRC" --toolchain "$TOOLCHAIN" \
        --manifest "$W/metadata/input-files.json"
    export SOURCE_DATE_EPOCH
    SOURCE_DATE_EPOCH=$(git -C "$SRC" show -s --format=%ct HEAD)
    # Force fresh C/tree-sitter and Crystal outputs on this target.
    find "$SRC/src/ext" -type f \( -name '*.o' -o -name '*.a' \) -delete
    rm -f -- "$SRC/bin/noir" "$SRC/bin/noir_spec"
    rm -rf -- "$CRYSTAL_CACHE_DIR"
    mkdir -p "$CRYSTAL_CACHE_DIR" "$SRC/bin"
    printf '%s\n' "${NATIVE_CRYSTAL_FLAGS[@]}" > "$W/metadata/crystal-build-flags.txt"
    (cd "$SRC" && crystal build src/noir.cr --release --no-debug \
      --mcpu x86-64 "${NATIVE_CRYSTAL_FLAGS[@]}" --verbose -o bin/noir) 2>&1 | tee "$W/logs/compile.log"
    readelf -h "$SRC/bin/noir" > "$W/metadata/elf-header.txt"
    readelf -d "$SRC/bin/noir" > "$W/metadata/elf-dynamic.txt"
    readelf --version-info "$SRC/bin/noir" > "$W/metadata/elf-versions.txt"
    grep -q 'Advanced Micro Devices X86-64' "$W/metadata/elf-header.txt" || die 'Not an x86-64 ELF.'
    grep -q '(NEEDED)' "$W/metadata/elf-dynamic.txt" || die 'Expected a native dynamically linked binary.'
    if grep -Eq 'RPATH|RUNPATH' "$W/metadata/elf-dynamic.txt"; then die 'Unexpected RPATH/RUNPATH; inspect the native link.'; fi
    ldd "$SRC/bin/noir" > "$W/metadata/ldd.txt"
    ! grep -q 'not found' "$W/metadata/ldd.txt" || die 'Unresolved shared library.'
    crystal --version > "$W/metadata/crystal-version.txt"
    shards --version > "$W/metadata/shards-version.txt"
    gcc --version > "$W/metadata/gcc-version.txt"
    cp /etc/os-release "$W/metadata/build-os-release.txt"
    rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$W/metadata/builder-rpms.tsv"
    printf '%s\n' "$(sha_file "$SRC/bin/noir")" > "$W/metadata/noir.sha256"
    printf '%s\n' "$NOIR_COMMIT" > "$W/metadata/noir.commit"
    upstream_tests
    log 'Native compilation and ELF checks completed.'
}

upstream_tests() {
    [[ -x "$SRC/bin/noir" && -s "$W/metadata/noir.sha256" ]] || die 'Run build first.'
    [[ $(sha_file "$SRC/bin/noir") == "$(cat "$W/metadata/noir.sha256")" ]] || die 'Built binary changed.'
    [[ $(git -C "$SRC" rev-parse HEAD) == "$NOIR_COMMIT" ]] || die 'Source revision mismatch.'
    python3 "$HERE/lib/input_audit.py" check --source "$SRC" --toolchain "$TOOLCHAIN" \
        --manifest "$W/metadata/input-files.json"
    rm -f -- "$W/metadata/upstream-tests.status"
    printf '%s\n' '--link-flags=-Wl,--no-export-dynamic' > "$W/metadata/upstream-suite-link-flags.txt"
    if [[ "$RUN_UPSTREAM_TESTS" == 1 ]]; then
        # Exporting all generated debug-suite symbols produces a malformed
        # native version table on these linkers. The application is unaffected.
        local suite_home
        suite_home=$(mktemp -d "$W/suite-home.XXXXXXXX")
        mkdir -p "$suite_home/.config"
        printf '%s\n' "$suite_home" > "$W/metadata/upstream-suite-home.txt"
        (cd "$SRC" && crystal build spec/suite.cr --mcpu x86-64 "${NATIVE_CRYSTAL_FLAGS[@]}" \
          --link-flags=-Wl,--no-export-dynamic -o bin/noir_spec && \
          HOME="$suite_home" XDG_CONFIG_HOME="$suite_home/.config" bin/noir_spec) \
          2>&1 | tee "$W/logs/upstream-tests.log"
        printf 'passed\n' > "$W/metadata/upstream-tests.status"
    else
        printf 'skipped-by-operator\n' > "$W/metadata/upstream-tests.status"
    fi
}

binary() {
    [[ -s "$W/metadata/noir.sha256" && -x "$SRC/bin/noir" ]] || die 'Run build first.'
    [[ $(sha_file "$SRC/bin/noir") == "$(cat "$W/metadata/noir.sha256")" ]] || die 'Built binary changed.'
    if [[ "$RUN_UPSTREAM_TESTS" == 1 ]]; then
        [[ -f "$W/metadata/upstream-tests.status" && $(cat "$W/metadata/upstream-tests.status") == passed ]] || die 'Upstream tests have not passed. Run the test stage.'
    fi
    python3 "$HERE/lib/package.py" binary --kit "$HERE" --work "$W" --out "$OUT" --target "$target"
}
full() {
    python3 "$HERE/lib/package.py" full --kit "$HERE" --work "$W" --out "$OUT" --target "$target"
}
case "$stage" in
  all) fetch; build; binary; full ;;
  fetch) fetch ;;
  build) build ;;
  test) upstream_tests ;;
  binary) binary ;;
  full) full ;;
esac
log "Stage $stage complete. Outputs: $OUT"
