#!/usr/bin/env bash
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
target=${1:?Usage: bootstrap.sh rocky9|alt104}
check_target "$target"
if [[ "$target" == rocky9 ]]; then
    # CRB supplies some development libraries; no EPEL or third-party RPMs.
    root_cmd dnf -y install dnf-plugins-core
    root_cmd dnf config-manager --set-enabled crb
    root_cmd dnf -y install gcc gcc-c++ make git curl tar gzip xz findutils \
      diffutils coreutils binutils pkgconf-pkg-config openssl-devel gc-devel \
      pcre2-devel libevent-devel libyaml-devel libzstd-devel zlib-devel libxml2-devel \
      python3 rpm ca-certificates util-linux
else
    # Keep the machine's existing ALT 10.4/p10 repositories. Never switch branch.
    # Candidate names are resolved against the actual enabled APT-RPM metadata.
    root_cmd apt-get update
    choose() {
        local x
        for x in "$@"; do
            if apt-cache show "$x" 2>/dev/null | grep '^Package:' >/dev/null; then
                printf '%s\n' "$x"; return 0
            fi
        done
        die "No package found among: $*. Check the enabled ALT 10.4 repositories."
    }
    packages=(gcc gcc-c++ make git-core curl tar gzip xz findutils diffutils \
      coreutils binutils python3 rpm ca-certificates util-linux gnupg alt-gpgkeys)
    packages+=("$(choose pkg-config pkgconf)")
    packages+=("$(choose libssl-devel openssl-devel)")
    packages+=("$(choose libgc-devel libgc1-devel libgc7-devel gc-devel)")
    packages+=("$(choose libpcre2-devel pcre2-devel)")
    packages+=("$(choose libevent-devel)")
    packages+=("$(choose libyaml-devel)")
    packages+=("$(choose libxml2-devel)")
    packages+=("$(choose libzstd-devel zstd-devel)")
    packages+=("$(choose zlib-devel)")
    root_cmd apt-get -y install "${packages[@]}"
    # ALT APT verifies its OS keyring, while RPM may start with no imported keys.
    # Import only reviewed native package signers, never keys from a bundle.
    root_cmd "$HERE/scripts/alt-import-os-rpm-keys.sh"
    root_cmd "$HERE/scripts/alt-cache-installed-rpms.sh" "${ALT_NATIVE_RPM_CACHE_DIR:-${WORK_ROOT:-$HERE/work}/alt104/cache/native-rpms}"
fi
log 'Bootstrap complete. Build as a normal user; sudo is used only for package installation.'
