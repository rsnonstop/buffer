#!/usr/bin/env bash
# Reproduce a native lab build through existing root SSH access.
set -Eeuo pipefail
KIT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
target=${1:-}
case "$target" in
    rocky9) destination=${LAB_SSH:-root@192.168.11.136}; builder=noirbuild
            remote_kit=/home/noirbuild/noir-1.4.0-rocky9-build-kit ;;
    alt104) destination=${LAB_SSH:-root@192.168.11.140}; builder=noirbuilder
            remote_kit=/home/noirbuilder/noir-1.4.0-build ;;
    *) echo 'Usage: scripts/lab-build.sh rocky9|alt104' >&2; exit 2 ;;
esac
[[ "$destination" =~ ^root@[A-Za-z0-9_.-]+$ ]] || { echo 'LAB_SSH must be root@host' >&2; exit 2; }
output=${LAB_OUT_ROOT:-$KIT/../artifacts}
mkdir -p "$output/$target/evidence"
temp=$(mktemp -d)
trap 'rm -rf -- "$temp"' EXIT
tar --exclude='./work' --exclude='./out' --exclude='__pycache__' \
    -czf "$temp/kit.tar.gz" -C "$KIT" .
remote_input=$(ssh -o BatchMode=yes "$destination" 'mktemp /var/tmp/noir-kit-upload.XXXXXXXX.tar.gz')
[[ "$remote_input" =~ ^/var/tmp/noir-kit-upload\.[A-Za-z0-9]+\.tar\.gz$ ]] || exit 2
scp -q "$temp/kit.tar.gz" "$destination:$remote_input"
ssh -o BatchMode=yes "$destination" bash -s -- "$target" "$builder" "$remote_kit" "$remote_input" \
    < "$KIT/scripts/lab-build-remote.sh" 2>&1 | tee "$output/$target/evidence/lab-build.log"
scp -q "$destination:$remote_kit/out/$target/*.tar.gz*" "$output/$target/"
# Keep all diagnostics outside the checksummed runtime bundles.
ssh -o BatchMode=yes "$destination" "tar -czf - -C $remote_kit work/$target/logs work/$target/metadata" \
    > "$output/$target/evidence/native-build-records.tar.gz"
(cd -- "$output/$target"; sha256sum --check ./*.tar.gz.sha256)
printf 'Native %s artifacts: %s/%s\n' "$target" "$output" "$target"
