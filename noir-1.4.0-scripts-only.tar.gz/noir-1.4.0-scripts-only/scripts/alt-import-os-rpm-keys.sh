#!/usr/bin/env bash
# Synchronize reviewed ALT package-signing keys from the installed OS keyring.
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
check_target alt104
(( EUID == 0 )) || die 'OS RPM trust provisioning requires root.'
for command in rpm gpg stat mktemp; do need "$command"; done
keyring=/usr/lib/alt-gpgkeys/pubring.gpg
vendors=/etc/apt/vendors.list.d/alt.list
[[ -f "$keyring" && ! -L "$keyring" ]] || die 'Installed ALT keyring is missing or is a symlink.'
[[ $(rpm -qf --qf '%{NAME}\n' "$keyring") == alt-gpgkeys ]] || die 'ALT keyring is not owned by installed alt-gpgkeys.'
[[ -f "$vendors" && ! -L "$vendors" ]] || die 'Installed ALT APT vendor trust file is missing.'
rpm -qf "$vendors" >/dev/null || die 'ALT APT vendor trust file is not owned by an installed RPM.'
for trusted_file in "$keyring" "$vendors"; do
    [[ $(stat -c '%u' "$trusted_file") == 0 ]] || die "OS trust file is not root-owned: $trusted_file"
    mode=$(stat -c '%a' "$trusted_file")
    (( (8#$mode & 0022) == 0 )) || die "OS trust file is writable by group/others: $trusted_file"
done
temp=$(mktemp -d /var/tmp/noir-alt-trust.XXXXXX)
chmod 0700 "$temp"
trap 'rm -rf -- "$temp"' EXIT
# The OS-trusted p10 key expired in July 2026. It is required for historical
# native RPMs signed during its validity (e.g. alt-os-release from 2021).
# RPM still checks each package signature normally; no expiry/signature bypass.
for fingerprint in \
    49B01E70C64124E6742EAE7195C584D5AE4AE412 \
    DF6C02E5F174D7CDF792A9CDFF979DEDDA2773BB \
    357BE37422F73D9CB3A0C8D142F343A2C7EB80F9; do
    grep -Fq "Fingerprint \"$fingerprint\";" "$vendors" || die 'Reviewed fingerprint missing from native APT vendor trust.'
    actual=$(gpg --homedir "$temp" --batch --no-options --no-default-keyring --keyring "$keyring" \
        --with-colons --fingerprint "$fingerprint" | awk -F: '$1 == "fpr" { print $10; exit }')
    [[ "$actual" == "$fingerprint" ]] || die 'Native ALT package-signer fingerprint mismatch.'
    gpg --homedir "$temp" --batch --no-options --no-default-keyring --keyring "$keyring" \
        --armor --export "$fingerprint" > "$temp/$fingerprint.gpg"
    [[ -s "$temp/$fingerprint.gpg" ]] || die 'Native package-signer export is empty.'
    rpm --import "$temp/$fingerprint.gpg"
    log "Imported reviewed ALT OS package signer: $fingerprint"
done
