#!/usr/bin/env bash
# Invoked by lab-build.sh, not a general privileged command service.
set -Eeuo pipefail
target=${1:?}; builder=${2:?}; remote_kit=${3:?}; uploaded=${4:?}
[[ $EUID == 0 ]] || exit 2
[[ "$target" == rocky9 || "$target" == alt104 ]] || exit 2
[[ "$builder" =~ ^[a-z][a-z0-9_]*$ ]] || exit 2
[[ "$remote_kit" =~ ^/home/[a-z0-9_]+/[A-Za-z0-9_.-]+$ ]] || exit 2
[[ "$uploaded" =~ ^/var/tmp/noir-kit-upload\.[A-Za-z0-9]+\.tar\.gz$ ]] || exit 2
admin_kit=$(mktemp -d /var/tmp/noir-admin-kit.XXXXXXXX)
sudo_rule=''; added_wheel=0
cleanup() {
    [[ -z "$sudo_rule" ]] || rm -f -- "$sudo_rule"
    if (( added_wheel )); then gpasswd -d "$builder" wheel >/dev/null; fi
    rm -rf -- "$admin_kit"
    rm -f -- "$uploaded"
}
trap cleanup EXIT
tar --no-same-owner -xzf "$uploaded" -C "$admin_kit"
. "$admin_kit/lib/common.sh"
check_target "$target"
# OS package/trust setup executes from a root-controlled kit copy.
"$admin_kit/scripts/bootstrap.sh" "$target"
if ! id "$builder" >/dev/null 2>&1; then useradd -m -s /bin/bash "$builder"; fi
[[ $(id -u "$builder") != 0 ]] || die 'Builder must be an ordinary account.'
mkdir -p "$remote_kit"
cp -a "$admin_kit/." "$remote_kit/"
chown -R "$builder:$(id -gn "$builder")" "$remote_kit"
if ! runuser -u "$builder" -- unshare --user --map-root-user --net true 2>/dev/null; then
    # Only namespace creation is privileged. Fixed argv then drops to builder.
    command -v sudo >/dev/null || die 'sudo is needed for a fixed namespace rule.'
    python=$(PATH=/usr/local/bin:/usr/bin:/bin python3 -c 'import sys; print(sys.executable)')
    rule_candidate=/etc/sudoers.d/noir-lab-smoke-$target
    [[ ! -e "$rule_candidate" ]] || die 'Temporary smoke sudo rule already exists.'
    sudo_rule=$rule_candidate
    app=$remote_kit/work/$target/staging/noir-1.4.0-$target-x86_64-binary
    printf '%s ALL=(root) NOPASSWD: /usr/bin/unshare --net -- runuser -u %s -- %s %s/tests/smoke.py --app %s/app --out %s/metadata/smoke --require-no-net\n' \
        "$builder" "$builder" "$python" "$remote_kit" "$app" "$app" > "$sudo_rule"
    chmod 0440 "$sudo_rule"
    visudo -cf "$sudo_rule"
    if [[ "$target" == alt104 ]] && ! id -nG "$builder" | tr ' ' '\n' | grep -Fxq wheel; then
        # ALT sudo is executable only by its wheel group. Restore membership.
        usermod -aG wheel "$builder"
        added_wheel=1
    fi
fi
# The quoted program expands positional arguments in the child shell.
# shellcheck disable=SC2016
runuser -u "$builder" -- bash -c 'cd -- "$1"; SKIP_BOOTSTRAP=1 exec "./build-$2.sh" all' \
    bash "$remote_kit" "$target"
