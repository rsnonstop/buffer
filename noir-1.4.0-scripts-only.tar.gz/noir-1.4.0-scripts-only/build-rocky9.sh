#!/usr/bin/env bash
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
if (( $# == 0 )); then set -- all; fi
exec "$HERE/scripts/build.sh" rocky9 "$@"
