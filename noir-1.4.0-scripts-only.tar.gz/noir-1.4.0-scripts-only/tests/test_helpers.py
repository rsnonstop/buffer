#!/usr/bin/env python3
"""Local helper unit tests. These never claim to compile or execute Noir."""
import json
import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

KIT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(KIT / 'lib'))
from rpm_bundle import Package, InstalledClosure, dynamic_paths, parse_packages, rich_names, verify_signature, download_rpms, run_logged, rocky_vault_repositories, verify_alt_identity, fill_alt_native_cache, fill_alt_official_snapshot, QF
from seal import seal, digest
from input_audit import inventory
from package import archive_tree, reset_dir
audit_spec = importlib.util.spec_from_file_location('artifact_audit', KIT/'scripts/audit-artifacts.py')
artifact_audit = importlib.util.module_from_spec(audit_spec)
audit_spec.loader.exec_module(artifact_audit)


def result(stdout='', stderr='', returncode=0):
    return subprocess.CompletedProcess([], returncode, stdout, stderr)


class RpmIdentityTests(unittest.TestCase):
    def test_absent_epoch(self):
        p = Package.parse('libfoo\t(none)\t1.0\t1.el9\tx86_64')
        self.assertEqual(p.epoch, '0')
        self.assertEqual(p.dnf_spec, 'libfoo-0:1.0-1.el9.x86_64')
        self.assertEqual(p.apt_spec, 'libfoo=1.0-1.el9')
    def test_nonzero_epoch(self):
        p = Package.parse('libfoo\t2\t1.0\talt1\tx86_64')
        self.assertEqual(p.apt_spec, 'libfoo=2:1.0-alt1')
    def test_roundtrip(self):
        p = Package('a', '0', '1', '1', 'noarch')
        self.assertEqual(parse_packages(p.tsv()+'\n'), [p])
    def test_invalid_identity(self):
        with self.assertRaises(ValueError): Package.parse('oops')
    def test_invalid_epoch(self):
        with self.assertRaises(ValueError): Package.parse('x\tNaN\t1\t1\tnoarch')
    def test_rich_simple(self):
        self.assertEqual(rich_names('(foo or bar)'), ['foo', 'bar'])
    def test_rich_elf_and_versions(self):
        self.assertEqual(rich_names('(libfoo.so.1()(64bit) and (bar >= 1.2))'), ['libfoo.so.1()(64bit)', 'bar'])
    def test_rich_conditional(self):
        self.assertEqual(rich_names('(foo if bar else baz)'), ['foo', 'bar', 'baz'])
    def test_valid_signature(self):
        with patch('rpm_bundle.run', return_value=result('Header V4 RSA/SHA256 Signature, key ID 1234: OK\n')):
            self.assertIn('OK', verify_signature('dummy.rpm'))
    def test_valid_signature_with_bad_in_digest(self):
        output = ('Header V4 DSA/SHA1 Signature, key ID ae4ae412: OK\n'
                  'MD5 digest: OK (2329fd3d30f947e6bad24a61611a0eb8)\n')
        with patch('rpm_bundle.run', return_value=result(output)):
            self.assertIn('OK', verify_signature('dummy.rpm'))
    def test_unsigned_digest_is_rejected(self):
        with patch('rpm_bundle.run', return_value=result('Header SHA256 digest: OK\nPayload SHA256 digest: OK')):
            with self.assertRaises(RuntimeError): verify_signature('dummy.rpm')
    def test_untrusted_signature(self):
        with patch('rpm_bundle.run', return_value=result('Header V4 RSA/SHA256 Signature: NOKEY\n')):
            with self.assertRaises(RuntimeError): verify_signature('dummy.rpm')
    def test_failed_signature(self):
        with patch('rpm_bundle.run', return_value=result('Signature: BAD', returncode=1)):
            with self.assertRaises(RuntimeError): verify_signature('dummy.rpm')
    def test_dynamic_libraries(self):
        output = ('linux-vdso.so.1 (0xabc)\n'
                  ' libfoo.so.1 => /lib64/libfoo.so.1 (0xabcd)\n'
                  ' /lib64/ld-linux-x86-64.so.2 (0xabcd)\n')
        with patch('rpm_bundle.run', return_value=result(output)):
            self.assertEqual(dynamic_paths('own-test-file'), ['/lib64/ld-linux-x86-64.so.2', '/lib64/libfoo.so.1'])
    def test_missing_dynamic_library(self):
        with patch('rpm_bundle.run', return_value=result('libfoo.so => not found\n')):
            with self.assertRaises(RuntimeError): dynamic_paths('own-test-file')
    def test_static_binary_rejected(self):
        with patch('rpm_bundle.run', return_value=result('statically linked\n')):
            with self.assertRaises(RuntimeError): dynamic_paths('own-test-file')
    def test_closure_cycles_and_rich_alternative(self):
        a = Package('app', '0', '1', '1', 'x86_64')
        b = Package('lib', '0', '1', '1', 'x86_64')
        def fake(args, check=True):
            if '--whatprovides' in args:
                cap = args[args.index('--whatprovides')+1]
                if cap == 'app': return result(a.tsv()+'\n')
                if cap == 'lib.so()(64bit)': return result(b.tsv()+'\n')
                return result(returncode=1)
            if '--requires' in args:
                if args[-1] == a.query: return result('(lib.so()(64bit) or absent)\nrpmlib(Test) = 1\n')
                if args[-1] == b.query: return result('app >= 1\n')
            raise AssertionError(args)
        with patch('rpm_bundle.run', side_effect=fake):
            self.assertEqual(InstalledClosure().walk(['app']), [a,b])
    def test_missing_provider(self):
        with patch('rpm_bundle.run', return_value=result(returncode=1)):
            with self.assertRaises(RuntimeError): InstalledClosure().walk(['absent'])
    def test_wrong_arch_provider(self):
        with patch('rpm_bundle.run', return_value=result('x\t0\t1\t1\taarch64\n')):
            with self.assertRaises(RuntimeError): InstalledClosure().walk(['x'])
    def test_alt_native_cache_filename(self):
        package = Package('bash', '0', '4.4.23', 'alt1', 'noarch')
        uri = 'http://ftp.altlinux.org/p10/branch/noarch/RPMS.classic/bash-4.4.23-alt1.noarch.rpm'
        filename = 'bash_4.4.23-alt1%3asisyphus+221902.500.4.1@1550587242_noarch.rpm'
        calls = []
        def fake(args, check=True):
            calls.append(args)
            if args[0] == 'apt-get':
                return result("'{}' {} 7584 BLAKE2b:example\n".format(uri, filename))
            if args[0] == 'curl':
                Path(args[args.index('--output')+1]).write_bytes(b'unit-test-download')
                return result()
            if args[0] == 'rpm' and '-qp' in args:
                return result(package.tsv() + '\n')
            raise AssertionError(args)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); metadata = root/'metadata'; metadata.mkdir()
            with patch('rpm_bundle.run', side_effect=fake):
                download_rpms('alt104', [package], root/'rpms', metadata)
            self.assertTrue((root/'rpms'/filename).is_file())
            self.assertIn('bash=4.4.23-alt1', calls[0])
    def test_native_failure_log_is_retained(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp)/'failure.log'
            with patch('rpm_bundle.run', return_value=result('out\n', 'real diagnostic\n', 1)):
                with self.assertRaises(RuntimeError): run_logged(['rpm','--test'], log)
            self.assertEqual(log.read_text(), 'out\nreal diagnostic\n')
    def test_rocky_vault_exact_minor(self):
        repos = rocky_vault_repositories('ID="rocky"\nVERSION_ID="9.7"\n')
        self.assertEqual(repos['noir-vault-baseos'],
            'https://dl.rockylinux.org/vault/rocky/9.7/BaseOS/x86_64/os/')
        with self.assertRaises(RuntimeError): rocky_vault_repositories('VERSION_ID="9"\n')
    def test_alt_native_build_identity_match(self):
        package = Package('bash', '0', '4.4.23', 'alt1', 'noarch')
        with patch('rpm_bundle.run', return_value=result('sisyphus+221902.500.4.1\t1550587242\n')):
            self.assertEqual(verify_alt_identity('test.rpm', package), 'sisyphus+221902.500.4.1\t1550587242')
    def test_alt_old_native_build_without_disttag(self):
        package = Package('bashrc', '0', '3.3.1', 'alt1', 'noarch')
        with patch('rpm_bundle.run', return_value=result('(none)\t1533298978\n')):
            self.assertEqual(verify_alt_identity('test.rpm', package), '(none)\t1533298978')
    def test_alt_republished_nevra_rejected(self):
        package = Package('bash', '0', '4.4.23', 'alt1', 'noarch')
        with patch('rpm_bundle.run', side_effect=[result('sisyphus+221902.500.4.1\t1550587242\n'),
                                                result('p10+999999.100.1.1\t1791264000\n')]):
            with self.assertRaises(RuntimeError): verify_alt_identity('test.rpm', package)
    def test_alt_cache_requires_signature_and_native_stamp(self):
        package = Package('glibc-core', '0', '2.32', 'alt5.p10.6', 'x86_64')
        def fake(args, check=True):
            if '-Kv' in args: return result('V4 DSA/SHA1 Signature, key ID ae4ae412: OK\n')
            if QF in args: return result(package.tsv()+'\n')
            return result('p10+123.100.1.1\t1600000000\n')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); cache=root/'cache'; cache.mkdir(); directory=root/'rpms'; directory.mkdir()
            metadata=root/'metadata'; metadata.mkdir()
            (cache/'native.rpm').write_bytes(b'unit-test-package-bytes')
            with patch('rpm_bundle.run', side_effect=fake):
                self.assertEqual(fill_alt_native_cache([package], directory, metadata, cache), [])
            self.assertEqual((directory/(package.query+'.rpm')).read_bytes(), b'unit-test-package-bytes')
            record=json.loads((metadata/'download-installed-cache.json').read_text())
            self.assertEqual(record['copied'][0]['native_build'], 'p10+123.100.1.1\t1600000000')
    def test_alt_cache_untrusted_candidate_rejected(self):
        package = Package('glibc-core', '0', '2.32', 'alt5.p10.6', 'x86_64')
        def fake(args, check=True):
            if '-Kv' in args: return result('Signature: NOKEY\n')
            if QF in args: return result(package.tsv()+'\n')
            return result('p10+123.100.1.1\t1600000000\n')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); cache=root/'cache'; cache.mkdir(); directory=root/'rpms'; directory.mkdir()
            metadata=root/'metadata'; metadata.mkdir(); (cache/'native.rpm').write_bytes(b'test')
            with patch('rpm_bundle.run', side_effect=fake):
                self.assertEqual(fill_alt_native_cache([package], directory, metadata, cache), [package])
            self.assertEqual(list(directory.glob('*.rpm')), [])
    def test_alt_snapshot_exact_signed_original(self):
        package = Package('perl-base', '1', '5.34.0', 'alt1', 'x86_64')
        def fake(args, check=True):
            if args[0] == 'curl':
                Path(args[args.index('--output')+1]).write_bytes(b'unit-test-native-snapshot')
                return result()
            if '-Kv' in args: return result('V4 DSA/SHA1 Signature, key ID ae4ae412: OK\n')
            if QF in args: return result(package.tsv()+'\n')
            return result('sisyphus+279621.700.1.1\t1626629811\n')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); directory=root/'rpms'; directory.mkdir(); metadata=root/'metadata'; metadata.mkdir()
            with patch('rpm_bundle.run', side_effect=fake), patch.dict(os.environ, {'ALT_SNAPSHOT_DATE':'2025/01/25'}):
                fill_alt_official_snapshot([package], directory, metadata)
            record=json.loads((metadata/'download-official-snapshot.json').read_text())
            self.assertEqual(record['copied'][0]['uri'],
                'https://ftp.altlinux.org/pub/distributions/archive/p10/date/2025/01/25/x86_64/RPMS.classic/perl-base-5.34.0-alt1.x86_64.rpm')
            self.assertTrue((directory/(package.query+'.rpm')).is_file())
    def test_alt_snapshot_identity_substitution_rejected(self):
        package = Package('perl-base', '1', '5.34.0', 'alt1', 'x86_64')
        replacement = Package('perl-base', '1', '5.34.0', 'alt2', 'x86_64')
        def fake(args, check=True):
            if args[0] == 'curl':
                Path(args[args.index('--output')+1]).write_bytes(b'test')
                return result()
            return result(replacement.tsv()+'\n')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); directory=root/'rpms'; directory.mkdir(); metadata=root/'metadata'; metadata.mkdir()
            with patch('rpm_bundle.run', side_effect=fake):
                with self.assertRaises(RuntimeError): fill_alt_official_snapshot([package], directory, metadata)
            self.assertEqual(list(directory.glob('*.rpm')), [])
    def test_rocky_vault_retry_retains_exact_specs_and_failure(self):
        package = Package('glibc', '0', '2.34', '231.el9_7.10', 'x86_64')
        calls = []
        def fake(args, check=True):
            calls.append(args)
            if len(calls) == 1: return result(stderr='Exact glibc missing from live repository\n', returncode=1)
            return result('Downloaded exact glibc\n')
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); metadata = root/'metadata'; metadata.mkdir()
            with patch('rpm_bundle.run', side_effect=fake), patch('rpm_bundle.rocky_vault_repositories',
                    return_value={'noir-vault-baseos': 'https://dl.rockylinux.org/vault/rocky/9.7/BaseOS/x86_64/os/'}):
                download_rpms('rocky9', [package], root/'rpms', metadata)
            self.assertEqual(calls[0][-1], package.dnf_spec)
            self.assertEqual(calls[1][-1], package.dnf_spec)
            self.assertIn('Exact glibc missing', (metadata/'download.log').read_text())
            self.assertIn('--repofrompath=noir-vault-baseos,https://dl.rockylinux.org/vault/rocky/9.7/BaseOS/x86_64/os/', calls[1])


class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / 'bundle'; self.root.mkdir()
        shutil.copy2(KIT/'templates/verify.sh', self.root/'verify.sh')
        (self.root/'app').mkdir()
        (self.root/'app/data.txt').write_text('real unit-test data\n')
        seal(self.root)
    def tearDown(self): self.tmp.cleanup()
    def verify(self):
        return subprocess.run([self.root/'verify.sh'], capture_output=True, text=True)
    def test_valid(self): self.assertEqual(self.verify().returncode,0)
    def test_tamper(self):
        (self.root/'app/data.txt').write_text('tampered')
        self.assertNotEqual(self.verify().returncode,0)
    def test_missing(self):
        (self.root/'app/data.txt').unlink()
        self.assertNotEqual(self.verify().returncode,0)
    def test_extra(self):
        (self.root/'unexpected').write_text('extra')
        self.assertNotEqual(self.verify().returncode,0)
    def test_symlink(self):
        (self.root/'link').symlink_to('/etc/passwd')
        self.assertNotEqual(self.verify().returncode,0)
    def test_symlink_seal_rejected(self):
        (self.root/'link').symlink_to('/etc/passwd')
        with self.assertRaises(ValueError): seal(self.root)
    def test_traversal(self):
        (self.root/'SHA256SUMS').write_text('0'*64+'  ./../elsewhere\n')
        self.assertNotEqual(self.verify().returncode,0)
    def test_unsafe_filename(self):
        (self.root/'spaces here').write_text('oops')
        with self.assertRaises(ValueError): seal(self.root)
    def test_duplicate_manifest(self):
        p = self.root/'SHA256SUMS'; p.write_text(p.read_text()*2)
        self.assertNotEqual(self.verify().returncode,0)
    def test_archive_and_checksum(self):
        path = self.root.parent/'test.tar.gz'
        archive_tree(self.root, path)
        self.assertEqual(path.with_name(path.name+'.sha256').read_text().split()[0], digest(path))
        with tarfile.open(path) as archive:
            self.assertIn('bundle/app/data.txt', archive.getnames())
    def test_reset_guard(self):
        with self.assertRaises(ValueError): reset_dir(self.root.parent, self.root)


class InputAuditTests(unittest.TestCase):
    def test_modification_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'src').mkdir(); (root/'tool').mkdir()
            file=root/'src/test.cr'; file.write_text('first')
            before=inventory(root/'src',root/'tool'); file.write_text('second')
            self.assertNotEqual(before,inventory(root/'src',root/'tool'))
    def test_generated_outputs_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'src/bin').mkdir(parents=True); (root/'tool').mkdir()
            (root/'src/test.cr').write_text('source'); before=inventory(root/'src',root/'tool')
            (root/'src/bin/noir').write_bytes(b'unit-test-only'); (root/'src/parser.o').write_bytes(b'unit-test-only')
            self.assertEqual(before,inventory(root/'src',root/'tool'))
    def test_toolchain_changes_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'src').mkdir(); (root/'tool').mkdir()
            file=root/'tool/compiler'; file.write_text('first')
            before=inventory(root/'src',root/'tool'); file.write_text('second')
            self.assertNotEqual(before,inventory(root/'src',root/'tool'))


class ArchiveAuditTests(unittest.TestCase):
    def test_sealed_archive_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)/'bundle'; root.mkdir()
            (root/'payload.txt').write_text('authentic test bytes')
            seal(root)
            archive = root.parent/'bundle.tar.gz'; archive_tree(root, archive)
            name, inventory, kept, header = artifact_audit.sealed_inventory(archive)
            self.assertEqual(name, 'bundle')
            self.assertEqual(inventory['payload.txt'], digest(root/'payload.txt'))
    def test_sealed_archive_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)/'bundle'; root.mkdir()
            (root/'payload.txt').write_text('initial'); seal(root)
            (root/'payload.txt').write_text('tampered')
            archive = root.parent/'bundle.tar.gz'; archive_tree(root, archive)
            with self.assertRaises(ValueError): artifact_audit.sealed_inventory(archive)
    def test_archive_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'test.tar.gz'
            with tarfile.open(path, 'w:gz') as archive:
                member = tarfile.TarInfo('bundle/link'); member.type = tarfile.SYMTYPE
                member.linkname = '/etc/passwd'; archive.addfile(member)
            with self.assertRaises(ValueError): artifact_audit.sealed_inventory(path)


class EntryPointTests(unittest.TestCase):
    def test_shell_syntax(self):
        for path in list(KIT.rglob('*.sh')) + [KIT/'templates/noir']:
            if 'work' not in path.parts and 'out' not in path.parts:
                with self.subTest(path=str(path)):
                    p = subprocess.run(['bash','-n',path],capture_output=True,text=True)
                    self.assertEqual(p.returncode,0,p.stderr)
    def test_installer_help(self):
        p = subprocess.run([KIT/'templates/install.sh','--help'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('--plan',p.stdout)
    def test_build_help(self):
        for target in ['rocky9','alt104']:
            p = subprocess.run([KIT/f'build-{target}.sh','--help'],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
    def test_invalid_target(self):
        p = subprocess.run([KIT/'scripts/build.sh','not-a-target','fetch'],capture_output=True,text=True)
        self.assertNotEqual(p.returncode,0)
        self.assertIn('Unknown target',p.stderr)
    @unittest.skipUnless('ID=debian' in Path('/etc/os-release').read_text(), 'guard evidence specific to this Debian host')
    def test_debian_rejected(self):
        for target in ['rocky9','alt104']:
            p = subprocess.run([KIT/f'build-{target}.sh','all'],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
            self.assertIn('Need ',p.stderr)

if __name__ == '__main__': unittest.main(verbosity=2)
