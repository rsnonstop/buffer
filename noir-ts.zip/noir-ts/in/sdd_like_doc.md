# Intro
Cybersecurity. OWASP noir. Static analysis. 
API Endpoint identification for Java Spring Boot applications and JAX-RS based applications 
by reading source code of the apps.

The issue with OWASP Noir - it misses some endpoints in JAX-RS based applications - it does not find them.

Attached files:
- "noir_sbt_springboot_updated.py" - python alternative to OWASP Noir, based on Tree-Sitter,
  to analyze Java Spring Boot based applications.

# Goal:
- create alternative tool (alternative to OWASP noir) based on tree-sitter, 
  that works only with Java Spring and JAX-RS frameworks based applications - to identify REST interfaces.
- The tool (that we create) can find more API interfaces/endpoints, than OWASP Noir

# TASK
XXXXXXXXXXXXXXXXXXXXXXXXXXXX

# Requirements
## Required command-line arguments
All startup parameters must be named arguments, not positional arguments.
- '--path' - path to a directory with source code of an application under analyzys.
  Last (right-most) directory in the directory path 'path' is refered to as 'module_name'.
  Example: 
    "--path /mnt/app1"
    Result: "module_name = app1"
- '--output'. Required. Path to the output CSV file.
- '--framework'
  Allowed values: spring, jaxrx
  Behavior:
  - When `--framework` is omitted, analyze the source code with both the Spring and JAX-RS analyzers.
  - When `--framework spring` is provided, treat/analyze the source code only as Spring.
  - When `--framework jaxrx` is provided, treat/analyze the source code only as JAX-RS.

- other params if needed

## Logic for identifying API Endpoints
Find endpoints using queries of tree-sitter.
For each endpoint - find data, needed to output (see section 'Output format' below):
- file, where this Endpoint is "implemented".
- For the endpoint implementation:
  - file
  - method or "class and method"
  - methos parameters of the method/"class method"
    - "as-is" as defined in source code - in definition of the method/"class method".


## Output format:
- file is UTF8 with BOM
- CSV
- CSV with headers. Delimeter is ";"
- CSV columns:
  - 'module_name'. Value: "{module_name}"
  - 'interface_type'. Value format: "http {HTTP_METHOD}". Examples: "http POST", "http GET".
  - 'endpoint'. Value format: "{uri_or_uri_template}". Examples: "/", "/{id}", "/update/{id}".
  - 'source_file_name'.
    Value: path to a file, where method/'class method" is defined. Path is relative to 'module_name' location. 
    Examples:
    - Startup script argument 'path' is '/mnt/app1'
      Absolute path to a file: '/mnt/app1/file1'
      Value: 'file1'
    - Startup script argument 'path' is '/mnt/app1'
      Absolute path to a file: '/mnt/app1/subdir/file2'
      Value: 'subdir/file2'      
  - 'method_name'. 
      - If value is method without a class, format is "{method}". Examples: "signin", "logout", "get_name".
      - If value is class method, format is "Class.method". Example: "ClassA.methodA"
  - 'parameters'. Value: comma separated list of method arguments "just as defined" in definition of the method in the referenced file/class.
    Example: java file has:
```
class ClassA {
  void get_name(String s1, int i){ ... }
}
```
    Then value is "String s1, int i"


## Implementation constraints
- Use the structure and coding approach of `noir_sbt_springboot_updated.py`.
- Keep the implementation simple and procedural, consistent with the existing script.
- Do not introduce a different architecture or a complex/“wise” approach.
- Do not invent new functionality or broaden framework/support coverage beyond the supplied Spring and JAX-RS scripts.
- Support only Spring Boot / Spring Web annotation endpoints and JAX-RS endpoints in the combined tool.
- At start of script include usage example in copy-paste ready format. Example:
```
python noir_sbt_spring_jaxrx.py \
  --path /mnt/app1 \
  --output endpoints.csv
```


## 4. Tree-sitter requirements
Java endpoint identification and extraction must be based on Tree-sitter queries.
- Use `tree_sitter` with the Java grammar.
- Use Tree-sitter to identify endpoint annotations, classes, methods, paths, HTTP methods, method parameters, etc.
- Use `QueryCursor.matches()` for Tree-sitter query results.
- Do not use `QueryCursor.captures()`.

## 7. Endpoint identification
Recursively inspect Java source files under `--path` and identify HTTP API endpoints using Tree-sitter queries.
For each identified endpoint, determine:
- the HTTP method;
- the complete endpoint URI or URI template;
- the source file containing the endpoint implementation;
- the implementing method, or class and method;
- the parameters from the implementing method declaration.

The complete endpoint must include applicable class-level and method-level path declarations.


Avoid installation of tree-sitter in your sandbox, as it's found in previous conversations 
- there is an issue to install in your sandbox - access to needed packages is blocked from your sandbox.
As result - avoid running the script in your sandbox (as it will fail as of absence of tree-siter dependency)

