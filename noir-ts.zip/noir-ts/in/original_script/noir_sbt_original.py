import csv
import json
import re
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
import argparse
import glob
from datetime import datetime
import tree_sitter_java as tsjava
from tree_sitter import Language, Parser, Query, QueryCursor

#from tree_sitter_languages import get_parser


DELIM = ";"  # разделитель CSV
log_file="noir_sbt.log"
ignored_dirs = ["node_modules", ".git", "dist", "build", "target", "__pycache__", ".venv", "venv", ".idea", ".vscode", "tmp", ".next", "out", "vendor", "test"]
DELTA=5


fw_files=dict()

def Wicket_Detector(fname,fcontent):
    dres=False
    if re.search(r'org\.apache\.wicket',fcontent):
        dres=True

    return(dres)

def Wicket_Analyzer(fname,fcontent):
    pass


def JaxRS_Detector(fname,fcontent):
    dres=False
    if re.search(r'jakarta.ws.rs',fcontent) or re.search(r'javax.ws.rs',fcontent):
        dres=True

    return(dres)

def JaxRS_Analyzer(fname,fcontent):
    ep_list=[]
    num=0
    anno_found=False
    was_anno=False
    anno_num=0
    write_log(fname+':')
    regex_lines=dict()
    ts_lines=dict()
    for line in fcontent:
        num=num+1
        if re.search(r'\@(Path|GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS|ServerEndpoint|ApplicationPath)',line):
            anno_found=True
            was_anno=True
            anno_num=num
            regex_lines[num]=line
        if anno_found and abs(int(anno_num)-int(num))<int(DELTA):
            s=str(num)+':'+line.strip()
            write_log(s)
        else:
            anno_found=False

    return(ep_list)



def SpringBoot_Route_Detector(fname,fcontent):
    dres=False
    if re.search(r'org\.springframework\.web\.reactive\.function\.server',fcontent):
        dres=True

    return(dres)


def SpringBoot_Codegen_Detector(fname,fcontent):
    dres=False
    if re.search(r'openapi\.codegen',fcontent) or re.search(r'io\.swagger\.codegen',fcontent):
        dres=True

    return(dres)

def SpringBoot_Codegen_Analyzer(fname,fcontent):
    pass


def SpringBoot_Route_Detector(fname,fcontent):
    dres=False
    if re.search(r'org\.springframework\.web\.reactive\.function\.server',fcontent):
        dres=True

    return(dres)

def SpringBoot_Route_Analyzer(fname,fcontent):
    pass

def SpringBoot_Detector(fname,fcontent):
    dres=False
    if re.search(r'org\.springframework\.web\.bind\.annotation\.',fcontent) or re.search(r'org\.springframework\.web\.reactive\.function\.server',fcontent):
        dres=True

    return(dres)

PARAM_NODES = {
    "formal_parameter",
    "spread_parameter",      # varargs
    "receiver_parameter",    # Outer this
}

def print_tree(node, indent=""):
    # Named nodes represent actual syntax constructs (ignoring punctuation/commas)
    node_name = f" [{node.type}]" if node.is_named else f" '{node.type}'"
    if not node.is_named:
        return
    # Extract row/col info
    start = node.start_point
    end = node.end_point
    grammar_name = node.grammar_name
    #node_text = node.text
    snode=str(node)
    node_value=node.text.decode('utf8')

    write_log(f"{indent}{node_name}{grammar_name} ({start[0]},{start[1]}) -> ({end[0]},{end[1]})")
    write_log(f"{indent} {node_value}")

    # Recurse through children
    for child in node.children:
        print_tree(child, indent + "  ")

def node_text(source: bytes, node) -> str:
    return source[node.start_byte:node.end_byte].decode("utf8")

def find_first(node, type_name: str):
    for child in node.children:
        if child.type == type_name:
            return child
    return None

def child_by_field(node, field_name: str):
    """Tree-sitter поля стабильнее структуры children."""
    try:
        return node.child_by_field_name(field_name)
    except Exception:
        return None

def find_first_recursive(node, type_name: str):
    """Надёжнее, чем искать только среди прямых детей."""
    if node.type == type_name:
        return node
    for child in node.children:
        found = find_first_recursive(child, type_name)
        if found:
            return found
    return None


def get_identifier_node(node):
    """
    Сначала пытаемся взять поле 'name', потом fallback на рекурсивный identifier.
    Это снижает риск 'тихих' пропусков из-за отличий AST между версиями грамматики.
    """
    name = child_by_field(node, "name")
    if name:
        return name
    return find_first_recursive(node, "identifier")

def normalize_path(path):
    path=path.replace("\"","")
    if path[0] != "/":
        path='/'+path
    return(path)

def get_HTTP_method(annotationName):
    match annotationName:
        case "GetMapping":
            return "GET"
        case "PostMapping":
            return "POST"
        case "PutMapping":
            return "PUT"
        case "DeleteMapping":
            return "DELETE"
        case "PatchMapping":
            return "PATCH"
        case "RequestMapping":
            return "GET"
        case _:
            return "GET"

def get_callable_parameters(source: bytes, params_node):
    """
    Возвращает список параметров для method_declaration / constructor_declaration.
    Для compact_constructor_declaration и annotation_type_element_declaration обычно [].
    """
    params = []

    if not params_node:
        return params

    for child in params_node.children:
        if child.type in PARAM_NODES:
            name_node = get_identifier_node(child)
            param_name = node_text(source, name_node) if name_node else ""
            param_type = get_param_type_text(source, child)

            params.append({"name": param_name, "type": param_type})

    return params

def get_param_type_text(source: bytes, param_node) -> str:
    """
    Тип параметра = всё до имени параметра.
    Для spread_parameter/receiver_parameter может отличаться, но обычно работает.
    """
    name_node = get_identifier_node(param_node)
    if not name_node:
        # fallback: если имени нет (редко), берём весь узел без имени
        return node_text(source, param_node).strip()

    return source[param_node.start_byte:name_node.start_byte].decode("utf8").strip()

def stringify_parameters(params: list[dict]) -> str:
    parts = []
    for p in params:
        p_type = (p.get("type") or "").strip()
        p_name = (p.get("name") or "").strip()

        if p_type and p_name:
            parts.append(f"{p_type} {p_name}")
        elif p_type:
            parts.append(p_type)
        elif p_name:
            parts.append(p_name)

    return ", ".join(parts)



def SpringBoot_Analyzer(fname,fcontent):
    query_str_class='''
    (class_declaration
        name: (identifier) @class.name) @class.body
    '''
    query_str_anno_class='''
    (class_declaration
        (modifiers
            (annotation
                name: (identifier) @name
                arguments:
                    (annotation_argument_list
                        (string_literal) @endpoint.path
                    )?
                    (annotation_argument_list
                        ( element_value_array_initializer) @endpoint.path
                    )?
                    (annotation_argument_list
                        (element_value_pair
                            key: (identifier) @param.name (#eq? @param.name "value")
                            value: (element_value_array_initializer) @endpoint.path
                            )
                    )?
            (#match? @name "^RequestMapping$")
            )
        )
        name: (identifier) @class.name) @class.body
    '''
    query_str_anno_get_null='''
    (method_declaration
        (modifiers
            (marker_annotation
                name: (identifier) @verb.name
                (#eq? @verb.name "GetMapping")
                )
            )
        name: (identifier) @method.name
        parameters: (formal_parameters) @func.parameters) @handler.method

    '''
    query_str_anno_other='''
    (method_declaration
        (modifiers
            (annotation
                name: (identifier) @verb.name
                arguments: (annotation_argument_list
                    (string_literal) @endpoint.path
                    )?
                    (annotation_argument_list
                        (element_value_pair
                            (identifier) @param-name (#eq? @param-name "path" )
                            value: (string_literal) @endpoint.path
                            )
                        )?
            (#match? @verb.name "^(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping)$")
            )
        )
        name: (identifier) @method.name
        parameters: (formal_parameters) @func.parameters) @handler.method

    '''
    query_str_anno_request='''
    (method_declaration
        (modifiers
            (annotation
                name: (identifier) @verb.name
                arguments: (annotation_argument_list
                    (string_literal) @endpoint-path
                    )?
                    (annotation_argument_list
                        (element_value_pair
                            (identifier) @param-name (#eq? @param-name "value")
                            value: (string_literal) @endpoint-path
                            )
                        )?
                    (annotation_argument_list
                        (element_value_pair
                            (identifier) @param-method (#eq? @param-method "method" )
                            value: (field_access) @method-name
                            )
                        )?

            (#eq? @verb.name "RequestMapping")
            )
        )
        name: (identifier) @method.name
        parameters: (formal_parameters) @func.parameters) @handler.method
    '''

    num=0
    anno_found=False
    was_anno=False
    anno_num=0
    ep_list=[]
    write_log(fname+':')
    regex_lines=dict()
    ts_lines=dict()
    for line in fcontent:
        num=num+1
        if re.search(r'\@(RequestMapping|GetMapping|PostMapping|PutMapping|PatchMapping|DeleteMapping)',line):
            anno_found=True
            was_anno=True
            anno_num=num
            regex_lines[num]=line
        if anno_found and abs(int(anno_num)-int(num))<int(DELTA):
            s=str(num)+':'+line.strip()
            write_log(s)
        else:
            anno_found=False
    if was_anno:
        with open(fname, "rb") as f:
            source = f.read()
        JAVA_LANGUAGE = Language(tsjava.language())
        parser = Parser(JAVA_LANGUAGE)
        tree = parser.parse(source)
        root = tree.root_node
        #print_tree(root)
        class_node = find_first(root, "class_declaration")

        if class_node:
            #search methods of class
            query_class = Query(JAVA_LANGUAGE, query_str_class)
            cursor_class = QueryCursor(query_class)
            captures_class = cursor_class.captures(root)
            class_names_n=captures_class["class.name"]
            class_bodies_n=captures_class["class.body"]
            classes_info=dict()
            ind=0
            for class_name_n in class_names_n:
                class_name=class_name_n.text.decode('utf8')
                classes_info[class_name]={"base_uri":"","body":class_bodies_n[ind]}
                ind=ind+1

            query_class = Query(JAVA_LANGUAGE, query_str_anno_class)
            cursor_class = QueryCursor(query_class)
            captures_class = cursor_class.captures(root)
            if captures_class:
                class_names_n=captures_class["class.name"]
                ep_pathes_n=captures_class["endpoint.path"]
                ind=0
                for class_name_n in class_names_n:
                    class_name=class_name_n.text.decode('utf8')
                    path=normalize_path(ep_pathes_n[ind].text.decode('utf8'))
                    classes_info[class_name]["base_uri"]=path
                    ind=ind+1


            for class_name in classes_info:
                basepath=classes_info[class_name]["base_uri"]
                class_root=classes_info[class_name]["body"]
                #GetMapping()
                query_class = Query(JAVA_LANGUAGE, query_str_anno_get_null)
                cursor_class = QueryCursor(query_class)
                captures_class = cursor_class.captures(class_root)
                if captures_class:
                    nodes_verb=captures_class["verb.name"]
                    nodes_method=captures_class["method.name"]
                    nodes_params=captures_class["func.parameters"]
                    ind=0
                    for node_verb in nodes_verb:
                        verb=node_verb.text.decode('utf8')
                        http_verb=get_HTTP_method(verb)
                        method_name=nodes_method[ind].text.decode('utf8')
                        node_params=nodes_params[ind]
                        params=get_callable_parameters(source, node_params)
                        sparams=stringify_parameters(params)
                        start = node_verb.start_point.row+1
                        ind=ind+1
                        ts_lines[start]=""
                        ep={"uri":basepath+"/","method": http_verb,"uri_params":sparams,"SrcFile":fname,"SrcLine":start ,"SFunction":class_name+'.'+method_name}
                        ep_list.append(ep)
                        debug_log(ep)

                #RequestMapping()
                query_class = Query(JAVA_LANGUAGE, query_str_anno_request)
                cursor_class = QueryCursor(query_class)
                captures_class = cursor_class.captures(class_root)
                if captures_class:
                    nodes_verb=captures_class["verb.name"]
                    nodes_method=captures_class["method.name"]
                    nodes_params=captures_class["func.parameters"]
                    ep_paths=captures_class["endpoint.path"]
                    ind=0
                    for node_verb in nodes_verb:
                        verb=node_verb.text.decode('utf8')
                        http_verb=get_HTTP_method(verb)
                        method_name=nodes_method[ind].text.decode('utf8')
                        node_params=nodes_params[ind]
                        params=get_callable_parameters(source, node_params)
                        sparams=stringify_parameters(params)
                        ep_path=normalize_path(ep_paths[ind].text.decode('utf8'))
                        start = node_verb.start_point.row+1
                        ind=ind+1
                        ts_lines[start]=""
                        ep={"uri":basepath+ep_path,"method": http_verb,"uri_params":sparams,"SrcFile":fname,"SrcLine":start ,"SFunction":class_name+'.'+method_name}
                        ep_list.append(ep)
                        debug_log(ep)

                #OtherMapping
                query_class = Query(JAVA_LANGUAGE, query_str_anno_other)
                cursor_class = QueryCursor(query_class)
                matches = cursor_class.matches(class_root)
                if matches:
                    for match in matches:
                        ep_path=''
                        for capture_name, nodes in match[1].items():
                            match capture_name:
                                case "verb.name":
                                    start = nodes[0].start_point.row+1
                                    ts_lines[start]=""
                                    verb=nodes[0].text.decode('utf8')
                                    http_verb=get_HTTP_method(verb)
                                case "method.name":
                                    method_name=nodes[0].text.decode('utf8')
                                case "func.parameters":
                                    node_params=nodes[0]
                                    params=get_callable_parameters(source, node_params)
                                    sparams=stringify_parameters(params)
                                case "endpoint.path":
                                    ep_path=normalize_path(nodes[0].text.decode('utf8'))

                        ep={"uri":basepath+ep_path,"method": http_verb,"uri_params":sparams,"SrcFile":fname,"SrcLine":start ,"SFunction":class_name+'.'+method_name}
                        ep_list.append(ep)
                        debug_log(ep)

            #if captures_class:
            #    nodes_verb=captures_class["verb.name"]
            #    nodes_method=captures_class["method.name"]
            #    nodes_params=captures_class["func.parameters"]
            #    ep_paths=captures_class["endpoint.path"]
            #    ind=0
            #    for node_verb in nodes_verb:
            #        write_log(str(ind))
            #        print_tree(node_verb)
            #        print_tree(ep_paths[ind])
            #        print_tree(nodes_method[ind])
            #        verb=node_verb.text.decode('utf8')
            #        ep_path=normalize_path(ep_paths[ind].text.decode('utf8'))
            #        http_verb=get_HTTP_method(verb)
            #        method_name=nodes_method[ind].text.decode('utf8')
            #        node_params=nodes_params[ind]
            #        params=get_callable_parameters(source, node_params)
            #        sparams=stringify_parameters(params)
            #        start = node_verb.start_point.row+1
            #        ind=ind+1
            #        ts_lines[start]=""
            #        ep={"uri":basepath+ep_path,"method": http_verb,"uri_params":sparams,"SrcFile":fname,"SrcLine":start ,"SFunction":class_name+'.'+method_name}
            #        ep_list.append(ep)
            #        debug_log(ep)




        else:
            #search functions
            basepath=""
            #GetMapping()
            query_class = Query(JAVA_LANGUAGE, query_str_anno_get_null)
            cursor_class = QueryCursor(query_class)
            captures_class = cursor_class.captures(root)
            if captures_class:
                nodes_verb=captures_class["verb.name"]
                nodes_method=captures_class["method.name"]
                nodes_params=captures_class["func.parameters"]
                ind=0
                for node_verb in nodes_verb:
                    verb=node_verb.text.decode('utf8')
                    http_verb=get_HTTP_method(verb)
                    method_name=nodes_method[ind].text.decode('utf8')
                    node_params=nodes_params[ind]
                    params=get_callable_parameters(source, node_params)
                    sparams=stringify_parameters(params)
                    start = node_verb.start_point.row+1
                    ind=ind+1
                    ts_lines[start]=""
                    ep={"uri":basepath,"method": http_verb,"uri_params":sparams,"SrcFile":fname,"SrcLine":start ,"SFunction":class_name+'.'+method_name}
                    ep_list.append(ep)
                    debug_log(ep)
            #RequestMapping()
            query_class = Query(JAVA_LANGUAGE, query_str_anno_request)
            cursor_class = QueryCursor(query_class)
            captures_class = cursor_class.captures(root)
            if captures_class:
                nodes_verb=captures_class["verb.name"]
                nodes_method=captures_class["method.name"]
                nodes_params=captures_class["func.parameters"]
                ep_paths=captures_class["endpoint.path"]
                ind=0
                for node_verb in nodes_verb:
                    verb=node_verb.text.decode('utf8')
                    http_verb=get_HTTP_method(verb)
                    method_name=nodes_method[ind].text.decode('utf8')
                    node_params=nodes_params[ind]
                    params=get_callable_parameters(source, node_params)
                    sparams=stringify_parameters(params)
                    ep_path=normalize_path(ep_paths[ind].text.decode('utf8'))
                    start = node_verb.start_point.row+1
                    ind=ind+1
                    ts_lines[start]=""
                    ep={"uri":basepath+ep_path,"method": http_verb,"uri_params":sparams,"SrcFile":fname,"SrcLine":start ,"SFunction":class_name+'.'+method_name}
                    ep_list.append(ep)
                    debug_log(ep)
            #OtherMapping
            query_class = Query(JAVA_LANGUAGE, query_str_anno_other)
            cursor_class = QueryCursor(query_class)
            captures_class = cursor_class.captures(root)
            if captures_class:
                nodes_verb=captures_class["verb.name"]
                nodes_method=captures_class["method.name"]
                nodes_params=captures_class["func.parameters"]
                ep_paths=captures_class["endpoint.path"]
                ind=0
                for node_verb in nodes_verb:
                    verb=node_verb.text.decode('utf8')
                    ep_path=normalize_path(ep_paths[ind].text.decode('utf8'))
                    http_verb=get_HTTP_method(verb)
                    method_name=nodes_method[ind].text.decode('utf8')
                    node_params=nodes_params[ind]
                    params=get_callable_parameters(source, node_params)
                    sparams=stringify_parameters(params)
                    start = node_verb.start_point.row+1
                    ind=ind+1
                    ts_lines[start]=""
                    ep={"uri":basepath+ep_path,"method": http_verb,"uri_params":sparams,"SrcFile":fname,"SrcLine":start ,"SFunction":class_name+'.'+method_name}
                    ep_list.append(ep)
                    debug_log(ep)


    for line in regex_lines:
        if not line in ts_lines:
            write_log("ERROR!!! "+str(line)+":"+regex_lines[line])


    return(ep_list)

Framework_list={
    "SpringBoot Annotation":{"mode":"auto","detector":SpringBoot_Detector,"analyzer":SpringBoot_Analyzer,"file_mask":".*.java$","hint":""},
    "SpringBoot Route":{"mode":"manual","detector":SpringBoot_Route_Detector,"analyzer":SpringBoot_Route_Analyzer,"file_mask":".*.java$","hint":""},
    "SpringBoot Codegen":{"mode":"manual","detector":SpringBoot_Codegen_Detector,"analyzer":SpringBoot_Codegen_Analyzer,"file_mask":".*pom.xml","hint":"Необходимо запросить у команды папку generated-source, получаемую после сборки, и запустить для нее noir_sbt"},
    "Apache Wicket":{"mode":"manual","detector":Wicket_Detector,"analyzer":Wicket_Analyzer,"file_mask":".*.java$","hint":""},
    "JaxRS":{"mode":"auto","detector":JaxRS_Detector,"analyzer":JaxRS_Analyzer,"file_mask":".*.java$","hint":""},
}

def debug_log(ep):
    line=ep["SrcLine"]
    uri=ep["uri"]
    verb=ep["method"]
    uri_params=ep["uri_params"]
    sf=ep["SFunction"]
    ep_s=f'{line } {verb} {uri} {sf} {uri_params}'
    write_log(ep_s)


def write_log(str):
    with open(log_file, "a") as rpt:
        now = datetime.now()
        dt = now.strftime('%Y-%m-%d %H:%M:%S')
        rpt.write(dt+' '+str+'\n')
        rpt.close()


def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        plines = f.read()
    f.close
    return(plines)

def read_file_line(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        plines = f.readlines()
    f.close
    return(plines)


def safe_str(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, (str, int, float, bool)):
        return str(x)
    try:
        return json.dumps(x, ensure_ascii=False)
    except Exception:
        return str(x)


pa_fieldnames = ["uri", "method","uri_params", "SrcFile","SrcLine","SFunction"]
ep_csv=list()


def write_csv(path: Path, fieldnames: List[str], rows: Iterable[Dict[str, Any]]) -> None:

    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, delimiter=DELIM, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else safe_str(r.get(k))) for k in fieldnames})



parser = argparse.ArgumentParser(description='получение списка endpoint с помощью анализа метаинформации директив фреймворков (SpringBoot)')
parser.add_argument('srcdir', help='директория с исходным кодом компонента')
parser.add_argument('outputpa', help='выходной csv-файл со списком endpoint')

args = parser.parse_args()

input_srcdir = args.srcdir
eplist=Path(args.outputpa)
log_file=args.outputpa+'.log'

with open(log_file, "w") as rpt:
    rpt.close()


#Detect
fw_founded=list()
for file in glob.glob(input_srcdir+'/**/*.*',recursive=True):
    #ignore work dirs
    ignored_f=False
    for ig_dir in ignored_dirs:
        if re.search(r'\\'+ig_dir+r'\\',file) or re.search('/'+ig_dir+'/',file):
            ignored_f=True
            #write_log("ignoring "+file)
            break
    if ignored_f:
        continue

    #write_log("analyzing "+file)
    #detect frameworks
    file_loaded=False
    fdata=""
    for fwname in Framework_list:
        fw=Framework_list[fwname]
        fmask=fw["file_mask"]
        if match:=re.match(fmask,file):
            if not file_loaded:
                fdata = read_file(file)
                file_loaded=True
            fw_detect=fw["detector"]
            fw_rez=fw_detect(file,fdata)
            if fw_rez:
                write_log("Detected "+fwname+' in '+file)
                if not fwname in fw_founded:
                    fw_founded.append(fwname)
                if not fwname in fw_files:
                    fw_files[fwname]=list()
                fw_files[fwname].append(file)

#analyze frameworks
for fwname in fw_founded:
    fw=Framework_list[fwname]
    hint=fw["hint"]
    mode=fw["mode"]
    print("Found "+fwname+" "+hint)
    fw_analyze=fw["analyzer"]
    if mode == "auto":
        files=fw_files[fwname]
        for file in files:
            fdata = read_file_line(file)
            ep_add=fw_analyze(file,fdata)
            ep_csv=ep_csv+ep_add



#write endpoints
write_csv(eplist, pa_fieldnames, ep_csv)


