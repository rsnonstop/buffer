# 16 — Добавление поддержки framework

[← Указатель методов](15-method-lookup.md) · [Оглавление](README.md)

Эта глава описывает production-путь изменения для добавления одного семейства
framework без его связывания со Spring, JAX-RS, CLI или publication artifact'ов.
Текущая интеграция Wicket служит исполняемым примером. Scalar-запрос
`--framework wicket` запускает только его намеренно пустой lifecycle;
повторяющийся запрос наподобие
`--framework spring --framework wicket` объединяет тот же lifecycle Wicket со
Spring. Ни одна из этих форм не заявляет о поддержке endpoint'ов Wicket.

Архитектура намеренно статична и процедурна. Поставляемый framework получает
один facade-module и одну строку в неизменяемой composition table. Он не
получает service container, dynamic module discovery или import'ы framework в
generic pipeline.

Основные координаты:

- identity и normalization запроса:
  [`src/noir/model.py`](../src/noir/model.py) :: `FrameworkSelection`,
  `FrameworkMode`, `_normalize_framework_mode()`, `AnalysisRequest` и
  `FrameworkPlan`;
- проекция CLI: [`src/noir/cli.py`](../src/noir/cli.py) ::
  `build_argument_parser()` и `run_cli()`;
- composition выполнения: [`src/noir/frameworks.py`](../src/noir/frameworks.py)
  :: `FrameworkAdapter`, `FRAMEWORK_ADAPTERS`;
- orchestration lifecycle: [`src/noir/pipeline.py`](../src/noir/pipeline.py) ::
  `_select_frameworks()`, `_build_workspace()`, `run_analysis()`;
- исполняемый пустой пример:
  [`src/noir/wicket_framework.py`](../src/noir/wicket_framework.py);
- политика marker'ов: [`src/noir/discovery.py`](../src/noir/discovery.py) ::
  `FRAMEWORK_MARKER_RULES`;
- необязательная политика annotation'ов:
  [`src/noir/inventory.py`](../src/noir/inventory.py) ::
  `SUPPORTED_ANNOTATION_REGISTRY`, `FINAL_TRIGGER_ANNOTATION_REGISTRY`;
- граница fact и evidence: [`src/noir/model.py`](../src/noir/model.py) ::
  `EndpointFact` и [`src/noir/evidence.py`](../src/noir/evidence.py).

## 1. Lifecycle и владение

Каждое выбранное семейство проходит один и тот же внешний lifecycle:

```mermaid
flowchart TD
    MODE[Политика framework] --> PLAN[FrameworkPlan]
    PLAN --> LOOKUP[frameworks.adapters_for_plan]
    SNAP[Неизменяемый snapshot source] --> WORK[Один нейтральный Java workspace]
    WORK --> CONFIG[Настройка каждого adapter<br/>selected=true или false]
    CONFIG --> AUDIT[Построение broad inventory]
    AUDIT --> TRIGGER[Построение final-trigger inventory]
    TRIGGER --> PREP[Подготовка каждого выбранного adapter]
    PREP --> ANALYZE[Анализ выбранными adapter'ами<br/>в порядке adapter registry]
    LOOKUP --> PREP
    ANALYZE --> FACTS[Требуются значения EndpointFact]
    FACTS --> RESULT[AnalysisResult]
    RESULT --> OUTPUT[Проекция CLI и publication]
```

Порядок фаз — это контракт:

1. snapshot source-byte'ов создаётся один раз;
2. нейтральный workspace разбирает каждый Java source один раз;
3. конфигурацию получает каждый adapter, включая невыбранные;
4. оба inventory видят полностью настроенный workspace;
5. все выбранные семейства завершают preparation до начала анализа любым
   семейством;
6. выбранный анализ выполняется в порядке `FRAMEWORK_ADAPTERS`; и
7. pipeline принимает только результаты `EndpointFact`.

Этими фазами владеет pipeline. Facade семейства владеет только работой своих
трёх hook'ов внутри этих фаз. Поэтому Spring и JAX-RS остаются независимыми: ни
один facade не импортирует другой, а добавление Wicket не добавляет ветку
Wicket в `run_analysis()`.

## 2. Сохраняйте registry выполнения и marker'ов раздельными

Два registry отвечают на разные вопросы, и объединять их нельзя.

| Registry | Чем владеет | Чем не владеет |
|---|---|---|
| `frameworks.FRAMEWORK_ADAPTERS` | поставляемые lifecycle-hook'и, авторитетный порядок выполнения, mapping явного/default selection, announcement'ы не-auto режима и порядок семейств в inventory/report | обнаружение raw source или semantic recognition annotation'ов |
| `discovery.FRAMEWORK_MARKER_RULES` | порядок raw finding'ов, вид input detector'а, политика selection для scalar-`auto`, advisory announcement'ы и подсказки report'ов | доступность analyzer'а, proof endpoint'а, порядок lifecycle или default membership |

`FrameworkAdapter.name` также служит ключом, передаваемым inventory builder'ам,
и поэтому становится identity раздела report. Сохраняйте его стабильным. Его
поле `selection` — типизированный публичный identity, используемый планами
запроса. Обычно эти значения имеют одинаковое написание, как у Wicket, но
выполняют разные задачи.

Wicket демонстрирует все три независимых решения политики:

- его enum identity и adapter делают его явно исполняемым;
- `default_selected=False` исключает его из запуска без явно заданного
  framework; и
- его marker-строка использует `selection_mode="manual"` и
  `auto_selected_framework=None`, поэтому строка Apache Wicket носит
  advisory-характер в scalar-режиме `auto`.

Явное намерение пользователя и raw marker evidence не являются proof
endpoint'а. Analyzer может выдать fact только при наличии разобранной,
однозначной semantics framework.

## 3. Добавьте model- и CLI-identity

Публично выбираемому семейству нужен один enum-member. Tuple вариантов CLI
автоматически выводится из всех enum-значений плюс `auto`; не редактируйте
`FRAMEWORK_MODE_CHOICES` напрямую. Runtime-валидация по enum сохраняет
согласованность написаний в CLI и программных вызовах.

Ниже приведён полный selection fragment с текущим identity Wicket и политикой
multi-selection:

```python
from enum import Enum
from typing import TypeAlias


class FrameworkSelection(str, Enum):
    """One normalized analyzer family selected by orchestration."""

    SPRING = "spring"
    JAX_RS = "jaxrx"
    WICKET = "wicket"


FRAMEWORK_MODE_CHOICES = tuple(
    selection.value for selection in FrameworkSelection
) + ("auto",)

FrameworkMode: TypeAlias = str | tuple[str, ...] | None


def _normalize_framework_mode(mode: FrameworkMode) -> FrameworkMode:
    """Validate and canonicalize one framework-selection policy."""

    if mode is None or mode == "auto":
        return mode
    is_group = isinstance(mode, tuple)
    values = mode if is_group else (mode,)
    if not values:
        raise ValueError("explicit framework selection must not be empty")
    if "auto" in values:
        raise ValueError("auto must be requested once and alone")
    try:
        selections = tuple(FrameworkSelection(value) for value in values)
    except (TypeError, ValueError) as error:
        raise ValueError(f"unsupported framework mode: {mode!r}") from error
    if len(set(selections)) != len(selections):
        raise ValueError("a framework may be requested only once")
    ordered = tuple(
        selection.value
        for selection in FrameworkSelection
        if selection in selections
    )
    return ordered if len(ordered) > 1 else ordered[0]
```

`AnalysisRequest.__post_init__()` вызывает этот helper. Одно явно заданное
семейство ради compatibility остаётся строкой; несколько явно заданных
семейств становятся неизменяемым tuple в порядке enum `FrameworkSelection`.
`None` остаётся политикой опущенного аргумента, а scalar `auto` — политикой
marker'ов. Пустой tuple, дубликат, неизвестный token или любой tuple,
содержащий `auto`, недопустим.

`FrameworkPlan.__post_init__()` применяет ту же normalization, отклоняет
дубликаты в effective selection и требует, чтобы selected set явного плана
совпадал с requested set. Для этого invariant он сравнивает set'ы, поскольку
окончательный порядок lifecycle задаётся adapter registry.

CLI сохраняет синтаксис одного значения и делает тот же option повторяемым:

```python
parser.add_argument(
    "--framework",
    action="append",
    choices=FRAMEWORK_MODE_CHOICES,
    help=(
        "analyze one registered framework; repeat for multiple frameworks; "
        "use auto alone to detect markers; omit to run Spring and JAX-RS"
    ),
)

requested_frameworks = arguments.framework
if requested_frameworks is None:
    framework_mode = None
elif len(requested_frameworks) == 1:
    framework_mode = requested_frameworks[0]
else:
    framework_mode = tuple(requested_frameworks)
try:
    request = AnalysisRequest(input_path, framework_mode=framework_mode)
except ValueError as error:
    # Reject duplicate or mixed-auto selections before opening any output.
    parser.error(str(error))
```

Эта normalization происходит до инициализации любого output. Публичная
политика:

```bash
python3 src/noir_sbt.py \
  --path "/workspace/application" \
  --output "endpoints.csv" \
  --framework spring \
  --framework wicket
```

| Форма вызова | Запрошенная политика | Фактическое поведение |
|---|---|---|
| без `--framework` | `None` | default adapter'ы: сначала Spring, затем JAX-RS |
| `--framework spring` | scalar explicit | только Spring; существующий синтаксис не изменён |
| `--framework wicket` | scalar explicit | только Wicket; пустой lifecycle |
| `--framework spring --framework wicket` | tuple explicit | ровно Spring и Wicket |
| те же два option'а в обратном порядке | normalized tuple explicit | всё равно сначала Spring, затем Wicket |
| `--framework auto` | scalar marker policy | subset, выбранный marker'ами; Wicket advisory |
| дубликат или `auto` вместе с другим вхождением | invalid | отклоняется до инициализации output |

Есть два намеренно раздельных источника порядка.
`_normalize_framework_mode()` канонизирует tuple запроса в порядке enum
`FrameworkSelection`. Затем `adapters_for_plan()` отображает выбранные identity
в порядке `FRAMEWORK_ADAPTERS`, который управляет configuration,
announcement'ами не-auto режима, разделами inventory, preparation и analysis.
Сейчас порядки enum и adapter registry совпадают: Spring, JAX-RS, Wicket, но их
зоны ответственности остаются различными.

При добавлении семейства добавляйте только его enum-member. Default membership
принадлежит строке adapter, automatic selection — строке marker. Сохраняйте
историческое публичное написание в значении enum, даже если Python-имя member'а
понятнее, как демонстрирует `JAX_RS = "jaxrx"`.

## 4. Создайте один полный facade семейства

Создайте `src/noir/<family>_framework.py`. Он может импортировать нейтральные
module'и и module'и собственного семейства. Он не должен импортировать facade
или semantic analyzer другого семейства.

Три hook'а выполняют следующие роли:

| Hook | Когда вызывается | Работа во владении hook'а |
|---|---|---|
| `configure_*_workspace(workspace, *, selected)` | один раз для каждого зарегистрированного adapter | подключить index'ы выбранного семейства или установить его стабильную пустую shape, если оно не выбрано |
| `prepare_*_analysis(request, workspace)` | один раз для каждого выбранного adapter после inventory | вычислить ограниченное project-wide состояние, необходимое до начала любого анализа |
| `analyze_*_framework(request, source_paths, workspace)` | один раз для каждого выбранного adapter после всей preparation | выполнить детерминированные pass'ы семейства и вернуть неизменяемый tuple fact'ов |

Не выполняйте parsing ни в одном hook. Используйте
`workspace["compilation_units"]` и упорядоченные source path'ы, которыми уже
владеет запуск. Храните изменяемые cache и index внутри workspace или одного
run-local объекта analyzer.

Ниже приведён полный минимальный facade Wicket. Тело каждой функции — текущее
намеренное поведение; за stub не скрыто неявное route rule:

```python
"""Minimal executable Apache Wicket framework-integration example.

Explicit selection containing Wicket runs these hooks through the same
registry lifecycle as a real family. They intentionally provide no Wicket
endpoint semantics: the stub creates no annotation classifications, workspace
state, diagnostics, or endpoint facts from the raw-text marker.
"""

from __future__ import annotations

from typing import Any

from .model import AnalysisRequest, EndpointFact


def configure_wicket_workspace(
    _workspace: dict[str, Any], *, selected: bool
) -> None:
    """Leave the neutral workspace unchanged for either selection state."""

    return None


def prepare_wicket_analysis(
    _request: AnalysisRequest, _workspace: dict[str, Any]
) -> None:
    """Complete selected Wicket preparation without semantic state."""

    return None


def analyze_wicket_framework(
    _request: AnalysisRequest,
    _source_paths: tuple[str, ...],
    _workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return no facts rather than treating marker text as endpoint proof."""

    return ()


__all__ = [
    "analyze_wicket_framework",
    "configure_wicket_workspace",
    "prepare_wicket_analysis",
]
```

Этот module реализует исполняемую wiring, а не semantic coverage. Сохраняйте его
пустым, пока отдельно определённая source shape Wicket не задаст, что считается
route, какие declaration'ы им владеют и какие неоднозначные случаи необходимо
отклонять.

## 5. Зарегистрируйте facade один раз

Импортируйте hook'и только в статическом composition root:

```python
from .wicket_framework import (
    analyze_wicket_framework,
    configure_wicket_workspace,
    prepare_wicket_analysis,
)
```

Затем поместите эту полную запись в `FRAMEWORK_ADAPTERS` на позицию,
соответствующую требуемому порядку lifecycle:

```python
FrameworkAdapter(
    name="wicket",
    selection=FrameworkSelection.WICKET,
    announcement="Found Apache Wicket",
    default_selected=False,
    configure_workspace=configure_wicket_workspace,
    prepare_analysis=prepare_wicket_analysis,
    analyze=analyze_wicket_framework,
)
```

Позиция в tuple adapter'ов задаёт авторитетный порядок lifecycle и
presentation не-auto режима. Имена и selection identity должны быть
уникальными, каждая строка должна иметь допустимый enum identity, а все
предоставленные hook'и должны быть callable. Для нового семейства безопасная
начальная политика — `default_selected=False`.

Обычное добавление семейства не требует ветки pipeline. Если изменение,
по-видимому, требует `if family == ...` в `run_analysis()`, поместите эту работу
в hook facade или расширьте действительно framework-neutral контракт.

## 6. Определите политику marker отдельно

Marker необязателен. Добавляйте его только тогда, когда raw text полезен для
user-facing finding или selection в scalar-режиме `auto`. Он остаётся
parser-free и не может создавать fact'ы.

Ниже приведены полный detector Wicket и его текущая advisory-строка registry:

```python
import re
from types import MappingProxyType


def detect_wicket_marker(_source_path: str, source_text: str) -> bool:
    """Recognize the raw-text Wicket marker for announcement only."""

    return re.search(r"org\.apache\.wicket", source_text) is not None


# This complete expression is the Wicket row inside FRAMEWORK_MARKER_RULES.
MappingProxyType(
    {
        "finding_name": "Apache Wicket",
        "selection_mode": "manual",
        "input_kind": "java",
        "marker_detector": detect_wicket_marker,
        "report_hint": "",
        "auto_selected_framework": None,
    }
),
```

Позиция этой строки в tuple `FRAMEWORK_MARKER_RULES` управляет порядком
finding'ов и announcement'ов scalar-режима `auto`. Эта строка не является
отдельной регистрацией выполнения.

Для automatic execution используйте `selection_mode="auto"` и задавайте
`auto_selected_framework` равным точному значению enum только после того, как
marker становится приемлемой run-wide эвристикой selection. Advisory detection
сохраняет `selection_mode="manual"` и `auto_selected_framework=None`, как это
делает Wicket. Default selection всё равно остаётся отдельным решением adapter.

## 7. Добавляйте semantic support только тогда, когда этого требует source evidence

Пустой lifecycle не разрешает inference endpoint'ов. Добавляйте semantic-работу
по одной ограниченной source shape за раз и храните её политику в module'ях,
принадлежащих семейству.

### 7.1 Query и общие Java-fact'ы

Сначала используйте существующие capture. Когда необходимая нейтральная syntax
shape отсутствует:

- добавьте её query source в
  [`src/noir/java_queries.py`](../src/noir/java_queries.py);
- включите fact'ы отдельного compilation unit в
  `JAVA_COMPILATION_UNIT_QUERY_SOURCES`;
- включите дополнительные cross-file capture'ы в
  `JAVA_WORKSPACE_QUERY_SOURCES` — полный mapping, компилируемый обычным
  построением workspace;
- формируйте syntax в `java_frontend`, а cross-file identity — в
  `java_workspace`; и
- удерживайте query cursor/node только в пределах времени жизни workspace.

Не добавляйте package name'ы framework или route policy в нейтральный query
layer. Нейтральный capture сообщает, какой Java syntax существует; decoder
семейства решает, что этот syntax означает.

### 7.2 Константы, decoder'ы и index'ы

Помещайте общий для evidence или output vocabulary в
[`src/noir/contracts.py`](../src/noir/contracts.py). Помещайте package'и
framework, annotation identity, traversal limit'ы и route decoder'ы в module
владеющего семейства, если только ими действительно не пользуется более одного
нейтрального consumer'а.

Разрешайте точный library identity через import'ы, source declaration'ы,
visibility и shadowing. Совпадения по simple name или raw marker недостаточно.
Сохраняйте invalid и ambiguous candidate'ы до тех пор, пока владеющий decoder
не сможет fail closed, вместо выбора по порядку scan.

Family-specific cross-file index'ы должны находиться за контрактом
`configure_*_workspace`. Подключайте их заполненную форму, когда семейство
выбрано, и, если нейтральным consumer'ам нужны стабильные ключи, пустую форму,
когда оно не выбрано. Вычисляйте project-wide состояние в
`prepare_*_analysis` — после inventory и перед анализом первым семейством.

### 7.3 Broad и final-trigger inventory

Изменения inventory необязательны и должны следовать реализованной semantics:

- добавляйте строки `SUPPORTED_ANNOTATION_REGISTRY[adapter.name]` только для
  точных annotation identity, которые может классифицировать broad audit;
- добавляйте строки `FINAL_TRIGGER_ANNOTATION_REGISTRY[adapter.name]` только
  для поддерживаемых placement'ов, способных напрямую представлять
  declaration endpoint'а;
- расширяйте `source_defined_annotation_classifications()`, когда composed или
  source-defined annotation требует semantic proof, принадлежащего семейству;
  и
- расширяйте `source_defined_final_trigger_classifications()` только тогда,
  когда такая declaration сама является поддерживаемым endpoint trigger.

Broad inventory и final-trigger inventory выполняют разные задачи. Не
добавляйте supporting annotation в final-trigger registry только потому, что
он полезен в broad audit.

Если новая method annotation может поставлять evidence строки CSV, добавьте
её token семейства evidence и priority в `METHOD_ANNOTATION_FAMILY_PRIORITY`,
а каждый точный поддерживаемый identity отобразите в
`METHOD_ANNOTATION_FAMILY_BY_IDENTITY`. Поддерживайте значение `family_by_name`
в строке inventory согласованным с этим vocabulary.

Сейчас у Wicket нет записи inventory, ветки source-defined classification или
token'а семейства evidence. Это намеренно. Раздел выбранного Wicket всё равно
появляется в final-trigger inventory для каждого обнаруженного Java-файла в
порядке adapter registry и остаётся пустым.

## 8. Выдавайте типизированные fact'ы и evidence

Каждая успешная ветка семейства возвращает `EndpointFact`, а не CSV mapping.
Заполняйте только значения, подтверждённые реализованным source rule:

- route path и method;
- публичный source и имя handler;
- раздельный provenance для route, handler и project, когда владение различается;
- protocol, surface, direction и technology семейства; и
- annotation evidence с подтверждённым ownership и представленные source
  target'ы, где это применимо.

Используйте [`src/noir/evidence.py`](../src/noir/evidence.py) ::
`method_annotation_evidence_from_node()` для настоящей route annotation,
`represented_target_evidence()` — для точной declaration, покрываемой fact'ом,
и `deduplicate_endpoint_facts()` — когда одному producer'у нужна локальная
consolidation с сохранением evidence. Никогда не создавайте annotation evidence
искусственно из `source_line`.

Когда появится реальная semantics Wicket, подтверждённый fact может использовать
`technology="wicket"`; текущий пустой facade не должен выдавать выдуманный
пример. Записывайте отклонение поддерживаемого candidate через
`noir.diagnostics.record()` на самой узкой полезной границе. Неожиданные
ошибки программирования, parser или filesystem по-прежнему должны прерывать
запуск, а не превращаться в успешный результат без endpoint'ов.

## 9. Пусть generic output обрабатывает новое семейство

Pipeline объединяет проверенные fact'ы в порядке adapter registry и возвращает
`AnalysisResult`. CLI проецирует каждое семейство одним и тем же путём:

```text
EndpointFact
  -> EndpointRowCandidate
  -> six-field consolidation plus evidence union
  -> seven-column CSV and companion reports
```

Не записывайте файлы и не печатайте из facade. Не добавляйте ветку framework в
`output.py` или renderer report'ов, если сам стабильный контракт публичного
artifact не изменяется. Inventory builder'ы уже получают имена выбранных
adapter'ов, поэтому смешанные запуски сохраняют порядок разделов adapter
registry без report-specific dispatch.

Текущее поведение Wicket намеренно пустое:

- Wicket сам по себе создаёт CSV только с header;
- в mixed selection fact'ы поступают только от реализованных семейств;
- broad annotation log не содержит classification'ов Wicket;
- report отсутствующих endpoint'ов содержит пустой раздел Wicket для каждого
  обнаруженного Java-файла, расположенный в порядке adapter registry; и
- selection не-auto режима, содержащая Wicket, включает
  `Found Apache Wicket` в порядке announcement'ов adapter registry.

## 10. Сохраняйте public- и logic-документацию согласованными

Каждый новый facade должен содержать краткий module docstring, который
фиксирует его владение и ссылается на эту главу и соответствующую logic-главу
семейства. Каждый нетривиальный hook должен объяснять input, output, effects и
failure behavior. Сохраняйте комментарии, объясняющие порядок pass'ов,
обработку неоднозначности, владение evidence и намеренно пустое поведение.

Обновляйте те актуальные поверхности документации, которые действительно
изменились:

- `README.md` — при изменении публичного поведения CLI или output;
- `is/000.current.md` — при изменении текущего архитектурного контракта;
- `p6.logic.ru/README.md`, карту кода, указатель методов и карту методов core
  runtime — при изменении владения и call path'ов; и
- отдельную главу семейства, когда появляется реальная semantics endpoint'ов.

Экспортируйте hook'и facade через `__all__` этого facade. Package root обычно
не требует экспорта hook'ов семейства. Если там добавляются действительно
публичные application- или output-convenience, используйте существующий lazy
mapping `__getattr__` и объявляйте их через `__dir__`, не инициализируя
analyzer'ы во время `import noir`.

## 11. Guardrail'ы

| Guardrail | Требуемая shape |
|---|---|
| parse once | используйте `source_paths` и compilation unit'ы workspace; никогда не создавайте parser внутри семейства |
| fail closed | требуйте точное, доступное и однозначное source evidence; ограничивайте recursion и data flow |
| family isolation | facade семейства импортирует только module'и своего семейства и нейтральные module'и; semantic module'и не импортируют соседние семейства |
| generic pipeline | selection и lifecycle остаются registry-driven; в `pipeline.py` нет ветки dispatch семейства |
| run-local state | подключайте изменяемые index'ы и cache к workspace или instance analyzer'а; не изменяйте module registry во время запуска |
| typed boundary | выдавайте неизменяемые значения `EndpointFact` и типизированное evidence; выполняйте проекцию только в `output.py` |
| effect boundary | diagnostic'и можно записывать; artifact path'ы, запись и stdout остаются в `cli.py` |
| detector separation | marker rule может выбирать или советовать, но никогда не доказывает endpoint |
| stable policy | explicit selectability, membership режима с опущенным аргументом и eligibility scalar-auto — разные решения |
| deterministic composition | enum order канонизирует tuple запроса; adapter order независимо управляет runtime и presentation не-auto режима |

## 12. Минимальная матрица production-изменений

Используйте наименьшую строку, соответствующую требуемой capability:

| Требуемая capability | Необходимые изменения | Что оставить без изменений |
|---|---|---|
| исполняемое пустое семейство | enum-member; полный facade с тремя hook'ами; одна запись adapter с `default_selected=False`; актуальная документация владения | family-loop'ы pipeline, inventory, evidence, output, marker registry |
| явная комбинация с существующими семействами | никакого family-specific механизма кроме регистрации; повторяемый CLI и tuple запроса уже объединяют зарегистрированные adapter'ы | синтаксис CLI, ветки pipeline, renderer report'ов |
| membership режима с опущенным аргументом | установите только политику `default_selected` adapter после обоснования широкого выполнения | marker policy и explicit identity |
| advisory source finding | parser-free detector и manual marker-строка без auto-selected identity | adapter default и semantic analyzer |
| eligibility scalar-auto | строка detector изменена на automatic selection с точным enum-token | adapter default и правила proof endpoint'а |
| новая нейтральная Java shape | query source плюс shaping compilation unit/workspace у нейтрального владельца | package'и framework и semantics route |
| cross-file состояние семейства | shape выбранного/невыбранного index в configure; ограниченный project derivation в prepare | владение parser и соседние facade'ы |
| видимость broad annotation | строка точного поддерживаемого annotation и при необходимости ветка source-defined classification | final-trigger inventory, если annotation напрямую не представляет endpoint |
| видимость endpoint trigger | строка final-trigger, placement rule, represented target и vocabulary семейства evidence, когда применимо | framework-ветки, специфичные для renderer |
| реальное извлечение endpoint'ов | один semantic pass во владении семейства, возвращающий полностью подтверждённые значения `EndpointFact` и evidence с подтверждённым ownership | publication CLI и публичная проекция, если контракт artifact не меняется |
| изменение public API или behavior | соответствующие README/current-state/logic map и lazy-root map, только если новое root-convenience действительно публично | eager-import'ы analyzer в package root |

Для Wicket сейчас активны только строки исполняемого пустого семейства и
advisory source finding. Превращение stub'а в реальный analyzer начинается с
заданной source shape Wicket, а затем добавляет только необходимые этой shape
query, decoder, inventory, evidence и fact. Активация default или scalar-auto
остаётся отдельным решением production policy.

Вернуться к [оглавлению руководства по логике](README.md).
