# 06 — Логика JAX-RS и Java WebSocket

[← Дополнительные поверхности Spring](05-spring-additional-surfaces.md) · [Оглавление](README.md) · [Далее: Output и evidence →](07-output-evidence-reports.md)

CLI token для этой ветки — `jaxrx`. Она создаёт два разных inbound-семейства
из одного parse-once Java workspace:

1. HTTP resources JAX-RS, включая методы из hierarchy и subresources.
2. Routes handshake Java WebSocket, объявленные через `@ServerEndpoint`.

Все producers возвращают неизменяемые значения
[`EndpointFact`](../src/noir/model.py).

Дополнение на уровне методов:
[14 — Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) прослеживает
прямые resources, выбор deployment, привязку hierarchy, recursion subresource
и построение WebSocket fact.

## 1. Владение и порядок выполнения

| Владелец | Entry point | Ответственность |
|---|---|---|
| [`noir.pipeline`](../src/noir/pipeline.py) | `_analyze_jaxrs()` / `run_analysis()` | Упорядочивает deployment, прямые units, анализ hierarchy и WebSocket. |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `build_java_compilation_unit()` | Разбирает один snapshot source и записывает syntax/query facts. |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace()` | Строит нейтральные индексы type, member, annotation и constant. |
| [`noir.jaxrs`](../src/noir/jaxrs.py) | `attach_workspace_indexes()` / `analyze_direct_jax_rs_unit()` | Индексирует designators и applications; анализирует прямые resources. |
| [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) | `build_jax_rs_deployment_model()` / `select_jax_rs_deployment_prefix()` | Объединяет source applications с ограниченным evidence `web.xml`. |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaSourceHierarchyGraph` | Владеет нейтральной hierarchy, generic adaptation и erased signatures. |
| [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) | `analyze_jax_rs_hierarchy_and_subresources()` | Разрешает annotation bundles, implementations и traversal locator. |
| [`noir.java_websocket`](../src/noir/java_websocket.py) | `analyze_java_websocket_endpoints()` | Извлекает handshakes WebSocket Javax/Jakarta. |

```mermaid
sequenceDiagram
    participant P as run_analysis
    participant W as общий Java workspace
    participant I as inventories
    participant D as deployment model
    participant J as прямой JAX-RS
    participant H as hierarchy/subresources
    participant S as Java WebSocket

    P->>W: один раз разобрать каждый source и подключить indexes
    P->>I: построить broad и final-trigger inventories
    P->>D: объединить evidence ApplicationPath и web.xml
    loop каждый compilation unit
        P->>J: analyze_direct_jax_rs_unit
    end
    P->>H: добавить inherited и locator-reached facts
    P->>S: добавить facts ServerEndpoint
    P-->>P: вернуть типизированный AnalysisResult
```

Когда работают обе framework-ветки, они разделяют этот workspace и deployment
state. Spring endpoint passes предшествуют JAX endpoint passes; ни одна ветка
не разбирает source повторно.

JAX-specific продукты workspace:

| Key | Значение |
|---|---|
| `jax_rs_custom_designator_candidates` | релевантные identities source-аннотаций, включая невалидные candidates |
| `jax_rs_custom_designators` | доказанные custom designators request-method |
| `jax_rs_applications` | source-записи `@ApplicationPath`, включая неразрешённые paths |
| `jax_rs_deployment_model` | deployment keys project/application после объединения evidence source и descriptor |

Запоминание невалидных candidates designator намеренно: использование
релевантной, но невалидной аннотации должно отравить выбор method, а не
выглядеть несвязанным.

## 2. Уравнения route

Для прямого root method:

```text
deployment prefix + root @Path + method @Path = endpoint path
```

Для inherited method или leaf subresource:

```text
deployment prefix
+ root @Path
+ selected interface contract @Path layers
+ locator @Path segments
+ leaf @Path
= endpoint path
```

Каждый включённый segment должен разрешаться статически. Request method
происходит ровно из одного валидного стандартного или custom designator.
Частичные paths никогда не выдаются.

## 3. Доказательство семейства Javax/Jakarta

Поддержка JAX-RS симметрична для `jakarta.ws.rs` и `javax.ws.rs`, а core types
находятся в соответствующем package `.core`.

| Evidence | Правило семейства |
|---|---|
| root `@Path` | задаёт семейство resource |
| стандартный designator | должен соответствовать root |
| custom designator | его настоящий `@HttpMethod` задаёт совпадающее семейство |
| method `@Path` | должен соответствовать root |
| `@ApplicationPath` | должен соответствовать непосредственно расширяемому core `Application` |
| annotation bundle hierarchy | каждая распознанная поддерживаемая JAX-аннотация должна принадлежать одному семейству |
| `@ServerEndpoint` | независимое семейство `jakarta.websocket` или `javax.websocket` |

Resolution учитывает imports и source. Локальные types, конфликты
exact/wildcard, недоступные declarations, смешанные семейства и дублирующиеся
fully qualified source identities приводят к fail-closed.

## 4. Custom designators request-method

[`index_jax_rs_custom_designators`](../src/noir/jaxrs.py) проверяет объявления
source-аннотаций до разрешения любого их использования. Валидное объявление
имеет:

1. ровно один настоящий Javax/Jakarta `@HttpMethod`;
2. ровно один настоящий `java.lang.annotation.Retention`;
3. `RetentionPolicy.RUNTIME`, разрешённый через правила Java name/static-member;
4. статически разрешённый String token;
5. token длиной не более 128 символов; и
6. token, соответствующий HTTP token grammar.

Общий constant resolver поддерживает ограниченные source constants,
concatenations, parentheses, точные static imports и однозначные static
wildcards. Он отвергает циклы, mutable/inaccessible fields, неправильные types,
неоднозначных owners и expressions сверх лимита.

[`resolve_custom_designator`](../src/noir/jaxrs.py) затем разрешает применённую
аннотацию ровно в одно доступное source declaration и одну валидную index
record. Результат — `none`, `resolved`, `invalid` или `ambiguous`. Релевантный
невалидный или неоднозначный результат делает выбор request-method невалидным.

Custom-аннотации только из dependency нельзя доказать, поскольку их
declarations и retention evidence отсутствуют в workspace.

## 5. Стандартные designators и paths метода

Моделируются стандартные аннотации `GET`, `POST`, `PUT`, `DELETE`, `PATCH`,
`HEAD` и `OPTIONS`. Стандартный designator должен иметь marker-форму;
arguments, несколько designators, смешанные семейства или релевантный
невалидный custom designator отвергают метод.

`@Path` уровня метода необязателен. Если присутствует, должна разрешиться ровно
одна настоящая аннотация семейства root с одним значением. Принимается один
positional value или один named `value`; смешивание этих форм, дополнительные
attributes, отсутствие/несколько values или неразрешённые expressions приводят
к fail-closed. Если аннотация отсутствует, используется пустой segment.

## 6. Source index `@ApplicationPath`

[`index_jax_rs_application_paths`](../src/noir/jaxrs.py) принимает конкретный
source class с ровно одним настоящим `@ApplicationPath` и прямым superclass
соответствующего core type `Application`. Непрямое наследование не создаёт
application record; public visibility не требуется.

Формы failure намеренно различаются:

| Условие | Результат |
|---|---|
| abstract application | диагностируется и исключается |
| несовпадение семейства или неразрешённый/непрямой superclass | диагностируется и исключается |
| несколько настоящих аннотаций | сохраняются невалидные records с null-path |
| одна аннотация с неразрешённым value | сохраняется одна record с null-path |
| одна разрешённая аннотация | валидная application record |

Исключённое application может оставить пустой prefix. Сохранённый null path
участвует в неоднозначности и может подавлять затронутые endpoints.

## 7. Прямой анализ resource

[`analyze_direct_jax_rs_unit`](../src/noir/jaxrs.py) получает compilation unit
из общего workspace.

### 7.1 Gate корня

Прямой root — видимый в workspace, нелокальный, конкретный class или record с
ровно одним настоящим разрешимым прямым `@Path`. Вложенный type с собственным
прямым path — независимый root; лексические внешние paths не наследуются.

Прямой pass не требует public root, уникальной fully qualified addressability
или доказанного runtime construction.

### 7.2 Gate метода

Для каждого прямого method под подходящим root:

1. разрешить ровно один designator request-method;
2. потребовать явный modifier `public`;
3. разрешить ноль или один `@Path` того же семейства;
4. выбрать один deployment prefix;
5. скомпоновать и выдать `EndpointFact`.

Метод с `@Path`, но без designator, не является прямым endpoint; анализ
hierarchy может использовать его как locator.

### 7.3 Accessor-методы компонентов record

Аннотации компонента могут описывать его неявный accessor без аргументов.
Участвуют только стандартные designators, `@Path` и source-аннотации с
доказанной применимостью к methods. Компонент игнорируется, если record
объявляет явный accessor того же имени без параметров.

Синтезированный fact использует имя компонента, пустые parameters и компонент
record как `represented_targets`. Его `annotation_evidence` пуст, потому что
request-аннотация находится не на declaration метода; поэтому строка CSV тоже
пуста.

## 8. Deployment model и `web.xml`

[`build_jax_rs_deployment_model`](../src/noir/jaxrs_deployment.py) объединяет
source applications с ограниченным evidence servlet descriptor.

### 8.1 Владение project и source keys

Ближайший layout, содержащий `src/main/java`, `src/main/resources` или
`src/main/webapp`, определяет владение project. Без marker project считается
analysis root. Key source application имеет вид:

```text
(project root, application package, Javax/Jakarta family)
```

Records с общим key сливаются, только если каждый path разрешён и все paths
совпадают; иначе prefix key неизвестен.

### 8.2 Bounds descriptor

Рассматриваются только regular files с точным именем `web.xml`. Discovery
отсекает ignored directories, `src/test` и `src/it`; исключает symlinks и файлы
больше 10 MiB; диагностирует нечитаемый или malformed XML.

Parser читает прямые servlet declarations, init parameters, mappings и URL
patterns. Mapping релевантен, если его servlet class совпадает с ограниченным
набором имён Jersey/RESTEasy/CXF или если его servlet/init parameters называют
поддерживаемый application class. Поддерживаемые имена init parameter:
`javax.ws.rs.Application` и `jakarta.ws.rs.Application`.

Нормализация URL pattern:

| Pattern | Prefix |
|---|---|
| `/api/*`, `/api/`, `api/*` | `/api` |
| `/` | пустой |
| `/*` | `/` |

Явный mapping, связанный с application key, переопределяет Java
`@ApplicationPath`; конфликтующие явные values делают key неизвестным. Один
несвязанный распознаваемый servlet prefix может применяться к известным source
applications, только если все такие mappings совпадают и в project нет
explicit application key. Descriptor сам по себе не создаёт endpoints.

### 8.3 Выбор prefix

[`select_jax_rs_deployment_prefix`](../src/noir/jaxrs_deployment.py) фильтрует по
project resource, совместимому семейству и packages application, являющимся
ancestors package resource. Он сохраняет наиболее специфичный package,
предпочитает explicit descriptor evidence, затем exact family evidence, и
требует, чтобы все оставшиеся candidates совпали в одном валидном path.

Отсутствие candidates означает пустой prefix, кроме узкого fallback для
единственного project с нестандартным layout: resource должен принадлежать
этому единственному project, а все совместимые entries — совпадать.
Неоднозначность диагностируется и подавляет endpoint.

Если deployment model не подключена, `resolve_jax_rs_resource_prefix()`
использует `jax_rs_applications` с теми же принципами наиболее специфичного
package/agreement. Обычный pipeline сначала всегда подключает полную model.

## 9. Привязка hierarchy

[`noir.java_hierarchy`](../src/noir/java_hierarchy.py) владеет уникальными
видимыми source types, edges class/interface, generic substitutions, source
methods, erased signatures и выбором максимально специфичного/default
interface. Дублирующиеся fully qualified identities исключаются из graph.

[`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) добавляет классификацию
JAX-аннотаций, atomic inheritance bundle, binding implementation, layers path
interface и traversal locator.

### 9.1 Bounds и implementations

| Bound | Значение |
|---|---:|
| depth hierarchy | 12 |
| расширенные states hierarchy | 256 |
| generic environment для одного interface | одно согласованное environment |

Identity override — имя метода плюс erased parameter types; return type не
входит в signature. Generic environments подставляются до erasure.

Пригодная implementation является non-static, non-private, non-abstract и
либо явно public методом class/record, либо default методом interface с телом.
Дублирующиеся erased signatures, неразрешённые signature types, неоднозначные
classes/defaults и несопоставимые annotation origins приводят к fail-closed.

### 9.2 Неделимые annotation bundles

Annotation bundle выбранного метода неделим:

- любая прямая аннотация, кроме настоящего `java.lang.Override`, или любая
  прямая аннотация параметра делает implementation source bundle;
- иначе побеждает ближайший подходящий bundle superclass;
- иначе может победить один максимально специфичный bundle interface;
- несколько или невалидные origins отвергают signature.

Весь поддерживаемый bundle проверяется на одно семейство Javax/Jakarta.
Поведение route происходит из `@Path` и request designator. Supporting
annotations, такие как consumes/produces, context, suspended и parameter
bindings, классифицируются, но их runtime behavior не моделируется.

Если метод interface предоставляет выбранный bundle, один настоящий
`@Path` уровня типа того же семейства на этом interface добавляет слой path.
Path уровня superclass этим правилом не добавляется.

## 10. Locators subresource

Эффективный метод является leaf, если имеет request designator, либо locator,
если имеет непустой `@Path` без designator.

Target locator должен однозначно разрешаться в конкретный source class или
record. Поддерживаются direct declared type, `Class<T>`, точный parameterized
source type и raw generic source type с его ограниченным default environment.
Отвергаются interfaces, abstract/external/duplicate/inaccessible types,
primitives, arrays и wildcards, неразрешённые variables, malformed arity и
формы не-resource.

Path метода locator определяет переход; собственный type-level `@Path` target
не добавляется.

Traversal является branch-local и ограничен depth 16, 4096 states на root и
8192 символами составного path. Активные циклы type/edge останавливают эту
ветвь. Leaf hierarchy/subresource выдаётся только при достижении через locator
или добавлении через hierarchy binding, что предотвращает дублирование обычных
прямых leaves.

[`deduplicate_endpoint_facts`](../src/noir/evidence.py) удаляет локальные для
analyzer дубликаты по typed identity и объединяет их annotation/target
evidence. Public consolidation по шести полям остаётся более поздней границей.

## 11. Handshake'и Java WebSocket

[`analyze_java_websocket_endpoints`](../src/noir/java_websocket.py) распознаёт
`jakarta.websocket.server.ServerEndpoint` и
`javax.websocket.server.ServerEndpoint` на одном уникальном workspace type.

Тип и каждый enclosing type должны быть public и видимыми. Class конкретен;
вложенный class статичен; и он имеет неявный или явный public constructor без
аргументов. Record должен иметь ноль компонентов. Остальные kinds type
отвергаются.

Аннотация принимает один positional value или named `value`. Смешивание форм,
отсутствующие/несколько values, неразрешённые constants, пустые paths, queries
или fragments приводят к fail-closed. При отсутствии начального slash он
добавляется. Атрибуты encoder, decoder, subprotocol и configurator не влияют на
identity route.

Deployment prefix JAX не применяется. Выданный fact использует:

| Поле | Значение |
|---|---|
| method | `GET` |
| protocol / surface / direction | `ws` / `websocket` / inbound |
| technology | `jax-websocket` |
| handler | endpoint type |
| annotation evidence | пустое |
| represented target | аннотированный type |

`@ServerEndpoint` не является evidence request-method, поэтому публичная
ячейка строки аннотации пуста.

## 12. Типизированный provenance и diagnostics

Прямые JAX methods записывают handler method как represented target, а
применённый стандартный/custom designator — как annotation evidence.
Синтезированные accessor record представляют компонент и не несут method
evidence.

Facts hierarchy и subresource всегда приписывают public handler и target
выбранной implementation. Аннотация superclass/interface может доказать route,
но даёт evidence строки CSV только тогда, когда её source method является
method реализации. Поэтому evidence между declarations оставляет public line
пустой.

Diagnostics проходят через
[`noir.diagnostics.record`](../src/noir/diagnostics.py). Привязанный collector
application/CLI захватывает их; непривязанный прямой call analyzer остаётся без
file I/O и просто не захватывает сообщение. Diagnostics не восстанавливаются
из endpoint facts.

## 13. Bounds и пределы доказательства

| Bound или неопределённость | Limit / область сохранения |
|---|---|
| Java constant depth / разрешённый string | 12 / 8192 символов |
| custom HTTP token | 128 символов |
| размер descriptor | 10 MiB |
| hierarchy | depth 12, 256 states |
| traversal locator | depth 16, 4096 states на root |
| составной path locator | 8192 символов |
| плохой root `@Path` | прямые методы root |
| невалидный/множественный/смешанный designator | method или binding |
| non-public прямой метод | method |
| неоднозначный deployment prefix | связанные endpoints |
| неполная hierarchy | неопределённые inherited additions, но не direct facts |
| невалидный return locator/cycle/limit | ветвь locator или budget root |
| невалидный type/path `@ServerEndpoint` | WebSocket type |
| malformed descriptor | descriptor; остальное evidence сохраняется |

Эта model не доказывает runtime scanning/registration, designators или
hierarchies из dependency bytecode, dynamic locator polymorphism,
constructor/injection viability для прямых roots, filters, proxies, hosts,
authentication, authorization, полную семантику parameter/media, WebSocket
callbacks или runtime deployment reachability за пределами ограниченного
source и descriptor evidence выше.

Далее: [07 — Output, evidence и reports](07-output-evidence-reports.md).
