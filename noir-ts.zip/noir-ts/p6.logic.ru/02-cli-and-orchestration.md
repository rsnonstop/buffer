# 02 — CLI и orchestration

[← Ментальная модель](01-mental-model.md) · [Индекс](README.md) · [Общий Java engine →](03-shared-java-engine.md)

Эта глава прослеживает один вызов от аргументов до неизменяемых результатов
анализа и опубликованных artifact'ов. Центральное правило владения:

> `noir.pipeline` задаёт порядок анализа; `noir.cli` владеет пользовательским
> input, файлами и stdout.

Дополняющая глава уровня методов: [12 — Методы core runtime](12-core-runtime-methods.md)
раскрывает этот route через точных caller'ов, значения, эффекты и выходы с
ошибкой.

Основные координаты кода:

- launcher: [`src/noir_sbt.py`](../src/noir_sbt.py);
- CLI: [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()`;
- типизированная точка входа приложения:
  [`src/noir/application.py`](../src/noir/application.py) :: `analyze()`;
- порядок stage'ей: [`src/noir/pipeline.py`](../src/noir/pipeline.py) ::
  `run_analysis()`;
- значения: [`src/noir/model.py`](../src/noir/model.py);
- discovery: [`src/noir/discovery.py`](../src/noir/discovery.py);
- diagnostic'и: [`src/noir/diagnostics.py`](../src/noir/diagnostics.py);
- projection и publication:
  [`src/noir/output.py`](../src/noir/output.py),
  [`src/noir/reports.py`](../src/noir/reports.py) и
  [`src/noir/comparison.py`](../src/noir/comparison.py).

## 1. Runtime route

`src/noir_sbt.py` импортирует `noir.cli.main` и завершается с возвращённым им
status. Логики приложения в нём нет.

~~~mermaid
flowchart LR
    U["CLI caller"] --> L["src/noir_sbt.py"]
    L --> CLI["noir.cli.run_cli"]
    CLI --> APP["noir.application.analyze"]
    APP --> PIPE["noir.pipeline.run_analysis"]
    PIPE --> JAVA["общий Java workspace"]
    JAVA --> PASS["Pass'ы Spring и JAX-RS"]
    PASS --> FACT["Значения EndpointFact"]
    FACT --> RESULT["AnalysisResult"]
    RESULT --> OUT["projection и report'ы"]
    OUT --> FILES["CSV и сопутствующие artifact'ы"]
~~~

Package-код никогда не импортирует launcher. Framework analyzer'ы потребляют
Java fact'ы, создают значения `EndpointFact` и записывают diagnostic'и. Они не
разбирают аргументы, не печатают и не публикуют файлы.

## 2. Типизированная граница приложения

Программный вызов выглядит так:

~~~python
from noir.application import analyze
from noir.model import AnalysisRequest

result = analyze(AnalysisRequest(source_root, framework_mode="spring"))
~~~

| Тип | Роль |
|---|---|
| `AnalysisRequest` | resolved root анализа и запрошенный framework mode |
| `FrameworkPlan` | запрошенный mode и эффективный упорядоченный выбор framework'ов |
| `EndpointFact` | route, handler, metadata protocol/surface и типизированное evidence |
| `AnalysisResult` | неизменяемые endpoint fact'ы, diagnostic'и, inventory, detection'ы и announcement'ы |

`AnalysisRequest` выполняет expand и resolve своего root и проверяет запрошенный
mode. Существование directory проверяет CLI, а не value type.

При projection endpoint fact'ов в CSV row'ы `run_cli()` использует basename
входной directory; output identity остаётся за пределами request приложения.

`noir.application.analyze()` владеет одним diagnostic scope. Если передан или
уже привязан collector, он использует его повторно, иначе создаёт новый. Он
запоминает начальный offset и присоединяет к возвращаемому `AnalysisResult`
только diagnostic'и, добавленные этим вызовом. Поэтому вложенные вызовы не
присваивают ранние сообщения внешнего вызова.

Граница приложения не выполняет CLI parsing и artifact I/O. `AnalysisRunner`
можно внедрять лишь для того, чтобы независимо тестировать эту небольшую
границу; production использует `run_analysis`.

## 3. Контракт CLI

~~~text
usage: noir_sbt.py [-h] --path PATH --output OUTPUT
                   [--framework {spring,jaxrx,auto}]
                   [--noir-report NOIR_REPORT]
~~~

| Аргумент | Обязателен | Значение |
|---|---:|---|
| `--path` | да | directory, анализируемая как единый Java workspace |
| `--output` | да | destination для endpoint CSV |
| `--framework spring` | нет | выбрать только Spring |
| `--framework jaxrx` | нет | выбрать только JAX-RS |
| `--framework auto` | нет | выбрать по узкому registry raw-text marker'ов |
| `--framework` не указан | — | выбрать сначала Spring, затем JAX-RS |
| `--noir-report` | нет | сравнить Noir v1.1 report с широким annotation inventory по каноническим source-файлу и строке |

`--path` проходит expand и resolve и должен указывать на существующую
directory. В `--output` раскрывается `~`, но путь не разрешается, поэтому
относительный destination остаётся относительно working directory процесса.
Родительские directory не создаются.

`--noir-report` проходит expand и resolve и должен указывать на существующий
файл. CLI загружает и проверяет его до создания или усечения output. Он
отклоняет некорректные JSON или формы report'а, некорректные значения строк,
неоднозначные интерпретации source-path и input, который является тем же
filesystem-файлом, что и любой производный output destination.

Source location Noir без номера строки не участвует в сравнении. Если строка
присутствует, это должно быть положительное целое число, не являющееся Boolean.
Относительные source-имена разрешаются от root анализа; неоднозначные варианты
написания с сохранённым root-prefix обрабатываются fail-closed. Подробные
правила сравнения приведены в главе
[07 — Output, evidence и report'ы](07-output-evidence-reports.md).

Конструирование argument parser не требует тяжёлых dependency, поэтому
`--help` работает без установленных package'ей Tree-sitter.

## 4. Порядок анализа

[`noir/pipeline.py`](../src/noir/pipeline.py) владеет следующей
однонаправленной последовательностью:

~~~mermaid
flowchart TD
    R["AnalysisRequest"] --> Gate["1. Проверить пару Tree-sitter"]
    Gate --> Snap["2. Найти Java-файлы и создать snapshot byte'ов"]
    Snap --> Select["3. Выбрать framework'и"]
    Select --> Work["4. Построить один runtime и workspace"]
    Work --> Audit["5. Построить широкий annotation inventory"]
    Audit --> Trigger["6. Построить final-trigger inventory для выбранных framework'ов"]
    Trigger --> Deploy["7. Построить JAX-RS deployment model, если выбран JAX-RS"]
    Deploy --> Spring{"Spring выбран?"}
    Spring -- да --> SP["8. Запустить упорядоченные Spring pass'ы"]
    Spring -- нет --> JAX
    SP --> JAX{"JAX-RS выбран?"}
    JAX -- да --> JP["9. Запустить упорядоченные JAX-RS pass'ы"]
    JAX -- нет --> Result["10. Проверить fact'ы и вернуть AnalysisResult"]
    JP --> Result
~~~

`require_tree_sitter()` принимает строго следующие версии:

~~~text
tree-sitter      0.25.2
tree-sitter-java 0.23.5
~~~

Отсутствующая или отличающаяся пара вызывает `RuntimeError`.

`_snapshot_sources()` находит Java-файлы по suffix `.java` без учёта регистра,
отсекает настроенные игнорируемые directory, сортирует по project-relative
имени и один раз читает каждый файл как byte'ы. `SourceSnapshot` требует
точного совпадения своего tuple путей и ключей content и предоставляет
неизменяемый content.

`_build_workspace()` создаёт один parser/query runtime и один раз разбирает
каждый файл из snapshot. Direct-цикл Spring вызывает
`analyze_direct_spring_mvc_unit(unit, workspace)`, а direct-цикл JAX-RS —
`analyze_direct_jax_rs_unit(unit, workspace)`; project-wide analyzer'ы повторно
используют тот же workspace.

### Порядок Spring pass'ов

1. direct MVC для каждого source;
2. functional route'ы и programmatic registration'ы;
3. MVC hierarchy;
4. Gateway;
5. static resource'ы;
6. HTTP Interface и OpenFeign client'ы;
7. построение project path configuration;
8. WebSocket handshake'и и messaging destination'ы;
9. применение project path configuration ко всем Spring fact'ам.

### Порядок JAX-RS pass'ов

1. direct resource'ы для каждого compilation unit;
2. hierarchy и рекурсивные subresource'ы;
3. handshake'и Java WebSocket server.

В комбинированном запуске полная последовательность Spring завершается до
начала direct-анализа JAX-RS. Project-wide pass'ы пропускаются, если compilation
unit'ов нет.

Каждый результат analyzer'а должен быть `EndpointFact`. Если analyzer нарушает
этот контракт, `run_analysis()` вызывает `TypeError` до конструирования result.

## 5. Выбор framework'ов и announcement'ы

Для неуказанного и явно заданных mode'ов marker scanning не запускается.

| Запрошенный mode | Эффективный упорядоченный выбор | Announcement'ы |
|---|---|---|
| не указан | Spring, JAX-RS | `Found SpringBoot Annotation`; `Found JaxRS` |
| `spring` | Spring | `Found SpringBoot Annotation` |
| `jaxrx` | JAX-RS | `Found JaxRS` |
| `auto` | семейства, выбранные marker-правилами | одна строка на каждую уникальную находку в порядке registry |

`auto` сканирует Java-byte'ы из snapshot и отдельно найденные файлы `pom.xml`.
Java-файлы второй раз не читаются.

| Находка | Input | Выбирает семейство? |
|---|---|---|
| SpringBoot Annotation | Java-marker Spring MVC или functional-router | Spring |
| SpringBoot Route | Java-marker functional-router | нет |
| SpringBoot Codegen | marker Maven generator | нет; announcement содержит подсказку о generated-source |
| Apache Wicket | Java-marker | нет |
| JaxRS | Java-marker `jakarta.ws.rs` или `javax.ws.rs` | JAX-RS |

Scan выполняется как сырой, регистрозависимый поиск текста и включает
комментарии и строковые литералы. Это evidence для выбора, а не semantic proof
endpoint'а. Он может выбрать семейство по тексту, не являющемуся кодом, и может
пропустить поддерживаемые surface'ы, если package-marker'ы отсутствуют. Самый
широкий запуск получается при отсутствии `--framework`.

Каждое вхождение находки/файла записывается как diagnostic. Announcement'ы
хранятся в `AnalysisResult` и следуют порядку registry. CLI печатает их после
успешного анализа, но до projection и publication. Поэтому последующая ошибка
может оставить output `Found ...` без итогового completion inventory.

Если `auto` не выбирает ни одного семейства, pipeline всё равно проверяет
dependency, строит snapshot, workspace и широкий annotation inventory, после
чего возвращает пустой список endpoint'ов. CLI публикует CSV только с header,
его log и пустой endpoint-trigger report.

## 6. Diagnostic'и

[`noir/diagnostics.py`](../src/noir/diagnostics.py) владеет:

- `DiagnosticCollector`: thread-safe коллекция in-memory entries с внедряемыми часами;
- `bind()`: выбор в scope с гарантированным восстановлением;
- `record()`: добавляет запись в выбранный collector или ничего не делает,
  если ни один не выбран;
- `format_endpoint_diagnostic()`: стабильное форматирование сообщения о
  принятом endpoint.

CLI привязывает один collector вокруг анализа, rendering и publication и до
анализа записывает строку framework-mode. Сопутствующий log содержит сначала
annotation-audit inventory, затем строки collector'а с timestamp.

Выбор collector'а локален для task/thread и восстанавливается при обычном
возврате и при исключениях. Вложенный вызов приложения возвращает только
entry, добавленные во время этого вызова; внешний collector по-прежнему
сохраняет сообщения, записанные, пока его запуск был активен. В самом
`AnalysisDiagnostic` нет timestamp; добавление timestamp принадлежит
`DiagnosticEntry` для представления в report.

## 7. Порядок artifact'ов

После анализа `run_cli()` выполняет следующие операции:

1. проецирует каждый `EndpointFact` в `EndpointRowCandidate`;
2. нормализует и консолидирует row'ы, объединяя private evidence;
3. формирует endpoint-trigger report;
4. если включено, сравнивает широкий annotation inventory с Noir и формирует
   comparison report;
5. формирует completion inventory в памяти;
6. напрямую записывает CSV;
7. напрямую записывает diagnostic log;
8. атомарно заменяет endpoint-trigger report;
9. атомарно заменяет Noir comparison report, если он включён;
10. печатает completion inventory и возвращает `0`.

~~~mermaid
flowchart TD
    A["Проверить аргументы и необязательный Noir input"] --> L["Создать или усечь diagnostic log"]
    L --> B["Привязать collector и выполнить анализ"]
    B --> C["Напечатать framework announcement'ы"]
    C --> D["Выполнить projection и consolidation"]
    D --> E["Сформировать report'ы и completion-текст"]
    E --> F["Записать CSV"]
    F --> G["Записать diagnostic log"]
    G --> H["Опубликовать endpoint-trigger report"]
    H --> I{"Comparison включён?"}
    I -- да --> J["Опубликовать comparison report"]
    I -- нет --> K["Напечатать completion inventory"]
    J --> K
~~~

Строка завершения `noir-ts analysis completed.` появляется только после
успешной publication всех запрошенных artifact'ов. Она никогда не печатается
при ошибках анализа, projection, rendering или записи.

### Имена artifact'ов

| `--output` | Diagnostic log | Endpoint-trigger report | Noir comparison report |
|---|---|---|---|
| `endpoints.csv` | `endpoints.csv.log` | `endpoints-anno-without-endpoints.log` | `endpoints-anno-without-noir-endpoints.log` |
| `endpoints.audit.csv` | `endpoints.audit.csv.log` | `endpoints.audit-anno-without-endpoints.log` | `endpoints.audit-anno-without-noir-endpoints.log` |
| `endpoints` | `endpoints.log` | `endpoints-anno-without-endpoints.log` | `endpoints-anno-without-noir-endpoints.log` |

При выводе имени каждого из двух byte-report'ов удаляется только последний
suffix. Запуск без `--noir-report` не создаёт и не удаляет более ранний
comparison artifact.

CSV и diagnostic log записываются напрямую. Каждый byte-report полностью
формируется, помещается во временный файл рядом с destination, сбрасывается и
синхронизируется через `fsync()`, а затем устанавливается посредством
`os.replace()`. При ошибке publication byte-report очищает staging-state, но
не откатывает уже опубликованные файлы.

## 8. Границы ошибок

Набор artifact'ов упорядочен, но не является одной filesystem-транзакцией.

| Точка ошибки | Наблюдаемое состояние |
|---|---|
| help, ошибка аргументов, некорректная input directory или некорректный Noir input | ни один artifact не инициализирован |
| инициализация diagnostic log | log может не записаться или быть усечён; другие artifact'ы не меняются |
| контролируемый `RuntimeError` анализа | CSV и byte-report'ы не меняются; log формируется с `ERROR:`; argparse завершается с кодом `2` |
| другая ошибка анализа, projection, comparison или rendering | CSV и byte-report'ы не меняются; log по возможности перезаписывается; исходное исключение выбрасывается повторно |
| ошибка записи CSV | CSV может оказаться частичным; log по возможности перезаписывается; byte-report'ы не меняются |
| ошибка записи diagnostic log | новый CSV остаётся; byte-report'ы не меняются |
| ошибка publication endpoint-trigger | новые CSV и log остаются; прежние byte-report'ы остаются |
| ошибка publication comparison | новые CSV, log и endpoint-trigger report остаются; прежний comparison report остаётся |
| успех | все запрошенные output готовы; completion inventory напечатан |

`SystemExit`, `KeyboardInterrupt` и другие подклассы `BaseException` не попадают
в общую recovery-ветвь `except Exception`. Ветвь контролируемого `RuntimeError`
явно записывает свой log до завершения через error-exit argparse.

Completion inventory перечисляет созданные artifact'ы, используя эффективные
написания output-путей, и отдельно обозначает разрешённый Noir report как
input. Его точная формулировка принадлежит `render_completion_summary()` и
тестируется на границе CLI.

Продолжение: [03 — Общий Java engine](03-shared-java-engine.md).
