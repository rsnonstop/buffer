# 12 — Core runtime: от точки входа до уровня методов

[← Именование и словарь](11-naming-and-code-vocabulary.md) ·
[Индекс](README.md) · [Методы Spring →](13-spring-methods.md)

Эта глава дополняет руководство уровня модулей картой native runtime на уровне
методов. Она охватывает команду и нейтральный к framework'ам Java engine;
method maps для конкретных framework'ов продолжаются в главах о Spring и
JAX-RS. Если руководство когда-либо разойдётся с кодом, авторитетным источником
является текущий source.

Практическое обещание этой главы просто: если читатель встречает в коде важный
core-symbol, поиск его точного имени в этом файле должен привести к его
контракту, месту в call graph или к компактному symbol index в разделе 9.

## 1. Как читать эту method map

Читайте runtime через четыре границы:

1. `src/noir_sbt.py` и `noir.cli.run_cli` владеют пользовательским input и
   эффектами artifact'ов.
2. `noir.application.analyze` владеет одним diagnostic scope вокруг
   типизированного запуска.
3. `noir.pipeline.run_analysis` владеет порядком анализа и выбором framework'ов.
4. Модули `noir.java_*` превращают неизменяемые source-byte'ы в многократно
   используемые syntax-, symbol-, constant-, method- и hierarchy-evidence.

Каждый подробный контракт ниже фиксирует пять аспектов:

- **Caller:** обычный upstream-владелец, а не каждый caller из тестов или
  utility.
- **Input/output:** важные типы и смысл, а не только Python-синтаксис.
- **Effects:** mutation, доступ к filesystem, stdout или захват diagnostic'ов.
- **Invariant:** на что downstream-код может полагаться после успеха.
- **Failure:** исключение, когда вся операция не может продолжаться, в отличие
  от консервативного `None`, `False` или пустой коллекции при неопределённом
  evidence.

Последнее различие принципиально. Java proof helper'ы обычно работают
fail-closed: неопределённый syntax не является endpoint evidence. Ошибки на
границе приложения обычно выбрасываются: ошибки dependency, контракта,
decode и I/O должны оставаться видимыми.

## 2. Call graph сверху вниз

Основная сплошная цепочка коротка. Широкое разветвление начинается только после
создания одного workspace.

```mermaid
flowchart TD
    E["src/noir_sbt.py\nmain()"] --> C["cli.run_cli(argv)"]
    C --> P["cli.build_argument_parser()"]
    C --> NR["необязательный load_noir_report_locations()"]
    C --> B["diagnostics.bind(collector)"]
    B --> A["application.analyze(request)"]
    A --> RA["pipeline.run_analysis(request)"]

    RA --> TS["tree_sitter_runtime.require_tree_sitter()"]
    RA --> SS["pipeline._snapshot_sources(root)"]
    SS --> DJ["discovery.discover_java_files(root)"]
    RA --> SF["pipeline._select_frameworks(request, snapshot)"]
    SF -->|"только auto"| SM["discovery.scan_framework_markers()"]
    RA --> BW["pipeline._build_workspace(snapshot)"]
    BW --> RT["tree_sitter_runtime.build_workspace_runtime()"]
    RT --> QR["build_query_runtime(JAVA_WORKSPACE_QUERY_SOURCES)"]
    BW --> JW["java_workspace.build_java_workspace()"]

    JW --> CU["java_frontend.build_java_compilation_unit()\nдля каждого source"]
    CU --> PQ["parse_java_query_set()"]
    PQ --> QM["run_query_matches() -> query_matches()"]
    JW --> IT["index_workspace_types()"]
    JW --> IC["index_workspace_constants()"]
    JW --> IA["index_java_annotation_declarations()"]

    BW --> SI["attach_spring_indexes(workspace)"]
    BW --> JI["присоединить или очистить JAX-RS index'ы"]
    RA --> AUDIT["build_annotation_audit_inventory()<br/>всегда"]
    RA -->|"выбранный набор не пуст"| TRIG["build_final_trigger_inventory()"]
    RA -->|"JAX-RS выбран"| DEP["build_jax_rs_deployment_model()"]
    RA -->|"Spring выбран"| SP["pipeline._analyze_spring()"]
    RA -->|"JAX-RS выбран"| JP["pipeline._analyze_jaxrs()"]
    DEP -->|"deployment model в workspace"| JP
    SP --> EF["Значения EndpointFact"]
    JP --> EF
    AUDIT --> RES["AnalysisResult"]
    TRIG --> RES
    EF --> RES
    RES --> A2["analyze сохраняет diagnostic'и result и<br/>добавляет slice collector'а этого вызова"]
    A2 --> C2["run_cli проецирует и консолидирует row'ы;<br/>формирует byte-report'ы и summary"]
    C2 --> PUB["публикация CSV, log, report annotations-without-endpoints,<br/>необязательного comparison"]
    PUB --> SUM["напечатать уже сформированный completion summary; вернуть 0"]
```

Две детали не позволяют неверно прочесть этот graph:

- `_snapshot_sources` один раз читает каждый обнаруженный Java-файл. Marker
  detection в режиме `auto` получает эти byte'ы и не перечитывает Java. Точные
  файлы `pom.xml` — отдельные input только для marker'ов; их читает discovery.
- `_build_workspace` всегда присоединяет Spring index'ы, нужные общей inventory
  logic. Он присоединяет JAX-RS index'ы, только если выбран JAX-RS, иначе
  очищает их. Endpoint-pass'ы всё равно запускаются строго согласно
  `FrameworkPlan.selected`.

## 3. Как перемещаются данные

### 3.1 Цепочка преобразований

| Stage | Input | Преобразование | Output и владение |
|---|---|---|---|
| CLI resolution | строки из `argparse` | раскрыть/разрешить input и необязательный Noir path; вывести output destination; при включённом comparison отклонить alias Noir-input/output | значения `Path`, которыми владеет `run_cli`; output parent, writability и collision между output заранее не проверяются |
| Типизированный request | resolved root анализа и mode | `AnalysisRequest.__post_init__` канонизирует root и проверяет mode | frozen `AnalysisRequest` |
| Source edge | канонический root | детерминированный discovery, затем один `read_bytes()` на Java path | frozen `SourceSnapshot(paths, content)`; content — `MappingProxyType` |
| Parser runtime | закреплённые source query | проверить точные dependency, создать один language/parser, скомпилировать query | runtime-словарь, сохраняемый workspace |
| Compilation unit'ы | source path + точные byte'ы + runtime | один parse и каждый общий query; сформировать import'ы, type'ы, annotation'ы, candidate'ы | один unit-словарь, сохраняющий byte'ы, tree, cursor'ы, сырые match'и и выведенные fact'ы |
| Workspace | все unit'ы | добавить fact'ы package collision, declaration index'ы, constant index'ы, определения annotation | один локальный для анализа изменяемый workspace, общий для каждого pass'а |
| Framework index'ы | workspace | присоединить semantic index'ы Spring и выбранного JAX-RS | дополнительные ключи в том же workspace |
| Analysis fact'ы | workspace + framework plan | inventory и analyzer pass'ы | неизменяемые значения `EndpointFact` плюс параллельные inventory |
| Граница result | fact'ы и plan'ы | tuple-snapshot и рекурсивный `freeze_data` inventory с открытой формой | frozen `AnalysisResult` |
| Граница presentation | `AnalysisResult` | endpoint projection, нормализация, шестиполевая consolidation, union evidence/target | финализированные публичные row'ы и represented target'ы |
| Publication | сформированные byte'ы/row'ы | упорядоченные записи | CSV, `.log`, report annotations-without-endpoints, необязательный Noir comparison |

### 3.2 Один source-файл в общем engine

```mermaid
flowchart LR
    P["path"] --> B["точные byte'ы"]
    B --> T["Tree-sitter tree"]
    T --> M["Именованные match'и query"]
    B --> U["compilation unit"]
    M --> U
    U --> TI["type_infos / imports / package"]
    U --> AC["кандидаты annotation и declaration"]
    U --> WC["workspace index'ы type/member/constant"]
    WC --> R["resolution имён + констант"]
    TI --> R
    AC --> F["framework analyzer'ы"]
    R --> F
    F --> E["EndpointFact"]
    E --> RC["row candidate"]
    RC --> CR["консолидированная CSV row"]
```

Nodes Tree-sitter не перемещаются сами по себе. Byte range каждого node имеет
смысл только вместе с точными source-byte'ами его unit, а query-nodes могут сохранять
state, принадлежащий cursor'у. Поэтому `parse_java_query_set` сохраняет tree и
cursor'ы в `lifetime_owners`; `build_java_compilation_unit` хранит их рядом со
всеми node.

### 3.3 Форма workspace, которую должен узнавать читатель

`build_java_workspace` создаёт словарь, поскольку framework-pass'ы присоединяют
дополнительные index'ы к одному локальному для анализа объекту. Его стабильное
ядро:

```text
workspace
  runtime
  compilation_units[path]
    source_path, source, tree, lifetime_owners, matches
    type_infos, imports, package
    annotation_occurrences, local_annotations, local_types
    type_candidates, method_candidates, record_component_candidates
    record_explicit_accessors, meta_candidates, element_candidates
    package_types, wildcard_source_types
    workspace_constant_records
  type_declarations[FQN] -> all workspace-visible declarations, including duplicates
  constants_by_owner_member[(FQN, name)]
  member_declarations[(FQN, name)]
  static_member_declarations[(FQN, name)]
  annotation_declarations[FQN] -> all workspace-visible declarations, including duplicates
  ... framework-owned indexes attached later
```

Дубликаты намеренно сохраняются. Resolver, которому нужна одна identity,
проверяет cardinality и отклоняет неоднозначность; порядок source никогда не
выбирает победителя.

## 4. Call graph путей ошибки

```mermaid
flowchart TD
    C["run_cli"] --> V{"валидация аргументов/path/report"}
    V -->|"некорректно"| PE["parser.error -> SystemExit\nанализ не начинается"]
    V -->|"корректно"| L0["усечь/создать log annotation'ов и diagnostic'ов"]
    L0 -->|"ошибка до внешнего try"| EARLY["пробросить; recovery-перезаписи нет"]
    L0 --> A["analyze -> run_analysis"]
    A -->|RuntimeError| RE["записать ERROR"]
    RE --> WL["записать текущий log annotation'ов и diagnostic'ов"]
    RE -->|"Exception при записи"| OE["внешний exception handler"]
    WL -->|"Exception при записи"| OE
    WL --> PE2["parser.error -> SystemExit"]
    A -->|"другой Exception"| OE
    OE --> BL["best-effort перезапись log annotation'ов и diagnostic'ов"]
    BL --> RAISE["повторно выбросить исходное исключение"]
    A -->|"успех"| ANN["напечатать framework announcement'ы"]
    ANN -->|RuntimeError| RE
    ANN -->|"другой Exception"| OE
    ANN --> PRE["спроецировать/консолидировать row'ы; сформировать byte-report'ы и summary"]
    PRE -->|Exception| OE
    PRE --> CSV["записать endpoint CSV"]
    CSV --> LOG["записать log annotation'ов и diagnostic'ов"]
    LOG --> ABS["атомарно опубликовать report annotations-without-endpoints"]
    ABS --> CMP["необязательно опубликовать comparison report"]
    CMP --> OUT["напечатать summary"]
    OUT -->|Exception| OE
    OUT -->|"успех"| OK["вернуть 0"]
    CSV -->|"Exception записи"| OE
    LOG -->|"Exception записи"| OE
    ABS -->|"Exception publication"| OE
    CMP -->|"Exception publication"| OE
```

Publication упорядочена, но не транзакционна. После успешной инициализации log
и входа во внешний `try` `Exception` не откатывает artifact, уже записанный
ранее в цепочке. Внешний handler пытается перезаписать log annotation'ов и
diagnostic'ов из имеющихся на данный момент inventory и diagnostic'ов,
игнорирует ошибку этой recovery-записи и повторно выбрасывает исходное
исключение. Ошибки validation и начального log происходят до этого handler'а;
значения `BaseException`, не являющиеся `Exception`, также обходят его.

Внутри Java-анализа неопределённость идёт по другому пути:

```mermaid
flowchart LR
    X["неопределённость syntax / name / accessibility / generic"] --> H["proof helper"]
    H --> N["None, False, пустые кандидаты или complete=False"]
    N --> S["framework consumer подавляет inference"]
    S --> Z["EndpointFact из этого неопределённого evidence не создаётся"]
```

Примеры: malformed аргументы annotation, неоднозначные import'ы, дублирующиеся
source FQN, cycle'ы констант, неподдерживаемые строковые выражения, недоступные
member'ы, unresolved generic edge и границы hierarchy traversal. Обычно они не
прерывают всё приложение.

## 5. Контракты методов вдоль основной цепочки runtime

### 5.1 Invocation, CLI и граница приложения

#### `src/noir_sbt.py` и `noir.cli`

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `main` | shell entry point; аргументы процесса -> integer/`SystemExit` | Alias для `run_cli`. `src/noir_sbt.py` вызывает `SystemExit(main())`, сохраняя exit code argparse. |
| `build_argument_parser` | `run_cli` или help/tests; без input -> настроенный `ArgumentParser` | Во время invocation не нужны analysis-import'ы сверх уже import-safe модулей. Определяет обязательные `--path`, `--output` и необязательные `--framework`, `--noir-report`. Argparse отклоняет значения вне `spring`, `jaxrx`, `auto`. |
| `_same_existing_file` | `run_cli`; два значения `Path` -> `bool` | Вызывает `Path.samefile`, чтобы обнаружить alias/hard link. Любой `OSError` превращается в `False`; это дополнительная защита от collision, а не проверка существования. |
| `render_completion_summary` | `run_cli`; path созданных artifact'ов и необязательная пара comparison-path -> `str` с завершающим newline | Чистое форматирование. Наличие ровно одного из comparison input/output вызывает `ValueError`; допустимы отсутствие обоих или наличие обоих. |
| `run_cli` | `main`, тесты, embedding; необязательные argv и clock -> `0` при успехе | Владеет validation path, stdout, инициализацией log, загрузкой report, rendering row/report и упорядоченной publication. Пользовательские ошибки обрабатывает `parser.error`. `RuntimeError` анализа превращается в diagnostic плюс ошибку argparse. После успешной инициализации log другие значения `Exception` пробрасываются после best-effort сохранения log; более ранние ошибки и значения `BaseException` вне `Exception` не попадают в этот recovery handler. Транзакционность не обещается. |

`run_cli` намеренно формирует report annotations-without-endpoints и
необязательный comparison report до записи endpoint CSV. Это проверяет большую
часть запуска до записи первого итогового artifact, но после начала publication
авторитетен порядок из раздела 4.

#### `noir.application.analyze`

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `AnalysisRunner` | type alias для dependency injection | Callable из `AnalysisRequest` в `AnalysisResult`; по умолчанию — `run_analysis`. |
| `analyze` | `run_cli` или library caller; типизированный request, необязательные collector/runner -> `AnalysisResult` | Отклоняет не-`AnalysisRequest` через `TypeError`. Выбирает явный collector, иначе уже привязанный collector, иначе новый. Сохраняет начальный offset, выполняет bind только при необходимости, запускает внедрённый runner, затем возвращает `dataclasses.replace(result, diagnostics=...)`, сохраняя diagnostic'и runner'а и добавляя только entry collector'а, записанные после offset этого вызова. Восстановление binding гарантирует `bind`; исключения runner'а пробрасываются без изменений, частичный result не фабрикуется. |

Именно entry offset в `analyze` позволяет вложенным вызовам совместно
использовать collector, не присваивая более ранние события. Collector не
очищается, а frozen result runner'а не изменяется.

### 5.2 Pipeline orchestration

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `SourceSnapshot.__post_init__` | создание dataclass в `_snapshot_sources`; paths + content -> sealed value | Копирует обе коллекции, требует точного совпадения path/key и отсутствия потери дублирующихся path, затем оборачивает content в `MappingProxyType`. Несовпадение вызывает `ValueError`. |
| `FrameworkDecision` | `_select_frameworks`; plan плюс evidence -> frozen decision | Переносит нормализованный plan отдельно от сырых detection и stdout-announcement'ов. |
| `_snapshot_sources` | `run_analysis`; канонический root -> `SourceSnapshot` | Находит стабильные Java-path и вызывает `read_bytes` ровно один раз на path. Ошибки discovery, filesystem и чтения пробрасываются; `SourceSnapshot` отделяет те byte'ы, которые вернуло каждое успешное чтение. Pass обнаружения изменений отсутствует. |
| `_select_frameworks` | `run_analysis`; request + snapshot -> `FrameworkDecision` | По умолчанию выбирает Spring, затем JAX-RS; явный mode выбирает ровно одно семейство; только `auto` сканирует marker'ы. Auto-diagnostic записываются для каждого occurrence, selection нормализуется в framework order, а announcement'ы следуют уникальным находкам registry. Ошибки decode/read при scanning пробрасываются. |
| `_build_workspace` | `run_analysis`; snapshot + JAX-RS flag -> workspace-словарь | Строит один полный query runtime и один общий workspace, всегда присоединяет Spring index'ы и присоединяет или очищает JAX-RS index'ы. Изменяет только новый workspace. Ошибки parser/query/dependency пробрасываются. |
| `_analyze_spring` | `run_analysis`; request + snapshot + workspace -> `list[EndpointFact]` | Запускает direct unit'ы в порядке snapshot, затем route registration, MVC hierarchy, gateway, resource'ы, client'ы, path configuration, WebSocket/messaging и в конце применяет configuration ко всем собранным Spring fact'ам. При пустых unit возвращает накопленные к этому моменту дополнения. Исключения analyzer'а пробрасываются. |
| `_analyze_jaxrs` | `run_analysis`; snapshot + workspace -> `list[EndpointFact]` | Для каждого разобранного unit записывает source heading и запускает direct JAX-RS. При наличии unit добавляет fact'ы hierarchy/subresource и Java WebSocket. Исключения пробрасываются. |
| `run_analysis` | `analyze`; `AnalysisRequest` -> `AnalysisResult` | Проверяет версии parser'а до filesystem snapshot; выбирает framework'и; строит один workspace; создаёт audit- и final-trigger-inventory; строит JAX-RS deployment model, если выбрано; запускает выбранные analyzer'ы; требует, чтобы каждый result был `EndpointFact`, иначе вызывает `TypeError`. Возвращает неизменяемые параллельные представления. Не записывает artifact'ы и ничего не печатает. |

`FrameworkPlan.selected` — авторитет исполнения. Detection и announcement —
каналы evidence/presentation, а не второй скрытый selector.

### 5.3 Discovery и parser runtime

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `_relative_name` | sorting/display в discovery; path + root -> относительная POSIX-строка | Использует `os.path.relpath`; нормализует порядок отображения, а не containment source. |
| `is_ignored_source_file` | caller'ы/tests; file + root -> `bool` | Сверяет с `IGNORED_SOURCE_DIRECTORIES` только компоненты родительских directory; само filename не считается совпадением с игнорируемой directory. |
| `_discover_named_files` | discovery Java/POM; root + predicate filename -> отсортированные path | Рекурсивно обходит, на месте отсекает игнорируемые directory, сортирует directory/file и итоговые relative key. Ошибки filesystem walk следуют поведению `os.walk`; файлы не читаются. |
| `discover_java_files` | `_snapshot_sources`; root -> `list[str]` | Регистронезависимый predicate `.java` над `_discover_named_files`. Проверка корректности Java отложена. |
| `discover_pom_files` | `scan_framework_markers`; root -> `list[str]` | Точный регистрозависимый predicate `pom.xml`. POM — marker-input, не input Java workspace. |
| `detect_spring_marker` | marker registry; path/text -> `bool` | Сырой регистрозависимый regex для package Spring MVC annotation или marker functional route. Комментарии и literal'ы учитываются, поскольку это convenience detection, а не semantic proof. |
| `detect_spring_functional_route_marker` | registry и `detect_spring_marker`; path/text -> `bool` | Распознаёт reactive functional server package. Это одновременно часть Spring auto selection и отдельная ручная находка. |
| `detect_jax_rs_marker` | marker registry; path/text -> `bool` | Распознаёт `jakarta.ws.rs` или `javax.ws.rs`. |
| `detect_spring_codegen_marker` | marker registry над POM text -> `bool` | Распознаёт текст OpenAPI/Swagger codegen; только announcement с `CODEGEN_REPORT_HINT`. |
| `detect_wicket_marker` | marker registry; path/text -> `bool` | Распознаёт текст Apache Wicket; только announcement, поскольку Wicket analyzer отсутствует. |
| `scan_framework_markers` | `_select_frameworks` в `auto`; root + mapping Java snapshot -> result-словарь | Декодирует Java как UTF-8, отдельно читает POM как UTF-8, проверяет candidate'ы в порядке relative path и правила в порядке registry. Возвращает каждый occurrence, уникальные находки в порядке registry и `frozenset` семейств, доступных для auto selection. Ошибки decode/I/O пробрасываются. |
| `require_tree_sitter` | `run_analysis` и runtime builder; без input -> `None` | Требует импортируемые объекты Tree-sitter и точные установленные версии из `SUPPORTED_VERSIONS`. Отсутствующие/несовпадающие dependency вызывают `RuntimeError` с инструкцией установки. |
| `build_query_runtime` | `build_workspace_runtime`; mapping query-name/source + необязательные language/parser -> runtime-словарь | Повторно проверяет dependency, создаёт/использует повторно Java language/parser и компилирует source query в отсортированном порядке имён. Некорректные query и ошибки construction пробрасываются. |
| `build_workspace_runtime` | `_build_workspace`; необязательные language/parser -> полный runtime | Делегирует с `JAVA_WORKSPACE_QUERY_SOURCES`; это единственный обычный набор query приложения. |
| `run_query_matches` | `build_java_workspace` через внедрённый matcher; query + root + lifetime list -> match'и | Адаптирует `query_matches` к установленному `QueryCursor`. Ошибки query пробрасываются. |
| `query_matches` | `run_query_matches`; скомпилированный query + root + cursor factory -> match'и | Создаёт cursor, исполняет его и при наличии `lifetime_owners` добавляет туда `(cursor, matches)`. Это намеренный side effect сохранения. |

### 5.4 Построение compilation unit и консервативный resolution

Основной construction graph:

```mermaid
flowchart TD
    BJC["build_java_compilation_unit"] --> PQS["parse_java_query_set"]
    BJC --> BTI["build_type_infos"]
    BJC --> PJI["parse_java_imports"]
    BJC --> JPN["java_package_name"]
    BJC --> AR["annotation_records"]
    BJC --> DAN["declared_annotation_names"]
    BJC --> GQC["group_query_captures"]
    BJC --> RZA["record_explicit_zero_parameter_accessors"]
    RK["resolve_known_annotation / resolve_known_type"] --> RKS["resolve_known_source_name"]
    RKS --> VLT["visible_local_type_names"]
```

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `parse_java_query_set` | `build_java_compilation_unit`; byte'ы + runtime + необязательный parsed tree + matcher -> `(tree, matches, lifetime_owners)` | Выполняет parse только при отсутствии переданного tree, запускает каждый скомпилированный query, сохраняет владельцев tree и cursor. Исключения parse/query пробрасываются. |
| `build_java_compilation_unit` | `build_java_workspace`; path + byte'ы + runtime -> unit-словарь | Один раз вызывает stage parse/query, затем выводит все стабильные unit-fact'ы из раздела 3.3. Не присоединяет framework-смысл. Исключения пробрасываются вместо возврата частичного unit. |
| `build_type_infos` | unit builder; source-byte'ы + match'и type -> info-словарь с byte-key | Сортирует внешние декларации перед вложенными, вычисляет lexical display name, abstract flag, workspace visibility и инициализирует framework-поле `mapping` значением `None`. Отсутствующие capture пропускаются. |
| `type_is_workspace_visible` | `build_type_infos`; type node -> `bool` | Member type остаются видимыми; декларации внутри executable/block/initializer scope — нет. Это допустимость source identity, а не проверка Java-access. |
| `visible_local_type_infos` / `visible_local_type_names` | resolution известных имён и annotation; unit + необязательный context -> infos/set | Моделирует lexical name, затеняющие import'ы. Context расширяет видимость через цепочку enclosing type и их видимые member'ы. Неизвестные context-fact дают консервативно более узкое представление. |
| `parse_java_imports` | unit builder; byte'ы + match'и import -> четыре lookup-tier | Возвращает коллекции exact, wildcard, static-exact и static-wildcard. Конфликтующие exact import'ы превращаются в `""` — terminal marker неоднозначности. Malformed declaration пропускаются. |
| `decode_java_string_literal` | evaluator workspace-констант и framework decoder'ы; literal + max length -> string или `None` | Поддерживает ограниченные обычные Java escape, Unicode- и octal-формы. Отклоняет формы без кавычек/text block, malformed escape, некорректную композицию surrogate и слишком большие декодированные значения. |
| `resolve_known_source_name` | helper'ы известных annotation/type; unit + spelling + ожидаемые simple name/package + local names -> package или `None` | Применяет Java-подобный приоритет: qualified spelling; lexical shadow; exact import; shadow source'ом из того же package; затем implicit/wildcard candidate с проверкой collision. Неоднозначность или mismatch возвращают `None` без перехода к более слабому tier. |
| `resolve_known_annotation` | framework/shared annotation logic; unit + name node + допустимые name/package -> identity-record или `None` | Читает точное spelling, проверяет допустимое simple name, делегирует resolution и возвращает `{name, namespace, spelling}` только при доказательстве. |
| `resolve_known_type` | framework/shared type logic; unit + spelling + ожидаемая identity + context -> package или `None` | Тот же консервативный resolver с context-sensitive lexical shadowing. |
| `get_annotation_arguments` | decoder'ы annotation; annotation node -> `(positional_values, named_values)` | Игнорирует дочерние комментарии и только формирует syntax. При дублировании named key остаётся последнее захваченное value, поскольку result — словарь; допустимость определяют framework decoder'ы. |
| `annotation_single_value_node` | общие helper'ы определения annotation; annotation node -> `(node, error)` | Принимает ровно одно positional value или одно named `value`; описывает missing, mixed, extra-key и multi-positional rejection без исключения. |
| `annotation_records`, `group_query_captures`, `record_explicit_zero_parameter_accessors` | unit builder -> нормализованные коллекции кандидатов | Выполняют deduplication по byte range, группируют только внутри полных query match и записывают явные методы без аргументов, подавляющие неявные record accessor'ы. Изменяют только свежие локальные коллекции. |

Малые syntax helper'ы — например `node_text`, `child_by_field`, `first_capture`,
`tree_node_key`, `nearest_enclosing_type`, `annotation_value_nodes` и
`unwrap_parenthesized_node` — намеренно узки. Они либо возвращают точное syntax
evidence, либо нейтральное значение отсутствующего evidence; они не выводят
framework identity.

### 5.5 Построение workspace, имена, константы и annotation'ы

```mermaid
flowchart TD
    BJW["build_java_workspace"] --> UNITS["построить все compilation unit'ы"]
    UNITS --> PKG["вывести package_types + wildcard_source_types"]
    PKG --> IWT["index_workspace_types"]
    IWT --> IWC["index_workspace_constants"]
    IWC --> IAD["index_java_annotation_declarations"]

    RSE["resolve_workspace_string_expression"] --> WCC["workspace_constant_candidates"]
    WCC --> ROW["resolve_workspace_owner_fqns / lexical_owner_fqns"]
    WCC --> WMR["workspace_member_records"]
    WMR --> WCA["workspace_constant_accessible"]
    RSE --> RSE

    ADEF["annotation_definition_is_method_applicable"] --> TAR["resolve_java_element_type"]
    ADEF --> UTR["unresolved_java_target_reference"]
```

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `build_java_workspace` | pipeline; mapping source-byte + runtime + необязательные tree + matcher -> workspace | Преобразует key path в строки, требует, чтобы каждое source-value было `bytes`, строит unit'ы в отсортированном порядке, выводит полный package universe, затем индексирует type'ы, константы и annotation declaration. Не-byte value вызывает `TypeError`; исключения parse/index пробрасываются. Framework index здесь не присоединяется. |
| `index_workspace_types` | workspace builder; workspace -> `None` | Изменяет `workspace["type_declarations"]`; сохраняет list для каждого FQN, чтобы дубликаты оставались evidence неоднозначности. |
| `index_workspace_constants` | workspace builder; workspace -> `None` | Изменяет workspace и unit'ы: добавляет индексированные field/enum declaration под workspace-visible owner'ами, записи static-declaration с metadata видимости для последующих проверок и допустимые записи Java `String` value. Недопустимые declaration остаются в index'ах shadowing. |
| `index_java_annotation_declarations` | workspace builder; workspace -> FQN-map | Возвращает определения workspace-visible annotation с сохранёнными дубликатами; caller сохраняет map. |
| `workspace_type_accessible` | resolver'ы FQN/type; declaration + consumer context -> `bool` | Применяет поддерживаемые правила visibility outer-chain, private-nest, package и named/unnamed-package. Не доказывает уникальность identity. |
| `workspace_type_fqn_accessible` | type resolution/hierarchy; workspace + consumer + FQN -> `bool` | Добавляет требование уникальности: ровно одна декларация, и она доступна. |
| `resolve_workspace_owner_fqns` | resolution констант и hierarchy; unit + qualifier + lexical owner + workspace + необязательные closed external -> кандидаты | Останавливается на первом применимом Java-tier: closed external, lexical member, exact import, same-package/global source, wildcard import. Возвращает отсортированных кандидатов; неоднозначность представляется, а не устраняется догадкой. |
| `workspace_constant_accessible` | member lookup; запись константы + consumer context + eligibility flag -> `bool` | Eligibility flag добавляют запрошенные проверки static-final или final. Независимо от них каждая cross-file запись должна быть static-final; затем видимость определяют границы package, same-nest private access и public outer-chain. |
| `lexical_instance_constant_accessible` | lookup неквалифицированной константы; запись + consumer site -> `bool` | Разрешает non-static final String только при доказанном enclosing instance и отсутствии static nested boundary. Записи static-final проходят эту дополнительную проверку. |
| `workspace_constant_candidates` | string evaluator; unit + reference + owner/workspace/context + известные константы -> candidate records | Реализует shadowing lexical declaration до static import; exact import до wildcard; resolution qualified owner; closed known constants. Неопределённые или неоднозначные owner-tier возвращают ноль кандидатов; дублирующиеся member declaration могут вернуть несколько кандидатов, которые evaluator отклоняет, поскольку cardinality не равна единице. |
| `resolve_workspace_string_expression` | decoder'ы route/config; unit + expression + workspace + owner -> string или `None` | Вычисляет literal, однозначные parentheses, `+` или одну допустимую reference. Рекурсивно проходит value declaration со stack cycle. Глубина выше `JAVA_CONSTANT_MAX_DEPTH`, длина выше `JAVA_CONSTANT_MAX_LENGTH`, неподдерживаемый syntax, не-addition, cycle или cardinality кандидатов не равная единице возвращают `None`. Java не исполняется. |
| `static_member_resolves_to` | resolution enum/annotation constant; unit + name + ожидаемый owner -> `bool` | Exact static import терминален. Wildcard успешен, только если ни один конкурирующий импортированный source-owner не предоставляет member с тем же именем. |
| `retention_is_runtime` | consumer'ы index source-defined annotation; unit + annotation -> `bool` | Доказывает настоящий `java.lang.annotation.RetentionPolicy.RUNTIME` — неквалифицированный через static resolution или квалифицированный через resolution известного type. Неопределённая форма возвращает `False`. |
| `custom_annotation_identity_candidates` | consumer'ы composed annotation; unit + spelling + workspace/context -> set source FQN | Применяет tier'ы lexical, exact import, same package, package shadow, затем wildcard. Set сохраняет неоднозначность, чтобы caller её отклонил. |
| `annotation_definition_is_method_applicable` | consumer'ы source-defined method annotation; definition -> `bool` | Отсутствие настоящего `@Target` означает широкое Java-default. Неоднозначный Target-подобный evidence, несколько/malformed target annotation, дублирующиеся value, unresolved константы или set без `METHOD` возвращают `False`. |

Меньшие predicate'ы `workspace_member_records`, `workspace_member_declared`,
`workspace_static_member_declared` и связанные с ними разделяют три fact'а,
которые нельзя смешивать: наличие декларации, доступность декларации и
допустимость в качестве compile-time-подобного String value.

### 5.6 Многократно используемые AST и method index'ы

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `java_ast.walk_named` | indexer'ы method/framework; root -> preorder iterator | Детерминированный, ориентированный на source обход named-node; без mutation. `java_methods.walk_named_nodes` — его импортированный alias. |
| `java_ast.raw_type_node` | `known_type` и analyzer'ы; type syntax -> raw node или `None` | Раскрывает generic- и annotated-type максимум на 16 слоёв; неоднозначная/malformed или превышающая границу вложенность возвращает `None`. `java_methods.raw_type_node` — тот же импортированный helper. |
| `java_ast.known_type` | framework analyzer'ы; unit + node + точные simple/package -> `bool` | Объединяет extraction raw type и консервативный `resolve_known_type`; любая неопределённость даёт `False`. `java_methods.known_type` реэкспортирует его. |
| `java_ast.is_direct_invocation_statement` | analyzer'ы route DSL; invocation + method body -> `bool` | Проходит только fluent receiver chain, затем требует direct `expression_statement` child переданного body. Assignment, return, lambda и nested expression ownership обрабатываются fail-closed. |
| `only_named_child` / `unwrap_parentheses` | analyzer'ы invocation; expression -> child/unwrapped node или `None` | Игнорируют комментарии, требуют один semantic child и ограничивают traversal wrapper'ов значением 16. |
| `invocation_arguments` / `invocation_name` | DSL analyzer'ы; method invocation -> node аргументов/name | Только формируют syntax. Отсутствующее поле arguments или неверный kind invocation возвращает `None`; комментарии исключаются. |
| `strict_formal_parameters` | strict method index; unit + parameter list -> tuple или `None` | Принимает только обычные formal parameter. Один receiver, varargs или malformed member отклоняет всю signature. |
| `varargs_formal_parameters` | varargs method index; unit + parameter list -> tuple или `None` | Также принимает структурно корректные node spread-parameter; неподдерживаемый syntax отклоняет всю signature. |
| `_formal_parameters` | два reader'а; policy flag -> tuple `FormalParameter` или `None` | Центральный parser all-or-nothing. Никогда не публикует частичную overload signature. |
| `_build_method_index` | публичные index builder'ы; workspace + parameter reader -> `MethodIndex` | Обходит source в порядке path и принимает executable method, только если его непосредственный parent — `class_body`, напрямую принадлежащий стабильному workspace-visible named type. Сортирует по path/start byte и создаёт bucket'ы `(owner_fqn, name)`. Abstract/bodyless/local/anonymous method и method с неподдерживаемой signature исключаются. |
| `build_strict_method_index` / `build_varargs_method_index` | специализированные framework analyzer'ы; workspace -> `MethodIndex` | Различаются только parameter policy, в остальном используют общий детерминированный indexing. |
| `MethodFact.name` / `MethodFact.owner_name` | analyzer lookup | Декодируют name из сохранённых unit-byte и предоставляют lexical display owner. Это чистые property; owning unit остаётся необходимым provenance. |

### 5.7 Source hierarchy и generic method binding

`JavaSourceHierarchyGraph` нейтрален к framework'ам, но hierarchy analyzer'ы
Spring и JAX-RS используют несколько методов с prefix underscore как seam
специализации. Поэтому, несмотря на Python-private написание, эти методы —
важные runtime-контракты.

```mermaid
flowchart TD
    INIT["JavaSourceHierarchyGraph.__init__"] --> BT["_build_java_type_index"]
    BT --> TP["_type_parameter_nodes"]
    BT --> IE["_parse_inheritance_edges"]
    BT --> PM["_parse_methods"]
    IE --> PTR["_parse_type_ref"]
    PM --> PTR
    PTR --> RTI["_resolve_type_identity"]

    HC["_build_hierarchy_context(root, env)"] --> RIE["_resolve_inheritance_edge"]
    RIE --> SUB["_substitute_type_ref"]
    SIG["_erased_method_signature"] --> ME["_method_env"]
    SIG --> SUB

    IB["_interface_branches"] --> MFS["_methods_for_signature"]
    IB --> HAB["_has_atomic_annotation_bundle"]
    IB --> RIE
    MSC["_select_maximally_specific_candidates"] --> RMC["_resolve_method_candidate"]
    MSC --> IST["_interface_subtype"]
```

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `JavaSourceHierarchyGraph.__init__` | Spring hierarchy analyzer и subclass JAX-RS; workspace -> graph | Сохраняет workspace, инициализирует cache signature и строит полный нейтральный type index. Исключения construction пробрасываются. |
| `_build_java_type_index` | constructor; workspace -> заполненный `types` | Включает только уникальные FQN workspace-visible class/interface/record. После того как существуют все identities, разбирает первый поддерживаемый bound, сохранённый для каждого type parameter, затем inheritance edges и методы. Дублирующиеся FQN и неподдерживаемые kind деклараций остаются non-traversable. |
| `_parse_type_ref` / `_resolve_type_identity` | построение index; syntax source-type + type variable -> `JavaTypeReference` или `None` | Поддерживает primitive, array, annotated type, non-wildcard generic, variable и однозначно resolved declaration. Полностью квалифицированное отсутствующее external name может быть signature identity, но никогда не source traversal target. Неподдерживаемые или неоднозначные формы возвращают `None`. |
| `_parse_methods` | построение graph; type record + owner variable -> mutation `record.methods` | Сохраняет метод, даже если его parameter не удаётся разобрать, используя `parameter_refs=None`, чтобы позднее overload family можно было пометить incomplete. Захватывает direct bundle annotation метода и параметров. |
| `_default_type_environment`, `_substitute_type_ref`, `_method_env` | adaptation signature/edge -> адаптированные environment/reference | Raw type variable используют erasure-only bound. Substitution защищён от cycle; unresolved variable/cycle возвращают `None`. Method variable расширяют, а не изменяют owner environment. |
| `_erased_method_signature` | framework hierarchy analyzer'ы и branch selection; method + адаптированный owner env -> `(name, erased parameters)` или `None` | Кэширует как успешные, так и unresolved result по identity метода плюс environment. Return type не участвует в override identity. |
| `_resolve_inheritance_edge` | hierarchy traversal; объявленный edge + environment -> source target/environment или `None` | Требует адаптированный non-array declared type в `types`; arity generic argument должен совпадать. Raw edge получает default erasure environment target'а. |
| `_build_hierarchy_context` | framework hierarchy analyzer'ы; root type + root env -> `JavaHierarchyContext` | Строит class-state и достижимые root interface. Cycle, отсутствующие/некорректные source-parent, несовместимые повторные environment, неверный kind, глубина больше `MAX_HIERARCHY_DEPTH` или state'ы сверх `MAX_HIERARCHY_STATES` устанавливают `complete=False`. Может вернуть частичные state'ы, но consumer должен учитывать completeness до inference. |
| `_erased_method_signature` / `_methods_for_signature` | logic binding class/interface -> совпадающие декларации | Ключ lookup — точная адаптированная erased signature. Несколько совпадающих деклараций в одной interface-ветви делают эту ветвь недопустимой вместо выбора по порядку. |
| `_has_atomic_annotation_bundle` | `_interface_branches`; method -> `bool` | Считает direct annotation метода, не являющиеся настоящим `Override`, вместе с annotation параметров одним atomic inheritance bundle. Единственный точный `java.lang.Override` игнорируется. |
| `_interface_branches` | hierarchy analyzer'ы Spring/JAX-RS; interface state + signature + mode `default`/annotation -> candidate keys + invalid flag | Применяет правила stop-at-declaration, рекурсивно следует interface с проверками depth/cycle и memoization, сохраняет environment кандидата. Отсутствующие edge, несколько declaration или некорректные формы implementation помечают ветвь invalid. |
| `_interface_subtype` | selection maximal-specificity; кандидат + возможный ancestor -> `(is_subtype, invalid)` | Ограниченный graph proof. Отличает определённый `False` от invalid traversal, чтобы caller не счёл неопределённость отсутствием subtyping. |
| `_select_maximally_specific_candidates` | hierarchy analyzer'ы; candidate keys -> survivors + invalid flag | Восстанавливает provenance кандидата, удаляет ancestor только когда доказано, что другой кандидат находится ниже него, и отклоняет весь selection при неразрешимом provenance или subtype proof. |

`JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord` и
`JavaHierarchyContext` — локальные для анализа записи, а не публичные
artifact'ы. Их node Tree-sitter остаются привязаны к unit workspace.
`JavaHierarchyContext.complete` — proof flag, а не процент progress.

### 5.8 Domain-значения, diagnostic'и, immutability и path

| Symbol | Caller; input -> output | Effects, invariant'ы и поведение при ошибке |
|---|---|---|
| `AnalysisRequest.__post_init__` | construction CLI/library -> нормализованный request | Раскрывает и разрешает root, не требуя его существования; отклоняет неподдерживаемый mode через `ValueError`. CLI отдельно требует directory. |
| `FrameworkPlan.__post_init__` | framework selection -> нормализованный plan | Приводит каждый selection к `FrameworkSelection`, отклоняет неподдерживаемый requested mode и дублирующиеся выбранные семейства. |
| `SourceFile.__post_init__`, `SourceFile.__fspath__`, `SourceFile.__str__` | construction provenance/path API | Требуют непустую строковую path identity, затем предоставляют её без доступа к filesystem. |
| `SourceSpan.__post_init__` | construction evidence/target | Приводит source identity и требует integer, non-boolean, непустой полуоткрытый byte interval `0 <= start < end`. |
| `SourceTarget.__post_init__` | construction target analyzer'ом | Требует непустой kind и проверенный `SourceSpan`. |
| `AnnotationEvidence.__post_init__` | construction evidence analyzer'ом | Приводит только source identity; family, line и same-file validity намеренно проверяются позднее в `noir.evidence`. |
| `EndpointFact.__post_init__` | каждый endpoint analyzer | Приводит все поля provenance source-file, требует типизированные evidence/target, создаёт snapshot их коллекций и необязательных path-layer Spring client. Не нормализует публичные route path и не проверяет семантически HTTP-методы. |
| `AnalysisResult.__post_init__` | границы pipeline/application | Требует типизированные member endpoint/diagnostic, создаёт их tuple-snapshot и рекурсивно замораживает inventory, detection и announcement с открытой формой. |
| `freeze_data` | `AnalysisResult` | Рекурсивно преобразует mapping в `MappingProxyType`, list и tuple в tuple, set во frozenset; scalar/unknown leaf остаются как есть. Изменяемого reverse view не создаёт. |
| `DiagnosticCollector.record` | модульный `record` или caller; string -> `DiagnosticEntry` | Под `RLock` добавляет timestamp и одну неизменяемую entry. Не-string вызывает `TypeError`; ошибки clock пробрасываются. |
| `DiagnosticCollector.entries`, `DiagnosticCollector.rendered_lines`, `DiagnosticCollector.captured`, `DiagnosticCollector.__len__` | application/report/tests | Возвращают защищённые lock'ом snapshot, строки формата report, membership по точному message и число entry. `entries` никогда не раскрывает изменяемый list. |
| `current` / `bind` / `record` | application и analyzer'ы | `current` читает `ContextVar`; `bind` проверяет type, устанавливает и всегда восстанавливает предыдущий token; модульный `record` добавляет в привязанный collector или намеренно ничего не делает, если ничего не привязано. |
| `format_endpoint_diagnostic` | endpoint analyzer'ы; `EndpointFact` -> стабильный text | Отклоняет другой type через `TypeError`. Использует локальный для analyzer'а `source_line`, а не проверенное public annotation evidence. |
| `join_endpoint_paths` | framework analyzer'ы; декодированный base + endpoint layer -> составная string | Чистая композиция до финальной публичной нормализации. Два пустых layer означают `/`; один пустой layer ничего не добавляет. |
| `ensure_path_leading_slash` | decoder'ы framework path; path layer -> string | Сохраняет `""` как отсутствие, в остальных случаях при необходимости добавляет один ведущий slash. |
| `relative_source_path` | presentation output/evidence; owned path + root анализа -> относительная POSIX-строка | Использует операции absolute/relative path только для spelling. Это не proof containment или ownership. |

## 6. Две разобранные трассы уровня методов

### 6.1 `auto` выбирает Spring по одному Java-marker

1. `run_cli` создаёт `AnalysisRequest(root, framework_mode="auto")`.
2. `AnalysisRequest.__post_init__` разрешает `root`.
3. Сначала `run_analysis` вызывает `require_tree_sitter`; если закреплённый
   runtime недоступен, ни один source не читается.
4. `_snapshot_sources` вызывает `discover_java_files`, читает каждый
   возвращённый path, а `SourceSnapshot.__post_init__` запечатывает точный
   path-to-byte map.
5. `_select_frameworks` вызывает `scan_framework_markers` с этими byte'ами.
6. `scan_framework_markers` декодирует Java, читает отдельно обнаруженные POM,
   проверяет каждую применимую entry `FRAMEWORK_MARKER_RULES` и возвращает
   представления occurrence, finding и selection.
7. `_select_frameworks` записывает каждый occurrence, преобразует выбранный
   token в `FrameworkSelection.SPRING`, восстанавливает глобальный framework
   order и создаёт `FrameworkPlan("auto", (SPRING,))`.
8. `_build_workspace` один раз разбирает каждый Java-файл из snapshot и
   присоединяет Spring index'ы; JAX-RS index'ы очищаются.
9. `run_analysis` строит inventory, пропускает JAX-RS deployment, вызывает
   только `_analyze_spring`, проверяет каждое созданное value и создаёт
   `AnalysisResult`.
10. `analyze` сохраняет diagnostic'и runner'а и добавляет только entry
    collector'а, созданные после его начального offset.
11. `run_cli` печатает announcement уникальной находки, затем выполняет
    projection и publication artifact'ов.

Raw marker selection доказывает лишь необходимость запуска Spring-pass'а.
Каждый Spring-метод всё равно требует разобранное semantic evidence до создания
endpoint.

### 6.2 Route path ссылается на source String-константу

1. Framework decoder передаёт node выражения annotation, его unit, lexical
   owner и общий workspace в `resolve_workspace_string_expression`.
2. Для identifier или field reference evaluator вызывает
   `workspace_constant_candidates`.
3. Для неквалифицированного имени `lexical_owner_fqns` выдаёт owner'ов изнутри
   наружу. Наличие declaration останавливает tier, даже если declaration
   недопустима.
4. `workspace_member_records` сначала требует уникальный source-owner, затем
   `workspace_constant_accessible` проверяет Java visibility и требуемую
   finality.
5. `lexical_instance_constant_accessible` доказывает наличие enclosing
   instance для non-static value; static nesting может отклонить его.
6. Если lexical declaration отсутствует, рассматриваются tier exact static
   import, затем wildcard static import. Несколько wildcard-owner'ов с
   декларацией создают неоднозначность и не дают кандидата.
7. Требуется ровно один кандидат. Closed known constant возвращает
   `resolved_value`; source-константа рекурсивно вычисляет свой `value_node`.
8. Identity записи добавляется в `stack`. Cycle, глубина свыше 12,
   неподдерживаемое expression или составное value длиннее 8192 символов
   возвращает `None`.
9. Только доказанная строка возвращается framework decoder'у и может стать
   route evidence. Частичного результата concatenation нет.

## 7. Правила чтения, предотвращающие неверные выводы

### Один parse не означает одну интерпретацию

Все framework-pass'ы используют одно syntax tree на source, но могут читать
разные представления candidate/index из того же unit. Route, найденный поздним
pass'ом, не является evidence повторного parsing файла.

### Изменяемый workspace не пересекает типизированную границу

Workspace намеренно изменяем во время одного анализа, поскольку владельцы
index присоединяют производные представления. `EndpointFact` и `AnalysisResult`
— frozen handoff. Объекты parser'а, node и workspace-словари не попадают в CSV
или presentation report'ов.

### Пустое evidence и ошибка приложения означают разное

`None`, `False`, `[]`, пустой set или `complete=False` обычно означают:
«статический proof не установлен». Исключение означает, что запрошенная
операция не смогла выполнить контракт runtime или данных. При расширении engine
не превращайте одну категорию в другую.

### Identity многослойна

- `tree_node_key` предоставляет локальный для unit byte-range key.
- `SourceSpan` идентифицирует файл плюс byte interval; `SourceTarget` добавляет
  kind представленной декларации.
- Identity Java-type — FQN, который обычно должен быть уникальным и доступным.
- `EndpointFact` — богатый output analyzer'а с отдельным provenance route,
  handler и project; каждый analyzer определяет собственный локальный key
  deduplication.
- Identity публичной row позднее устанавливается шестиполевым key consolidation
  output.

### Порядок — часть воспроизводимости

Порядок discovery, compilation query, method index, framework, finding,
analyzer-pass и publication artifact'ов задан явно. Set может намеренно
представлять неупорядоченных кандидатов, но любое решение presentation или
traversal либо сортирует его, либо требует уникальности.

## 8. Куда двигаться дальше под этим слоем

Если symbol отсутствует в этой главе:

- Начните с `p6.logic.ru/10-code-and-test-map.md`, чтобы определить владеющую
  feature.
- Используйте точный import или call в месте метода, затем найдите определяющий
  module командой `rg -n '^(class|def) |<symbol>' src/noir`.
- Для endpoint-semantics Spring продолжите с `04-spring-mvc.md` и
  `05-spring-additional-surfaces.md`.
- Для semantics JAX-RS и Java WebSocket продолжите с `06-jax-rs.md`.
- Для projection `EndpointFact`, merge evidence, report'ов и byte-level output
  продолжите с `07-output-evidence-reports.md`.
- Для конкретного повествования source-to-row используйте
  `08-worked-traces.md`.

Private helper'ы документируются здесь, если они координируют stage'и, хранят
state, содержат существенное branching или используются как seam
framework-специализации. Малые syntax helper'ы индексированы ниже, чтобы поиск
точного имени всё равно приводил в этот файл; их source-docstring остаётся
ближайшим руководством уровня statement.

## 9. Полный index покрытия core-symbol'ов

Этот index перечисляет каждый экспортируемый top-level symbol в охваченных
модулях, а также важные private helper'ы и методы class'ов. Imported alias
помечены, чтобы читатель мог перейти к фактическому владельцу.

### 9.1 Invocation и orchestration

| Module | Точные symbol'ы | Указатель покрытия |
|---|---|---|
| `src/noir_sbt.py` | `main` | Разделы 2, 5.1 |
| `noir.application` | `AnalysisRunner`, `analyze` | Раздел 5.1 |
| `noir.cli` | `build_argument_parser`, `main`, `render_completion_summary`, `run_cli`; private `_same_existing_file` | Разделы 4, 5.1 |
| `noir.pipeline` | `SourceSnapshot`, `SourceSnapshot.__post_init__`, `FrameworkDecision`, `run_analysis`; private `_snapshot_sources`, `_select_frameworks`, `_build_workspace`, `_analyze_spring`, `_analyze_jaxrs` | Разделы 2, 3, 5.2 |

### 9.2 Discovery и parser runtime

| Module | Точные symbol'ы | Указатель покрытия |
|---|---|---|
| `noir.discovery` | `CODEGEN_REPORT_HINT`, `FRAMEWORK_MARKER_RULES`, `detect_jax_rs_marker`, `detect_spring_codegen_marker`, `detect_spring_functional_route_marker`, `detect_spring_marker`, `detect_wicket_marker`, `discover_java_files`, `discover_pom_files`, `is_ignored_source_file`, `scan_framework_markers`; private `_relative_name`, `_discover_named_files` | Раздел 5.3. `CODEGEN_REPORT_HINT` — suffix ручного follow-up; `FRAMEWORK_MARKER_RULES` — упорядоченный неизменяемый registry. |
| `noir.tree_sitter_runtime` | `SUPPORTED_VERSIONS`, `build_query_runtime`, `build_workspace_runtime`, `require_tree_sitter`, `run_query_matches` | Разделы 2, 5.3. `SUPPORTED_VERSIONS` — точная dependency policy. |
| `noir.java_queries` | `JAVA_ANNOTATION_USAGE_QUERY`, `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | Разделы 3, 5.3. Это соответственно широкий annotation query, mapping базовых unit-query и полный workspace-union. |

### 9.3 Java AST и frontend

| Module | Точные symbol'ы | Указатель покрытия |
|---|---|---|
| `noir.java_ast` | `direct_interface_types`, `field`, `is_direct_invocation_statement`, `known_type`, `raw_type_node`, `source_text`, `walk_named` | Раздел 5.6. `field` делегирует защищённый field access; `source_text` декодирует сохранённые byte'ы unit; `direct_interface_types` формирует только direct declaration. |
| `noir.java_frontend` | `JAVA_CONSTANT_MAX_LENGTH`, `annotation_has_no_values`, `annotation_records`, `annotation_single_value_node`, `annotation_value_nodes`, `binary_expression_is_addition`, `build_java_compilation_unit`, `build_type_infos`, `child_by_field`, `declaration_modifier_names`, `declared_annotation_names`, `decode_java_string_literal`, `direct_annotation_records`, `find_first`, `first_capture`, `get_annotation_arguments`, `group_query_captures`, `java_package_name`, `lexical_type_chain`, `nearest_enclosing_type`, `node_text`, `owner_name_for_node`, `parameter_list_source_text`, `parse_java_imports`, `parse_java_query_set`, `qualified_type_name`, `query_matches`, `record_explicit_zero_parameter_accessors`, `resolve_known_annotation`, `resolve_known_source_name`, `resolve_known_type`, `tree_node_key`, `type_is_abstract`, `type_is_workspace_visible`, `unwrap_parenthesized_node`, `visible_local_type_infos`, `visible_local_type_names` | Разделы 3, 5.3, 5.4. Методы construction/resolution имеют там подробные контракты; остальные имена — syntax-only shaping helper'ы, описанные непосредственно ниже. |

Малые helper'ы `java_frontend` разрешаются следующим образом:

| Точный symbol | Компактный контракт |
|---|---|
| `node_text` | Точный UTF-8 decode byte-slice; ошибки decode/range не скрываются. |
| `find_first` | Первый direct child запрошенного type, иначе `None`; без descent. |
| `child_by_field` | Запрошенный parser field, но любое исключение parser-recovery/API превращается в `None`. |
| `parameter_list_source_text` | Точное обрезанное содержимое parameter-list; отсутствующий node превращается в `""`. |
| `first_capture` | Первый node под одной query-label, иначе `None`. |
| `tree_node_key` | Identity `(start_byte, end_byte)`, действительная только внутри его unit. |
| `nearest_enclosing_type` | Поднимается по parent до ближайшей именованной declaration class/interface/enum/record/annotation. |
| `type_is_abstract` | True только для class declaration, явно помеченной `abstract`. |
| `declared_annotation_names` | Set захваченных имён source annotation declaration для проверок shadow. |
| `binary_expression_is_addition` | Доказывает `+` через field, token или точный текст между operand; иначе false. |
| `annotation_value_nodes` | Один scalar как list из одного элемента или элементы array, не являющиеся комментариями. |
| `unwrap_parenthesized_node` | Раскрывает только parentheses с единственным child; неоднозначность даёт `None`. |
| `owner_name_for_node` | Lexical display owner для context-node, иначе `None`. |
| `lexical_type_chain` | Цепочка type-info снаружи внутрь из отношений byte-key. |
| `java_package_name` | Один однозначно захваченный package, иначе unnamed package `""`. |
| `annotation_has_no_values` | True, когда аргументы отсутствуют или их node имеет ноль `named_children`; комментарии отдельно не фильтруются. |
| `qualified_type_name` | Package плюс lexical display name или display name в unnamed package. |
| `declaration_modifier_names` | Set token'ов named- и access/static/final-modifier. |
| `direct_annotation_records` | Упорядоченные по source записи annotation/name-node непосредственно в modifier декларации. |

### 9.4 Workspace и method index

| Module | Точные symbol'ы | Указатель покрытия |
|---|---|---|
| `noir.java_workspace` | `JAVA_CONSTANT_MAX_DEPTH`, `JAVA_ELEMENT_TYPES`, `annotation_definition_is_method_applicable`, `build_java_workspace`, `context_is_static_for_instance_constant`, `custom_annotation_identity_candidates`, `index_java_annotation_declarations`, `index_workspace_constants`, `index_workspace_types`, `known_static_constant_record`, `lexical_instance_constant_accessible`, `lexical_owner_fqns`, `resolve_java_element_type`, `resolve_workspace_owner_fqns`, `resolve_workspace_string_expression`, `retention_is_runtime`, `static_member_resolves_to`, `unresolved_java_target_reference`, `workspace_constant_accessible`, `workspace_constant_candidates`, `workspace_member_declared`, `workspace_member_records`, `workspace_static_member_declaration_accessible`, `workspace_static_member_declared`, `workspace_type_accessible`, `workspace_type_exists`, `workspace_type_fqn_accessible` | Раздел 5.5. `JAVA_CONSTANT_MAX_DEPTH` равен 12; `JAVA_ELEMENT_TYPES` — закрытый set настоящих member'ов ElementType. |
| `noir.java_methods` | `FormalParameter`, `MethodFact`, `MethodFact.name`, `MethodFact.owner_name`, `MethodIndex`, `build_strict_method_index`, `build_varargs_method_index`, `child_field`, `invocation_arguments`, `invocation_name`, `known_type`, `node_text`, `only_named_child`, `raw_type_node`, `strict_formal_parameters`, `unwrap_parentheses`, `varargs_formal_parameters`, `walk_named_nodes`; private `_formal_parameters`, `_build_method_index`; type alias `ParameterReader` | Раздел 5.6. `child_field`, `known_type`, `node_text`, `raw_type_node` и `walk_named_nodes` — импортированные alias helper'ов `java_ast`. |

Компактные контракты predicate'ов workspace, не раскрытых выше:

| Точный symbol | Компактный контракт |
|---|---|
| `workspace_member_records` | Values одного уникального owner, отфильтрованные через `workspace_constant_accessible`; иначе пусто. |
| `workspace_type_exists` | Любая workspace-visible индексированная declaration по FQN, включая дублирующиеся или Java-inaccessible записи. |
| `workspace_member_declared` | Любая индексированная member declaration, даже без пригодного String value. |
| `workspace_static_member_declaration_accessible` | Visibility static declaration для проверок неоднозначности wildcard. |
| `workspace_static_member_declared` | Уникальный source-owner плюс как минимум одна доступная одноимённая static declaration. |
| `lexical_owner_fqns` | FQN owner'ов изнутри наружу для unit/display owner. |
| `context_is_static_for_instance_constant` | Поднимается наружу; static method/field/initializer либо граница named-type, достигнутая до instance-context method/field, означает отсутствие instance. |
| `known_static_constant_record` | Оборачивает closed dependency value в форму candidate-record со стабильной synthetic identity. |
| `unresolved_java_target_reference` | Отличает неоднозначное evidence, выглядящее как настоящий `Target`, от несвязанного source annotation. |
| `resolve_java_element_type` | Доказывает одну настоящую константу `ElementType` через static- или type-resolution; иначе `None`. |

### 9.5 Hierarchy graph

| Module | Точные symbol'ы | Указатель покрытия |
|---|---|---|
| `noir.java_hierarchy` | `JAVA_LANG_TYPES`, `PRIMITIVE_NODE_TYPES`, `MAX_HIERARCHY_DEPTH`, `MAX_HIERARCHY_STATES`, `JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord`, `JavaHierarchyContext`, `JavaSourceHierarchyGraph`, `JavaSourceHierarchyGraph.__init__` | Раздел 5.7. Константы задают закрытый словарь signature и proof bound. |
| Методы построения `JavaSourceHierarchyGraph` | `_build_java_type_index`, `_type_parameter_nodes`, `_unit_source_for_node`, `_modifier_names`, `_parse_methods`, `_parse_inheritance_edges`, `_parse_parameter_ref`, `_with_dimensions`, `_parse_type_ref`, `_resolve_type_identity` | Раздел 5.7; `_unit_source_for_node` находит owning byte'ы по identity root-node и вызывает `KeyError`, если node не принадлежит этому workspace. |
| Методы adaptation `JavaSourceHierarchyGraph` | `_default_type_environment`, `_as_erasure_only_ref`, `_substitute_type_ref`, `_erased_type_name`, `_type_environment_key`, `_method_env`, `_erased_method_signature`, `_resolve_inheritance_edge` | Раздел 5.7. Они никогда не загружают classpath; вся adaptation — ограниченное reasoning по source/closed-identity. |
| Методы binding `JavaSourceHierarchyGraph` | `_build_hierarchy_context` (включая вложенный `visit`), `_is_public_implementation`, `_is_ancestor_annotation_method`, `_methods_for_signature`, `_is_genuine_override`, `_has_atomic_annotation_bundle`, `_interface_branches`, `_resolve_method_candidate`, `_interface_subtype`, `_select_maximally_specific_candidates` | Раздел 5.7. Вложенный `visit` проверяет и memoize'ит одно ограниченное состояние reachable-interface; несовместимые повторные environment, cycle или bound делают context неполным. `_is_public_implementation` принимает concrete public method class или record, а также допустимый interface default; `_is_ancestor_annotation_method` принимает наследуемые interface/public/protected declaration. |

### 9.6 Domain, diagnostic'и, immutability и path

| Module | Точные symbol'ы | Указатель покрытия |
|---|---|---|
| `noir.model` | `FrameworkMode`, `FrameworkSelection`, `AnalysisRequest`, `AnalysisRequest.__post_init__`, `FrameworkPlan`, `FrameworkPlan.__post_init__`, `SourceFile`, `SourceFile.__post_init__`, `SourceFile.__fspath__`, `SourceFile.__str__`, `SourceSpan`, `SourceSpan.__post_init__`, `SourceTarget`, `SourceTarget.__post_init__`, `AnnotationEvidence`, `AnnotationEvidence.__post_init__`, `EndpointFact`, `EndpointFact.__post_init__`, `AnalysisDiagnostic`, `AnalysisResult`, `AnalysisResult.__post_init__`; private `_read_path` | Разделы 3, 5.8. `_read_path` сохраняет существующий `SourceFile` или создаёт его из `os.fspath`. |
| `noir.diagnostics` | `DiagnosticEntry`, `DiagnosticEntry.message`, `DiagnosticEntry.rendered_line`, `DiagnosticCollector`, `DiagnosticCollector.__init__`, `DiagnosticCollector.record`, `DiagnosticCollector.entries`, `DiagnosticCollector.rendered_lines`, `DiagnosticCollector.captured`, `DiagnosticCollector.__len__`, `bind`, `current`, `format_endpoint_diagnostic`, `record`; type alias `Clock` | Разделы 4, 5.1, 5.8. `DiagnosticEntry.rendered_line` использует точность до секунды `%Y-%m-%d %H:%M:%S`. |
| `noir.immutability` | `freeze_data` | Разделы 3, 5.8 |
| `noir.paths` | `ensure_path_leading_slash`, `join_endpoint_paths`, `relative_source_path` | Раздел 5.8 |

Сгенерированные dataclass'ами методы equality/representation — обычная
механика Python, а не отдельные точки входа логики. Выше названы все написанные
вручную методы и property, влияющие на runtime-поведение.

Продолжение: [13 — Методы Spring](13-spring-methods.md); либо воспользуйтесь
[указателем методов](15-method-lookup.md) для точного source-symbol.
