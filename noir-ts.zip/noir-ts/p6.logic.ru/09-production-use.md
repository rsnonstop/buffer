# 09 — Production-использование и контроль рисков

[← Разобранные трассировки](08-worked-traces.md) · [Оглавление](README.md) · [Далее: Карта кода →](10-code-map.md)

Noir — консервативный producer исходного evidence. Он не запускает Java-
приложение, не загружает произвольный bytecode зависимостей, не вычисляет каждое
расширение framework и не проверяет развёрнутые network- и security-настройки.
При управляемом run нужно совместно рассматривать все созданные artifacts и
сверять их с независимым build- или runtime-view.

## 1. Что доказывает строка

Строка CSV означает:

> Для этого input root, зафиксированных Java bytes, поддерживаемых non-Java
> inputs, закреплённого parser и реализованных ограниченных static rules был
> доказан endpoint fact; затем output layer атрибутировал, нормализовал и
> сгруппировал его в public row.

Строка не доказывает, что:

- route активен в развёрнутом profile;
- его owner становится bean, resource, servlet или proxy;
- route достижим через hosts, gateways, policy или security;
- каждый runtime route присутствует в CSV;
- каждое framework request condition представлено в identity строки;
- handler авторизован, безопасен или корректно реализован.

~~~mermaid
flowchart LR
    SOURCE["Evidence Noir из source"] --> REVIEW["production-сверка"]
    BUILD["Build, generated source и dependencies"] --> REVIEW
    RUNTIME["Runtime inventory route'ов"] --> REVIEW
    DEPLOY["данные proxy, servlet, broker и deployment"] --> REVIEW
    REVIEW --> REGISTER["проверенный реестр endpoints"]
~~~

Ни source analysis, ни runtime-наблюдение не должны молча отменять результаты
друг друга. Расхождения — это evidence, которое нужно классифицировать.

## 2. Текущий production flow

~~~mermaid
flowchart TB
    SCRIPT["src/noir_sbt.py<br/>тонкий launcher"] --> CLI["noir.cli.run_cli<br/>валидация и publication"]
    CLI --> APP["noir.application.analyze<br/>типизированный run и scope diagnostics"]
    APP --> PIPE["noir.pipeline.run_analysis<br/>snapshot и порядок passes"]
    PIPE --> RUNTIME["noir.tree_sitter_runtime<br/>gate версий"]
    PIPE --> WORK["noir.java_workspace<br/>единый общий parse/index workspace"]
    WORK --> PASSES["выбранные family facades"]
    PASSES --> RESULT["неизменяемый AnalysisResult"]
    RESULT --> OUTPUT["noir.output<br/>projection и consolidation"]
    RESULT --> REPORTS["noir.reports<br/>сопутствующие artifacts"]
    NOIR["опциональный Noir v1.1 JSON"] --> COMPARE["noir.comparison"]
    COMPARE --> CLI
    OUTPUT --> CLI
    REPORTS --> CLI
~~~

Стабильные владельцы:

- [`noir.cli.run_cli`](../src/noir/cli.py) владеет arguments, destinations,
  порядком publication, сообщениями об ошибках и stdout.
- [`noir.application.analyze`](../src/noir/application.py) владеет одним
  типизированным call и присоединяет только diagnostics этого call.
- [`noir.pipeline.run_analysis`](../src/noir/pipeline.py) владеет проверкой
  dependencies, snapshot source, выбором frameworks, построением одного workspace,
  inventories и порядком analyzers.
- [`noir.java_frontend`](../src/noir/java_frontend.py) и
  [`noir.java_workspace`](../src/noir/java_workspace.py) владеют parsing и общими
  source indexes.
- Framework-модули потребляют compilation units или общий workspace и напрямую
  выдают значения `EndpointFact`.
- [`noir.output`](../src/noir/output.py) владеет намеренно lossy-границей CSV.
- [`noir.reports`](../src/noir/reports.py) и
  [`noir.comparison`](../src/noir/comparison.py) владеют rendering сопутствующих
  материалов и semantics сравнения.

Analysis не выполняет artifact I/O. Launcher не содержит application logic.

## 3. Воспроизводимое окружение

Pipeline вызывает
[`require_tree_sitter()`](../src/noir/tree_sitter_runtime.py) перед discovery
source. Принимается точная пара:

~~~text
tree-sitter      == 0.25.2
tree-sitter-java == 0.23.5
~~~

Отсутствующие package metadata или bindings либо другая пара приводят к
контролируемому `RuntimeError`, в том числе при пустом source root. Создавайте
изолированное окружение из
[`src/requirements.txt`](../src/requirements.txt); не обновляйте только один
parser package без повторной валидации.

Сохраняйте для каждого контролируемого run:

- commit анализатора;
- digest Python-окружения или container;
- commit приложения/build и состояние generated source;
- точную invocation, разрешённый analysis root, запрошенную framework policy и
  effective selection в порядке registry;
- релевантные inputs properties, YAML, descriptors и profiles;
- hashes каждого созданного artifact.

Широкий log содержит timestamps, поэтому его hash идентифицирует конкретный run,
а не ожидаемый byte-for-byte результат повторного запуска.

## 4. Политика выбора framework

### 4.1 Предпочитайте широкий default

Без `--framework` запускается сначала Spring, затем JAX-RS:

~~~bash
python3 src/noir_sbt.py \
  --path "/absolute/path/to/application" \
  --output "/absolute/path/to/staging/endpoints.csv"
~~~

Используйте `--framework spring` или `--framework jaxrx`, только когда владелец
приложения установил, что исключённое семейство нерелевантно. Повторяйте option,
если контролируемому scope требуется конкретная комбинация, например
`--framework spring --framework wicket`. Duplicate values и смешанные запросы
`auto`/explicit невалидны. Принимаемый token для JAX-RS — `jaxrx`. Explicit
selection Wicket сейчас задействует пустой integration lifecycle; её нельзя
считать inventory Wicket endpoints. Configuration, announcements,
inventories и analysis следуют порядку registry, а не порядку options.

### 4.2 Считайте `auto` режимом для удобства

`--framework auto` сканирует Java snapshot по необработанным, чувствительным к
регистру markers, а также проверяет точные файлы `pom.xml`. Analyzer может быть
выбран из-за текста в comment или string; framework может быть пропущен, если ни
один поддерживаемый marker не встретился. Находки code generation и Wicket —
это announcements; они не выбирают analyzer.

Wicket также присутствует в static execution table с реальной identity
`FrameworkSelection.WICKET`. Поэтому он является explicit mode CLI, но
`default_selected=False` исключает его из omitted mode, а manual marker rule —
из auto selection. Сейчас его hooks не выполняют semantic work и не возвращают
facts. Отдельный marker registry остаётся authority для advisory finding.

Auto selection не является контролем полноты. При production governance
фиксируйте найденные markers и обосновывайте использование этого режима.

## 5. Зафиксируйте правильный input

### 5.1 Выберите одно deployable application

Root должен включать каждую source-связь, необходимую для static model:

- строковые constants, разрешаемые между файлами (cross-file);
- объявленные в source composed или custom annotations;
- interfaces и superclasses controllers/resources;
- target types locators и application classes JAX-RS;
- дескрипторы `web.xml`;
- поддерживаемые Spring properties и YAML;
- каждый source module, упаковываемый в deployment.

Слишком узкий root создаёт false negatives. Слишком широкий monorepo root может
создать дублирующиеся FQN, конфликтующие configuration/application facts,
избыточное потребление памяти и нерелевантный source, похожий на deployable.
Обычная единица анализа — одно deployable application вместе с включёнными в
него source modules.

### 5.2 Материализуйте generated source осознанно

Generated Java виден, только если существует ниже root и вне исключённой
directory. Типичные build destinations, такие как `build`, `target` и `out`,
игнорируются. Скопируйте необходимый generated source во включённое staging tree
либо проанализируйте его поставляемый source отдельно и задокументируйте связи,
потерянные при разделении run. Зафиксируйте version и inputs генератора.

### 5.3 Учитывайте момент создания snapshot

[`SourceSnapshot`](../src/noir/pipeline.py) хранит каждый обнаруженный Java path
и его точные bytes. Marker selection, построение workspace, inventories и все
выбранные analyzers используют эти bytes. Каждый файл парсится один раз, а его
compilation unit используется совместно; прямой Spring получает
`analyze_direct_spring_mvc_unit(unit, workspace)`, а прямой JAX-RS —
`analyze_direct_jax_rs_unit(unit, workspace)`.

`pom.xml`, конфигурация Spring и `web.xml` читаются владеющими ими stages и не
входят в Java snapshot. Запускайте анализ для immutable checkout, чтобы эти
inputs не могли измениться в середине analysis.

~~~mermaid
sequenceDiagram
    participant Gate as gate parser
    participant Snap as Java snapshot
    participant Work as общий workspace
    participant Pass as analyzers
    Gate->>Snap: только поддерживаемый runtime
    loop deterministic Java paths
        Snap->>Work: фиксированные bytes, один parse
    end
    Work->>Pass: общие units и indexes
~~~

### 5.4 Согласуйте input для сравнения Noir

`--noir-report` сравнивает широкое множество распознанных annotations с
locations endpoints из Noir v1.1 по точному canonical source path и положительной
one-based line. Генерируйте report для той же source revision и layout.
Перемещение файла или вставка строки может превратить совпадающий evidence в
кажущееся расхождение.

Loader читает `endpoints[*].details.code_paths[*]`, проверяет присутствующие
значения line, разрешает поддерживаемые формы relative path и отклоняет
неоднозначные существующие интерпретации path. Отсутствующие lines допустимы,
но не дают location для сравнения. Некорректный input отклоняется до начала
publication output.

Результат сравнения — annotation-location audit, а не endpoint-only список
false negatives. Activation, class-path, media, parameter, client и messaging
annotations могут законно не иметь endpoint на собственной строке. Annotations
на одной строке неразличимы, поскольку Noir location не содержит identity
annotation.

## 6. Детерминированное и fail-closed поведение

При одинаковых inputs и поддерживаемых dependencies:

- Java discovery и roots analyzers используют стабильный порядок;
- source bytes, trees и время жизни queries принадлежат одному workspace;
- конфликты imports и дублирующиеся source identities остаются неоднозначными;
- consumers types, constants, annotations, hierarchy и deployment требуют
  однозначно доказанного evidence;
- ограниченные evaluators возвращают unresolved, а не исполняют Java;
- CSV groups сортируются по нормализованной public identity из шести полей;
- final-trigger report сортирует source evidence и не содержит timestamps.

Fail closed означает, что недоказанный candidate обычно не создаёт fact. Это
не означает, что весь source file обязан компилироваться. Реализация не
отклоняет каждый файл, корень Tree-sitter которого сообщает об ошибке;
восстановленное subtree, соответствующее поддерживаемой форме, всё ещё может
создать evidence. Считайте распарсенный, но не компилируемый source риском,
требующим review.

Типичные причины локального отклонения: конфликтующие imports, shadowed
constants, дублирующиеся FQN, неполные или циклические hierarchies, неоднозначные
deployment prefixes, неподдерживаемый data flow и превышенные semantic bounds.

Diagnostics — упорядоченные events с timestamps. Bytes CSV и final-trigger
могут быть стабильны, тогда как diagnostic log различается из-за часов или
чередования events.

## 7. Вложенные calls и concurrency

[`noir.application.analyze`](../src/noir/application.py) принимает immutable
`AnalysisRequest` и, опционально, принадлежащий run `DiagnosticCollector`.
[`noir.diagnostics.bind`](../src/noir/diagnostics.py) изолирует вложенные bindings,
а entries collector защищены lock.

Для одновременных embedded runs используйте:

- отдельные request, workspace, parser runtime и collector для каждого run;
- неизменяемые input trees;
- различные artifact destinations, когда caller позднее публикует результаты.

Не используйте один collector совместно для одновременных analyses: его event
stream может перемешаться, а один result — присвоить новые entries другого run.
Для параллельного CLI отдельные processes дают самую простую границу памяти и
stdout. Никогда не позволяйте двум invocations писать в одни destinations.

## 8. Публикация artifact'ов упорядочена, но не транзакционна

Родительская directory для output должна уже существовать. Relative output paths
разрешаются вызывающим процессом. CLI может перезаписывать существующие artifacts;
в comparison mode он не позволяет переданному Noir report одновременно быть
каким-либо output destination, включая alias через hard link.

Для `endpoints.csv` базовые файлы таковы:

~~~text
endpoints.csv
endpoints.csv.log
endpoints-anno-without-endpoints.log
~~~

С `--noir-report` также записывается:

~~~text
endpoints-anno-without-noir-endpoints.log
~~~

Порядок publication в [`run_cli()`](../src/noir/cli.py):

1. проверить input directory и опциональный Noir report;
2. создать или обнулить широкий `.log`;
3. выполнить анализ, спроецировать типизированные facts, консолидировать rows и
   отрендерить report payloads;
4. записать semicolon CSV с BOM;
5. записать широкий log annotations/diagnostics;
6. атомарно заменить final-trigger report;
7. атомарно заменить comparison report, если он запрошен;
8. вывести completion inventory и вернуть 0.

Эти файлы не образуют одну атомарную транзакцию. Важные состояния при ошибках:

| Место ошибки | Наблюдаемое состояние |
|---|---|
| некорректный input или Noir report | существующие outputs не изменены |
| контролируемая ошибка analysis | предыдущие CSV/reports остаются; широкий log содержит diagnostics текущей ошибки |
| неожиданная ошибка analysis или rendering | предыдущие CSV/reports остаются; широкий log обновляется по возможности |
| запись CSV | CSV может быть частичным; широкий log обновляется по возможности; atomic reports остаются прежними версиями |
| запись широкого log | текущий CSV может существовать; atomic reports остаются прежними версиями |
| publication final-trigger | текущие CSV и широкий log существуют; предыдущий final-trigger report сохраняется при ошибке replacement |
| publication comparison | текущие CSV, широкий log и final-trigger report существуют; предыдущий comparison report сохраняется при ошибке replacement |

`publish_bytes_atomically()` создаёт staging рядом с destination, выполняет flush,
`fsync`, close и вызывает `os.replace`; при ошибке он по возможности удаляет
staging file. Каждый call защищает только один report. Completion stdout
печатается лишь после успешной последней запрошенной publication.

Используйте свежую staging directory, проверьте весь набор artifacts, завершите
review, а затем публикуйте эту directory как единый release, контролируемый
окружающей automation. Не потребляйте CSV, пока process ещё выполняется.

## 9. Контрольный список перед запуском

Перед контролируемым run проверьте:

- [ ] root является source tree нужного deployable application;
- [ ] необходимый generated Java материализован во включённых paths;
- [ ] установлена точная пара parser;
- [ ] Java и non-Java inputs останутся неизменными;
- [ ] родитель output существует и является свежим staging location;
- [ ] framework choice широк или его ограничение обосновано;
- [ ] любой Noir report получен из той же revision и layout;
- [ ] присутствуют нужные конфигурация Spring и descriptors JAX-RS;
- [ ] имена ignored directories не скрывают deployed source;
- [ ] файлы используют читаемые ожидаемые encodings;
- [ ] бюджеты memory и time покрывают весь workspace;
- [ ] никакой другой process не пишет в те же paths.

[`IGNORED_SOURCE_DIRECTORIES`](../src/noir/contracts.py) содержит точные
basenames для деревьев dependencies, version control, build output, cache,
редакторов, virtual environment, temporary и generated output, а также других
неproduction-деревьев.

Любая directory с одним из этих точных basenames отсекается независимо от
места. Сопоставление Java suffix регистронезависимо. Для Maven discovery в
auto-mode требуется точное lowercase-имя `pom.xml`.

Нечитаемый Java прерывает построение snapshot. Некорректный UTF-8 может прервать
marker selection или последующее decoding. Считайте readability и encoding
входными gates.

## 10. Gates проверки после run

### Gate 1: структурная корректность

- Exit status равен нулю.
- CSV начинается с UTF-8 BOM, использует точки с запятой и записи CRLF и имеет
  ровно семь columns плюс header даже при отсутствии данных.
- Оба baseline companion paths существуют; comparison output существует, когда запрошен.
- Completion stdout называет каждый artifact этого run.
- `module_name` равен basename разрешённого input root.
- source paths принадлежат ожидаемому module inventory.

### Gate 2: проверка mode и surface

Прочитайте diagnostic framework mode. Отдельно подсчитайте строки для inbound
HTTP, Gateway, static handlers, outbound clients, WebSocket handshakes и message
destinations `SEND`/`SUBSCRIBE`. Не считайте каждую строку открытым inbound
server route.

### Gate 3: diagnostics и непредставленные triggers

Назначьте каждому непустому entry final-trigger одну disposition, например:
unsupported form, dead source, missing input, analyzer defect или deployment
ambiguity. Найдите в diagnostics как минимум `ERROR`, `Skipped`, `unresolved`,
`ambiguous`, `invalid`, `limit`, `cycle`, `duplicate`, `mixed` и ошибки
configuration. Отсутствие diagnostic не означает автоматического одобрения.

В comparison mode классифицируйте распознанные non-trigger annotations отдельно
от endpoint designators. Перед выводами о coverage учтите Noir paths без line и
неразличимость annotations на одной строке.

### Gate 4: независимая reconciliation

Сравните нормализованные surface/direction, method и path с одним или несколькими
источниками:

- Spring runtime mappings или другой независимо наблюдаемый inventory routes;
- introspection реализации JAX-RS;
- OpenAPI из deployed build;
- конфигурация Gateway, servlet или broker;
- сгенерированные route manifests.

Классифицируйте оба направления:

~~~text
runtime only -> static false negative, missing source/dependency, dynamic route, or root mismatch
static only  -> inactive profile/owner, static approximation, dead source, or deployment mismatch
~~~

### Gate 5: выборочные source traces

Для каждой присутствующей surface проследите representative rows через
задокументированные rules. Включите нормализованный path, унаследованный или
composed route, route с configuration prefix и пустую `method_annotation_line`,
когда она доступна.

## 11. Ожидаемые gaps

### Возможные строки только в static view

- прямой Spring MVC не доказывает activation controller;
- request conditions типа и метода Spring используют упорядоченное объединение;
- profiles, conditional owners, scanning и runtime feature flags не вычисляются;
- dead, excluded или noncompiled Java ниже root может быть распарсен;
- CSV identity не включает headers, media negotiation, filters и security;
- source configuration может отличаться от deployed resources;
- static-resource pattern не доказывает существование backing resource;
- parser recovery может распознать поддерживаемое subtree в некорректном source.

### Возможные отсутствующие runtime rows

- source игнорируется, находится вне root, генерируется позднее или присутствует только в dependency;
- identity type, annotation, constant, import, hierarchy или deployment нельзя доказать однозначно;
- registration динамична, рефлексивна, условна или использует неподдерживаемые DSL shapes;
- hierarchy неполна, дублируется, циклична, несовместима или превышает bound;
- locator возвращает external, interface или dynamic target;
- association JAX-RS application/package/servlet отсутствует или неоднозначна;
- evidence Javax и Jakarta смешано;
- Spring properties, YAML, profiles или data flow выходят за ограниченную model;
- auto mode не выбирает необходимый analyzer;
- повреждение синтаксиса мешает требуемой query shape.

Final-trigger report охватывает распознанные annotation triggers. Он не может
перечислить каждый возможный dynamic registration call.

## 12. Масштаб и semantic bounds

Workspace хранит каждый массив bytes Java source, syntax tree, владельца времени
жизни query и cross-file index. Inventories и endpoint candidates сосуществуют
до presentation. Общего ограничения на число файлов или объём bytes для run нет,
поэтому, когда это практично, анализируйте по одному deployable application.

Текущие branch limits:

| Модель | Ограничение |
|---|---:|
| Глубина и длина string expression Java/Spring | 12 / 8192 characters |
| Глубина и states Java hierarchy | 12 / 256 |
| Подстановки Spring placeholder и длина configured path | 100 / 8192 characters |
| Spring functional nesting, chain steps и routes | 16 / 256 / 4096 |
| Глубина, states и composed path JAX-RS subresource | 16 / 4096 / 8192 characters |
| один найденный `web.xml` | 10 MiB |

Превышение semantic bound отклоняет эту ветвь; оно не уменьшает memory, уже
занятую workspace.

## 13. Security и обработка данных

Широкий и final-trigger reports могут содержать annotation и следующие за ней
source lines. Строки CSV содержат внутренние paths, имена handlers и raw-написание
parameters. Обращайтесь с artifacts согласно access classification repository:

- по умолчанию не используйте public CI attachments;
- применяйте policy retention и redaction перед передачей;
- просматривайте logs в viewer, который не исполняет terminal escapes или links;
- проверяйте downstream file permissions;
- никогда не делайте вывод об authorization posture по наличию endpoint.

CSV cells, начинающиеся с `=`, `+`, `-` или `@`, не нейтрализуются. Импортируйте
CSV как text либо очистите downstream-копию перед открытием в spreadsheet.

Analyzer не оценивает authentication, authorization, CSRF, filters, validation,
rate limiting, flow чувствительных данных или exploitability.

## 14. Правила безопасного расширения

При добавлении coverage:

1. Поместите полную family sequence за её тремя facade hooks и добавьте один
   static [`FrameworkAdapter`](../src/noir/frameworks.py); сохраняйте
   [`noir.pipeline`](../src/noir/pipeline.py) generic.
2. Повторно используйте compilation units и indexes общего workspace; не парсите
   Java внутри feature module.
3. Держите framework-neutral parsing и правила имён в `java_frontend`,
   `java_workspace`, `java_ast`, `java_methods` или `java_hierarchy`; Spring/JAX-RS
   semantics оставляйте в framework-модулях.
4. Выдавайте значения `EndpointFact` с route, handler, project, annotation и
   represented-target evidence.
5. Ограничивайте exploration и отклоняйте неоднозначный evidence вместо догадок.
6. Записывайте ошибки candidates через [`noir.diagnostics.record`](../src/noir/diagnostics.py).
7. Оставляйте public projection в [`noir.output`](../src/noir/output.py), rendering
   reports — в [`noir.reports`](../src/noir/reports.py), а порядок filesystem —
   в [`noir.cli`](../src/noir/cli.py).
8. Перечитывайте владеющий analyzer, общие proof helpers, output projection и
   границу CLI, когда меняются эти responsibilities.

Полная последовательность действий maintainer'а разобрана на примере
выбираемого stub Wicket в
[16 — Добавление поддержки framework](16-adding-framework-support.md).

## 15. Запись о release и правило go/no-go

Сохраняйте как минимум:

~~~text
Analyzer commit/version:
Python/parser environment digest:
Application/build commit and generated-source state:
Analysis root, requested framework policy, and effective selection:
Artifact hashes and staging publication ID:
CSV counts by surface and method:
Final-trigger dispositions:
Noir comparison input/version and dispositions, if used:
Diagnostic dispositions:
Runtime/static reconciliation summary:
Accepted gaps, owners, and expiry:
Approval date:
~~~

Используйте результат как управляемый endpoint register, только если run
воспроизводим, все ожидаемые artifacts принадлежат одному успешному staging run,
каждый существенный diagnostic и непредставленный trigger получил disposition,
а различия с независимым inventory объяснены. Иначе он остаётся полезным audit
evidence, но не production-complete inventory.

Далее: [10 — Карта кода](10-code-map.md).
