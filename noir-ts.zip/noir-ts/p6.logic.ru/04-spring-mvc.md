# 04 — Логика Spring MVC

[← Общий Java engine](03-shared-java-engine.md) · [Оглавление](README.md) · [Дополнительные поверхности Spring →](05-spring-additional-surfaces.md)

Эта глава объясняет прямые аннотированные методы, accessor-методы компонентов
record, составные mapping-аннотации, определённые в source, и наследуемые
контракты controller. Другие механизмы Spring endpoint описаны в
[05 — Дополнительные поверхности Spring](05-spring-additional-surfaces.md).

> [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) владеет семантикой Spring
> mapping. Модуль потребляет общие Java facts и выдаёт значения `EndpointFact`.

Дополнение на уровне методов: [13 — Методы Spring](13-spring-methods.md)
раскрывает call graph прямых и составных аннотаций, alias и иерархии.

## 1. Владельцы и entry points

| Владелец | Основные символы | Ответственность |
|---|---|---|
| [`noir.spring_mvc`](../src/noir/spring_mvc.py) | `analyze_direct_spring_mvc_unit()`, `decode_builtin_spring_mapping()`, `decode_spring_composed_mapping()` | прямые mapping, составные аннотации и семантика `AliasFor` |
| [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) | `SpringMvcHierarchyAnalyzer`, `analyze_spring_mvc_hierarchy()` | наследуемые mapping-контракты, привязанные к конкретным controller |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `resolve_known_annotation()`, query group и helpers исходного текста | синтаксис в том же файле и identity библиотек |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `resolve_workspace_string_expression()`, `index_java_annotation_definitions()`, helpers доступности/retention аннотаций | значения между файлами и нейтральная структура source-аннотаций |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaSourceHierarchyGraph` | граф типов source, подстановка generic, erased signatures и специфичность interface |
| [`noir.evidence`](../src/noir/evidence.py) | `method_annotation_evidence_from_mapping()`, `represented_target_evidence()` | типизированный provenance (происхождение) |
| [`noir.spring_framework`](../src/noir/spring_framework.py) | `analyze_spring_framework()` | итерация по unit для прямого анализа и полная orchestration семейства Spring в заданном порядке |

Framework-модули импортируют Java helpers, композицию путей, builders evidence
и запись diagnostic из их собственных модулей-владельцев. Они не создают
parser и не публикуют artifacts.

## 2. Анализ общего unit

Pipeline строит один workspace, в котором нейтральные определения
source-аннотаций уже существуют до начала extraction endpoint'ов. Для каждого
snapshot source он находит compilation unit и вызывает:

~~~python
analyze_direct_spring_mvc_unit(unit, workspace)
~~~

Прямой analyzer повторно использует:

- точные source bytes и узлы синтаксиса;
- imports и query group объявлений;
- query group типов, методов и компонентов record;
- разрешение String по всему workspace, включая константы в том же и других
  файлах;
- нейтральные определения source-аннотаций.

Он копирует записи каждого типа перед добавлением локального для анализа
состояния mapping; общий unit и узлы Tree-sitter остаются неизменными.

~~~mermaid
sequenceDiagram
    participant P as facade spring_framework
    participant W as общий Java workspace
    participant D as прямой Spring analyzer
    participant H as analyzer иерархии

    P->>W: получить все parsed unit'ы snapshot'а и нейтральные definitions
    loop каждый compilation unit
        P->>D: analyze_direct_spring_mvc_unit(unit, workspace)
        D->>W: повторно использовать синтаксис и индексы
    end
    P->>H: analyze_spring_mvc_hierarchy(workspace)
    H->>W: повторно использовать иерархию и mapping facts
~~~

## 3. Прямой MVC flow

~~~mermaid
flowchart TD
    A[общий compilation unit] --> T[декодировать mapping на лексических типах]
    T --> M[обойти аннотированные методы в порядке source]
    M --> E{конкретный видимый в workspace class или record?}
    E -- нет --> Skip[пропустить target]
    E -- да --> F[первый распознанный mapping метода]
    F --> V{валиден?}
    V -- нет --> Skip
    V -- да --> L[скомпоновать mapping типов от внешнего к внутреннему]
    L --> C{каждый распознанный слой типа валиден?}
    C -- нет --> Skip
    C -- да --> X[размножить paths и выполнить упорядоченный union методов]
    X --> Fact[выдать значения EndpointFact]

    T --> R[обойти аннотированные компоненты record]
    R --> Z{подходящий неявный accessor?}
    Z -- нет --> Skip
    Z -- да --> F
~~~

Обычный метод, выдаваемый прямым pass, принадлежит захваченному class или
record, который не является abstract и видим в workspace. Interface, abstract
class и типы внутри методов, блоков, lambda или initializer не выдают прямых
facts.

Прямой pass не требует:

- `@Controller` или `@RestController`;
- public-типа или public-метода;
- нестатического метода;
- тела метода;
- доказательства активации bean.

Это намеренная граница false-positive: настоящий mapping на ином образом не
активированном конкретном source-владельце может выдать endpoint.

## 4. Identity встроенных mapping

Поддерживаемый package —
`org.springframework.web.bind.annotation`.

| Аннотация | Условие метода |
|---|---|
| `GetMapping` | `GET` |
| `PostMapping` | `POST` |
| `PutMapping` | `PUT` |
| `DeleteMapping` | `DELETE` |
| `PatchMapping` | `PATCH` |
| `RequestMapping` | явный упорядоченный набор или без ограничения |

`resolve_spring_mapping_name()` принимает точное fully qualified name,
совпадающий точный import или настоящий wildcard import Spring, если
source-объявления не конфликтуют.

Функция отвергает похожие имена и неоднозначный provenance. Видимый
лексический тип, source-декларация типа из того же package, конфликтующий точный
import или конфликтующий source-тип из wildcard-import'а могут затенить
ожидаемую identity.

`decode_builtin_spring_mapping()` различает:

- не распознано: вернуть `None`, чтобы можно было попробовать другую аннотацию;
- распознано и валидно: сохранить paths, методы, узел аннотации, canonical
  identity и семейство evidence;
- распознано, но невалидно: сохранить невалидный результат, подавляющий target.

Последнее состояние обеспечивает правило первого распознанного mapping.

## 5. Декодирование path

`get_spring_annotation_paths()` принимает positional-форму, `value` и `path`:

~~~java
@GetMapping("/items")
@GetMapping(value = "/items")
@GetMapping(path = "/items")
@GetMapping({"/items", "/archive"})
@GetMapping(path = Paths.ROOT + "/items")
~~~

Правила:

- более одного positional argument делает mapping невалидным;
- positional argument вместе с именованным `value` невалиден;
- `value` и `path` могут сосуществовать, только если их полностью разрешённые
  упорядоченные последовательности идентичны;
- arrays размножают варианты;
- дубликаты удаляются в порядке первого появления;
- отсутствие выбранного элемента или явно пустой array добавляет один пустой
  слой path;
- непустые paths получают начальный slash;
- если какое-либо выбранное expression не разрешено, весь набор path mapping
  невалиден; частичное размножение не сохраняется.

Значения используют ограниченный workspace String resolver: literals,
parentheses, addition и доказанные ссылки на константы. Циклы, неоднозначность,
неподдерживаемые expressions, recursion глубже 12 или значение длиннее 8192
символов приводят к fail-closed.

Другие атрибуты Spring mapping здесь не участвуют в identity path.

## 6. HTTP methods

Сокращённые verb-аннотации добавляют свой фиксированный метод. Для
`RequestMapping` элемент `method` принимает настоящие элементы
`RequestMethod`, найденные через qualified names, точные imports или
однозначные static imports.

Стабильный порядок:

~~~text
GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS, TRACE
~~~

| Форма `RequestMapping.method` | Результат |
|---|---|
| отсутствует или явно пустой array | без ограничения |
| каждый элемент валиден | упорядоченные уникальные методы |
| смешаны валидные и невалидные элементы | невалидные значения диагностируются; валидные сохраняются |
| каждый явный элемент невалиден | mapping невалиден |

Итог без ограничения превращается в `ANY`.

Условия типа и метода используют `union_request_method_conditions()`. Это
упорядоченный union, а не intersection Spring runtime:

~~~text
type methods   = [GET]
method methods = [POST, TRACE]
effective      = [GET, POST, TRACE]
~~~

Этот наблюдаемый выбор — важное ограничение интерпретации.

## 7. Первый mapping и лексические слои типов

`first_spring_mapping()` сортирует применённые аннотации по позиции в source.
Для каждой аннотации он пробует:

1. декодирование встроенного mapping;
2. декодирование составного mapping, определённого в source.

Побеждает первый результат, отличный от `None`. Поэтому распознанный
невалидный mapping блокирует более поздний валидный mapping на том же
объявлении.

~~~mermaid
flowchart LR
    A[аннотации в порядке source] --> B{распознана?}
    B -- нет --> C[следующая аннотация]
    C --> B
    B -- валидна --> D[использовать mapping]
    B -- невалидна --> E[пропустить target]
~~~

Для вложенных прямых class или record `compose_lexical_type_mapping()` проходит
слои типов от внешнего к внутреннему. Отсутствующие mapping типов нейтральны;
невалидный распознанный слой подавляет endpoint под ним.

Paths образуют Cartesian product:

~~~text
outer type paths × inner type paths × method paths
~~~

Дубликаты path сохраняют порядок первого появления. Для условий методов
используется описанный выше упорядоченный union.

## 8. Типизированные facts и evidence

Каждая эффективная пара path/method создаёт `EndpointFact`:

| Поле fact | Значение для прямого метода |
|---|---|
| `path` / `method` | составной route и эффективный HTTP method |
| `parameters` | нормализованный raw-текст внутри скобок списка параметров Java |
| `source_file` | source-файл handler |
| `source_line` | строка выбранной mapping-аннотации |
| `handler_name` | display name лексического типа плюс имя метода |
| `technology` / `protocol` / `surface` / `direction` | Spring, HTTP, server, inbound |
| `annotation_evidence` | проверенный provenance mapping метода из того же файла |
| `represented_targets` | точный span объявления метода |

`parameters` — не разобранный список HTTP-параметров.

Для составного mapping provenance указывает на применённую внешнюю
source-аннотацию и её canonical FQN, а разрешённое семейство mapping остаётся
доступным для выбора строки аннотации.

Каждый выданный fact записывается через `format_endpoint_diagnostic()`.
Сам analyzer не выполняет file I/O.

## 9. Accessor-методы компонентов record

У компонента Java record есть неявный accessor без параметров. Mapping на
компоненте может представлять этот accessor, когда:

1. его владелец — конкретный record, видимый в workspace;
2. нет явного метода без параметров с именем компонента;
3. применённый mapping встроенный либо является source-аннотацией, применимой
   к `METHOD`;
4. первый распознанный mapping и все лексические слои типов валидны.

Перегрузка с параметрами не подавляет неявный accessor.

Source-аннотация применима к методу, когда не осталось настоящего `@Target`,
либо когда разрешён ровно один настоящий `java.lang.annotation.Target` и его
уникальный набор элементов включает `ElementType.METHOD`. Неоднозначный
provenance, несколько настоящих targets, невалидная форма значения, дубликаты
или неизвестные element types либо набор без `METHOD` приводят к fail-closed.

Facts компонентов record используют:

- пустой `parameters`;
- строку mapping как `source_line`;
- identity Spring HTTP/server/inbound;
- отсутствие evidence аннотации метода;
- span компонента record как represented target.

## 10. Составные mapping, определённые в source

Составные mapping доказываются только по объявлениям аннотаций в общем source
workspace. Dependency bytecode и reflection не используются.

`index_java_annotation_definitions()` индексирует нейтральную Java-структуру
каждой source-аннотации:

- FQN, unit и identity типа;
- прямые meta-annotations;
- объявленные элементы, их types и defaults;
- прямые аннотации элементов, включая кандидатов `AliasFor`.

Все объявления одного FQN остаются видимыми, поэтому дубликаты остаются
неоднозначными. `source_annotation_definition()` требует одну доступную
identity и одно доступное definition.

Составное использование поддерживается только тогда, когда:

1. применённая аннотация разрешается в одно доступное source definition;
2. traversal meta-annotation не содержит циклов и укладывается в depth 12;
3. ровно одна route-ветвь достигает настоящего листа `RequestMapping`;
4. сокращённая verb-аннотация не используется как лист объявления;
5. каждый custom-слой имеет ровно один настоящий `@Retention(RUNTIME)`;
6. фиксированный leaf mapping валиден;
7. alias edges, типы элементов, defaults, промежуточные и use-site значения
   согласованы.

Несвязанные meta-annotations игнорируются. Source meta-annotation, которая
входит в mapping graph, но отсутствует, неоднозначна, недоступна, циклична или
невалидна, заставляет составное использование завершиться fail-closed.

~~~mermaid
flowchart TD
    A[применённая source-аннотация] --> B{одно доступное definition?}
    B -- нет identity --> N[не составная]
    B -- неоднозначно или недоступно --> X[распознана как невалидная]
    B -- да --> C[собрать ветви meta-annotation]
    C --> D{ровно одна ациклическая ветвь RequestMapping?}
    D -- нет --> X
    D -- да --> E{каждый custom-слой имеет runtime retention?}
    E -- нет --> X
    E -- да --> F{leaf и aliases согласованы?}
    F -- нет --> X
    F -- да --> G[canonical mapping]
~~~

`spring_composed_definition_is_supported()` выполняет проверку уровня
definition, используемую inventory аннотаций. Definition может оставаться
доступным для аудита, даже если одно его применение позднее не проходит
проверки размещения или значения.

## 11. Правила `AliasFor`

Принимается только настоящий
`org.springframework.core.annotation.AliasFor`. Похожие имена, несколько
кандидатов на одном элементе или неоднозначный provenance делают edge
невалидным.

Поддерживаются, в частности, формы:

~~~java
@AliasFor("path")
@AliasFor(value = "path")
@AliasFor(attribute = "path")
@AliasFor(annotation = RequestMapping.class, attribute = "path")
~~~

`value` и `attribute` — aliases и не могут присутствовать вместе. Допускается
не более одного positional value. Неизвестные named arguments отвергаются.
`annotation` должен быть разрешимым class literal, называющим ожидаемое
definition ветви или строго проверенную прямую sibling-аннотацию.

Канонические конечные элементы:

| Целевой элемент | Обработка |
|---|---|
| mapping `value` или `path` | endpoint path |
| `RequestMapping.method` | endpoint method |
| `name` или `version` | проверить форму String, затем исключить из identity endpoint |
| `params`, `headers`, `consumes` или `produces` | проверить форму String-array, затем исключить |
| проверенный custom sibling/local element | проверить согласованность типа/значения, затем исключить |

Правила graph и значений:

- циклы отвергаются;
- edges не могут указывать на внешний custom annotation в ветви;
- sibling target должен быть одной доступной runtime-retained прямой
  meta-annotation с одним target element;
- локальные пары alias должны быть взаимными;
- отсутствующие или дублирующиеся target elements невалидны;
- identity String и `RequestMethod` должны разрешаться точно;
- поддерживается forwarding scalar-to-array, но не array-to-scalar;
- сходящиеся значения требуют совместимых объявленных типов;
- неявные сходящиеся aliases требуют равных разрешимых defaults;
- неизвестные use-site attributes и обязательные элементы без defaults
  невалидны;
- cardinality значения должна соответствовать форме scalar/array;
- несколько выбранных значений для одного terminal должны совпадать.

Значения переопределяются от внутреннего слоя к внешнему:

~~~text
fixed RequestMapping leaf
    < inner custom meta-annotation values
    < outer custom meta-annotation values
    < explicit values on the applied type, method, or component
~~~

Внутри слоя явные значения имеют приоритет над defaults. Пустые значения не
стирают уже фиксированный непустой path или условие метода. Конфликтующие
значения делают весь mapping невалидным.

Итоговый mapping направляет provenance на применённую внешнюю аннотацию,
поэтому output evidence использует строку этого source, а не внутреннюю строку
`RequestMapping`.

## 12. Дополнения из иерархии

[`noir/spring_mvc_hierarchy.py`](../src/noir/spring_mvc_hierarchy.py)
обрабатывает наследуемые контракты как дополнительный pass после прямого
анализа.

Корень controller должен быть:

- одним уникальным source FQN;
- конкретным видимым в workspace class, не record;
- непосредственно аннотирован настоящим `Controller` или `RestController`.

Составные stereotypes и наследуемые marker controller не распознаются.

`SpringMvcHierarchyAnalyzer(workspace)` строит один
`JavaSourceHierarchyGraph` и caches mapping. Нейтральный graph предоставляет
edges superclass/interface, подстановку generic, erased signatures,
доступность, выбор конкретной/default реализации и максимально специфичные
методы interface.

Цикл, неразрешённый edge или edge неверного kind, несогласованное состояние
generic, недоступное объявление или превышение bound делает иерархию controller
неполной и подавляет все добавления иерархии для этого корня. После того как
graph признан полным, неоднозначность реализации или контракта подавляет только
затронутую signature.

### Выбор source mapping

Для каждой erased signature:

1. выбрать один пригодный конкретный class method или максимально специфичный
   default method interface для attribution handler;
2. если эта реализация принадлежит подходящему abstract/interface contract и
   имеет mapping, использовать его;
3. иначе выбрать ближайшее доступное mapped-объявление abstract class;
4. иначе потребовать один максимально специфичный доступный mapped origin
   interface;
5. оставить mapping на конкретной реализации корня прямому analyzer.

Конкурирующие несвязанные origins interface приводят к fail-closed. Diamond,
достигающий того же объявления, считается одним origin.

Слои hierarchy path в точности таковы:

~~~text
concrete controller's direct type mapping
+ mapping-source owner's direct type mapping
+ selected method mapping
~~~

Лексические enclosing types не являются hierarchy prefixes. Методы
объединяются упорядоченным union по трём слоям и становятся `ANY`, когда
ограничений нет.

### Attribution

Identity handler, parameters, source file и handler line факта берутся у
выбранной пригодной реализации. Route provenance берётся у выбранного mapped
contract. Project provenance указывает на корень конкретного controller.

Evidence аннотации метода сохраняется только тогда, когда source mapping и
реализация — один и тот же метод. Наследуемые mapping между разными методами
оставляют это evidence пустым. Represented target всегда идентифицирует
выбранный метод реализации.

## 13. Сводка подавления

| Проблема | Результат |
|---|---|
| аннотация не является доказанной Spring identity | не распознана; можно попробовать следующую аннотацию |
| выбранное expression path не разрешено | распознанный mapping невалиден; target пропущен |
| смешаны валидные и невалидные значения method | валидные значения сохраняются; невалидные диагностируются |
| каждое явное значение method невалидно | mapping невалиден |
| невалидный mapping лексического типа | прямые endpoint потомков подавляются |
| невалидный первый распознанный mapping | последующие mapping игнорируются; target пропущен |
| composed definition отсутствует, неоднозначно или недоступно | после нахождения identity составное использование завершается fail-closed |
| несколько составных ветвей или цикл | составной mapping невалиден |
| невалидный provenance, type, default или value `AliasFor` | составной mapping невалиден |
| явный accessor record без параметров | endpoint неявного компонента подавлен |
| source-аннотация неприменима к `METHOD` | кандидат компонента record исключён |
| неполная иерархия | наследуемые добавления этого controller подавлены; прямые facts остаются |
| конкретная реализация имеет mapping | добавление иерархии подавлено; им владеет прямой analyzer |
| неоднозначная реализация или contract | затронутая signature пропущена |

## 14. Намеренные ограничения

Анализ Spring MVC не доказывает:

- что прямой владелец является активированным Spring bean;
- семантику Spring runtime intersection для условий типа/метода;
- identity endpoint из `headers`, `params`, `consumes`, `produces`, `version`
  или `name`;
- составные аннотации, доступные только в dependency bytecode;
- произвольный runtime alias synthesis вне ограниченного source graph;
- controller scanning, conditional beans, profiles или security;
- объявления Kotlin, Groovy, compiled или generated, не предоставленные как
  Java source;
- наследуемые контракты, source-иерархию которых нельзя разрешить полностью.

Продолжение: [05 — Дополнительные поверхности Spring](05-spring-additional-surfaces.md).
