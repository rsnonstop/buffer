# 01 — Ментальная модель

## 1. Что представляет собой программа — и чем она не является

`noir_sbt` — статический распознаватель по source-коду. Он использует
Java-синтаксис и намеренно ограниченную semantic model, чтобы доказывать
endpoint fact'ы. Он не использует Maven или Gradle для компиляции кода, не
загружает classpath, не создаёт Spring application context, не запускает
JAX-RS container, не исполняет configuration-методы и не вычисляет
произвольный Java-код.

Этот выбор объясняет центральное правило всей реализации:

> Создавать endpoint, когда identity framework'а, данные route, привязка к
source и явные проверки допустимости текущей ветви статически однозначны; в
противном случае записывать причину в log и пропускать его.

Это поведение «fail closed» на уровне кандидата. Некорректный кандидат обычно
не прерывает scan и не удаляет корректных соседних кандидатов.

## 2. Граница системы

```mermaid
flowchart TB
    subgraph Inputs["Входные данные"]
        J["Java source-файлы"]
        SP["Spring application.properties / yml / yaml"]
        WX["JAX-RS web.xml"]
        CLI["CLI options"]
    end

    subgraph StaticAnalyzer["Статический анализатор noir_sbt"]
        D["Discovery"]
        TS["Tree-sitter parse и query"]
        W["Semantic index'ы всего workspace"]
        SA["Семейство Spring analyzer'ов"]
        JA["Семейство JAX-RS analyzer'ов"]
        FN["Форматирование, нормализация, объединение evidence"]
    end

    subgraph Outputs["Выходные данные"]
        CSV["Endpoint CSV"]
        LOG["Log annotation'ов + diagnostic'ов"]
        ABS["Log annotations-without-endpoints"]
        STD["stdout / stderr / exit status"]
    end

    CLI --> D
    J --> D
    D --> TS --> W
    SP --> SA
    WX --> JA
    W --> SA
    W --> JA
    SA --> FN
    JA --> FN
    FN --> CSV
    W --> LOG
    SA --> LOG
    JA --> LOG
    W --> ABS
    FN --> ABS
    D --> STD
```

Всё, что требует информации за пределами этих source/configuration-входов,
находится вне proof model. Примеры: runtime-условия bean'ов, active profile'и,
bytecode dependency, программно генерируемые строки, reflection за пределами
одной поддерживаемой формы registration, умолчания servlet-container'а, не
закодированные в поддерживаемой source/XML-модели, и route'ы, добавляемые
библиотеками в runtime.

## 3. Слои и направление dependency

[`src/noir_sbt.py`](../src/noir_sbt.py) — только исполняемый launcher. Читайте
приложение от границы команды внутрь:

```mermaid
flowchart TD
    F["noir_sbt.py\nlauncher"] --> C["noir.cli\nэффекты команды"]
    C --> A["noir.application\nтипизированный diagnostic scope"]
    A --> P["noir.pipeline\nоднонаправленный порядок stage'ей"]
    P --> M["noir.model\nнеизменяемые request/result/fact'ы"]

    P --> J["java_frontend + java_workspace"]
    J --> N["java_ast + java_methods + java_hierarchy"]
    J --> S["Semantic pass'ы Spring"]
    J --> X["Semantic pass'ы JAX-RS"]

    S --> O["noir.output + noir.reports"]
    X --> O
    C --> O
```

Pipeline импортирует конкретные analysis pass'ы, порядок которых он задаёт.
Специализированные analyzer'ы принимают общий workspace и специфичную для
feature configuration, используют сфокусированные helper'ы из владеющих ими
модулей и сразу возвращают значения `EndpointFact`. Service locator или
межмодульного global state нет.

Блоки диаграммы соответствуют следующим конкретным определениям:

| Понятие на диаграмме | Координата кода | Что там изучать |
|---|---|---|
| граница request и result | [`src/noir/model.py`](../src/noir/model.py) :: `AnalysisRequest`, `AnalysisResult` | Валидация, неизменяемость и данные, которым разрешено пересекать границу приложения |
| полный stage flow | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | Единственный верхнеуровневый порядок discovery, построения workspace и framework-pass'ов |
| представление source | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `SourceSnapshot` и `_snapshot_sources()` | Точный инвариант path/byte, обеспечивающий внутреннюю согласованность запуска |
| parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `build_workspace_runtime()` | Закреплённая dependency-gate и построение query/runtime |
| богатая identity endpoint'а | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` | Route, handler, project, protocol/surface и private evidence до потерь в CSV |
| граница публичной row | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` | Какие богатые поля сохраняются при projection, а какие намеренно отбрасываются |

## 4. Один общий workspace, много семейств endpoint'ов

Сначала `run_analysis()` создаёт неизменяемый `SourceSnapshot`. Затем
нейтральный `java_workspace.build_java_workspace()` создаёт каждый compilation
unit и общие index'ы; pipeline присоединяет Spring/JAX-специфичные index'ы к
этому же объекту. `build_workspace_runtime()` один раз компилирует полный общий
набор query. Ни один framework-pass повторно не разбирает source, уже
находящийся в workspace.

```mermaid
flowchart LR
    F["Каждый найденный Java-файл"] --> U["Compilation unit"]
    U --> T["Типы и lexical nesting"]
    U --> I["Import'ы и package"]
    U --> C["Строковые константы"]
    U --> A["Вхождения и определения annotation'ов"]
    T --> W["Workspace index'ы"]
    I --> W
    C --> W
    A --> W
    W --> X1["Direct decoder'ы"]
    W --> X2["Hierarchy graph'ы"]
    W --> X3["Распознаватели Functional/DSL"]
    W --> X4["Audit inventory"]
```

Workspace охватывает всё source-дерево, а не один файл, потому что path'ы и
route annotation'ы могут зависеть от:

- констант, объявленных в других файлах;
- exact- и wildcard-import'ов;
- вложенных типов или типов из того же package;
- source-defined composed annotation'ов;
- custom JAX-RS annotation'ов HTTP-метода;
- generic interface'ов и abstract base class'ов;
- return type'ов subresource;
- принадлежности к project.

## 5. Каталог семейств endpoint'ов

Следующая таблица — высокоуровневая dispatch-карта. Подробные proof condition'ы
приведены в главах о framework'ах.

| Семейство | Распознаваемая source-форма | Внутренний surface | Форма публичного `interface_type` |
|---|---|---|---|
| Spring MVC direct | `@GetMapping`, другие shortcut'ы, `@RequestMapping`, поддерживаемые composed mapping'и | server | `http <verb>` |
| Spring MVC hierarchy | Mapping на interface/abstract contract, привязанный к методу concrete controller | server | `http <verb>` |
| Spring functional | Servlet/WebFlux `RouterFunction` в настоящем publisher'е `@Bean` | server | `http <verb>` |
| Spring programmatic MVC | Ограниченный graph `RequestMappingHandlerMapping.registerMapping` | server | `http <verb>` |
| Spring Cloud Gateway | Ограниченный Java DSL `@Bean RouteLocator` | gateway | `http-gateway <verb>` |
| Spring static resources | `WebMvcConfigurer.addResourceHandlers` | static-handler | `http-static-handler GET` |
| Spring HTTP Interface | `@HttpExchange` / фиксированные exchange annotation'ы на interface'ах | client | `http-client <verb>` |
| Spring OpenFeign | Interface с `@FeignClient` и MVC mapping'ами | client | `http-client <verb>` |
| Spring raw/STOMP handshake | Registration'ы `WebSocketConfigurer` или `WebSocketMessageBrokerConfigurer` | websocket-handshake | `ws GET` |
| Spring messaging | Controller с `@MessageMapping` / `@SubscribeMapping` | message | `ws SEND` / `ws SUBSCRIBE` |
| JAX-RS direct | Concrete class/record с `@Path` и public designator method | default server | `http <verb>` |
| JAX-RS hierarchy | Annotation bundle interface/abstract-контракта, привязанный по erased signature | default server | `http <verb>` |
| JAX-RS subresource | Один или несколько типизированных locator-edge'ей `@Path`, ведущих к leaf | default server | `http <verb>` |
| Java WebSocket | Javax/Jakarta class/record с `@ServerEndpoint` | websocket | `ws GET` |

Для protocol'ов, отличных от HTTP, formatter отбрасывает подтип surface.
Поэтому Spring handshake и JAX WebSocket handshake оба превращаются в CSV в
`ws GET`.

## 6. Три identity внутри одного endpoint fact

Некоторые analyzer'ы различают:

1. **route declaration** — место объявления path/verb;
2. **concrete handler** — method/type, сообщаемый как реализация endpoint'а;
3. **project owner** — тот, чья Spring/JAX configuration задаёт base path.

У direct-метода все три обычно находятся в одном файле. Они могут расходиться:

```mermaid
flowchart LR
    C["Interface contract\n@GetMapping('/items')"] -->|"route source"| E["Внутренний endpoint fact"]
    H["Concrete controller\nItemsController.list()"] -->|"handler + source для CSV"| E
    P["Publisher/configuration module"] -->|"владелец base path"| E
    E --> R["CSV row"]
    R --> O["Остаются только concrete source/method"]
```

Типизированное значение может переносить все три identity, не предоставляя
наружу изменяемую row-форму:

```python
EndpointFact(
    path="/api/items",
    method="GET",
    parameters="String filter",
    source_file=SourceFile("/workspace/app/ItemsController.java"),
    source_line=42,
    handler_name="ItemsController.list",
    route_source_file=SourceFile("/workspace/contracts/ItemsApi.java"),
    route_source_line=12,
    handler_source_file=SourceFile("/workspace/app/ItemsController.java"),
    handler_source_line=42,
    project_source_file=SourceFile("/workspace/app/Routes.java"),
    technology="spring",
    protocol="http",
    surface="server",
    direction="inbound",
    annotation_evidence=(...),
    represented_targets=(...),
)
```

Не каждый analyzer заполняет каждое необязательное поле provenance или
classification. Projection принимает только `EndpointFact`, сохраняет
типизированное evidence до consolidation и не копирует `source_line` напрямую
в CSV.

## 7. Pass'ы, работающие по принципу additions-only

Direct pass'ы Spring и JAX-RS покрывают простые concrete annotation'ы.
Hierarchy-, route-registration- и другие специализированные extraction-pass'ы
добавляют fact'ы, которые они могут доказать сверх этой основы; локальное для
кандидата отклонение в одном из таких pass'ов не удаляет несвязанный direct
fact. Описание additions-only заканчивается на extraction: более поздний
Spring configuration pass переписывает каждый Spring path и может удалить
любой fact, чей настроенный path не удалось разрешить. Неожиданное исключение
в любом pass'е прерывает весь запуск.

```mermaid
flowchart TD
    SD["Direct Spring fact'ы"] --> SA["Добавить Spring route registration, hierarchy и другие surface'ы"]
    SA --> C["Применить Spring configuration; fact'ы могут быть переписаны или удалены"]
    JD["Direct JAX-RS fact'ы"] --> JA["Добавить JAX-RS hierarchy, locator- и WebSocket-fact'ы"]
    C --> M["Объединить fact'ы выбранных framework'ов"]
    JA --> M
    M --> N["Нормализовать"]
    N --> G["Сгруппировать по публичной шестиполевой identity"]
    G --> R["Одна итоговая row на identity"]
```

Итоговая identity включает concrete source, имя метода и сырой текст
параметров. Два handler'а с одинаковыми method/path остаются двумя row'ами,
если эти поля различаются.

## 8. Два значения слова «строка»

Есть два несвязанных понятия строки:

- `source_line` — внутренняя diagnostic-строка analyzer'а; в зависимости от
  ветви это может быть route call, handler method, annotation или type.
- `method_annotation_line` позже выбирается из проверенного same-source
  evidence annotation'а метода.

Они не взаимозаменяемы. Non-annotation route'ы и унаследованные cross-file
mapping'и могут иметь осмысленный внутренний `source_line`, тогда как колонка
CSV остаётся пустой.

## 9. Детерминизм и полнота

Реализация уделяет большое внимание детерминированному порядку и отклонению
неоднозначностей:

- сортированный discovery;
- точные source identity;
- фиксированный порядок framework'ов и HTTP-методов;
- порядок по source-byte;
- детерминированная локальная и итоговая deduplication;
- ограниченный graph traversal;
- отклонение нескольких равноценных допустимых binding'ов.

Эти свойства делают повторные результаты доступными для audit, но не
доказывают полноту. Поддерживаемый Java-код, оказавшийся неподдерживаемым или
неоднозначным для анализатора, может быть пропущен. Поэтому diagnostic'и и
report annotations-without-endpoints являются частью результата, а не
необязательным шумом.

Далее: [02 — CLI и orchestration](02-cli-and-orchestration.md).
