# 07 — Типизированный output, evidence, consolidation и reports

[← JAX-RS](06-jax-rs.md) · [Оглавление](README.md) · [Далее: Пошаговые примеры →](08-worked-traces.md)

Один анализ создаёт богатый неизменяемый результат и три baseline artifacts.
`--noir-report` добавляет четвёртый artifact сравнения. Каждый отвечает на свой
вопрос:

| Artifact | Вопрос | Владелец |
|---|---|---|
| endpoint CSV | Какие endpoint rows доказала ограниченная source model? | [`noir.output`](../src/noir/output.py) |
| `<output>.log` | Какие релевантные аннотации и diagnostic events были замечены? | [`noir.reports`](../src/noir/reports.py) |
| `*-anno-without-endpoints.log` | Какие final-trigger declaration targets не имеют итоговой row? | [`noir.reports`](../src/noir/reports.py) |
| `*-anno-without-noir-endpoints.log` | Какие broad annotation locations не имеют точного location в переданном report Noir v1.1? | [`noir.comparison`](../src/noir/comparison.py) |

Дополнение на уровне методов:
[14 — Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) прослеживает
точные методы evidence, consolidation, rendering, comparison и publication.

Для `--output endpoints.csv`:

```text
endpoints.csv.log
endpoints-anno-without-endpoints.log
endpoints-anno-without-noir-endpoints.log  # only with --noir-report
```

CSV из семи колонок намеренно lossy. Companion reports — параллельные views
evidence, их нельзя восстановить из CSV.

## 1. Presentation flow

```mermaid
flowchart TB
    Pipeline["run_analysis"] --> Result["AnalysisResult"]
    Result --> Facts["tuple[EndpointFact]"]
    Result --> Audit["broad inventory аннотаций"]
    Result --> Triggers["final-trigger inventory"]

    Facts --> Project["endpoint_fact_to_row_candidate"]
    Project --> Candidates["значения EndpointRowCandidate"]
    Candidates --> Consolidate["нормализация + group по шести полям + union evidence"]
    Consolidate --> Rows["ConsolidatedEndpoints.rows"]
    Consolidate --> Targets["ConsolidatedEndpoints.represented_targets"]

    Audit --> Broad["log аннотаций/diagnostic"]
    Triggers --> Absent["renderer отсутствующих triggers"]
    Targets --> Absent
    Audit --> Compare["необязательное сравнение точных locations"]

    Rows --> CSV["endpoint CSV"]
    Broad --> Log["<output>.log"]
    Absent --> Missing["atomic report отсутствующих triggers"]
    Compare --> NoirMissing["atomic comparison report"]
```

В зоне ответственности [`run_cli`](../src/noir/cli.py) находятся validation
аргументов, единый diagnostic scope, projection, rendering, порядок publication
и success output.
Framework analyzers ничего не знают о CSV или paths artifacts.

## 2. Типизированные значения до presentation

### 2.1 `EndpointFact`

Framework analyzers возвращают frozen slot-based значения
[`EndpointFact`](../src/noir/model.py). Важные поля:

| Данные | Значение |
|---|---|
| `path`, `method`, `parameters` | результат analyzer до public normalization |
| `source_file`, `source_line`, `handler_name` | public attribution и diagnostic context analyzer |
| `route_source_file`, `route_source_line` | provenance declaration route |
| `handler_source_file`, `handler_source_line` | provenance конкретного handler |
| `project_source_file` | provenance владения configuration |
| `protocol`, `surface`, `direction`, `technology` | богатая классификация interface |
| `annotation_evidence` | tuple из `AnnotationEvidence` |
| `represented_targets` | tuple из `SourceTarget` |
| `spring_client_path_layers` | отложенные слои path Spring client или `None` |

Source inputs, похожие на path, нормализуются в `SourceFile`. Evidence и
targets уже должны быть типизированы; mappings отвергаются. Каждая domain
collection фиксируется как immutable tuple.

`SourceSpan` хранит непустой half-open byte range в одном `SourceFile`.
`SourceTarget` добавляет kind declaration (`method`, `record-component` или
`type`). Это отделяет source provenance от display strings и parser nodes.

### 2.2 Значения output

[`endpoint_fact_to_row_candidate`](../src/noir/output.py) принимает один
`EndpointFact` и возвращает frozen `EndpointRowCandidate`, содержащий:

- шесть ячеек public identity;
- принадлежащее ему `AnnotationEvidence`; и
- принадлежащие ему значения `SourceTarget`.

Седьмая ячейка CSV не выбирается во время projection. Сначала evidence должно
объединиться по всем candidates с одинаковой public identity.

[`ConsolidatedEndpoints`](../src/noir/output.py) содержит только:

- `rows`: tuple read-only string mappings; и
- `represented_targets`: типизированный глобальный union targets.

Внутри domain нет второй формы row. Граница public CSV и граница
типизированного report-evidence остаются явными.

## 3. Единственная граница потери информации

Projection сохраняет только то, что способен выразить стабильный public
artifact:

```mermaid
flowchart LR
    Fact["EndpointFact: route + handler + project + classification + evidence"]
    Fact --> Candidate["EndpointRowCandidate"]
    Candidate --> Identity["шесть public cells"]
    Candidate --> Evidence["принадлежащее annotation evidence"]
    Candidate --> Targets["принадлежащие represented targets"]
    Identity --> Group["consolidate_endpoint_rows"]
    Evidence --> Group
    Targets --> Group
    Group --> Row["семь public cells"]
    Group --> TargetUnion["глобальный union targets"]
```

Детали route/handler/project, direction, technology и некоторые детали surface
не помещаются в CSV. Они остаются доступными до этой projection.

## 4. Семь колонок и identity по шести полям

Точный public-порядок из [`CSV_FIELDS`](../src/noir/contracts.py):

| Позиция | Колонка | Построение |
|---:|---|---|
| 1 | `module_name` | basename analysis root, переданный CLI |
| 2 | `interface_type` | сжатые protocol/surface плюс method |
| 3 | `endpoint` | нормализованный path, URL или destination |
| 4 | `source_file_name` | POSIX path относительно analysis root |
| 5 | `method_name` | handler, выбранный analyzer |
| 6 | `parameters` | spelling параметров, предоставленный analyzer |
| 7 | `method_annotation_line` | строка выбранного принадлежащего evidence либо пусто |

Только первые шесть определяют identity:

```text
(module_name,
 interface_type,
 endpoint,
 source_file_name,
 method_name,
 parameters)
```

`method_annotation_line` описывает эту identity. Candidates, различающиеся
только evidence, должны объединиться до выбора строки.

Public values преобразуются в strings без mutation inputs. `None` становится
пустой ячейкой; scalar values используют своё обычное spelling; structured
values предпочитают Unicode JSON и откатываются к `str`, если encoding
завершается неудачно.

## 5. `interface_type`

Projection добавляет endpoint method к сжатому виду interface:

| Fact | Публичное значение |
|---|---|
| HTTP server `GET` | `http GET` |
| HTTP server без ограничения | `http ANY` |
| HTTP client `POST` | `http-client POST` |
| HTTP gateway `GET` | `http-gateway GET` |
| HTTP static handler `GET` | `http-static-handler GET` |
| WebSocket handshake `GET` | `ws GET` |
| отправка message | `ws SEND` |

Для HTTP пустой/server surface становится `http`; другой surface становится
`http-<surface>`. Для non-HTTP protocols публичен только protocol. Внутренние
surface, direction и technology остаются facts, но отдельно не кодируются.

## 6. Нормализация path до grouping

[`normalize_endpoint_path`](../src/noir/output.py) запускается до построения
identity key, поэтому разные spellings analyzers могут консолидироваться.

### 6.1 Spring templates и placeholders

Сбалансированный regex template Spring теряет constraint:

```text
/orders/{id:[0-9]{1,3}} -> /orders/{id}
```

Scanner учитывает вложенные/escaped braces. Несбалансированная форма
сохраняется, а не угадывается.

Каждый оставшийся `${...}` превращается в стабильный brace parameter по
последнему Java-like identifier или в `value`, если такого нет:

```text
${route.leaf}    -> {leaf}
${route.leaf:/x} -> {x}
${---}           -> {value}
```

Это presentation normalization, а не вычисление project properties.

### 6.2 Slashes и protocols

Повторяющиеся slashes схлопываются, кроме случаев с предшествующим `:`, чтобы
сохранить authority URL. `http-client` и `http-gateway` всё равно
нормализуются как HTTP. Непустое относительное HTTP-значение получает начальный
slash; non-HTTP destinations остаются относительными.

```text
http-client GET + api//items      -> /api/items
ws SEND         + topic//events   -> topic/events
http GET        + HTTP://x//v1    -> HTTP://x/v1
grpc CALL       + service//Method -> service/Method
```

## 7. Evidence аннотации метода

Строка CSV никогда не копируется из `EndpointFact.source_line`. Она заново
вычисляется из проверенных [`AnnotationEvidence`](../src/noir/model.py).

Одна пригодная record доказывает:

- положительную non-Boolean integer line;
- canonical dotted identity Java-аннотации;
- распознанное семейство evidence; и
- canonical source аннотации, равный public endpoint source.

Canonical ownership использует нормализованные real absolute paths. Аннотация
interface, superclass, declaration route или configuration может доказывать
endpoint, не владея его public handler row; она не может заполнить ячейку line
этой row.

[`merge_method_annotation_evidence`](../src/noir/evidence.py) выполняет
deduplication по:

```text
(family, line, identity, canonical source file)
```

[`select_method_annotation_evidence`](../src/noir/evidence.py) сортирует по:

1. mapping Spring для конкретного verb;
2. generic mapping Spring;
3. message mapping Spring;
4. request-method designator JAX-RS;
5. наименьшая line внутри family;
6. identity аннотации как окончательный tie-break.

Поэтому Spring verb mapping на line 20 имеет приоритет над JAX designator на
line 2. Проверенные source-defined аннотации несут family, установленное их
semantic decoder.

Типичные пустые lines встречаются у cross-file inherited mappings,
синтезированных accessor record, registrations
functional/Gateway/resource и `@ServerEndpoint`.

## 8. Represented targets

Report отсутствующих triggers вычитает declarations, а не route strings или
имена handler. Один target выглядит так:

```text
SourceTarget(
  kind,
  SourceSpan(SourceFile(canonical_path), start_byte, end_byte)
)
```

Spans удовлетворяют `0 <= start_byte < end_byte`. Поддерживаемые kinds:
`method`, `record-component` и `type`.

Projection сохраняет только targets, принадлежащие public source file endpoint.
Consolidation канонизирует, дедублицирует, сортирует и объединяет targets по
всем сохранившимся public groups.

Subtraction выполняется на уровне target. Если одна итоговая row представляет
method, то покрыты все final-trigger аннотации, прикреплённые к этому method.
Target interface остаётся отсутствующим, когда row представляет только
конкретную implementation. Одна сгруппированная CSV row может покрыть несколько
точных declarations, поскольку дубликаты объединяют своё target evidence.

## 9. Типизированные merge и consolidation

Локальное для analyzer слияние и public consolidation решают разные задачи.

[`merge_endpoint_facts`](../src/noir/evidence.py) сохраняет обычные поля более
нового `EndpointFact`, объединяя annotation evidence и targets.
[`deduplicate_endpoint_facts`](../src/noir/evidence.py) принимает typed identity
callback, позволяя каждому analyzer включать transient или surface-specific
identity.

[`consolidate_endpoint_rows`](../src/noir/output.py) является authoritative для
public artifact:

1. скопировать шесть public cells;
2. преобразовать их в strings и нормализовать `endpoint`;
3. сгруппировать по точному tuple из шести values;
4. объединить annotation evidence и represented targets;
5. выбрать annotation line;
6. построить новую row из семи полей в требуемом порядке;
7. отсортировать groups лексикографически; и
8. вернуть immutable tuple/read-only snapshots.

Разворот порядка итерации candidates даёт то же consolidated value. Любое
различие нормализованных method, interface, handler, source file, parameters
или endpoint сохраняет rows раздельными.

### Пример merge

У двух candidates один public handler:

| Поле | A | B |
|---|---|---|
| endpoint | `//api//items/{id:[0-9]+}` | `/api/items/{id}` |
| evidence | JAX `GET`, line 2 | Spring `GetMapping`, line 20 |
| target | method bytes 30–50 | method bytes 10–20 |

Оба нормализуются в `/api/items/{id}`. Шесть полей совпадают, priority family
Spring выбирает line 20, и оба targets сохраняются. Public row:

```text
app;http GET;/api/items/{id};Api.java;Api.items;;20
```

## 10. Companion views аннотаций

### 10.1 Broad log аннотаций и diagnostics

[`write_annotation_diagnostic_log`](../src/noir/reports.py) записывает broad
inventory аннотаций, после которого следует обязательная секция
`Diagnostics:`. Broad inventory включает triggers endpoint и полезные metadata
активации/binding. Каждое occurrence может показывать source spelling, line,
framework classifications, resolved identities и source extract. Для файла
без распознанных аннотаций выводится `Annotations: none`.

Inventory имеет детерминированный порядок анализа и не содержит timestamps.
После него следуют строки collector с timestamps.

### 10.2 Report annotations-without-endpoints

[`render_annotations_without_endpoints_report_bytes`](../src/noir/reports.py)
получает final-trigger inventory и глобальный union targets. Функция:

- сортирует файлы по display path;
- сохраняет порядок выбранных execution adapters, переданный при построении
  inventory;
- фильтрует по точному membership target;
- сортирует оставшиеся declarations по byte span;
- рендерит детерминированные UTF-8 bytes; и
- выдаёт `Annotations without endpoints: none` для пустой выбранной секции.

Пустой inventory создаёт ровно пустые bytes. При выводе path удаляется только
последний suffix:

```text
endpoints.csv       -> endpoints-anno-without-endpoints.log
endpoints           -> endpoints-anno-without-endpoints.log
endpoints.audit.csv -> endpoints.audit-anno-without-endpoints.log
```

Любая explicit selection с Wicket — полезный пример empty path. Сейчас у Wicket
нет broad- или final-trigger classifications для annotations, а его facade не
выдаёт facts. Для каждого обнаруженного Java-файла
final-trigger inventory всё равно содержит выбранную секцию `wicket` в порядке
adapter registry, а renderer выводит
`Annotations without endpoints: none`; если Java-файлов нет, report пуст.
Чтобы добавить реальные classifications и facts, следуйте extension path из
[16 — Добавление поддержки framework](16-adding-framework-support.md), не
добавляя отдельную ветвь Wicket в renderer.

## 11. Необязательное сравнение locations Noir

`--noir-report` сравнивает broad inventory аннотаций — не CSV rows и не
final-trigger inventory — с source locations из JSON report Noir v1.1.

[`load_noir_report_locations`](../src/noir/comparison.py) проверяет input до
инициализации любого output. Root — object с array `endpoints`; каждый endpoint
имеет `details.code_paths`; каждый code path имеет непустой string `path`.
Отсутствующая/null line пропускается. Присутствующая line должна быть
положительным non-Boolean integer.

Absolute paths канонизируются напрямую. Relative paths разрешаются от analysis
root. Spelling, включающий basename root, разрешает неоднозначность по реальным
файлам; два существующих варианта interpretation делают report невалидным.

Точный match key:

```text
(canonical real absolute source path, positive one-based annotation line)
```

URL, HTTP method, technology, имя аннотации и enclosing declaration не
участвуют. Поэтому две распознанные аннотации в одной физической line либо обе
совпадают, либо обе остаются unmatched.

[`compare_annotation_audit_inventory`](../src/noir/comparison.py) сохраняет
file, spelling, line, framework/resolved identity и extract для каждого
unmatched occurrence. Поскольку broad inventory включает support annotations,
этот report означает «у Noir нет source location endpoint на этой строке
аннотации», а не обязательно «Noir пропустил endpoint».

Детерминированный report суммирует общее число annotations, уникальные
locations Noir, точные matches и unmatched occurrences. Его path следует тому
же правилу последнего suffix:

```text
endpoints.csv       -> endpoints-anno-without-noir-endpoints.log
endpoints           -> endpoints-anno-without-noir-endpoints.log
endpoints.audit.csv -> endpoints.audit-anno-without-noir-endpoints.log
```

Когда `--noir-report` отсутствует, этот файл не создаётся и не удаляется.

## 12. Run-local diagnostics

[`noir.diagnostics`](../src/noir/diagnostics.py) захватывает diagnostics в
memory. Модуль не выполняет artifact I/O.

Каждый CLI run создаёт `DiagnosticCollector` с injected clock и привязывает
его через `ContextVar`. Вложенные scopes восстанавливают предыдущий collector;
collectors защищают собственные списки entries. Immutable `DiagnosticEntry`
содержит timestamp и `AnalysisDiagnostic`. Его rendered line:

```text
YYYY-MM-DD HH:MM:SS message
```

Module function `record(message) -> None` захватывает запись при наличии
привязанного collector, иначе выполняет безвредный no-op. Поэтому прямые pure
call'ы analyzer'а остаются без file I/O.
[`noir.application.analyze`](../src/noir/application.py) добавляет к immutable
`AnalysisResult` только diagnostics, созданные во время этого invocation; CLI
использует `rendered_lines` того же collector для broad log.

## 13. Точные bytes CSV

[`write_endpoint_csv`](../src/noir/output.py) открывает файл с `utf-8-sig` и
`newline=""`, затем использует `csv.DictWriter` с `CSV_FIELDS` и delimiter
semicolon. Наблюдаемый contract:

- UTF-8 BOM (`EF BB BF`);
- ровно семь колонок header в документированном порядке;
- разделители semicolon;
- обычное CSV quoting для delimiters, quotes и newlines;
- records CRLF (`\r\n`); и
- header даже при отсутствии rows.

Writer копирует и преобразует в string нужные cells, игнорирует неизвестные
presentation keys и не мутирует consolidated rows.

## 14. Порядок publication CLI и failures

CLI — упорядоченная multi-artifact operation, а не одна atomic transaction.
Необязательная validation input Noir — gate до publication.

```mermaid
flowchart TD
    Validate["проверить input и optional Noir report"] --> LogInit["создать/обнулить broad log"]
    LogInit --> Analyze["анализировать с bound collector"]
    Analyze --> Memory["project, consolidate, render reports и summary"]
    Memory --> CSV["записать CSV напрямую"]
    CSV --> Broad["записать broad log напрямую"]
    Broad --> Absent["atomic replace report отсутствующих triggers"]
    Absent --> Optional{"comparison включено?"}
    Optional -->|да| Comparison["atomic replace comparison report"]
    Optional -->|нет| Print["напечатать completion summary"]
    Comparison --> Print
```

Broad log инициализируется после validation path/input. CSV и broad log
записываются напрямую и могут отражать неудавшийся текущий run. При failure CLI
пытается в best-effort режиме перезаписать broad log, не маскируя исходную
ошибку. Контролируемый `RuntimeError` Tree-sitter записывает `ERROR: ...`,
записывает log и завершается через error path argument-parser до publication
CSV/report.

[`publish_bytes_atomically`](../src/noir/reports.py) обрабатывает каждый byte
report:

1. создать соседний temporary file;
2. записать полный in-memory payload;
3. выполнить flush и `fsync`;
4. закрыть; и
5. заменить через `os.replace`.

При failure на этапах write, flush, sync, close и replace, а также при
interruption, код по возможности очищает staging state и сохраняет предыдущий
завершённый destination данного artifact. Более ранние успешные artifacts не
откатываются. Если publication comparison завершается неудачно, текущие
CSV/log/absent output сохраняются, как и предыдущий comparison report.

Parent directory output'а должна уже существовать. Completion text печатается
один раз и только после publication всех запрошенных artifacts. Framework
announcements `Found ...` предшествуют ему. Любой failure подавляет блок
`noir-ts analysis completed.`.

## 15. Совместное чтение artifacts

1. Проверьте header CSV, module и семейства interface.
2. Различайте rows server, client, gateway, static, handshake и message.
3. Читайте пустую annotation line как «нет принадлежащего selectable evidence».
4. Просмотрите каждую непустую секцию absent-trigger.
5. В comparison mode отделяйте endpoint designators от допустимых support
   annotations, не имеющих location Noir.
6. Ищите в broad log errors, пропущенные candidates, неразрешённые identity,
   ambiguity и решения configuration.
7. Учитывайте порядок publication, когда artifacts выглядят как результаты
   разных состояний run.
8. Сопоставляйте static facts с runtime inventories для dynamic,
   dependency-defined или reflective routes.

`EndpointFact` отвечает, что знает analysis. CSV отвечает, что сохраняет
presentation. Типизированные evidence и companion reports объясняют разницу.

Далее: [08 — Пошаговые примеры](08-worked-traces.md).
