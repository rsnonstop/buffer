# 10 — Карта кода

[← Разобранные трассировки](08-worked-traces.md) · [Оглавление](README.md) · [Словарь application logic →](11-naming-and-code-vocabulary.md)

Эта глава связывает текущее поведение application с владеющим им production
source. Вместо номеров строк координаты используют links на файлы и стабильные
symbols.

## 1. Архитектурный маршрут

~~~mermaid
flowchart TB
    LAUNCH["src/noir_sbt.py<br/>guard запуска"]
    CLI["noir.cli<br/>аргументы, artifacts, stdout"]
    APP["noir.application<br/>типизированный scope diagnostics"]
    PIPE["noir.pipeline<br/>snapshot, selection, generic phases"]
    REG["noir.frameworks<br/>static execution table"]
    RUNTIME["tree_sitter_runtime<br/>version gate и runtime"]
    JAVA["java_frontend + java_workspace<br/>однократный parse и index"]
    SPRING["spring_framework<br/>Spring family facade"]
    JAX["jaxrs_framework<br/>JAX-RS family facade"]
    WICKET["wicket_framework<br/>selectable empty facade"]
    MODEL["noir.model<br/>типизированные facts и result"]
    INV["noir.inventory<br/>broad- и trigger-views"]
    OUTPUT["noir.output<br/>projection и consolidation"]
    REPORTS["noir.reports + noir.comparison<br/>render и publish"]

    LAUNCH --> CLI --> APP --> PIPE
    PIPE --> REG
    PIPE --> RUNTIME --> JAVA
    REG --> SPRING
    REG --> JAX
    REG --> WICKET
    JAVA --> SPRING --> MODEL
    JAVA --> JAX --> MODEL
    JAVA --> WICKET
    WICKET -. empty tuple .-> MODEL
    JAVA --> INV --> MODEL
    MODEL --> OUTPUT --> REPORTS
    CLI --> REPORTS
~~~

`src/noir_sbt.py` намеренно является тонким launcher. Поведение application
находится в `src/noir/`, модули которого напрямую импортируют настоящих
владельцев. Framework analyzers потребляют общий workspace и выдают значения
`EndpointFact`; они не зависят от launcher, не изменяют command state и не
публикуют файлы.

### Быстрый маршрут по реализации

| Шаг | Координата в коде | Ответственность |
|---|---|---|
| launch | [`src/noir_sbt.py`](../src/noir_sbt.py) :: executable guard | Импортировать `noir.cli.main` и завершиться с его status. |
| validate и publish | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` | Проверить inputs, привязать diagnostics, вызвать analysis, выполнить projection fact'ов, опубликовать запрошенные artifacts по порядку и вывести сообщение об успехе. |
| владеть одним типизированным run | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` | Проверить `AnalysisRequest`, владеть collector или повторно использовать его, вызвать pipeline и присоединить только diagnostics этой invocation. |
| оркестрировать analysis | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | Проверить доступность parser, создать snapshot sources, выбрать frameworks, построить один workspace, запустить analyzers и вернуть `AnalysisResult`. |
| скомпоновать analyzer families | [`src/noir/frameworks.py`](../src/noir/frameworks.py) :: `FRAMEWORK_ADAPTERS` | Связать static hooks каждого family с execution order, identity для explicit selection и default policy. |
| запустить family sequences | [`src/noir/spring_framework.py`](../src/noir/spring_framework.py) :: `analyze_spring_framework()`; [`src/noir/jaxrs_framework.py`](../src/noir/jaxrs_framework.py) :: `analyze_jaxrs_framework()`; [`src/noir/wicket_framework.py`](../src/noir/wicket_framework.py) :: `analyze_wicket_framework()` | Владеть порядком passes каждого family или намеренно пустым поведением без cross-family imports. |
| построить parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `require_tree_sitter()`, `build_workspace_runtime()` | Обеспечить поддерживаемую пару dependencies и построить parser/query runtime. |
| parse и index | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` → [`src/noir/java_frontend.py`](../src/noir/java_frontend.py) :: `build_java_compilation_unit()` | Единожды распарсить каждый source из snapshot и построить общие per-file и cross-file facts. |
| запустить direct mappings | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()`; [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` | Интерпретировать доказанные direct annotations Spring и JAX-RS как типизированные endpoint facts. |
| построить inventories | [`src/noir/inventory.py`](../src/noir/inventory.py) :: `build_annotation_audit_inventory()`, `build_final_trigger_inventory()` | Построить broad annotation view и более узкий endpoint-trigger view из общего workspace. |
| project и consolidate | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()`, `consolidate_endpoint_rows()` | Пересечь public-границу потери информации, нормализовать identity, объединить evidence и выбрать annotation line. |
| render reports | [`src/noir/reports.py`](../src/noir/reports.py) :: `render_annotations_without_endpoints_report_bytes()`; [`src/noir/comparison.py`](../src/noir/comparison.py) :: `flatten_final_trigger_inventory()`, `compare_final_trigger_inventory()` | Создать trigger-based отчёт об отсутствии и опциональное trigger-only сравнение по точному source location. |

## 2. Владение в package

### 2.1 Invocation и application core

| Владелец | Основные symbols | Ответственность |
|---|---|---|
| [`noir.cli`](../src/noir/cli.py) | `build_argument_parser`, `run_cli`, `render_completion_summary` | User input, filesystem effects, порядок publication и stdout. |
| [`noir.application`](../src/noir/application.py) | `AnalysisRunner`, `analyze` | Типизированная граница call и владение diagnostics. |
| [`noir.pipeline`](../src/noir/pipeline.py) | `SourceSnapshot`, `FrameworkDecision`, `run_analysis` | Полный порядок source-to-result без artifact I/O. |
| [`noir.frameworks`](../src/noir/frameworks.py) | `FrameworkAdapter`, `FRAMEWORK_ADAPTERS`, `default_framework_selections`, `adapters_for_plan` | Зафиксированная execution composition, selection lookup, setup/preparation hooks и порядок families. |
| [`noir.discovery`](../src/noir/discovery.py) | `discover_java_files`, `discover_pom_files`, `scan_framework_markers` | Отсечение ignored paths, deterministic discovery и marker-based auto selection. |
| [`noir.tree_sitter_runtime`](../src/noir/tree_sitter_runtime.py) | `SUPPORTED_VERSIONS`, `require_tree_sitter`, `build_workspace_runtime`, `run_query_matches` | Gate parser packages и построение query runtime. |
| [`noir.diagnostics`](../src/noir/diagnostics.py) | `DiagnosticCollector`, `bind`, `record`, `format_endpoint_diagnostic` | Захват diagnostics в рамках run и стабильные сообщения endpoint. |
| [`noir.contracts`](../src/noir/contracts.py) | `CSV_FIELDS`, framework constants, evidence-family constants | Общий декларативный словарь для analyzers и presentation. |

### 2.2 Общий Java engine

| Владелец | Основные symbols | Ответственность |
|---|---|---|
| [`noir.java_queries`](../src/noir/java_queries.py) | `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | Framework-neutral определения query source. |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `parse_java_query_set`, `build_java_compilation_unit`, `resolve_known_annotation`, `resolve_known_type` | Parsing Tree-sitter, association captures, per-file facts и identity известных libraries. |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace`, `resolve_workspace_owner_fqns`, `resolve_workspace_string_expression` | Cross-file types, members, constants, annotations, retention и access rules. |
| [`noir.java_ast`](../src/noir/java_ast.py) | `field`, `walk_named`, `known_type`, `is_direct_invocation_statement` | Небольшие общие helpers навигации по AST и доказательства. |
| [`noir.java_methods`](../src/noir/java_methods.py) | `MethodFact`, `MethodIndex`, `build_strict_method_index`, `build_varargs_method_index` | Детерминированные method и invocation indexes для ограниченных source flows. |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord`, `JavaSourceHierarchyGraph` | Generic adaptation, erased signatures, traversal inheritance и selection implementation. |
| [`noir.paths`](../src/noir/paths.py) | `join_endpoint_paths`, `ensure_path_leading_slash`, `relative_source_path` | Нейтральная композиция route и форматирование public source path. |

Построением runtime владеет `tree_sitter_runtime`; собственно parse source
принадлежит `java_frontend`. Framework analyzers получают распарсенные продукты
workspace и никогда не строят собственный parser.

### 2.3 Framework-analyzer'ы

| Владелец | Точка входа | Surface |
|---|---|---|
| [`noir.spring_framework`](../src/noir/spring_framework.py) | `configure_spring_workspace`, `prepare_spring_analysis`, `analyze_spring_framework` | No-op shared setup/preparation и полный упорядоченный набор Spring analyzers. |
| [`noir.jaxrs_framework`](../src/noir/jaxrs_framework.py) | `configure_jaxrs_workspace`, `prepare_jaxrs_analysis`, `analyze_jaxrs_framework` | JAX indexes, deployment model, direct resources, hierarchy/subresources и Java WebSocket. |
| [`noir.wicket_framework`](../src/noir/wicket_framework.py) | `configure_wicket_workspace`, `prepare_wicket_analysis`, `analyze_wicket_framework` | Доступные через explicit selection no-op setup/preparation и пустой result analysis; semantics endpoints пока нет. |
| [`noir.spring_mvc`](../src/noir/spring_mvc.py) | `analyze_direct_spring_mvc_unit` | Direct MVC mappings, composed annotations, records и mapping indexes. |
| [`noir.spring_route_registrations`](../src/noir/spring_route_registrations.py) | `analyze_spring_route_registrations` | Functional routes RouterFunction и programmatic MVC registrations. |
| [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) | `analyze_spring_mvc_hierarchy` | Унаследованные mapping contracts, связанные с concrete controllers. |
| [`noir.spring_gateway`](../src/noir/spring_gateway.py) | `analyze_spring_gateway` | Routes Java DSL Spring Cloud Gateway. |
| [`noir.spring_config`](../src/noir/spring_config.py) | `build_spring_path_configuration`, `analyze_spring_resource_handlers`, `apply_spring_path_configuration` | Конфигурация project, resource handlers, placeholders и финальные Spring path layers. |
| [`noir.spring_clients`](../src/noir/spring_clients.py) | `analyze_spring_http_clients` | Outbound contracts Spring HTTP Interface и OpenFeign. |
| [`noir.spring_websocket_messaging`](../src/noir/spring_websocket_messaging.py) | `analyze_spring_websocket_and_messaging` | Raw/STOMP handshakes и message destinations. |
| [`noir.jaxrs`](../src/noir/jaxrs.py) | `analyze_direct_jax_rs_unit` | Direct resources, custom request methods, record accessors и application paths. |
| [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) | `build_jax_rs_deployment_model`, `select_jax_rs_deployment_prefix` | Source applications и ограниченные deployment prefixes из `web.xml`. |
| [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) | `analyze_jax_rs_hierarchy_and_subresources` | Унаследованные resource bundles и рекурсивные subresource locators. |
| [`noir.java_websocket`](../src/noir/java_websocket.py) | `analyze_java_websocket_endpoints` | Server-side handshake'и Javax/Jakarta WebSocket. |

Каждый entry point выше возвращает значения `EndpointFact`. Локальная
deduplication использует callback, вычисляющий analyzer-specific identity, и
общий merger типизированного evidence в `noir.evidence`.

### 2.4 Domain, evidence и presentation

| Владелец | Основные symbols | Ответственность |
|---|---|---|
| [`noir.model`](../src/noir/model.py) | `FrameworkMode`, `FrameworkSelection`, `AnalysisRequest`, `FrameworkPlan`, `EndpointFact`, `AnalysisResult` | Immutable-словарь application, включая normalization scalar/tuple requests. |
| [`noir.evidence`](../src/noir/evidence.py) | `method_annotation_evidence_from_node`, `represented_target_evidence`, `deduplicate_endpoint_facts` | Валидация, merge и selection типизированного provenance. |
| [`noir.inventory`](../src/noir/inventory.py) | `build_annotation_audit_inventory`, `build_final_trigger_inventory` | Broad и endpoint-trigger views annotations. |
| [`noir.output`](../src/noir/output.py) | `EndpointRowCandidate`, `ConsolidatedEndpoints`, `consolidate_endpoint_rows`, `write_endpoint_csv` | Projection public rows, группировка по шести полям, выбор седьмого поля и точные bytes CSV. |
| [`noir.reports`](../src/noir/reports.py) | `write_annotation_diagnostic_log`, `render_annotations_without_endpoints_report_bytes`, `publish_bytes_atomically` | Базовые companion artifacts. |
| [`noir.comparison`](../src/noir/comparison.py) | `load_noir_report_locations`, `flatten_final_trigger_inventory`, `compare_final_trigger_inventory`, `render_noir_comparison_report_bytes` | Строгая валидация Noir report, нормализация trigger occurrences и точное сравнение canonical file/line. |
| [`noir.immutability`](../src/noir/immutability.py) | `freeze_data` | Отделение и заморозка вложенных result data. |

## 3. Точный порядок analyzers

`run_analysis()` создаёт snapshot и framework decision, затем строит neutral
workspace. Перед построением broad и final-trigger inventories он конфигурирует
каждый adapter с его selected state. Далее он подготавливает каждый выбранный
adapter; на этом этапе JAX-RS строит свой deployment model. Только после
завершения всей preparation pipeline вызывает выбранные analyzers в порядке
execution registry.

Порядок Spring:

1. direct Spring MVC для каждого source;
2. functional и programmatic route registrations;
3. дополнения MVC hierarchy;
4. Gateway;
5. handlers статических resources;
6. исходящие clients;
7. конфигурация project path;
8. WebSocket и messaging;
9. одно финальное применение Spring path configuration ко всем собранным facts.

Порядок JAX-RS:

1. direct JAX-RS для каждой compilation unit;
2. дополнения hierarchy и subresource;
3. handshake'и Java WebSocket.

Для выбранного Wicket действуют те же три lifecycle phases без semantic work:
configure оставляет workspace без изменений, prepare оставляет project state
без изменений, а analyze возвращает `()`. Wicket может запускаться отдельно
или в составе repeated explicit selection, например вместе со Spring. Registry,
а не порядок options в CLI, помещает Spring перед Wicket. Wicket исключён из
default-набора для omitted mode и из auto selection.

Эти passes используют один workspace. Порядок их iteration может влиять на
diagnostics, но public rows позднее нормализуются, группируются и сортируются
в `noir.output`.

## 4. Особенно важные production invariants

| Инвариант | Где устанавливается инвариант |
|---|---|
| Script является только executable launcher; package code никогда его не импортирует. | `src/noir_sbt.py` и направление imports package |
| У построения parser runtime один owner, а у фактического parsing Java — один frontend owner. | `noir.tree_sitter_runtime` и `noir.java_frontend` |
| Каждый обнаруженный Java source читается и парсится один раз, затем повторно используется каждым выбранным pass. | `SourceSnapshot`, `build_java_workspace()` и `run_analysis()` |
| Entry points analyzer'ов возвращают `EndpointFact`; presentation не может создавать analyzer facts. | Типизированные границы analyzers и построение `AnalysisResult` |
| Diagnostics принадлежат одной invocation application; только CLI публикует artifacts и stdout. | `noir.application`, `noir.diagnostics` и `noir.cli` |
| Неоднозначные Java identity, constants, hierarchy, deployment или flow локально работают fail closed. | Resolver/decoder, владеющий каждой proof boundary |
| Дублирующиеся facts детерминированно объединяют annotation evidence и represented targets. | `noir.evidence` и `noir.output` |
| Первые шесть полей CSV определяют identity строки; annotation line выбирается после merge evidence. | `EndpointRowCandidate.public_identity()` и `consolidate_endpoint_rows()` |
| Успех CLI появляется только после publication всех запрошенных artifacts. | Финальная ветвь `run_cli()` |

## 5. Владение change impact

| Если меняется… | Начните с… | Затем проследуйте… |
|---|---|---|
| Валидация CLI, naming, publication или stdout | `noir.cli` | к report renderer или application call, только если меняется и эта граница |
| request/result или scope diagnostics | `noir.model`, `noir.application`, `noir.diagnostics` | к порядку stages pipeline, если меняется lifecycle |
| discovery или automatic framework markers | `noir.discovery` | к `_select_frameworks()` и projection announcements |
| порядок execution, default family selection или adapter hooks | `noir.frameworks` | к facade соответствующего family, затем к orchestration phases в `noir.pipeline` |
| добавление ещё одного framework family | [Добавление поддержки framework](16-adding-framework-support.md) | к identity в model/CLI, одному facade, одной adapter record, затем к optional semantic inventories и evidence |
| построение parser/query | `noir.tree_sitter_runtime`, `noir.java_queries`, `noir.java_frontend` | к consumers workspace, использующим изменившийся capture |
| imports, types, constants, access или ambiguity | `noir.java_workspace` | к каждому analyzer, потребляющему изменившееся proof |
| direct semantics Spring или JAX | `noir.spring_mvc` или `noir.jaxrs` | к hierarchy/configuration, только когда они участвуют |
| одна supplemental surface | владеющий ею module Spring/JAX/WebSocket | к evidence и output, если меняется public identity |
| владение evidence или deduplication | `noir.evidence` | к `noir.output`, inventories и reports |
| Parsing или matching Noir report | `noir.comparison` | к `noir.cli`, если меняются naming или порядок publication |
| общие constants или registries | `noir.contracts` или определяющий module | ко всем importers, поскольку у этих значений намеренно несколько consumers |

Для missing endpoint сравните принятую source shape с самой близкой похожей
формой, которая работает fail closed: shadowed import, ambiguous constant,
unsupported placement, mixed namespace, cycle или unresolved value. Первый
resolver, вернувший `None`, владеет соответствующим решением application.

## 6. Индекс «глава → код»

| Глава | Первая координата в коде |
|---|---|
| [Ментальная модель](01-mental-model.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [CLI и orchestration](02-cli-and-orchestration.md) | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` |
| [Общий Java engine](03-shared-java-engine.md) | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` |
| [Spring MVC](04-spring-mvc.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [Дополнительные Spring surfaces](05-spring-additional-surfaces.md) | [`src/noir/spring_framework.py`](../src/noir/spring_framework.py) :: `analyze_spring_framework()` |
| [JAX-RS](06-jax-rs.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Output и reports](07-output-evidence-reports.md) | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` |
| [Разобранные трассировки](08-worked-traces.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Production-использование](09-production-use.md) | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` |
| [Словарь application](11-naming-and-code-vocabulary.md) | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` |
| [Методы core runtime](12-core-runtime-methods.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Методы Spring](13-spring-methods.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Поиск методов](15-method-lookup.md) | поиск точного symbol по трём руководствам уровня методов |
| [Добавление поддержки framework](16-adding-framework-support.md) | [`src/noir/frameworks.py`](../src/noir/frameworks.py) :: `FrameworkAdapter` и один family facade |

Вернитесь к [оглавлению guide](README.md) или продолжите с
[словарём application logic](11-naming-and-code-vocabulary.md).
