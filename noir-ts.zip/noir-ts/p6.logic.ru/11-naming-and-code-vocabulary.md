# 11 — Имена и словарь кода

[← Карта кода и тестов](10-code-and-test-map.md) · [Оглавление](README.md) ·
[Методы core runtime →](12-core-runtime-methods.md)

Это приложение к документации определяет имена, используемые текущим application в `src/noir/`.
Словарь сопровождает один run от типизированного request через общие Java facts
и framework analysis до public artifacts.

## 1. Предложение, описывающее application

> Проанализировать один `AnalysisRequest`: создать snapshot его Java sources,
> построить один общий workspace, выполнить выбранные framework passes и вернуть
> immutable-значения `EndpointFact` и inventories в `AnalysisResult`.

Затем CLI выполняет projection и publication этого result:

~~~mermaid
flowchart LR
    R[AnalysisRequest] --> S[SourceSnapshot]
    S --> W[Java workspace]
    W --> P[Framework passes]
    P --> F[EndpointFact]
    F --> A[AnalysisResult]
    A --> C[EndpointRowCandidate]
    C --> O[CSV и сопутствующие reports]
~~~

Эти имена остаются различными, потому что несут разную информацию.
`EndpointFact` богаче строки CSV, а source snapshot — не parsed compilation unit.

## 2. Application values

Immutable-словарь application находится в
[`noir/model.py`](../src/noir/model.py).

| Имя | Значение |
|---|---|
| `AnalysisRequest` | нормализованный root анализа и запрошенный framework mode |
| `FrameworkSelection` | одно нормализованное семейство analyzer: Spring или JAX-RS |
| `FrameworkPlan` | запрошенный mode вместе с фактическим упорядоченным selection |
| `SourceFile` | типизированная identity source path |
| `SourceSpan` | точный полуоткрытый byte interval внутри одного source file |
| `SourceTarget` | kind декларации вместе с точным span, представленным endpoint |
| `AnnotationEvidence` | проверенный provenance method annotation из того же файла |
| `EndpointFact` | lossless output analyzer до public projection |
| `AnalysisDiagnostic` | presentation-neutral event, созданный во время analysis |
| `AnalysisResult` | immutable facts, inventories, данные framework decision, announcements и diagnostics |

[`noir/application.py`](../src/noir/application.py) :: `analyze()` —
programmatic boundary. Она принимает `AnalysisRequest`, запускает pipeline в
одном diagnostic scope и возвращает `AnalysisResult`. Она не выполняет parsing
arguments или artifact I/O.

CLI получает имя CSV module из basename input directory; это presentation value,
а не intent анализа application.

## 3. Словарь orchestration

[`noir/pipeline.py`](../src/noir/pipeline.py) владеет порядком source-to-result.

| Имя | Ответственность |
|---|---|
| `SourceSnapshot` | детерминированные source paths и точные bytes, единожды прочитанные для run |
| `FrameworkDecision` | фактический `FrameworkPlan`, обнаруженные markers и announcements |
| `_snapshot_sources()` | обнаружить Java files и захватить их bytes |
| `_select_frameworks()` | применить explicit, default или marker-based selection |
| `_build_workspace()` | построить один parser runtime, один workspace и indexes выбранных frameworks |
| `_analyze_spring()` | запустить все Spring endpoint surfaces, затем применить project path configuration |
| `_analyze_jaxrs()` | запустить direct resources, hierarchy/subresources и Java WebSocket |
| `run_analysis()` | проверить dependencies, упорядочить каждый stage, обеспечить типизированные results analyzers и построить `AnalysisResult` |

**Pass** — шаг analyzer над общим workspace. Pass не выполняет discovery файлов
и не публикует artifacts.

Default framework mode выбирает Spring и JAX-RS в таком порядке.
`--framework auto` вместо этого сканирует raw marker evidence и может выбрать
более узкий набор. Extraction endpoints начинается только после построения
inventories и, при необходимости, deployment model JAX-RS.

## 4. Общий Java-словарь

Java engine разделяет построение runtime, per-file parsing, cross-file resolution,
method flow и inheritance:

~~~mermaid
flowchart TB
    B[Bytes из snapshot] --> U[Compilation unit]
    U --> W[Indexes workspace]
    W --> M[Method facts и indexes]
    W --> H[Hierarchy graph]
    M --> X[Интерпретация framework]
    H --> X
~~~

- **Runtime** — проверенные language Tree-sitter, parser, queries и factory
  query cursor, которыми владеет
  [`noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py).
- **Compilation unit** — распарсенное и проиндексированное представление одного
  Java file, сохраняющее его source bytes и nodes Tree-sitter. Его строит
  [`noir/java_frontend.py`](../src/noir/java_frontend.py).
- **Workspace** — collection compilation units вместе с cross-file indexes
  types, imports, members, constants, annotations и framework declarations.
  Его строит [`noir/java_workspace.py`](../src/noir/java_workspace.py).
- **Method fact** и **method index** описывают ограниченные Java method bodies,
  formal parameters, invocations и lookup identity. Они находятся в
  [`noir/java_methods.py`](../src/noir/java_methods.py).
- **Hierarchy graph** описывает видимые в source types, supertypes, method
  signatures и selection implementation. Он находится в
  [`noir/java_hierarchy.py`](../src/noir/java_hierarchy.py).

Глаголы resolver имеют стабильные значения:

| Prefix | Значение |
|---|---|
| `resolve_known_*` | доказать identity поддерживаемой library внутри одной compilation unit |
| `resolve_workspace_*` | пройти по видимым в source declarations или constants между units |
| `index_*` | получить повторно используемые lookup data |
| `select_*` | выбрать из доказанных candidates, обычно отклоняя ambiguity |
| `decode_*` | интерпретировать syntax value после установления его identity |
| `analyze_*` | выдать endpoint facts для одной определённой surface |

## 5. Словарь framework

Название технологии в коде и прозе — **JAX-RS**. Public selector CLI остаётся
`jaxrx`.

### Владельцы Spring

| Module | Surface |
|---|---|
| [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) | direct MVC mappings, composed annotations, records и mapping indexes |
| [`noir/spring_route_registrations.py`](../src/noir/spring_route_registrations.py) | functional routes и programmatic MVC registrations |
| [`noir/spring_mvc_hierarchy.py`](../src/noir/spring_mvc_hierarchy.py) | унаследованные mapping contracts, связанные с concrete controllers |
| [`noir/spring_gateway.py`](../src/noir/spring_gateway.py) | routes Java DSL Spring Cloud Gateway |
| [`noir/spring_config.py`](../src/noir/spring_config.py) | project path configuration и static resource handlers |
| [`noir/spring_clients.py`](../src/noir/spring_clients.py) | outbound contracts HTTP Interface и OpenFeign |
| [`noir/spring_websocket_messaging.py`](../src/noir/spring_websocket_messaging.py) | raw/STOMP handshakes и message destinations |

### Владельцы JAX-RS и WebSocket

| Module | Surface |
|---|---|
| [`noir/jaxrs.py`](../src/noir/jaxrs.py) | direct resources, custom request methods, records и application paths |
| [`noir/jaxrs_deployment.py`](../src/noir/jaxrs_deployment.py) | source applications и ограниченные deployment prefixes из `web.xml` |
| [`noir/jaxrs_hierarchy.py`](../src/noir/jaxrs_hierarchy.py) | унаследованные resource bundles и рекурсивные subresource locators |
| [`noir/java_websocket.py`](../src/noir/java_websocket.py) | server handshakes Javax/Jakarta |

**Direct** означает, что route evidence интерпретируется на его concrete source
declaration с повторным использованием unit, уже находящегося в workspace.

**Supplemental surface** означает другой содержащий routes механизм помимо
direct annotation mappings: иерархия, functional-регистрация, Gateway,
resources, clients, deployment, subresources или messaging.

**Fail closed** означает, что unsupported или ambiguous candidate не добавляет
endpoint fact. Обычно analyzer записывает diagnostic на этой границе отклонения
и продолжает работу с независимыми candidates.

## 6. Границы analyzer

Framework analyzers импортируют constants, Java helpers, операции evidence и
recording diagnostics из владеющих ими модулей `noir`. Их public entry points
получают только semantic inputs, например source, compilation unit, workspace
или Spring path configuration.

Каждый endpoint producer напрямую возвращает `EndpointFact`. Локальная для
analyzer deduplication вызывает
[`deduplicate_endpoint_facts()`](../src/noir/evidence.py) с identity function
конкретной surface; общая операция детерминированно объединяет annotation
evidence и represented targets. Pipeline отклоняет любой result, не являющийся
`EndpointFact`, до построения `AnalysisResult`.

Эта граница сохраняет независимость extraction code от parsing CLI, stdout,
publication файлов и state executable launcher.

## 7. Словарь endpoint и evidence

`EndpointFact` сохраняет различия, которые public CSV представить не может:

- technology, protocol, surface и direction;
- request method, path, имя handler и parameters;
- владение public source;
- provenance route, handler и project/configuration;
- значения `AnnotationEvidence`;
- значения `SourceTarget`, представленные endpoint;
- неразрешённые Spring client path layers до применения project configuration.

**Represented target** — точная identity source declaration: canonical file,
kind declaration и byte span. Сохранившиеся targets используются для вычитания
представленных declarations из endpoint-trigger inventory.

**Row candidate** — первая public projection endpoint fact.
**Consolidated endpoint set** содержит детерминированно упорядоченные public rows
вместе с объединёнными represented targets, которые нужны reports.

~~~mermaid
flowchart LR
    F[EndpointFact] -->|однократная projection| C[EndpointRowCandidate]
    C -->|normalize + group| O[ConsolidatedEndpoints]
    O --> CSV[Семь полей CSV]
    O --> T[Represented targets]
~~~

Первые шесть полей CSV образуют identity строки. `method_annotation_line`
выбирается только после merge всего проверенного same-file annotation evidence
для этой identity.

## 8. Effects и владение artifacts

Используйте эти глаголы последовательно:

| Глагол | Значение |
|---|---|
| `record` | добавить diagnostic в collector текущего run |
| `render` | создать bytes или text, не меняя filesystem |
| `write` | сериализовать CSV или diagnostic log на владеющей ими границе |
| `publish` | атомарно заменить destination подготовленного byte-report |
| `announce` | вернуть стабильный text для вывода CLI |

[`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` владеет validation arguments,
naming output, projection, подготовкой reports, порядком publication и stdout.
Analyzers возвращают facts и записывают diagnostics; они не пишут artifacts.

Endpoint CSV и diagnostic log записываются напрямую. Byte reports атомарно
заменяются по отдельности. Поэтому полный набор artifacts не образует одну
filesystem transaction.

Framework announcements печатаются после analysis. Completion inventory из
`render_completion_summary()` выводится только после успешной publication
каждого запрошенного artifact.

## 9. Public-имена, которые остаются стабильными

- `src/noir_sbt.py` — executable path, напрямую делегирующий `noir.cli.main`.
- `--framework jaxrx` выбирает JAX-RS.
- Колонки CSV: `module_name`, `interface_type`, `endpoint`,
  `source_file_name`, `method_name`, `parameters` и
  `method_annotation_line`.
- Сопутствующий diagnostic artifact — `<output>.log`.
- Имя endpoint-trigger report заканчивается на `-anno-without-endpoints.log`.
- С `--noir-report` имя report сравнения по точному source location
  заканчивается на
  `-anno-without-noir-endpoints.log`.
- Установленные announcements `Found ...` и строка успешного завершения
  `noir-ts analysis completed.` остаются user-visible contracts.

Comparison report основан на occurrences. Несопоставленная распознанная
annotation сама по себе не доказывает, что Noir пропустил endpoint.

## 10. Практический маршрут чтения

Читайте текущий код в таком порядке:

1. [`src/noir_sbt.py`](../src/noir_sbt.py) — передача управления executable;
2. [`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` — user-visible транзакция;
3. [`noir/application.py`](../src/noir/application.py) :: `analyze()` —
   типизированная programmatic boundary;
4. [`noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` — точный
   порядок stages;
5. `SourceSnapshot` и
   [`build_java_workspace()`](../src/noir/java_workspace.py) — общие parse-once data;
6. [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) или
   [`noir/jaxrs.py`](../src/noir/jaxrs.py) — direct-семантика framework;
7. один supplemental analyzer — его ограниченная source surface;
8. [`noir/model.py`](../src/noir/model.py) :: `EndpointFact` и
   [`noir/evidence.py`](../src/noir/evidence.py) — контракт результата analyzer;
9. [`noir/output.py`](../src/noir/output.py),
   [`noir/reports.py`](../src/noir/reports.py) и
   [`noir/comparison.py`](../src/noir/comparison.py) — projection и artifacts.

Продолжите с [12 — Методы core runtime](12-core-runtime-methods.md) или
вернитесь к [оглавлению guide](README.md).
