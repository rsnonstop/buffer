# 11 — Словарь application logic и разобранные значения

[← Карта кода](10-code-map.md) · [Оглавление](README.md) ·
[Методы core runtime →](12-core-runtime-methods.md)

Эта справочная глава определяет термины, используемые текущей реализацией
application в `src/noir/`. Словарь прослеживает один run: от типизированного
request через общие Java facts и framework-анализ к public artifacts.

## 1. Предложение, описывающее application

> Проанализировать один `AnalysisRequest`: создать snapshot его Java sources,
> построить один общий workspace, сконфигурировать static adapters, построить
> inventories, подготовить каждое выбранное family, запустить его facade и
> вернуть immutable-значения `EndpointFact` и inventories в `AnalysisResult`.

Затем CLI выполняет projection и publication этого result:

~~~mermaid
flowchart LR
    R[AnalysisRequest] --> S[SourceSnapshot]
    S --> W[Workspace Java]
    W --> A[Сконфигурированные framework adapters]
    A --> I[Inventories]
    I --> P[Подготовленные facades выбранных families]
    P --> F[EndpointFact]
    F --> A[AnalysisResult]
    A --> C[EndpointRowCandidate]
    C --> O[CSV и сопутствующие reports]
~~~

Эти имена остаются различными, потому что несут разную информацию.
`EndpointFact` богаче строки CSV, а source snapshot — не parsed compilation unit.

## 2. Значения application

Immutable-словарь application находится в
[`noir/model.py`](../src/noir/model.py).

| Имя | Значение |
|---|---|
| `AnalysisRequest` | нормализованный root анализа и запрошенный default, auto, scalar-explicit или tuple-explicit framework mode |
| `FrameworkSelection` | одно нормализованное executable family: Spring, JAX-RS или Wicket |
| `FrameworkMode` | `None`, scalar `auto`, один explicit token или immutable tuple из нескольких explicit tokens |
| `FRAMEWORK_MODE_CHOICES` | все значения `FrameworkSelection` в enum order, после которых следует отдельная policy `auto` |
| `FrameworkPlan` | нормализованная запрошенная policy вместе с effective selection в порядке registry |
| `SourceFile` | типизированная identity source path |
| `SourceSpan` | точный полуоткрытый byte interval внутри одного source file |
| `SourceTarget` | kind декларации вместе с точным span, представленным endpoint |
| `AnnotationEvidence` | проверенный provenance method annotation из того же файла |
| `EndpointFact` | lossless output analyzer до public projection |
| `AnalysisDiagnostic` | presentation-neutral event, созданный во время analysis |
| `AnalysisResult` | immutable facts, inventories, данные framework decision, announcements и diagnostics |

[`noir/application.py`](../src/noir/application.py) :: `analyze()` —
programmatic boundary. Она принимает `AnalysisRequest`, запускает pipeline в
одном diagnostic scope и возвращает `AnalysisResult`. Она не выполняет parsing
arguments или artifact I/O.

CLI получает имя CSV module из basename input directory; это presentation value,
а не intent анализа application.

## 3. Словарь orchestration

[`noir/pipeline.py`](../src/noir/pipeline.py) владеет порядком source-to-result.
[`noir/frameworks.py`](../src/noir/frameworks.py) владеет static execution
composition, используемой этим порядком.

| Имя | Ответственность |
|---|---|
| `SourceSnapshot` | детерминированные source paths и точные bytes, единожды прочитанные для run |
| `FrameworkDecision` | фактический `FrameworkPlan`, обнаруженные markers и announcements |
| `FrameworkAdapter` | имя одного family и его selection identity, default policy, announcement и hooks configure/prepare/analyze |
| `FRAMEWORK_ADAPTERS` | зафиксированный execution order: Spring, JAX-RS, затем selectable, но не default Wicket stub |
| `_snapshot_sources()` | обнаружить Java files и захватить их bytes |
| `_select_frameworks()` | применить scalar/tuple explicit, default или marker-based selection и восстановить порядок registry |
| `_build_workspace()` | построить один parser runtime/workspace, затем сконфигурировать каждый adapter с его selected state |
| `analyze_spring_framework()` | запустить все Spring endpoint surfaces, затем применить project path configuration |
| `analyze_jaxrs_framework()` | после preparation JAX deployment запустить direct resources, hierarchy/subresources и Java WebSocket |
| `analyze_wicket_framework()` | выполнить seam выбранного Wicket и вернуть пустой tuple endpoints, пока не появится semantic support |
| `run_analysis()` | проверить dependencies; выполнить configure; построить inventories; подготовить все выбранные adapters; проанализировать их в порядке registry; обеспечить типизированные results и построить `AnalysisResult` |

**Pass** — шаг analyzer над общим workspace. Pass не выполняет discovery файлов
и не публикует artifacts.

Default framework mode выбирает Spring и JAX-RS в таком порядке. Одиночная
explicit option остаётся scalar request; повторяющиеся explicit options образуют
immutable tuple, effective selection которого восстанавливается в порядке
adapter registry. Duplicates и combinations, содержащие `auto`, невалидны.
`--framework auto` остаётся scalar policy, которая сканирует raw marker evidence
и может выбрать более узкий набор. `FRAMEWORK_MARKER_RULES` отдельно владеет
порядком findings и announcements `auto`. Explicit selection Wicket запускает
его no-op facade, но marker Wicket остаётся advisory, а его adapter исключён из
default. Извлечение endpoint'ов начинается только после построения inventories и
preparation каждого выбранного adapter, включая deployment model JAX-RS. Полный
путь добавления описан в
[16 — Добавление поддержки framework](16-adding-framework-support.md).

## 4. Общий Java-словарь

Java engine разделяет построение runtime, per-file parsing, cross-file resolution,
method flow и inheritance:

~~~mermaid
flowchart TB
    B[Bytes из snapshot] --> U[Compilation unit]
    U --> W[Index'ы workspace]
    W --> M[Method facts и index'ы]
    W --> H[Graph hierarchy]
    M --> X[Интерпретация framework]
    H --> X
~~~

- **Runtime** — проверенная language Tree-sitter, parser, queries и factory
  для query cursor; ими владеет
  [`noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py).
- **Java source input** — один выбранный path `.java` вместе с его bytes из
  snapshot. Application value `SourceFile` из раздела 2 обозначает только
  типизированную identity path.
- **Parsed tree** — только syntax tree Tree-sitter для этих bytes. Такое дерево
  ещё не содержит imports, identities types или route candidates Noir.
- **Compilation unit** — полное распарсенное и проиндексированное Noir-
  представление одного Java source file. Оно объединяет path, точные bytes,
  parsed tree, результаты queries, imports, lexical types, occurrences
  annotations и сгруппированные declaration candidates. Его строит
  [`noir/java_frontend.py`](../src/noir/java_frontend.py).
- **Parsed unit** — пояснительное сокращение для compilation unit; отдельного
  application type `ParsedUnit` нет. В Python argument с именем `unit` обычно
  содержит dictionary compilation unit. Он не означает весь project или Java
  package.
- **Workspace** — коллекция compilation units вместе с cross-file indexes
  types, imports, members, constants, annotations и framework declarations.
  Его строит [`noir/java_workspace.py`](../src/noir/java_workspace.py).
- **Method fact** и **method index** описывают ограниченные Java method bodies,
  formal parameters, invocations и lookup identity. Они находятся в
  [`noir/java_methods.py`](../src/noir/java_methods.py).
- **Hierarchy graph** описывает видимые в source types, supertypes, method
  signatures и selection implementation. Он находится в
  [`noir/java_hierarchy.py`](../src/noir/java_hierarchy.py).

Например, после parsing `/workspace/app/ItemsController.java` значения
`workspace["compilation_units"][path]` и `unit`, переданное в
`analyze_direct_spring_mvc_unit(unit, workspace)`, являются одним
Python-объектом:

~~~python
unit = {
    "source_path": "/workspace/app/ItemsController.java",
    "source": b"package app; class ItemsController { ... }",
    "tree": tree_sitter_tree,
    "package": "app",
    "imports": {"exact": {}, "wildcards": set(), ...},
    "type_infos": {(13, 62): {"simple_name": "ItemsController", ...}},
    ...,
}
workspace["compilation_units"][unit["source_path"]] is unit  # True
~~~

Имена `tree_sitter_tree` и `...` выше обозначают сохранённые parser objects и
пропущенные поля; полная shape показана ниже.

Глаголы resolver имеют стабильные значения:

| Префикс | Значение |
|---|---|
| `resolve_known_*` | доказать identity поддерживаемой library внутри одной compilation unit |
| `resolve_workspace_*` | пройти по видимым в source declarations или constants между units |
| `index_*` | получить повторно используемые lookup data |
| `select_*` | выбрать из доказанных candidates, обычно отклоняя ambiguity |
| `decode_*` | интерпретировать syntax value после установления его identity |
| `analyze_*` | выдать endpoint facts для одной определённой surface |

<a id="workspace-and-index-vocabulary"></a>

## Словарь workspace и index'ов

### Java names и declarations

Эти термины описывают evidence на уровне application, а не абстрактную
грамматику Java:

| Термин | Значение в Noir | Пример конкретного значения |
|---|---|---|
| **package name** | Namespace, объявленный одной compilation unit. Unnamed package представлен как `""`. | `"app.api"` из `package app.api;` |
| **simple type name** | Имя объявленного type без package и enclosing type. | `"ItemsController"` |
| **package type name** | Top-level simple name, существующий в package и потому способный заблокировать shortcut имени library. В `package_types` unit не входят её собственные top-level names: их уже покрывают facts lexical type этой unit. | `"Fast"` в `items_unit["package_types"] == {"Fast", "RestApplication"}` |
| **lexical display name** | Отображаемое в source имя type с enclosing types, но без package. Оно используется для owner-relative lookup и diagnostics. | `"Routes.Admin"` для member class `Admin` внутри `Routes` |
| **FQN** (fully qualified name) | Стабильная identity из package и lexical type, используемая между файлами. | `"app.api.Routes.Admin"` |
| **type declaration by FQN** | Одна source declaration record, сохранённая под её FQN. Bucket является list, потому что два файла могут объявить одинаковый FQN и должны остаться ambiguous. | `workspace["type_declarations"]["app.ItemsController"]` |
| **member declaration** | Evidence, что видимый в workspace source owner объявляет field, interface constant или enum constant с данным именем. Evidence сохраняется, даже если из declaration нельзя получить подходящее String value: само присутствие имени может остановить lookup на этом Java tier. Methods в этом index не хранятся. | `("routes.Paths", "ROOT")` |
| **static member declaration** | Member-declaration record, для которой дополнительно доказан static в поддерживаемой lookup model; она включает access facts для обнаружения collisions static wildcard. Constants interface и enum считаются static. Methods здесь не хранятся. | `workspace["static_member_declarations"][("routes.Paths", "ROOT")]` |
| **source annotation declaration** | Java `@interface`, видимый в workspace и объявленный в анализируемом source, в отличие от применённой annotation occurrence или annotation, доступной только из dependency. | declaration `public @interface Fast {}` с FQN `"app.Fast"` |
| **annotation occurrence** | Одно применение annotation к declaration или parameter. | `@Fast` на `ItemsResource.list()` |
| **annotation definition** | Source annotation declaration с neutral syntax facts: meta-annotations, elements, types, defaults и element annotations. Framework analyzers интерпретируют эти facts, не копируя их. | `workspace["annotation_definitions"]["app.Fast"][0]` |

Фраза **status member declaration** не является application term или Python-
полем. Если она встречается в prompt, её следует читать как **static member
declaration**.

<a id="name-spelling-qualification-and-shadowing"></a>

### Написание names, qualification и shadowing

**Spelling at a syntax node** — точный текст имени, записанный в одном месте
source. Для одной и той же identity Spring annotation это может быть
`GetMapping` или
`org.springframework.web.bind.annotation.GetMapping`. Syntax node важен,
поскольку imports и видимые lexical declarations могут различаться в разных
местах.

**Unqualified** spelling type или member содержит только искомое имя, например
`GetMapping` или `ROOT`. **Qualified** spelling указывает owner или namespace,
например `RetentionPolicy.RUNTIME` или
`org.springframework.web.bind.annotation.GetMapping`. **Fully qualified**
spelling type указывает полные package и type name. Resolver известных libraries
принимает dotted spelling annotation/type только тогда, когда это точный
поддерживаемый FQN; он не угадывает частично qualified identities libraries.

**Shadowing** означает, что имя, объявленное в более сильном Java lookup scope,
владеет spelling, поэтому одноимённый import или поддерживаемый library type
использовать нельзя. Например:

~~~java
package app;

import org.springframework.web.bind.annotation.*;

class ItemsController {
    @interface GetMapping {
        String value();
    }

    @GetMapping("/items")
    void list() {}
}
~~~

В syntax node `@GetMapping` видимая member annotation
`ItemsController.GetMapping` shadows имя Spring, импортированное wildcard.
Поэтому Noir не классифицирует эту occurrence как `GetMapping` Spring. Он также
не переходит к wildcard import лишь потому, что local declaration непригодна
для желаемой framework-интерпретации.

### Что такое index

**Index** — это analysis-local lookup data, полученные из immutable source
snapshot. Они отвечают на повторяющийся application-вопрос, например «какие
source types имеют этот FQN?» или «какие handler bodies имеют заданные owner и
name?». Это не database, не file offset и не обязательно Python `dict`: set,
list, dataclass или graph тоже могут быть index, если это полезная lookup shape.

Большинство declaration indexes отображают semantic key в **candidate bucket**.
Bucket намеренно сохраняет все declarations. Consumers, которым нужна одна
identity, проверяют, что сохранился ровно один accessible candidate; insertion
order никогда молча не выбирает winner.

Названные в guide семейства semantic indexes каталогизированы ниже как core
workspace indexes, framework-attached indexes и derived method/hierarchy
indexes. Переменная вроде `statement_index`, которая содержит только позицию в
list, не является workspace index.

В примерах structures ниже используются следующие sources:

~~~java
// /workspace/routes/Paths.java
package routes;

public final class Paths {
    public static final String ROOT = "/api";
    public static int MODE = 1;
}
~~~

~~~java
// /workspace/app/Fast.java
package app;

import jakarta.ws.rs.HttpMethod;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Retention(RUNTIME)
@HttpMethod("FAST")
public @interface Fast {}
~~~

~~~java
// /workspace/app/ItemsController.java
package app;

import static routes.Paths.ROOT;
import org.springframework.web.bind.annotation.GetMapping;

class ItemsController {
    @GetMapping(ROOT + "/items")
    public String list(String filter) { return filter; }
}
~~~

~~~java
// /workspace/app/RestApplication.java
package app;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/rest")
public class RestApplication extends Application {}
~~~

### Основные index'ы workspace

[`build_java_workspace()`](../src/noir/java_workspace.py) создаёт следующие
стабильные neutral lookup views. Entries, помеченные «per unit», находятся
внутри каждого value `workspace["compilation_units"]`.

| Index или lookup view | Структура «ключ → значение» | На какой application-вопрос отвечает |
|---|---|---|
| `runtime` | language, parser, compiled query map и cursor factory | Какие validated parser objects и полный neutral query set владеют этими units? |
| `compilation_units` | string source path → dictionary compilation unit | Какой именно parsed source object принадлежит этому path? |
| `matches` (per unit) | query name → полные query matches Tree-sitter | Какие raw syntax associations захвачены в этом файле? |
| `type_infos` (per unit) | `(start_byte, end_byte)` → record lexical type | Какой source type владеет этим node и видим ли он в workspace? |
| `imports` (per unit) | четыре views: `exact`, `wildcards`, `static_exact`, `static_wildcards` | Какой Java lookup tier может использовать spelling из source? |
| declaration candidates (per unit) | key byte range declaration → полные capture dictionaries | Какие annotations принадлежат этому type, method, record component, annotation definition или annotation element? Поля: `type_candidates`, `method_candidates`, `record_component_candidates`, `meta_candidates` и `element_candidates`. |
| `package_types` (per unit) | set остальных top-level simple names в том же package | Блокирует ли same-package source type ожидаемый external type? |
| `wildcard_source_types` (per unit) | simple name → set импортированных source FQN | Может ли wildcard source import конфликтовать с известным library candidate? |
| `type_declarations` | FQN → list `{fqn, unit, type_info}` | Существует ли ровно один accessible source type с этой identity? |
| `member_declarations` | `(owner FQN, member name)` → set IDs declarations | Объявляет ли этот owner имя, даже если из него нельзя прочитать route String? |
| `static_member_declarations` | `(owner FQN, member name)` → list records declaration/access | Может ли другой static wildcard owner сделать unqualified member ambiguous? |
| `constants_by_owner_member` | `(owner FQN, member name)` → list records String initializer | Какие source String declarations являются candidates для bounded value resolution? |
| `annotation_definitions` | annotation FQN → list neutral definition records, содержащих identity declaration, direct meta-annotations и структуру declared elements | Какую объявленную в project annotation identity может обозначать применённая annotation и какую source structure может доказать framework? |

`workspace_constant_records` — records String candidates этой же unit в source
order. `workspace_member_declarations` и
`workspace_static_member_declarations` — references на соответствующие
workspace-wide views, присоединённые к каждой unit для resolvers, которые
получают unit напрямую.

Ниже приведён сокращённый, но структурно точный result для этих source-примеров.
`paths_unit`, `fast_unit` и значения `*_node` являются ссылками на реальные
compilation units и Tree-sitter objects, сохранённые в workspace:

~~~python
workspace = {
    "compilation_units": {
        "/workspace/routes/Paths.java": paths_unit,
        "/workspace/app/Fast.java": fast_unit,
        "/workspace/app/ItemsController.java": items_unit,
        "/workspace/app/RestApplication.java": application_unit,
    },
    "type_declarations": {
        "routes.Paths": [
            {"fqn": "routes.Paths", "unit": paths_unit, "type_info": paths_info}
        ],
        "app.Fast": [
            {"fqn": "app.Fast", "unit": fast_unit, "type_info": fast_info}
        ],
        "app.ItemsController": [
            {
                "fqn": "app.ItemsController",
                "unit": items_unit,
                "type_info": items_info,
            }
        ],
        ...,
    },
    "member_declarations": {
        ("routes.Paths", "ROOT"): {
            ("/workspace/routes/Paths.java", field_start, field_end, name_start)
        },
        ("routes.Paths", "MODE"): {
            ("/workspace/routes/Paths.java", mode_start, mode_end, mode_name_start)
        },
    },
    "static_member_declarations": {
        ("routes.Paths", "ROOT"): [
            {
                "owner_fqn": "routes.Paths",
                "unit": paths_unit,
                "static": True,
                "public": True,
                ...,
            }
        ],
        ("routes.Paths", "MODE"): [{...}],
    },
    "constants_by_owner_member": {
        ("routes.Paths", "ROOT"): [
            {
                "name": "ROOT",
                "owner_fqn": "routes.Paths",
                "value_node": root_literal_node,
                "final_constant": True,
                "static_final": True,
                ...,
            }
        ]
    },
    "annotation_definitions": {
        "app.Fast": [
            {
                "fqn": "app.Fast",
                "simple_name": "Fast",
                "unit": fast_unit,
                "type_info": fast_info,
                "meta_annotations": [
                    {"node": retention_node, "name_node": retention_name_node},
                    {"node": http_method_node, "name_node": http_method_name_node},
                ],
                "elements": {},
            }
        ]
    },
    ...,
}

items_unit["package_types"] == {"Fast", "RestApplication"}
~~~

`MODE` присутствует в declaration indexes, где может shadow другое `MODE`, но
не в `constants_by_owner_member`: его declared type не соответствует
поддерживаемой shape value `java.lang.String`. Если бы второй файл объявлял
`routes.Paths`, соответствующий bucket `type_declarations` содержал бы две
records, а resolution, зависящий от этой identity, сработал бы fail closed.

### Framework-specific indexes и models

После создания neutral indexes pipeline и analyzers добавляют в тот же workspace
следующие semantic views. Spring напрямую потребляет `annotation_definitions`,
а не поддерживает собственную Spring-копию.

| Index или model | Структура | Значение |
|---|---|---|
| `jax_rs_custom_designator_candidates` | set annotation FQN | Source annotations с релевантным evidence `@HttpMethod`, включая invalid. Сохранение invalid candidates не позволяет применённому сломанному designator выглядеть нерелевантным. |
| `jax_rs_custom_designators` | annotation FQN → list valid designator records | Доказанные runtime custom request methods, включая HTTP token и namespace Javax/Jakarta. |
| `jax_rs_applications` | list application records | Concrete direct subclasses `Application` с namespace, package, source identity и resolved path либо `None`. List сохраняет disagreement и unresolved paths для prefix selection. |
| `jax_rs_deployment_model` | dictionary с `deployment_prefixes`, `applications_by_class_name` и explicit descriptor keys | Evidence deployment prefix по project/package/family, общее для direct- и hierarchy-анализа JAX-RS; key из descriptor может использовать `None`, если family Javax/Jakarta не установлена. |

Для declarations `Fast` и `RestApplication` выше JAX-RS views имеют примерно
такие values:

~~~python
workspace["jax_rs_custom_designator_candidates"] == {"app.Fast"}

workspace["jax_rs_custom_designators"] == {
    "app.Fast": [
        {
            "fqn": "app.Fast",
            "simple_name": "Fast",
            "namespace": "jakarta.ws.rs",
            "method": "FAST",
            "source_path": "/workspace/app/Fast.java",
        }
    ]
}

workspace["jax_rs_applications"] == [
    {
        "namespace": "jakarta.ws.rs",
        "package": "app",
        "path": "/rest",
        "source_path": "/workspace/app/RestApplication.java",
        "simple_name": "RestApplication",
        "fqn": "app.RestApplication",
    }
]

workspace["jax_rs_deployment_model"] = {
    "analysis_root": "/workspace",
    "deployment_prefixes": {
        ("/workspace", "app", "jakarta.ws.rs"): "/rest"
    },
    "applications_by_class_name": {
        "RestApplication": (("/workspace", "app", "jakarta.ws.rs"),),
        "app.RestApplication": (("/workspace", "app", "jakarta.ws.rs"),),
    },
    "xml_configured_application_keys": set(),
}
~~~

Когда JAX-RS не выбран, его attacher устанавливает те же keys candidates,
designators и applications с пустыми values. Поэтому consumer может читать
стабильную shape, не интерпретируя отсутствующий key как application evidence.

### Производные method- и hierarchy-index'ы

Некоторые views создаются только теми passes, которым они нужны, а не
присоединяются как общие workspace keys:

| Представление | Структура | Значение |
|---|---|---|
| `MethodIndex` | упорядоченный tuple `methods` плюс `(owner FQN, method name)` → tuple overloads | Исполняемые source methods, принятые strict-parameter или varargs-parameter policy. |
| `JavaSourceHierarchyGraph.types` | unique FQN → `JavaTypeRecord` | Доступные для traversal source classes, interfaces и records с edges и methods. Duplicate FQN исключаются из map, а не выбираются. |
| hierarchy signature cache | provenance method плюс adapted generic environment → erased signature либо `None` | Повторно использует уже доказанную override identity для того же generic state. Является внутренним для одного graph. |
| JAX-RS effective-method cache | resource FQN, generic environment и namespace → list выбранных `JaxRsEffectiveMethod` | Повторно использует bindings concrete implementation к annotation bundle во время traversal locators. Является внутренним для одного analyzer. |

Inventory не является одним из этих resolver indexes. Это application result,
который записывает распознанные occurrences annotations для reporting; он не
выбирает Java type, member или handler identity.

<a id="java-data-structures-by-module"></a>

## Структуры данных Java по модулям

Примеры этого раздела — Python-shaped views реальных application objects.
Имена с окончаниями `_node`, `_tree` или `_unit` обозначают живые сохранённые
objects Tree-sitter или compilation unit, а не strings, восстановленные из
source.

### `noir.java_frontend`

Основная data structure — dictionary compilation unit, возвращаемая
`build_java_compilation_unit()`. Сначала она содержит per-file facts; позднее
workspace construction присоединяет references package-collision и member
indexes:

~~~python
items_unit = {
    # identity and parser lifetime
    "source_path": "/workspace/app/ItemsController.java",
    "source": b"package app; ...",
    "tree": items_tree,
    "lifetime_owners": [items_tree, (type_query_cursor, type_query_matches), ...],

    # raw query products
    "matches": {
        "package": [...],
        "import": [...],
        "type": [...],
        "method_annotation": [...],
        ...,
    },

    # same-file name facts
    "package": "app",
    "imports": {
        "exact": {
            "GetMapping": "org.springframework.web.bind.annotation.GetMapping"
        },
        "wildcards": set(),
        "static_exact": {"ROOT": "routes.Paths.ROOT"},
        "static_wildcards": set(),
    },
    "type_infos": {
        items_type_key: {
            "node": items_type_node,
            "simple_name": "ItemsController",
            "display_name": "ItemsController",
            "outer_key": None,
            "abstract": False,
            "workspace_visible": True,
            "mapping": None,
        }
    },
    "local_types": {"ItemsController"},
    "local_annotations": set(),
    "annotation_occurrences": [
        {"node": get_mapping_node, "name_node": get_mapping_name_node}
    ],

    # complete query matches grouped by their owning declaration
    "type_candidates": {items_type_key: [...]},
    "method_candidates": {list_method_key: [...]},
    "record_component_candidates": {},
    "record_explicit_accessors": set(),
    "meta_candidates": {},
    "element_candidates": {},

    # attached by java_workspace after every unit exists
    "package_types": {"Fast", "RestApplication"},
    "wildcard_source_types": {},
    "workspace_constant_records": [],
    "workspace_member_declarations": workspace_member_declarations,
    "workspace_static_member_declarations": workspace_static_declarations,
}
~~~

Например, одна entry в `items_unit["matches"]["type"]` имеет shape
`(pattern_index, {"type.node": [items_type_node], "type.name":
[items_type_name_node]})`. Candidate groupings сохраняют эти полные capture
dictionaries, чтобы nodes из разных query matches никогда случайно не
объединялись.

Keys byte range вроде `items_type_key` имеют вид `(start_byte, end_byte)` и
уникальны только внутри этой unit. Полная record несёт свою unit всякий раз,
когда попадает в cross-file index.

### `noir.java_ast`

`java_ast` намеренно не определяет второй AST или wrapper class. Его data — это
compilation unit и живые objects `Node` Tree-sitter. Помимо прочих parser
attributes, node предоставляет `type`, `start_byte`, `end_byte`, `parent`,
`children` и `named_children`. Helpers задают ограниченные вопросы к этой уже
существующей structure:

~~~python
name_node = java_ast.field(list_method_node, "name")
java_ast.source_text(items_unit, name_node)             # "list"
list(java_ast.walk_named(list_method_node))             # source-order subtree
java_ast.raw_type_node(list_return_type_node)            # unwrapped raw type node
java_ast.known_type(items_unit, string_node, "String", "java.lang")  # True
java_ast.is_direct_invocation_statement(route_call_node, body_node)   # True/False
~~~

Последний call отличает fluent route call, являющийся direct statement в body
handler/configuration, от call, вложенного в return, assignment, lambda или
несвязанное expression.

### `noir.java_methods`

Этот module превращает syntax methods в три application structures:

| Структура | Содержимое на уровне application |
|---|---|
| `FormalParameter` | Имя input handler, syntax type, полный syntax declaration и признак принятой varargs form |
| `MethodFact` | Один исполняемый source handler с его unit/type owner, nodes name, return/input/body, нормализованными formal inputs и modifiers |
| `MethodIndex` | Все принятые handlers в deterministic source order плюс buckets overloads по owner/name |

Для source method `public String list(String filter) { ... }` пример index
выглядит так:

~~~python
filter_parameter = FormalParameter(
    name="filter",
    type_node=string_type_node,
    node=filter_parameter_node,
    varargs=False,
)

list_method = MethodFact(
    unit=items_unit,
    owner_info=items_info,
    owner_fqn="app.ItemsController",
    node=list_method_node,
    name_node=list_name_node,
    return_type_node=string_return_type_node,
    parameters_node=list_parameters_node,
    body_node=list_body_node,
    parameters=(filter_parameter,),
    modifiers=frozenset({"public"}),
)

method_index = MethodIndex(
    methods=(list_method,),
    by_owner_name={
        ("app.ItemsController", "list"): (list_method,)
    },
)
~~~

Bucket содержит все принятые overloads. DSL recognizer применяет собственные
rules arguments и types после lookup; сам index не вызывает method и не решает,
что он определяет endpoint.

### `noir.java_hierarchy`

Neutral hierarchy представляет types до добавления framework meaning:

| Структура | Содержимое на уровне application |
|---|---|
| `JavaTypeReference` | Declared type, type variable, primitive или erasure-only reference; optional generic arguments и dimensions array |
| `JavaMethodRecord` | Owner одного source method, source identity, annotations, modifiers, parsed references parameters/result и bounds method-generic |
| `JavaTypeRecord` | Один unique traversable class/interface/record с direct methods, superclass, interfaces и bounds type variables |
| `JavaHierarchyContext` | Одна adapted class chain, reachable interface roots и proof flag `complete` для выбранного concrete type |
| `JavaSourceHierarchyGraph` | Workspace плюс `types` по FQN и его environment-sensitive signature cache |

Для source:

~~~java
package app;

record Item(String id) {}

interface ItemsApi<T> {
    T find(String id);
}

final class ItemsResource implements ItemsApi<Item> {
    public Item find(String id) { return null; }
}
~~~

Основные records имеют следующую shape:

~~~python
item_ref = JavaTypeReference("decl", "app.Item")
string_ref = JavaTypeReference("decl", "java.lang.String")
api_edge = JavaTypeReference("decl", "app.ItemsApi", (item_ref,))

api_record = JavaTypeRecord(
    fqn="app.ItemsApi",
    unit=api_unit,
    type_info=api_info,
    kind="interface_declaration",
    type_parameters=("T",),
    methods=[api_find_method],
    interfaces=(),
)

resource_record = JavaTypeRecord(
    fqn="app.ItemsResource",
    unit=resource_unit,
    type_info=resource_info,
    kind="class_declaration",
    type_parameters=(),
    methods=[resource_find_method],
    interfaces=(api_edge,),
    interfaces_valid=True,
)

graph.types == {
    "app.ItemsApi": api_record,
    "app.ItemsResource": resource_record,
    ...,
}

context = JavaHierarchyContext(
    class_states=[(resource_record, {})],
    interface_roots=[(api_record, {"T": item_ref})],
    complete=True,
)
~~~

`JavaMethodRecord.parameter_refs` для обеих declarations `find` содержит
`string_ref`. После adaptation `T` к `app.Item` их erased override signature —
`("find", ("java.lang.String",))`. Graph сообщает `complete=False`, а не
выполняет inference через unresolved edge, cycle, generic conflict или proof
bound.

### `noir.jaxrs_hierarchy`

`JaxRsHierarchyAnalyzer` наследует neutral graph, поэтому сохраняет те же
records `types` и добавляет binding state JAX-RS:

| Структура | Содержимое на уровне application |
|---|---|
| `JaxRsEffectiveMethod` | Concrete implementation, её generic environment, method-источник неделимого annotation bundle JAX-RS, decoded binding leaf/locator, признак добавления hierarchy и erased signature |
| `SubresourceTypeState` | FQN concrete return type плюс adapted generic environment, используемые как branch-local identity cycle locator |
| `_effective_cache` | Уже выбранные effective methods по resource, generic environment и namespace Javax/Jakarta |

Унаследованный interface contract `@GET @Path("/items/{id}")`, связанный с
`ItemsResource.find`, приблизительно представлен так:

~~~python
effective = JaxRsEffectiveMethod(
    implementation=resource_find_method,
    implementation_env={},
    annotation_source=api_find_method,
    binding={
        "kind": "leaf",
        "path": "/items/{id}",
        "method": "GET",
        "evidence_node": get_annotation_node,
        "annotation_identity": "jakarta.ws.rs.GET",
        "annotation_family": "jax-rs-designator",
    },
    hierarchy_added=True,
    signature=("find", ("java.lang.String",)),
)

state = SubresourceTypeState(
    record_fqn="app.ItemSubresource",
    env_key=(("T", JavaTypeReference("decl", "app.Item")),),
)
~~~

Effective record ещё не является endpoint. Analyzer должен также доказать
resource root, path layer interface, deployment prefix и любой locator path, а
затем построить `EndpointFact`. Полный пример hierarchy JAX-RS приведён в
[разделе 9 главы 06 — binding hierarchy](06-jax-rs.md#9-hierarchy-binding).

### Термины механизмов analyzer'а

| Термин | Значение | Короткий пример |
|---|---|---|
| **workspace index** | Один из общих lookup views выше, полученный один раз и повторно используемый несколькими framework passes. | Разрешить `ROOT` через `constants_by_owner_member[("routes.Paths", "ROOT")]`. |
| **direct decoder** | Интерпретирует route evidence, физически прикреплённое к concrete type, method или record component в одной compilation unit. Может использовать workspace resolution, но не выводит inherited route и не отслеживает configuration DSL. | Декодировать `@GetMapping("/items")` на `ItemsController.list`. |
| **hierarchy graph** | Связи source types и methods, используемые для доказательства inherited contract и выбора его concrete implementation. | Связать interface `ItemsApi.find` с class method `ItemsResource.find`. |
| **functional/DSL recognizer** | Следует по ограниченной, явно моделируемой invocation shape в source method bodies. Распознаёт API calls и aliases, но не исполняет произвольный Java. | Распознать `RouterFunctions.route(GET("/items"), handler::list)` или поддерживаемую Gateway route chain. |

## 5. Словарь framework

Название технологии в коде и прозе — **JAX-RS**. Public selector CLI остаётся
`jaxrx`.

### Владельцы Spring

| Модуль | Surface |
|---|---|
| [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) | direct MVC mappings, composed annotations, records и mapping indexes |
| [`noir/spring_route_registrations.py`](../src/noir/spring_route_registrations.py) | functional routes и programmatic MVC registrations |
| [`noir/spring_mvc_hierarchy.py`](../src/noir/spring_mvc_hierarchy.py) | унаследованные mapping contracts, связанные с concrete controllers |
| [`noir/spring_gateway.py`](../src/noir/spring_gateway.py) | routes Java DSL Spring Cloud Gateway |
| [`noir/spring_config.py`](../src/noir/spring_config.py) | project path configuration и static resource handlers |
| [`noir/spring_clients.py`](../src/noir/spring_clients.py) | outbound contracts HTTP Interface и OpenFeign |
| [`noir/spring_websocket_messaging.py`](../src/noir/spring_websocket_messaging.py) | raw/STOMP handshakes и message destinations |

### Владельцы JAX-RS и WebSocket

| Модуль | Surface |
|---|---|
| [`noir/jaxrs.py`](../src/noir/jaxrs.py) | direct resources, custom request methods, records и application paths |
| [`noir/jaxrs_deployment.py`](../src/noir/jaxrs_deployment.py) | source applications и ограниченные deployment prefixes из `web.xml` |
| [`noir/jaxrs_hierarchy.py`](../src/noir/jaxrs_hierarchy.py) | унаследованные resource bundles и рекурсивные subresource locators |
| [`noir/java_websocket.py`](../src/noir/java_websocket.py) | server handshakes Javax/Jakarta |

**Direct** означает, что route evidence интерпретируется на его concrete source
declaration с повторным использованием unit, уже находящегося в workspace.

**Direct Spring MVC** — это per-compilation-unit pass, который объединяет
mapping annotations, физически присутствующие на lexical types, с mapping на
concrete method или подходящем record component. Слово «direct» противопоставляет
его inherited contract interface/superclass и route, выраженному calls в DSL
method body; оно не означает особый вид HTTP connection.

~~~java
@RequestMapping("/api")
class ItemsController {
    @GetMapping("/items")
    Item list(String filter) { return null; }
}
~~~

Из этой unit pass direct Spring MVC может выдать `GET /api/items` с handler
`ItemsController.list` и spelling parameter `String filter`. Hierarchy analysis
не требуется, потому что оба path layers и concrete handler присутствуют на
этих declarations.

**Supplemental surface** означает другой содержащий routes механизм помимо
direct annotation mappings: иерархия, functional-регистрация, Gateway,
resources, clients, deployment, subresources или messaging.

**Fail closed** означает, что unsupported или ambiguous candidate не добавляет
endpoint fact. Обычно analyzer записывает diagnostic на этой границе отклонения
и продолжает работу с независимыми candidates.

## 6. Границы analyzer

Framework analyzers импортируют constants, Java helpers, операции evidence и
recording diagnostics из владеющих ими модулей `noir`. Их public entry points
получают только semantic inputs, например source, compilation unit, workspace
или Spring path configuration.

Каждый endpoint producer напрямую возвращает `EndpointFact`. Локальная для
analyzer deduplication вызывает
[`deduplicate_endpoint_facts()`](../src/noir/evidence.py) с identity function
конкретной surface; общая операция детерминированно объединяет annotation
evidence и represented targets. Pipeline отклоняет любой result, не являющийся
`EndpointFact`, до построения `AnalysisResult`.

Эта граница сохраняет независимость extraction code от parsing CLI, stdout,
publication файлов и state executable launcher.

## 7. Словарь endpoint и evidence

`EndpointFact` сохраняет различия, которые public CSV представить не может:

- technology, protocol, surface и direction;
- request method, path, имя handler и parameters;
- владение public source;
- provenance route, handler и project/configuration;
- значения `AnnotationEvidence`;
- значения `SourceTarget`, представленные endpoint;
- неразрешённые Spring client path layers до применения project configuration.

**Represented target** — точная identity source declaration: canonical file,
kind declaration и byte span. Сохранившиеся targets используются для вычитания
представленных declarations из endpoint-trigger inventory.

**Row candidate** — первая public projection endpoint fact.
**Consolidated endpoint set** содержит детерминированно упорядоченные public rows
вместе с объединёнными represented targets, которые нужны reports.

~~~mermaid
flowchart LR
    F[EndpointFact] -->|однократная projection| C[EndpointRowCandidate]
    C -->|normalize + group| O[ConsolidatedEndpoints]
    O --> CSV[Семь полей CSV]
    O --> T[Represented targets]
~~~

Первые шесть полей CSV образуют identity строки. `method_annotation_line`
выбирается только после merge всего проверенного same-file annotation evidence
для этой identity.

## 8. Effects и владение artifacts

Используйте эти глаголы последовательно:

| Глагол | Значение |
|---|---|
| `record` | добавить diagnostic в collector текущего run |
| `render` | создать bytes или text, не меняя filesystem |
| `write` | сериализовать CSV или diagnostic log на владеющей ими границе |
| `publish` | атомарно заменить destination подготовленного byte-report |
| `announce` | вернуть стабильный text для вывода CLI |

[`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` отвечает за validation
аргументов, naming output, projection, подготовку reports, порядок publication
и stdout.
Analyzers возвращают facts и записывают diagnostics; они не пишут artifacts.

Endpoint CSV и diagnostic log записываются напрямую. Byte reports атомарно
заменяются по отдельности. Поэтому полный набор artifacts не образует одну
filesystem transaction.

Framework announcements печатаются после analysis. Completion inventory из
`render_completion_summary()` выводится только после успешной publication
каждого запрошенного artifact.

## 9. Public-имена, которые остаются стабильными

- `src/noir_sbt.py` — executable path, напрямую делегирующий `noir.cli.main`.
- `--framework jaxrx` выбирает JAX-RS.
- Повторение `--framework` выбирает несколько explicit families; порядок
  execution и presentation остаётся static adapter order.
- Колонки CSV: `module_name`, `interface_type`, `endpoint`,
  `source_file_name`, `method_name`, `parameters` и
  `method_annotation_line`.
- Сопутствующий diagnostic artifact — `<output>.log`.
- Имя endpoint-trigger report заканчивается на `-anno-without-endpoints.log`.
- С `--noir-report` имя report сравнения по точному source location
  заканчивается на
  `-anno-without-noir-endpoints.log`.
- Установленные announcements `Found ...` и строка успешного завершения
  `noir-ts analysis completed.` остаются user-visible contracts.

Comparison report основан на occurrences и учитывает только потенциальные
endpoint-trigger'ы из final-trigger inventory. Supporting annotations остаются в
broad diagnostic companion, но исключаются из сравнения. Несопоставленный
trigger сам по себе не доказывает, что Noir пропустил reachable endpoint.

## 10. Практический маршрут чтения

Читайте текущий код в таком порядке:

1. [`src/noir_sbt.py`](../src/noir_sbt.py) — передача управления executable;
2. [`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` — user-visible транзакция;
3. [`noir/application.py`](../src/noir/application.py) :: `analyze()` —
   типизированная programmatic boundary;
4. [`noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` — точный
   порядок stages;
5. `SourceSnapshot` и
   [`build_java_workspace()`](../src/noir/java_workspace.py) — общие parse-once data;
6. [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) или
   [`noir/jaxrs.py`](../src/noir/jaxrs.py) — direct-семантика framework;
7. один supplemental analyzer — его ограниченная source surface;
8. [`noir/model.py`](../src/noir/model.py) :: `EndpointFact` и
   [`noir/evidence.py`](../src/noir/evidence.py) — контракт результата analyzer;
9. [`noir/output.py`](../src/noir/output.py),
   [`noir/reports.py`](../src/noir/reports.py) и
   [`noir/comparison.py`](../src/noir/comparison.py) — projection и artifacts.

Продолжите с [12 — Методы core runtime](12-core-runtime-methods.md) или
вернитесь к [оглавлению guide](README.md).
