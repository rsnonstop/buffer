# 05 — Spring за пределами аннотированного MVC

[← Spring MVC](04-spring-mvc.md) · [Оглавление](README.md) · [Далее: JAX-RS →](06-jax-rs.md)

Ветка Spring — упорядоченный набор ограниченных source analyzers. Прямой MVC,
регистрации functional routes, contracts иерархии, Gateway, статические
resources, исходящие clients, handshake'и WebSocket и message destinations потребляют один
и тот же parse-once Java workspace. Каждый успешный producer возвращает
неизменяемые значения [`EndpointFact`](../src/noir/model.py); projection в CSV
выполняется позже.

Дополнение на уровне методов: [13 — Методы Spring](13-spring-methods.md)
прослеживает каждый дополнительный entry point через его private decoders с
множеством ветвлений.

```mermaid
flowchart TB
    Snapshot["SourceSnapshot: paths + точные bytes"] --> Workspace["java_workspace: один parsed unit для каждого source"]
    Workspace --> Direct["прямой Spring MVC"]
    Direct --> Registrations["functional + registerMapping"]
    Registrations --> Hierarchy["MVC hierarchy"]
    Hierarchy --> Gateway["Gateway"]
    Gateway --> Resources["resource handlers"]
    Resources --> Clients["HTTP clients"]
    Clients --> BuildConfig["конфигурация project path"]
    BuildConfig --> Messaging["WebSocket + messaging"]
    Messaging --> Apply["однократно применить configuration"]
    Apply --> Result["AnalysisResult.endpoints"]
```

## 1. Владение и контракт pass

[`noir.pipeline._analyze_spring`](../src/noir/pipeline.py) задаёт следующий
порядок:

1. [`analyze_direct_spring_mvc_unit`](../src/noir/spring_mvc.py) для каждого
   compilation unit из snapshot;
2. [`analyze_spring_route_registrations`](../src/noir/spring_route_registrations.py);
3. [`analyze_spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py);
4. [`analyze_spring_gateway`](../src/noir/spring_gateway.py);
5. [`analyze_spring_resource_handlers`](../src/noir/spring_config.py);
6. [`analyze_spring_http_clients`](../src/noir/spring_clients.py);
7. [`build_spring_path_configuration`](../src/noir/spring_config.py);
8. [`analyze_spring_websocket_and_messaging`](../src/noir/spring_websocket_messaging.py);
9. [`apply_spring_path_configuration`](../src/noir/spring_config.py).

Analyzers импортируют syntax, name resolution, evidence и diagnostic helpers
из владеющих ими packages. Они не находят функции через namespace модуля, не
создают ещё один parser, не проецируют CSV rows и не записывают artifacts.

Важные классификации `EndpointFact`:

| Surface | Protocol / surface / direction | Публичный `interface_type` | Source attribution |
|---|---|---|---|
| functional `RouterFunction` | `http` / `server` / inbound | `http <verb>` | точный handler, иначе publisher |
| `registerMapping` | `http` / `server` / inbound | `http <verb>` | отражённый source handler |
| Spring Cloud Gateway | `http` / `gateway` / inbound | `http-gateway <verb>` | publisher route |
| MVC resource handler | `http` / `static-handler` / inbound | `http-static-handler GET` | метод configurer |
| HTTP Interface / Feign | `http` / `client` / outbound | `http-client <verb>` | метод contract |
| WebSocket handshake | `ws` / `websocket-handshake` / inbound | `ws GET` | метод registration |
| message mapping | `ws` / `message` / inbound | `ws SEND` или `ws SUBSCRIBE` | аннотированный handler |

Provenance route, handler и project остаются отдельными полями.
Типизированные `annotation_evidence` и `represented_targets` переживают
локальную deduplication и configuration, чтобы output и companion reports
могли принимать независимые решения.

## 2. Functional routes

[`spring_route_registrations.py`](../src/noir/spring_route_registrations.py)
моделирует ограниченный язык servlet/WebFlux router поверх общего method index.

### 2.1 Доказательство publisher

Functional publisher должен быть методом одного уникального, видимого,
конкретного source class и иметь:

- ровно один настоящий прямой Spring `@Bean`;
- однозначно разрешённый return type servlet или WebFlux `RouterFunction`;
- ровно один прямой top-level `return`; и
- возвращаемое expression из поддерживаемой router grammar.

Вложенные returns, несколько return paths, поддельные аннотации или types,
неоднозначные imports и дублирующиеся source owners отвергают такой publisher.

Поддерживаются прямые predicate routes, chains `andRoute`, builder calls с
фиксированным verb и ограниченные блоки `nest`:

```java
return RouterFunctions.route(GET("/orders/{id}"), this::get)
    .andRoute(POST("/orders"), this::create);
```

```java
return RouterFunctions.route()
    .GET("/orders", this::list)
    .nest(path("/{id}"), nested -> {
        nested.GET("", this::get);
        nested.DELETE("", this::delete);
    })
    .build();
```

Распознаются verbs `GET`, `HEAD`, `POST`, `PUT`, `PATCH`, `DELETE` и
`OPTIONS`. Paths используют workspace String resolver. Selector должен
доказывать один method и один static path. Настоящие request predicates,
которые не выбирают method или path, могут быть исключены из public identity,
включая ограниченные сочетания `and`/`or`/`negate` и однозначно
инициализированное typed final поле predicate.

Дополнительный predicate path или method меняет identity и отвергается.
Затенённые receivers, затенённые static imports, неоднозначные wildcard imports,
dynamic paths и неподдерживаемые predicate calls также приводят к fail-closed.

### 2.2 Attribution handler и bounds

`this::handler` связывается с конкретным объявлением только тогда, когда один
нестатический source method того же owner имеет поддерживаемую форму с одним
параметром. Его объявление становится public handler и represented target.

Lambda или непрямая ссылка всё ещё может доказать публикацию route, не
доказывая handler; attribution тогда откатывается к publisher с `@Bean`.
Отсутствующая прямая ссылка на метод невалидна. Неоднозначная overload сохраняет
валидный route только с attribution publisher.

Decoder ограничивает publisher значениями 256 chain steps, nesting depth 16 и
4096 выданных routes. Превышение bound отвергает такой publisher.

## 3. Программный `RequestMappingHandlerMapping`

Тот же модуль распознаёт прямые calls `registerMapping`. Owner должен быть
уникальным, видимым, конкретным class с ровно одним настоящим прямым
`@Configuration`. Метод registration должен быть нестатическим `void`, иметь
один прямой marker-only `@Autowired`, принимать ровно один настоящий параметр
`RequestMappingHandlerMapping` и вызывать `registerMapping` на этом точном
параметре.

Моделируется следующая форма:

```java
mapping.registerMapping(
    RequestMappingInfo.paths("/admin/reload")
        .methods(RequestMethod.POST)
        .build(),
    handler,
    Handler.class.getMethod("reload")
);
```

Mapping и отражённый method могут быть inline или сохранены в одной более
ранней прямой local variable с уникальным именем и ожидаемым type. Tracked
locals и релевантные параметры нельзя переназначать, обновлять или объявлять
повторно с неоднозначностью.

Для `RequestMappingInfo` вызов `paths(...)` обязателен и статически разрешается;
`methods(...)` необязателен и должен содержать настоящие Spring request-method
values. Другие builder stages не принимаются. Отсутствующее условие method
выдаёт `ANY`.

Reflection должен разрешить один конкретный source class, одно непустое имя
метода, canonical parameter class literals и ровно одну public non-static
overload. Аргумент handler должен быть параметром метода этого source type.

Моделируемый control flow, вложенная registration, `unregisterMapping` или
mutation tracked state отвергают метод registration. После доказательства
состояния метода отдельный malformed call можно пропустить, сохранив валидные
sibling calls.

## 4. MVC hierarchy

[`SpringMvcHierarchyAnalyzer`](../src/noir/spring_mvc_hierarchy.py) добавляет
routes, у которых Spring mapping contract и конкретный handler находятся в
разных source declarations. Он опирается на нейтральный type graph в
[`java_hierarchy.py`](../src/noir/java_hierarchy.py).

Analyzer разрешает уникальные source identities, erased method signatures,
generic adaptation, максимально специфичные interfaces и эффективные
конкретные реализации. Неопределённые или конфликтующие hierarchy edges
подавляют только зависящие от них facts; независимо доказанные прямые MVC facts
остаются.

Выданный fact приписывает public row и represented target конкретной
реализации. Mapping evidence из другого объявления может доказать endpoint,
но не владеет row реализации и потому не может заполнить для неё
`method_annotation_line`.

## 5. Spring Cloud Gateway

[`analyze_spring_gateway`](../src/noir/spring_gateway.py) распознаёт ограниченные
publication chains `RouteLocator`. Publisher требует один настоящий прямой
`@Bean`, настоящий return type `RouteLocator`, ровно один настоящий параметр
`RouteLocatorBuilder` и прямой return `builder.routes()...build()`.

Принимаются ровно такие последовательности route predicate:

- `path(...)`;
- `path(...).and().method(...)`; или
- `method(...).and().path(...)`.

Аргументы path и method могут размножаться после static resolution.
Последовательные calls `filter(...)` или `filters(...)` принимаются только
после распознанной predicate sequence. Route ID и destination могут быть
dynamic, поскольку они не определяют inbound route.

Поддерживаемые methods берутся из настоящих значений `RequestMethod` или
`HttpMethod`; `CONNECT` доступен только через `HttpMethod`. Один точный helper
того же owner может вернуть поддерживаемую predicate chain от настоящего
`PredicateSpec` к настоящему `BooleanSpec`.

Неподдерживаемая route lambda диагностируется и пропускается, а валидные
siblings сохраняются. Malformed внешняя publication chain отвергает publisher.

## 6. Статические resource handlers

[`analyze_spring_resource_handlers`](../src/noir/spring_config.py) распознаёт
уникальный конкретный `WebMvcConfigurer` и его canonical public non-static
текстовый-`void` метод `addResourceHandlers(ResourceHandlerRegistry)`.

Поддерживаются прямые top-level registrations, начинающиеся от точного
параметра:

```java
registry.addResourceHandler("/assets/**", Paths.DOCS)
        .addResourceLocations("classpath:/static/");
```

Каждый аргумент `addResourceHandler` разрешается независимо, поэтому
невалидный аргумент не отбрасывает валидные siblings. Physical resource
locations и последующее поведение chain не интерпретируются. Facts используют
`GET`, `http`, `static-handler` и направление inbound.

Mutation receiver, aliases, вложенные calls, поддельные interfaces и неверные
формы метода отвергают затронутый метод configurer.

## 7. Исходящие HTTP clients

[`analyze_spring_http_clients`](../src/noir/spring_clients.py) выдаёт
facts `http`/`client`/`outbound` для уникальных видимых source interfaces.

### 7.1 Spring HTTP Interface

Каждый лексический слой interface может добавлять один generic слой path/method
уровня типа `@HttpExchange`. Прямые non-private non-static методы могут
использовать фиксированные `*Exchange`-аннотации или generic
`@HttpExchange(method = ...)`. Наследование interface не обходится.

Важные правила:

- generic method tokens ограничены и переводятся в uppercase;
- generic `@HttpExchange` без method выдаёт `ANY`;
- aliases `value` и `url` должны совпадать;
- positional и named `value` нельзя смешивать;
- аннотации с фиксированным verb отвергают явный `method`;
- `contentType`, `accept` и `headers` нейтральны к route; и
- восстановленные arrays размножаются детерминированно.

Несколько настоящих mappings метода могут добавить несколько facts. Условия
method уровня type и method объединяются union. Неопределённый type layer
подавляет interface; неопределённый mapping метода можно пропустить независимо.

### 7.2 OpenFeign

Feign contract требует ровно один настоящий прямой `@FeignClient` на
уникальном видимом interface. Его атрибуты `name`, `value`, `url` и `path`
классифицируют contract, но не добавляют слои path.

Настоящие встроенные или составные Spring MVC mapping на лексических слоях
interface и прямых пригодных методах задают paths и methods. Анализируются
только прямые методы contract. Невалидные type mappings подавляют contract;
невалидные method mappings остаются локальными.

### 7.3 Отложенные paths client

Client facts сохраняют лексические компоненты path в
`EndpointFact.spring_client_path_layers`, пока не станет известна project
configuration. Это единственное явное transient field в модели endpoint.
Placeholders разрешаются отдельно в каждом слое перед join. Внутренний
абсолютный слой `http://` или `https://` сбрасывает внешние слои:

```text
/catalog + ${inventory.base}/items
${inventory.base}=https://inventory.example
=> https://inventory.example/items
```

Clients никогда не получают `server.servlet.context-path` или
`spring.webflux.base-path`.

## 8. WebSocket handshakes и messaging

[`analyze_spring_websocket_and_messaging`](../src/noir/spring_websocket_messaging.py)
выдаёт handshake facts (`ws GET`) и STOMP-style destination facts (`ws SEND`
или `ws SUBSCRIBE`).

### 8.1 Handshakes

Моделируются две точные формы configurer:

| Interface | Method | Registry | Registration |
|---|---|---|---|
| `WebSocketMessageBrokerConfigurer` | `registerStompEndpoints` | `StompEndpointRegistry` | `addEndpoint(paths...)` |
| `WebSocketConfigurer` | `registerWebSocketHandlers` | `WebSocketHandlerRegistry` | `addHandler(handler, paths...)` |

Owner уникален, видим и конкретен. Метод canonical public non-static и
текстовый `void`; его registry нельзя мутировать. Registrations являются
прямыми top-level chains. Path-neutral suffixes включают configuration
interceptor, allowed origin, allowed-origin-pattern и handshake-handler.
`withSockJS()` отвергается, поскольку расширяет transport behavior.

Для raw WebSocket registration handler должен разрешаться в одно точное поле
настоящего type `WebSocketHandler`. Явное `this.field` отличает поле, затенённое
local variable. Аргументы path размножаются независимо.

### 8.2 Application prefixes и message handlers

Canonical методы `configureMessageBroker(MessageBrokerRegistry)` могут задавать
project-scoped application prefixes одним прямым call
`setApplicationDestinationPrefixes(...)`. Отсутствие call означает пустой
prefix; несколько calls, вложенные calls, mutation, неразрешённые значения или
неоднозначное владение project делают модель message-prefix этого project
невалидной.

Лексическая chain типов message handler должна содержать настоящий
`@Controller` или `@RestController`. Значения `@MessageMapping` уровня типа
компонуются по лексическим слоям. Прямые аннотации метода затем выдают:

- `@MessageMapping` → `SEND`;
- `@SubscribeMapping` → `SUBSCRIBE`.

Aliases `value` и `path` должны совпадать. Destinations метода явные, непустые
и static; arrays размножаются по project prefix, paths лексических типов и
paths метода. Правила композиции/иерархии MVC и server base paths не применяются
к message destinations.

## 9. Конфигурация project path

[`build_spring_path_configuration`](../src/noir/spring_config.py) строит
`SpringWorkspacePathConfiguration` после Spring passes, не относящихся к
messaging. Анализ
WebSocket/message потребляет её, затем `apply_spring_path_configuration()`
возвращает новый tuple сконфигурированных facts. Pipeline вызывает эту функцию
один раз.

### 9.1 Выбор project и файла

Владение project предпочитает один применимый ancestor `src/main/java`, затем
один ancestor `src`, иначе analysis root. Повторяющиеся применимые markers,
неоднозначное владение или source за пределами analysis root означают
отсутствие project. Static paths могут сохраниться без project configuration;
path с оставшимся непригодным placeholder syntax — нет.

Functional facts сохраняют `project_source_file` как publisher, даже когда
public handler находится в другом файле. Поэтому configuration следует
владению публикацией route.

Места configuration читаются в порядке увеличения precedence:

1. `src/main/resources`;
2. `resources`;
3. project root.

Внутри location: `application.properties`, затем `application.yml`, затем
`application.yaml`. Более поздние значения перезаписывают ранние. Readers
моделируют небольшой детерминированный subset. YAML допускает только mapping;
sequences, anchors, document markers, malformed structure и profile activation
keys отвергают такой файл.

### 9.2 Правила resolution

Inbound server prefix использует непустой `spring.webflux.base-path`, иначе
`server.servlet.context-path`. `${key}` и `${key:default}` допускают
ограниченную вложенную substitution. Отсутствующий key без default становится
пустым. Malformed syntax, более 100 substitutions или результат длиннее 8192
символов отвергает endpoint.

```mermaid
flowchart TD
    Fact["EndpointFact"] --> Kind{"surface"}
    Kind -->|"inbound HTTP, gateway, static, handshake"| Server["разрешить path + добавить server base"]
    Kind -->|"outbound client"| Client["разрешить path layers; абсолютный URL сбрасывает их"]
    Kind -->|"message"| Message["применить только application prefix"]
    Server --> Replace["dataclasses.replace с разрешённым path"]
    Client --> Replace
    Message --> Replace
    Replace --> Keep["сконфигурированный EndpointFact"]
    Fact -->|"не разрешается"| Drop["диагностировать и исключить candidate"]
```

Inputs никогда не мутируются. Не-Spring facts проходят без изменения, если
переданы функции. Неразрешённый candidate диагностируется и удаляется, не
затрагивая siblings.

## 10. Evidence, deduplication и область failure

Каждый analyzer добавляет типизированное evidence через
[`noir.evidence`](../src/noir/evidence.py):

- `AnnotationEvidence` идентифицирует принадлежащую endpoint аннотацию
  request-method;
- `SourceTarget` идентифицирует представленный method, record component или
  type;
- `merge_endpoint_facts()` сохраняет fact более позднего analyzer, объединяя
  обе коллекции evidence; и
- `deduplicate_endpoint_facts()` применяет analyzer-specific typed identity.

Локальная identity намеренно богаче публичной identity CSV. Identity client
включает отложенные path layers; identity message включает protocol/surface.
Более поздняя граница
[`consolidate_endpoint_rows`](../src/noir/output.py) нормализует public paths и
группирует по точным шести public fields для всех analyzers.

У большинства routes на основе call/DSL нет evidence аннотации метода, потому
что identity route происходит из invocation, а не endpoint-аннотации. Но они
сохраняют точный declaration target, владеющий row. Если configuration
отбрасывает fact, его target не входит в итоговый union represented targets.

Область fail-closed соответствует наименьшей границе доказательства:

| Неопределённость | Область |
|---|---|
| невалидное functional expression или превышен budget | publisher |
| невалидный programmatic flow или mutation | метод registration |
| плохая registration после доказательства state метода | call |
| malformed publication chain Gateway | publisher |
| неподдерживаемая lambda Gateway | route |
| неразрешённый resource argument | argument |
| мутированный resource registry | метод configurer |
| невалидный type layer client | interface |
| невалидный mapping метода client | mapping |
| невалидный application destination prefix | message facts этого project |
| неразрешённый configured path | endpoint fact |
| дублирующаяся source identity | consumer, которому нужна уникальность |

Эти analyzers не создают Spring container, не выполняют profiles или bean
conditions, не исследуют dependency bytecode и не вычисляют произвольные
helpers. Headers, media conditions, filters, security и физическое
существование resource обычно находятся вне public identity endpoint.
Outbound client facts не являются inbound attack surface, а rows handshake и
message представляют разные стадии protocol.

Далее: [06 — JAX-RS](06-jax-rs.md).
