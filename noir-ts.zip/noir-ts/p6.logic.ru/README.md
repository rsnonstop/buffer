# Руководство по логике noir-ts

В этой папке объясняется текущая реализация, стоящая за вызовом:

~~~bash
python3 src/noir_sbt.py \
  --path "<application source directory>" \
  --output "endpoints.csv"
~~~

Приложение — консервативный Java-анализатор endpoint'ов, работающий
исключительно с source-кодом Spring и JAX-RS, а также с выбираемым пустым
integration stub для Wicket, который делает extension seam исполняемым.
Авторитетным источником для этого руководства служит production-код данного
репозитория. Более ранние материалы sprint'ов и OpenSpec фиксируют эволюцию
поведения; они не описывают текущую архитектуру.

## Как читать код и описание логики вместе

Координата кода связывает файл-владелец с именем определения, например
[`src/noir/pipeline.py`](../src/noir/pipeline.py) ::
`run_analysis()`. Перейдите по ссылке, а затем найдите symbol в файле.
Docstring'и source-module'ей ссылаются обратно на соответствующую главу о
логике.

- Начните с [карты кода](10-code-map.md), если вам известно поведение и нужно
  найти его владельца.
- Начните с [указателя методов](15-method-lookup.md), если вы выбрали функцию
  или класс в `src/` и хотите узнать его callers, data flow и контекст в
  приложении.
- Начните с docstring source-module, если вам известен код и нужно понять его
  роль в приложении.
- Считайте type hint'ы механическим контрактом, а комментарии — объяснениями
  порядка, владения, неоднозначности и решений об evidence.

У руководства есть два взаимодополняющих уровня глубины:

- главы 01–11 объясняют систему через поведение, архитектуру, framework и
  artifact;
- главы 12–15 объясняют её через runtime-вызовы и точные Python-symbol'ы; и
- глава 16 описывает maintainer-путь добавления семейства framework.

Второй слой дополняет, а не заменяет первый. Карточка метода лучше подходит для
следования за кодом; глава о поведении — для понимания того, почему метод
применяет конкретное правило.

## Самое короткое точное объяснение

Один вызов:

1. проверяет CLI-пути и, при наличии, Noir report;
2. создаёт неизменяемый `AnalysisRequest` и diagnostic collector в scope одного
   запуска;
3. проверяет закреплённую пару Tree-sitter, обнаруживает Java-файлы и один раз
   создаёт snapshot каждого файла;
4. выбирает одно или несколько явно заданных семейств, default-набор
   Spring/JAX-RS либо subset, выведенный из marker'ов, на основании запрошенного
   режима и evidence из snapshot;
5. один раз разбирает каждый snapshot, строит нейтральные index'ы, настраивает
   каждый static adapter, строит оба inventory, подготавливает все выбранные
   семейства, а затем запускает facade'ы выбранных семейств в статическом порядке
   registry;
6. возвращает в `AnalysisResult` только неизменяемые значения `EndpointFact`,
   inventory, announcement'ы и diagnostic'и;
7. проецирует fact'ы в семиколоночный CSV identity, объединяет evidence
   дубликатов, формирует сопутствующие report'ы, публикует artifact'ы по порядку
   и печатает итоговый inventory лишь после успешной publication.

Если `--framework` не указан, запускаются Spring и JAX-RS. Повторите option для
явной комбинации, например `--framework spring --framework wicket`. Tuple
запроса канонизируется в порядке enum framework; effective lifecycle и
presentation не-auto режима независимо следуют статическому порядку adapter
registry. Один явный запрос Wicket запускает только его пустой facade lifecycle.
Дубликаты и смешанные запросы `auto`/explicit недопустимы. Scalar-режим `auto`
не изменён, а Wicket исключён как из default selection, так и из auto selection.

~~~mermaid
flowchart LR
    L["src/noir_sbt.py<br/>тонкий launcher"] --> CLI["noir.cli<br/>валидация и publication"]
    CLI --> APP["noir.application<br/>типизированный запуск + diagnostic scope"]
    APP --> PIPE["noir.pipeline<br/>generic-порядок стадий"]
    PIPE --> REG["noir.frameworks<br/>статическая execution table"]
    PIPE --> TS["tree_sitter_runtime<br/>проверенный parser runtime"]
    PIPE --> JAVA["java_frontend + java_workspace<br/>однократный parse + общие index'ы"]
    REG --> SPRING["facade spring_framework"]
    REG --> JAX["facade jaxrs_framework"]
    REG --> WICKET["выбираемый пустой stub Wicket"]
    JAVA --> SPRING
    JAVA --> JAX
    JAVA --> WICKET
    SPRING --> FACT["EndpointFact"]
    JAX --> FACT
    WICKET -. пустой tuple .-> FACT
    FACT --> RESULT["AnalysisResult"]
    RESULT --> OUT["noir.output + noir.reports"]
    OUT --> CSV["CSV и сопутствующие report'ы"]
    NOIR["необязательный Noir v1.1 JSON"] --> COMP["noir.comparison"]
    COMP --> OUT
~~~

## Порядок чтения руководства

| Порядок | Глава | Главный вопрос |
|---:|---|---|
| 1 | [Ментальная модель](01-mental-model.md) | Каковы границы системы и data flow? |
| 2 | [CLI и orchestration](02-cli-and-orchestration.md) | Что и в каком порядке происходит после вызова? |
| 3 | [Общий Java engine](03-shared-java-engine.md) | Как обрабатываются parsing, имена, константы и неоднозначность? |
| 4 | [Spring MVC](04-spring-mvc.md) | Как декодируются прямые, composed, record- и унаследованные MVC mapping'и? |
| 5 | [Дополнительные поверхности Spring](05-spring-additional-surfaces.md) | Как находятся functional route'ы, registration'ы, Gateway, resource'ы, client'ы и messaging? |
| 6 | [JAX-RS и Java WebSocket](06-jax-rs.md) | Как работают resource'ы, deployment, hierarchy, subresource'ы, custom verb'ы и handshake'и? |
| 7 | [Output, evidence и report'ы](07-output-evidence-reports.md) | Как типизированные fact'ы превращаются в row'ы и audit-artifact'ы? |
| 8 | [Разобранные трассы](08-worked-traces.md) | Как логика ведёт себя на конкретных Java-примерах? |
| 9 | [Production-эксплуатация](09-production-use.md) | Какие ограничения и операционные риски важны? |
| 10 | [Карта кода](10-code-map.md) | Где реализовано каждое поведение? |
| 11 | [Словарь логики приложения](11-naming-and-code-vocabulary.md) | Что означают термины приложения и их конкретные значения? |
| 12 | [Методы core runtime](12-core-runtime-methods.md) | Какие методы проводят вызов через parsing, построение workspace и orchestration? |
| 13 | [Методы Spring](13-spring-methods.md) | Какие цепочки методов декодируют каждую поверхность Spring и создают fact'ы? |
| 14 | [Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) | Какие цепочки методов декодируют JAX-RS/WebSocket и проводят fact'ы в artifact'ы? |
| 15 | [Указатель методов и стратегия чтения](15-method-lookup.md) | Где описан выбранный source-symbol и как читать его call graph? |
| 16 | [Добавление поддержки framework](16-adding-framework-support.md) | Какие изменения model, facade, registry, evidence и guardrail вводят ещё одно семейство? |

## Представления, которые даёт руководство

Ни одна диаграмма не способна хорошо объяснить статический анализатор целиком.
Поэтому главы намеренно предлагают следующие взаимодополняющие представления,
стандартные для индустрии:

| Представление | На какой вопрос отвечает | Основные главы |
|---|---|---|
| system context и границы | Что находится внутри noir-ts, а что остаётся внешним evidence или output? | 01, 09 |
| статическое владение | Какой package/module владеет каждой ответственностью и dependency? | 01, 10, 11 |
| динамический call/sequence | В каком порядке вызываются методы, включая решения и выходы с ошибкой? | 02, 08, 12–14 |
| lifecycle данных | Как byte'ы превращаются в syntax fact'ы, semantic fact'ы, evidence, row'ы и файлы? | 01, 03, 07, 12–14 |
| политика решений и неоднозначности | Какой proof требуется и где анализ работает fail closed? | 03–06, 12–14 |
| границы effects и failure | Какие методы записывают diagnostic'и, печатают или изменяют artifact'ы? | 02, 07, 09, 12, 14 |
| разобранные execution trace'ы | Как конкретный Java source проходит через эти вызовы? | 08 |
| трассируемость source | Где реализовано поведение и какие определения его используют? | 10, 12–15 |
| расширение framework | Как новое семейство присоединяется к статическому lifecycle без coupling с существующими семействами? | 16 |
| операционный риск | Что production-пользователь должен зафиксировать, отслеживать и проверять? | 09 |

## Не смешивайте три представления

### Представление source

Java-declaration'ы, annotation'ы, import'ы, константы, configuration-файлы и
deployment descriptor'ы — это evidence. Это не endpoint row'ы.

### Представление внутренних fact'ов

Каждый analyzer сразу выдаёт `EndpointFact`. Fact сохраняет protocol, surface,
direction, атрибуцию route и handler, типизированное annotation evidence и
представленные source target'ы. Pipeline отклоняет любой результат analyzer'а,
который не является `EndpointFact`.

### Представление публичных artifact'ов

`noir.output` выполняет намеренный шаг с потерей информации. Он создаёт шесть
публичных identity-полей, нормализует и группирует их, а затем выбирает
`method_annotation_line` из объединённого evidence. Некоторые внутренние
различия не помещаются в CSV и доступны только логике report'ов.

~~~mermaid
flowchart TD
    SRC["Evidence из source"] --> FACT["EndpointFact"]
    FACT --> ROW["EndpointRowCandidate"]
    ROW --> GROUP["ConsolidatedEndpoints"]
    GROUP --> CSV["Семь публичных CSV-полей"]
    FACT --> EV["AnnotationEvidence + SourceTarget"]
    EV --> GROUP
    GROUP --> AUDIT["Сопутствующие report'ы"]
~~~

## Основной словарь

- **Direct analyzer:** интерпретирует route annotation на конкретной
  source-declaration, повторно используя общий compilation unit.
- **Supplemental analyzer:** добавляет ещё одну подтверждённую source'ом
  поверхность — например унаследованный contract, functional registration,
  client, Gateway route или WebSocket destination.
- **Framework adapter:** одна статическая composition-запись, связывающая имя
  семейства, selection identity, default policy, setup/preparation hook'и и
  facade семейства. Наличие marker и default membership остаются разными
  решениями.
- **Fail closed:** пропускает неподдерживаемого или неоднозначного candidate,
  не пытаясь угадать; обычно записывает diagnostic на границе отклонения.
- **Workspace:** все разобранные compilation unit'ы и cross-file index'ы,
  используемые выбранными analyzer'ами.
- **Route source:** declaration, задающая identity route.
- **Handler source:** конкретная Java-declaration, атрибутированная endpoint'у.
- **Represented target:** точные source-файл, вид declaration и byte span,
  используемые report'ом annotations-without-endpoints.
- **Method annotation evidence:** проверенный same-file provenance, по которому
  после группировки выбирается публичная строка annotation.

## Главное для production

- Требуемая пара parser'ов: `tree-sitter==0.25.2` и
  `tree-sitter-java==0.23.5`.
- Каждый обнаруженный Java-файл читается один раз и разбирается один раз за
  запуск. Все выбранные analyzer'ы повторно используют полученный unit.
- Большинство неопределённостей локальны и обрабатываются fail closed. Успешный
  exit не доказывает, что было понято всё динамическое поведение framework.
- Endpoint CSV и artifact `Annotation and diagnostics log` записываются
  напрямую. Каждый byte-report заменяется атомарно, но полный набор artifact'ов
  не является одной filesystem-транзакцией.
- Announcement'ы framework предшествуют итоговому completion inventory.
  Неудачный запуск никогда не печатает `noir-ts analysis completed.`
- Diagnostic'и принадлежат текущему запуску приложения; analyzer'ы записывают
  их через `noir.diagnostics` и не записывают файлы report'ов.
- Во время review храните CSV вместе с сопутствующими report'ами: CSV намеренно
  содержит меньше provenance, чем внутренние fact'ы.

Продолжение: [01 — Ментальная модель](01-mental-model.md).
