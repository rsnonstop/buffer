# 10 — Карта кода и тестов

[← Разобранные трассировки](08-worked-traces.md) · [Оглавление](README.md) · [Имена и словарь →](11-naming-and-code-vocabulary.md)

Эта глава связывает текущее поведение с владеющим им source и regression tests.
Вместо номеров строк координаты используют links на файлы и стабильные symbols.

## 1. Архитектурный маршрут

~~~mermaid
flowchart TB
    LAUNCH["src/noir_sbt.py<br/>executable guard"]
    CLI["noir.cli<br/>arguments, artifacts, stdout"]
    APP["noir.application<br/>типизированный scope diagnostics"]
    PIPE["noir.pipeline<br/>snapshot, selection, порядок passes"]
    RUNTIME["tree_sitter_runtime<br/>version gate и runtime"]
    JAVA["java_frontend + java_workspace<br/>однократный parse и index"]
    SPRING["Анализаторы Spring"]
    JAX["Анализаторы JAX-RS"]
    MODEL["noir.model<br/>типизированные facts и result"]
    INV["noir.inventory<br/>broad- и trigger-views"]
    OUTPUT["noir.output<br/>projection и consolidation"]
    REPORTS["noir.reports + noir.comparison<br/>render и publish"]

    LAUNCH --> CLI --> APP --> PIPE
    PIPE --> RUNTIME --> JAVA
    JAVA --> SPRING --> MODEL
    JAVA --> JAX --> MODEL
    JAVA --> INV --> MODEL
    MODEL --> OUTPUT --> REPORTS
    CLI --> REPORTS
~~~

`src/noir_sbt.py` намеренно является тонким launcher. Поведение application
находится в `src/noir/`, модули которого напрямую импортируют настоящих
владельцев. Framework analyzers потребляют общий workspace и выдают значения
`EndpointFact`; они не зависят от launcher, не изменяют command state и не
публикуют файлы.

### Быстрый маршрут по реализации

| Шаг | Координата в коде | Ответственность |
|---|---|---|
| launch | [`src/noir_sbt.py`](../src/noir_sbt.py) :: executable guard | Импортировать `noir.cli.main` и завершиться с его status. |
| validate и publish | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` | Проверить inputs, привязать diagnostics, вызвать analysis, project facts, опубликовать запрошенные artifacts по порядку и вывести сообщение об успехе. |
| владеть одним типизированным run | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` | Проверить `AnalysisRequest`, владеть collector или повторно использовать его, вызвать pipeline и присоединить только diagnostics этой invocation. |
| оркестрировать analysis | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | Проверить доступность parser, создать snapshot sources, выбрать frameworks, построить один workspace, запустить analyzers и вернуть `AnalysisResult`. |
| построить parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `require_tree_sitter()`, `build_workspace_runtime()` | Обеспечить поддерживаемую пару dependencies и построить parser/query runtime. |
| parse и index | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` → [`src/noir/java_frontend.py`](../src/noir/java_frontend.py) :: `build_java_compilation_unit()` | Единожды распарсить каждый source из snapshot и построить общие per-file и cross-file facts. |
| запустить direct mappings | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()`; [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` | Интерпретировать доказанные direct annotations Spring и JAX-RS как типизированные endpoint facts. |
| построить inventories | [`src/noir/inventory.py`](../src/noir/inventory.py) :: `build_annotation_audit_inventory()`, `build_final_trigger_inventory()` | Построить broad annotation view и более узкий endpoint-trigger view из общего workspace. |
| project и consolidate | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()`, `consolidate_endpoint_rows()` | Пересечь public-границу потери информации, нормализовать identity, объединить evidence и выбрать annotation line. |
| render reports | [`src/noir/reports.py`](../src/noir/reports.py) :: `render_annotations_without_endpoints_report_bytes()`; [`src/noir/comparison.py`](../src/noir/comparison.py) :: `compare_annotation_audit_inventory()` | Создать trigger-based отчёт об отсутствии и опциональное сравнение по точному source location. |

## 2. Владение в package

### 2.1 Invocation и application core

| Владелец | Основные symbols | Ответственность |
|---|---|---|
| [`noir.cli`](../src/noir/cli.py) | `build_argument_parser`, `run_cli`, `render_completion_summary` | User input, filesystem effects, порядок publication и stdout. |
| [`noir.application`](../src/noir/application.py) | `AnalysisRunner`, `analyze` | Типизированная граница call и владение diagnostics. |
| [`noir.pipeline`](../src/noir/pipeline.py) | `SourceSnapshot`, `FrameworkDecision`, `run_analysis` | Полный порядок source-to-result без artifact I/O. |
| [`noir.discovery`](../src/noir/discovery.py) | `discover_java_files`, `discover_pom_files`, `scan_framework_markers` | Отсечение ignored paths, deterministic discovery и marker-based auto selection. |
| [`noir.tree_sitter_runtime`](../src/noir/tree_sitter_runtime.py) | `SUPPORTED_VERSIONS`, `require_tree_sitter`, `build_workspace_runtime`, `run_query_matches` | Gate parser packages и построение query runtime. |
| [`noir.diagnostics`](../src/noir/diagnostics.py) | `DiagnosticCollector`, `bind`, `record`, `format_endpoint_diagnostic` | Захват diagnostics в рамках run и стабильные сообщения endpoint. |
| [`noir.contracts`](../src/noir/contracts.py) | `CSV_FIELDS`, framework constants, evidence-family constants | Общий декларативный словарь для analyzers и presentation. |

### 2.2 Общий Java engine

| Владелец | Основные symbols | Ответственность |
|---|---|---|
| [`noir.java_queries`](../src/noir/java_queries.py) | `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | Framework-neutral определения query source. |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `parse_java_query_set`, `build_java_compilation_unit`, `resolve_known_annotation`, `resolve_known_type` | Parsing Tree-sitter, association captures, per-file facts и identity известных libraries. |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace`, `resolve_workspace_owner_fqns`, `resolve_workspace_string_expression` | Cross-file types, members, constants, annotations, retention и access rules. |
| [`noir.java_ast`](../src/noir/java_ast.py) | `field`, `walk_named`, `known_type`, `is_direct_invocation_statement` | Небольшие общие helpers навигации по AST и доказательства. |
| [`noir.java_methods`](../src/noir/java_methods.py) | `MethodFact`, `MethodIndex`, `build_strict_method_index`, `build_varargs_method_index` | Детерминированные method и invocation indexes для ограниченных source flows. |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord`, `JavaSourceHierarchyGraph` | Generic adaptation, erased signatures, traversal inheritance и selection implementation. |
| [`noir.paths`](../src/noir/paths.py) | `join_endpoint_paths`, `ensure_path_leading_slash`, `relative_source_path` | Нейтральная композиция route и форматирование public source path. |

Построением runtime владеет `tree_sitter_runtime`; собственно parse source
принадлежит `java_frontend`. Framework analyzers получают распарсенные продукты
workspace и никогда не строят собственный parser.

### 2.3 Framework analyzers

| Владелец | Entry point | Surface |
|---|---|---|
| [`noir.spring_mvc`](../src/noir/spring_mvc.py) | `analyze_direct_spring_mvc_unit` | Direct MVC mappings, composed annotations, records и mapping indexes. |
| [`noir.spring_route_registrations`](../src/noir/spring_route_registrations.py) | `analyze_spring_route_registrations` | Functional routes RouterFunction и programmatic MVC registrations. |
| [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) | `analyze_spring_mvc_hierarchy` | Унаследованные mapping contracts, связанные с concrete controllers. |
| [`noir.spring_gateway`](../src/noir/spring_gateway.py) | `analyze_spring_gateway` | Routes Java DSL Spring Cloud Gateway. |
| [`noir.spring_config`](../src/noir/spring_config.py) | `build_spring_path_configuration`, `analyze_spring_resource_handlers`, `apply_spring_path_configuration` | Конфигурация project, resource handlers, placeholders и финальные Spring path layers. |
| [`noir.spring_clients`](../src/noir/spring_clients.py) | `analyze_spring_http_clients` | Outbound contracts Spring HTTP Interface и OpenFeign. |
| [`noir.spring_websocket_messaging`](../src/noir/spring_websocket_messaging.py) | `analyze_spring_websocket_and_messaging` | Raw/STOMP handshakes и message destinations. |
| [`noir.jaxrs`](../src/noir/jaxrs.py) | `analyze_direct_jax_rs_unit` | Direct resources, custom request methods, record accessors и application paths. |
| [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) | `build_jax_rs_deployment_model`, `select_jax_rs_deployment_prefix` | Source applications и ограниченные deployment prefixes из `web.xml`. |
| [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) | `analyze_jax_rs_hierarchy_and_subresources` | Унаследованные resource bundles и рекурсивные subresource locators. |
| [`noir.java_websocket`](../src/noir/java_websocket.py) | `analyze_java_websocket_endpoints` | Server-side handshake'и Javax/Jakarta WebSocket. |

Каждый entry point выше возвращает значения `EndpointFact`. Локальная
deduplication использует callback, вычисляющий analyzer-specific identity, и
общий merger типизированного evidence в `noir.evidence`.

### 2.4 Domain, evidence и presentation

| Владелец | Основные symbols | Ответственность |
|---|---|---|
| [`noir.model`](../src/noir/model.py) | `AnalysisRequest`, `FrameworkPlan`, `EndpointFact`, `AnalysisResult` | Immutable-словарь application. |
| [`noir.evidence`](../src/noir/evidence.py) | `method_annotation_evidence_from_node`, `represented_target_evidence`, `deduplicate_endpoint_facts` | Валидация, merge и selection типизированного provenance. |
| [`noir.inventory`](../src/noir/inventory.py) | `build_annotation_audit_inventory`, `build_final_trigger_inventory` | Broad и endpoint-trigger views annotations. |
| [`noir.output`](../src/noir/output.py) | `EndpointRowCandidate`, `ConsolidatedEndpoints`, `consolidate_endpoint_rows`, `write_endpoint_csv` | Projection public rows, группировка по шести полям, выбор седьмого поля и точные bytes CSV. |
| [`noir.reports`](../src/noir/reports.py) | `write_annotation_diagnostic_log`, `render_annotations_without_endpoints_report_bytes`, `publish_bytes_atomically` | Базовые companion artifacts. |
| [`noir.comparison`](../src/noir/comparison.py) | `load_noir_report_locations`, `compare_annotation_audit_inventory`, `render_noir_comparison_report_bytes` | Строгая валидация Noir report и точное сравнение canonical file/line. |
| [`noir.immutability`](../src/noir/immutability.py) | `freeze_data` | Отделение и заморозка вложенных result data. |

## 3. Точный порядок analyzers

`run_analysis()` сначала создаёт snapshot, framework decision, общий workspace и
broad annotation inventory. Он строит final-trigger inventory, когда выбран
хотя бы один framework. Когда выбран JAX-RS, до extraction endpoints он также
строит deployment model.

Порядок Spring:

1. direct Spring MVC для каждого source;
2. functional и programmatic route registrations;
3. дополнения MVC hierarchy;
4. Gateway;
5. handlers статических resources;
6. исходящие clients;
7. конфигурация project path;
8. WebSocket и messaging;
9. одно финальное применение Spring path configuration ко всем собранным facts.

Порядок JAX-RS:

1. direct JAX-RS для каждой compilation unit;
2. дополнения hierarchy и subresource;
3. handshake'и Java WebSocket.

Эти passes используют один workspace. Порядок их iteration может влиять на
diagnostics, но public rows позднее нормализуются, группируются и сортируются
в `noir.output`.

## 4. Карта тестов

[`tests/noir_test_support.py`](../tests/noir_test_support.py) предоставляет
native-проверку доступности parser, builder in-memory workspace и типизированный
application helper, используемые semantic tests.

| Семейство тестов | Основные файлы | Ответственность |
|---|---|---|
| architecture и documentation | [`test_noir_architecture.py`](../tests/test_noir_architecture.py), [`test_noir_documentation.py`](../tests/test_noir_documentation.py) | Направление dependencies, форма launcher, framework-neutral владение core, владение parser и navigability кода/guide. |
| application core | [`test_noir_application.py`](../tests/test_noir_application.py), [`test_noir_diagnostics.py`](../tests/test_noir_diagnostics.py), [`test_noir_pipeline.py`](../tests/test_noir_pipeline.py), [`test_noir_parse_once.py`](../tests/test_noir_parse_once.py) | Типизированные requests/results, isolation diagnostics, порядок frameworks, snapshot source и один parse каждого файла. |
| domain и output | [`test_noir_domain_model.py`](../tests/test_noir_domain_model.py), [`test_noir_paths.py`](../tests/test_noir_paths.py), [`test_noir_output.py`](../tests/test_noir_output.py) | Immutable facts, композиция path, merge evidence, normalization, grouping и bytes CSV. |
| executable contract | [`test_noir_sbt_cli_black_box.py`](../tests/test_noir_sbt_cli_black_box.py), [`test_noir_comparison_cli.py`](../tests/test_noir_comparison_cli.py) | Invocation script, help/failure behavior, порядок artifacts, stdout и опциональный comparison mode. |
| broad Java/framework behavior | [`test_noir_sbt.py`](../tests/test_noir_sbt.py), [`test_noir_sbt_differentiators.py`](../tests/test_noir_sbt_differentiators.py), [`test_noir_sbt_record_and_custom_method_extensions.py`](../tests/test_noir_sbt_record_and_custom_method_extensions.py) | Gates parser, resolution, direct-поведение Spring/JAX, record accessors и custom method annotations. |
| discovery и annotation views | [`test_noir_sbt_framework_auto.py`](../tests/test_noir_sbt_framework_auto.py), [`test_noir_sbt_annotation_log.py`](../tests/test_noir_sbt_annotation_log.py), [`test_noir_sbt_absent_annotation_log.py`](../tests/test_noir_sbt_absent_annotation_log.py), [`test_noir_sbt_method_annotation_line.py`](../tests/test_noir_sbt_method_annotation_line.py) | Marker selection, inventories, rendering diagnostics, represented targets и annotation-line evidence. |
| специализированные Spring surfaces | `tests/test_noir_sbt_spring_*.py` | Clients, configuration/resources, Gateway, hierarchy, registrations и messaging. |
| JAX-RS и Java WebSocket | `test_noir_sbt_jax_rs_direct.py`, `test_noir_sbt_jax_rs_deployment.py`, `test_noir_sbt_jax_rs_hierarchy_subresources.py`, `test_noir_sbt_java_websocket.py` | Direct resources, владение deployment, hierarchy/subresources, namespace rules и handshakes. |
| Сравнение Noir | [`test_noir_comparison.py`](../tests/test_noir_comparison.py), [`test_noir_comparison_cli.py`](../tests/test_noir_comparison_cli.py) | Валидация report, canonical locations, matching, rendering, naming и ошибки publication. |

## 5. Особенно важные invariants

| Invariant | Основное место regression |
|---|---|
| Script является только executable launcher; package code никогда его не импортирует. | `test_noir_architecture.py`, `test_noir_sbt_cli_black_box.py` |
| У parser packages/построения runtime один native owner; у parsing source один frontend owner. | `test_noir_architecture.py`, `test_noir_parse_once.py` |
| Каждый обнаруженный Java source читается и парсится один раз, затем повторно используется каждым выбранным pass. | `test_noir_parse_once.py`, `test_noir_pipeline.py` |
| Pipeline отклоняет output analyzer, если это не `EndpointFact`; semantic analyzer tests напрямую проверяют типизированные entry points. | `test_noir_pipeline.py` и каждый semantic analyzer test |
| Diagnostics ограничены run, и только CLI владеет publication artifacts и stdout. | `test_noir_application.py`, `test_noir_diagnostics.py`, `test_noir_sbt_cli_black_box.py` |
| Неоднозначные Java identity, constants, hierarchy, deployment или flow локально работают fail closed. | ближайший direct или специализированный analyzer test |
| Дублирующиеся facts детерминированно объединяют annotation evidence и represented targets. | `test_noir_domain_model.py`, `test_noir_output.py`, специализированные analyzer tests |
| Первые шесть полей CSV определяют identity строки; annotation line выбирается после merge evidence. | `test_noir_output.py`, `test_noir_sbt_method_annotation_line.py` |
| Успех CLI появляется только после publication всех запрошенных artifacts. | `test_noir_sbt_cli_black_box.py`, `test_noir_comparison_cli.py` |

## 6. Где должна находиться regression

| Изменение | Первое место теста | Добавьте ещё один layer, когда… |
|---|---|---|
| Валидация CLI, naming, publication или stdout | black-box или comparison CLI test | также изменилась внутренняя rendering logic |
| request/result или scope diagnostics | application/diagnostics test | также изменился порядок stages |
| discovery или auto markers | framework-auto test | изменяется output invocation |
| построение parser/query | frontend или parse-once test | изменяется cross-file resolution |
| imports, types, constants, access или ambiguity | differentiator или ближайший analyzer test | это потребляет более одной surface |
| direct semantics Spring или JAX | соответствующий direct analyzer test | участвует hierarchy/configuration |
| одна supplemental surface | соответствующий Spring/JAX/WebSocket test | изменяются public grouping или report evidence |
| владение evidence или deduplication | domain/output/method-line test | изменяются bytes artifact |
| Parsing или matching Noir report | comparison unit test | меняется порядок CLI или filesystem state |
| Dependency module или запрещённый effect | architecture test | semantic behavior также нужно продемонстрировать |

Полезная semantic regression сопоставляет одну принятую source shape с наиболее
похожей формой, которая должна сработать fail closed: shadowed import,
неоднозначная constant, unsupported placement, mixed namespace, cycle или
unresolved value.

## 7. Валидация

Используйте закреплённое окружение из [`src/requirements.txt`](../src/requirements.txt).

~~~bash
PYTHONDONTWRITEBYTECODE=1 \
  .venv/bin/python -m unittest discover -s tests -p 'test_noir*.py'

PYTHONDONTWRITEBYTECODE=1 \
  .venv/bin/python -m compileall -q src tests

git diff --check
~~~

Проверяйте skips: parser-backed tests могут быть пропущены, когда необходимая
пара dependencies недоступна.

## 8. Индекс «глава → код»

| Глава | Первая координата в коде |
|---|---|
| [Ментальная модель](01-mental-model.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [CLI и orchestration](02-cli-and-orchestration.md) | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` |
| [Общий Java engine](03-shared-java-engine.md) | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` |
| [Spring MVC](04-spring-mvc.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [Дополнительные Spring surfaces](05-spring-additional-surfaces.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `_analyze_spring()` |
| [JAX-RS](06-jax-rs.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Output и reports](07-output-evidence-reports.md) | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` |
| [Разобранные трассировки](08-worked-traces.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Production-использование](09-production-use.md) | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` |
| [Имена и словарь](11-naming-and-code-vocabulary.md) | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` |
| [Методы core runtime](12-core-runtime-methods.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Методы Spring](13-spring-methods.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Поиск методов](15-method-lookup.md) | поиск точного symbol по трём руководствам уровня методов |

Вернитесь к [оглавлению guide](README.md) или продолжите с
[именами и словарём кода](11-naming-and-code-vocabulary.md).
