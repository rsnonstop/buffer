# 02 — CLI and orchestration

[← Mental model](01-mental-model.md) · [Index](README.md) · [Shared Java engine →](03-shared-java-engine.md)

This chapter follows one invocation from arguments to immutable analysis
results and published artifacts. The central ownership rule is:

> `noir.pipeline` orders analysis; `noir.cli` owns user input, files, and
> stdout.

Method-level companion: [12 — Core runtime methods](12-core-runtime-methods.md)
expands this route into exact callers, values, effects, and failure exits.

Primary code coordinates:

- launcher: [`src/noir_sbt.py`](../src/noir_sbt.py);
- CLI: [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()`;
- typed application entry:
  [`src/noir/application.py`](../src/noir/application.py) :: `analyze()`;
- stage order: [`src/noir/pipeline.py`](../src/noir/pipeline.py) ::
  `run_analysis()`;
- values: [`src/noir/model.py`](../src/noir/model.py);
- discovery: [`src/noir/discovery.py`](../src/noir/discovery.py);
- diagnostics: [`src/noir/diagnostics.py`](../src/noir/diagnostics.py);
- projection and publication:
  [`src/noir/output.py`](../src/noir/output.py),
  [`src/noir/reports.py`](../src/noir/reports.py), and
  [`src/noir/comparison.py`](../src/noir/comparison.py).

## 1. Runtime route

`src/noir_sbt.py` imports `noir.cli.main` and exits with its status. It contains
no application logic.

~~~mermaid
flowchart LR
    U[CLI caller] --> L[src/noir_sbt.py]
    L --> CLI[noir.cli.run_cli]
    CLI --> APP[noir.application.analyze]
    APP --> PIPE[noir.pipeline.run_analysis]
    PIPE --> JAVA[shared Java workspace]
    JAVA --> PASS[Spring and JAX-RS passes]
    PASS --> FACT[EndpointFact values]
    FACT --> RESULT[AnalysisResult]
    RESULT --> OUT[projection and reports]
    OUT --> FILES[CSV and companion artifacts]
~~~

Package code never imports the launcher. Framework analyzers consume Java
facts, emit `EndpointFact` values, and record diagnostics. They do not parse
arguments, print, or publish files.

## 2. Typed application boundary

A programmatic call uses:

~~~python
from noir.application import analyze
from noir.model import AnalysisRequest

result = analyze(AnalysisRequest(source_root, framework_mode="spring"))
~~~

| Type | Role |
|---|---|
| `AnalysisRequest` | resolved analysis root and requested framework mode |
| `FrameworkPlan` | requested mode plus the effective ordered framework selection |
| `EndpointFact` | route, handler, protocol/surface metadata, and typed evidence |
| `AnalysisResult` | immutable endpoint facts, diagnostics, inventories, detections, and announcements |

`AnalysisRequest` expands and resolves its root and validates the requested
mode. Directory existence is checked by the CLI, not by the value type.

`run_cli()` uses the input directory basename when projecting endpoint facts
to CSV rows; output identity stays outside the application request.

`noir.application.analyze()` owns one diagnostic scope. It reuses a supplied
or already-bound collector when present, otherwise creates one. It records the
entry offset and attaches only diagnostics added by that invocation to the
returned `AnalysisResult`. Nested calls therefore do not claim earlier
messages from an outer call.

The application boundary performs no CLI parsing or artifact I/O.
`AnalysisRunner` is injectable only to keep this small boundary independently
testable; production uses `run_analysis`.

## 3. CLI contract

~~~text
usage: noir_sbt.py [-h] --path PATH --output OUTPUT
                   [--framework {spring,jaxrx,auto}]
                   [--noir-report NOIR_REPORT]
~~~

| Argument | Required | Meaning |
|---|---:|---|
| `--path` | yes | directory analyzed as one Java workspace |
| `--output` | yes | endpoint CSV destination |
| `--framework spring` | no | select only Spring |
| `--framework jaxrx` | no | select only JAX-RS |
| `--framework auto` | no | select from the narrow raw-text marker registry |
| omitted `--framework` | — | select Spring, then JAX-RS |
| `--noir-report` | no | compare a Noir v1.1 report with the broad annotation inventory by canonical source file and line |

`--path` is expanded, resolved, and required to be an existing directory.
`--output` expands `~` but is not resolved, so a relative destination remains
relative to the process working directory. Parent directories are not created.

`--noir-report` is expanded, resolved, and required to be an existing file.
The CLI loads and validates it before creating or truncating output. It rejects
invalid JSON or report shapes, invalid line values, ambiguous source-path
interpretations, and an input that is the same filesystem file as any derived
output destination.

Noir source locations without a line do not participate in comparison. A
present line must be a positive non-Boolean integer. Relative source names are
resolved against the analysis root; ambiguous retained-root-prefix spellings
fail closed. The detailed comparison rules are in
[07 — Output, evidence, and reports](07-output-evidence-reports.md).

Argument-parser construction is dependency-light, so `--help` works without
the Tree-sitter packages installed.

## 4. Analysis order

[`noir/pipeline.py`](../src/noir/pipeline.py) owns this one-way sequence:

~~~mermaid
flowchart TD
    R[AnalysisRequest] --> Gate[1. Validate Tree-sitter pair]
    Gate --> Snap[2. Discover and snapshot Java bytes]
    Snap --> Select[3. Select frameworks]
    Select --> Work[4. Build one runtime and workspace]
    Work --> Audit[5. Build broad annotation inventory]
    Audit --> Trigger[6. Build final-trigger inventory when selected]
    Trigger --> Deploy[7. Build JAX-RS deployment model when selected]
    Deploy --> Spring{Spring selected?}
    Spring -- yes --> SP[8. Run ordered Spring passes]
    Spring -- no --> JAX
    SP --> JAX{JAX-RS selected?}
    JAX -- yes --> JP[9. Run ordered JAX-RS passes]
    JAX -- no --> Result[10. Validate facts and return AnalysisResult]
    JP --> Result
~~~

`require_tree_sitter()` accepts exactly:

~~~text
tree-sitter      0.25.2
tree-sitter-java 0.23.5
~~~

A missing or different pair raises `RuntimeError`.

`_snapshot_sources()` discovers Java filenames case-insensitively by `.java`
suffix, prunes configured ignored directories, sorts by project-relative name,
and reads each file once as bytes. `SourceSnapshot` requires its path tuple and
content keys to match exactly and exposes immutable content.

`_build_workspace()` constructs one parser/query runtime and parses every
snapshotted file once. The Spring direct loop calls
`analyze_direct_spring_mvc_unit(unit, workspace)` and the JAX-RS direct loop
calls `analyze_direct_jax_rs_unit(unit, workspace)`; project-wide analyzers
reuse that same workspace.

### Spring pass order

1. direct MVC for each source;
2. functional routes and programmatic registrations;
3. MVC hierarchy;
4. Gateway;
5. static resources;
6. HTTP Interface and OpenFeign clients;
7. build project path configuration;
8. WebSocket handshakes and messaging destinations;
9. apply project path configuration to all Spring facts.

### JAX-RS pass order

1. direct resources for each compilation unit;
2. hierarchy and recursive subresources;
3. Java WebSocket server handshakes.

In a combined run, the complete Spring sequence finishes before direct JAX-RS
analysis begins. Project-wide passes are skipped when there are no compilation
units.

Every analyzer result must be an `EndpointFact`. `run_analysis()` raises
`TypeError` before constructing the result if any analyzer violates that
contract.

## 5. Framework selection and announcements

For omitted and explicit modes, marker scanning does not run.

| Requested mode | Effective ordered selection | Announcements |
|---|---|---|
| omitted | Spring, JAX-RS | `Found SpringBoot Annotation`; `Found JaxRS` |
| `spring` | Spring | `Found SpringBoot Annotation` |
| `jaxrx` | JAX-RS | `Found JaxRS` |
| `auto` | families selected by marker rules | one line per distinct finding, in registry order |

`auto` scans snapshotted Java bytes and separately discovered `pom.xml` files.
Java files are not read a second time.

| Finding | Input | Selects a family? |
|---|---|---|
| SpringBoot Annotation | Spring MVC or functional-router Java marker | Spring |
| SpringBoot Route | functional-router Java marker | no |
| SpringBoot Codegen | Maven generator marker | no; announcement includes a generated-source hint |
| Apache Wicket | Java marker | no |
| JaxRS | `jakarta.ws.rs` or `javax.ws.rs` Java marker | JAX-RS |

The scan is raw, case-sensitive text and includes comments and string literals.
It is selection evidence, not semantic endpoint proof. It may select from
non-code text and can miss supported surfaces whose package markers are
absent. Omitting `--framework` is the broadest run.

Every finding/file occurrence is recorded as a diagnostic. Announcements are
stored in `AnalysisResult` and follow registry order. The CLI prints them after
analysis succeeds but before projection and publication. A later failure can
therefore leave `Found ...` output without the final completion inventory.

If `auto` selects no family, the pipeline still validates dependencies, builds
the snapshot, workspace, and broad annotation inventory, and returns no
endpoints. The CLI publishes a header-only CSV, its log, and an empty
endpoint-trigger report.

## 6. Diagnostics

[`noir/diagnostics.py`](../src/noir/diagnostics.py) owns:

- `DiagnosticCollector`: thread-safe in-memory entries with an injected clock;
- `bind()`: scoped selection with guaranteed restoration;
- `record()`: append to the selected collector, or do nothing when none is
  selected;
- `format_endpoint_diagnostic()`: stable accepted-endpoint message formatting.

The CLI binds one collector around analysis, rendering, and publication and
records the framework-mode line before analysis. The companion log contains
the annotation-audit inventory first, followed by timestamped collector lines.

Collector selection is task/thread-local and is restored on normal return and
on exceptions. A nested application call returns only entries added during
that call; the enclosing collector still retains messages recorded while its
run was active. `AnalysisDiagnostic` itself has no timestamp; timestamping
belongs to `DiagnosticEntry` for report presentation.

## 7. Artifact order

After analysis, `run_cli()` performs these operations:

1. project every `EndpointFact` to an `EndpointRowCandidate`;
2. normalize and consolidate rows, merging private evidence;
3. render the endpoint-trigger report;
4. when enabled, compare the broad annotation inventory with Noir and render
   the comparison report;
5. render the completion inventory in memory;
6. write the CSV directly;
7. write the diagnostic log directly;
8. atomically replace the endpoint-trigger report;
9. atomically replace the Noir comparison report when enabled;
10. print the completion inventory and return `0`.

~~~mermaid
flowchart TD
    A[validate arguments and optional Noir input] --> L[create or truncate diagnostic log]
    L --> B[bind collector and analyze]
    B --> C[print framework announcements]
    C --> D[project and consolidate]
    D --> E[render reports and completion text]
    E --> F[write CSV]
    F --> G[write diagnostic log]
    G --> H[publish endpoint-trigger report]
    H --> I{comparison enabled?}
    I -- yes --> J[publish comparison report]
    I -- no --> K[print completion inventory]
    J --> K
~~~

The completion line `noir-ts analysis completed.` appears only after every
requested publication succeeds. It is never printed for analysis, projection,
rendering, or write failures.

### Artifact names

| `--output` | Diagnostic log | Endpoint-trigger report | Noir comparison report |
|---|---|---|---|
| `endpoints.csv` | `endpoints.csv.log` | `endpoints-anno-without-endpoints.log` | `endpoints-anno-without-noir-endpoints.log` |
| `endpoints.audit.csv` | `endpoints.audit.csv.log` | `endpoints.audit-anno-without-endpoints.log` | `endpoints.audit-anno-without-noir-endpoints.log` |
| `endpoints` | `endpoints.log` | `endpoints-anno-without-endpoints.log` | `endpoints-anno-without-noir-endpoints.log` |

Only the final suffix is removed when either byte-report name is derived. A run
without `--noir-report` neither creates nor removes an earlier comparison
artifact.

The CSV and diagnostic log are direct writes. Each byte report is rendered
fully, staged beside its destination, flushed and `fsync()`ed, then installed
with `os.replace()`. Byte-report publication cleans up staging state after
failures but does not roll back files already published.

## 8. Failure boundaries

The artifact set is ordered but is not one filesystem transaction.

| Failure point | Observable state |
|---|---|
| help, argument error, invalid input directory, or invalid Noir input | no artifact is initialized |
| diagnostic-log initialization | the log may fail or be truncated; other artifacts are unchanged |
| controlled analysis `RuntimeError` | CSV and byte reports remain unchanged; log is rendered with `ERROR:`; argparse exits `2` |
| other analysis, projection, comparison, or render failure | CSV and byte reports remain unchanged; log is rewritten best effort; original exception is re-raised |
| CSV write failure | CSV may be partial; log is rewritten best effort; byte reports are unchanged |
| diagnostic-log write failure | the new CSV remains; byte reports are unchanged |
| endpoint-trigger publication failure | new CSV and log remain; prior byte reports remain |
| comparison publication failure | new CSV, log, and endpoint-trigger report remain; prior comparison report remains |
| success | all requested outputs are complete; completion inventory is printed |

`SystemExit`, `KeyboardInterrupt`, and other `BaseException` subclasses do not
enter the general `except Exception` recovery branch. The controlled
`RuntimeError` path writes its log explicitly before using argparse's error
exit.

The completion inventory lists generated artifacts using effective output
spellings and identifies the resolved Noir report separately as input. Its
exact wording is owned by `render_completion_summary()` and tested at the CLI
boundary.

Continue with [03 — Shared Java engine](03-shared-java-engine.md).
