# 09 — Production use and risk controls

[← Worked traces](08-worked-traces.md) · [Index](README.md) · [Next: Code map →](10-code-map.md)

Noir is a conservative source-evidence producer. It does not start the Java
application, load arbitrary dependency bytecode, evaluate every framework
extension, or inspect deployed networking and security. A governed run must
review all produced artifacts together and reconcile them with an independent
build or runtime view.

## 1. What a row proves

A CSV row means:

> For this input root, the snapshotted Java bytes, supported non-Java inputs,
> pinned parser, and implemented bounded static rules proved an endpoint fact;
> the output layer then attributed, normalized, and grouped it into a public
> row.

A row does not prove that:

- the route is active in the deployed profile;
- its owner becomes a bean, resource, servlet, or proxy;
- the route is reachable through hosts, gateways, policy, or security;
- every runtime route appears in the CSV;
- every framework request condition is represented in row identity;
- the handler is authorized, safe, or correctly implemented.

~~~mermaid
flowchart LR
    SOURCE["Noir source evidence"] --> REVIEW["production reconciliation"]
    BUILD["build, generated source, dependencies"] --> REVIEW
    RUNTIME["runtime route inventory"] --> REVIEW
    DEPLOY["proxy, servlet, broker, deployment data"] --> REVIEW
    REVIEW --> REGISTER["reviewed endpoint register"]
~~~

Neither source analysis nor runtime observation should silently override the
other. Differences are evidence to classify.

## 2. Current production flow

~~~mermaid
flowchart TB
    SCRIPT["src/noir_sbt.py<br/>thin launcher"] --> CLI["noir.cli.run_cli<br/>validation and publication"]
    CLI --> APP["noir.application.analyze<br/>typed run and diagnostic scope"]
    APP --> PIPE["noir.pipeline.run_analysis<br/>snapshot and pass order"]
    PIPE --> RUNTIME["noir.tree_sitter_runtime<br/>version gate"]
    PIPE --> WORK["noir.java_workspace<br/>one shared parse/index workspace"]
    WORK --> PASSES["selected family facades"]
    PASSES --> RESULT["immutable AnalysisResult"]
    RESULT --> OUTPUT["noir.output<br/>projection and consolidation"]
    RESULT --> REPORTS["noir.reports<br/>companion artifacts"]
    NOIR["optional Noir v1.1 JSON"] --> COMPARE["noir.comparison"]
    COMPARE --> CLI
    OUTPUT --> CLI
    REPORTS --> CLI
~~~

Stable owners:

- [`noir.cli.run_cli`](../src/noir/cli.py) owns arguments, destinations,
  publication order, failure reporting, and stdout.
- [`noir.application.analyze`](../src/noir/application.py) owns one typed call
  and attaches only that call's diagnostics.
- [`noir.pipeline.run_analysis`](../src/noir/pipeline.py) owns dependency
  validation, source snapshotting, framework selection, workspace construction,
  inventories, and analyzer order.
- [`noir.java_frontend`](../src/noir/java_frontend.py) and
  [`noir.java_workspace`](../src/noir/java_workspace.py) own parsing and shared
  source indexes.
- Framework modules consume compilation units or the shared workspace and emit
  `EndpointFact` values directly.
- [`noir.output`](../src/noir/output.py) owns the deliberate lossy CSV boundary.
- [`noir.reports`](../src/noir/reports.py) and
  [`noir.comparison`](../src/noir/comparison.py) own companion rendering and
  comparison semantics.

Analysis has no artifact I/O. The launcher contains no application logic.

## 3. Reproducible environment

The pipeline calls
[`require_tree_sitter()`](../src/noir/tree_sitter_runtime.py) before source
discovery. The accepted pair is exact:

~~~text
tree-sitter      == 0.25.2
tree-sitter-java == 0.23.5
~~~

Missing package metadata, missing bindings, or a different pair raises a
controlled `RuntimeError`, including for an empty source root. Build an
isolated environment from
[`src/requirements.txt`](../src/requirements.txt); do not upgrade only one
parser package without revalidation.

Retain with each controlled run:

- analyzer commit;
- Python environment or container digest;
- application/build commit and generated-source state;
- exact invocation, resolved analysis root, requested framework policy, and
  effective registry-ordered selection;
- relevant property, YAML, descriptor, and profile inputs;
- hashes of every produced artifact.

The broad log contains timestamps, so its hash identifies one run rather than
an expected byte-for-byte rerun result.

## 4. Framework-selection policy

### 4.1 Prefer the broad default

Omitting `--framework` runs Spring, then JAX-RS:

~~~bash
python3 src/noir_sbt.py \
  --path "/absolute/path/to/application" \
  --output "/absolute/path/to/staging/endpoints.csv"
~~~

Use `--framework spring` or `--framework jaxrx` only when application ownership
has established that the excluded family is irrelevant. Repeat the option when
the governed scope needs a specific combination, for example
`--framework spring --framework wicket`. Duplicate values and mixed
`auto`/explicit requests are invalid. The accepted JAX-RS token is `jaxrx`.
Explicit Wicket selection currently exercises an empty integration lifecycle
and must not be treated as a Wicket endpoint inventory. Registry order, rather
than option order, controls configuration, announcements, inventories, and
analysis.

### 4.2 Treat `auto` as a convenience mode

`--framework auto` scans the Java snapshot with raw, case-sensitive markers
and also inspects exact `pom.xml` files. It can select an analyzer because text
appears in a comment or string, and it can miss a framework whose supported
marker never appears. Code-generation and Wicket findings are announcements;
they do not select an analyzer.

Wicket also appears in the static execution table with a real
`FrameworkSelection.WICKET` identity. That makes it an explicit CLI mode, but
`default_selected=False` excludes it from omitted mode and its manual marker
rule excludes it from auto selection. Its hooks currently perform no semantic
work and return no facts. The separate marker registry remains the authority
for the advisory finding.

Auto selection is not a completeness control. Record the marker findings and
justify its use when the result is production governed.

## 5. Freeze the right input

### 5.1 Choose one deployable application

The root should include every source relationship needed by the static model:

- cross-file string constants;
- source-defined composed or custom annotations;
- controller/resource interfaces and superclasses;
- locator target types and JAX-RS application classes;
- `web.xml` descriptors;
- supported Spring properties and YAML;
- every source module packaged into the deployment.

A narrow root creates false negatives. A broad monorepo root can create
duplicate FQNs, conflicting configuration/application facts, excess memory
use, and unrelated deployable-looking source. One deployable application plus
its included source modules is the usual analysis unit.

### 5.2 Materialize generated source deliberately

Generated Java is visible only when it exists below the root and outside a
pruned directory. Common build destinations such as `build`, `target`, and
`out` are ignored. Copy required generated source into an included staging
tree, or analyze its delivered source separately and document the relationships
lost by splitting the run. Record generator version and inputs.

### 5.3 Understand snapshot timing

[`SourceSnapshot`](../src/noir/pipeline.py) retains every discovered Java path
and its exact bytes. Marker selection, workspace construction, inventories, and
all selected analyzers use those bytes. Each file is parsed once and its
compilation unit is shared; direct Spring receives
`analyze_direct_spring_mvc_unit(unit, workspace)`, and direct JAX-RS receives
`analyze_direct_jax_rs_unit(unit, workspace)`.

`pom.xml`, Spring configuration, and `web.xml` are read by their owning stages,
not included in the Java snapshot. Run against an immutable checkout so these
inputs cannot change mid-analysis.

~~~mermaid
sequenceDiagram
    participant Gate as parser gate
    participant Snap as Java snapshot
    participant Work as shared workspace
    participant Pass as analyzers
    Gate->>Snap: supported runtime only
    loop deterministic Java paths
        Snap->>Work: fixed bytes, one parse
    end
    Work->>Pass: shared units and indexes
~~~

### 5.4 Keep Noir comparison input aligned

`--noir-report` compares potential endpoint-trigger annotations from the
final-trigger inventory with Noir v1.1 endpoint locations by exact canonical
source path and positive one-based line. Generate the report from the same
source revision and layout. A moved file or inserted line can turn matching
evidence into an apparent difference.

The loader reads `endpoints[*].details.code_paths[*]`, validates present line
values, resolves supported relative-path forms, and rejects ambiguous existing
path interpretations. Missing lines are valid but provide no comparable
location. Invalid input is rejected before output publication begins.

The comparison result is a trigger-location audit, not an endpoint
false-negative list. It excludes supporting activation, path-modifier, media,
parameter-binding, and other non-trigger annotations. A trigger can still fail
later endpoint conditions, so an unmatched occurrence does not by itself prove
that Noir missed a reachable endpoint. Same-line triggers are indistinguishable
because the Noir location has no annotation identity.

## 6. Deterministic and fail-closed behavior

With identical inputs and supported dependencies:

- Java discovery and analyzer roots use stable ordering;
- source bytes, trees, and query lifetimes remain owned by one workspace;
- import conflicts and duplicate source identities remain ambiguous;
- type, constant, annotation, hierarchy, and deployment consumers require
  uniquely provable evidence;
- bounded evaluators return unresolved instead of executing Java;
- CSV groups sort by the normalized six-field public identity;
- the final-trigger report sorts source evidence and has no timestamps.

Fail closed means that an unproved candidate normally emits no fact. It does
not mean the entire source file must compile. The implementation does not
reject every file whose Tree-sitter root reports an error; a recovered subtree
that matches a supported shape can still produce evidence. Treat parsed but
noncompiled source as a review risk.

Typical local rejection causes include conflicting imports, shadowed
constants, duplicate FQNs, incomplete or cyclic hierarchies, ambiguous
deployment prefixes, unsupported data flow, and exceeded semantic bounds.

Diagnostics are ordered timestamped events. CSV and final-trigger bytes may be
stable while the diagnostic log differs by clock or event interleaving.

## 7. Nested calls and concurrency

[`noir.application.analyze`](../src/noir/application.py) accepts an immutable
`AnalysisRequest` and optionally a run-owned `DiagnosticCollector`.
[`noir.diagnostics.bind`](../src/noir/diagnostics.py) isolates nested bindings,
and collector entries are lock protected.

For simultaneous embedded runs, use:

- one request, workspace, parser runtime, and collector per run;
- immutable input trees;
- distinct artifact destinations when a caller later publishes results.

Do not share one collector across simultaneous analyses: its event stream can
interleave, and one result could claim another run's new entries. For CLI
parallelism, separate processes are the simplest memory and stdout boundary.
Never let two invocations write the same destinations.

## 8. Artifact publication is ordered, not transactional

The output parent must already exist. Relative output paths are resolved by the
calling process. The CLI can overwrite existing artifacts; in comparison mode
it prevents the supplied Noir report from also being any output destination,
including a hard-link alias.

For `endpoints.csv`, the baseline files are:

~~~text
endpoints.csv
endpoints.csv.log
endpoints-anno-without-endpoints.log
~~~

With `--noir-report`, it also writes:

~~~text
endpoints-anno-without-noir-endpoints.log
~~~

Publication order in [`run_cli()`](../src/noir/cli.py) is:

1. validate the input directory and optional Noir report;
2. create or truncate the broad `.log`;
3. analyze, project typed facts, consolidate rows, and render report payloads;
4. write the BOM-prefixed semicolon CSV;
5. write the broad annotation/diagnostic log;
6. atomically replace the final-trigger report;
7. atomically replace the comparison report when requested;
8. print the completion inventory and return 0.

The files are not one atomic transaction. Important failure states are:

| Failure point | Observable state |
|---|---|
| invalid input or invalid Noir report | existing outputs untouched |
| controlled analysis error | prior CSV/reports remain; broad log contains current error diagnostics |
| unexpected analysis or rendering error | prior CSV/reports remain; broad log is updated best effort |
| CSV write | CSV may be partial; broad log is updated best effort; atomic reports remain prior versions |
| broad-log write | current CSV may exist; atomic reports remain prior versions |
| final-trigger publication | current CSV and broad log exist; prior final-trigger report is preserved when replacement fails |
| comparison publication | current CSV, broad log, and final-trigger report exist; prior comparison report is preserved when replacement fails |

`publish_bytes_atomically()` stages beside the destination, flushes, `fsync`s,
closes, and calls `os.replace`; it cleans its staging file on failure when
possible. Each call protects one report only. Completion stdout is printed
only after the last requested publication succeeds.

Use a fresh staging directory, verify the whole artifact set, complete review,
then publish that directory as one release controlled by the surrounding
automation. Do not consume the CSV while the process is still running.

## 9. Preflight checklist

Before a controlled run, confirm:

- [ ] the root is the intended deployable application's source tree;
- [ ] required generated Java has been materialized in included paths;
- [ ] the exact parser pair is installed;
- [ ] Java and non-Java inputs will remain unchanged;
- [ ] the output parent exists and is a fresh staging location;
- [ ] the framework choice is broad or its restriction is justified;
- [ ] any Noir report comes from the same revision and layout;
- [ ] required Spring configuration and JAX-RS descriptors are present;
- [ ] ignored directory names do not hide deployed source;
- [ ] files use readable expected encodings;
- [ ] memory and time budgets cover the whole workspace;
- [ ] no other process writes the same paths.

[`IGNORED_SOURCE_DIRECTORIES`](../src/noir/contracts.py) contains exact
basenames for dependency, version-control, build-output, cache, editor,
virtual-environment, temporary, generated-output, and other non-production
trees.

Any directory with one of those exact basenames is pruned wherever it occurs.
Java suffix matching is case-insensitive. Auto-mode Maven discovery requires
the exact lowercase filename `pom.xml`.

Unreadable Java aborts snapshot construction. Invalid UTF-8 can abort marker
selection or later decoding. Treat readability and encoding as input gates.

## 10. Post-run review gates

### Gate 1: structural validity

- Exit status is zero.
- CSV begins with a UTF-8 BOM, uses semicolons and CRLF records, and has exactly
  seven columns plus a header even when empty.
- Both baseline companion paths exist; comparison output exists when requested.
- Completion stdout names every artifact from this run.
- `module_name` equals the resolved input-root basename.
- source paths belong to the intended module inventory.

### Gate 2: mode and surface sanity

Read the framework-mode diagnostic. Count rows separately for inbound HTTP,
Gateway, static handlers, outbound clients, WebSocket handshakes, and message
`SEND`/`SUBSCRIBE` destinations. Do not treat every row as an exposed inbound
server route.

### Gate 3: diagnostics and unrepresented triggers

Give every nonempty final-trigger entry a disposition, such as unsupported
form, dead source, missing input, analyzer defect, or deployment ambiguity.
Search diagnostics for at least `ERROR`, `Skipped`, `unresolved`, `ambiguous`,
`invalid`, `limit`, `cycle`, `duplicate`, `mixed`, and configuration failures.
No diagnostic is not automatic approval.

In comparison mode, review unmatched potential endpoint triggers separately
from the broad annotation inventory in `endpoints.csv.log`. Account for
line-less Noir paths, later noir-ts endpoint gates, and same-line
indistinguishability before drawing coverage conclusions.

### Gate 4: independent reconciliation

Compare normalized surface/direction, method, and path against one or more of:

- Spring runtime mappings or another independently observed route inventory;
- JAX-RS implementation introspection;
- OpenAPI from the deployed build;
- Gateway, servlet, or broker configuration;
- generated route manifests.

Classify both directions:

~~~text
runtime only -> static false negative, missing source/dependency, dynamic route, or root mismatch
static only  -> inactive profile/owner, static approximation, dead source, or deployment mismatch
~~~

### Gate 5: sampled source traces

For every present surface, trace representative rows through the documented
rules. Include a normalized path, inherited or composed route,
configuration-prefixed route, and blank `method_annotation_line` when
available.

## 11. Expected gaps

### Possible static-only rows

- direct Spring MVC does not prove controller activation;
- Spring type and method request conditions use an ordered union;
- profiles, conditional owners, scanning, and runtime feature flags are not
  evaluated;
- dead, excluded, or noncompiled Java below the root can be parsed;
- CSV identity omits headers, media negotiation, filters, and security;
- source configuration can differ from deployed resources;
- a static-resource pattern does not prove its backing resource exists;
- parser recovery can recognize a supported subtree in invalid source.

### Possible missing runtime rows

- source is ignored, outside the root, generated later, or dependency-only;
- a type, annotation, constant, import, hierarchy, or deployment identity is
  not uniquely provable;
- registration is dynamic, reflective, conditional, or uses unsupported DSL
  shapes;
- a hierarchy is incomplete, duplicated, cyclic, incompatible, or over bound;
- a locator returns an external, interface, or dynamic target;
- JAX-RS application/package/servlet association is absent or ambiguous;
- Javax and Jakarta evidence is mixed;
- Spring properties, YAML, profiles, or data flow exceed the bounded model;
- auto mode does not select the needed analyzer;
- syntax damage prevents the required query shape.

The final-trigger report covers recognized annotation triggers. It cannot list
every possible dynamic registration call.

## 12. Scale and semantic bounds

The workspace retains every Java source byte array, syntax tree, query lifetime
owner, and cross-file index. Inventories and endpoint candidates coexist until
presentation. There is no whole-run file-count or byte-size cap, so analyze one
deployable application at a time where practical.

Current branch limits include:

| Model | Bound |
|---|---:|
| Java/Spring string expression depth and length | 12 / 8192 characters |
| Java hierarchy depth and states | 12 / 256 |
| Spring placeholder substitutions and configured path length | 100 / 8192 characters |
| Spring functional nesting, chain steps, and routes | 16 / 256 / 4096 |
| JAX-RS subresource depth, states, and composed path | 16 / 4096 / 8192 characters |
| one discovered `web.xml` | 10 MiB |

Exceeding a semantic bound rejects that branch; it does not reduce memory
already retained by the workspace.

## 13. Security and data handling

The broad log and both final-trigger-based reports can contain an annotation
plus following source lines. CSV rows contain internal paths, handler names,
and raw parameter spelling. Treat artifacts at the repository's access
classification:

- avoid public CI attachments by default;
- apply retention and redaction policy before sharing;
- inspect logs with a viewer that does not execute terminal escapes or links;
- verify downstream file permissions;
- never infer authorization posture from endpoint presence.

CSV cells beginning with `=`, `+`, `-`, or `@` are not neutralized. Import the
CSV as text or sanitize a downstream copy before opening it in a spreadsheet.

The analyzer does not assess authentication, authorization, CSRF, filters,
validation, rate limiting, sensitive-data flow, or exploitability.

## 14. Safe extension rules

When adding coverage:

1. Put the complete family sequence behind its three facade hooks and add one
   static [`FrameworkAdapter`](../src/noir/frameworks.py); keep
   [`noir.pipeline`](../src/noir/pipeline.py) generic.
2. Reuse compilation units and indexes from the shared workspace; do not parse
   Java inside a feature module.
3. Keep framework-neutral parsing and name rules in `java_frontend`,
   `java_workspace`, `java_ast`, `java_methods`, or `java_hierarchy`; keep
   Spring/JAX-RS meaning in framework modules.
4. Emit `EndpointFact` values with route, handler, project, annotation, and
   represented-target evidence.
5. Bound exploration and reject ambiguous evidence instead of guessing.
6. Record candidate failures through [`noir.diagnostics.record`](../src/noir/diagnostics.py).
7. Keep public projection in [`noir.output`](../src/noir/output.py), report
   rendering in [`noir.reports`](../src/noir/reports.py), and filesystem order
   in [`noir.cli`](../src/noir/cli.py).
8. Re-read the owning analyzer, shared proof helpers, output projection, and
   CLI boundary when those responsibilities change.

The complete maintainer sequence, using the selectable Wicket stub as the
worked example, is [16 — Adding framework support](16-adding-framework-support.md).

## 15. Release record and go/no-go rule

Retain at least:

~~~text
Analyzer commit/version:
Python/parser environment digest:
Application/build commit and generated-source state:
Analysis root, requested framework policy, and effective selection:
Artifact hashes and staging publication ID:
CSV counts by surface and method:
Final-trigger dispositions:
Noir comparison input/version and dispositions, if used:
Diagnostic dispositions:
Runtime/static reconciliation summary:
Accepted gaps, owners, and expiry:
Approval date:
~~~

Use the result as a governed endpoint register only when the run is
reproducible, all expected artifacts belong to one successful staging run,
every material diagnostic and unrepresented trigger has a disposition, and
differences against an independent inventory are explained. Otherwise it
remains useful audit evidence, not a production-complete inventory.

Next: [10 — Code map](10-code-map.md).
