# 03 — Shared Java engine

[← CLI and orchestration](02-cli-and-orchestration.md) · [Index](README.md) · [Spring MVC →](04-spring-mvc.md)

The Java engine is the framework-neutral evidence layer below Spring, JAX-RS,
WebSocket, Gateway, client, and registration analysis. It parses source and
answers bounded Java questions; it does not decide that a construct is an
endpoint.

Its central rule is:

> One run snapshots every discovered Java source, parses each source once, and
> gives every selected analyzer the same compilation units and workspace
> indexes.

Method-level companion: [12 — Core runtime methods](12-core-runtime-methods.md)
maps the parser, unit builders, resolvers, indexes, and hierarchy methods by
exact symbol name.

## 1. Ownership

~~~mermaid
flowchart TB
    P[noir.pipeline<br/>snapshot and order] --> R[tree_sitter_runtime<br/>version gate and runtime]
    P --> W[java_workspace<br/>one shared workspace]
    R --> W
    W --> F[java_frontend<br/>compilation units]
    W --> A[java_ast<br/>small syntax proofs]
    W --> M[java_methods<br/>method indexes]
    W --> H[java_hierarchy<br/>type graph]
    W --> S[Spring interpretation]
    W --> J[JAX-RS interpretation]
    A --> S
    M --> S
    H --> S
    H --> J
~~~

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.pipeline`](../src/noir/pipeline.py) | `SourceSnapshot`, `_snapshot_sources()`, `_build_workspace()` | immutable input and its place in stage order |
| [`noir.tree_sitter_runtime`](../src/noir/tree_sitter_runtime.py) | `require_tree_sitter()`, `build_workspace_runtime()`, `run_query_matches()` | supported parser pair, parser/query construction, and cursor lifetime policy |
| [`noir.java_queries`](../src/noir/java_queries.py) | `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | complete framework-neutral query sources |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `parse_java_query_set()`, `build_java_compilation_unit()` | one-file syntax products and same-file facts |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace()`, `resolve_workspace_owner_fqns()`, `resolve_workspace_string_expression()` | cross-file declarations, access, and bounded resolution |
| [`noir.java_ast`](../src/noir/java_ast.py) | `field()`, `walk_named()`, `known_type()`, `is_direct_invocation_statement()` | reusable syntax proofs |
| [`noir.java_methods`](../src/noir/java_methods.py) | `MethodFact`, `MethodIndex`, `build_strict_method_index()`, `build_varargs_method_index()` | bounded method and invocation facts |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaSourceHierarchyGraph` | source type graph, generic substitution, signatures, and inheritance |

The neutral modules do not classify Spring or JAX-RS annotations. Framework
modules import these helpers directly and add route meaning only after Java
identity is proven.

## 2. Snapshot and parser runtime

`_snapshot_sources()` discovers Java files in deterministic project-relative
order, reads each exactly once, and constructs `SourceSnapshot`:

| Field | Meaning |
|---|---|
| `paths` | ordered tuple of source-path strings |
| `content` | read-only path-to-byte-content view with exactly the same keys |

Construction rejects any path/content mismatch. Marker selection, workspace
construction, and direct-pass order all consume this same snapshot. A source
change on disk after snapshotting cannot split one run into two byte views.

Before discovery, `require_tree_sitter()` accepts exactly:

| Distribution | Supported version |
|---|---:|
| `tree-sitter` | `0.25.2` |
| `tree-sitter-java` | `0.23.5` |

Missing bindings, missing package metadata, or another version pair stops
analysis before parsing.

`build_workspace_runtime()` creates one Java language, one parser, and the
complete named query set. Query sources are compiled in deterministic name
order. The workspace query set captures:

- package and import declarations;
- classes, interfaces, enums, records, and annotation declarations;
- fields, interface constants, and enum constants;
- annotations on types, methods, and record components;
- all annotation occurrences used by inventories;
- annotation meta-annotations, elements, and defaults;
- record methods.

`JAVA_COMPILATION_UNIT_QUERY_SOURCES` is the per-file base;
`JAVA_WORKSPACE_QUERY_SOURCES` adds the captures needed by project-wide
resolution.

## 3. Exactly one parse per source

~~~mermaid
sequenceDiagram
    participant Pipeline as noir.pipeline
    participant Runtime as tree_sitter_runtime
    participant Workspace as java_workspace
    participant Frontend as java_frontend
    participant Parser as Tree-sitter
    participant Passes as framework passes

    Pipeline->>Runtime: build_workspace_runtime()
    Pipeline->>Workspace: build_java_workspace(snapshot content)
    loop each source path in sorted order
        Workspace->>Frontend: build_java_compilation_unit(bytes)
        Frontend->>Parser: parse(bytes)
        Parser-->>Frontend: syntax tree
        Frontend->>Frontend: execute compiled queries
        Frontend-->>Workspace: compilation unit
    end
    Workspace->>Workspace: build cross-file indexes
    Workspace-->>Pipeline: shared workspace
    Pipeline->>Passes: reuse units and indexes
~~~

In the application path there is one parser call per snapshotted source.
Direct Spring receives `analyze_direct_spring_mvc_unit(unit, workspace)` and
direct JAX-RS receives `analyze_direct_jax_rs_unit(unit, workspace)`.
Project-wide passes receive the same workspace. No framework analyzer creates a
parser or reparses source.

`build_java_workspace()` can accept already-parsed trees for lower-level
callers. For supplied paths it adopts those trees, then derives the same
compilation-unit and workspace facts.

## 4. Compilation-unit facts

`build_java_compilation_unit()` retains the complete per-file evidence needed
by later passes:

| Field group | Contents |
|---|---|
| identity | source path, exact bytes, package name |
| syntax lifetime | tree, query matches, cursor/result owners |
| imports | exact and wildcard type imports; exact and wildcard static imports |
| types | lexical type records, local type names, package collision facts |
| declarations | raw field, interface-constant, and enum captures consumed by workspace indexes |
| annotations | all occurrences, declarations, meta-annotations, elements, and defaults |
| route candidates | grouped type, method, and record-component captures |
| records | explicit zero-parameter accessor facts |

A complete Tree-sitter match is the association unit. Captures from unrelated
matches are never combined only because they share a capture name.

The engine does not reject an entire file merely because the syntax root
contains a recovered error. A recovered subtree that satisfies a query may
still contribute evidence; later resolvers reject malformed or ambiguous
shapes locally.

### Type visibility

Each named type records its simple and lexical names, outer type, declaration
node, abstract flag, and whether it can participate in workspace lookup.

- top-level types are visible to the workspace;
- member types are visible when their outer chain is visible;
- types inside methods, constructors, lambdas, blocks, and initializers affect
  lexical shadowing but do not become workspace identities.

Node byte ranges are unique only within one compilation unit. Cross-file
records retain their owning unit or source path.

### Tree and query lifetime

Indexes keep Tree-sitter nodes, so their owners must remain alive. A compilation
unit retains:

- its syntax tree;
- every query cursor and raw match result that produced stored nodes;
- the source bytes used by node byte ranges.

The workspace retains all compilation units. Any project-wide record that
retains a node also retains its unit identity.

## 5. Cross-file indexes

After all units exist, `build_java_workspace()` derives facts that cannot be
settled from one file:

~~~mermaid
flowchart LR
    U[Compilation units] --> P[package type names]
    U --> T[type declarations by FQN]
    U --> M[member declarations]
    U --> S[static member declarations]
    U --> C[String constants by owner and member]
    U --> A[source annotation declarations]
~~~

Important distinctions:

- every declaration for a fully qualified type name is retained; duplicates
  remain ambiguous;
- member declarations are retained even when they cannot provide a String
  value, because they can shadow imported members;
- constant records retain modifier, initializer, owner, unit, and access
  evidence;
- static member declarations include enum constants, so wildcard ambiguity is
  visible;
- source annotation declarations are neutral identities until a framework
  proves their meaning.

Sources and records are processed in deterministic source order. Consumers
that need one identity require exactly one accessible candidate.

## 6. Fail-closed name resolution

The engine models only the Java lookup needed by supported analyzers. It never
selects a convenient lower-priority candidate after a higher-priority tier is
ambiguous or ineligible.

### Imports

Import declarations become four lookup sets:

~~~text
import a.b.Type;          -> exact type import
import a.b.*;             -> wildcard type import
import static a.b.C.X;    -> exact static member import
import static a.b.C.*;    -> wildcard static member import
~~~

Conflicting exact imports retain an explicit ambiguity marker. Malformed
imports are ignored rather than guessed.

### Known annotation and type identity

`resolve_known_annotation()` and `resolve_known_type()` prove supported
library identities through Java-like tiers:

~~~mermaid
flowchart TD
    Start[spelling at one syntax node] --> Q{qualified?}
    Q -- yes --> Exact{exact supported FQN?}
    Exact -- no --> Fail[unresolved]
    Exact -- yes --> Found[one identity]
    Q -- no --> Local{visible lexical type shadows it?}
    Local -- yes --> Fail
    Local -- no --> Import{exact import?}
    Import -- wrong or ambiguous --> Fail
    Import -- supported identity --> Found
    Import -- absent --> Same{same-package source type shadows it?}
    Same -- yes --> Fail
    Same -- no --> Candidates[implicit/current/wildcard candidates]
    Candidates --> One{exactly one without collision?}
    One -- yes --> Found
    One -- no --> Fail
~~~

`java.lang` participates only for identities expected there. Package wildcard
resolution checks source types that can collide with an expected external
identity. A source declaration at an otherwise supported external FQN blocks
the shortcut.

General source-owner lookup considers lexical nested types, exact imports,
same-package types, and wildcard imports in priority order. It enforces private
nest, package, public outer-chain, and named/unnamed-package access rules.
Duplicate FQNs never become first-wins.

## 7. String constants and expressions

Unqualified member lookup begins with the lexical owner chain. If that tier
declares the name, lookup stops there even when the declaration is mutable,
wrongly typed, or inaccessible as a value. Only an absent lexical declaration
permits static-import lookup.

Cross-file values require an accessible `static final String`. Interface
constants receive Java's implicit `public static final` treatment. A supported
same-file use may read a final instance String; a static method or initializer
may not. `this.member` is outside the workspace expression evaluator.

Static wildcard imports resolve only when exactly one imported owner declares
the member. Qualified references first resolve their owner to exactly one FQN.

The supported expression language is deliberately small:

~~~text
StringExpression := Java string literal
                  | ( StringExpression )
                  | StringExpression + StringExpression
                  | eligible identifier or member reference
~~~

The literal decoder supports ordinary Java escapes, repeated-`u` Unicode
escapes, bounded octal escapes, and valid UTF-16 surrogate pairs. It rejects
malformed escapes, unpaired surrogates, text blocks, and oversized results.

The only dependency constants resolved without loading classes are the closed
JAX `HttpMethod` token constants. They still pass through import, shadowing,
owner, member, and ambiguity checks.

## 8. Reusable method and hierarchy views

### `java_ast`

This module supplies small proofs over one unit: source text, guarded field
access, named-node traversal, bounded raw-type unwrapping, known-type identity,
direct interfaces, and proof that a fluent invocation chain is a direct
method-body statement.

### `java_methods`

`FormalParameter`, `MethodFact`, and `MethodIndex` describe source methods in
stable source order. Strict and varargs builders make accepted formal-parameter
shapes explicit. Index keys use owner FQN and method name. Functional-route,
Gateway, registration, configuration, and messaging analyzers reuse these
facts while attaching their own DSL rules.

### `java_hierarchy`

`JavaSourceHierarchyGraph` indexes unique workspace-visible classes,
interfaces, and records; parses bounded type references; substitutes generic
parameters; computes erased method signatures; traverses inheritance edges;
and selects effective or maximally specific interface methods.

Duplicate type identities do not enter the traversable graph. Missing source
parents, invalid generic shapes, cycles, incompatible type environments, or
multiple effective method candidates make the relevant traversal incomplete.
Spring and JAX-RS hierarchy analyzers do not infer endpoints from an incomplete
proof.

## 9. Framework index attachment

The neutral builder stops after Java declaration indexes. The pipeline then
adds framework indexes to that same workspace without parsing again:

~~~mermaid
flowchart TD
    Base[neutral workspace] --> Spring[source Spring annotation definitions]
    Base --> Choice{JAX-RS selected?}
    Choice -- yes --> Verbs[custom request-method designators]
    Choice -- yes --> Apps[ApplicationPath and Application facts]
    Choice -- no --> Empty[empty JAX indexes]
    Spring --> Inventories[annotation inventories]
    Verbs --> Inventories
    Apps --> Deploy[JAX-RS deployment model]
    Deploy --> Passes[framework passes]
    Inventories --> Passes
~~~

`spring_mvc.attach_workspace_indexes()` builds source annotation definitions
with meta-annotations, elements, and defaults. Spring later proves runtime
retention, composed mapping branches, and `AliasFor` edges.

When JAX-RS is selected, `jaxrs.attach_workspace_indexes()` builds custom
request-method candidates and `ApplicationPath` facts. It validates namespace,
unique `HttpMethod` identity, retention, target shape, and bounded token value.
When JAX-RS is not selected, `jaxrs.clear_workspace_indexes()` installs empty
JAX views.

`build_jax_rs_deployment_model()` adds bounded deployment ownership before
endpoint extraction when JAX-RS is selected. Method indexes and hierarchy
graphs are derived from the existing workspace by the passes that need them.

## 10. Proof bounds

| Concern | Bound or rule | When not proven |
|---|---|---|
| Tree-sitter pair | exact supported versions | analysis stops before parsing |
| snapshot | unique path set equal to content keys | construction fails |
| String-expression recursion | depth 12 | value unresolved |
| decoded or combined String | 8192 characters | value unresolved |
| constant cycle | repeated declaration identity | value unresolved |
| type/member candidate | exactly one accessible identity | identity unresolved |
| raw-type unwrapping | 16 steps | syntax unsupported |
| hierarchy depth | 12 | traversal incomplete |
| hierarchy expansion | 256 states | traversal incomplete |
| duplicate source FQN | all declarations retained | identity-dependent consumers fail closed |
| conflicting exact import | explicit ambiguity marker | no fallback past that tier |

These are semantic proof limits. Returning unresolved is safer than emitting an
endpoint from an identity the engine cannot establish.

## 11. Worked flow: Spring path constant

Assume the snapshot contains:

~~~java
// routes/Paths.java
package routes;
public final class Paths {
    public static final String ROOT = "/api";
}

// app/ItemsController.java
package app;
import static routes.Paths.ROOT;
import org.springframework.web.bind.annotation.GetMapping;

class ItemsController {
    @GetMapping(ROOT + "/items")
    void items() {}
}
~~~

Resolution proceeds as follows:

1. both files enter one `SourceSnapshot`;
2. one parser runtime is built and each file is parsed once;
3. the controller unit records the exact `GetMapping` and static `ROOT`
   imports;
4. the workspace records one visible `routes.Paths` declaration and one
   accessible `ROOT` constant;
5. Spring proves `GetMapping` against its exact supported identity;
6. the binary addition requires both operands to resolve;
7. no lexical declaration shadows `ROOT`, so the exact static import is
   consulted;
8. its owner resolves uniquely to `routes.Paths` and its initializer decodes
   to `/api`;
9. the second literal decodes to `/items` and bounded concatenation produces
   `/api/items`;
10. Spring emits typed endpoint evidence from the same controller unit.

~~~mermaid
flowchart TD
    Snap[snapshot bytes] --> Parse[one parse per file]
    Parse --> Imports[annotation and static imports]
    Parse --> Decls[type and member declarations]
    Imports --> Ann{GetMapping proven?}
    Decls --> Root{ROOT uniquely accessible?}
    Ann -- no --> Stop[no endpoint]
    Root -- no --> Stop
    Ann -- yes --> Expr[evaluate bounded expression]
    Root -- yes --> Expr
    Expr -- unresolved --> Stop
    Expr -- /api/items --> Endpoint[Spring endpoint fact]
~~~

The flow stops if `ROOT` is shadowed by an ineligible lexical member, its
import is conflicting, `routes.Paths` has duplicate source declarations, the
field is inaccessible or non-final across files, the initializer cycles, or
concatenation exceeds its bound. It never bypasses a failed higher-priority
tier.

## 12. Deliberate limits

The shared engine is not a Java compiler or interpreter. It does not model:

- classpath ordering or arbitrary dependency bytecode;
- complete typing, overload resolution, or compilation success;
- general local-variable or method data flow;
- method calls, builders, `String.format`, conditionals, ternaries, or runtime
  configuration in annotation values;
- full generic and wildcard semantics;
- reflection, proxies, module visibility, or framework runtime scanning.

Specialized analyzers may implement a bounded framework DSL over the shared
tree, but they never own Java parsing or widen the neutral String resolver into
general execution.

Continue with [04 — Spring MVC](04-spring-mvc.md).
