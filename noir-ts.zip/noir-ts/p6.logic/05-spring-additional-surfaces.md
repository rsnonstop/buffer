# 05 — Spring beyond annotated MVC

[← Spring MVC](04-spring-mvc.md) · [Index](README.md) · [Next: JAX-RS →](06-jax-rs.md)

The Spring branch is an ordered set of bounded source analyzers. Direct MVC,
functional registrations, hierarchy contracts, Gateway, static resources,
outbound clients, WebSocket handshakes, and message destinations all consume
the same parse-once Java workspace. Every successful producer returns immutable
[`EndpointFact`](../src/noir/model.py) values; CSV projection happens later.

Method-level companion: [13 — Spring methods](13-spring-methods.md) follows
each supplemental entry point through its branch-heavy private decoders.

```mermaid
flowchart TB
    Snapshot["SourceSnapshot: paths + exact bytes"] --> Workspace["java_workspace: one parsed unit per source"]
    Workspace --> Direct["direct Spring MVC"]
    Direct --> Registrations["functional + registerMapping"]
    Registrations --> Hierarchy["MVC hierarchy"]
    Hierarchy --> Gateway["Gateway"]
    Gateway --> Resources["resource handlers"]
    Resources --> Clients["HTTP clients"]
    Clients --> BuildConfig["build project path configuration"]
    BuildConfig --> Messaging["WebSocket + messaging"]
    Messaging --> Apply["apply configuration once"]
    Apply --> Result["AnalysisResult.endpoints"]
```

## 1. Ownership and pass contract

[`noir.pipeline._analyze_spring`](../src/noir/pipeline.py) establishes this
order:

1. [`analyze_direct_spring_mvc_unit`](../src/noir/spring_mvc.py) for every
   snapshotted compilation unit;
2. [`analyze_spring_route_registrations`](../src/noir/spring_route_registrations.py);
3. [`analyze_spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py);
4. [`analyze_spring_gateway`](../src/noir/spring_gateway.py);
5. [`analyze_spring_resource_handlers`](../src/noir/spring_config.py);
6. [`analyze_spring_http_clients`](../src/noir/spring_clients.py);
7. [`build_spring_path_configuration`](../src/noir/spring_config.py);
8. [`analyze_spring_websocket_and_messaging`](../src/noir/spring_websocket_messaging.py);
9. [`apply_spring_path_configuration`](../src/noir/spring_config.py).

The analyzers import syntax, name-resolution, evidence, and diagnostic helpers
from their package owners. They do not locate functions through a module
namespace, create another parser, project CSV rows, or write artifacts.

The important `EndpointFact` classifications are:

| Surface | Protocol / surface / direction | Public `interface_type` | Source attribution |
|---|---|---|---|
| functional `RouterFunction` | `http` / `server` / inbound | `http <verb>` | exact handler, else publisher |
| `registerMapping` | `http` / `server` / inbound | `http <verb>` | reflected source handler |
| Spring Cloud Gateway | `http` / `gateway` / inbound | `http-gateway <verb>` | route publisher |
| MVC resource handler | `http` / `static-handler` / inbound | `http-static-handler GET` | configurer method |
| HTTP Interface / Feign | `http` / `client` / outbound | `http-client <verb>` | contract method |
| WebSocket handshake | `ws` / `websocket-handshake` / inbound | `ws GET` | registration method |
| message mapping | `ws` / `message` / inbound | `ws SEND` or `ws SUBSCRIBE` | annotated handler |

Route, handler, and project provenance remain separate fields. Typed
`annotation_evidence` and `represented_targets` survive local deduplication and
configuration so output and companion reports can make independent decisions.

## 2. Functional routes

[`spring_route_registrations.py`](../src/noir/spring_route_registrations.py)
models a constrained servlet/WebFlux router language over the shared method
index.

### 2.1 Publisher proof

A functional publisher must be a method on one unique, visible, concrete
source class and must have:

- exactly one genuine direct Spring `@Bean`;
- a uniquely resolved servlet or WebFlux `RouterFunction` return type;
- exactly one direct top-level `return`; and
- a returned expression in the supported router grammar.

Nested returns, multiple return paths, fake annotations or types, ambiguous
imports, and duplicate source owners reject that publisher.

Supported forms include direct predicate routes, `andRoute` chains, fixed-verb
builder calls, and bounded `nest` blocks:

```java
return RouterFunctions.route(GET("/orders/{id}"), this::get)
    .andRoute(POST("/orders"), this::create);
```

```java
return RouterFunctions.route()
    .GET("/orders", this::list)
    .nest(path("/{id}"), nested -> {
        nested.GET("", this::get);
        nested.DELETE("", this::delete);
    })
    .build();
```

Recognized verbs are `GET`, `HEAD`, `POST`, `PUT`, `PATCH`, `DELETE`, and
`OPTIONS`. Paths use the workspace String resolver. A selector must prove one
method and one static path. Genuine request predicates that do not select a
method or path may be omitted from public identity, including bounded
`and`/`or`/`negate` combinations and a uniquely initialized typed final
predicate field.

An extra path or method predicate changes identity and is rejected. Shadowed
receivers, shadowed static imports, ambiguous wildcard imports, dynamic paths,
and unsupported predicate calls also fail closed.

### 2.2 Handler attribution and bounds

`this::handler` binds to a concrete declaration only when one same-owner,
non-static source method has the supported one-parameter shape. Its declaration
becomes the public handler and represented target.

A lambda or an indirect reference can still prove route publication without
proving a handler; attribution then falls back to the `@Bean` publisher. A
missing direct method reference is invalid. An ambiguous overload preserves a
valid route only with publisher attribution.

The decoder limits a publisher to 256 chain steps, nesting depth 16, and 4096
emitted routes. Exceeding a bound rejects that publisher.

## 3. Programmatic `RequestMappingHandlerMapping`

The same module recognizes direct `registerMapping` calls. The owner must be a
unique, visible, concrete class with exactly one genuine direct
`@Configuration`. A registration method must be non-static `void`, carry one
marker-only direct `@Autowired`, accept exactly one genuine
`RequestMappingHandlerMapping` parameter, and invoke `registerMapping` on that
exact parameter.

The modeled shape is:

```java
mapping.registerMapping(
    RequestMappingInfo.paths("/admin/reload")
        .methods(RequestMethod.POST)
        .build(),
    handler,
    Handler.class.getMethod("reload")
);
```

The mapping and reflected method may be inline or stored in one earlier,
direct, uniquely named local of the expected type. Tracked locals and relevant
parameters cannot be reassigned, updated, or ambiguously redeclared.

For `RequestMappingInfo`, `paths(...)` is required and statically resolved;
`methods(...)` is optional and must contain genuine Spring request-method
values. No other builder stage is accepted. An absent method condition emits
`ANY`.

Reflection must resolve one concrete source class, one nonempty method name,
canonical parameter class literals, and exactly one public non-static overload.
The handler argument must be a method parameter of that source type.

Modeled control flow, nested registration, `unregisterMapping`, or mutation of
tracked state rejects the registration method. Once method state is proven,
one malformed call can be skipped while valid sibling calls survive.

## 4. MVC hierarchy

[`SpringMvcHierarchyAnalyzer`](../src/noir/spring_mvc_hierarchy.py) adds routes
whose Spring mapping contract and concrete handler occur on different source
declarations. It relies on the neutral type graph in
[`java_hierarchy.py`](../src/noir/java_hierarchy.py).

The analyzer resolves unique source identities, erased method signatures,
generic adaptation, maximally specific interfaces, and effective concrete
implementations. Uncertain or conflicting hierarchy edges suppress only facts
that depend on them; independently proven direct MVC facts remain.

The emitted fact attributes the public row and represented target to the
concrete implementation. Mapping evidence from a different declaration can
prove the endpoint but does not own the implementation row, so it cannot fill
that row's `method_annotation_line`.

## 5. Spring Cloud Gateway

[`analyze_spring_gateway`](../src/noir/spring_gateway.py) recognizes bounded
`RouteLocator` publisher chains. A publisher needs one genuine direct `@Bean`,
a genuine `RouteLocator` return type, exactly one genuine
`RouteLocatorBuilder` parameter, and a direct `builder.routes()...build()`
return.

Accepted route predicate sequences are exactly:

- `path(...)`;
- `path(...).and().method(...)`; or
- `method(...).and().path(...)`.

Path and method arguments may fan out after static resolution. Consecutive
`filter(...)` or `filters(...)` calls are accepted only after the recognized
predicate sequence. Route ID and destination may be dynamic because they do
not define the inbound route.

Supported methods come from genuine `RequestMethod` or `HttpMethod` values;
`CONNECT` is available only through `HttpMethod`. One exact same-owner helper
may return the supported predicate chain from a genuine `PredicateSpec` to a
genuine `BooleanSpec`.

An unsupported route lambda is diagnosed and skipped while valid siblings
survive. A malformed outer publication chain rejects the publisher.

## 6. Static resource handlers

[`analyze_spring_resource_handlers`](../src/noir/spring_config.py) recognizes a
unique concrete `WebMvcConfigurer` and its canonical public, non-static,
textual-`void` `addResourceHandlers(ResourceHandlerRegistry)` method.

Direct top-level registrations rooted at the exact parameter are supported:

```java
registry.addResourceHandler("/assets/**", Paths.DOCS)
        .addResourceLocations("classpath:/static/");
```

Each `addResourceHandler` argument resolves independently, so a bad argument
does not discard valid siblings. The physical resource locations and later
chain behavior are not interpreted. Facts use `GET`, `http`, `static-handler`,
and inbound direction.

Receiver mutation, aliases, nested calls, fake interfaces, and wrong method
shapes reject the affected configurer method.

## 7. Outbound HTTP clients

[`analyze_spring_http_clients`](../src/noir/spring_clients.py) emits
`http`/`client`/`outbound` facts for unique visible source interfaces.

### 7.1 Spring HTTP Interface

Each lexical interface layer may contribute one generic type-level
`@HttpExchange` path/method layer. Direct, non-private, non-static methods may
use fixed `*Exchange` annotations or generic `@HttpExchange(method = ...)`.
Interface inheritance is not traversed.

Important rules:

- generic method tokens are bounded and uppercased;
- generic `@HttpExchange` without a method emits `ANY`;
- `value` and `url` aliases must agree;
- positional and named `value` cannot be mixed;
- fixed-verb annotations reject an explicit `method`;
- `contentType`, `accept`, and `headers` are route-neutral; and
- recovered arrays fan out deterministically.

Multiple genuine method mappings may contribute multiple facts. Type- and
method-level method conditions are unioned. An uncertain type layer suppresses
the interface; an uncertain method mapping can be skipped independently.

### 7.2 OpenFeign

A Feign contract needs exactly one genuine direct `@FeignClient` on a unique
visible interface. Its `name`, `value`, `url`, and `path` attributes classify
the contract but do not contribute path layers.

Genuine built-in or composed Spring MVC mappings on lexical interface layers
and direct usable methods supply paths and methods. Only direct contract
methods are analyzed. Invalid type mappings suppress the contract; invalid
method mappings remain local.

### 7.3 Deferred client paths

Client facts retain lexical path components in
`EndpointFact.spring_client_path_layers` until project configuration is known.
This is the only explicit transient field in the endpoint model. Placeholders
are resolved per layer before joining. An inner absolute `http://` or
`https://` layer resets outer layers:

```text
/catalog + ${inventory.base}/items
${inventory.base}=https://inventory.example
=> https://inventory.example/items
```

Clients never receive `server.servlet.context-path` or
`spring.webflux.base-path`.

## 8. WebSocket handshakes and messaging

[`analyze_spring_websocket_and_messaging`](../src/noir/spring_websocket_messaging.py)
emits handshake facts (`ws GET`) and STOMP-style destination facts (`ws SEND`
or `ws SUBSCRIBE`).

### 8.1 Handshakes

Two exact configurer shapes are modeled:

| Interface | Method | Registry | Registration |
|---|---|---|---|
| `WebSocketMessageBrokerConfigurer` | `registerStompEndpoints` | `StompEndpointRegistry` | `addEndpoint(paths...)` |
| `WebSocketConfigurer` | `registerWebSocketHandlers` | `WebSocketHandlerRegistry` | `addHandler(handler, paths...)` |

The owner is unique, visible, and concrete. The method is canonical public,
non-static, and textual `void`; its registry cannot be mutated. Registrations
are direct top-level chains. Path-neutral suffixes include interceptor, allowed
origin, allowed-origin-pattern, and handshake-handler configuration.
`withSockJS()` is rejected because it expands transport behavior.

For raw WebSocket registration, the handler must resolve to one exact field of
genuine `WebSocketHandler` type. Explicit `this.field` disambiguates a field
shadowed by a local. Path arguments fan out independently.

### 8.2 Application prefixes and message handlers

Canonical `configureMessageBroker(MessageBrokerRegistry)` methods may define
project-scoped application prefixes with one direct
`setApplicationDestinationPrefixes(...)` call. No call means an empty prefix;
multiple calls, nested calls, mutation, unresolved values, or ambiguous project
ownership invalidate that project's message-prefix model.

A message handler's lexical type chain must contain a genuine `@Controller` or
`@RestController`. Type-level `@MessageMapping` values compose across lexical
layers. Direct method annotations then emit:

- `@MessageMapping` → `SEND`;
- `@SubscribeMapping` → `SUBSCRIBE`.

`value` and `path` aliases must agree. Method destinations are explicit,
nonempty, and static; arrays fan out across project prefix, lexical type paths,
and method paths. MVC composition/hierarchy rules and server base paths do not
apply to message destinations.

## 9. Project path configuration

[`build_spring_path_configuration`](../src/noir/spring_config.py) builds a
`SpringWorkspacePathConfiguration` after the non-message Spring passes.
WebSocket/message analysis consumes it, then
`apply_spring_path_configuration()` returns a new tuple of configured facts.
The pipeline calls this function once.

### 9.1 Project and file selection

Project ownership prefers one applicable `src/main/java` ancestor, otherwise
one `src` ancestor, otherwise the analysis root. Repeated applicable markers,
ambiguous ownership, or sources outside the analysis root yield no project.
Static paths can survive without project configuration; a path that still has
unusable placeholder syntax cannot.

Functional facts retain `project_source_file` as the publisher even when the
public handler is in another file. Configuration therefore follows route
publication ownership.

Configuration locations are read in increasing precedence:

1. `src/main/resources`;
2. `resources`;
3. project root.

Within a location: `application.properties`, `application.yml`, then
`application.yaml`. Later values overwrite earlier values. The readers model a
small deterministic subset. YAML is mapping-only; sequences, anchors, document
markers, malformed structure, and profile activation keys reject that file.

### 9.2 Resolution rules

The inbound server prefix uses nonempty `spring.webflux.base-path`, otherwise
`server.servlet.context-path`. `${key}` and `${key:default}` permit bounded
nested substitution. A missing key without a default becomes empty. Malformed
syntax, more than 100 substitutions, or a result longer than 8192 characters
rejects that endpoint.

```mermaid
flowchart TD
    Fact["EndpointFact"] --> Kind{"surface"}
    Kind -->|"inbound HTTP, gateway, static, handshake"| Server["resolve path + prepend server base"]
    Kind -->|"outbound client"| Client["resolve path layers; absolute URL resets"]
    Kind -->|"message"| Message["apply application prefix only"]
    Server --> Replace["dataclasses.replace with resolved path"]
    Client --> Replace
    Message --> Replace
    Replace --> Keep["configured EndpointFact"]
    Fact -->|"unresolvable"| Drop["diagnose and omit candidate"]
```

Inputs are never mutated. Non-Spring facts pass through unchanged if supplied.
An unresolved candidate is diagnosed and removed without affecting siblings.

## 10. Evidence, deduplication, and failure scope

Every analyzer attaches typed evidence through
[`noir.evidence`](../src/noir/evidence.py):

- `AnnotationEvidence` identifies an owned request-method annotation;
- `SourceTarget` identifies a represented method, record component, or type;
- `merge_endpoint_facts()` keeps the later analyzer fact while unioning both
  evidence collections; and
- `deduplicate_endpoint_facts()` applies an analyzer-specific typed identity.

Local identity is intentionally richer than public CSV identity. Client
identity includes deferred path layers; message identity includes
protocol/surface. The later
[`consolidate_endpoint_rows`](../src/noir/output.py) boundary normalizes public
paths and groups on the exact six public fields across every analyzer.

Most call/DSL routes have no method-annotation evidence because route identity
comes from an invocation rather than an endpoint annotation. They still carry
the exact declaration target that owns the row. If configuration drops a fact,
its target does not enter the final represented-target union.

Fail-closed scope follows the smallest proof boundary:

| Uncertainty | Scope |
|---|---|
| invalid functional expression or exceeded budget | publisher |
| invalid programmatic flow or mutation | registration method |
| bad registration after method state is proven | call |
| malformed Gateway publication chain | publisher |
| unsupported Gateway lambda | route |
| unresolved resource argument | argument |
| mutated resource registry | configurer method |
| invalid client type layer | interface |
| invalid client method mapping | mapping |
| invalid application destination prefix | that project's message facts |
| unresolved configured path | endpoint fact |
| duplicate source identity | consumer that needs uniqueness |

These analyzers do not create a Spring container, execute profiles or bean
conditions, inspect dependency bytecode, or evaluate arbitrary helpers.
Headers, media conditions, filters, security, and physical resource existence
are generally outside public endpoint identity. Outbound client facts are not
inbound attack surface, and handshake/message rows represent different
protocol stages.

Next: [06 — JAX-RS](06-jax-rs.md).
