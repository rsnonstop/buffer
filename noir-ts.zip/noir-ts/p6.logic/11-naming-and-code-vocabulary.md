# 11 — Naming and code vocabulary

[← Code and test map](10-code-and-test-map.md) · [Index](README.md) ·
[Core runtime methods →](12-core-runtime-methods.md)

This appendix defines the names used by the current `src/noir/` application.
The vocabulary follows one run from typed request, through shared Java facts
and framework analysis, to public artifacts.

## 1. The application sentence

> Analyze one `AnalysisRequest` by snapshotting its Java sources, building one
> shared workspace, running the selected framework passes, and returning
> immutable `EndpointFact` values and inventories in an `AnalysisResult`.

The CLI then projects and publishes that result:

~~~mermaid
flowchart LR
    R[AnalysisRequest] --> S[SourceSnapshot]
    S --> W[Java workspace]
    W --> P[Framework passes]
    P --> F[EndpointFact]
    F --> A[AnalysisResult]
    A --> C[EndpointRowCandidate]
    C --> O[CSV and companion reports]
~~~

These names stay distinct because they carry different information. An
`EndpointFact` is richer than a CSV row, and a source snapshot is not a parsed
compilation unit.

## 2. Application values

The immutable application vocabulary lives in
[`noir/model.py`](../src/noir/model.py).

| Name | Meaning |
|---|---|
| `AnalysisRequest` | normalized analysis root and requested framework mode |
| `FrameworkSelection` | one normalized analyzer family: Spring or JAX-RS |
| `FrameworkPlan` | requested mode plus the effective ordered selection |
| `SourceFile` | typed source-path identity |
| `SourceSpan` | exact half-open byte interval inside one source file |
| `SourceTarget` | declaration kind plus exact span represented by an endpoint |
| `AnnotationEvidence` | validated same-file method-annotation provenance |
| `EndpointFact` | lossless analyzer output before public projection |
| `AnalysisDiagnostic` | presentation-neutral event produced during analysis |
| `AnalysisResult` | immutable facts, inventories, framework decision data, announcements, and diagnostics |

[`noir/application.py`](../src/noir/application.py) :: `analyze()` is the
programmatic boundary. It accepts an `AnalysisRequest`, runs the pipeline
inside one diagnostic scope, and returns an `AnalysisResult`. It performs no
argument parsing or artifact I/O.

The CLI derives the CSV module name from the input directory basename; it is a
presentation value, not application-analysis intent.

## 3. Orchestration vocabulary

[`noir/pipeline.py`](../src/noir/pipeline.py) owns the source-to-result order.

| Name | Responsibility |
|---|---|
| `SourceSnapshot` | deterministic source paths and the exact bytes read once for the run |
| `FrameworkDecision` | effective `FrameworkPlan`, marker detections, and announcements |
| `_snapshot_sources()` | discover Java files and capture their bytes |
| `_select_frameworks()` | apply explicit, default, or marker-based selection |
| `_build_workspace()` | construct one parser runtime, one workspace, and selected framework indexes |
| `_analyze_spring()` | run all Spring endpoint surfaces, then apply project path configuration |
| `_analyze_jaxrs()` | run direct resources, hierarchy/subresources, and Java WebSocket |
| `run_analysis()` | validate dependencies, order every stage, enforce typed analyzer results, and build `AnalysisResult` |

A **pass** is an analyzer step over the shared workspace. A pass neither
discovers files nor publishes artifacts.

The default framework mode selects Spring and JAX-RS in that order.
`--framework auto` instead scans raw marker evidence and may select a narrower
set. Endpoint extraction starts only after inventories and, when needed, the
JAX-RS deployment model have been built.

## 4. Shared Java vocabulary

The Java engine separates runtime construction, per-file parsing, cross-file
resolution, method flow, and inheritance:

~~~mermaid
flowchart TB
    B[Snapshotted bytes] --> U[Compilation unit]
    U --> W[Workspace indexes]
    W --> M[Method facts and indexes]
    W --> H[Hierarchy graph]
    M --> X[Framework interpretation]
    H --> X
~~~

- A **runtime** is the validated Tree-sitter language, parser, queries, and
  query-cursor factory owned by
  [`noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py).
- A **compilation unit** is the parsed and indexed representation of one Java
  file, retaining its source bytes and Tree-sitter nodes. It is built by
  [`noir/java_frontend.py`](../src/noir/java_frontend.py).
- A **workspace** is the collection of compilation units plus cross-file
  indexes for types, imports, members, constants, annotations, and framework
  declarations. It is built by
  [`noir/java_workspace.py`](../src/noir/java_workspace.py).
- A **method fact** and **method index** describe bounded Java method bodies,
  formal parameters, invocations, and lookup identity. They live in
  [`noir/java_methods.py`](../src/noir/java_methods.py).
- A **hierarchy graph** describes source-visible types, supertypes, method
  signatures, and implementation selection. It lives in
  [`noir/java_hierarchy.py`](../src/noir/java_hierarchy.py).

Resolver verbs have stable meanings:

| Prefix | Meaning |
|---|---|
| `resolve_known_*` | prove a supported library identity within one compilation unit |
| `resolve_workspace_*` | follow source-visible declarations or constants across units |
| `index_*` | derive reusable lookup data |
| `select_*` | choose from proven candidates, normally rejecting ambiguity |
| `decode_*` | interpret a syntax value after its identity is known |
| `analyze_*` | emit endpoint facts for one defined surface |

## 5. Framework vocabulary

The technology name is **JAX-RS** in code and prose. The public CLI selector
remains `jaxrx`.

### Spring owners

| Module | Surface |
|---|---|
| [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) | direct MVC mappings, composed annotations, records, and mapping indexes |
| [`noir/spring_route_registrations.py`](../src/noir/spring_route_registrations.py) | functional routes and programmatic MVC registrations |
| [`noir/spring_mvc_hierarchy.py`](../src/noir/spring_mvc_hierarchy.py) | inherited mapping contracts bound to concrete controllers |
| [`noir/spring_gateway.py`](../src/noir/spring_gateway.py) | Spring Cloud Gateway Java DSL routes |
| [`noir/spring_config.py`](../src/noir/spring_config.py) | project path configuration and static resource handlers |
| [`noir/spring_clients.py`](../src/noir/spring_clients.py) | HTTP Interface and OpenFeign outbound contracts |
| [`noir/spring_websocket_messaging.py`](../src/noir/spring_websocket_messaging.py) | raw/STOMP handshakes and message destinations |

### JAX-RS and WebSocket owners

| Module | Surface |
|---|---|
| [`noir/jaxrs.py`](../src/noir/jaxrs.py) | direct resources, custom request methods, records, and application paths |
| [`noir/jaxrs_deployment.py`](../src/noir/jaxrs_deployment.py) | source applications and bounded `web.xml` deployment prefixes |
| [`noir/jaxrs_hierarchy.py`](../src/noir/jaxrs_hierarchy.py) | inherited resource bundles and recursive subresource locators |
| [`noir/java_websocket.py`](../src/noir/java_websocket.py) | Javax/Jakarta server handshakes |

**Direct** means that route evidence is interpreted on its concrete source
declaration while reusing the unit already in the workspace.

**Supplemental surface** means another route-bearing mechanism beyond direct
annotation mappings: hierarchy, functional registration, Gateway, resources,
clients, deployment, subresources, or messaging.

**Fail closed** means an unsupported or ambiguous candidate contributes no
endpoint fact. The analyzer normally records a diagnostic at that rejection
boundary and continues with independent candidates.

## 6. Analyzer boundaries

Framework analyzers import constants, Java helpers, evidence operations, and
diagnostic recording from their owning `noir` modules. Their public entry
points receive only semantic inputs such as a source, compilation unit,
workspace, or Spring path configuration.

Every endpoint producer returns `EndpointFact` directly. Analyzer-local
deduplication calls
[`deduplicate_endpoint_facts()`](../src/noir/evidence.py) with a
surface-specific identity function; the shared operation merges annotation
evidence and represented targets deterministically. The pipeline rejects any
non-`EndpointFact` result before constructing `AnalysisResult`.

This boundary keeps extraction code independent of CLI parsing, stdout, file
publication, and executable-launcher state.

## 7. Endpoint and evidence vocabulary

An `EndpointFact` keeps distinctions that the public CSV cannot represent:

- technology, protocol, surface, and direction;
- request method, path, handler name, and parameters;
- public source ownership;
- route, handler, and project/configuration provenance;
- `AnnotationEvidence` values;
- `SourceTarget` values represented by the endpoint;
- unresolved Spring client path layers until project configuration applies.

A **represented target** is an exact source declaration identity: canonical
file, declaration kind, and byte span. Surviving targets are used to subtract
represented declarations from the endpoint-trigger inventory.

A **row candidate** is the first public projection of an endpoint fact. A
**consolidated endpoint set** contains deterministically ordered public rows
plus merged represented targets needed by reports.

~~~mermaid
flowchart LR
    F[EndpointFact] -->|project once| C[EndpointRowCandidate]
    C -->|normalize + group| O[ConsolidatedEndpoints]
    O --> CSV[Seven CSV fields]
    O --> T[Represented targets]
~~~

The first six CSV fields form row identity. `method_annotation_line` is chosen
only after all validated same-file annotation evidence for that identity has
been merged.

## 8. Effects and artifact ownership

Use these verbs consistently:

| Verb | Meaning |
|---|---|
| `record` | append a diagnostic to the current run's collector |
| `render` | create bytes or text without changing the filesystem |
| `write` | serialize a CSV or diagnostic log at its owning boundary |
| `publish` | atomically replace a prepared byte-report destination |
| `announce` | return stable text for the CLI to print |

[`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` owns argument validation,
output naming, projection, report preparation, publication order, and stdout.
Analyzers return facts and record diagnostics; they do not write artifacts.

The endpoint CSV and diagnostic log are direct writes. Byte reports are
atomically replaced individually. The complete artifact set is therefore not
one filesystem transaction.

Framework announcements are printed after analysis. The completion inventory
from `render_completion_summary()` is printed only after every requested
artifact has been published successfully.

## 9. Public names that remain stable

- `src/noir_sbt.py` is the executable path and delegates directly to
  `noir.cli.main`.
- `--framework jaxrx` selects JAX-RS.
- The CSV columns are `module_name`, `interface_type`, `endpoint`,
  `source_file_name`, `method_name`, `parameters`, and
  `method_annotation_line`.
- The diagnostic companion is `<output>.log`.
- The endpoint-trigger report ends in `-anno-without-endpoints.log`.
- With `--noir-report`, the exact source-location comparison ends in
  `-anno-without-noir-endpoints.log`.
- Established `Found ...` announcements and the success line
  `noir-ts analysis completed.` remain user-visible contracts.

The comparison report is occurrence-based. An unmatched recognized annotation
is not, by itself, proof that Noir missed an endpoint.

## 10. Practical reading route

Read current code in this order:

1. [`src/noir_sbt.py`](../src/noir_sbt.py) for the executable handoff;
2. [`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` for the user-visible
   transaction;
3. [`noir/application.py`](../src/noir/application.py) :: `analyze()` for the
   typed programmatic boundary;
4. [`noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` for exact
   stage order;
5. `SourceSnapshot` and
   [`build_java_workspace()`](../src/noir/java_workspace.py) for parse-once
   shared data;
6. [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) or
   [`noir/jaxrs.py`](../src/noir/jaxrs.py) for direct framework semantics;
7. one supplemental analyzer for its bounded source surface;
8. [`noir/model.py`](../src/noir/model.py) :: `EndpointFact` and
   [`noir/evidence.py`](../src/noir/evidence.py) for the analyzer result
   contract;
9. [`noir/output.py`](../src/noir/output.py),
   [`noir/reports.py`](../src/noir/reports.py), and
   [`noir/comparison.py`](../src/noir/comparison.py) for projection and
   artifacts.

Continue with [12 — Core runtime methods](12-core-runtime-methods.md), or
return to the [guide index](README.md).
