# 11 — Application logic vocabulary and worked values

[← Code map](10-code-map.md) · [Index](README.md) ·
[Core runtime methods →](12-core-runtime-methods.md)

This appendix defines the names used by the current `src/noir/` application.
The vocabulary follows one run from typed request, through shared Java facts
and framework analysis, to public artifacts.

## 1. The application sentence

> Analyze one `AnalysisRequest` by snapshotting its Java sources, building one
> shared workspace, configuring static adapters, building inventories,
> preparing every selected family, running its facade, and returning immutable
> `EndpointFact` values and inventories in an `AnalysisResult`.

The CLI then projects and publishes that result:

~~~mermaid
flowchart LR
    R[AnalysisRequest] --> S[SourceSnapshot]
    S --> W[Java workspace]
    W --> A[Configured framework adapters]
    A --> I[Inventories]
    I --> P[Prepared selected family facades]
    P --> F[EndpointFact]
    F --> A[AnalysisResult]
    A --> C[EndpointRowCandidate]
    C --> O[CSV and companion reports]
~~~

These names stay distinct because they carry different information. An
`EndpointFact` is richer than a CSV row, and a source snapshot is not a parsed
compilation unit.

## 2. Application values

The immutable application vocabulary lives in
[`noir/model.py`](../src/noir/model.py).

| Name | Meaning |
|---|---|
| `AnalysisRequest` | normalized analysis root and requested default, auto, scalar-explicit, or tuple-explicit framework mode |
| `FrameworkSelection` | one normalized executable family: Spring, JAX-RS, or Wicket |
| `FrameworkMode` | `None`, scalar `auto`, one explicit token, or an immutable tuple of several explicit tokens |
| `FRAMEWORK_MODE_CHOICES` | all `FrameworkSelection` values in enum order followed by the distinct `auto` policy |
| `FrameworkPlan` | normalized requested policy plus the effective registry-ordered selection |
| `SourceFile` | typed source-path identity |
| `SourceSpan` | exact half-open byte interval inside one source file |
| `SourceTarget` | declaration kind plus exact span represented by an endpoint |
| `AnnotationEvidence` | validated same-file method-annotation provenance |
| `EndpointFact` | lossless analyzer output before public projection |
| `AnalysisDiagnostic` | presentation-neutral event produced during analysis |
| `AnalysisResult` | immutable facts, inventories, framework decision data, announcements, and diagnostics |

[`noir/application.py`](../src/noir/application.py) :: `analyze()` is the
programmatic boundary. It accepts an `AnalysisRequest`, runs the pipeline
inside one diagnostic scope, and returns an `AnalysisResult`. It performs no
argument parsing or artifact I/O.

The CLI derives the CSV module name from the input directory basename; it is a
presentation value, not application-analysis intent.

## 3. Orchestration vocabulary

[`noir/pipeline.py`](../src/noir/pipeline.py) owns the source-to-result order.
[`noir/frameworks.py`](../src/noir/frameworks.py) owns the static execution
composition used by that order.

| Name | Responsibility |
|---|---|
| `SourceSnapshot` | deterministic source paths and the exact bytes read once for the run |
| `FrameworkDecision` | effective `FrameworkPlan`, marker detections, and announcements |
| `FrameworkAdapter` | one family name and selection identity, default policy, announcement, and configure/prepare/analyze hooks |
| `FRAMEWORK_ADAPTERS` | frozen execution order: Spring, JAX-RS, then the selectable but non-default Wicket stub |
| `_snapshot_sources()` | discover Java files and capture their bytes |
| `_select_frameworks()` | apply scalar/tuple explicit, default, or marker-based selection and restore registry order |
| `_build_workspace()` | construct one parser runtime/workspace, then configure every adapter with its selected state |
| `analyze_spring_framework()` | run all Spring endpoint surfaces, then apply project path configuration |
| `analyze_jaxrs_framework()` | run direct resources, hierarchy/subresources, and Java WebSocket after JAX deployment preparation |
| `analyze_wicket_framework()` | execute the selected Wicket seam and return an empty endpoint tuple until semantic support exists |
| `run_analysis()` | validate dependencies; configure; build inventories; prepare all selected adapters; analyze them in registry order; enforce typed results; and build `AnalysisResult` |

A **pass** is an analyzer step over the shared workspace. A pass neither
discovers files nor publishes artifacts.

The default framework mode selects Spring and JAX-RS in that order. A single
explicit option remains a scalar request; repeated explicit options form an
immutable tuple whose effective selection is restored to adapter-registry
order. Duplicates and combinations containing `auto` are invalid.
`--framework auto` remains a scalar policy that scans raw marker evidence and
may select a narrower set. `FRAMEWORK_MARKER_RULES` separately owns finding
order and `auto` announcements. Explicit Wicket selection runs its no-op
facade, but the Wicket marker remains advisory and its adapter is excluded
from the default.
Endpoint extraction starts only after inventories and every selected adapter's
preparation, including the JAX-RS deployment model. The complete addition path
is [16 — Adding framework support](16-adding-framework-support.md).

## 4. Shared Java vocabulary

The Java engine separates runtime construction, per-file parsing, cross-file
resolution, method flow, and inheritance:

~~~mermaid
flowchart TB
    B[Snapshotted bytes] --> U[Compilation unit]
    U --> W[Workspace indexes]
    W --> M[Method facts and indexes]
    W --> H[Hierarchy graph]
    M --> X[Framework interpretation]
    H --> X
~~~

- A **runtime** is the validated Tree-sitter language, parser, queries, and
  query-cursor factory owned by
  [`noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py).
- A **Java source input** is one selected `.java` path plus its snapshotted
  bytes. The `SourceFile` application value in section 2 names only the typed
  path identity.
- A **parsed tree** is only Tree-sitter's syntax tree for those bytes. It does
  not yet contain Noir's imports, type identities, or route candidates.
- A **compilation unit** is Noir's complete parsed-and-indexed representation of
  one Java source file. It keeps the path, exact bytes, parsed tree, query
  results, imports, lexical types, annotation occurrences, and grouped
  declaration candidates together. It is built by
  [`noir/java_frontend.py`](../src/noir/java_frontend.py).
- **Parsed unit** is explanatory shorthand for a compilation unit; there is no
  second `ParsedUnit` application type. In Python, an argument named `unit`
  normally holds that compilation-unit dictionary. It does not mean the whole
  project or a Java package.
- A **workspace** is the collection of compilation units plus cross-file
  indexes for types, imports, members, constants, annotations, and framework
  declarations. It is built by
  [`noir/java_workspace.py`](../src/noir/java_workspace.py).
- A **method fact** and **method index** describe bounded Java method bodies,
  formal parameters, invocations, and lookup identity. They live in
  [`noir/java_methods.py`](../src/noir/java_methods.py).
- A **hierarchy graph** describes source-visible types, supertypes, method
  signatures, and implementation selection. It lives in
  [`noir/java_hierarchy.py`](../src/noir/java_hierarchy.py).

For example, after `/workspace/app/ItemsController.java` has been parsed,
`workspace["compilation_units"][path]` and the `unit` passed to
`analyze_direct_spring_mvc_unit(unit, workspace)` are the same Python object:

~~~python
unit = {
    "source_path": "/workspace/app/ItemsController.java",
    "source": b"package app; class ItemsController { ... }",
    "tree": tree_sitter_tree,
    "package": "app",
    "imports": {"exact": {}, "wildcards": set(), ...},
    "type_infos": {(13, 62): {"simple_name": "ItemsController", ...}},
    ...,
}
workspace["compilation_units"][unit["source_path"]] is unit  # True
~~~

Names such as `tree_sitter_tree` and `...` above stand for retained parser
objects and omitted fields; the complete shape is shown below.

Resolver verbs have stable meanings:

| Prefix | Meaning |
|---|---|
| `resolve_known_*` | prove a supported library identity within one compilation unit |
| `resolve_workspace_*` | follow source-visible declarations or constants across units |
| `index_*` | derive reusable lookup data |
| `select_*` | choose from proven candidates, normally rejecting ambiguity |
| `decode_*` | interpret a syntax value after its identity is known |
| `analyze_*` | emit endpoint facts for one defined surface |

## Workspace and index vocabulary

### Java names and declarations

These terms describe application evidence, not Java grammar in the abstract:

| Term | Meaning in Noir | Concrete value example |
|---|---|---|
| **package name** | Namespace declared by one compilation unit. The unnamed package is represented by `""`. | `"app.api"` from `package app.api;` |
| **simple type name** | Declared type name without a package or enclosing type. | `"ItemsController"` |
| **package type name** | A top-level simple name known to exist in a package and therefore able to block a library-name shortcut. In a unit's `package_types`, the unit's own top-level names are excluded because its lexical-type facts already cover them. | `"Fast"` in `items_unit["package_types"] == {"Fast", "RestApplication"}` |
| **lexical display name** | Source-facing type name including enclosing types, but not the package. It is used for owner-relative lookup and diagnostics. | `"Routes.Admin"` for member class `Admin` inside `Routes` |
| **FQN** (fully qualified name) | Stable package plus lexical type identity used across files. | `"app.api.Routes.Admin"` |
| **type declaration by FQN** | One source declaration record stored under its FQN. The bucket is a list because two files can declare the same FQN and must remain ambiguous. | `workspace["type_declarations"]["app.ItemsController"]` |
| **member declaration** | Evidence that a workspace-visible source owner declares a field, interface constant, or enum constant with a name. It is retained even when it is not a usable String value, because its presence can stop lookup at that Java tier. Methods are not stored in this index. | `("routes.Paths", "ROOT")` |
| **static member declaration** | A member-declaration record additionally proven static for the supported lookup model, with access facts used to detect static-wildcard collisions. Interface and enum constants count as static. Methods are not stored here. | `workspace["static_member_declarations"][("routes.Paths", "ROOT")]` |
| **source annotation declaration** | A workspace-visible Java `@interface` declared in the analyzed source, as distinct from an applied annotation occurrence or dependency-only annotation. | declaration `public @interface Fast {}` with FQN `"app.Fast"` |
| **annotation occurrence** | One use of an annotation on a declaration or parameter. | `@Fast` on `ItemsResource.list()` |
| **annotation definition** | A source annotation declaration enriched with neutral syntax facts: its meta-annotations, elements, types, defaults, and element annotations. Framework analyzers interpret those facts without copying them. | `workspace["annotation_definitions"]["app.Fast"][0]` |

The phrase **status member declaration** is not an application term or a
Python field. Where that wording appears in a prompt, read it as **static
member declaration**.

### Name spelling, qualification, and shadowing

A **spelling at a syntax node** is the exact name text written at one source
location. For the same Spring annotation identity it might be `GetMapping` or
`org.springframework.web.bind.annotation.GetMapping`. The syntax node matters
because imports and lexically visible declarations can differ by location.

An **unqualified** type or member spelling contains only the name being looked
up, such as `GetMapping` or `ROOT`. A **qualified** spelling supplies an owner
or namespace, such as `RetentionPolicy.RUNTIME` or
`org.springframework.web.bind.annotation.GetMapping`. A **fully qualified**
type spelling supplies the complete package and type name. The known-library
resolver accepts a dotted annotation/type spelling only when it is the exact
supported FQN; it does not guess partially qualified library identities.

**Shadowing** means that a name declared in a stronger Java lookup scope owns
the spelling, so a same-named import or supported library type cannot be used.
For example:

~~~java
package app;

import org.springframework.web.bind.annotation.*;

class ItemsController {
    @interface GetMapping {
        String value();
    }

    @GetMapping("/items")
    void list() {}
}
~~~

At the `@GetMapping` node, the visible member annotation
`ItemsController.GetMapping` shadows the wildcard-imported Spring name. Noir
therefore does not classify this occurrence as Spring's `GetMapping`. It also
does not fall through to the wildcard import merely because the local
declaration is unusable for a desired framework interpretation.

### What an index is

An **index** is analysis-local lookup data derived from the immutable source
snapshot. It answers a recurring application question such as “which source
types have this FQN?” or “which handler bodies have this owner and name?”
It is not a database, a file offset, or necessarily a Python `dict`: a set,
list, dataclass, or graph can be an index when that is the useful lookup shape.

Most declaration indexes map a semantic key to a **candidate bucket**. A
bucket deliberately keeps all declarations. Consumers that need one identity
check that exactly one accessible candidate survives; insertion order never
silently selects a winner.

The semantic index families named in this guide are catalogued below as core
workspace indexes, framework-attached indexes, and derived method/hierarchy
indexes. A variable such as `statement_index` that merely holds a list
position is not a workspace index.

The following sources will be used in the structure examples:

~~~java
// /workspace/routes/Paths.java
package routes;

public final class Paths {
    public static final String ROOT = "/api";
    public static int MODE = 1;
}
~~~

~~~java
// /workspace/app/Fast.java
package app;

import jakarta.ws.rs.HttpMethod;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Retention(RUNTIME)
@HttpMethod("FAST")
public @interface Fast {}
~~~

~~~java
// /workspace/app/ItemsController.java
package app;

import static routes.Paths.ROOT;
import org.springframework.web.bind.annotation.GetMapping;

class ItemsController {
    @GetMapping(ROOT + "/items")
    public String list(String filter) { return filter; }
}
~~~

~~~java
// /workspace/app/RestApplication.java
package app;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/rest")
public class RestApplication extends Application {}
~~~

### Core workspace indexes

[`build_java_workspace()`](../src/noir/java_workspace.py) creates these stable
neutral lookup views. Entries described as “per unit” live inside each value
of `workspace["compilation_units"]`.

| Index or lookup view | Key to value structure | Application question answered |
|---|---|---|
| `runtime` | language, parser, compiled query map, and cursor factory | Which validated parser objects and complete neutral query set own these units? |
| `compilation_units` | source-path string → compilation-unit dictionary | Which exact parsed source object belongs to this path? |
| `matches` (per unit) | query name → complete Tree-sitter query matches | Which raw syntax associations were captured in this file? |
| `type_infos` (per unit) | `(start_byte, end_byte)` → lexical type record | Which source type owns this node, and is it workspace-visible? |
| `imports` (per unit) | four views: `exact`, `wildcards`, `static_exact`, `static_wildcards` | Which Java lookup tier can a source spelling use? |
| declaration candidates (per unit) | declaration byte-range key → complete capture dictionaries | Which annotations belong to this type, method, record component, annotation definition, or annotation element? The fields are `type_candidates`, `method_candidates`, `record_component_candidates`, `meta_candidates`, and `element_candidates`. |
| `package_types` (per unit) | set of other top-level simple names in the same package | Does a same-package source type block an expected external type? |
| `wildcard_source_types` (per unit) | simple name → set of imported source FQNs | Can a wildcard source import collide with a known library candidate? |
| `type_declarations` | FQN → list of `{fqn, unit, type_info}` | Is there exactly one accessible source type with this identity? |
| `member_declarations` | `(owner FQN, member name)` → set of declaration IDs | Does this owner declare the name, even if no route String can be read from it? |
| `static_member_declarations` | `(owner FQN, member name)` → list of declaration/access records | Can another static wildcard owner make an unqualified member ambiguous? |
| `constants_by_owner_member` | `(owner FQN, member name)` → list of String initializer records | Which source String declarations are candidates for bounded value resolution? |
| `annotation_definitions` | annotation FQN → list of neutral definition records containing declaration identity, direct meta-annotations, and declared element structure | Which project-declared annotation identity could an applied annotation denote, and what source structure can a framework prove about it? |

`workspace_constant_records` is the same unit's String-candidate records in
source order. `workspace_member_declarations` and
`workspace_static_member_declarations` are references to the corresponding
workspace-wide views, attached to each unit for resolvers that receive a unit
directly.

Here is a shortened but structurally faithful result for the example sources.
`paths_unit`, `fast_unit`, and the `*_node` values are references to the real
compilation-unit and Tree-sitter objects retained by the workspace:

~~~python
workspace = {
    "compilation_units": {
        "/workspace/routes/Paths.java": paths_unit,
        "/workspace/app/Fast.java": fast_unit,
        "/workspace/app/ItemsController.java": items_unit,
        "/workspace/app/RestApplication.java": application_unit,
    },
    "type_declarations": {
        "routes.Paths": [
            {"fqn": "routes.Paths", "unit": paths_unit, "type_info": paths_info}
        ],
        "app.Fast": [
            {"fqn": "app.Fast", "unit": fast_unit, "type_info": fast_info}
        ],
        "app.ItemsController": [
            {
                "fqn": "app.ItemsController",
                "unit": items_unit,
                "type_info": items_info,
            }
        ],
        ...,
    },
    "member_declarations": {
        ("routes.Paths", "ROOT"): {
            ("/workspace/routes/Paths.java", field_start, field_end, name_start)
        },
        ("routes.Paths", "MODE"): {
            ("/workspace/routes/Paths.java", mode_start, mode_end, mode_name_start)
        },
    },
    "static_member_declarations": {
        ("routes.Paths", "ROOT"): [
            {
                "owner_fqn": "routes.Paths",
                "unit": paths_unit,
                "static": True,
                "public": True,
                ...,
            }
        ],
        ("routes.Paths", "MODE"): [{...}],
    },
    "constants_by_owner_member": {
        ("routes.Paths", "ROOT"): [
            {
                "name": "ROOT",
                "owner_fqn": "routes.Paths",
                "value_node": root_literal_node,
                "final_constant": True,
                "static_final": True,
                ...,
            }
        ]
    },
    "annotation_definitions": {
        "app.Fast": [
            {
                "fqn": "app.Fast",
                "simple_name": "Fast",
                "unit": fast_unit,
                "type_info": fast_info,
                "meta_annotations": [
                    {"node": retention_node, "name_node": retention_name_node},
                    {"node": http_method_node, "name_node": http_method_name_node},
                ],
                "elements": {},
            }
        ]
    },
    ...,
}

items_unit["package_types"] == {"Fast", "RestApplication"}
~~~

`MODE` appears in the declaration indexes, where it can shadow another
`MODE`, but not in `constants_by_owner_member`: its declared type is not the
supported `java.lang.String` value shape. If a second file declared
`routes.Paths`, the corresponding `type_declarations` bucket would contain two
records and identity-dependent resolution would fail closed.

### Framework-specific indexes and models

The pipeline and analyzers add the following semantic views to the same
workspace after the neutral indexes exist. Spring consumes
`annotation_definitions` directly instead of maintaining a Spring-owned copy.

| Index or model | Structure | Meaning |
|---|---|---|
| `jax_rs_custom_designator_candidates` | set of annotation FQNs | Source annotations that carry relevant `@HttpMethod` evidence, including invalid ones. Retaining invalid candidates prevents an applied, broken designator from looking unrelated. |
| `jax_rs_custom_designators` | annotation FQN → list of valid designator records | Proven runtime custom request methods, including HTTP token and Javax/Jakarta namespace. |
| `jax_rs_applications` | list of application records | Concrete direct `Application` subclasses with namespace, package, source identity, and resolved path or `None`. A list preserves disagreement and unresolved paths for prefix selection. |
| `jax_rs_deployment_model` | dictionary containing `deployment_prefixes`, `applications_by_class_name`, and explicit descriptor keys | Project/package/family deployment-prefix evidence shared by direct and hierarchy JAX-RS analysis; a descriptor-derived key can use `None` when no Javax/Jakarta family was established. |

For the `Fast` and `RestApplication` declarations above, the JAX-RS views have
values like:

~~~python
workspace["jax_rs_custom_designator_candidates"] == {"app.Fast"}

workspace["jax_rs_custom_designators"] == {
    "app.Fast": [
        {
            "fqn": "app.Fast",
            "simple_name": "Fast",
            "namespace": "jakarta.ws.rs",
            "method": "FAST",
            "source_path": "/workspace/app/Fast.java",
        }
    ]
}

workspace["jax_rs_applications"] == [
    {
        "namespace": "jakarta.ws.rs",
        "package": "app",
        "path": "/rest",
        "source_path": "/workspace/app/RestApplication.java",
        "simple_name": "RestApplication",
        "fqn": "app.RestApplication",
    }
]

workspace["jax_rs_deployment_model"] = {
    "analysis_root": "/workspace",
    "deployment_prefixes": {
        ("/workspace", "app", "jakarta.ws.rs"): "/rest"
    },
    "applications_by_class_name": {
        "RestApplication": (("/workspace", "app", "jakarta.ws.rs"),),
        "app.RestApplication": (("/workspace", "app", "jakarta.ws.rs"),),
    },
    "xml_configured_application_keys": set(),
}
~~~

When JAX-RS is not selected, its attacher installs the same candidate,
designator, and application keys with empty values. A consumer can therefore
read a stable shape without interpreting a missing key as application
evidence.

### Derived method and hierarchy indexes

Some views are created by only the passes that need them rather than attached
as shared workspace keys:

| View | Structure | Meaning |
|---|---|---|
| `MethodIndex` | ordered `methods` tuple plus `(owner FQN, method name)` → overload tuple | Executable source methods accepted by either the strict-parameter or varargs-parameter policy. |
| `JavaSourceHierarchyGraph.types` | unique FQN → `JavaTypeRecord` | Traversable source classes, interfaces, and records with edges and methods. Duplicate FQNs are excluded from this map rather than chosen. |
| hierarchy signature cache | method provenance plus adapted generic environment → erased signature or `None` | Reuses an already-proven override identity for the same generic state. It is internal to one graph. |
| JAX-RS effective-method cache | resource FQN, generic environment, and namespace → selected `JaxRsEffectiveMethod` list | Reuses concrete implementation-to-annotation-bundle bindings during locator traversal. It is internal to one analyzer. |

An inventory is not one of these resolver indexes. It is an application result
that records recognized annotation occurrences for reporting; it does not
choose Java type, member, or handler identity.

## Java data structures by module

The examples in this section are Python-shaped views of the real application
objects. Names ending in `_node`, `_tree`, or `_unit` stand for live retained
Tree-sitter or compilation-unit objects, not strings reconstructed from source.

### `noir.java_frontend`

The principal data structure is the compilation-unit dictionary returned by
`build_java_compilation_unit()`. It starts with per-file facts; workspace
construction later attaches package-collision and member-index references:

~~~python
items_unit = {
    # identity and parser lifetime
    "source_path": "/workspace/app/ItemsController.java",
    "source": b"package app; ...",
    "tree": items_tree,
    "lifetime_owners": [items_tree, (type_query_cursor, type_query_matches), ...],

    # raw query products
    "matches": {
        "package": [...],
        "import": [...],
        "type": [...],
        "method_annotation": [...],
        ...,
    },

    # same-file name facts
    "package": "app",
    "imports": {
        "exact": {
            "GetMapping": "org.springframework.web.bind.annotation.GetMapping"
        },
        "wildcards": set(),
        "static_exact": {"ROOT": "routes.Paths.ROOT"},
        "static_wildcards": set(),
    },
    "type_infos": {
        items_type_key: {
            "node": items_type_node,
            "simple_name": "ItemsController",
            "display_name": "ItemsController",
            "outer_key": None,
            "abstract": False,
            "workspace_visible": True,
            "mapping": None,
        }
    },
    "local_types": {"ItemsController"},
    "local_annotations": set(),
    "annotation_occurrences": [
        {"node": get_mapping_node, "name_node": get_mapping_name_node}
    ],

    # complete query matches grouped by their owning declaration
    "type_candidates": {items_type_key: [...]},
    "method_candidates": {list_method_key: [...]},
    "record_component_candidates": {},
    "record_explicit_accessors": set(),
    "meta_candidates": {},
    "element_candidates": {},

    # attached by java_workspace after every unit exists
    "package_types": {"Fast", "RestApplication"},
    "wildcard_source_types": {},
    "workspace_constant_records": [],
    "workspace_member_declarations": workspace_member_declarations,
    "workspace_static_member_declarations": workspace_static_declarations,
}
~~~

For example, one entry in `items_unit["matches"]["type"]` has the shape
`(pattern_index, {"type.node": [items_type_node], "type.name":
[items_type_name_node]})`. Candidate groupings retain these complete capture
dictionaries so nodes from separate query matches are never accidentally
combined.

The byte-range keys such as `items_type_key` are `(start_byte, end_byte)` and
are unique only inside this unit. A complete record carries its unit whenever
it moves into a cross-file index.

### `noir.java_ast`

`java_ast` intentionally defines no second AST or wrapper class. Its data is a
compilation unit plus live Tree-sitter `Node` objects. A node provides, among
other parser attributes, `type`, `start_byte`, `end_byte`, `parent`,
`children`, and `named_children`. The helpers make bounded questions about
that existing structure:

~~~python
name_node = java_ast.field(list_method_node, "name")
java_ast.source_text(items_unit, name_node)             # "list"
list(java_ast.walk_named(list_method_node))             # source-order subtree
java_ast.raw_type_node(list_return_type_node)            # unwrapped raw type node
java_ast.known_type(items_unit, string_node, "String", "java.lang")  # True
java_ast.is_direct_invocation_statement(route_call_node, body_node)   # True/False
~~~

The last call distinguishes a fluent route call that is a direct statement in
the handler/configuration body from one nested in a return, assignment,
lambda, or unrelated expression.

### `noir.java_methods`

This module turns method syntax into three application structures:

| Structure | Application content |
|---|---|
| `FormalParameter` | handler input name, type syntax, full declaration syntax, and whether it is the accepted varargs form |
| `MethodFact` | one executable source handler with its owning unit/type, name and return/input/body nodes, normalized formal inputs, and modifiers |
| `MethodIndex` | all accepted handlers in deterministic source order plus owner/name overload buckets |

For the source method `public String list(String filter) { ... }`, an illustrative
index is:

~~~python
filter_parameter = FormalParameter(
    name="filter",
    type_node=string_type_node,
    node=filter_parameter_node,
    varargs=False,
)

list_method = MethodFact(
    unit=items_unit,
    owner_info=items_info,
    owner_fqn="app.ItemsController",
    node=list_method_node,
    name_node=list_name_node,
    return_type_node=string_return_type_node,
    parameters_node=list_parameters_node,
    body_node=list_body_node,
    parameters=(filter_parameter,),
    modifiers=frozenset({"public"}),
)

method_index = MethodIndex(
    methods=(list_method,),
    by_owner_name={
        ("app.ItemsController", "list"): (list_method,)
    },
)
~~~

The bucket contains all accepted overloads. A DSL recognizer applies its own
argument and type rules after lookup; the index itself does not call the
method or decide that it defines an endpoint.

### `noir.java_hierarchy`

The neutral hierarchy represents types before framework meaning is added:

| Structure | Application content |
|---|---|
| `JavaTypeReference` | a declared type, type variable, primitive, or erasure-only reference; optional generic arguments and array dimensions |
| `JavaMethodRecord` | one source method's owner, source identity, annotations, modifiers, parsed parameter/result references, and method-generic bounds |
| `JavaTypeRecord` | one unique traversable class/interface/record with direct methods, superclass, interfaces, and type-variable bounds |
| `JavaHierarchyContext` | one adapted class chain, reachable interface roots, and a `complete` proof flag for a selected concrete type |
| `JavaSourceHierarchyGraph` | workspace plus FQN-keyed `types` and its environment-sensitive signature cache |

Given:

~~~java
package app;

record Item(String id) {}

interface ItemsApi<T> {
    T find(String id);
}

final class ItemsResource implements ItemsApi<Item> {
    public Item find(String id) { return null; }
}
~~~

the central records have this shape:

~~~python
item_ref = JavaTypeReference("decl", "app.Item")
string_ref = JavaTypeReference("decl", "java.lang.String")
api_edge = JavaTypeReference("decl", "app.ItemsApi", (item_ref,))

api_record = JavaTypeRecord(
    fqn="app.ItemsApi",
    unit=api_unit,
    type_info=api_info,
    kind="interface_declaration",
    type_parameters=("T",),
    methods=[api_find_method],
    interfaces=(),
)

resource_record = JavaTypeRecord(
    fqn="app.ItemsResource",
    unit=resource_unit,
    type_info=resource_info,
    kind="class_declaration",
    type_parameters=(),
    methods=[resource_find_method],
    interfaces=(api_edge,),
    interfaces_valid=True,
)

graph.types == {
    "app.ItemsApi": api_record,
    "app.ItemsResource": resource_record,
    ...,
}

context = JavaHierarchyContext(
    class_states=[(resource_record, {})],
    interface_roots=[(api_record, {"T": item_ref})],
    complete=True,
)
~~~

`JavaMethodRecord.parameter_refs` for both `find` declarations contains
`string_ref`. After adapting `T` to `app.Item`, their erased override signature
is `("find", ("java.lang.String",))`. The graph reports `complete=False`
instead of inferring through an unresolved edge, cycle, generic conflict, or
proof bound.

### `noir.jaxrs_hierarchy`

`JaxRsHierarchyAnalyzer` subclasses the neutral graph, so it retains the same
`types` records and adds JAX-RS binding state:

| Structure | Application content |
|---|---|
| `JaxRsEffectiveMethod` | concrete implementation, its generic environment, the method supplying the indivisible JAX-RS annotation bundle, decoded leaf/locator binding, whether hierarchy added it, and erased signature |
| `SubresourceTypeState` | concrete return-type FQN plus adapted generic environment used as branch-local locator cycle identity |
| `_effective_cache` | already selected effective methods by resource, generic environment, and Javax/Jakarta namespace |

An inherited `@GET @Path("/items/{id}")` interface contract bound to
`ItemsResource.find` is represented approximately as:

~~~python
effective = JaxRsEffectiveMethod(
    implementation=resource_find_method,
    implementation_env={},
    annotation_source=api_find_method,
    binding={
        "kind": "leaf",
        "path": "/items/{id}",
        "method": "GET",
        "evidence_node": get_annotation_node,
        "annotation_identity": "jakarta.ws.rs.GET",
        "annotation_family": "jax-rs-designator",
    },
    hierarchy_added=True,
    signature=("find", ("java.lang.String",)),
)

state = SubresourceTypeState(
    record_fqn="app.ItemSubresource",
    env_key=(("T", JavaTypeReference("decl", "app.Item")),),
)
~~~

The effective record is not yet an endpoint. The analyzer must also prove the
resource root, interface path layer, deployment prefix, and any locator path,
then constructs an `EndpointFact`. A complete JAX-RS hierarchy example appears
in [06 — Hierarchy binding](06-jax-rs.md#9-hierarchy-binding).

### Analyzer mechanism terms

| Term | Meaning | Short example |
|---|---|---|
| **workspace index** | One of the shared lookup views above, derived once and reused by multiple framework passes. | Resolve `ROOT` through `constants_by_owner_member[("routes.Paths", "ROOT")]`. |
| **direct decoder** | Interprets route evidence physically attached to a concrete type, method, or record component in one compilation unit. It can use workspace resolution but does not infer an inherited route or trace a configuration DSL. | Decode `@GetMapping("/items")` on `ItemsController.list`. |
| **hierarchy graph** | Source-type and method relationships used to prove an inherited contract and select its concrete implementation. | Bind interface `ItemsApi.find` to class method `ItemsResource.find`. |
| **functional/DSL recognizer** | Follows a bounded, explicitly modeled invocation shape in source method bodies. It recognizes API calls and aliases; it does not execute arbitrary Java. | Recognize `RouterFunctions.route(GET("/items"), handler::list)` or a supported Gateway route chain. |

## 5. Framework vocabulary

The technology name is **JAX-RS** in code and prose. The public CLI selector
remains `jaxrx`.

### Spring owners

| Module | Surface |
|---|---|
| [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) | direct MVC mappings, composed annotations, records, and mapping indexes |
| [`noir/spring_route_registrations.py`](../src/noir/spring_route_registrations.py) | functional routes and programmatic MVC registrations |
| [`noir/spring_mvc_hierarchy.py`](../src/noir/spring_mvc_hierarchy.py) | inherited mapping contracts bound to concrete controllers |
| [`noir/spring_gateway.py`](../src/noir/spring_gateway.py) | Spring Cloud Gateway Java DSL routes |
| [`noir/spring_config.py`](../src/noir/spring_config.py) | project path configuration and static resource handlers |
| [`noir/spring_clients.py`](../src/noir/spring_clients.py) | HTTP Interface and OpenFeign outbound contracts |
| [`noir/spring_websocket_messaging.py`](../src/noir/spring_websocket_messaging.py) | raw/STOMP handshakes and message destinations |

### JAX-RS and WebSocket owners

| Module | Surface |
|---|---|
| [`noir/jaxrs.py`](../src/noir/jaxrs.py) | direct resources, custom request methods, records, and application paths |
| [`noir/jaxrs_deployment.py`](../src/noir/jaxrs_deployment.py) | source applications and bounded `web.xml` deployment prefixes |
| [`noir/jaxrs_hierarchy.py`](../src/noir/jaxrs_hierarchy.py) | inherited resource bundles and recursive subresource locators |
| [`noir/java_websocket.py`](../src/noir/java_websocket.py) | Javax/Jakarta server handshakes |

**Direct** means that route evidence is interpreted on its concrete source
declaration while reusing the unit already in the workspace.

**Direct Spring MVC** is therefore the per-compilation-unit pass that composes
mapping annotations physically present on lexical types with a mapping on a
concrete method or eligible record component. It is “direct” in contrast to an
inherited interface/superclass contract and to a route expressed as calls in a
method-body DSL; it does not mean a special kind of HTTP connection.

~~~java
@RequestMapping("/api")
class ItemsController {
    @GetMapping("/items")
    Item list(String filter) { return null; }
}
~~~

The direct Spring MVC pass can emit `GET /api/items` with handler
`ItemsController.list` and parameter spelling `String filter` from this unit.
Hierarchy analysis is not needed because both path layers and the concrete
handler are present on these declarations.

**Supplemental surface** means another route-bearing mechanism beyond direct
annotation mappings: hierarchy, functional registration, Gateway, resources,
clients, deployment, subresources, or messaging.

**Fail closed** means an unsupported or ambiguous candidate contributes no
endpoint fact. The analyzer normally records a diagnostic at that rejection
boundary and continues with independent candidates.

## 6. Analyzer boundaries

Framework analyzers import constants, Java helpers, evidence operations, and
diagnostic recording from their owning `noir` modules. Their public entry
points receive only semantic inputs such as a source, compilation unit,
workspace, or Spring path configuration.

Every endpoint producer returns `EndpointFact` directly. Analyzer-local
deduplication calls
[`deduplicate_endpoint_facts()`](../src/noir/evidence.py) with a
surface-specific identity function; the shared operation merges annotation
evidence and represented targets deterministically. The pipeline rejects any
non-`EndpointFact` result before constructing `AnalysisResult`.

This boundary keeps extraction code independent of CLI parsing, stdout, file
publication, and executable-launcher state.

## 7. Endpoint and evidence vocabulary

An `EndpointFact` keeps distinctions that the public CSV cannot represent:

- technology, protocol, surface, and direction;
- request method, path, handler name, and parameters;
- public source ownership;
- route, handler, and project/configuration provenance;
- `AnnotationEvidence` values;
- `SourceTarget` values represented by the endpoint;
- unresolved Spring client path layers until project configuration applies.

A **represented target** is an exact source declaration identity: canonical
file, declaration kind, and byte span. Surviving targets are used to subtract
represented declarations from the endpoint-trigger inventory.

A **row candidate** is the first public projection of an endpoint fact. A
**consolidated endpoint set** contains deterministically ordered public rows
plus merged represented targets needed by reports.

~~~mermaid
flowchart LR
    F[EndpointFact] -->|project once| C[EndpointRowCandidate]
    C -->|normalize + group| O[ConsolidatedEndpoints]
    O --> CSV[Seven CSV fields]
    O --> T[Represented targets]
~~~

The first six CSV fields form row identity. `method_annotation_line` is chosen
only after all validated same-file annotation evidence for that identity has
been merged.

## 8. Effects and artifact ownership

Use these verbs consistently:

| Verb | Meaning |
|---|---|
| `record` | append a diagnostic to the current run's collector |
| `render` | create bytes or text without changing the filesystem |
| `write` | serialize a CSV or diagnostic log at its owning boundary |
| `publish` | atomically replace a prepared byte-report destination |
| `announce` | return stable text for the CLI to print |

[`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` owns argument validation,
output naming, projection, report preparation, publication order, and stdout.
Analyzers return facts and record diagnostics; they do not write artifacts.

The endpoint CSV and diagnostic log are direct writes. Byte reports are
atomically replaced individually. The complete artifact set is therefore not
one filesystem transaction.

Framework announcements are printed after analysis. The completion inventory
from `render_completion_summary()` is printed only after every requested
artifact has been published successfully.

## 9. Public names that remain stable

- `src/noir_sbt.py` is the executable path and delegates directly to
  `noir.cli.main`.
- `--framework jaxrx` selects JAX-RS.
- Repeating `--framework` selects several explicit families; execution and
  presentation order remains the static adapter order.
- The CSV columns are `module_name`, `interface_type`, `endpoint`,
  `source_file_name`, `method_name`, `parameters`, and
  `method_annotation_line`.
- The diagnostic companion is `<output>.log`.
- The endpoint-trigger report ends in `-anno-without-endpoints.log`.
- With `--noir-report`, the exact source-location comparison ends in
  `-anno-without-noir-endpoints.log`.
- Established `Found ...` announcements and the success line
  `noir-ts analysis completed.` remain user-visible contracts.

The comparison report is occurrence-based. An unmatched recognized annotation
is not, by itself, proof that Noir missed an endpoint.

## 10. Practical reading route

Read current code in this order:

1. [`src/noir_sbt.py`](../src/noir_sbt.py) for the executable handoff;
2. [`noir/cli.py`](../src/noir/cli.py) :: `run_cli()` for the user-visible
   transaction;
3. [`noir/application.py`](../src/noir/application.py) :: `analyze()` for the
   typed programmatic boundary;
4. [`noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` for exact
   stage order;
5. `SourceSnapshot` and
   [`build_java_workspace()`](../src/noir/java_workspace.py) for parse-once
   shared data;
6. [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) or
   [`noir/jaxrs.py`](../src/noir/jaxrs.py) for direct framework semantics;
7. one supplemental analyzer for its bounded source surface;
8. [`noir/model.py`](../src/noir/model.py) :: `EndpointFact` and
   [`noir/evidence.py`](../src/noir/evidence.py) for the analyzer result
   contract;
9. [`noir/output.py`](../src/noir/output.py),
   [`noir/reports.py`](../src/noir/reports.py), and
   [`noir/comparison.py`](../src/noir/comparison.py) for projection and
   artifacts.

Continue with [12 — Core runtime methods](12-core-runtime-methods.md), or
return to the [guide index](README.md).
