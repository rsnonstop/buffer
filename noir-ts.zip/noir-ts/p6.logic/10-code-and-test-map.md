# 10 — Code and test map

[← Worked traces](08-worked-traces.md) · [Index](README.md) · [Naming and vocabulary →](11-naming-and-code-vocabulary.md)

This chapter maps current behavior to its owning source and regression tests.
Coordinates use linked files plus stable symbols instead of line numbers.

## 1. Architectural route

~~~mermaid
flowchart TB
    LAUNCH["src/noir_sbt.py<br/>executable guard"]
    CLI["noir.cli<br/>arguments, artifacts, stdout"]
    APP["noir.application<br/>typed diagnostic scope"]
    PIPE["noir.pipeline<br/>snapshot, selection, pass order"]
    RUNTIME["tree_sitter_runtime<br/>version gate and runtime"]
    JAVA["java_frontend + java_workspace<br/>parse once and index"]
    SPRING["Spring analyzers"]
    JAX["JAX-RS analyzers"]
    MODEL["noir.model<br/>typed facts and result"]
    INV["noir.inventory<br/>broad and trigger views"]
    OUTPUT["noir.output<br/>projection and consolidation"]
    REPORTS["noir.reports + noir.comparison<br/>render and publish"]

    LAUNCH --> CLI --> APP --> PIPE
    PIPE --> RUNTIME --> JAVA
    JAVA --> SPRING --> MODEL
    JAVA --> JAX --> MODEL
    JAVA --> INV --> MODEL
    MODEL --> OUTPUT --> REPORTS
    CLI --> REPORTS
~~~

`src/noir_sbt.py` is intentionally a thin launcher. Application behavior lives
under `src/noir/`, whose modules import their real owners directly. Framework
analyzers consume the shared workspace and emit `EndpointFact` values; they do
not depend on the launcher, mutate command state, or publish files.

### Fast implementation trail

| Step | Code coordinate | Responsibility |
|---|---|---|
| launch | [`src/noir_sbt.py`](../src/noir_sbt.py) :: executable guard | Import `noir.cli.main` and exit with its status. |
| validate and publish | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` | Validate inputs, bind diagnostics, invoke analysis, project facts, publish requested artifacts in order, and print success output. |
| own one typed run | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` | Validate `AnalysisRequest`, own or reuse a collector, call the pipeline, and attach only this invocation's diagnostics. |
| orchestrate analysis | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | Validate parser availability, snapshot sources, select frameworks, build one workspace, run analyzers, and return `AnalysisResult`. |
| build parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `require_tree_sitter()`, `build_workspace_runtime()` | Enforce the supported dependency pair and construct the parser/query runtime. |
| parse and index | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` → [`src/noir/java_frontend.py`](../src/noir/java_frontend.py) :: `build_java_compilation_unit()` | Parse each snapshotted source once and build shared per-file and cross-file facts. |
| run direct mappings | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()`; [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` | Interpret proven direct Spring and JAX-RS annotations as typed endpoint facts. |
| build inventories | [`src/noir/inventory.py`](../src/noir/inventory.py) :: `build_annotation_audit_inventory()`, `build_final_trigger_inventory()` | Build the broad annotation view and the narrower endpoint-trigger view from the shared workspace. |
| project and consolidate | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()`, `consolidate_endpoint_rows()` | Cross the public information-loss boundary, normalize identity, merge evidence, and select the annotation line. |
| render reports | [`src/noir/reports.py`](../src/noir/reports.py) :: `render_annotations_without_endpoints_report_bytes()`; [`src/noir/comparison.py`](../src/noir/comparison.py) :: `compare_annotation_audit_inventory()` | Render the trigger-based absent report and optional exact source-location comparison. |

## 2. Package ownership

### 2.1 Invocation and application core

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.cli`](../src/noir/cli.py) | `build_argument_parser`, `run_cli`, `render_completion_summary` | User input, filesystem effects, publication order, and stdout. |
| [`noir.application`](../src/noir/application.py) | `AnalysisRunner`, `analyze` | Typed call boundary and diagnostic ownership. |
| [`noir.pipeline`](../src/noir/pipeline.py) | `SourceSnapshot`, `FrameworkDecision`, `run_analysis` | Complete source-to-result ordering with no artifact I/O. |
| [`noir.discovery`](../src/noir/discovery.py) | `discover_java_files`, `discover_pom_files`, `scan_framework_markers` | Ignored-path pruning, deterministic discovery, and marker-based auto selection. |
| [`noir.tree_sitter_runtime`](../src/noir/tree_sitter_runtime.py) | `SUPPORTED_VERSIONS`, `require_tree_sitter`, `build_workspace_runtime`, `run_query_matches` | Parser package gate and query runtime construction. |
| [`noir.diagnostics`](../src/noir/diagnostics.py) | `DiagnosticCollector`, `bind`, `record`, `format_endpoint_diagnostic` | Run-scoped diagnostic capture and stable endpoint messages. |
| [`noir.contracts`](../src/noir/contracts.py) | `CSV_FIELDS`, framework constants, evidence-family constants | Shared declarative vocabulary used by analyzers and presentation. |

### 2.2 Shared Java engine

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.java_queries`](../src/noir/java_queries.py) | `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | Framework-neutral query-source definitions. |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `parse_java_query_set`, `build_java_compilation_unit`, `resolve_known_annotation`, `resolve_known_type` | Tree-sitter parsing, capture association, per-file facts, and known-library identity. |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace`, `resolve_workspace_owner_fqns`, `resolve_workspace_string_expression` | Cross-file types, members, constants, annotations, retention, and access rules. |
| [`noir.java_ast`](../src/noir/java_ast.py) | `field`, `walk_named`, `known_type`, `is_direct_invocation_statement` | Small shared AST navigation and proof helpers. |
| [`noir.java_methods`](../src/noir/java_methods.py) | `MethodFact`, `MethodIndex`, `build_strict_method_index`, `build_varargs_method_index` | Deterministic method and invocation indexes for bounded source flows. |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord`, `JavaSourceHierarchyGraph` | Generic adaptation, erased signatures, inheritance traversal, and implementation selection. |
| [`noir.paths`](../src/noir/paths.py) | `join_endpoint_paths`, `ensure_path_leading_slash`, `relative_source_path` | Neutral route composition and public source-path formatting. |

Runtime construction belongs to `tree_sitter_runtime`; the actual source parse
belongs to `java_frontend`. Framework analyzers receive parsed workspace
products and never construct their own parser.

### 2.3 Framework analyzers

| Owner | Entry point | Surface |
|---|---|---|
| [`noir.spring_mvc`](../src/noir/spring_mvc.py) | `analyze_direct_spring_mvc_unit` | Direct MVC mappings, composed annotations, records, and mapping indexes. |
| [`noir.spring_route_registrations`](../src/noir/spring_route_registrations.py) | `analyze_spring_route_registrations` | Functional RouterFunction routes and programmatic MVC registrations. |
| [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) | `analyze_spring_mvc_hierarchy` | Inherited mapping contracts bound to concrete controllers. |
| [`noir.spring_gateway`](../src/noir/spring_gateway.py) | `analyze_spring_gateway` | Spring Cloud Gateway Java DSL routes. |
| [`noir.spring_config`](../src/noir/spring_config.py) | `build_spring_path_configuration`, `analyze_spring_resource_handlers`, `apply_spring_path_configuration` | Project configuration, resource handlers, placeholders, and final Spring path layers. |
| [`noir.spring_clients`](../src/noir/spring_clients.py) | `analyze_spring_http_clients` | Spring HTTP Interface and OpenFeign outbound contracts. |
| [`noir.spring_websocket_messaging`](../src/noir/spring_websocket_messaging.py) | `analyze_spring_websocket_and_messaging` | Raw/STOMP handshakes and message destinations. |
| [`noir.jaxrs`](../src/noir/jaxrs.py) | `analyze_direct_jax_rs_unit` | Direct resources, custom request methods, record accessors, and application paths. |
| [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) | `build_jax_rs_deployment_model`, `select_jax_rs_deployment_prefix` | Source applications and bounded `web.xml` deployment prefixes. |
| [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) | `analyze_jax_rs_hierarchy_and_subresources` | Inherited resource bundles and recursive subresource locators. |
| [`noir.java_websocket`](../src/noir/java_websocket.py) | `analyze_java_websocket_endpoints` | Javax/Jakarta WebSocket server handshakes. |

Every entry point above returns `EndpointFact` values. Local deduplication uses
an analyzer-specific identity callback and the shared typed evidence merger in
`noir.evidence`.

### 2.4 Domain, evidence, and presentation

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.model`](../src/noir/model.py) | `AnalysisRequest`, `FrameworkPlan`, `EndpointFact`, `AnalysisResult` | Immutable application vocabulary. |
| [`noir.evidence`](../src/noir/evidence.py) | `method_annotation_evidence_from_node`, `represented_target_evidence`, `deduplicate_endpoint_facts` | Validate, merge, and select typed provenance. |
| [`noir.inventory`](../src/noir/inventory.py) | `build_annotation_audit_inventory`, `build_final_trigger_inventory` | Broad and endpoint-trigger annotation views. |
| [`noir.output`](../src/noir/output.py) | `EndpointRowCandidate`, `ConsolidatedEndpoints`, `consolidate_endpoint_rows`, `write_endpoint_csv` | Public row projection, six-field grouping, seventh-field selection, and exact CSV bytes. |
| [`noir.reports`](../src/noir/reports.py) | `write_annotation_diagnostic_log`, `render_annotations_without_endpoints_report_bytes`, `publish_bytes_atomically` | Baseline companion artifacts. |
| [`noir.comparison`](../src/noir/comparison.py) | `load_noir_report_locations`, `compare_annotation_audit_inventory`, `render_noir_comparison_report_bytes` | Strict Noir report validation and exact canonical file/line comparison. |
| [`noir.immutability`](../src/noir/immutability.py) | `freeze_data` | Detach and freeze nested result data. |

## 3. Exact analyzer order

`run_analysis()` first creates the snapshot, framework decision, shared
workspace, and broad annotation inventory. It builds the final-trigger
inventory when at least one framework is selected. When JAX-RS is selected it
also builds the deployment model before endpoint extraction.

Spring order:

1. direct Spring MVC for each source;
2. functional and programmatic route registrations;
3. MVC hierarchy additions;
4. Gateway;
5. static resource handlers;
6. outbound clients;
7. project path configuration;
8. WebSocket and messaging;
9. one final Spring path-configuration application across collected facts.

JAX-RS order:

1. direct JAX-RS for each compilation unit;
2. hierarchy and subresource additions;
3. Java WebSocket handshakes.

These passes share one workspace. Their iteration order may affect diagnostics,
but public rows are normalized, grouped, and sorted later by `noir.output`.

## 4. Test map

[`tests/noir_test_support.py`](../tests/noir_test_support.py) provides the
native parser-availability check, in-memory workspace builder, and typed
application helper used by semantic tests.

| Test family | Main files | Responsibility |
|---|---|---|
| architecture and documentation | [`test_noir_architecture.py`](../tests/test_noir_architecture.py), [`test_noir_documentation.py`](../tests/test_noir_documentation.py) | Dependency direction, launcher shape, framework-neutral core ownership, parser ownership, and code/guide navigability. |
| application core | [`test_noir_application.py`](../tests/test_noir_application.py), [`test_noir_diagnostics.py`](../tests/test_noir_diagnostics.py), [`test_noir_pipeline.py`](../tests/test_noir_pipeline.py), [`test_noir_parse_once.py`](../tests/test_noir_parse_once.py) | Typed requests/results, diagnostic isolation, framework order, source snapshotting, and one parse per file. |
| domain and output | [`test_noir_domain_model.py`](../tests/test_noir_domain_model.py), [`test_noir_paths.py`](../tests/test_noir_paths.py), [`test_noir_output.py`](../tests/test_noir_output.py) | Immutable facts, path composition, evidence merge, normalization, grouping, and CSV bytes. |
| executable contract | [`test_noir_sbt_cli_black_box.py`](../tests/test_noir_sbt_cli_black_box.py), [`test_noir_comparison_cli.py`](../tests/test_noir_comparison_cli.py) | Script invocation, help/failure behavior, artifact order, stdout, and optional comparison mode. |
| broad Java/framework behavior | [`test_noir_sbt.py`](../tests/test_noir_sbt.py), [`test_noir_sbt_differentiators.py`](../tests/test_noir_sbt_differentiators.py), [`test_noir_sbt_record_and_custom_method_extensions.py`](../tests/test_noir_sbt_record_and_custom_method_extensions.py) | Parser gates, resolution, direct Spring/JAX behavior, record accessors, and custom method annotations. |
| discovery and annotation views | [`test_noir_sbt_framework_auto.py`](../tests/test_noir_sbt_framework_auto.py), [`test_noir_sbt_annotation_log.py`](../tests/test_noir_sbt_annotation_log.py), [`test_noir_sbt_absent_annotation_log.py`](../tests/test_noir_sbt_absent_annotation_log.py), [`test_noir_sbt_method_annotation_line.py`](../tests/test_noir_sbt_method_annotation_line.py) | Marker selection, inventories, diagnostic rendering, represented targets, and annotation-line evidence. |
| specialized Spring surfaces | `tests/test_noir_sbt_spring_*.py` | Clients, configuration/resources, Gateway, hierarchy, registrations, and messaging. |
| JAX-RS and Java WebSocket | `test_noir_sbt_jax_rs_direct.py`, `test_noir_sbt_jax_rs_deployment.py`, `test_noir_sbt_jax_rs_hierarchy_subresources.py`, `test_noir_sbt_java_websocket.py` | Direct resources, deployment ownership, hierarchy/subresources, namespace rules, and handshakes. |
| Noir comparison | [`test_noir_comparison.py`](../tests/test_noir_comparison.py), [`test_noir_comparison_cli.py`](../tests/test_noir_comparison_cli.py) | Report validation, canonical locations, matching, rendering, naming, and publication failures. |

## 5. High-value invariants

| Invariant | Primary regression home |
|---|---|
| The script is only an executable launcher; package code never imports it. | `test_noir_architecture.py`, `test_noir_sbt_cli_black_box.py` |
| Parser packages/runtime construction have one native owner; source parsing has one frontend owner. | `test_noir_architecture.py`, `test_noir_parse_once.py` |
| Each discovered Java source is read and parsed once, then reused by every selected pass. | `test_noir_parse_once.py`, `test_noir_pipeline.py` |
| The pipeline rejects analyzer output that is not an `EndpointFact`; semantic analyzer tests exercise the typed entry points directly. | `test_noir_pipeline.py` and each semantic analyzer test |
| Diagnostics are run scoped, and only the CLI owns artifact publication and stdout. | `test_noir_application.py`, `test_noir_diagnostics.py`, `test_noir_sbt_cli_black_box.py` |
| Ambiguous Java identity, constants, hierarchy, deployment, or flow fail closed locally. | nearest direct or specialized analyzer test |
| Duplicate facts merge annotation evidence and represented targets deterministically. | `test_noir_domain_model.py`, `test_noir_output.py`, specialized analyzer tests |
| The first six CSV fields define row identity; the annotation line is selected after evidence merge. | `test_noir_output.py`, `test_noir_sbt_method_annotation_line.py` |
| CLI success appears only after all requested artifacts publish. | `test_noir_sbt_cli_black_box.py`, `test_noir_comparison_cli.py` |

## 6. Where a regression belongs

| Change | First test home | Add another layer when… |
|---|---|---|
| CLI validation, naming, publication, or stdout | black-box or comparison CLI test | internal rendering logic also changed |
| request/result or diagnostic scope | application/diagnostics test | stage ordering also changed |
| discovery or auto markers | framework-auto test | invocation output changes |
| parser/query construction | frontend or parse-once test | cross-file resolution changes |
| imports, types, constants, access, or ambiguity | differentiator or nearest analyzer test | more than one surface consumes it |
| direct Spring or JAX semantics | matching direct analyzer test | hierarchy/configuration participates |
| one supplemental surface | matching Spring/JAX/WebSocket test | public grouping or report evidence changes |
| evidence ownership or deduplication | domain/output/method-line test | artifact bytes change |
| Noir report parsing or matching | comparison unit test | CLI order or filesystem state changes |
| module dependency or forbidden effect | architecture test | semantic behavior must also be demonstrated |

A useful semantic regression pairs one accepted source shape with its closest
look-alike that must fail closed: a shadowed import, ambiguous constant,
unsupported placement, mixed namespace, cycle, or unresolved value.

## 7. Validation

Use the pinned environment from [`src/requirements.txt`](../src/requirements.txt).

~~~bash
PYTHONDONTWRITEBYTECODE=1 \
  .venv/bin/python -m unittest discover -s tests -p 'test_noir*.py'

PYTHONDONTWRITEBYTECODE=1 \
  .venv/bin/python -m compileall -q src tests

git diff --check
~~~

Inspect skips: parser-backed tests can skip when the required dependency pair
is unavailable.

## 8. Chapter-to-code index

| Chapter | First code coordinate |
|---|---|
| [Mental model](01-mental-model.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [CLI and orchestration](02-cli-and-orchestration.md) | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` |
| [Shared Java engine](03-shared-java-engine.md) | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` |
| [Spring MVC](04-spring-mvc.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [Additional Spring surfaces](05-spring-additional-surfaces.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `_analyze_spring()` |
| [JAX-RS](06-jax-rs.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Output and reports](07-output-evidence-reports.md) | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` |
| [Worked traces](08-worked-traces.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Production use](09-production-use.md) | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` |
| [Naming and vocabulary](11-naming-and-code-vocabulary.md) | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` |
| [Core runtime methods](12-core-runtime-methods.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Spring methods](13-spring-methods.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Method lookup](15-method-lookup.md) | exact symbol search across the three method guides |

Return to the [guide index](README.md), or continue to
[Naming and code vocabulary](11-naming-and-code-vocabulary.md).
