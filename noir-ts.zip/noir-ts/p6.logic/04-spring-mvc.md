# 04 — Spring MVC logic

[← Shared Java engine](03-shared-java-engine.md) · [Index](README.md) · [Additional Spring surfaces →](05-spring-additional-surfaces.md)

This chapter explains direct annotated methods, record-component accessors,
source-defined composed mappings, and inherited controller contracts. Other
Spring endpoint mechanisms are covered in
[05 — Additional Spring surfaces](05-spring-additional-surfaces.md).

> [`noir/spring_mvc.py`](../src/noir/spring_mvc.py) owns Spring mapping
> semantics. It consumes shared Java facts and emits `EndpointFact` values.

Method-level companion: [13 — Spring methods](13-spring-methods.md) expands
the direct, composed-annotation, alias, and hierarchy call graphs.

## 1. Owners and entry points

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.spring_mvc`](../src/noir/spring_mvc.py) | `analyze_direct_spring_mvc_unit()`, `decode_builtin_spring_mapping()`, `decode_spring_composed_mapping()`, `attach_workspace_indexes()` | direct mappings, composed annotations, `AliasFor`, and Spring annotation indexes |
| [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) | `SpringMvcHierarchyAnalyzer`, `analyze_spring_mvc_hierarchy()` | inherited mapping contracts bound to concrete controllers |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `resolve_known_annotation()`, query-group and source-text helpers | same-file syntax and library identity |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `resolve_workspace_string_expression()`, annotation declaration/access/retention helpers | cross-file values and source annotation identity |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaSourceHierarchyGraph` | source type graph, generic substitution, erased signatures, and interface specificity |
| [`noir.evidence`](../src/noir/evidence.py) | `method_annotation_evidence_from_mapping()`, `represented_target_evidence()` | typed provenance |
| [`noir.pipeline`](../src/noir/pipeline.py) | `_analyze_spring()` | direct-unit iteration and ordered Spring passes |

The framework modules import Java helpers, path composition, evidence builders,
and diagnostic recording from their native owners. They do not construct a
parser or publish artifacts.

## 2. Shared-unit analysis

The pipeline builds one workspace and attaches Spring annotation definitions
before endpoint extraction. For each snapshotted source, it looks up the
compilation unit and calls:

~~~python
analyze_direct_spring_mvc_unit(unit, workspace)
~~~

The direct analyzer reuses:

- exact source bytes and syntax nodes;
- imports and declaration query groups;
- type, method, and record-component query groups;
- whole-workspace String resolution, including same-file and cross-file constants;
- source annotation declarations and Spring definition indexes.

It copies per-type records before adding analysis-local mapping state; the
shared unit and Tree-sitter nodes remain unchanged.

`attach_workspace_indexes()` calls
`build_spring_annotation_definitions()` on the finished neutral workspace. It
does not read or parse source.

~~~mermaid
sequenceDiagram
    participant P as noir.pipeline
    participant W as shared Java workspace
    participant I as Spring index attachment
    participant D as direct Spring analyzer
    participant H as hierarchy analyzer

    P->>W: parse every snapshot source once
    W->>I: attach source annotation definitions
    loop each compilation unit
        P->>D: analyze_direct_spring_mvc_unit(unit, workspace)
        D->>W: reuse syntax and indexes
    end
    P->>H: analyze_spring_mvc_hierarchy(workspace)
    H->>W: reuse hierarchy and mapping facts
~~~

## 3. Direct MVC flow

~~~mermaid
flowchart TD
    A[shared compilation unit] --> T[decode mappings on lexical types]
    T --> M[visit annotated methods in source order]
    M --> E{concrete workspace-visible class or record?}
    E -- no --> Skip[skip target]
    E -- yes --> F[first recognized method mapping]
    F --> V{valid?}
    V -- no --> Skip
    V -- yes --> L[compose outer-to-inner type mappings]
    L --> C{every recognized type layer valid?}
    C -- no --> Skip
    C -- yes --> X[fan out paths and ordered method union]
    X --> Fact[emit EndpointFact values]

    T --> R[visit annotated record components]
    R --> Z{eligible implicit accessor?}
    Z -- no --> Skip
    Z -- yes --> F
~~~

A directly emitted ordinary method belongs to a captured class or record that
is non-abstract and workspace-visible. Interfaces, abstract classes, and types
inside methods, blocks, lambdas, or initializers do not emit direct facts.

The direct pass does not require:

- `@Controller` or `@RestController`;
- a public type or method;
- a non-static method;
- a method body;
- proof of bean activation.

This is a deliberate false-positive boundary: a genuine mapping on an
otherwise unactivated concrete source owner can emit an endpoint.

## 4. Built-in mapping identity

The supported package is
`org.springframework.web.bind.annotation`.

| Annotation | Method condition |
|---|---|
| `GetMapping` | `GET` |
| `PostMapping` | `POST` |
| `PutMapping` | `PUT` |
| `DeleteMapping` | `DELETE` |
| `PatchMapping` | `PATCH` |
| `RequestMapping` | explicit ordered set, or unconstrained |

`resolve_spring_mapping_name()` accepts an exact fully qualified name, a
matching exact import, or the genuine Spring wildcard import when source
declarations do not collide.

It rejects lookalikes and ambiguous provenance. A visible lexical type,
same-package declaration, conflicting exact import, or conflicting wildcard
source type can shadow the expected identity.

`decode_builtin_spring_mapping()` distinguishes:

- not recognized: return `None`, so another annotation may be tried;
- recognized and valid: retain paths, methods, annotation node, canonical
  identity, and evidence family;
- recognized but invalid: retain an invalid result that suppresses the target.

That last state enforces the first-recognized-mapping rule.

## 5. Path decoding

`get_spring_annotation_paths()` accepts positional, `value`, and `path` forms:

~~~java
@GetMapping("/items")
@GetMapping(value = "/items")
@GetMapping(path = "/items")
@GetMapping({"/items", "/archive"})
@GetMapping(path = Paths.ROOT + "/items")
~~~

Rules:

- more than one positional argument is invalid;
- positional plus named `value` is invalid;
- `value` and `path` may coexist only when their fully resolved ordered
  sequences are identical;
- arrays fan out;
- duplicates are removed in first-seen order;
- no selected element, or an explicit empty array, contributes one empty path
  layer;
- nonempty paths gain a leading slash;
- if any selected expression is unresolved, the whole mapping path set is
  invalid; partial fan-out is not retained.

Values use the bounded workspace String resolver: literals, parentheses,
addition, and proven constant references. Cycles, ambiguity, unsupported
expressions, recursion beyond 12, or a value longer than 8192 characters fail
closed.

Other Spring mapping attributes do not contribute path identity here.

## 6. HTTP methods

Verb shortcuts contribute their fixed method. For `RequestMapping`, the
`method` element accepts genuine `RequestMethod` members reached through
qualified names, exact imports, or unambiguous static imports.

Stable order:

~~~text
GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS, TRACE
~~~

| `RequestMapping.method` shape | Result |
|---|---|
| absent or explicit empty array | unconstrained |
| every member valid | ordered unique methods |
| valid and invalid members mixed | invalid values are diagnosed; valid values survive |
| every explicit member invalid | mapping invalid |

An unconstrained final result becomes `ANY`.

Type and method conditions use `union_request_method_conditions()`. This is an
ordered union, not Spring runtime intersection:

~~~text
type methods   = [GET]
method methods = [POST, TRACE]
effective      = [GET, POST, TRACE]
~~~

That observable choice is an important interpretation limit.

## 7. First mapping and lexical type layers

`first_spring_mapping()` sorts applied annotations by source position. For each
it tries:

1. built-in decoding;
2. source-defined composed decoding.

The first result other than `None` wins. A recognized invalid mapping therefore
blocks a later valid mapping on the same declaration.

~~~mermaid
flowchart LR
    A[annotations in source order] --> B{recognized?}
    B -- no --> C[next annotation]
    C --> B
    B -- valid --> D[use mapping]
    B -- invalid --> E[skip target]
~~~

For nested direct classes or records,
`compose_lexical_type_mapping()` walks outer-to-inner type layers. Missing type
mappings are neutral; an invalid recognized layer suppresses endpoints below
it.

Paths form a Cartesian product:

~~~text
outer type paths × inner type paths × method paths
~~~

Duplicate paths retain first-seen order. Method conditions use the ordered
union described above.

## 8. Typed facts and evidence

Each effective path/method pair produces an `EndpointFact` with:

| Fact field | Direct method value |
|---|---|
| `path` / `method` | composed route and effective HTTP method |
| `parameters` | normalized raw text inside Java parameter-list parentheses |
| `source_file` | handler source file |
| `source_line` | selected mapping annotation line |
| `handler_name` | lexical type display name plus method name |
| `technology` / `protocol` / `surface` / `direction` | Spring, HTTP, server, inbound |
| `annotation_evidence` | validated same-file method mapping provenance |
| `represented_targets` | exact method declaration span |

`parameters` is not a parsed list of HTTP parameters.

For a composed mapping, provenance points to the applied outer source
annotation and its canonical FQN, while its resolved mapping family remains
available for annotation-line selection.

Each emitted fact is recorded through
`format_endpoint_diagnostic()`. The analyzer itself performs no file I/O.

## 9. Record-component accessors

A Java record component has an implicit zero-parameter accessor. A mapping on
the component can represent that accessor when:

1. its owner is a concrete workspace-visible record;
2. no explicit zero-parameter method has the component name;
3. the applied mapping is built-in or a source annotation applicable to
   `METHOD`;
4. the first recognized mapping and all lexical type layers are valid.

A parameterized overload does not suppress the implicit accessor.

A source annotation is method-applicable when no genuine `@Target` remains, or
when exactly one genuine `java.lang.annotation.Target` resolves and its unique
element set includes `ElementType.METHOD`. Ambiguous provenance, multiple
genuine targets, invalid value shape, duplicate or unknown element types, or a
set without `METHOD` fails closed.

Record-component facts use:

- empty `parameters`;
- the mapping line as `source_line`;
- HTTP/server/inbound Spring identity;
- no method-annotation evidence;
- the record-component span as the represented target.

## 10. Source-defined composed mappings

Composed mappings are proven only from annotation declarations in the shared
source workspace. Dependency bytecode and reflection are not consulted.

`build_spring_annotation_definitions()` indexes each source annotation's:

- FQN, unit, and type identity;
- direct meta-annotations;
- declared elements, element types, and defaults;
- direct element annotations, including `AliasFor` candidates.

All declarations for an FQN remain visible, so duplicates stay ambiguous.
`source_annotation_definition()` requires one accessible identity and one
accessible definition.

A composed use is supported only when:

1. the applied annotation resolves to one accessible source definition;
2. meta-annotation traversal is acyclic and within depth 12;
3. exactly one route branch reaches a genuine `RequestMapping` leaf;
4. a verb shortcut is not used as a declaration leaf;
5. every custom layer has exactly one genuine `@Retention(RUNTIME)`;
6. the fixed leaf mapping is valid;
7. alias edges, element types, defaults, intermediate values, and use-site
   values are coherent.

Unrelated meta-annotations are ignored. A source meta-annotation that enters
the mapping graph but is missing, ambiguous, inaccessible, cyclic, or invalid
makes the composed use fail closed.

~~~mermaid
flowchart TD
    A[applied source annotation] --> B{one accessible definition?}
    B -- no identity --> N[not composed]
    B -- ambiguous or inaccessible --> X[recognized invalid]
    B -- yes --> C[collect meta-annotation branches]
    C --> D{exactly one acyclic RequestMapping branch?}
    D -- no --> X
    D -- yes --> E{every custom layer retained at runtime?}
    E -- no --> X
    E -- yes --> F{leaf and aliases coherent?}
    F -- no --> X
    F -- yes --> G[canonical mapping]
~~~

`spring_composed_definition_is_supported()` performs definition-level
validation used by the annotation inventory. A definition can remain auditable
even when one applied occurrence later fails its placement or value checks.

## 11. `AliasFor` rules

Only genuine `org.springframework.core.annotation.AliasFor` is accepted.
Lookalikes, multiple candidates on one element, or ambiguous provenance
invalidate the edge.

Supported forms include:

~~~java
@AliasFor("path")
@AliasFor(value = "path")
@AliasFor(attribute = "path")
@AliasFor(annotation = RequestMapping.class, attribute = "path")
~~~

`value` and `attribute` are aliases and cannot both appear. At most one
positional value is accepted. Unknown named arguments are rejected.
`annotation` must be a resolvable class literal naming the expected branch
definition or a narrowly validated direct sibling annotation.

Canonical terminals:

| Target | Treatment |
|---|---|
| mapping `value` or `path` | endpoint path |
| `RequestMapping.method` | endpoint method |
| `name` or `version` | validate String shape, then omit from endpoint identity |
| `params`, `headers`, `consumes`, or `produces` | validate String-array shape, then omit |
| validated custom sibling/local element | validate type/value coherence, then omit |

Graph and value rules:

- cycles are rejected;
- edges cannot target an outer custom annotation in the branch;
- a sibling target must be one accessible runtime-retained direct
  meta-annotation with one target element;
- local alias pairs must be reciprocal;
- missing or duplicate target elements are invalid;
- String and `RequestMethod` identities must resolve exactly;
- scalar-to-array forwarding is supported; array-to-scalar is not;
- converging values require compatible declared types;
- implicit converging aliases require equal resolvable defaults;
- unknown use-site attributes and required elements without defaults are
  invalid;
- value cardinality must match scalar/array shape;
- multiple selected values for one terminal must agree.

Values override from inner to outer:

~~~text
fixed RequestMapping leaf
    < inner custom meta-annotation values
    < outer custom meta-annotation values
    < explicit values on the applied type, method, or component
~~~

Within a layer, explicit values beat defaults. Empty values do not erase an
already fixed nonempty path or method condition. Conflicting values invalidate
the whole mapping.

The final mapping points provenance at the applied outer annotation, so output
evidence uses that source line rather than the inner `RequestMapping` line.

## 12. Hierarchy additions

[`noir/spring_mvc_hierarchy.py`](../src/noir/spring_mvc_hierarchy.py) handles
inherited contracts as an additive pass after direct analysis.

A controller root must be:

- one unique source FQN;
- a concrete workspace-visible class, not a record;
- directly annotated with a genuine `Controller` or `RestController`.

Composed stereotypes and inherited controller markers are not recognized.

`SpringMvcHierarchyAnalyzer(workspace)` constructs one
`JavaSourceHierarchyGraph` and mapping caches. The neutral graph supplies
superclass/interface edges, generic substitution, erased signatures,
accessibility, concrete/default implementation selection, and maximally
specific interface methods.

A cycle, unresolved or wrong-kind edge, inconsistent generic state,
inaccessible declaration, or exceeded bound makes the controller hierarchy
incomplete and suppresses all hierarchy additions for that root. Once the
graph is complete, implementation or contract ambiguity suppresses only the
affected signature.

### Mapping-source selection

For each erased signature:

1. select one usable concrete class method or maximally specific interface
   default method for handler attribution;
2. if that implementation belongs to an eligible abstract/interface contract
   and has a mapping, use it;
3. otherwise choose the nearest accessible mapped abstract-class declaration;
4. otherwise require one maximally specific accessible mapped interface
   origin;
5. leave a mapping on the concrete root implementation to the direct analyzer.

Competing unrelated interface origins fail closed. A diamond reaching the same
declaration is one origin.

Hierarchy path layers are exactly:

~~~text
concrete controller's direct type mapping
+ mapping-source owner's direct type mapping
+ selected method mapping
~~~

Lexical enclosing types are not hierarchy prefixes. Methods are ordered-unioned
across the three layers and become `ANY` when unconstrained.

### Attribution

The fact's handler identity, parameters, source file, and handler line come
from the selected usable implementation. Route provenance comes from the
selected mapped contract. Project provenance points to the concrete controller
root.

Method-annotation evidence is retained only when mapping source and
implementation are the same method. Cross-method inherited mappings leave that
evidence empty. The represented target always identifies the selected
implementation method.

## 13. Suppression summary

| Problem | Result |
|---|---|
| annotation is not a proved Spring identity | not recognized; later annotation may be tried |
| selected path expression unresolved | recognized mapping invalid; target skipped |
| mixed valid and invalid method values | valid values survive; invalid values are diagnosed |
| every explicit method value invalid | mapping invalid |
| invalid lexical type mapping | descendant direct endpoints suppressed |
| invalid first recognized mapping | later mappings ignored; target skipped |
| composed definition missing, ambiguous, or inaccessible | composed use fails closed after identity is found |
| multiple composed branches or cycle | composed mapping invalid |
| invalid `AliasFor` provenance, type, default, or value | composed mapping invalid |
| explicit zero-parameter record accessor | implicit component endpoint suppressed |
| source annotation not applicable to `METHOD` | record-component candidate excluded |
| incomplete hierarchy | inherited additions for that controller suppressed; direct facts remain |
| concrete implementation has a mapping | hierarchy addition suppressed; direct analyzer owns it |
| ambiguous implementation or contract | affected signature skipped |

## 14. Deliberate limits

Spring MVC analysis does not prove:

- that a direct owner is an activated Spring bean;
- Spring runtime intersection semantics for type/method conditions;
- endpoint identity from `headers`, `params`, `consumes`, `produces`,
  `version`, or `name`;
- composed annotations available only in dependency bytecode;
- arbitrary runtime alias synthesis outside the bounded source graph;
- controller scanning, conditional beans, profiles, or security;
- Kotlin, Groovy, compiled, or generated declarations not supplied as Java
  source;
- inherited contracts whose source hierarchy cannot be resolved completely.

Continue with [05 — Additional Spring surfaces](05-spring-additional-surfaces.md).
