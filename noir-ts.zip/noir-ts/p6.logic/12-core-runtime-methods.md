# 12 — Core runtime, from entry point to method level

[← Naming and vocabulary](11-naming-and-code-vocabulary.md) ·
[Index](README.md) · [Spring methods →](13-spring-methods.md)

This chapter supplements the module-level guide with a method-level map of the
native runtime. It covers the command and the framework-neutral Java engine;
framework-specific method maps continue in the Spring and JAX-RS chapters.
The current source is the authority if this guide and code ever diverge.

The practical promise of this chapter is simple: if a reader encounters an
important core symbol in code, searching this file for its exact name should
lead to its contract, its place in a call graph, or the compact symbol index in
section 9.

## 1. How to read this method map

Read the runtime in four boundaries:

1. `src/noir_sbt.py` and `noir.cli.run_cli` own user input and artifact effects.
2. `noir.application.analyze` owns one diagnostic scope around a typed run.
3. `noir.pipeline.run_analysis` owns analysis order and framework selection.
4. `noir.java_*` modules turn immutable source bytes into reusable syntax,
   symbol, constant, method, and hierarchy evidence.

Each detailed contract below records five things:

- **Caller**: the normal upstream owner, not every test or utility caller.
- **Input/output**: the important types and meaning, not merely Python syntax.
- **Effects**: mutation, filesystem access, stdout, or diagnostic capture.
- **Invariant**: what downstream code may rely on after success.
- **Failure**: an exception when the whole operation cannot continue, versus a
  conservative `None`, `False`, or empty collection when evidence is uncertain.

That last distinction is central. Java proof helpers normally fail closed:
uncertain syntax is not endpoint evidence. Application-edge failures normally
raise: dependency, invalid contract, decode, and I/O errors must remain visible.

## 2. Top-down call graph

The solid spine is short. The broad fan-out happens only after one workspace
has been created.

```mermaid
flowchart TD
    E["src/noir_sbt.py\nmain()"] --> C["cli.run_cli(argv)"]
    C --> P["cli.build_argument_parser()"]
    C --> NR["optional load_noir_report_locations()"]
    C --> B["diagnostics.bind(collector)"]
    B --> A["application.analyze(request)"]
    A --> RA["pipeline.run_analysis(request)"]

    RA --> TS["tree_sitter_runtime.require_tree_sitter()"]
    RA --> SS["pipeline._snapshot_sources(root)"]
    SS --> DJ["discovery.discover_java_files(root)"]
    RA --> SF["pipeline._select_frameworks(request, snapshot)"]
    SF -->|auto only| SM["discovery.scan_framework_markers()"]
    RA --> BW["pipeline._build_workspace(snapshot)"]
    BW --> RT["tree_sitter_runtime.build_workspace_runtime()"]
    RT --> QR["build_query_runtime(JAVA_WORKSPACE_QUERY_SOURCES)"]
    BW --> JW["java_workspace.build_java_workspace()"]

    JW --> CU["java_frontend.build_java_compilation_unit()\nfor each source"]
    CU --> PQ["parse_java_query_set()"]
    PQ --> QM["run_query_matches() -> query_matches()"]
    JW --> IT["index_workspace_types()"]
    JW --> IC["index_workspace_constants()"]
    JW --> IA["index_java_annotation_declarations()"]

    BW --> SI["attach_spring_indexes(workspace)"]
    BW --> JI["attach or clear JAX-RS indexes"]
    RA --> AUDIT["build_annotation_audit_inventory()<br/>always"]
    RA -->|selected set is nonempty| TRIG["build_final_trigger_inventory()"]
    RA -->|JAX-RS selected| DEP["build_jax_rs_deployment_model()"]
    RA -->|Spring selected| SP["pipeline._analyze_spring()"]
    RA -->|JAX-RS selected| JP["pipeline._analyze_jaxrs()"]
    DEP -->|deployment model on workspace| JP
    SP --> EF["EndpointFact values"]
    JP --> EF
    AUDIT --> RES["AnalysisResult"]
    TRIG --> RES
    EF --> RES
    RES --> A2["analyze preserves result diagnostics and<br/>appends this call's collector slice"]
    A2 --> C2["run_cli projects and consolidates rows;<br/>renders byte reports and summary"]
    C2 --> PUB["publish CSV, log, annotations-without-endpoints report,<br/>optional comparison"]
    PUB --> SUM["print already-rendered completion summary; return 0"]
```

Two details prevent misleading readings of this graph:

- `_snapshot_sources` reads each discovered Java file once. `auto` marker
  detection receives those bytes; it does not reread Java. Exact `pom.xml`
  files are separate marker-only inputs and are read by discovery.
- `_build_workspace` always attaches the Spring indexes needed by shared
  inventory logic. It attaches JAX-RS indexes only when JAX-RS is selected,
  otherwise it clears them. Endpoint passes still run strictly according to
  `FrameworkPlan.selected`.

## 3. How data travels

### 3.1 Transformation chain

| Stage | Input | Transformation | Output and ownership |
|---|---|---|---|
| CLI resolution | strings from `argparse` | expand/resolve the input and optional Noir path; derive output destinations; when comparison is enabled, reject a Noir-input/output alias | `Path` values owned by `run_cli`; output parent, writability, and output/output collisions are not prevalidated |
| Typed request | resolved analysis root and mode | `AnalysisRequest.__post_init__` canonicalizes root and validates mode | frozen `AnalysisRequest` |
| Source edge | canonical root | deterministic discovery, then one `read_bytes()` per Java path | frozen `SourceSnapshot(paths, content)`; content is a `MappingProxyType` |
| Parser runtime | pinned query sources | validate exact dependencies, create one language/parser, compile queries | runtime dictionary retained by workspace |
| Compilation units | source path + exact bytes + runtime | one parse and every shared query; shape imports, types, annotations, candidates | one unit dictionary retaining bytes, tree, cursors, raw matches, and derived facts |
| Workspace | all units | add package collision facts, declaration indexes, constant indexes, annotation definitions | one analysis-local mutable workspace shared by every pass |
| Framework indexes | workspace | attach Spring and selected JAX-RS semantic indexes | more keys on the same workspace |
| Analysis facts | workspace + framework plan | inventory and analyzer passes | immutable `EndpointFact` values plus parallel inventories |
| Result boundary | facts and plans | tuple snapshots and recursive `freeze_data` of open-shaped inventories | frozen `AnalysisResult` |
| Presentation boundary | `AnalysisResult` | endpoint projection, normalization, six-field consolidation, evidence/target union | finalized public rows and represented targets |
| Publication | rendered bytes/rows | ordered writes | CSV, `.log`, annotations-without-endpoints report, optional Noir comparison |

### 3.2 One source file through the shared engine

```mermaid
flowchart LR
    P["path"] --> B["exact bytes"]
    B --> T["Tree-sitter tree"]
    T --> M["named query matches"]
    B --> U["compilation unit"]
    M --> U
    U --> TI["type_infos / imports / package"]
    U --> AC["annotation and declaration candidates"]
    U --> WC["workspace type/member/constant indexes"]
    WC --> R["name + constant resolution"]
    TI --> R
    AC --> F["framework analyzers"]
    R --> F
    F --> E["EndpointFact"]
    E --> RC["row candidate"]
    RC --> CR["consolidated CSV row"]
```

Tree-sitter nodes do not travel alone. A node's byte range is meaningful only
with its unit's exact source bytes, and query nodes can retain cursor-owned
state. `parse_java_query_set` therefore retains the tree and cursors in
`lifetime_owners`; `build_java_compilation_unit` keeps them beside all nodes.

### 3.3 The workspace shape readers should recognize

`build_java_workspace` creates a dictionary because framework passes attach
additional indexes to the same analysis-local object. Its stable core is:

```text
workspace
  runtime
  compilation_units[path]
    source_path, source, tree, lifetime_owners, matches
    type_infos, imports, package
    annotation_occurrences, local_annotations, local_types
    type_candidates, method_candidates, record_component_candidates
    record_explicit_accessors, meta_candidates, element_candidates
    package_types, wildcard_source_types
    workspace_constant_records
  type_declarations[FQN] -> all workspace-visible declarations, including duplicates
  constants_by_owner_member[(FQN, name)]
  member_declarations[(FQN, name)]
  static_member_declarations[(FQN, name)]
  annotation_declarations[FQN] -> all workspace-visible declarations, including duplicates
  ... framework-owned indexes attached later
```

Duplicates are intentionally retained. A resolver that needs one identity
checks cardinality and rejects ambiguity; source ordering never chooses a
winner.

## 4. Failure-path call graph

```mermaid
flowchart TD
    C["run_cli"] --> V{"argument/path/report validation"}
    V -->|invalid| PE["parser.error -> SystemExit\nno analysis starts"]
    V -->|valid| L0["truncate/create annotation and diagnostics log"]
    L0 -->|failure before outer try| EARLY["propagate; no recovery rewrite"]
    L0 --> A["analyze -> run_analysis"]
    A -->|RuntimeError| RE["record ERROR"]
    RE --> WL["write current annotation and diagnostics log"]
    RE -->|recording Exception| OE["outer exception handler"]
    WL -->|write Exception| OE
    WL --> PE2["parser.error -> SystemExit"]
    A -->|other Exception| OE
    OE --> BL["best-effort annotation and diagnostics log rewrite"]
    BL --> RAISE["re-raise original exception"]
    A -->|success| ANN["print framework announcements"]
    ANN -->|RuntimeError| RE
    ANN -->|other Exception| OE
    ANN --> PRE["project/consolidate rows; render byte reports and summary"]
    PRE -->|Exception| OE
    PRE --> CSV["write endpoint CSV"]
    CSV --> LOG["write annotation and diagnostics log"]
    LOG --> ABS["atomically publish annotations-without-endpoints report"]
    ABS --> CMP["optionally publish comparison report"]
    CMP --> OUT["print summary"]
    OUT -->|Exception| OE
    OUT -->|success| OK["return 0"]
    CSV -->|write Exception| OE
    LOG -->|write Exception| OE
    ABS -->|publish Exception| OE
    CMP -->|publish Exception| OE
```

Publication is ordered, not transactional. Once log initialization has
succeeded and the outer `try` is active, an `Exception` does not roll back an
artifact already written earlier in the chain. The outer handler tries to
rewrite the annotation and diagnostics log from whatever inventory and
diagnostics currently exist, ignores a failure in that recovery write, and
re-raises the original exception. Validation and initial-log failures occur
before this handler; `BaseException` values outside `Exception` also bypass it.

Inside Java analysis, uncertainty follows a different route:

```mermaid
flowchart LR
    X["syntax / name / accessibility / generic uncertainty"] --> H["proof helper"]
    H --> N["None, False, empty candidates, or complete=False"]
    N --> S["framework consumer suppresses inference"]
    S --> Z["no EndpointFact from that uncertain evidence"]
```

Examples are malformed annotation arguments, ambiguous imports, duplicate
source FQNs, constant cycles, unsupported string expressions, inaccessible
members, unresolved generic edges, and hierarchy traversal bounds. They do not
normally abort the entire application.

## 5. Method contracts along the runtime spine

### 5.1 Invocation, CLI, and application boundary

#### `src/noir_sbt.py` and `noir.cli`

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `main` | shell entry point; process arguments -> integer/`SystemExit` | Alias of `run_cli`. `src/noir_sbt.py` raises `SystemExit(main())`, preserving argparse exit codes. |
| `build_argument_parser` | `run_cli` or help/tests; no input -> configured `ArgumentParser` | No analysis imports are required at invocation time beyond already import-safe modules. Defines required `--path`, `--output`; optional `--framework` and `--noir-report`. Argparse rejects values outside `spring`, `jaxrx`, `auto`. |
| `_same_existing_file` | `run_cli`; two `Path` values -> `bool` | Calls `Path.samefile` to catch aliases/hard links. Any `OSError` becomes `False`; it is an extra collision guard, not existence validation. |
| `render_completion_summary` | `run_cli`; generated artifact paths and optional paired comparison paths -> newline-terminated `str` | Pure formatting. Exactly one of comparison input/output raises `ValueError`; both absent or both present are valid. |
| `run_cli` | `main`, tests, embedding; optional argv and clock -> `0` on success | Owns path validation, stdout, log initialization, report loading, row/report rendering, and ordered publication. `parser.error` handles user errors. Analysis `RuntimeError` is converted to a diagnostic plus argparse error. After successful log initialization, other `Exception` values propagate after best-effort log persistence; earlier failures and `BaseException` values outside `Exception` do not enter that recovery handler. It never promises transactionality. |

`run_cli` deliberately renders the annotations-without-endpoints and optional
comparison reports before writing the endpoint CSV. This validates more of the
run before the first final artifact write, but once publication starts the
order shown in section 4 is authoritative.

#### `noir.application.analyze`

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `AnalysisRunner` | type alias used for dependency injection | A callable from `AnalysisRequest` to `AnalysisResult`; default is `run_analysis`. |
| `analyze` | `run_cli` or library caller; typed request, optional collector/runner -> `AnalysisResult` | Rejects a non-`AnalysisRequest` with `TypeError`. Chooses the explicit collector, otherwise the currently bound collector, otherwise a new collector. Saves its entry offset, binds only if needed, runs the injected runner, then returns `dataclasses.replace(result, diagnostics=...)`, preserving the runner's diagnostics and appending only collector entries recorded since this invocation's offset. Binding restoration is guaranteed by `bind`; runner exceptions propagate unchanged and no partial result is fabricated. |

The entry offset in `analyze` is why nested calls can share a collector without
claiming earlier events as their own. The collector is not cleared, and the
runner's frozen result is not mutated.

### 5.2 Pipeline orchestration

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `SourceSnapshot.__post_init__` | dataclass construction in `_snapshot_sources`; paths + content -> sealed value | Copies both collections, requires exact path/key agreement and no duplicate path loss, then wraps content in `MappingProxyType`. Mismatch raises `ValueError`. |
| `FrameworkDecision` | `_select_frameworks`; plan plus evidence -> frozen decision | Carries the normalized plan separately from raw detections and stdout announcements. |
| `_snapshot_sources` | `run_analysis`; canonical root -> `SourceSnapshot` | Discovers stable Java paths and calls `read_bytes` exactly once per path. Discovery, filesystem, and read failures propagate; `SourceSnapshot` detaches whatever bytes each successful read returned. There is no change-detection pass. |
| `_select_frameworks` | `run_analysis`; request + snapshot -> `FrameworkDecision` | Default selects Spring then JAX-RS; explicit mode selects exactly one; only `auto` scans markers. Auto diagnostics are recorded per occurrence, selection is normalized into framework order, while announcements follow distinct registry findings. Decode/read errors from scanning propagate. |
| `_build_workspace` | `run_analysis`; snapshot + JAX-RS flag -> workspace dictionary | Builds one complete query runtime and one shared workspace, always attaches Spring indexes, and attaches or clears JAX-RS indexes. Mutates the new workspace only. Parser/query/dependency errors propagate. |
| `_analyze_spring` | `run_analysis`; request + snapshot + workspace -> `list[EndpointFact]` | Runs direct units in snapshot order, then route registrations, MVC hierarchy, gateway, resources, clients, path configuration, WebSocket/messaging, and finally applies configuration to all collected Spring facts. Empty units return additions collected so far. Analyzer exceptions propagate. |
| `_analyze_jaxrs` | `run_analysis`; snapshot + workspace -> `list[EndpointFact]` | For each parsed unit, records its source heading and runs direct JAX-RS. With units present, adds hierarchy/subresources and Java WebSocket facts. Exceptions propagate. |
| `run_analysis` | `analyze`; `AnalysisRequest` -> `AnalysisResult` | Enforces parser versions before filesystem snapshot; selects frameworks; builds one workspace; creates audit and final-trigger inventories; builds JAX-RS deployment model when selected; runs selected analyzers; requires every result to be `EndpointFact` or raises `TypeError`. Returns immutable parallel views. It writes no artifacts and prints nothing. |

`FrameworkPlan.selected` is the execution authority. Detections and
announcements are evidence/presentation channels, not a second hidden selector.

### 5.3 Discovery and parser runtime

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `_relative_name` | discovery sorting/display; path + root -> POSIX relative string | Uses `os.path.relpath`; it normalizes display order, not source containment. |
| `is_ignored_source_file` | callers/tests; file + root -> `bool` | Checks only parent directory components against `IGNORED_SOURCE_DIRECTORIES`; the filename itself is not an ignored-directory match. |
| `_discover_named_files` | Java/POM discovery; root + filename predicate -> sorted paths | Walks recursively, prunes ignored directories in place, sorts directories/files and final relative keys. Filesystem walk errors follow `os.walk` behavior; it does not read files. |
| `discover_java_files` | `_snapshot_sources`; root -> `list[str]` | Case-insensitive `.java` predicate over `_discover_named_files`. Java validity is deferred. |
| `discover_pom_files` | `scan_framework_markers`; root -> `list[str]` | Exact case-sensitive `pom.xml` predicate. POMs are marker inputs, not Java workspace inputs. |
| `detect_spring_marker` | marker registry; path/text -> `bool` | Raw, case-sensitive regex for Spring MVC annotation package or functional route marker. Comments and literals count because this is convenience detection, not semantic proof. |
| `detect_spring_functional_route_marker` | registry and `detect_spring_marker`; path/text -> `bool` | Recognizes the reactive functional server package. It is both part of Spring auto selection and a separate manual finding. |
| `detect_jax_rs_marker` | marker registry; path/text -> `bool` | Recognizes `jakarta.ws.rs` or `javax.ws.rs`. |
| `detect_spring_codegen_marker` | marker registry over POM text -> `bool` | Recognizes OpenAPI/Swagger codegen text; announcement only, with `CODEGEN_REPORT_HINT`. |
| `detect_wicket_marker` | marker registry; path/text -> `bool` | Recognizes Apache Wicket text; announcement only because no Wicket analyzer exists. |
| `scan_framework_markers` | `_select_frameworks` in `auto`; root + Java snapshot mapping -> result dictionary | Decodes Java as UTF-8, separately reads POMs as UTF-8, evaluates candidates in relative-path order and rules in registry order. Returns every occurrence, distinct findings in registry order, and a `frozenset` of auto-selectable families. Decode/I/O failures propagate. |
| `require_tree_sitter` | `run_analysis` and runtime builder; no input -> `None` | Requires importable Tree-sitter objects and exact installed versions in `SUPPORTED_VERSIONS`. Missing/mismatched dependencies raise `RuntimeError` with installation guidance. |
| `build_query_runtime` | `build_workspace_runtime`; query-name/source mapping + optional language/parser -> runtime dictionary | Revalidates dependencies, creates/reuses Java language/parser, and compiles query sources in sorted name order. Invalid queries and construction errors propagate. |
| `build_workspace_runtime` | `_build_workspace`; optional language/parser -> complete runtime | Delegates with `JAVA_WORKSPACE_QUERY_SOURCES`; this is the one normal application query set. |
| `run_query_matches` | `build_java_workspace` through injected matcher; query + root + lifetime list -> matches | Adapts `query_matches` to the installed `QueryCursor`. Query errors propagate. |
| `query_matches` | `run_query_matches`; compiled query + root + cursor factory -> matches | Creates a cursor, executes it, and appends `(cursor, matches)` to `lifetime_owners` when provided. This retention is an intentional side effect. |

### 5.4 Compilation-unit construction and conservative resolution

The core construction graph is:

```mermaid
flowchart TD
    BJC["build_java_compilation_unit"] --> PQS["parse_java_query_set"]
    BJC --> BTI["build_type_infos"]
    BJC --> PJI["parse_java_imports"]
    BJC --> JPN["java_package_name"]
    BJC --> AR["annotation_records"]
    BJC --> DAN["declared_annotation_names"]
    BJC --> GQC["group_query_captures"]
    BJC --> RZA["record_explicit_zero_parameter_accessors"]
    RK["resolve_known_annotation / resolve_known_type"] --> RKS["resolve_known_source_name"]
    RKS --> VLT["visible_local_type_names"]
```

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `parse_java_query_set` | `build_java_compilation_unit`; bytes + runtime + optional parsed tree + matcher -> `(tree, matches, lifetime_owners)` | Parses only when no tree is supplied, runs every compiled query, retains tree and cursor owners. Parse/query exceptions propagate. |
| `build_java_compilation_unit` | `build_java_workspace`; path + bytes + runtime -> unit dictionary | Calls the parse/query stage once, then derives all stable unit facts listed in section 3.3. It does not attach framework meaning. Exceptions propagate rather than returning a partial unit. |
| `build_type_infos` | unit builder; source bytes + type matches -> byte-keyed info dictionary | Sorts outer declarations before nested declarations, computes lexical display names, abstract flag, workspace visibility, and initializes the framework `mapping` field to `None`. Missing captures are skipped. |
| `type_is_workspace_visible` | `build_type_infos`; type node -> `bool` | Member types remain visible; declarations inside executable/block/initializer scopes do not. This is source-identity eligibility, not Java access checking. |
| `visible_local_type_infos` / `visible_local_type_names` | known-name and annotation resolution; unit + optional context -> infos/set | Models lexical names that shadow imports. Context expands visibility through the enclosing type chain and its visible members. Unknown context facts produce a conservative smaller view. |
| `parse_java_imports` | unit builder; bytes + import matches -> four lookup tiers | Returns exact, wildcard, static-exact, static-wildcard collections. Conflicting exact imports become `""`, a terminal ambiguity marker. Malformed declarations are skipped. |
| `decode_java_string_literal` | workspace constant evaluator and framework decoders; literal + max length -> string or `None` | Supports bounded ordinary Java escapes, Unicode and octal forms. Rejects non-quoted/text-block shapes, malformed escapes, invalid surrogate composition, and oversized decoded values. |
| `resolve_known_source_name` | known annotation/type helpers; unit + spelling + expected simple name/packages + local names -> package or `None` | Applies Java-like priority: qualified spelling; lexical shadow; exact import; same-package source shadow; then implicit/wildcard candidates with collision checks. Ambiguity or mismatch returns `None` and never falls through to a weaker tier. |
| `resolve_known_annotation` | framework/shared annotation logic; unit + name node + allowed names/packages -> identity record or `None` | Reads exact spelling, checks allowed simple name, delegates resolution, and returns `{name, namespace, spelling}` only when proven. |
| `resolve_known_type` | framework/shared type logic; unit + spelling + expected identity + context -> package or `None` | Same conservative resolver with context-sensitive lexical shadowing. |
| `get_annotation_arguments` | annotation decoders; annotation node -> `(positional_values, named_values)` | Ignores comment children and shapes syntax only. Duplicate named keys follow the last captured value because the result is a dictionary; framework decoders own admissibility. |
| `annotation_single_value_node` | shared annotation-definition helpers; annotation node -> `(node, error)` | Accepts exactly one positional value or one named `value`; describes missing, mixed, extra-key, and multi-positional rejection without raising. |
| `annotation_records`, `group_query_captures`, `record_explicit_zero_parameter_accessors` | unit builder -> normalized candidate collections | Deduplicate by byte range, group only within complete query matches, and record explicit zero-argument methods that suppress implicit record accessors. They mutate only fresh local collections. |

Small syntax helpers such as `node_text`, `child_by_field`, `first_capture`,
`tree_node_key`, `nearest_enclosing_type`, `annotation_value_nodes`, and
`unwrap_parenthesized_node` are deliberately narrow. They either return exact
syntax evidence or a neutral missing-evidence value; they do not infer a
framework identity.

### 5.5 Workspace construction, names, constants, and annotations

```mermaid
flowchart TD
    BJW["build_java_workspace"] --> UNITS["build all compilation units"]
    UNITS --> PKG["derive package_types + wildcard_source_types"]
    PKG --> IWT["index_workspace_types"]
    IWT --> IWC["index_workspace_constants"]
    IWC --> IAD["index_java_annotation_declarations"]

    RSE["resolve_workspace_string_expression"] --> WCC["workspace_constant_candidates"]
    WCC --> ROW["resolve_workspace_owner_fqns / lexical_owner_fqns"]
    WCC --> WMR["workspace_member_records"]
    WMR --> WCA["workspace_constant_accessible"]
    RSE --> RSE

    ADEF["annotation_definition_is_method_applicable"] --> TAR["resolve_java_element_type"]
    ADEF --> UTR["unresolved_java_target_reference"]
```

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `build_java_workspace` | pipeline; source-byte mapping + runtime + optional trees + matcher -> workspace | Stringifies path keys, requires every source value to be `bytes`, builds units in sorted order, derives the complete package universe, then indexes types, constants, and annotation declarations. A non-byte value raises `TypeError`; parse/index exceptions propagate. No framework index is attached here. |
| `index_workspace_types` | workspace builder; workspace -> `None` | Mutates `workspace["type_declarations"]`; retains a list for every FQN so duplicates remain ambiguity evidence. |
| `index_workspace_constants` | workspace builder; workspace -> `None` | Mutates workspace and units with indexed field/enum declarations under workspace-visible owners, static-declaration records carrying visibility metadata for later checks, and eligible Java `String` value records. Ineligible declarations remain in shadowing indexes. |
| `index_java_annotation_declarations` | workspace builder; workspace -> FQN map | Returns workspace-visible annotation definitions with duplicates intact; caller stores the map. |
| `workspace_type_accessible` | FQN/type resolvers; declaration + consumer context -> `bool` | Applies supported outer-chain visibility, private-nest, package, and named/unnamed-package rules. It does not prove identity uniqueness. |
| `workspace_type_fqn_accessible` | type resolution/hierarchy; workspace + consumer + FQN -> `bool` | Adds the uniqueness requirement: exactly one declaration and accessible. |
| `resolve_workspace_owner_fqns` | constant and hierarchy resolution; unit + qualifier + lexical owner + workspace + optional closed externals -> candidates | Stops at the first applicable Java tier: closed external, lexical members, exact import, same-package/global source, wildcard imports. Returns sorted candidates; ambiguity is represented, not guessed away. |
| `workspace_constant_accessible` | member lookup; constant record + consumer context + eligibility flags -> `bool` | Eligibility flags add requested static-final or final checks. Independently, every cross-file record must be static-final; package boundaries, same-nest private access, and public outer chains then govern visibility. |
| `lexical_instance_constant_accessible` | unqualified constant lookup; record + consumer site -> `bool` | Allows non-static final Strings only with a provable enclosing instance and no static nested boundary. Static-final records pass this extra check. |
| `workspace_constant_candidates` | string evaluator; unit + reference + owner/workspace/context + known constants -> candidate records | Implements lexical declaration shadowing before static imports; exact import before wildcard; qualified owner resolution; closed known constants. Unresolved or ambiguous owner tiers return no candidates; duplicate member declarations can return multiple candidates, which the evaluator rejects because cardinality is not one. |
| `resolve_workspace_string_expression` | route/config decoders; unit + expression + workspace + owner -> string or `None` | Evaluates literal, unambiguous parentheses, `+`, or one eligible reference. Recurses through value declarations with a cycle stack. Depth over `JAVA_CONSTANT_MAX_DEPTH`, length over `JAVA_CONSTANT_MAX_LENGTH`, unsupported syntax, non-addition, cycle, or candidate cardinality other than one returns `None`. It does not execute Java. |
| `static_member_resolves_to` | enum/annotation constant resolution; unit + name + expected owner -> `bool` | Exact static import is terminal. Wildcard succeeds only if no competing imported source owner exposes the same member. |
| `retention_is_runtime` | source-defined annotation index consumers; unit + annotation -> `bool` | Proves genuine `java.lang.annotation.RetentionPolicy.RUNTIME`, either unqualified through static resolution or qualified through known-type resolution. Uncertain shape returns `False`. |
| `custom_annotation_identity_candidates` | composed-annotation consumers; unit + spelling + workspace/context -> set of source FQNs | Applies lexical, exact import, same package, package shadow, then wildcard tiers. A set preserves ambiguity for the caller to reject. |
| `annotation_definition_is_method_applicable` | source-defined method annotation consumers; definition -> `bool` | No genuine `@Target` means Java's broad default. Ambiguous Target-like evidence, multiple/malformed target annotations, duplicate values, unresolved constants, or a set lacking `METHOD` returns `False`. |

The smaller `workspace_member_records`, `workspace_member_declared`,
`workspace_static_member_declared`, and related predicates separate three facts
that must not be conflated: declaration presence, declaration accessibility,
and eligibility as a compile-time-like String value.

### 5.6 Reusable AST and method indexes

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `java_ast.walk_named` | method/framework indexers; root -> preorder iterator | Deterministic source-oriented named-node traversal; no mutation. `java_methods.walk_named_nodes` is its imported alias. |
| `java_ast.raw_type_node` | `known_type` and analyzers; type syntax -> raw node or `None` | Unwraps generic and annotated types for at most 16 layers; ambiguous/malformed or over-bound nesting returns `None`. `java_methods.raw_type_node` is the same imported helper. |
| `java_ast.known_type` | framework analyzers; unit + node + exact simple/package -> `bool` | Combines raw type extraction and conservative `resolve_known_type`; any uncertainty is `False`. `java_methods.known_type` re-exports it. |
| `java_ast.is_direct_invocation_statement` | route DSL analyzers; invocation + method body -> `bool` | Walks only a fluent receiver chain, then requires a direct `expression_statement` child of the supplied body. Assignments, returns, lambdas, and nested expression ownership fail closed. |
| `only_named_child` / `unwrap_parentheses` | invocation analyzers; expression -> child/unwrapped node or `None` | Ignore comments, require one semantic child, and bound wrapper traversal at 16. |
| `invocation_arguments` / `invocation_name` | DSL analyzers; method invocation -> argument nodes/name | Shape syntax only. A missing arguments field or wrong invocation kind returns `None`; comments are excluded. |
| `strict_formal_parameters` | strict method index; unit + parameter list -> tuple or `None` | Accepts ordinary formal parameters only. One receiver, varargs, or malformed member rejects the entire signature. |
| `varargs_formal_parameters` | varargs method index; unit + parameter list -> tuple or `None` | Also accepts structurally valid spread-parameter nodes; unsupported syntax rejects the entire signature. |
| `_formal_parameters` | the two readers; policy flag -> tuple of `FormalParameter` or `None` | Central all-or-nothing parser. It never publishes a partial overload signature. |
| `_build_method_index` | public index builders; workspace + parameter reader -> `MethodIndex` | Walks sources in path order and accepts an executable method only when its immediate parent is a `class_body` directly owned by a stable workspace-visible named type. It sorts by path/start byte and creates `(owner_fqn, name)` buckets. Abstract/bodyless/local/anonymous or unsupported-signature methods are excluded. |
| `build_strict_method_index` / `build_varargs_method_index` | specialized framework analyzers; workspace -> `MethodIndex` | Differ only by parameter policy and otherwise share deterministic indexing. |
| `MethodFact.name` / `MethodFact.owner_name` | analyzer lookup | Decode the name from retained unit bytes and expose the lexical display owner. They are pure properties; the owning unit remains necessary provenance. |

### 5.7 Source hierarchy and generic method binding

`JavaSourceHierarchyGraph` is framework-neutral, but Spring and JAX-RS
hierarchy analyzers consume several underscore-prefixed methods as their
specialization seam. Those methods are therefore important runtime contracts
despite their Python-private spelling.

```mermaid
flowchart TD
    INIT["JavaSourceHierarchyGraph.__init__"] --> BT["_build_java_type_index"]
    BT --> TP["_type_parameter_nodes"]
    BT --> IE["_parse_inheritance_edges"]
    BT --> PM["_parse_methods"]
    IE --> PTR["_parse_type_ref"]
    PM --> PTR
    PTR --> RTI["_resolve_type_identity"]

    HC["_build_hierarchy_context(root, env)"] --> RIE["_resolve_inheritance_edge"]
    RIE --> SUB["_substitute_type_ref"]
    SIG["_erased_method_signature"] --> ME["_method_env"]
    SIG --> SUB

    IB["_interface_branches"] --> MFS["_methods_for_signature"]
    IB --> HAB["_has_atomic_annotation_bundle"]
    IB --> RIE
    MSC["_select_maximally_specific_candidates"] --> RMC["_resolve_method_candidate"]
    MSC --> IST["_interface_subtype"]
```

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `JavaSourceHierarchyGraph.__init__` | Spring hierarchy analyzer and JAX-RS subclass; workspace -> graph | Stores the workspace, initializes signature cache, and builds the full neutral type index. Construction exceptions propagate. |
| `_build_java_type_index` | constructor; workspace -> populated `types` | Includes only unique workspace-visible class/interface/record FQNs. After every identity exists, it parses the first supported bound retained for each type parameter, then inheritance edges and methods. Duplicate FQNs and unsupported declaration kinds remain non-traversable. |
| `_parse_type_ref` / `_resolve_type_identity` | index construction; source type syntax + type variables -> `JavaTypeReference` or `None` | Supports primitives, arrays, annotated types, non-wildcard generics, variables, and uniquely resolved declarations. A fully qualified absent external name can be signature identity but never a source traversal target. Unsupported or ambiguous forms return `None`. |
| `_parse_methods` | graph build; type record + owner variables -> mutation of `record.methods` | Retains a method even when its parameters cannot be parsed, using `parameter_refs=None` so an overload family can be marked incomplete later. Captures direct method and parameter annotation bundles. |
| `_default_type_environment`, `_substitute_type_ref`, `_method_env` | signature/edge adaptation -> adapted environments/references | Raw type variables use erasure-only bounds. Substitution is cycle-safe; unresolved variables/cycles return `None`. Method variables extend, rather than mutate, the owner environment. |
| `_erased_method_signature` | framework hierarchy analyzers and branch selection; method + adapted owner env -> `(name, erased parameters)` or `None` | Caches both successful and unresolved results by method identity plus environment. Return type does not participate in override identity. |
| `_resolve_inheritance_edge` | hierarchy traversal; declared edge + environment -> source target/environment or `None` | Requires an adapted non-array declared type in `types`; generic argument arity must match. A raw edge receives the target's default erasure environment. |
| `_build_hierarchy_context` | framework hierarchy analyzers; root type + root env -> `JavaHierarchyContext` | Builds class states and reachable interface roots. Cycles, missing/invalid source parents, incompatible repeated environments, bad kind, depth over `MAX_HIERARCHY_DEPTH`, or states over `MAX_HIERARCHY_STATES` set `complete=False`. It may return partial states, but consumers must honor completeness before inference. |
| `_erased_method_signature` / `_methods_for_signature` | class/interface binding logic -> matching declarations | Exact adapted erased signature is the lookup key. Multiple matching declarations in one interface branch invalidate that branch rather than selecting by order. |
| `_has_atomic_annotation_bundle` | `_interface_branches`; method -> `bool` | Treats direct non-genuine-`Override` method annotations plus parameter annotations as one atomic inheritance bundle. Exact `java.lang.Override` alone is ignored. |
| `_interface_branches` | Spring/JAX-RS hierarchy analyzers; interface state + signature + `default`/annotation mode -> candidate keys + invalid flag | Applies stop-at-declaration rules, recursively follows interfaces with depth/cycle checks plus memoization, and preserves candidate environment. Missing edges, multiple declarations, or invalid implementation shapes mark the branch invalid. |
| `_interface_subtype` | maximal-specificity selection; candidate + potential ancestor -> `(is_subtype, invalid)` | Bounded graph proof. It distinguishes a definite `False` from an invalid traversal so callers cannot treat uncertainty as non-subtyping. |
| `_select_maximally_specific_candidates` | hierarchy analyzers; candidate keys -> survivors + invalid flag | Restores candidate provenance, removes an ancestor only when another candidate is proven below it, and rejects the whole selection on unresolvable provenance or subtype proof. |

`JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord`, and
`JavaHierarchyContext` are analysis-local records, not public artifacts. Their
Tree-sitter nodes remain tied to workspace units. `JavaHierarchyContext.complete`
is a proof flag, not a progress percentage.

### 5.8 Domain values, diagnostics, immutability, and paths

| Symbol | Caller; input -> output | Effects, invariants, and failure behavior |
|---|---|---|
| `AnalysisRequest.__post_init__` | CLI/library construction -> normalized request | Expands and resolves root without requiring it to exist; rejects unsupported mode with `ValueError`. CLI separately requires a directory. |
| `FrameworkPlan.__post_init__` | framework selection -> normalized plan | Coerces each selection to `FrameworkSelection`, rejects unsupported requested mode and duplicate selected families. |
| `SourceFile.__post_init__`, `SourceFile.__fspath__`, `SourceFile.__str__` | provenance construction/path APIs | Require a non-empty string path identity, then expose it without filesystem access. |
| `SourceSpan.__post_init__` | evidence/target construction | Coerces source identity and requires integer, non-boolean, non-empty half-open byte interval `0 <= start < end`. |
| `SourceTarget.__post_init__` | analyzer target construction | Requires non-empty kind and a validated `SourceSpan`. |
| `AnnotationEvidence.__post_init__` | analyzer evidence construction | Coerces source identity only; family, line, and same-file validity are deliberately enforced later by `noir.evidence`. |
| `EndpointFact.__post_init__` | every endpoint analyzer | Coerces all source-file provenance fields, requires typed evidence/targets, snapshots their collections, and snapshots optional Spring client path layers. It does not normalize public route paths or semantically validate HTTP methods. |
| `AnalysisResult.__post_init__` | pipeline/application boundaries | Requires typed endpoint/diagnostic members, tuple-snapshots them, and recursively freezes open-shaped inventories, detections, and announcements. |
| `freeze_data` | `AnalysisResult` | Recursively converts mappings to `MappingProxyType`, lists and tuples to tuples, and sets to frozensets; scalar/unknown leaves remain as-is. It creates no mutable reverse view. |
| `DiagnosticCollector.record` | module `record` or caller; string -> `DiagnosticEntry` | Under `RLock`, timestamps and appends one immutable entry. Non-string raises `TypeError`; clock failures propagate. |
| `DiagnosticCollector.entries`, `DiagnosticCollector.rendered_lines`, `DiagnosticCollector.captured`, `DiagnosticCollector.__len__` | application/report/tests | Return locked snapshots, report-format lines, exact-message membership, and entry count. `entries` never exposes the mutable list. |
| `current` / `bind` / `record` | application and analyzers | `current` reads a `ContextVar`; `bind` type-checks, sets, and always restores the previous token; module `record` appends to the bound collector or intentionally does nothing when none is bound. |
| `format_endpoint_diagnostic` | endpoint analyzers; `EndpointFact` -> stable text | Rejects another type with `TypeError`. Uses analyzer-local `source_line`, not validated public annotation evidence. |
| `join_endpoint_paths` | framework analyzers; decoded base + endpoint layer -> composed string | Pure composition before final public normalization. Two empty layers mean `/`; one empty layer contributes nothing. |
| `ensure_path_leading_slash` | framework path decoders; path layer -> string | Preserves `""` as absent and otherwise adds one leading slash if needed. |
| `relative_source_path` | output/evidence presentation; owned path + analysis root -> POSIX relative string | Uses absolute/relative path operations for spelling only. It is not a containment or ownership proof. |

## 6. Two worked method-level traces

### 6.1 `auto` selects Spring from one Java marker

1. `run_cli` creates `AnalysisRequest(root, framework_mode="auto")`.
2. `AnalysisRequest.__post_init__` resolves `root`.
3. `run_analysis` first calls `require_tree_sitter`; no source is read if the
   pinned runtime is unavailable.
4. `_snapshot_sources` calls `discover_java_files`, reads every returned path,
   and `SourceSnapshot.__post_init__` seals the exact path-to-byte map.
5. `_select_frameworks` calls `scan_framework_markers` with those bytes.
6. `scan_framework_markers` decodes Java, reads separately discovered POMs,
   tests every applicable `FRAMEWORK_MARKER_RULES` entry, and returns occurrence,
   finding, and selection views.
7. `_select_frameworks` records every occurrence, converts the selected token
   to `FrameworkSelection.SPRING`, restores global framework order, and creates
   a `FrameworkPlan("auto", (SPRING,))`.
8. `_build_workspace` parses every snapshotted Java file once and attaches
   Spring indexes; it clears JAX-RS indexes.
9. `run_analysis` builds inventories, skips JAX-RS deployment, calls only
   `_analyze_spring`, validates every emitted value, and creates `AnalysisResult`.
10. `analyze` preserves the runner's diagnostics and appends only collector
    entries added since its entry offset.
11. `run_cli` prints the distinct finding announcement, then projects and
    publishes artifacts.

Raw marker selection proves only that the Spring pass should run. Each Spring
method still requires parsed semantic evidence before it emits an endpoint.

### 6.2 A route path refers to a source String constant

1. A framework decoder passes the annotation expression node, its unit,
   lexical owner, and shared workspace to `resolve_workspace_string_expression`.
2. For an identifier or field reference, the evaluator calls
   `workspace_constant_candidates`.
3. For an unqualified name, `lexical_owner_fqns` yields inner-to-outer owners.
   Declaration presence stops the tier even if the declaration is ineligible.
4. `workspace_member_records` first requires a unique source owner, then
   `workspace_constant_accessible` checks Java visibility and required finality.
5. `lexical_instance_constant_accessible` proves that a non-static value has an
   enclosing instance; static nesting can reject it.
6. If no lexical declaration exists, exact static import and then wildcard
   static import tiers are considered. Multiple declaring wildcard owners are
   ambiguity and produce no candidate.
7. Exactly one candidate is required. A closed known constant returns its
   `resolved_value`; a source constant recursively evaluates its `value_node`.
8. The record identity is added to `stack`. A cycle, depth above 12, unsupported
   expression, or composed value above 8192 characters returns `None`.
9. Only a proven string returns to the framework decoder and can become route
   evidence. There is no partial concatenation result.

## 7. Reading rules that prevent wrong conclusions

### One parse does not mean one interpretation

All framework passes share one syntax tree per source, but they can read
different candidate/index views from the same unit. A route found in a later
pass is not evidence that the file was reparsed.

### Mutable workspace does not cross the typed boundary

The workspace is deliberately mutable during one analysis because index
owners attach derived views. `EndpointFact` and `AnalysisResult` are frozen
handoffs. Parser objects, nodes, and workspace dictionaries do not enter CSV
or report presentation.

### Empty evidence and application failure mean different things

`None`, `False`, `[]`, an empty set, or `complete=False` usually means “this
static proof was not established.” An exception means the requested operation
could not honor its runtime or data contract. Do not convert one category into
the other when extending the engine.

### Identity is layered

- `tree_node_key` supplies a unit-local byte-range key.
- `SourceSpan` identifies a file plus a byte interval; `SourceTarget` adds the
  represented declaration kind.
- Java type identity is an FQN that must normally be unique and accessible.
- `EndpointFact` is rich analyzer output with separate route, handler, and
  project provenance; each analyzer defines its own local deduplication key.
- Public row identity is established later by output consolidation's six-field
  key.

### Ordering is part of reproducibility

Discovery order, query compilation order, method index order, framework order,
finding order, analyzer pass order, and artifact publication order are all
explicit. A set may intentionally represent unordered candidates, but any
presentation or traversal decision either sorts it or requires uniqueness.

## 8. Where to continue below this layer

When the symbol is not in this chapter:

- Start with `p6.logic/10-code-and-test-map.md` to identify the owning feature.
- Use the exact import or call at the method site, then search its defining
  module with `rg -n '^(class|def) |<symbol>' src/noir`.
- For Spring endpoint semantics, continue with `04-spring-mvc.md` and
  `05-spring-additional-surfaces.md`.
- For JAX-RS and Java WebSocket semantics, continue with `06-jax-rs.md`.
- For `EndpointFact` projection, evidence merge, reports, and byte-level output,
  continue with `07-output-evidence-reports.md`.
- For a concrete source-to-row narrative, use `08-worked-traces.md`.

Private helpers are documented here when they coordinate stages, hold state,
contain substantial branching, or are consumed as a framework specialization
seam. Tiny syntax helpers are indexed below so exact-name search still lands in
this file; their source docstrings remain the closest statement-level guide.

## 9. Complete core symbol coverage index

This index lists every exported top-level symbol in the covered modules, plus
the important private helpers and class methods. Imported aliases are marked so
the reader can jump to the actual owner.

### 9.1 Invocation and orchestration

| Module | Exact symbols | Coverage pointer |
|---|---|---|
| `src/noir_sbt.py` | `main` | Sections 2, 5.1 |
| `noir.application` | `AnalysisRunner`, `analyze` | Section 5.1 |
| `noir.cli` | `build_argument_parser`, `main`, `render_completion_summary`, `run_cli`; private `_same_existing_file` | Sections 4, 5.1 |
| `noir.pipeline` | `SourceSnapshot`, `SourceSnapshot.__post_init__`, `FrameworkDecision`, `run_analysis`; private `_snapshot_sources`, `_select_frameworks`, `_build_workspace`, `_analyze_spring`, `_analyze_jaxrs` | Sections 2, 3, 5.2 |

### 9.2 Discovery and parser runtime

| Module | Exact symbols | Coverage pointer |
|---|---|---|
| `noir.discovery` | `CODEGEN_REPORT_HINT`, `FRAMEWORK_MARKER_RULES`, `detect_jax_rs_marker`, `detect_spring_codegen_marker`, `detect_spring_functional_route_marker`, `detect_spring_marker`, `detect_wicket_marker`, `discover_java_files`, `discover_pom_files`, `is_ignored_source_file`, `scan_framework_markers`; private `_relative_name`, `_discover_named_files` | Section 5.3. `CODEGEN_REPORT_HINT` is the manual follow-up suffix; `FRAMEWORK_MARKER_RULES` is the ordered immutable registry. |
| `noir.tree_sitter_runtime` | `SUPPORTED_VERSIONS`, `build_query_runtime`, `build_workspace_runtime`, `require_tree_sitter`, `run_query_matches` | Sections 2, 5.3. `SUPPORTED_VERSIONS` is the exact dependency policy. |
| `noir.java_queries` | `JAVA_ANNOTATION_USAGE_QUERY`, `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | Sections 3, 5.3. They are respectively the broad annotation query, base unit query mapping, and complete workspace union. |

### 9.3 Java AST and frontend

| Module | Exact symbols | Coverage pointer |
|---|---|---|
| `noir.java_ast` | `direct_interface_types`, `field`, `is_direct_invocation_statement`, `known_type`, `raw_type_node`, `source_text`, `walk_named` | Section 5.6. `field` delegates guarded field access; `source_text` decodes retained unit bytes; `direct_interface_types` shapes only direct declarations. |
| `noir.java_frontend` | `JAVA_CONSTANT_MAX_LENGTH`, `annotation_has_no_values`, `annotation_records`, `annotation_single_value_node`, `annotation_value_nodes`, `binary_expression_is_addition`, `build_java_compilation_unit`, `build_type_infos`, `child_by_field`, `declaration_modifier_names`, `declared_annotation_names`, `decode_java_string_literal`, `direct_annotation_records`, `find_first`, `first_capture`, `get_annotation_arguments`, `group_query_captures`, `java_package_name`, `lexical_type_chain`, `nearest_enclosing_type`, `node_text`, `owner_name_for_node`, `parameter_list_source_text`, `parse_java_imports`, `parse_java_query_set`, `qualified_type_name`, `query_matches`, `record_explicit_zero_parameter_accessors`, `resolve_known_annotation`, `resolve_known_source_name`, `resolve_known_type`, `tree_node_key`, `type_is_abstract`, `type_is_workspace_visible`, `unwrap_parenthesized_node`, `visible_local_type_infos`, `visible_local_type_names` | Sections 3, 5.3, 5.4. Construction/resolution methods have detailed contracts there; the remaining names are syntax-only shaping helpers described immediately below. |

The small `java_frontend` helpers resolve as follows:

| Exact symbol | Compact contract |
|---|---|
| `node_text` | Exact byte-slice UTF-8 decode; decode/range errors are not hidden. |
| `find_first` | First direct child with the requested type, otherwise `None`; no descent. |
| `child_by_field` | Requested parser field, but any parser-recovery/API exception becomes `None`. |
| `parameter_list_source_text` | Exact parameter-list interior trimmed; missing node becomes `""`. |
| `first_capture` | First node under one query label, otherwise `None`. |
| `tree_node_key` | `(start_byte, end_byte)` identity valid only within its unit. |
| `nearest_enclosing_type` | Walk parents to the nearest named class/interface/enum/record/annotation declaration. |
| `type_is_abstract` | True only for an explicitly `abstract` class declaration. |
| `declared_annotation_names` | Set of captured source annotation declaration names for shadow checks. |
| `binary_expression_is_addition` | Proves `+` using field, token, or exact inter-operand text; otherwise false. |
| `annotation_value_nodes` | One scalar as a one-item list, or non-comment array elements. |
| `unwrap_parenthesized_node` | Unwraps only single-child parentheses; ambiguity becomes `None`. |
| `owner_name_for_node` | Lexical display owner for a context node, otherwise `None`. |
| `lexical_type_chain` | Outer-to-inner type-info chain from byte-key relationships. |
| `java_package_name` | One unambiguous captured package, otherwise unnamed package `""`. |
| `annotation_has_no_values` | True when arguments are absent or their node has zero `named_children`; it does not separately filter comments. |
| `qualified_type_name` | Package plus lexical display name, or display name in unnamed package. |
| `declaration_modifier_names` | Named and access/static/final modifier token set. |
| `direct_annotation_records` | Source-ordered annotation/name-node records directly in declaration modifiers. |

### 9.4 Workspace and method index

| Module | Exact symbols | Coverage pointer |
|---|---|---|
| `noir.java_workspace` | `JAVA_CONSTANT_MAX_DEPTH`, `JAVA_ELEMENT_TYPES`, `annotation_definition_is_method_applicable`, `build_java_workspace`, `context_is_static_for_instance_constant`, `custom_annotation_identity_candidates`, `index_java_annotation_declarations`, `index_workspace_constants`, `index_workspace_types`, `known_static_constant_record`, `lexical_instance_constant_accessible`, `lexical_owner_fqns`, `resolve_java_element_type`, `resolve_workspace_owner_fqns`, `resolve_workspace_string_expression`, `retention_is_runtime`, `static_member_resolves_to`, `unresolved_java_target_reference`, `workspace_constant_accessible`, `workspace_constant_candidates`, `workspace_member_declared`, `workspace_member_records`, `workspace_static_member_declaration_accessible`, `workspace_static_member_declared`, `workspace_type_accessible`, `workspace_type_exists`, `workspace_type_fqn_accessible` | Section 5.5. `JAVA_CONSTANT_MAX_DEPTH` is 12; `JAVA_ELEMENT_TYPES` is the closed genuine ElementType member set. |
| `noir.java_methods` | `FormalParameter`, `MethodFact`, `MethodFact.name`, `MethodFact.owner_name`, `MethodIndex`, `build_strict_method_index`, `build_varargs_method_index`, `child_field`, `invocation_arguments`, `invocation_name`, `known_type`, `node_text`, `only_named_child`, `raw_type_node`, `strict_formal_parameters`, `unwrap_parentheses`, `varargs_formal_parameters`, `walk_named_nodes`; private `_formal_parameters`, `_build_method_index`; type alias `ParameterReader` | Section 5.6. `child_field`, `known_type`, `node_text`, `raw_type_node`, and `walk_named_nodes` are imported aliases of `java_ast` helpers. |

Compact contracts for workspace predicates not expanded above:

| Exact symbol | Compact contract |
|---|---|
| `workspace_member_records` | Values for one unique owner filtered through `workspace_constant_accessible`; otherwise empty. |
| `workspace_type_exists` | Any workspace-visible indexed declaration at an FQN, including duplicate or Java-inaccessible records. |
| `workspace_member_declared` | Any indexed member declaration, even without usable String value. |
| `workspace_static_member_declaration_accessible` | Static declaration visibility for wildcard ambiguity checks. |
| `workspace_static_member_declared` | Unique source owner plus at least one accessible same-named static declaration. |
| `lexical_owner_fqns` | Inner-to-outer owner FQNs for a unit/display owner. |
| `context_is_static_for_instance_constant` | Walks outward; a static method/field/initializer, or a named-type boundary reached before a method/field instance context, means no instance. |
| `known_static_constant_record` | Wraps a closed dependency value in candidate-record form with stable synthetic identity. |
| `unresolved_java_target_reference` | Distinguishes ambiguous genuine-looking `Target` evidence from an unrelated source annotation. |
| `resolve_java_element_type` | Proves one genuine `ElementType` constant through static or type resolution; else `None`. |

### 9.5 Hierarchy graph

| Module | Exact symbols | Coverage pointer |
|---|---|---|
| `noir.java_hierarchy` | `JAVA_LANG_TYPES`, `PRIMITIVE_NODE_TYPES`, `MAX_HIERARCHY_DEPTH`, `MAX_HIERARCHY_STATES`, `JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord`, `JavaHierarchyContext`, `JavaSourceHierarchyGraph`, `JavaSourceHierarchyGraph.__init__` | Section 5.7. Constants define closed signature vocabulary and proof bounds. |
| `JavaSourceHierarchyGraph` build methods | `_build_java_type_index`, `_type_parameter_nodes`, `_unit_source_for_node`, `_modifier_names`, `_parse_methods`, `_parse_inheritance_edges`, `_parse_parameter_ref`, `_with_dimensions`, `_parse_type_ref`, `_resolve_type_identity` | Section 5.7; `_unit_source_for_node` finds owning bytes by root-node identity and raises `KeyError` if the node is not from this workspace. |
| `JavaSourceHierarchyGraph` adaptation methods | `_default_type_environment`, `_as_erasure_only_ref`, `_substitute_type_ref`, `_erased_type_name`, `_type_environment_key`, `_method_env`, `_erased_method_signature`, `_resolve_inheritance_edge` | Section 5.7. They never load a classpath; all adaptation is bounded source/closed-identity reasoning. |
| `JavaSourceHierarchyGraph` binding methods | `_build_hierarchy_context` (including nested `visit`), `_is_public_implementation`, `_is_ancestor_annotation_method`, `_methods_for_signature`, `_is_genuine_override`, `_has_atomic_annotation_bundle`, `_interface_branches`, `_resolve_method_candidate`, `_interface_subtype`, `_select_maximally_specific_candidates` | Section 5.7. Nested `visit` validates and memoizes one bounded reachable-interface state; incompatible repeated environments, cycles, or bounds make the context incomplete. `_is_public_implementation` accepts concrete public class or record methods, plus valid interface defaults; `_is_ancestor_annotation_method` accepts inheritable interface/public/protected declarations. |

### 9.6 Domain, diagnostics, immutability, and paths

| Module | Exact symbols | Coverage pointer |
|---|---|---|
| `noir.model` | `FrameworkMode`, `FrameworkSelection`, `AnalysisRequest`, `AnalysisRequest.__post_init__`, `FrameworkPlan`, `FrameworkPlan.__post_init__`, `SourceFile`, `SourceFile.__post_init__`, `SourceFile.__fspath__`, `SourceFile.__str__`, `SourceSpan`, `SourceSpan.__post_init__`, `SourceTarget`, `SourceTarget.__post_init__`, `AnnotationEvidence`, `AnnotationEvidence.__post_init__`, `EndpointFact`, `EndpointFact.__post_init__`, `AnalysisDiagnostic`, `AnalysisResult`, `AnalysisResult.__post_init__`; private `_read_path` | Sections 3, 5.8. `_read_path` preserves an existing `SourceFile` or constructs one from `os.fspath`. |
| `noir.diagnostics` | `DiagnosticEntry`, `DiagnosticEntry.message`, `DiagnosticEntry.rendered_line`, `DiagnosticCollector`, `DiagnosticCollector.__init__`, `DiagnosticCollector.record`, `DiagnosticCollector.entries`, `DiagnosticCollector.rendered_lines`, `DiagnosticCollector.captured`, `DiagnosticCollector.__len__`, `bind`, `current`, `format_endpoint_diagnostic`, `record`; type alias `Clock` | Sections 4, 5.1, 5.8. `DiagnosticEntry.rendered_line` uses second-resolution `%Y-%m-%d %H:%M:%S`. |
| `noir.immutability` | `freeze_data` | Sections 3, 5.8 |
| `noir.paths` | `ensure_path_leading_slash`, `join_endpoint_paths`, `relative_source_path` | Section 5.8 |

The dataclasses' generated equality/representation methods are ordinary Python
mechanics and are not separate logic entry points. All handwritten methods and
properties that affect runtime behavior are named above.

Continue with [13 — Spring methods](13-spring-methods.md), or use the
[method lookup](15-method-lookup.md) for an exact source symbol.
