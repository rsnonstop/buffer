# noir-ts logic guide

This folder explains the current implementation behind:

~~~bash
python3 src/noir_sbt.py \
  --path "<application source directory>" \
  --output "endpoints.csv"
~~~

The application is a conservative, source-only Java endpoint analyzer for
Spring and JAX-RS. The code and tests in this repository are the authority for
this guide. Earlier sprint and OpenSpec material records how behavior evolved;
it is not the current architecture.

## Reading code and logic together

A code coordinate links an owning file and names a definition, for example
[`src/noir/pipeline.py`](../src/noir/pipeline.py) ::
`run_analysis()`. Follow the link, then use symbol search in the file. Source
module docstrings point back to the relevant logic chapter.

- Start with [the code and test map](10-code-and-test-map.md) when you know a
  behavior and need its owner.
- Start with [the method lookup](15-method-lookup.md) when you selected a
  function or class in `src/` and need its callers, data flow, and application
  context.
- Start with a source module docstring when you know the code and need its
  application role.
- Treat type hints as the mechanical contract and comments as explanations of
  ordering, ownership, ambiguity, and evidence decisions.

The guide has two complementary depths:

- chapters 01–11 explain the system by behavior, architecture, framework, and
  artifact; and
- chapters 12–15 explain it by runtime calls and exact Python symbols.

The second layer supplements rather than replaces the first. A method card is
best for following code; a behavior chapter is best for understanding why the
method applies a particular rule.

## The shortest accurate explanation

One invocation:

1. validates CLI paths and, when supplied, the Noir report;
2. creates an immutable `AnalysisRequest` and a run-scoped diagnostic
   collector;
3. validates the pinned Tree-sitter pair, discovers Java files, and snapshots
   each file once;
4. selects Spring, JAX-RS, or both from the requested mode and snapshot marker
   evidence;
5. parses each snapshot once, builds shared indexes, then runs the chosen
   analyzers in explicit order;
6. returns only immutable `EndpointFact` values, inventories, announcements,
   and diagnostics in `AnalysisResult`;
7. projects facts to the seven-column CSV identity, merges duplicate evidence,
   renders companion reports, publishes artifacts in order, and prints the
   completion inventory only after successful publication.

Omitting `--framework` runs both analyzer families. `--framework auto` is a
separate raw-text marker mode and intentionally selects a narrower set.

~~~mermaid
flowchart LR
    L["src/noir_sbt.py<br/>thin launcher"] --> CLI["noir.cli<br/>validation and publication"]
    CLI --> APP["noir.application<br/>typed run + diagnostic scope"]
    APP --> PIPE["noir.pipeline<br/>snapshot and pass order"]
    PIPE --> TS["tree_sitter_runtime<br/>validated parser runtime"]
    PIPE --> JAVA["java_frontend + java_workspace<br/>parse once + shared indexes"]
    JAVA --> SPRING["Spring analyzers"]
    JAVA --> JAX["JAX-RS analyzers"]
    SPRING --> FACT["EndpointFact"]
    JAX --> FACT
    FACT --> RESULT["AnalysisResult"]
    RESULT --> OUT["noir.output + noir.reports"]
    OUT --> CSV["CSV and companion reports"]
    NOIR["optional Noir v1.1 JSON"] --> COMP["noir.comparison"]
    COMP --> OUT
~~~

## Guide order

| Order | Chapter | Main question |
|---:|---|---|
| 1 | [Mental model](01-mental-model.md) | What are the system boundaries and data flows? |
| 2 | [CLI and orchestration](02-cli-and-orchestration.md) | What happens after invocation, and in what order? |
| 3 | [Shared Java engine](03-shared-java-engine.md) | How are parsing, names, constants, and ambiguity handled? |
| 4 | [Spring MVC](04-spring-mvc.md) | How are direct, composed, record, and inherited MVC mappings decoded? |
| 5 | [Additional Spring surfaces](05-spring-additional-surfaces.md) | How are functional routes, registrations, Gateway, resources, clients, and messaging found? |
| 6 | [JAX-RS and Java WebSocket](06-jax-rs.md) | How do resources, deployment, hierarchy, subresources, custom verbs, and handshakes work? |
| 7 | [Output, evidence, and reports](07-output-evidence-reports.md) | How do typed facts become rows and audit artifacts? |
| 8 | [Worked traces](08-worked-traces.md) | How does the logic behave on concrete Java examples? |
| 9 | [Production use](09-production-use.md) | Which limits and operational risks matter? |
| 10 | [Code and test map](10-code-and-test-map.md) | Where is each behavior implemented and tested? |
| 11 | [Naming and vocabulary](11-naming-and-code-vocabulary.md) | What do application terms mean? |
| 12 | [Core runtime methods](12-core-runtime-methods.md) | Which methods carry invocation through parsing, workspace construction, and orchestration? |
| 13 | [Spring methods](13-spring-methods.md) | Which method chains decode each Spring surface and produce facts? |
| 14 | [JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) | Which method chains decode JAX-RS/WebSocket and carry facts into artifacts? |
| 15 | [Method lookup and reading strategy](15-method-lookup.md) | Where is a selected source symbol explained, and how should its call graph be read? |

## Views provided by the guide

No single diagram explains a static analyzer well. The chapters deliberately
provide the following industry-standard complementary views:

| View | What it answers | Primary chapters |
|---|---|---|
| system context and boundaries | What is inside noir-ts, and what remains external evidence or output? | 01, 09 |
| static ownership | Which package/module owns each responsibility and dependency? | 01, 10, 11 |
| dynamic call/sequence | In what order are methods called, including decisions and failure exits? | 02, 08, 12–14 |
| data lifecycle | How do bytes become syntax facts, semantic facts, evidence, rows, and files? | 01, 03, 07, 12–14 |
| decision and ambiguity policy | What proof is required, and where does analysis fail closed? | 03–06, 12–14 |
| effects and failure boundaries | Which methods record diagnostics, print, or mutate artifacts? | 02, 07, 09, 12, 14 |
| worked execution traces | How does concrete Java source travel through those calls? | 08 |
| source and test traceability | Where is a behavior implemented and which regression suite protects it? | 10, 12–15 |
| operational risk | What must a production user freeze, monitor, and review? | 09 |

## Keep three views separate

### Source view

Java declarations, annotations, imports, constants, configuration files, and
deployment descriptors are evidence. They are not endpoint rows.

### Internal fact view

Every analyzer emits `EndpointFact` directly. A fact preserves protocol,
surface, direction, route and handler attribution, typed annotation evidence,
and represented source targets. The pipeline rejects any analyzer result that
is not an `EndpointFact`.

### Public artifact view

`noir.output` performs the deliberate information-loss step. It creates six
public identity fields, normalizes and groups them, then selects
`method_annotation_line` from merged evidence. Some internal distinctions do
not fit the CSV and remain available only to report logic.

~~~mermaid
flowchart TD
    SRC["Source evidence"] --> FACT["EndpointFact"]
    FACT --> ROW["EndpointRowCandidate"]
    ROW --> GROUP["ConsolidatedEndpoints"]
    GROUP --> CSV["Seven public CSV fields"]
    FACT --> EV["AnnotationEvidence + SourceTarget"]
    EV --> GROUP
    GROUP --> AUDIT["Companion reports"]
~~~

## Core vocabulary

- **Direct analyzer:** interprets a route annotation on its concrete source
  declaration while reusing the shared compilation unit.
- **Supplemental analyzer:** adds another source-backed surface such as an
  inherited contract, functional registration, client, Gateway route, or
  WebSocket destination.
- **Fail closed:** skips an unsupported or ambiguous candidate instead of
  guessing, normally recording a diagnostic at the rejection boundary.
- **Workspace:** all parsed compilation units plus cross-file indexes used by
  the selected analyzers.
- **Route source:** the declaration that contributes route identity.
- **Handler source:** the concrete Java declaration attributed to the endpoint.
- **Represented target:** an exact source file, declaration kind, and byte span
  used by the annotations-without-endpoints report.
- **Method annotation evidence:** validated same-file provenance used to choose
  the public annotation line after grouping.

## Production essentials

- The required parser pair is `tree-sitter==0.25.2` and
  `tree-sitter-java==0.23.5`.
- Every discovered Java file is read once and parsed once per run. All selected
  analyzers reuse the resulting unit.
- Most uncertainty is local and fail-closed. A successful exit does not prove
  that every dynamic framework behavior was understood.
- The endpoint CSV and the `Annotation and diagnostics log` artifact use direct
  writes. Each byte report is atomically replaced, but the complete artifact
  set is not one filesystem transaction.
- Framework announcements precede the final completion inventory. A failed run
  never prints `noir-ts analysis completed.`
- Diagnostics belong to the current application run; analyzers record through
  `noir.diagnostics` and do not write report files.
- Preserve the CSV and its companion reports together during review because
  the CSV intentionally contains less provenance than the internal facts.

Continue with [01 — Mental model](01-mental-model.md).
