# 16 — Adding framework support

[← Method lookup](15-method-lookup.md) · [Index](README.md)

This chapter is the production change path for adding one framework family
without coupling it to Spring, JAX-RS, the CLI, or artifact publication. The
current Wicket integration is the executable example. A scalar
`--framework wicket` request runs only its deliberately empty lifecycle; a
repeated request such as `--framework spring --framework wicket` composes the
same Wicket lifecycle with Spring. Neither form claims Wicket endpoint support.

The architecture is intentionally static and procedural. A shipped framework
gets one facade module and one row in an immutable composition table. It does
not get a service container, dynamic module discovery, or framework imports in
the generic pipeline.

Primary coordinates:

- request identity and normalization:
  [`src/noir/model.py`](../src/noir/model.py) :: `FrameworkSelection`,
  `FrameworkMode`, `_normalize_framework_mode()`, `AnalysisRequest`, and
  `FrameworkPlan`;
- CLI projection: [`src/noir/cli.py`](../src/noir/cli.py) ::
  `build_argument_parser()` and `run_cli()`;
- execution composition: [`src/noir/frameworks.py`](../src/noir/frameworks.py)
  :: `FrameworkAdapter`, `FRAMEWORK_ADAPTERS`;
- lifecycle orchestration: [`src/noir/pipeline.py`](../src/noir/pipeline.py) ::
  `_select_frameworks()`, `_build_workspace()`, `run_analysis()`;
- executable empty example:
  [`src/noir/wicket_framework.py`](../src/noir/wicket_framework.py);
- marker policy: [`src/noir/discovery.py`](../src/noir/discovery.py) ::
  `FRAMEWORK_MARKER_RULES`;
- optional annotation policy: [`src/noir/inventory.py`](../src/noir/inventory.py)
  :: `SUPPORTED_ANNOTATION_REGISTRY`, `FINAL_TRIGGER_ANNOTATION_REGISTRY`;
- fact and evidence boundary: [`src/noir/model.py`](../src/noir/model.py) ::
  `EndpointFact` and [`src/noir/evidence.py`](../src/noir/evidence.py).

## 1. Lifecycle and ownership

Every selected family follows the same outer lifecycle:

```mermaid
flowchart TD
    MODE[Framework policy] --> PLAN[FrameworkPlan]
    PLAN --> LOOKUP[frameworks.adapters_for_plan]
    SNAP[Immutable source snapshot] --> WORK[One neutral Java workspace]
    WORK --> CONFIG[Configure every adapter<br/>selected=true or false]
    CONFIG --> AUDIT[Build broad inventory]
    AUDIT --> TRIGGER[Build final-trigger inventory]
    TRIGGER --> PREP[Prepare every selected adapter]
    PREP --> ANALYZE[Analyze selected adapters<br/>in adapter-registry order]
    LOOKUP --> PREP
    ANALYZE --> FACTS[Require EndpointFact values]
    FACTS --> RESULT[AnalysisResult]
    RESULT --> OUTPUT[CLI projection and publication]
```

The phase order is a contract:

1. source bytes are snapshotted once;
2. the neutral workspace parses each Java source once;
3. every adapter receives configuration, including unselected adapters;
4. inventories observe the fully configured workspace;
5. all selected families finish preparation before any family analyzes;
6. selected analysis runs in `FRAMEWORK_ADAPTERS` order; and
7. the pipeline accepts only `EndpointFact` results.

The pipeline owns those phases. A family facade owns only what its three hooks
do inside them. Spring and JAX-RS therefore remain independent: neither facade
imports the other, and adding Wicket adds no Wicket branch to `run_analysis()`.

## 2. Keep execution and marker registries separate

The two registries answer different questions and must not be merged.

| Registry | Owns | Does not own |
|---|---|---|
| `frameworks.FRAMEWORK_ADAPTERS` | shipped lifecycle hooks, authoritative execution order, explicit/default selection mapping, non-auto announcements, and inventory/report family order | raw source detection or semantic annotation recognition |
| `discovery.FRAMEWORK_MARKER_RULES` | raw finding order, detector input kind, scalar-`auto` selection policy, advisory announcements, and report hints | analyzer availability, endpoint proof, lifecycle order, or default membership |

`FrameworkAdapter.name` is also the key passed to the inventory builders and
therefore becomes the report-section identity. Keep it stable. Its
`selection` is the typed public identity used by request plans. Those values
normally share one spelling, as Wicket does, but they have different jobs.

Wicket demonstrates all three independent policy decisions:

- its enum identity and adapter make it explicitly executable;
- `default_selected=False` keeps it out of an omitted-framework run; and
- its marker row uses `selection_mode="manual"` and
  `auto_selected_framework=None`, so an Apache Wicket string is advisory in
  scalar `auto` mode.

Explicit user intent and raw marker evidence are not endpoint proof. Parsed,
unambiguous framework semantics are required before an analyzer may emit a
fact.

## 3. Add model and CLI identity

A publicly selectable family needs one enum member. The CLI choice tuple is
derived automatically from every enum value plus `auto`; do not edit
`FRAMEWORK_MODE_CHOICES` directly. Runtime validation against the enum keeps
CLI and programmatic spellings aligned.

This is the complete selection fragment with the current Wicket identity and
multi-selection policy:

```python
from enum import Enum
from typing import TypeAlias


class FrameworkSelection(str, Enum):
    """One normalized analyzer family selected by orchestration."""

    SPRING = "spring"
    JAX_RS = "jaxrx"
    WICKET = "wicket"


FRAMEWORK_MODE_CHOICES = tuple(
    selection.value for selection in FrameworkSelection
) + ("auto",)

FrameworkMode: TypeAlias = str | tuple[str, ...] | None


def _normalize_framework_mode(mode: FrameworkMode) -> FrameworkMode:
    """Validate and canonicalize one framework-selection policy."""

    if mode is None or mode == "auto":
        return mode
    is_group = isinstance(mode, tuple)
    values = mode if is_group else (mode,)
    if not values:
        raise ValueError("explicit framework selection must not be empty")
    if "auto" in values:
        raise ValueError("auto must be requested once and alone")
    try:
        selections = tuple(FrameworkSelection(value) for value in values)
    except (TypeError, ValueError) as error:
        raise ValueError(f"unsupported framework mode: {mode!r}") from error
    if len(set(selections)) != len(selections):
        raise ValueError("a framework may be requested only once")
    ordered = tuple(
        selection.value
        for selection in FrameworkSelection
        if selection in selections
    )
    return ordered if len(ordered) > 1 else ordered[0]
```

`AnalysisRequest.__post_init__()` calls this helper. One explicit family stays
a string for compatibility; several explicit families become an immutable
tuple in `FrameworkSelection` enum order. `None` remains the omitted policy and
scalar `auto` remains the marker policy. An empty tuple, a duplicate, an
unknown token, or any tuple containing `auto` is invalid.

`FrameworkPlan.__post_init__()` applies the same normalization, rejects
duplicate effective selections, and requires an explicit plan's selected set
to equal its requested set. It compares sets for that invariant because final
lifecycle order comes from the adapter registry.

The CLI keeps one-value syntax and makes the same option repeatable:

```python
parser.add_argument(
    "--framework",
    action="append",
    choices=FRAMEWORK_MODE_CHOICES,
    help=(
        "analyze one registered framework; repeat for multiple frameworks; "
        "use auto alone to detect markers; omit to run Spring and JAX-RS"
    ),
)

requested_frameworks = arguments.framework
if requested_frameworks is None:
    framework_mode = None
elif len(requested_frameworks) == 1:
    framework_mode = requested_frameworks[0]
else:
    framework_mode = tuple(requested_frameworks)
try:
    request = AnalysisRequest(input_path, framework_mode=framework_mode)
except ValueError as error:
    # Reject duplicate or mixed-auto selections before opening any output.
    parser.error(str(error))
```

That normalization occurs before any output is initialized. The public policy
is:

```bash
python3 src/noir_sbt.py \
  --path "/workspace/application" \
  --output "endpoints.csv" \
  --framework spring \
  --framework wicket
```

| Invocation shape | Requested policy | Effective behavior |
|---|---|---|
| no `--framework` | `None` | default adapters: Spring, then JAX-RS |
| `--framework spring` | scalar explicit | Spring only; existing syntax unchanged |
| `--framework wicket` | scalar explicit | Wicket only; empty lifecycle |
| `--framework spring --framework wicket` | tuple explicit | exactly Spring and Wicket |
| the same two options in reverse order | normalized tuple explicit | still Spring then Wicket |
| `--framework auto` | scalar marker policy | marker-selected subset; Wicket advisory |
| a duplicate or `auto` with another occurrence | invalid | rejected before output initialization |

There are two deliberate ordering authorities. `_normalize_framework_mode()`
canonicalizes the request tuple in `FrameworkSelection` enum order.
`adapters_for_plan()` then maps the selected identities in
`FRAMEWORK_ADAPTERS` order, which controls configuration, non-auto
announcements, inventory sections, preparation, and analysis. The current enum
and adapter orders align as Spring, JAX-RS, Wicket, but their responsibilities
remain distinct.

When adding a family, add its enum member only. Default membership belongs to
the adapter row; automatic selection belongs to the marker row. Preserve a
historical public spelling in the enum value even when the Python member name
is clearer, as `JAX_RS = "jaxrx"` demonstrates.

## 4. Create one complete family facade

Create `src/noir/<family>_framework.py`. It may import neutral modules and
modules from its own family. It must not import another family facade or
semantic analyzer.

The three hooks have these roles:

| Hook | When called | Owned work |
|---|---|---|
| `configure_*_workspace(workspace, *, selected)` | once for every registered adapter | attach selected family indexes, or install a stable empty shape when unselected |
| `prepare_*_analysis(request, workspace)` | once for every selected adapter after inventories | derive bounded project-wide state needed before any analysis starts |
| `analyze_*_framework(request, source_paths, workspace)` | once for every selected adapter after all preparation | run the family's deterministic passes and return an immutable fact tuple |

Do not parse in any hook. Consume `workspace["compilation_units"]` and the
ordered source paths already owned by the run. Keep mutable caches and indexes
inside the workspace or one run-local analyzer object.

The following is a complete minimal Wicket facade. Every function body is the
current deliberate behavior; there is no implied route rule hidden behind the
stub:

```python
"""Minimal executable Apache Wicket framework-integration example.

Explicit selection containing Wicket runs these hooks through the same
registry lifecycle as a real family. They intentionally provide no Wicket
endpoint semantics: the stub creates no annotation classifications, workspace
state, diagnostics, or endpoint facts from the raw-text marker.
"""

from __future__ import annotations

from typing import Any

from .model import AnalysisRequest, EndpointFact


def configure_wicket_workspace(
    _workspace: dict[str, Any], *, selected: bool
) -> None:
    """Leave the neutral workspace unchanged for either selection state."""

    return None


def prepare_wicket_analysis(
    _request: AnalysisRequest, _workspace: dict[str, Any]
) -> None:
    """Complete selected Wicket preparation without semantic state."""

    return None


def analyze_wicket_framework(
    _request: AnalysisRequest,
    _source_paths: tuple[str, ...],
    _workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return no facts rather than treating marker text as endpoint proof."""

    return ()


__all__ = [
    "analyze_wicket_framework",
    "configure_wicket_workspace",
    "prepare_wicket_analysis",
]
```

This module is executable wiring, not semantic coverage. Keep it empty until
a separately defined Wicket source shape identifies what constitutes a route,
which declarations own it, and which ambiguous cases must be rejected.

## 5. Register the facade once

Import the hooks only at the static composition root:

```python
from .wicket_framework import (
    analyze_wicket_framework,
    configure_wicket_workspace,
    prepare_wicket_analysis,
)
```

Then place this complete record in `FRAMEWORK_ADAPTERS` at the intended
lifecycle position:

```python
FrameworkAdapter(
    name="wicket",
    selection=FrameworkSelection.WICKET,
    announcement="Found Apache Wicket",
    default_selected=False,
    configure_workspace=configure_wicket_workspace,
    prepare_analysis=prepare_wicket_analysis,
    analyze=analyze_wicket_framework,
)
```

The adapter tuple position is authoritative lifecycle and non-auto
presentation order. Names and selection identities must be unique, every row
must have a valid enum identity, and all provided hooks must be callable.
`default_selected=False` is the safe initial policy for a new family.

No ordinary family addition needs a pipeline branch. If the change appears to
require `if family == ...` in `run_analysis()`, place that work in a facade hook
or extend a genuinely framework-neutral contract instead.

## 6. Decide marker policy independently

A marker is optional. Add one only when raw text is useful for a user-facing
finding or scalar-`auto` selection. It remains parser-free and cannot produce
facts.

These are the complete Wicket detector and its current advisory registry row:

```python
import re
from types import MappingProxyType


def detect_wicket_marker(_source_path: str, source_text: str) -> bool:
    """Recognize the raw-text Wicket marker for announcement only."""

    return re.search(r"org\.apache\.wicket", source_text) is not None


# This complete expression is the Wicket row inside FRAMEWORK_MARKER_RULES.
MappingProxyType(
    {
        "finding_name": "Apache Wicket",
        "selection_mode": "manual",
        "input_kind": "java",
        "marker_detector": detect_wicket_marker,
        "report_hint": "",
        "auto_selected_framework": None,
    }
),
```

Tuple position inside the existing `FRAMEWORK_MARKER_RULES` value controls
finding and scalar-`auto` announcement order. The row is not a separate
execution registration.

For automatic execution, use `selection_mode="auto"` and set
`auto_selected_framework` to the exact enum value only after the marker is an
acceptable run-wide selection heuristic. Advisory detection keeps
`selection_mode="manual"` and `auto_selected_framework=None`, as Wicket does.
Default selection still remains a separate adapter decision.

## 7. Add semantic support only when source evidence requires it

The empty lifecycle does not authorize endpoint inference. Introduce semantic
work one bounded source shape at a time and keep its policy in family-owned
modules.

### 7.1 Queries and shared Java facts

Use existing captures first. When a required neutral syntax shape is absent:

- add its query source in [`src/noir/java_queries.py`](../src/noir/java_queries.py);
- include per-compilation-unit facts in `JAVA_COMPILATION_UNIT_QUERY_SOURCES`;
- include any additional cross-file captures in
  `JAVA_WORKSPACE_QUERY_SOURCES`, the complete mapping compiled by normal
  workspace construction;
- shape syntax in `java_frontend` and cross-file identity in `java_workspace`;
  and
- retain query cursors/nodes only within the workspace lifetime.

Do not add framework package names or route policy to the neutral query layer.
A neutral capture says what Java syntax exists; the family decoder decides
what that syntax means.

### 7.2 Constants, decoders, and indexes

Put vocabulary shared by evidence or output in
[`src/noir/contracts.py`](../src/noir/contracts.py). Put framework packages,
annotation identities, traversal limits, and route decoders in the owning
family module unless more than one neutral consumer genuinely shares them.

Resolve exact library identity through imports, source declarations,
visibility, and shadowing. A simple-name match or raw marker is insufficient.
Preserve invalid and ambiguous candidates until the owning decoder can fail
closed rather than choosing by scan order.

Family-specific cross-file indexes belong behind `configure_*_workspace`.
Attach their populated form when selected and, when neutral consumers require
stable keys, their empty form when unselected. Derive project-wide state in
`prepare_*_analysis`, after inventories and before the first family analyzes.

### 7.3 Broad and final-trigger inventories

Inventory changes are optional and must follow implemented semantics:

- add `SUPPORTED_ANNOTATION_REGISTRY[adapter.name]` entries only for exact
  annotation identities the broad audit can classify;
- add `FINAL_TRIGGER_ANNOTATION_REGISTRY[adapter.name]` entries only for
  supported placements that can directly represent an endpoint declaration;
- extend `source_defined_annotation_classifications()` when a composed or
  source-defined annotation needs family-owned semantic proof; and
- extend `source_defined_final_trigger_classifications()` only when such a
  declaration is itself a supported endpoint trigger.

The broad inventory and final-trigger inventory have different purposes. Do
not add a supporting annotation to the final-trigger registry merely because
it is useful in the broad audit.

If a new method annotation may supply CSV line evidence, add its evidence
family token and priority to `METHOD_ANNOTATION_FAMILY_PRIORITY`, and map each
exact supported identity in `METHOD_ANNOTATION_FAMILY_BY_IDENTITY`. Keep the
inventory row's `family_by_name` consistent with that vocabulary.

Wicket currently has no inventory entry, no source-defined classification
branch, and no evidence-family token. That is intentional. A selected Wicket
section still appears in the final-trigger inventory for each discovered Java
file, in adapter-registry order, and is empty.

## 8. Emit typed facts and evidence

Every successful family branch returns `EndpointFact`, never a CSV mapping.
Populate only values proven by the implemented source rule:

- route path and method;
- public source and handler name;
- distinct route, handler, and project provenance when ownership differs;
- protocol, surface, direction, and family technology; and
- owned annotation evidence and represented source targets where applicable.

Use [`src/noir/evidence.py`](../src/noir/evidence.py) ::
`method_annotation_evidence_from_node()` for a genuine route annotation,
`represented_target_evidence()` for the exact declaration covered by the
fact, and `deduplicate_endpoint_facts()` when one producer needs local
evidence-preserving consolidation. Never manufacture annotation evidence from
`source_line`.

When real Wicket semantics exist, a proven fact may use
`technology="wicket"`; the current empty facade must not emit a fabricated
example. Record supported candidate rejection through
`noir.diagnostics.record()` at the narrowest useful boundary. Unexpected
programming, parser, or filesystem failures must still abort the run rather
than becoming endpoint-free success.

## 9. Let generic output carry the new family

The pipeline combines validated facts in adapter-registry order and returns an
`AnalysisResult`. The CLI projects every family through the same path:

```text
EndpointFact
  -> EndpointRowCandidate
  -> six-field consolidation plus evidence union
  -> seven-column CSV and companion reports
```

Do not write files or print from a facade. Do not add a framework branch to
`output.py` or the report renderer unless the stable public artifact contract
itself changes. Inventory builders already receive selected adapter names, so
mixed runs preserve adapter-registry section order without report-specific
dispatch.

Current Wicket behavior is deliberately empty:

- Wicket alone produces a header-only CSV;
- a mixed selection contributes facts only from implemented families;
- the broad annotation log contains no Wicket classifications;
- the absent-endpoint report contains an empty Wicket section for each
  discovered Java file, positioned by adapter-registry order; and
- non-auto selection containing Wicket includes `Found Apache Wicket` in
  adapter-registry announcement order.

## 10. Keep public and logic documentation aligned

Every new facade should contain a concise module docstring that states its
ownership and links to this chapter plus the relevant family logic chapter.
Every non-trivial hook should explain inputs, output, effects, and failure
behavior. Preserve comments that explain pass order, ambiguity handling,
evidence ownership, and deliberate empty behavior.

Update the live documentation surfaces that actually change:

- `README.md` for public CLI or output behavior;
- `is/000.current.md` for the current architectural contract;
- `p6.logic/README.md`, the code map, method lookup, and core runtime method
  map for new ownership and call paths; and
- a dedicated family chapter when real endpoint semantics are introduced.

Export facade hooks through the facade's `__all__`. The package root usually
needs no family hook export. If genuinely public application or output
conveniences are added there, use the existing lazy `__getattr__` map and
advertise them through `__dir__` without initializing analyzers during
`import noir`.

## 11. Guardrails

| Guardrail | Required shape |
|---|---|
| parse once | consume `source_paths` and workspace compilation units; never construct a parser in the family |
| fail closed | require exact, accessible, unambiguous source evidence; bound recursion and data flow |
| family isolation | a family facade imports only its family and neutral modules; semantic modules do not import sibling families |
| generic pipeline | selection and lifecycle remain registry-driven; no family dispatch branch in `pipeline.py` |
| run-local state | attach mutable indexes and caches to the workspace or analyzer instance; do not mutate module registries during a run |
| typed boundary | emit immutable `EndpointFact` values and typed evidence; project only in `output.py` |
| effect boundary | diagnostics may be recorded; artifact paths, writes, and stdout remain in `cli.py` |
| detector separation | marker rules may select or advise, but never prove an endpoint |
| stable policy | explicit selectability, omitted-mode membership, and scalar-auto eligibility are separate decisions |
| deterministic composition | enum order canonicalizes request tuples; adapter order independently controls runtime and non-auto presentation |

## 12. Minimal production change matrix

Use the smallest row that matches the intended capability:

| Intended capability | Required changes | Leave unchanged |
|---|---|---|
| executable empty family | enum member; complete three-hook facade; one adapter record with `default_selected=False`; live ownership documentation | pipeline family loops, inventories, evidence, output, marker registry |
| explicit combination with existing families | no family-specific mechanism beyond registration; the repeatable CLI and request tuple already compose registered adapters | CLI syntax, pipeline branches, report renderer |
| omitted-mode membership | set only the adapter's `default_selected` policy after broad execution is justified | marker policy and explicit identity |
| advisory source finding | parser-free detector and manual marker row with no auto-selected identity | adapter default and semantic analyzer |
| scalar-auto eligibility | detector row changed to automatic selection with the exact enum token | adapter default and endpoint proof rules |
| new neutral Java shape | query source plus compilation-unit/workspace shaping at the neutral owner | framework packages and route semantics |
| family cross-file state | selected/unselected index shapes in configure; bounded project derivation in prepare | parser ownership and sibling facades |
| broad annotation visibility | exact supported annotation row and any required source-defined classification branch | final-trigger inventory unless the annotation directly represents an endpoint |
| endpoint-trigger visibility | final-trigger row, placement rule, represented target, and evidence-family vocabulary when applicable | renderer-specific framework branches |
| real endpoint extraction | one family-owned semantic pass returning fully proven `EndpointFact` values and owned evidence | CLI publication and public projection unless the artifact contract changes |
| public API or behavior change | relevant README/current-state/logic maps and lazy-root map only when a new root convenience is genuinely public | eager analyzer imports at package root |

For Wicket, only the executable-empty-family and advisory-source-finding rows
are active today. Turning the stub into a real analyzer begins with a specified
Wicket source shape, then adds only the query, decoder, inventory, evidence,
and fact work that shape requires. Default or scalar-auto activation remains a
separate production policy decision.

Return to the [logic guide index](README.md).
