# 01 — Mental model

## 1. What the program is—and is not

`noir_sbt` is a static source recognizer. It uses Java syntax plus a deliberately bounded semantic model to prove endpoint facts. It does not use Maven or Gradle to compile the code, load a classpath, construct a Spring application context, start a JAX-RS container, execute configuration methods, or evaluate arbitrary Java.

That choice explains the central rule used throughout the implementation:

> Emit an endpoint when the framework identity, route data, source binding, and the current branch's explicit eligibility checks are statically unambiguous; otherwise log the reason and skip it.

This is “fail closed” at the candidate level. A bad candidate normally does not abort the scan and does not erase valid sibling candidates.

## 2. System boundary

```mermaid
flowchart TB
    subgraph Inputs
        J["Java source files"]
        SP["Spring application.properties / yml / yaml"]
        WX["JAX-RS web.xml"]
        CLI["CLI options"]
    end

    subgraph StaticAnalyzer["noir_sbt static analyzer"]
        D["Discovery"]
        TS["Tree-sitter parse and queries"]
        W["Whole-workspace semantic indexes"]
        SA["Spring analyzer family"]
        JA["JAX-RS analyzer family"]
        FN["Formatting, normalization, evidence merge"]
    end

    subgraph Outputs
        CSV["Endpoint CSV"]
        LOG["Annotation + diagnostic log"]
        ABS["Annotations-without-endpoints log"]
        STD["stdout / stderr / exit status"]
    end

    CLI --> D
    J --> D
    D --> TS --> W
    SP --> SA
    WX --> JA
    W --> SA
    W --> JA
    SA --> FN
    JA --> FN
    FN --> CSV
    W --> LOG
    SA --> LOG
    JA --> LOG
    W --> ABS
    FN --> ABS
    D --> STD
```

Anything requiring information outside those source/configuration inputs is outside the proof model. Examples include runtime bean conditions, active profiles, dependency bytecode, programmatically generated strings, reflection beyond the one supported registration shape, servlet-container defaults not encoded in the supported source/XML model, and routes introduced by libraries at runtime.

## 3. Layers and dependency direction

[`src/noir_sbt.py`](../src/noir_sbt.py) is only the executable launcher. Read
the application from the command boundary inward:

```mermaid
flowchart TD
    F["noir_sbt.py\nlauncher"] --> C["noir.cli\ncommand effects"]
    C --> A["noir.application\ntyped diagnostic scope"]
    A --> P["noir.pipeline\none-way stage order"]
    P --> M["noir.model\nimmutable request/result/facts"]

    P --> J["java_frontend + java_workspace"]
    J --> N["java_ast + java_methods + java_hierarchy"]
    J --> S["Spring semantic passes"]
    J --> X["JAX-RS semantic passes"]

    S --> O["noir.output + noir.reports"]
    X --> O
    C --> O
```

The pipeline imports the concrete analysis passes it sequences. Specialized
analyzers accept the shared workspace and any feature-specific configuration,
use focused helpers from their owning modules, and return `EndpointFact`
values directly. There is no service locator or cross-module global state.

The diagram's boxes correspond to these concrete definitions:

| Diagram concept | Code coordinate | What to inspect there |
|---|---|---|
| request and result boundary | [`src/noir/model.py`](../src/noir/model.py) :: `AnalysisRequest`, `AnalysisResult` | Validation, immutability, and the data allowed across the application boundary |
| complete stage flow | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | The only top-level ordering of discovery, workspace construction, and framework passes |
| source view | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `SourceSnapshot` and `_snapshot_sources()` | The exact path/byte invariant that makes a run internally consistent |
| parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `build_workspace_runtime()` | The pinned dependency gate and query/runtime construction |
| rich endpoint identity | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` | Route, handler, project, protocol/surface, and private evidence before CSV loss |
| public row boundary | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` | Which rich fields survive projection and which are intentionally discarded |

## 4. One shared workspace, many endpoint families

`run_analysis()` first creates an immutable `SourceSnapshot`. The neutral
`java_workspace.build_java_workspace()` then creates every compilation unit
and shared index; the pipeline attaches Spring/JAX-specific indexes to that
same object. `build_workspace_runtime()` compiles the complete shared query
set once. No framework pass reparses a source already present in the
workspace.

```mermaid
flowchart LR
    F["Every discovered Java file"] --> U["Compilation unit"]
    U --> T["Types and lexical nesting"]
    U --> I["Imports and package"]
    U --> C["String constants"]
    U --> A["Annotation occurrences and definitions"]
    T --> W["Workspace indexes"]
    I --> W
    C --> W
    A --> W
    W --> X1["Direct decoders"]
    W --> X2["Hierarchy graphs"]
    W --> X3["Functional/DSL recognizers"]
    W --> X4["Audit inventories"]
```

The workspace is whole-tree rather than file-local because paths and route annotations can depend on:

- constants declared in other files;
- exact and wildcard imports;
- nested or same-package types;
- source-defined composed annotations;
- custom JAX-RS HTTP method annotations;
- generic interfaces and abstract base classes;
- subresource return types;
- project ownership.

## 5. Endpoint-family catalogue

The following table is the high-level dispatch map. Detailed proof conditions are in the framework chapters.

| Family | Recognized source shape | Internal surface | Public `interface_type` shape |
|---|---|---|---|
| Spring MVC direct | `@GetMapping`, other shortcuts, `@RequestMapping`, supported composed mappings | server | `http <verb>` |
| Spring MVC hierarchy | Mapping on interface/abstract contract bound to a concrete controller method | server | `http <verb>` |
| Spring functional | Servlet/WebFlux `RouterFunction` in a genuine `@Bean` publisher | server | `http <verb>` |
| Spring programmatic MVC | Bounded `RequestMappingHandlerMapping.registerMapping` graph | server | `http <verb>` |
| Spring Cloud Gateway | Bounded `@Bean RouteLocator` Java DSL | gateway | `http-gateway <verb>` |
| Spring static resources | `WebMvcConfigurer.addResourceHandlers` | static-handler | `http-static-handler GET` |
| Spring HTTP Interface | `@HttpExchange` / fixed exchange annotations on interfaces | client | `http-client <verb>` |
| Spring OpenFeign | `@FeignClient` interface plus MVC mappings | client | `http-client <verb>` |
| Spring raw/STOMP handshake | `WebSocketConfigurer` or `WebSocketMessageBrokerConfigurer` registrations | websocket-handshake | `ws GET` |
| Spring messaging | Controller `@MessageMapping` / `@SubscribeMapping` | message | `ws SEND` / `ws SUBSCRIBE` |
| JAX-RS direct | Concrete `@Path` class/record with public designator method | default server | `http <verb>` |
| JAX-RS hierarchy | Interface/abstract annotation bundle bound by erased signature | default server | `http <verb>` |
| JAX-RS subresource | One or more typed `@Path` locator edges leading to a leaf | default server | `http <verb>` |
| Java WebSocket | Javax/Jakarta `@ServerEndpoint` class/record | websocket | `ws GET` |

For non-HTTP protocols, the formatter discards the surface subtype. A Spring handshake and a JAX WebSocket handshake therefore both become `ws GET` in the CSV.

## 6. Three identities inside one endpoint fact

Several analyzers distinguish:

1. **route declaration** — where the path/verb was declared;
2. **concrete handler** — the method/type reported as implementing the endpoint;
3. **project owner** — whose Spring/JAX configuration supplies a base path.

For a direct method all three are usually the same file. They can diverge:

```mermaid
flowchart LR
    C["Interface contract\n@GetMapping('/items')"] -->|"route source"| E["Internal endpoint fact"]
    H["Concrete controller\nItemsController.list()"] -->|"handler + CSV source"| E
    P["Publisher/configuration module"] -->|"base path owner"| E
    E --> R["CSV row"]
    R --> O["Only concrete source/method remains"]
```

The typed value can carry all three identities without exposing a mutable row
shape:

```python
EndpointFact(
    path="/api/items",
    method="GET",
    parameters="String filter",
    source_file=SourceFile("/workspace/app/ItemsController.java"),
    source_line=42,
    handler_name="ItemsController.list",
    route_source_file=SourceFile("/workspace/contracts/ItemsApi.java"),
    route_source_line=12,
    handler_source_file=SourceFile("/workspace/app/ItemsController.java"),
    handler_source_line=42,
    project_source_file=SourceFile("/workspace/app/Routes.java"),
    technology="spring",
    protocol="http",
    surface="server",
    direction="inbound",
    annotation_evidence=(...),
    represented_targets=(...),
)
```

Not every analyzer populates every optional provenance or classification field.
Projection accepts only `EndpointFact`, preserves typed evidence until
consolidation, and does not copy `source_line` directly to the CSV.

## 7. Additions-only passes

The direct Spring and JAX-RS passes cover simple concrete annotations. Hierarchy, route-registration, and other specialized extraction passes append facts they can prove beyond that baseline; a candidate-local rejection in one of those passes does not delete an unrelated direct fact. This additions-only description ends at extraction: the later Spring configuration pass rewrites every Spring path and can drop any fact whose configured path cannot be resolved. An unexpected exception in any pass aborts the whole run.

```mermaid
flowchart TD
    SD["Direct Spring facts"] --> SA["Append Spring route registrations, hierarchy, and other surfaces"]
    SA --> C["Apply Spring configuration; facts may be rewritten or dropped"]
    JD["Direct JAX-RS facts"] --> JA["Append JAX-RS hierarchy, locator, and WebSocket facts"]
    C --> M["Combine selected framework facts"]
    JA --> M
    M --> N["Normalize"]
    N --> G["Group on public six-field identity"]
    G --> R["One final row per identity"]
```

The final identity includes concrete source, method name, and raw parameter text. Two handlers with the same method/path remain two rows when those fields differ.

## 8. The two meanings of “line”

There are two unrelated line concepts:

- `source_line` is the analyzer’s internal diagnostic line, which may be a route call, handler method, annotation, or type depending on the branch.
- `method_annotation_line` is selected later from validated same-source method-annotation evidence.

They are not interchangeable. Non-annotation routes and cross-file inherited mappings can have a meaningful internal `source_line` while the CSV column is blank.

## 9. Determinism versus completeness

The implementation invests heavily in deterministic ordering and ambiguity rejection:

- sorted discovery;
- exact source identities;
- fixed framework and HTTP-method order;
- source-byte ordering;
- deterministic local and final deduplication;
- bounded graph traversal;
- rejection of multiple equally valid bindings.

Those properties make repeated results auditable, but they do not prove completeness. Unsupported or ambiguous valid Java can be skipped. The diagnostics and annotations-without-endpoints report are therefore part of the result, not optional noise.

Next: [02 — CLI and orchestration](02-cli-and-orchestration.md).
