# 10 — Code map

[← Worked traces](08-worked-traces.md) · [Index](README.md) · [Application vocabulary →](11-naming-and-code-vocabulary.md)

This chapter maps current application behavior to its owning production
source. Coordinates use linked files plus stable symbols instead of line
numbers.

## 1. Architectural route

~~~mermaid
flowchart TB
    LAUNCH["src/noir_sbt.py<br/>executable guard"]
    CLI["noir.cli<br/>arguments, artifacts, stdout"]
    APP["noir.application<br/>typed diagnostic scope"]
    PIPE["noir.pipeline<br/>snapshot, selection, generic phases"]
    REG["noir.frameworks<br/>static execution table"]
    RUNTIME["tree_sitter_runtime<br/>version gate and runtime"]
    JAVA["java_frontend + java_workspace<br/>parse once and index"]
    SPRING["spring_framework<br/>Spring family facade"]
    JAX["jaxrs_framework<br/>JAX-RS family facade"]
    WICKET["wicket_framework<br/>selectable empty facade"]
    MODEL["noir.model<br/>typed facts and result"]
    INV["noir.inventory<br/>broad and trigger views"]
    OUTPUT["noir.output<br/>projection and consolidation"]
    REPORTS["noir.reports + noir.comparison<br/>render and publish"]

    LAUNCH --> CLI --> APP --> PIPE
    PIPE --> REG
    PIPE --> RUNTIME --> JAVA
    REG --> SPRING
    REG --> JAX
    REG --> WICKET
    JAVA --> SPRING --> MODEL
    JAVA --> JAX --> MODEL
    JAVA --> WICKET
    WICKET -. empty tuple .-> MODEL
    JAVA --> INV --> MODEL
    MODEL --> OUTPUT --> REPORTS
    CLI --> REPORTS
~~~

`src/noir_sbt.py` is intentionally a thin launcher. Application behavior lives
under `src/noir/`, whose modules import their real owners directly. Framework
analyzers consume the shared workspace and emit `EndpointFact` values; they do
not depend on the launcher, mutate command state, or publish files.

### Fast implementation trail

| Step | Code coordinate | Responsibility |
|---|---|---|
| launch | [`src/noir_sbt.py`](../src/noir_sbt.py) :: executable guard | Import `noir.cli.main` and exit with its status. |
| validate and publish | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` | Validate inputs, bind diagnostics, invoke analysis, project facts, publish requested artifacts in order, and print success output. |
| own one typed run | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` | Validate `AnalysisRequest`, own or reuse a collector, call the pipeline, and attach only this invocation's diagnostics. |
| orchestrate analysis | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | Validate parser availability, snapshot sources, select frameworks, build one workspace, run analyzers, and return `AnalysisResult`. |
| compose analyzer families | [`src/noir/frameworks.py`](../src/noir/frameworks.py) :: `FRAMEWORK_ADAPTERS` | Bind static family hooks, execution order, explicit selection identity, and default policy. |
| run family sequences | [`src/noir/spring_framework.py`](../src/noir/spring_framework.py) :: `analyze_spring_framework()`; [`src/noir/jaxrs_framework.py`](../src/noir/jaxrs_framework.py) :: `analyze_jaxrs_framework()`; [`src/noir/wicket_framework.py`](../src/noir/wicket_framework.py) :: `analyze_wicket_framework()` | Own each family's pass order or deliberate empty behavior without cross-family imports. |
| build parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `require_tree_sitter()`, `build_workspace_runtime()` | Enforce the supported dependency pair and construct the parser/query runtime. |
| parse and index | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` → [`src/noir/java_frontend.py`](../src/noir/java_frontend.py) :: `build_java_compilation_unit()` | Parse each snapshotted source once and build shared per-file and cross-file facts. |
| run direct mappings | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()`; [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` | Interpret proven direct Spring and JAX-RS annotations as typed endpoint facts. |
| build inventories | [`src/noir/inventory.py`](../src/noir/inventory.py) :: `build_annotation_audit_inventory()`, `build_final_trigger_inventory()` | Build the broad annotation view and the narrower endpoint-trigger view from the shared workspace. |
| project and consolidate | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()`, `consolidate_endpoint_rows()` | Cross the public information-loss boundary, normalize identity, merge evidence, and select the annotation line. |
| render reports | [`src/noir/reports.py`](../src/noir/reports.py) :: `render_annotations_without_endpoints_report_bytes()`; [`src/noir/comparison.py`](../src/noir/comparison.py) :: `flatten_final_trigger_inventory()`, `compare_final_trigger_inventory()` | Render the trigger-based absent report and optional trigger-only exact source-location comparison. |

## 2. Package ownership

### 2.1 Invocation and application core

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.cli`](../src/noir/cli.py) | `build_argument_parser`, `run_cli`, `render_completion_summary` | User input, filesystem effects, publication order, and stdout. |
| [`noir.application`](../src/noir/application.py) | `AnalysisRunner`, `analyze` | Typed call boundary and diagnostic ownership. |
| [`noir.pipeline`](../src/noir/pipeline.py) | `SourceSnapshot`, `FrameworkDecision`, `run_analysis` | Complete source-to-result ordering with no artifact I/O. |
| [`noir.frameworks`](../src/noir/frameworks.py) | `FrameworkAdapter`, `FRAMEWORK_ADAPTERS`, `default_framework_selections`, `adapters_for_plan` | Frozen execution composition, selection lookup, setup/preparation hooks, and family order. |
| [`noir.discovery`](../src/noir/discovery.py) | `discover_java_files`, `discover_pom_files`, `scan_framework_markers` | Ignored-path pruning, deterministic discovery, and marker-based auto selection. |
| [`noir.tree_sitter_runtime`](../src/noir/tree_sitter_runtime.py) | `SUPPORTED_VERSIONS`, `require_tree_sitter`, `build_workspace_runtime`, `run_query_matches` | Parser package gate and query runtime construction. |
| [`noir.diagnostics`](../src/noir/diagnostics.py) | `DiagnosticCollector`, `bind`, `record`, `format_endpoint_diagnostic` | Run-scoped diagnostic capture and stable endpoint messages. |
| [`noir.contracts`](../src/noir/contracts.py) | `CSV_FIELDS`, framework constants, evidence-family constants | Shared declarative vocabulary used by analyzers and presentation. |

### 2.2 Shared Java engine

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.java_queries`](../src/noir/java_queries.py) | `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | Framework-neutral query-source definitions. |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `parse_java_query_set`, `build_java_compilation_unit`, `resolve_known_annotation`, `resolve_known_type` | Tree-sitter parsing, capture association, per-file facts, and known-library identity. |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace`, `resolve_workspace_owner_fqns`, `resolve_workspace_string_expression` | Cross-file types, members, constants, annotations, retention, and access rules. |
| [`noir.java_ast`](../src/noir/java_ast.py) | `field`, `walk_named`, `known_type`, `is_direct_invocation_statement` | Small shared AST navigation and proof helpers. |
| [`noir.java_methods`](../src/noir/java_methods.py) | `MethodFact`, `MethodIndex`, `build_strict_method_index`, `build_varargs_method_index` | Deterministic method and invocation indexes for bounded source flows. |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaTypeReference`, `JavaMethodRecord`, `JavaTypeRecord`, `JavaSourceHierarchyGraph` | Generic adaptation, erased signatures, inheritance traversal, and implementation selection. |
| [`noir.paths`](../src/noir/paths.py) | `join_endpoint_paths`, `ensure_path_leading_slash`, `relative_source_path` | Neutral route composition and public source-path formatting. |

Runtime construction belongs to `tree_sitter_runtime`; the actual source parse
belongs to `java_frontend`. Framework analyzers receive parsed workspace
products and never construct their own parser.

### 2.3 Framework analyzers

| Owner | Entry point | Surface |
|---|---|---|
| [`noir.spring_framework`](../src/noir/spring_framework.py) | `configure_spring_workspace`, `prepare_spring_analysis`, `analyze_spring_framework` | No-op shared setup/preparation plus the complete ordered Spring family. |
| [`noir.jaxrs_framework`](../src/noir/jaxrs_framework.py) | `configure_jaxrs_workspace`, `prepare_jaxrs_analysis`, `analyze_jaxrs_framework` | JAX indexes, deployment model, direct resources, hierarchy/subresources, and Java WebSocket. |
| [`noir.wicket_framework`](../src/noir/wicket_framework.py) | `configure_wicket_workspace`, `prepare_wicket_analysis`, `analyze_wicket_framework` | Explicitly selectable no-op setup/preparation and empty analysis result; no endpoint semantics yet. |
| [`noir.spring_mvc`](../src/noir/spring_mvc.py) | `analyze_direct_spring_mvc_unit` | Direct MVC mappings, composed annotations, records, and mapping indexes. |
| [`noir.spring_route_registrations`](../src/noir/spring_route_registrations.py) | `analyze_spring_route_registrations` | Functional RouterFunction routes and programmatic MVC registrations. |
| [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) | `analyze_spring_mvc_hierarchy` | Inherited mapping contracts bound to concrete controllers. |
| [`noir.spring_gateway`](../src/noir/spring_gateway.py) | `analyze_spring_gateway` | Spring Cloud Gateway Java DSL routes. |
| [`noir.spring_config`](../src/noir/spring_config.py) | `build_spring_path_configuration`, `analyze_spring_resource_handlers`, `apply_spring_path_configuration` | Project configuration, resource handlers, placeholders, and final Spring path layers. |
| [`noir.spring_clients`](../src/noir/spring_clients.py) | `analyze_spring_http_clients` | Spring HTTP Interface and OpenFeign outbound contracts. |
| [`noir.spring_websocket_messaging`](../src/noir/spring_websocket_messaging.py) | `analyze_spring_websocket_and_messaging` | Raw/STOMP handshakes and message destinations. |
| [`noir.jaxrs`](../src/noir/jaxrs.py) | `analyze_direct_jax_rs_unit` | Direct resources, custom request methods, record accessors, and application paths. |
| [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) | `build_jax_rs_deployment_model`, `select_jax_rs_deployment_prefix` | Source applications and bounded `web.xml` deployment prefixes. |
| [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) | `analyze_jax_rs_hierarchy_and_subresources` | Inherited resource bundles and recursive subresource locators. |
| [`noir.java_websocket`](../src/noir/java_websocket.py) | `analyze_java_websocket_endpoints` | Javax/Jakarta WebSocket server handshakes. |

Every entry point above returns `EndpointFact` values. Local deduplication uses
an analyzer-specific identity callback and the shared typed evidence merger in
`noir.evidence`.

### 2.4 Domain, evidence, and presentation

| Owner | Principal symbols | Responsibility |
|---|---|---|
| [`noir.model`](../src/noir/model.py) | `FrameworkMode`, `FrameworkSelection`, `AnalysisRequest`, `FrameworkPlan`, `EndpointFact`, `AnalysisResult` | Immutable application vocabulary, including scalar/tuple request normalization. |
| [`noir.evidence`](../src/noir/evidence.py) | `method_annotation_evidence_from_node`, `represented_target_evidence`, `deduplicate_endpoint_facts` | Validate, merge, and select typed provenance. |
| [`noir.inventory`](../src/noir/inventory.py) | `build_annotation_audit_inventory`, `build_final_trigger_inventory` | Broad and endpoint-trigger annotation views. |
| [`noir.output`](../src/noir/output.py) | `EndpointRowCandidate`, `ConsolidatedEndpoints`, `consolidate_endpoint_rows`, `write_endpoint_csv` | Public row projection, six-field grouping, seventh-field selection, and exact CSV bytes. |
| [`noir.reports`](../src/noir/reports.py) | `write_annotation_diagnostic_log`, `render_annotations_without_endpoints_report_bytes`, `publish_bytes_atomically` | Baseline companion artifacts. |
| [`noir.comparison`](../src/noir/comparison.py) | `load_noir_report_locations`, `flatten_final_trigger_inventory`, `compare_final_trigger_inventory`, `render_noir_comparison_report_bytes` | Strict Noir report validation, trigger-occurrence normalization, and exact canonical file/line comparison. |
| [`noir.immutability`](../src/noir/immutability.py) | `freeze_data` | Detach and freeze nested result data. |

## 3. Exact analyzer order

`run_analysis()` creates the snapshot and framework decision, then builds the
neutral workspace. It configures every adapter with its selected state before
building the broad and final-trigger inventories. Next it prepares every
selected adapter; JAX-RS builds its deployment model here. Only after all
preparation completes does the pipeline call selected analyzers in execution-
registry order.

Spring order:

1. direct Spring MVC for each source;
2. functional and programmatic route registrations;
3. MVC hierarchy additions;
4. Gateway;
5. static resource handlers;
6. outbound clients;
7. project path configuration;
8. WebSocket and messaging;
9. one final Spring path-configuration application across collected facts.

JAX-RS order:

1. direct JAX-RS for each compilation unit;
2. hierarchy and subresource additions;
3. Java WebSocket handshakes.

Selected Wicket order is the same three lifecycle phases with no semantic
work: configure leaves the workspace unchanged, prepare leaves project state
unchanged, and analyze returns `()`. It may run alone or in a repeated explicit
selection such as Spring plus Wicket. The registry, not CLI occurrence order,
places Spring before Wicket. Wicket is excluded from the omitted-mode default
and from auto selection.

These passes share one workspace. Their iteration order may affect diagnostics,
but public rows are normalized, grouped, and sorted later by `noir.output`.

## 4. High-value production invariants

| Invariant | Where the invariant is established |
|---|---|
| The script is only an executable launcher; package code never imports it. | `src/noir_sbt.py` and package import direction |
| Parser runtime construction has one owner and actual Java parsing has one frontend owner. | `noir.tree_sitter_runtime` and `noir.java_frontend` |
| Each discovered Java source is read and parsed once, then reused by every selected pass. | `SourceSnapshot`, `build_java_workspace()`, and `run_analysis()` |
| Analyzer entry points return `EndpointFact`; presentation cannot manufacture analyzer facts. | typed analyzer boundaries and `AnalysisResult` construction |
| Diagnostics belong to one application invocation; only the CLI publishes artifacts and stdout. | `noir.application`, `noir.diagnostics`, and `noir.cli` |
| Ambiguous Java identity, constants, hierarchy, deployment, or flow fail closed locally. | the resolver/decoder that owns each proof boundary |
| Duplicate facts merge annotation evidence and represented targets deterministically. | `noir.evidence` and `noir.output` |
| The first six CSV fields define row identity; annotation line selection occurs after evidence merge. | `EndpointRowCandidate.public_identity()` and `consolidate_endpoint_rows()` |
| CLI success appears only after all requested artifacts publish. | the final branch of `run_cli()` |

## 5. Change-impact ownership

| If changing… | Start with… | Then follow… |
|---|---|---|
| CLI validation, naming, publication, or stdout | `noir.cli` | report renderer or application call only when that boundary also changes |
| request/result or diagnostic scope | `noir.model`, `noir.application`, `noir.diagnostics` | pipeline stage order if the lifecycle changes |
| discovery or automatic framework markers | `noir.discovery` | `_select_frameworks()` and announcement projection |
| execution order, default family selection, or adapter hooks | `noir.frameworks` | the owning family facade, then `noir.pipeline` phase orchestration |
| adding another framework family | [Adding framework support](16-adding-framework-support.md) | model/CLI identity, one facade, one adapter record, then optional semantic inventories and evidence |
| parser/query construction | `noir.tree_sitter_runtime`, `noir.java_queries`, `noir.java_frontend` | workspace consumers of a changed capture |
| imports, types, constants, access, or ambiguity | `noir.java_workspace` | every analyzer that consumes the changed proof |
| direct Spring or JAX semantics | `noir.spring_mvc` or `noir.jaxrs` | hierarchy/configuration only when it participates |
| one supplemental surface | its owning Spring/JAX/WebSocket module | evidence and output if public identity changes |
| evidence ownership or deduplication | `noir.evidence` | `noir.output`, inventories, and reports |
| Noir report parsing or matching | `noir.comparison` | `noir.cli` when naming or publication order changes |
| shared constants or registries | `noir.contracts` or the defining module | all importers, because these values deliberately have multiple consumers |

For a missing endpoint, compare an accepted source shape with its closest
look-alike that fails closed: a shadowed import, ambiguous constant,
unsupported placement, mixed namespace, cycle, or unresolved value. The first
resolver that returns `None` owns the relevant application decision.

## 6. Chapter-to-code index

| Chapter | First code coordinate |
|---|---|
| [Mental model](01-mental-model.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [CLI and orchestration](02-cli-and-orchestration.md) | [`src/noir/cli.py`](../src/noir/cli.py) :: `run_cli()` |
| [Shared Java engine](03-shared-java-engine.md) | [`src/noir/java_workspace.py`](../src/noir/java_workspace.py) :: `build_java_workspace()` |
| [Spring MVC](04-spring-mvc.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [Additional Spring surfaces](05-spring-additional-surfaces.md) | [`src/noir/spring_framework.py`](../src/noir/spring_framework.py) :: `analyze_spring_framework()` |
| [JAX-RS](06-jax-rs.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Output and reports](07-output-evidence-reports.md) | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` |
| [Worked traces](08-worked-traces.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Production use](09-production-use.md) | [`src/noir/application.py`](../src/noir/application.py) :: `analyze()` |
| [Application vocabulary](11-naming-and-code-vocabulary.md) | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` |
| [Core runtime methods](12-core-runtime-methods.md) | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` |
| [Spring methods](13-spring-methods.md) | [`src/noir/spring_mvc.py`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` |
| [JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) | [`src/noir/jaxrs.py`](../src/noir/jaxrs.py) :: `analyze_direct_jax_rs_unit()` |
| [Method lookup](15-method-lookup.md) | exact symbol search across the three method guides |
| [Adding framework support](16-adding-framework-support.md) | [`src/noir/frameworks.py`](../src/noir/frameworks.py) :: `FrameworkAdapter` and one family facade |

Return to the [guide index](README.md), or continue to
[Application logic vocabulary](11-naming-and-code-vocabulary.md).
