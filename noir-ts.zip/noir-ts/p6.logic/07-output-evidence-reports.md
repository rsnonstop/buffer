# 07 — Typed output, evidence, consolidation, and reports

[← JAX-RS](06-jax-rs.md) · [Index](README.md) · [Next: Worked traces →](08-worked-traces.md)

One analysis produces a rich immutable result and three baseline artifacts.
`--noir-report` adds a fourth comparison artifact. Each answers a different
question:

| Artifact | Question | Owner |
|---|---|---|
| endpoint CSV | Which endpoint rows did the bounded source model prove? | [`noir.output`](../src/noir/output.py) |
| `<output>.log` | Which relevant annotations and diagnostic events were observed? | [`noir.reports`](../src/noir/reports.py) |
| `*-anno-without-endpoints.log` | Which final-trigger declaration targets have no final row? | [`noir.reports`](../src/noir/reports.py) |
| `*-anno-without-noir-endpoints.log` | Which potential endpoint-trigger locations have no exact location in a supplied Noir v1.1 report? | [`noir.comparison`](../src/noir/comparison.py) |

Method-level companion:
[14 — JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) traces
the exact evidence, consolidation, rendering, comparison, and publication
methods.

For `--output endpoints.csv`:

```text
endpoints.csv.log
endpoints-anno-without-endpoints.log
endpoints-anno-without-noir-endpoints.log  # only with --noir-report
```

The seven-column CSV is intentionally lossy. Companion reports are parallel
evidence views and cannot be reconstructed from it.

## 1. Presentation flow

```mermaid
flowchart TB
    Pipeline["run_analysis"] --> Result["AnalysisResult"]
    Result --> Facts["tuple[EndpointFact]"]
    Result --> Audit["broad annotation inventory"]
    Result --> Triggers["final-trigger inventory"]

    Facts --> Project["endpoint_fact_to_row_candidate"]
    Project --> Candidates["EndpointRowCandidate values"]
    Candidates --> Consolidate["normalize + six-field group + evidence union"]
    Consolidate --> Rows["ConsolidatedEndpoints.rows"]
    Consolidate --> Targets["ConsolidatedEndpoints.represented_targets"]

    Audit --> Broad["annotation/diagnostic log"]
    Triggers --> Absent["absent-trigger renderer"]
    Targets --> Absent
    Triggers --> Compare["optional exact-location comparison"]

    Rows --> CSV["endpoint CSV"]
    Broad --> Log["<output>.log"]
    Absent --> Missing["atomic absent-trigger report"]
    Compare --> NoirMissing["atomic comparison report"]
```

[`run_cli`](../src/noir/cli.py) owns argument validation, one diagnostic scope,
projection, rendering, publication order, and success output. Framework
analyzers do not know about CSV or artifact paths.

## 2. Typed values before presentation

### 2.1 `EndpointFact`

Framework analyzers return frozen, slot-based
[`EndpointFact`](../src/noir/model.py) values. Important fields are:

| Data | Meaning |
|---|---|
| `path`, `method`, `parameters` | analyzer result before public normalization |
| `source_file`, `source_line`, `handler_name` | public attribution and analyzer diagnostic context |
| `route_source_file`, `route_source_line` | route declaration provenance |
| `handler_source_file`, `handler_source_line` | concrete handler provenance |
| `project_source_file` | configuration ownership provenance |
| `protocol`, `surface`, `direction`, `technology` | rich interface classification |
| `annotation_evidence` | tuple of `AnnotationEvidence` |
| `represented_targets` | tuple of `SourceTarget` |
| `spring_client_path_layers` | deferred Spring client path layers, or `None` |

Path-like source inputs are normalized to `SourceFile`. Evidence and targets
must already be typed; mappings are rejected. Every domain collection is
snapshotted as an immutable tuple.

`SourceSpan` stores a nonempty half-open byte range in one `SourceFile`.
`SourceTarget` adds declaration kind (`method`, `record-component`, or `type`).
This separates source provenance from display strings and parser nodes.

### 2.2 Output values

[`endpoint_fact_to_row_candidate`](../src/noir/output.py) accepts one
`EndpointFact` and returns a frozen `EndpointRowCandidate` containing:

- the six public identity cells;
- owned `AnnotationEvidence`; and
- owned `SourceTarget` values.

The seventh CSV cell is not chosen during projection. Evidence must first merge
across every candidate with the same public identity.

[`ConsolidatedEndpoints`](../src/noir/output.py) contains only:

- `rows`: a tuple of read-only string mappings; and
- `represented_targets`: the typed global target union.

There is no second row shape inside the domain. The public CSV boundary and the
typed report-evidence boundary remain explicit.

## 3. The one information-loss boundary

Projection retains only what the stable public artifact can express:

```mermaid
flowchart LR
    Fact["EndpointFact: route + handler + project + classification + evidence"]
    Fact --> Candidate["EndpointRowCandidate"]
    Candidate --> Identity["six public cells"]
    Candidate --> Evidence["owned annotation evidence"]
    Candidate --> Targets["owned represented targets"]
    Identity --> Group["consolidate_endpoint_rows"]
    Evidence --> Group
    Targets --> Group
    Group --> Row["seven public cells"]
    Group --> TargetUnion["global target union"]
```

Route/handler/project detail, direction, technology, and some surface detail do
not all fit the CSV. They remain available until this projection.

## 4. Seven columns and six-field identity

The exact public order from [`CSV_FIELDS`](../src/noir/contracts.py) is:

| Position | Column | Construction |
|---:|---|---|
| 1 | `module_name` | analysis-root basename supplied by CLI |
| 2 | `interface_type` | compressed protocol/surface plus method |
| 3 | `endpoint` | normalized path, URL, or destination |
| 4 | `source_file_name` | POSIX path relative to analysis root |
| 5 | `method_name` | analyzer-selected handler |
| 6 | `parameters` | analyzer-supplied parameter spelling |
| 7 | `method_annotation_line` | selected owned evidence line, or blank |

Only the first six define identity:

```text
(module_name,
 interface_type,
 endpoint,
 source_file_name,
 method_name,
 parameters)
```

`method_annotation_line` describes that identity. Candidates differing only in
evidence must merge before the line is selected.

Public values are stringified without mutating inputs. `None` becomes an empty
cell; scalar values use their normal spelling; structured values prefer Unicode
JSON and fall back to `str` if encoding fails.

## 5. `interface_type`

Projection appends the endpoint method to a compressed interface kind:

| Fact | Public value |
|---|---|
| HTTP server `GET` | `http GET` |
| HTTP server unconstrained | `http ANY` |
| HTTP client `POST` | `http-client POST` |
| HTTP gateway `GET` | `http-gateway GET` |
| HTTP static handler `GET` | `http-static-handler GET` |
| WebSocket handshake `GET` | `ws GET` |
| message send | `ws SEND` |

For HTTP, empty/server surface becomes `http`; another surface becomes
`http-<surface>`. For non-HTTP protocols, only the protocol is public. Internal
surface, direction, and technology remain facts but are not separately encoded.

## 6. Path normalization before grouping

[`normalize_endpoint_path`](../src/noir/output.py) runs before the identity key
is built, so different analyzer spellings can consolidate.

### 6.1 Spring templates and placeholders

A balanced Spring regex template drops its constraint:

```text
/orders/{id:[0-9]{1,3}} -> /orders/{id}
```

The scanner respects nested/escaped braces. An unbalanced shape is preserved
rather than guessed.

Any remaining `${...}` becomes a stable brace parameter using its last
Java-like identifier, or `value` when none exists:

```text
${route.leaf}    -> {leaf}
${route.leaf:/x} -> {x}
${---}           -> {value}
```

This is presentation normalization, not project-property evaluation.

### 6.2 Slashes and protocols

Repeated slashes collapse unless preceded by `:`, preserving URL authority.
`http-client` and `http-gateway` still normalize as HTTP. A nonempty relative
HTTP value gains a leading slash; non-HTTP destinations stay relative.

```text
http-client GET + api//items      -> /api/items
ws SEND         + topic//events   -> topic/events
http GET        + HTTP://x//v1    -> HTTP://x/v1
grpc CALL       + service//Method -> service/Method
```

## 7. Method-annotation evidence

The CSV line is never copied from `EndpointFact.source_line`. It is recalculated
from validated [`AnnotationEvidence`](../src/noir/model.py).

One usable record proves:

- a positive non-Boolean integer line;
- a canonical dotted Java annotation identity;
- a recognized evidence family; and
- a canonical annotation source equal to the public endpoint source.

Canonical ownership uses normalized real absolute paths. An interface,
superclass, route declaration, or configuration annotation may prove an
endpoint while not owning its public handler row; it cannot fill that row's
line cell.

[`merge_method_annotation_evidence`](../src/noir/evidence.py) deduplicates by:

```text
(family, line, identity, canonical source file)
```

[`select_method_annotation_evidence`](../src/noir/evidence.py) orders by:

1. Spring verb-specific mapping;
2. Spring generic mapping;
3. Spring message mapping;
4. JAX-RS request-method designator;
5. lowest line within a family;
6. annotation identity as final tie-break.

A Spring verb mapping at line 20 therefore outranks a JAX designator at line 2.
Validated source-defined annotations carry the family established by their
semantic decoder.

Typical blank lines include cross-file inherited mappings, synthesized record
accessors, functional/Gateway/resource registrations, and `@ServerEndpoint`.

## 8. Represented targets

The absent-trigger report subtracts declarations, not route strings or handler
names. One target is:

```text
SourceTarget(
  kind,
  SourceSpan(SourceFile(canonical_path), start_byte, end_byte)
)
```

Spans satisfy `0 <= start_byte < end_byte`. The supported kinds are `method`,
`record-component`, and `type`.

Projection keeps only targets owned by the endpoint's public source file.
Consolidation canonicalizes, deduplicates, sorts, and unions targets across all
surviving public groups.

Subtraction is target-level. If one final row represents a method, every
final-trigger annotation attached to that method is covered. An interface
target stays absent when the row represents only a concrete implementation.
One grouped CSV row can cover multiple exact declarations because duplicates
union their target evidence.

## 9. Typed merge and consolidation

Analyzer-local merging and public consolidation solve different problems.

[`merge_endpoint_facts`](../src/noir/evidence.py) keeps the newer
`EndpointFact`'s ordinary fields while unioning annotation evidence and targets.
[`deduplicate_endpoint_facts`](../src/noir/evidence.py) accepts a typed identity
callback, allowing each analyzer to include transient or surface-specific
identity.

[`consolidate_endpoint_rows`](../src/noir/output.py) is authoritative for the
public artifact:

1. copy the six public cells;
2. stringify them and normalize `endpoint`;
3. group by the exact six-value tuple;
4. union annotation evidence and represented targets;
5. select the annotation line;
6. build a fresh seven-field row in requested order;
7. sort groups lexicographically; and
8. return immutable tuple/read-only snapshots.

Reversing candidate iteration produces the same consolidated value. Any
difference in normalized method, interface, handler, source file, parameters,
or endpoint keeps rows separate.

### Worked merge

Two candidates have the same public handler:

| Field | A | B |
|---|---|---|
| endpoint | `//api//items/{id:[0-9]+}` | `/api/items/{id}` |
| evidence | JAX `GET`, line 2 | Spring `GetMapping`, line 20 |
| target | method bytes 30–50 | method bytes 10–20 |

Both normalize to `/api/items/{id}`. The six fields match, Spring family
priority selects line 20, and both targets survive. The public row is:

```text
app;http GET;/api/items/{id};Api.java;Api.items;;20
```

## 10. Companion annotation views

### 10.1 Broad annotation and diagnostic log

[`write_annotation_diagnostic_log`](../src/noir/reports.py) writes the broad
annotation inventory followed by a mandatory `Diagnostics:` section. Broad
inventory includes endpoint triggers and useful activation/binding metadata.
Each occurrence can show source spelling, line, framework classifications,
resolved identities, and a source extract. A file without recognized
annotations renders `Annotations: none`.

The inventory has deterministic analysis order and no timestamps. Timestamped
collector lines follow it.

### 10.2 Annotation-without-endpoints report

[`render_annotations_without_endpoints_report_bytes`](../src/noir/reports.py)
receives final-trigger inventory and the global target union. It:

- sorts files by display path;
- preserves the selected execution-adapter order supplied by inventory
  construction;
- filters by exact target membership;
- orders remaining declarations by byte span;
- renders deterministic UTF-8 bytes; and
- emits `Annotations without endpoints: none` for an empty selected section.

An empty inventory produces exactly empty bytes. Path derivation removes only
the final suffix:

```text
endpoints.csv       -> endpoints-anno-without-endpoints.log
endpoints           -> endpoints-anno-without-endpoints.log
endpoints.audit.csv -> endpoints.audit-anno-without-endpoints.log
```

Any explicit selection containing Wicket is a useful empty-path example.
Wicket currently has no broad or final-trigger annotation classifications and
its facade emits no facts. For every discovered Java file, the final-trigger
inventory still carries the selected `wicket` section in adapter-registry
order and the renderer prints
`Annotations without endpoints: none`; with no Java files the report is empty.
Adding real classifications and facts follows the extension path in
[16 — Adding framework support](16-adding-framework-support.md) without adding
a Wicket branch to the renderer.

## 11. Optional Noir location comparison

`--noir-report` compares the final-trigger inventory—not the broad annotation
inventory or CSV rows—with source locations from a Noir v1.1 JSON report. It
therefore uses the same trigger recognition and supported-placement gates as
the annotations-without-endpoints report while applying a different coverage
rule.

[`load_noir_report_locations`](../src/noir/comparison.py) validates input before
any output is initialized. The root is an object with an `endpoints` array;
each endpoint has `details.code_paths`; and every code path has a nonempty
string `path`. A missing/null line is skipped. A present line must be a positive
non-Boolean integer.

Absolute paths canonicalize directly. Relative paths resolve from the analysis
root. A spelling that includes the root basename is disambiguated against real
files; two existing interpretations make the report invalid.

The exact match key is:

```text
(canonical real absolute source path, positive one-based annotation line)
```

URL, HTTP method, technology, annotation name, and enclosing declaration do
not participate. Two potential endpoint-trigger annotations on one physical
line therefore both match or both remain unmatched.

[`flatten_final_trigger_inventory`](../src/noir/comparison.py) merges repeated
framework classifications for the same exact annotation byte span, then
preserves file, spelling, line, framework/resolved identity, and extract for
each unique trigger occurrence. [`compare_final_trigger_inventory`](../src/noir/comparison.py)
partitions those occurrences by exact source location. Supporting annotations
are excluded. An unmatched trigger means “Noir has no endpoint source location
at this annotation line,” not necessarily “Noir missed a reachable endpoint.”

The deterministic report summarizes total annotations, unique Noir locations,
exact matches, and unmatched occurrences. Its path follows the same final-suffix
rule:

```text
endpoints.csv       -> endpoints-anno-without-noir-endpoints.log
endpoints           -> endpoints-anno-without-noir-endpoints.log
endpoints.audit.csv -> endpoints.audit-anno-without-noir-endpoints.log
```

It is not created or removed when `--noir-report` is omitted.

## 12. Run-local diagnostics

[`noir.diagnostics`](../src/noir/diagnostics.py) captures diagnostics in memory.
It performs no artifact I/O.

Each CLI run creates a `DiagnosticCollector` with an injected clock and binds
it through a `ContextVar`. Nested scopes restore the previous collector;
collectors protect their own entry lists. An immutable `DiagnosticEntry`
contains a timestamp and `AnalysisDiagnostic`. Its rendered line is:

```text
YYYY-MM-DD HH:MM:SS message
```

The module function `record(message) -> None` captures when a collector is
bound and otherwise performs a harmless no-op. Direct pure analyzer calls are
therefore file-free. [`noir.application.analyze`](../src/noir/application.py)
attaches only diagnostics added during that invocation to the immutable
`AnalysisResult`; the CLI uses the same collector's `rendered_lines` for the
broad log.

## 13. Exact CSV bytes

[`write_endpoint_csv`](../src/noir/output.py) opens with `utf-8-sig` and
`newline=""`, then uses `csv.DictWriter` with `CSV_FIELDS` and semicolon
delimiter. The observable contract is:

- UTF-8 BOM (`EF BB BF`);
- exactly seven header columns in documented order;
- semicolon separators;
- normal CSV quoting for delimiters, quotes, and newlines;
- CRLF (`\r\n`) records; and
- a header even when there are no rows.

The writer copies and stringifies requested cells, ignores unknown presentation
keys, and does not mutate consolidated rows.

## 14. CLI publication order and failures

The CLI is an ordered multi-artifact operation, not one atomic transaction.
Optional Noir input validation is a pre-publication gate.

```mermaid
flowchart TD
    Validate["validate input and optional Noir report"] --> LogInit["create/truncate broad log"]
    LogInit --> Analyze["analyze with bound collector"]
    Analyze --> Memory["project, consolidate, render reports and summary"]
    Memory --> CSV["write CSV directly"]
    CSV --> Broad["write broad log directly"]
    Broad --> Absent["atomically replace absent-trigger report"]
    Absent --> Optional{"comparison enabled?"}
    Optional -->|yes| Comparison["atomically replace comparison report"]
    Optional -->|no| Print["print completion summary"]
    Comparison --> Print
```

The broad log is initialized after path/input validation. CSV and broad log are
direct writes and may reflect a failed current run. On failure, the CLI makes a
best-effort broad-log rewrite without masking the original error. A controlled
Tree-sitter `RuntimeError` records `ERROR: ...`, writes the log, and exits via
the argument-parser error path before CSV/report publication.

[`publish_bytes_atomically`](../src/noir/reports.py) handles each byte report:

1. create a sibling temporary file;
2. write the complete in-memory payload;
3. flush and `fsync`;
4. close; and
5. replace with `os.replace`.

Write, flush, sync, close, replace, and interruption failures clean staging
state when possible and preserve that artifact's prior completed destination.
Earlier successful artifacts are not rolled back. If comparison publication
fails, current CSV/log/absent output remains while the prior comparison report
survives.

The output parent must already exist. Completion text is printed once and only
after every requested artifact publishes. Framework `Found ...` announcements
precede it. Any failure suppresses the `noir-ts analysis completed.` block.

## 15. Reading the artifacts together

1. Verify CSV header, module, and interface families.
2. Distinguish server, client, gateway, static, handshake, and message rows.
3. Read a blank annotation line as “no owned selectable evidence.”
4. Review every nonempty absent-trigger section.
5. In comparison mode, review every unmatched potential endpoint trigger while
   remembering that absence at its source line does not prove a reachable
   endpoint was missed.
6. Search the broad log for errors, skipped candidates, unresolved identity,
   ambiguity, and configuration decisions.
7. Account for publication order when artifacts appear to come from different
   run states.
8. Reconcile static facts with runtime inventories for dynamic,
   dependency-defined, or reflective routes.

`EndpointFact` answers what analysis knows. The CSV answers what presentation
keeps. Typed evidence and companion reports explain the difference.

Next: [08 — Worked traces](08-worked-traces.md).
