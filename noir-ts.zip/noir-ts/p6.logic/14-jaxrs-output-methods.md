# 14 — JAX-RS to artifacts: method-level logic atlas

[← Spring methods](13-spring-methods.md) · [Index](README.md) ·
[Method lookup →](15-method-lookup.md)

This chapter supplements the module-level views in
[06 — JAX-RS and Java WebSocket](06-jax-rs.md) and
[07 — Output, evidence, and reports](07-output-evidence-reports.md). It follows
the current implementation from the JAX-RS/WebSocket passes down to individual
decision methods, then follows their data through evidence validation,
consolidation, CSV/log rendering, and optional Noir comparison.

The source is authoritative. A coordinate such as
[`src/noir/jaxrs.py`](../src/noir/jaxrs.py) ::
`resolve_jax_rs_request_designator()` means: open that file and search for that
exact symbol. Private helpers are included when they own an ambiguity rule,
failure boundary, fact/evidence construction, recursion, validation, or
publication decision.

## 1. Top-down call graph

The requested modules do not own the outermost orchestration. Their callers in
`noir.pipeline` and `noir.cli` are shown so the entry and exit edges are not
hidden.

```mermaid
flowchart TD
    CLI["cli.run_cli"] --> APP["application.analyze"]
    APP --> RUN["pipeline.run_analysis"]
    RUN --> WS["build shared Java workspace"]
    RUN --> REG["frameworks registry"]
    REG --> CONF["jaxrs_framework.configure_jaxrs_workspace"]
    WS --> CONF
    CONF --> JI["jaxrs.attach_workspace_indexes"]
    JI --> CDI["index_jax_rs_custom_designators"]
    JI --> API["index_jax_rs_application_paths"]

    RUN --> BROAD["inventory.build_annotation_audit_inventory"]
    RUN -->|"at least one family selected"| TRIG["inventory.build_final_trigger_inventory"]
    RUN -->|"prepare selected adapters"| PREP["jaxrs_framework.prepare_jaxrs_analysis"]
    PREP --> DEP["jaxrs_deployment.build_jax_rs_deployment_model"]

    RUN -->|"analyze selected adapters"| JPASS["jaxrs_framework.analyze_jaxrs_framework"]
    JPASS --> DIRECT["jaxrs.analyze_direct_jax_rs_unit<br/>once per unit"]
    JPASS --> HIER["jaxrs_hierarchy.analyze_jax_rs_hierarchy_and_subresources<br/>once per workspace"]
    JPASS --> SOCK["java_websocket.analyze_java_websocket_endpoints<br/>once per workspace"]
    DIRECT --> FACT["EndpointFact"]
    HIER --> FACT
    SOCK --> FACT

    FACT --> RESULT["AnalysisResult.endpoints"]
    RESULT --> PROJECT["output.endpoint_fact_to_row_candidate<br/>one per fact"]
    PROJECT --> CAND["EndpointRowCandidate"]
    CAND --> CONS["output.consolidate_endpoint_rows"]
    CONS --> FINAL["ConsolidatedEndpoints"]

    FINAL --> CSV["output.write_endpoint_csv"]
    BROAD --> LOG["reports.write_annotation_diagnostic_log"]
    DIAG["bound DiagnosticCollector rendered lines"] --> LOG
    TRIG --> ABSENT["reports.render_annotations_without_endpoints_report_bytes"]
    FINAL -->|"represented_targets"| ABSENT
    TRIG -->|"comparison enabled"| COMP["comparison.compare_final_trigger_inventory"]
    NOIR["Noir v1.1 JSON locations"] --> COMP
    COMP --> CRENDER["comparison.render_noir_comparison_report_bytes"]
    ABSENT --> APUB["reports.publish_bytes_atomically"]
    CRENDER --> CPUB["reports.publish_bytes_atomically"]
```

Ordering inside `pipeline.run_analysis()` matters:

1. The shared workspace is built, then every adapter configures its selected
   or unselected workspace shape; selected JAX-RS attaches its indexes.
2. The annotation-audit inventory is always built before endpoint analyzers.
   The final-trigger inventory is also built then when at least one framework
   family is selected; with no selected family it is the empty tuple. Both
   describe source evidence, not analyzer success.
3. Every selected adapter prepares before any selected analyzer runs. The
   JAX-RS preparation hook attaches its deployment model in this phase.
4. Direct JAX-RS facts are collected in source-snapshot order; hierarchy facts
   and WebSocket facts are then appended once each.
5. `AnalysisResult` crosses into the CLI, where all facts are projected and
   globally consolidated before an artifact is opened for endpoint output.

## 2. Data contracts carried across the graph

| Value | Created by | Consumed by | Contract that matters downstream |
|---|---|---|---|
| shared `workspace` mapping | `java_workspace.build_java_workspace()` plus index attachers | inventories and every analyzer | Compilation units are reused; JAX keys are attached once and are not rebuilt per unit. |
| `jax_rs_custom_designators` | `index_jax_rs_custom_designators()` | direct/hierarchy designator resolution and inventories | Declaration-shaped runtime records are retained by FQN; duplicate declarations remain multiple records so use-site resolution can reject them. |
| `jax_rs_applications` | `index_jax_rs_application_paths()` | deployment builder and the non-model fallback selector | A record can deliberately carry `path=None`, preserving ambiguity. |
| `jax_rs_deployment_model` | `build_jax_rs_deployment_model()` | `resolve_jax_rs_resource_prefix()` | Prefixes are keyed by project, application package, and Javax/Jakarta namespace. |
| broad annotation inventory | `build_annotation_audit_inventory()` | annotation and diagnostics log | Includes supported framework annotations even when they are not endpoint triggers. |
| final-trigger inventory | `build_final_trigger_inventory()` | annotations-without-endpoints report and optional Noir comparison | Includes only supported trigger placements and carries exact `SourceTarget` identity plus annotation byte spans. |
| `EndpointFact` | direct, hierarchy, WebSocket, and other analyzers | `endpoint_fact_to_row_candidate()` | Rich immutable fact; scalar route data and two typed provenance collections stay separate. |
| `AnnotationEvidence` | `make_method_annotation_evidence()` and node/mapping helpers | evidence merge and seventh-column selection | Same-file, positive-line, canonical annotation identity with a trusted family. |
| `SourceTarget` | `make_source_target()` and its node helper | evidence merge and annotations-without-endpoints subtraction | Canonical file + declaration kind + nonempty half-open byte span. |
| `EndpointRowCandidate` | `endpoint_fact_to_row_candidate()` | `consolidate_endpoint_rows()` | Six public identity values plus private owned evidence. |
| `ConsolidatedEndpoints` | `consolidate_endpoint_rows()` | CSV writer and annotations-without-endpoints renderer | Frozen public rows plus the union of targets represented by surviving groups. |
| `AnnotationComparison` | `compare_final_trigger_inventory()` | comparison report renderer | Exact partition of potential trigger occurrences by canonical `(source file, line)`, not endpoint reachability. |

Two evidence streams intentionally travel side by side:

```mermaid
flowchart LR
    A["request-method annotation node"] --> ME["AnnotationEvidence<br/>file + line + identity + family"]
    D["represented Java declaration node"] --> ST["SourceTarget<br/>file + kind + byte span"]
    ME --> EF["EndpointFact"]
    ST --> EF
    EF --> RC["EndpointRowCandidate"]
    RC --> GROUP["six-field consolidation"]
    GROUP --> PICK["select_method_annotation_evidence"]
    PICK --> LINE["method_annotation_line"]
    GROUP --> UNION["merge_represented_targets"]
    UNION --> SUB["subtract from final-trigger inventory"]
```

`source_line` on `EndpointFact` is diagnostic context. It is not automatically
the CSV annotation line. Likewise, an annotation line is not a declaration
identity and cannot suppress an entry in the annotations-without-endpoints
report.

## 3. Direct JAX-RS methods

Owner: [`src/noir/jaxrs.py`](../src/noir/jaxrs.py).

### 3.1 Index preparation

```mermaid
flowchart TD
    ATTACH["attach_workspace_indexes"] --> CUSTOM["index_jax_rs_custom_designators"]
    ATTACH --> APPS["index_jax_rs_application_paths"]
    CUSTOM --> DHTTP["decode_custom_http_method"]
    CUSTOM --> RUNTIME["retention_is_runtime"]
    APPS --> NS["resolve_direct_jax_rs_application_namespace"]
    APPS --> PATH["decode_jax_rs_path_annotation"]
    DISABLED["clear_workspace_indexes"] --> EMPTY["empty JAX keys"]
```

`attach_workspace_indexes(workspace)` is the enabled-branch entry point. It mutates
only the supplied workspace by attaching custom-designator and application
indexes. `clear_workspace_indexes(workspace)` installs the same key shape with
empty values when JAX-RS is disabled; consumers therefore do not need
missing-key branches.

`index_jax_rs_custom_designators(workspace)` walks metadata candidates for
source annotation declarations. It first records every relevant source FQN in
`jax_rs_custom_designator_candidates`; that poison set lets an invalid or
ambiguous declaration remain relevant when later applied. A valid record is
added to `jax_rs_custom_designators` only after exactly one genuine
`@HttpMethod`, exactly one runtime `@Retention`, a statically resolved value,
the 128-character bound, and `HTTP_METHOD_TOKEN` all pass.

`index_jax_rs_application_paths(workspace)` walks class declarations carrying
genuine `@ApplicationPath`. Abstract classes are omitted. Multiple genuine
annotations are diagnosed and retained as one `path=None` record per genuine
annotation, carrying that annotation's namespace, without using superclass
identity to choose among them. With exactly one
annotation, the class must be a matching direct core `Application` subclass;
mismatched and indirect shapes are omitted. An unresolved value on that valid
shape produces `path=None`, preventing a later selector from treating
uncertainty as absence.

### 3.2 One direct unit

```mermaid
flowchart TD
    ENTRY["analyze_direct_jax_rs_unit(unit, workspace)"] --> ROOTS["resolve_jax_rs_resource_root<br/>for visible concrete classes/records"]
    ROOTS --> METHODS["iterate method_candidates"]
    METHODS --> DES["resolve_jax_rs_request_designator"]
    DES --> PUB["method_is_public"]
    PUB --> MPATH["resolve_jax_rs_method_path"]
    MPATH --> PREFIX["resolve_jax_rs_resource_prefix"]
    PREFIX --> JOIN["join deployment + root + method paths"]
    JOIN --> EVID["method_annotation_evidence_from_node<br/>represented_target_evidence"]
    EVID --> FACT["EndpointFact + diagnostic"]

    ROOTS --> COMPONENTS["iterate record_component_candidates"]
    COMPONENTS --> SELECT["select_jax_rs_accessor_annotations"]
    SELECT --> DES
    COMPONENTS --> EXPLICIT["skip explicit accessor"]
```

The entry point has two loops:

- A declared-method loop requires one designator, explicit `public`, an
  optional valid same-family method path, and one deployment-prefix decision.
  It emits method annotation evidence and a represented method target.
- A record-component loop models an implicit zero-argument accessor only when
  no explicit accessor shadows it. Method-applicable component annotations
  participate. It emits a represented record-component target, but no method
  annotation evidence because the annotation is not physically on a method.

Every successful fact is `technology="jax-rs"`, `direction="inbound"`; HTTP
server values come from `EndpointFact` defaults. The handler and public source
belong to the concrete method/accessor. The function returns an immutable
tuple and records one endpoint diagnostic per emitted fact.

### 3.3 Direct-method symbol contracts

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `log_jax_rs_skip()` | Formats one owner-scoped fail-closed diagnostic and delegates to the run-bound diagnostic collector. It does not raise or write a file. |
| `decode_jax_rs_path_annotation()` | Accepts one already-proven `Path`-family record, enforces the single-value shape, resolves a Java string in the correct constant owner, and returns a leading-slash layer. Returns `None` and diagnoses malformed/unresolved values. |
| `resolve_direct_jax_rs_application_namespace()` | Reads exactly one direct superclass and resolves the core `Application` type. Returns `jakarta.ws.rs`/`javax.ws.rs`, otherwise `None`. |
| `decode_custom_http_method()` | Resolves a custom `@HttpMethod` value, including bounded static constants; returns the token only if it is at most 128 characters and matches `HTTP_METHOD_TOKEN`. |
| `index_jax_rs_custom_designators()` | Mutates the workspace with the candidate poison set and the record index described above. Records are stored in per-FQN lists; use-site resolution requires one source declaration and one record, so duplicate FQNs fail closed. |
| `select_jax_rs_accessor_annotations()` | Filters record-component annotations to standard JAX route annotations or source annotations proven applicable to methods. |
| `resolve_custom_designator()` | Resolves an applied name against source candidates and accessibility. Returns a mapping whose `status` is exactly `none`, `resolved`, `invalid`, or `ambiguous`; only `resolved` carries a record. |
| `index_jax_rs_application_paths()` | Mutates `workspace["jax_rs_applications"]`; retains selected invalid path records to carry uncertainty into prefix selection. |
| `package_is_ancestor()` | Implements package ownership: empty ancestor, exact package, or dotted prefix. Used by the fallback selector when no deployment model is attached. |
| `package_specificity()` | Counts package segments so the fallback selector can keep the deepest owning application package. |
| `resolve_jax_rs_resource_prefix()` | Uses the attached deployment selector when present. Its fallback filters same-family applications, prefers most-specific package ownership, requires agreement, returns `""` for proven absence, and `None` for diagnosed ambiguity. |
| `method_is_public()` | Implements the direct-pass explicit-`public` gate from the method's modifiers; inherited implementation rules live elsewhere. |
| `resolve_jax_rs_resource_root()` | Requires exactly one genuine type `@Path`, decodes it, and returns `{path, namespace}`. No path means “not a root”; invalid or multiple path evidence is diagnosed and also returns `None`. |
| `resolve_jax_rs_request_designator()` | Scans all method/component records. It accepts at most one marker-shaped standard or valid source custom designator in the root namespace. Any relevant invalid/mixed designator poisons the whole selection; multiple valid designators also reject it. |
| `resolve_jax_rs_method_path()` | Returns `""` when absent, one decoded path when uniquely same-family, or `None` after ambiguity/mixed/value failure. |
| `analyze_direct_jax_rs_unit()` | Orchestrates both direct loops and is the only function in this module that constructs endpoint facts. |
| `attach_workspace_indexes()` | Enabled-branch index orchestration: custom designators first, application paths second. |
| `clear_workspace_indexes()` | Disabled-branch shape initialization; it performs no source analysis. |

## 4. Deployment-prefix methods

Owner: [`src/noir/jaxrs_deployment.py`](../src/noir/jaxrs_deployment.py).

### 4.1 Model construction and lookup

```mermaid
flowchart TD
    BUILD["build_jax_rs_deployment_model"] --> COALESCE["_coalesce_source_application_prefixes"]
    BUILD --> CLASSIDX["_index_source_applications_by_class_name"]
    BUILD --> DISCOVER["discover_web_xml_files"]
    DISCOVER --> PROJECT["infer_jax_rs_project_root"]
    BUILD --> PARSE["parse_jax_rs_web_xml_mappings"]
    PARSE --> PRED["servlet/application predicates"]
    BUILD --> KEYS["_resolve_mapping_application_keys"]
    BUILD --> NORMAL["normalize_servlet_mapping_prefix"]
    BUILD --> OVERLAY["explicit mappings override source paths"]
    OVERLAY --> MODEL["workspace.jax_rs_deployment_model"]
    MODEL --> SELECT["select_jax_rs_deployment_prefix"]
```

`build_jax_rs_deployment_model()` starts with indexed source applications,
coalesces each `(project root, package, namespace)` key, and then overlays
bounded `web.xml` mappings. Conflicting source paths or explicit mappings are
represented as `None`. A single unassociated recognizable servlet prefix can
fill source application keys in its project only when it is unambiguous and
no application key in that project is explicitly configured.

`select_jax_rs_deployment_prefix()` binds one resource unit to its inferred
project, compatible namespace, and ancestor application package. It keeps the
deepest package. At equal depth it prefers explicit XML evidence, otherwise an
exact namespace over namespace-neutral inference. One agreed non-null path is
returned; ambiguity returns `None` with a diagnostic. No matching candidate
normally returns `""`, with one tightly bounded nonstandard-layout fallback.

### 4.2 Deployment symbol contracts

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `_absolute_path()` | Anchors a relative descriptor/source path to the explicit analysis root and normalizes an absolute spelling. |
| `infer_jax_rs_project_root()` | Finds the ancestor immediately before a modeled `src/main/...` marker; otherwise returns the normalized analysis root. |
| `discover_web_xml_files()` | Deterministically walks the analysis root, prunes ignored and non-production source trees, and returns sorted regular nonsymlink `web.xml` files no larger than `MAX_WEB_XML_BYTES`. Filesystem probe failures omit candidates. |
| `_local_name()` | Removes XML namespace or prefix spelling before tag comparison. |
| `_children()` | Selects direct XML children by namespace-free local name. |
| `_child_text()` | Returns normalized text of the first matching direct child or `""`. |
| `is_jax_rs_servlet_class()` | Applies the bounded Jersey/RESTEasy/CXF/servlet-class spelling registry. It is evidence recognition, not general servlet inference. |
| `is_jax_rs_application_class_name()` | Recognizes core or application-like class spellings used by bounded descriptor association. |
| `infer_application_package_from_class_name()` | Returns a package only for a non-core, nonservlet application-like qualified class name. |
| `normalize_servlet_mapping_prefix()` | Removes trailing `/*` first, then a non-root trailing slash, and adds a leading slash when needed. Consequently literal `/` becomes `""`, while literal `/*` becomes `/`; this ordered rule is part of the current contract. |
| `parse_jax_rs_web_xml_mappings()` | Parses direct servlet declarations/init params and servlet mappings. Returns raw pattern/application-class/JAX-RS recognition records; malformed XML is raised to its caller. |
| `_application_key()` | Produces the source key `(project root, package, namespace)`. |
| `_has_project_marker()` | Determines whether a path itself contains any modeled standard-layout marker; used to guard the nonstandard fallback. |
| `_coalesce_source_application_prefixes()` | Groups indexed source applications and returns one path only when every member resolved and all agree; otherwise stores `None`. |
| `_index_source_applications_by_class_name()` | Maps both simple and FQN application names to sorted exact source keys. |
| `_resolve_mapping_application_keys()` | Prefers project-local exact source-class matches; otherwise derives project/package/namespace-neutral keys from dependency-like application names. |
| `build_jax_rs_deployment_model()` | Reads bounded descriptors, diagnoses unreadable/malformed XML, overlays prefixes, attaches and returns the deployment model. It does not create endpoints. |
| `_package_is_ancestor()` | Private typed equivalent of the JAX module package-ownership predicate. |
| `_package_specificity()` | Private typed package-depth ranker used by the model selector. |
| `select_jax_rs_deployment_prefix()` | Performs project/package/namespace/evidence-priority selection and distinguishes absent `""` from ambiguous `None`. |

Exported data contracts in this module are `PROJECT_MARKERS`,
`APPLICATION_INIT_PARAMS`, `CORE_APPLICATION_CLASSES`, and
`MAX_WEB_XML_BYTES`. Changing one changes discovery or descriptor proof scope,
not just presentation.

## 5. Hierarchy and subresource methods

Owner: [`src/noir/jaxrs_hierarchy.py`](../src/noir/jaxrs_hierarchy.py).
Framework-neutral inheritance, generic adaptation, erased signatures, and
maximally-specific interface selection are delegated to the superclass in
`noir.java_hierarchy`; the symbols below own the JAX-RS layer.

### 5.1 Effective-method and recursive-locator graph

```mermaid
flowchart TD
    WRAP["analyze_jax_rs_hierarchy_and_subresources"] --> INIT["JaxRsHierarchyAnalyzer.__init__"]
    INIT --> ROUTES["analyze_jax_rs_routes"]
    ROUTES --> ROOT["resolve_jax_rs_resource_root"]
    ROOT --> PREFIX["resolve_jax_rs_resource_prefix"]
    PREFIX --> WALK["_collect_subresource_endpoints"]

    WALK --> EFFECTIVE["_resolve_effective_jax_rs_methods"]
    EFFECTIVE --> SOURCE["_select_jax_rs_annotation_source"]
    SOURCE --> BIND["_decode_jax_rs_method_binding"]
    BIND --> CLASSIFY["_classify_jax_rs_annotation<br/>_standard_jax_annotation_family"]
    WALK --> IPATH["_resolve_interface_contract_path"]
    WALK --> LEAF{"leaf or locator?"}
    LEAF -->|leaf reached through hierarchy/locator| FACT["_build_recalled_endpoint"]
    LEAF -->|locator| TARGET["_resolve_subresource_target"]
    TARGET --> WALK
    ROUTES --> DEDUP["_deduplicate"]
```

`_resolve_effective_jax_rs_methods()` is the main binding method. It caches by
resource FQN, adapted type environment, and namespace. Direct public usable
methods survive an unrelated incomplete hierarchy when their own atomic
bundle is sufficient. Inherited additions require a complete bounded graph,
one erased signature, one implementation/default, and one atomic annotation
source. Its result pairs the concrete implementation with the declaration
that supplies route annotations.

`_collect_subresource_endpoints()` is branch-recursive. Its state contains the
concrete resource FQN and generic environment. It rejects repeated active
types, repeated locator edges, depth over `MAX_SUBRESOURCE_DEPTH`, states at
`MAX_SUBRESOURCE_STATES`, and composed paths over `MAX_COMPOSED_PATH`. A leaf
is added here only if it was reached through a locator or its binding was
introduced by hierarchy analysis; ordinary direct leaves remain owned by the
direct pass.

`_build_recalled_endpoint()` always attributes the fact and represented target
to the selected concrete implementation. It adds method annotation evidence
only when that same method declaration supplied the bundle. An interface or
superclass can prove a route without claiming a line in another file's CSV
row.

### 5.2 Hierarchy symbol contracts

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `SubresourceTypeState` | Frozen cycle identity: resource FQN plus a deterministic generic-environment key. |
| `JaxRsEffectiveMethod` | Mutable internal selection record pairing implementation, adapted environment, atomic annotation source, decoded binding, hierarchy-added flag, and erased signature. |
| `_deduplicate()` | Analyzer-local merge keyed by method, path, public source, handler, and parameters. It unions typed evidence through `deduplicate_endpoint_facts()`; public six-field consolidation still happens later. |
| `JaxRsHierarchyAnalyzer.__init__()` | Builds the neutral Java graph and creates the effective-method cache. |
| `JaxRsHierarchyAnalyzer._log_jax_rs_skip()` | Converts a Java method/type record into a diagnostic owner and delegates to `log_jax_rs_skip()`. |
| `JaxRsHierarchyAnalyzer._select_jax_rs_annotation_source()` | Selects an indivisible bundle: implementation first, then nearest eligible superclass, then one maximally specific interface origin. Ambiguity, blocked branches, or multiple source identities return `None`. |
| `JaxRsHierarchyAnalyzer._classify_jax_rs_annotation()` | Classifies supported standard JAX/core/container annotations, then source custom designators; returns a route name, `custom`, or `other`. |
| `JaxRsHierarchyAnalyzer._standard_jax_annotation_family()` | Resolves a genuine supported standard annotation to `jakarta.ws.rs` or `javax.ws.rs`; non-JAX evidence returns `None`. |
| `JaxRsHierarchyAnalyzer._decode_jax_rs_method_binding()` | Validates the atomic bundle's single family, designator, and path. Returns a `leaf` binding, a nonempty-path `locator` binding, or `None`. |
| `JaxRsHierarchyAnalyzer._resolve_interface_contract_path()` | Adds one direct type-level path only when the selected annotation source is an interface and the endpoint is hierarchy-added. Missing is `""`; invalid/mixed is diagnosed `None`. |
| `JaxRsHierarchyAnalyzer._resolve_effective_jax_rs_methods()` | Selects and caches concrete implementation/bundle pairs, with direct-method survival and stricter inherited completeness as described above. |
| nested `collect_interface_signatures()` | Recursively adds erased signatures from bounded reachable interface states to `_resolve_effective_jax_rs_methods()`; it stops on the shared depth bound or a cycle. |
| `JaxRsHierarchyAnalyzer._resolve_subresource_target()` | Substitutes the implementation's return type, unwraps `Class<T>`, and requires one concrete source class/record. It returns the type plus exact/default generic environment or `None`. |
| `JaxRsHierarchyAnalyzer._build_recalled_endpoint()` | Constructs one hierarchy/locator HTTP `EndpointFact`, owned by the implementation, with same-declaration-only annotation evidence and exact represented method target. |
| `JaxRsHierarchyAnalyzer._collect_subresource_endpoints()` | Performs bounded branch-recursive traversal with branch-local cycle sets and a root-shared state budget, emits additive leaves, diagnoses locator failures, and recursively follows valid target states. |
| `JaxRsHierarchyAnalyzer.analyze_jax_rs_routes()` | Finds each proven root, selects its deployment prefix, traverses from the default type environment, and returns deterministic analyzer-local deduplicated additions. |
| `analyze_jax_rs_hierarchy_and_subresources()` | Public one-call wrapper that creates a fresh analyzer and returns only hierarchy/subresource additions. |

The module-level proof bounds are `MAX_SUBRESOURCE_DEPTH = 16`,
`MAX_SUBRESOURCE_STATES = 4096`, and `MAX_COMPOSED_PATH = 8192`. They bound a
root traversal; exceeding a bound suppresses the affected branch/root work,
not already proven direct facts.

## 6. Java WebSocket methods

Owner: [`src/noir/java_websocket.py`](../src/noir/java_websocket.py).

```mermaid
flowchart TD
    ENTRY["analyze_java_websocket_endpoints"] --> ANN["_resolve_server_endpoint_annotation"]
    ANN --> UNIQUE["unique workspace type identity"]
    UNIQUE --> TYPE["_endpoint_type_rejection_reason"]
    TYPE --> VALUE["_extract_server_endpoint_path_node"]
    VALUE --> CONST["resolve_workspace_string_expression"]
    CONST --> TARGET["represented_target_evidence(type)"]
    TARGET --> FACT["GET ws/websocket EndpointFact"]
```

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `JAVA_WEBSOCKET_SERVER_ENDPOINT_PACKAGES` | The exact Jakarta/Javax provenance registry for `ServerEndpoint`. |
| `_log_websocket_skip()` | Records a type-scoped rejection without writing files or raising. |
| `_declared_constructors()` | Returns explicit constructors from the type body; a missing body/constructors yields an empty list. |
| `_has_public_zero_arg_constructor()` | Treats no explicit constructor as the implicit usable constructor; otherwise requires at least one explicit public zero-argument constructor. |
| `_record_has_no_components()` | Proves the record's canonical constructor has zero components. |
| `_endpoint_type_rejection_reason()` | Returns the first visibility, enclosing visibility, type-kind, abstractness, static-nesting, or construction rejection; returns `None` when viable. |
| `_resolve_server_endpoint_annotation()` | Returns one genuine annotation record enriched with resolved namespace/name, no-candidate `(None, None)`, or an ambiguity error. |
| `_extract_server_endpoint_path_node()` | Accepts exactly one positional value or named `value`, ignores unrelated options, and returns a node/error pair. |
| `analyze_java_websocket_endpoints()` | Walks deterministic units/types, requires unique source identity and viable construction, resolves a nonempty query/fragment-free path, and emits a `GET`, `ws`, `websocket`, inbound `EndpointFact`. It represents the annotated type and deliberately emits no method annotation evidence. |

No JAX-RS deployment prefix is consulted for WebSocket handshakes. The exact
path is slash-prefixed, but it remains otherwise independent of HTTP resource
composition.

## 7. Annotation inventory methods

Owner: [`src/noir/inventory.py`](../src/noir/inventory.py).

The broad audit and final-trigger inventory answer different questions and
must not be derived from each other.

```mermaid
flowchart LR
    OCC["unit.annotation_occurrences"] --> BROAD["build_annotation_audit_inventory"]
    BROAD --> AFC["annotation_framework_classifications"]
    AFC --> REG["registered_annotation_classifications"]
    AFC --> SRC["source_defined_annotation_classifications"]
    AFC --> META["contextual_metadata_classifications"]
    BROAD --> ROWEX["annotation_source_extract"]
    ROWEX --> BI["broad per-file inventory"]

    OCC --> FINAL["build_final_trigger_inventory"]
    FINAL --> TARGET["discover_applied_annotation_target"]
    TARGET --> PLACE["final_trigger_placement_supported"]
    FINAL --> FTC["final_trigger_classifications"]
    FTC --> DIR["direct_final_trigger_classifications"]
    FTC --> SDEF["source_defined_final_trigger_classifications"]
    FINAL --> PHY["java_physical_source_lines<br/>annotation_physical_source_extract"]
    FINAL --> FI["narrow per-file/per-framework inventory"]
```

### 7.1 Broad-audit lane

`build_annotation_audit_inventory()` emits one file record for every parsed
unit, including files with no classified annotations. For every occurrence it
merges three independent provenance lanes:

- `registered_annotation_classifications()` proves exact built-in framework
  identities while refusing to let a same-FQN source declaration masquerade
  as a dependency annotation.
- `source_defined_annotation_classifications()` recognizes supported Spring
  composed annotations and valid JAX-RS custom designators from attached
  source indexes.
- `contextual_metadata_classifications()` includes `@Retention`, `@Target`, or
  Spring `@AliasFor` only when the occurrence belongs to a validated
  source-defined route annotation.

Occurrences are unique by their Tree-sitter node key and sorted in source
order. The extract uses Tree-sitter rows plus up to ten following nonempty
lines. This inventory feeds only the human annotation and diagnostics log; it
does not claim that an endpoint exists.

### 7.2 Final-trigger lane

`build_final_trigger_inventory()` accepts only annotations applied directly to
a stable method, record component, or named type and only at a placement the
corresponding analyzer supports. Each candidate includes its canonical
`SourceTarget`, resolved identity/family, byte span, human target label, and a
byte-aligned extract. Within one selected framework, an occurrence resolving
to multiple identities is omitted rather than guessed.

This inventory is built before endpoint analysis. Later,
`render_annotations_without_endpoints_report_bytes()` subtracts the exact
targets unioned from surviving consolidated rows. Thus a rejected trigger
remains visible; a trigger covered by any duplicate fact in the surviving
public group is removed. The optional Noir comparison consumes the same
inventory but compares each trigger's canonical source file and start line
against Noir rather than subtracting noir-ts declaration targets.

### 7.3 Inventory symbol contracts

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `SUPPORTED_ANNOTATION_REGISTRY` | Broad built-in framework provenance and audit-role registry. |
| `FINAL_TRIGGER_ANNOTATION_REGISTRY` | Immutable narrow trigger registry with supported placement and evidence family per identity. |
| `annotation_owner_name()` | Finds the nearest named type display owner for source-definition resolution; missing owner becomes `""`. |
| `registered_annotation_classifications()` | Returns exact built-in `{framework, resolved}` classifications for selected families, unless analyzed source owns the expected FQN. |
| `source_definition_for_annotation_metadata()` | Finds the unique neutral source annotation definition enclosing one metadata occurrence. |
| `source_defined_annotation_classifications()` | Returns supported composed/custom source identities using neutral definitions and framework-specific validation indexes. |
| `contextual_metadata_classifications()` | Attributes Java/Spring definition metadata only when it belongs to a validated selected-framework definition. |
| `annotation_framework_classifications()` | Concatenates all broad lanes, deduplicates by `(framework, resolved)`, and returns deterministic order. |
| `_annotation_source_extract_from_rows()` | Builds an annotation row span plus a bounded number of following nonempty rows. |
| `annotation_source_extract()` | Converts Tree-sitter point rows to a broad-audit extract, correcting an exclusive zero-column end row. |
| `java_physical_source_lines()` | Splits bytes only on LF/CRLF/CR and returns exact byte starts plus decoded lines for target-aligned reporting. |
| `annotation_physical_source_extract()` | Maps annotation byte bounds into the physical-line model and delegates extract rendering; malformed spans return an empty extract. |
| `_record_component_name_node()` | Recovers ordinary or varargs record-component names. |
| `discover_applied_annotation_target()` | Returns exact method, record-component, or named-type declaration metadata. Anonymous/recovered/unsupported shapes fail closed with `None`. |
| `normalize_applied_to_parameters()` | Removes parentheses and collapses Java whitespace for a stable human method label; it is not target identity. |
| `applied_annotation_target_label()` | Renders `method Owner.name(params)`, `record component Owner.name`, or `type Owner`; missing stable ownership returns `None`. |
| `final_trigger_placement_supported()` | Encodes which declaration kinds each final-trigger analyzer supports. |
| `direct_final_trigger_classifications()` | Classifies exact built-in triggers at supported placements and rejects source-shadowed dependency identities. |
| `source_defined_final_trigger_classifications()` | Classifies validated Spring composed or JAX custom triggers, including method-applicability checks for record components. |
| `final_trigger_classifications()` | Merges direct/source lanes by `(framework, resolved)` in deterministic order. |
| `build_final_trigger_inventory()` | Builds the narrow per-file/per-framework inventory with exact targets and byte-aligned extracts. |
| `build_annotation_audit_inventory()` | Builds the broad per-file audit inventory with all selected-framework occurrence classifications. |

## 8. Evidence methods

Owner: [`src/noir/evidence.py`](../src/noir/evidence.py).

Evidence validation is deliberately centralized. Analyzer code can propose a
line or declaration, but these methods decide whether it crosses the typed
boundary.

### 8.1 Construction, ownership, merge, selection

```mermaid
flowchart TD
    NODE["Tree-sitter annotation node"] --> MEN["method_annotation_evidence_from_node"]
    MAP["decoded mapping"] --> MEM["method_annotation_evidence_from_mapping"]
    MEN --> MAKE["make_method_annotation_evidence"]
    MEM --> MEN
    MAKE --> FAM["method_annotation_family"]
    MAKE --> CANON["canonical_source_file_name"]
    MAKE --> AE["AnnotationEvidence or None"]

    DECL["declaration node"] --> RTE["represented_target_evidence"]
    RTE --> STN["source_target_from_node"]
    STN --> MST["make_source_target"]
    MST --> ST["SourceTarget or None"]

    AE --> MERGEA["merge_method_annotation_evidence"]
    ST --> MERGET["merge_represented_targets"]
    MERGEA --> FACTMERGE["merge_endpoint_facts / deduplicate_endpoint_facts"]
    MERGET --> FACTMERGE
    FACTMERGE --> OWN["owned_method_annotation_evidence<br/>owned_represented_targets"]
    OWN --> SELECT["select_method_annotation_evidence"]
```

The annotation selection key is:

```text
(METHOD_ANNOTATION_FAMILY_PRIORITY[family], line, identity)
```

It is applied only after evidence from all candidates in one public six-field
group has merged. The earliest line globally is therefore not necessarily the
winner.

### 8.2 Evidence symbol contracts

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `EndpointIdentity` | Type alias for an analyzer-supplied callable returning a tuple identity for local deduplication. |
| `_java_identifier_start()` | Implements accepted Unicode categories plus `_`/`$` for the first Java identifier character. |
| `_java_identifier_part()` | Extends start characters with Java combining, decimal, and formatting categories. |
| `_is_canonical_annotation_identity()` | Requires a dotted sequence of complete Java identifiers; simple identities are valid, partial dotted segments are not. |
| `canonical_source_file_name()` | Converts usable path-like input to absolute real, normalized-case identity; unusable input returns `None`. It does not require the file to exist. |
| `make_source_target()` | Validates canonical source, supported kind, integer nonboolean bounds, and `0 <= start < end`; returns typed target or `None`. |
| `source_target_from_node()` | Reads byte bounds from a parser node and delegates target validation. |
| `represented_target_evidence()` | Converts a node to the zero-or-one tuple expected by `EndpointFact`. |
| `_canonical_source_target()` | Type-checks and revalidates an existing `SourceTarget`; malformed typed fields may be dropped, wrong collection element types raise. |
| `merge_represented_targets()` | Rejects mapping/string containers, canonicalizes, unions by `(file, kind, start, end)`, and returns sorted typed targets. |
| `method_annotation_family()` | Enforces the fixed family for built-ins. Source-defined identities may use only a family present in the priority registry; contradictions return `None`. |
| `make_method_annotation_evidence()` | Requires a positive nonboolean line, canonical identity, trusted family, and equal canonical annotation/endpoint files. Returns typed evidence or `None`. |
| `method_annotation_evidence_from_node()` | Reads a one-based start row and produces a zero-or-one evidence tuple. |
| `method_annotation_evidence_from_mapping()` | Adapts an analyzer-local mapping containing node/identity/family; non-mappings return an empty tuple. |
| `merge_method_annotation_evidence()` | Type-checks, revalidates, deduplicates by family/line/identity/file, and returns deterministic evidence order. |
| `merge_endpoint_facts()` | Keeps the candidate fact's scalar fields while unioning current and candidate evidence/targets into a replaced immutable fact. |
| `deduplicate_endpoint_facts()` | Requires `EndpointFact` elements and a tuple-producing identity callback; sorted local keys determine output order and duplicate facts merge evidence. |
| `owned_method_annotation_evidence()` | Revalidates and retains only evidence whose canonical file equals the endpoint's public source file. |
| `owned_represented_targets()` | Revalidates and retains only represented declarations in the endpoint's public source file. |
| `select_method_annotation_evidence()` | Returns the minimum family-priority/line/identity candidate or `None`. |

## 9. Output projection and consolidation methods

Owner: [`src/noir/output.py`](../src/noir/output.py).

### 9.1 Lossy projection and authoritative grouping

```mermaid
flowchart TD
    FACT["EndpointFact"] --> PROJ["endpoint_fact_to_row_candidate"]
    PROJ --> OWN1["owned_method_annotation_evidence"]
    PROJ --> OWN2["owned_represented_targets"]
    PROJ --> CAND["EndpointRowCandidate"]
    CAND --> CONS["consolidate_endpoint_rows"]
    CONS --> STR["stringify_output_value"]
    CONS --> NORM["normalize_endpoint_path"]
    NORM --> SPR["normalize_spring_regex_templates"]
    CONS --> KEY["six-field tuple key"]
    KEY --> EM["merge evidence and targets"]
    EM --> PICK["select_method_annotation_evidence"]
    PICK --> FINAL["ConsolidatedEndpoints"]
    FINAL --> CSV["write_endpoint_csv"]
```

`endpoint_fact_to_row_candidate()` is the explicit semantic compression
boundary. It maps protocol/surface to public `interface_type`, relativizes the
public source file, and drops rich route/configuration provenance that does not
fit the CSV. It preserves only owned typed evidence alongside the six public
values.

`consolidate_endpoint_rows()` stringifies the first six fields, normalizes the
endpoint according to the public protocol, and groups by exactly:

```text
(module_name, interface_type, endpoint,
 source_file_name, method_name, parameters)
```

Within each group it unions both evidence streams. Only then does it select
`method_annotation_line`. Sorted full keys make output independent of analyzer
iteration order. Its `represented_targets` result is the union across every
surviving group and every duplicate candidate, not merely one representative.

### 9.2 Output symbol contracts

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `EndpointRowCandidate` | Frozen six-field projection plus private typed annotation/target collections. |
| `EndpointRowCandidate.__post_init__()` | Copies both collections to tuples and rejects mappings or wrong element types. |
| `EndpointRowCandidate.public_identity()` | Returns a fresh six-field dictionary in contract order; callers cannot mutate the candidate through it. |
| `ConsolidatedEndpoints` | Frozen rows plus the represented-target union retained for companion reporting. |
| `ConsolidatedEndpoints.__post_init__()` | Copies/freezes each row, requires string keys/cells, and seals the typed target tuple. |
| `stringify_output_value()` | Maps `None` to empty, preserves scalar spelling, prefers Unicode JSON for structures, and finally uses `str()` for presentation robustness. |
| `endpoint_fact_to_row_candidate()` | Requires an `EndpointFact`, computes public interface/source values, and carries only same-public-file evidence. |
| `normalize_spring_regex_templates()` | Removes balanced `{name:regex}` constraints. Inside a recognized constraint it tracks escaped and nested braces so they do not close the template early; unsupported or unbalanced syntax is preserved rather than guessed. |
| `normalize_endpoint_path()` | Applies Spring-template and placeholder normalization, collapses repeated non-scheme slashes, and adds a leading slash only to relative HTTP paths. |
| `consolidate_endpoint_rows()` | Owns the exact public identity, evidence union, annotation-line choice, deterministic order, and surviving represented-target union. |
| `write_endpoint_csv()` | Directly overwrites the requested path using UTF-8 BOM, semicolon delimiter, `csv` quoting, and CRLF record endings. It copies only requested fields; it is not atomic. |

The public schema itself is owned by `contracts.CSV_FIELDS`, not repeated in
the writer.

## 10. Report rendering and publication methods

Owner: [`src/noir/reports.py`](../src/noir/reports.py).

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `annotation_inventory_lines()` | Presentation-only renderer for the broad audit inventory. It emits deterministic newline-free lines, explicit empty-file state, classifications, and extracts. |
| `write_annotation_diagnostic_log()` | Directly renders and overwrites the annotation and diagnostics log (`<output>.log`) in UTF-8. Layout is broad inventory, blank separator when needed, `Diagnostics:`, then already timestamp-rendered collector lines. It is not atomic. |
| `render_annotations_without_endpoints_report_bytes()` | Side-effect-free renderer. It canonicalizes the supplied target union, subtracts targets by exact equality, sorts files/frameworks/source spans, and returns UTF-8 bytes. Invalid target evidence cannot hide a trigger. |
| `derive_annotations_without_endpoints_report_path()` | Removes only the final output suffix, if any, and appends `-anno-without-endpoints.log`. |
| `publish_bytes_atomically()` | Creates a sibling temp file, writes, flushes, and fsyncs it, then `os.replace()`s one destination. Any `BaseException` triggers best-effort descriptor/temp cleanup and is re-raised unchanged. It gives one-file atomic replacement, not multi-artifact rollback or directory durability. |

The side-effect-free byte renderers consume normalized data and never reach
back into Java nodes or analyzers. The annotations-without-endpoints bytes,
optional comparison bytes, and completion text are prepared before publication
starts; the CSV and annotation and diagnostics log render during their direct
writes.

## 11. Noir comparison methods

Owner: [`src/noir/comparison.py`](../src/noir/comparison.py).

The comparison is between potential endpoint-trigger occurrences in the
final-trigger inventory and location-bearing
`endpoints[*].details.code_paths[*]` in a Noir v1.1 JSON object. Supporting
annotations from the broad audit are excluded. This is not a comparison of
URL/method endpoint identities, and an unmatched trigger does not by itself
prove that Noir missed a reachable endpoint.

```mermaid
flowchart TD
    JSON["Noir JSON path"] --> LOAD["load_noir_report_locations"]
    LOAD --> JPATH["_canonical_location_path<br/>allow retained root prefix"]
    LOAD --> LOC["frozenset SourceLocation"]
    INV["final-trigger inventory"] --> FLAT["flatten_final_trigger_inventory"]
    FLAT --> IPATH["_canonical_location_path<br/>directly root-relative"]
    FLAT --> ITEMS["sorted AnnotationAuditItem occurrences"]
    LOC --> CMP["compare_final_trigger_inventory"]
    ITEMS --> CMP
    CMP --> PART["matched / missing exact locations"]
    PART --> RENDER["render_noir_comparison_report_bytes"]
```

### 11.1 Comparison symbol contracts

| Exact symbol | Role, result, and failure behavior |
|---|---|
| `NoirReportValidationError` | Public `ValueError` subtype for malformed JSON or unsupported Noir structure/path/line values. |
| `SourceLocation` | Ordered canonical source-file and positive one-based line pair. |
| `AnnotationFramework` | Ordered retained `{framework, resolved}` classification. |
| `SourceExtractLine` | Ordered retained physical line and source text. |
| `AnnotationAuditItem` | One flattened annotation occurrence with display data and canonical match location. Generated comparison reports populate it from the final-trigger inventory. |
| `AnnotationComparison` | Deterministic full/matched/missing partitions, sorted unique Noir locations, and an input-scope discriminator. |
| `AnnotationComparison.total_count` | Number of flattened annotation occurrences in the supplied comparison scope. |
| `AnnotationComparison.matched_count` | Number whose exact location is in the Noir location set. |
| `AnnotationComparison.missing_count` | Number outside that set. |
| `AnnotationComparison.trigger_only` | Distinguishes the CLI's final-trigger comparison from the retained neutral broad-inventory helper so report explanations remain truthful for both inputs. |
| `_sequence()` | Strictly requires a non-string sequence at a JSON coordinate; otherwise raises `NoirReportValidationError`. |
| `_mapping()` | Strictly requires an object/mapping at a JSON coordinate. |
| `_positive_line()` | Requires a positive nonboolean integer. Its message also describes nullable Noir locations because callers handle `null` before invoking it. |
| `_analysis_root_path()` | Resolves a usable analysis root and retains supplied/resolved basename candidates for Noir's optional retained-root spelling. |
| `_canonical_location_path()` | Resolves absolute/root-relative paths through the shared canonicalizer. For Noir inputs only, it disambiguates an optional root basename using file existence and fails closed when both interpretations exist. |
| `_load_json_object()` | Reads UTF-8 JSON with optional BOM and requires a top-level object; I/O errors propagate, shape/decode errors use `NoirReportValidationError`. |
| `load_noir_report_locations()` | Strictly validates endpoints/details/code_paths and every present path. Missing/null lines contribute no location; present lines are validated and canonical duplicates collapse. |
| `_inventory_sequence()` | Adapts structural sequence failures to `ValueError` for internal inventory validation. |
| `_inventory_mapping()` | Adapts structural mapping failures to `ValueError`. |
| `_inventory_text()` | Requires nonempty text unless `allow_empty=True`, used for source extract content. |
| `_inventory_line()` | Requires a positive inventory line and adapts the error to `ValueError`. |
| `_inventory_byte_offset()` | Requires a nonnegative, nonboolean annotation byte offset and adapts failure to `ValueError`. |
| `_flatten_frameworks()` | Validates required fields, deduplicates typed classifications, and returns sorted values. |
| `_flatten_extract()` | Validates required line/source fields, deduplicates, and source-sorts extract lines. |
| `_annotation_sort_key()` | Defines deterministic occurrence order by display file, line, name, classifications, extract, and canonical location. |
| `flatten_annotation_audit_inventory()` | Retained neutral helper that validates and flattens broad-inventory records; generated Noir comparison reports do not call it. |
| `compare_annotation_audit_inventory()` | Retained neutral helper that partitions a supplied broad inventory; the CLI uses the final-trigger-specific entry point below. |
| `flatten_final_trigger_inventory()` | Validates final-trigger sections, canonicalizes file identity, merges cross-framework classifications by exact annotation byte span, and returns sorted typed occurrences. |
| `_compare_annotations()` | Type-checks supplied locations and partitions normalized items by exact `SourceLocation` equality. |
| `compare_final_trigger_inventory()` | Flattens the final-trigger inventory and delegates its exact-location partition. |
| `_render_annotation_item()` | Renders one missing annotation occurrence with all classifications and extract lines. |
| `render_noir_comparison_report_bytes()` | Type-checks the comparison and emits deterministic UTF-8 summary/detail bytes. Its support-annotation explanation follows `trigger_only`; generated CLI reports state that support annotations are excluded. |
| `derive_noir_comparison_report_path()` | Removes only the final output suffix and appends `-anno-without-noir-endpoints.log`. |

## 12. Shared declarative contracts

Owner: [`src/noir/contracts.py`](../src/noir/contracts.py). This module has no
methods; its exported constants are behavior shared by discovery, analyzers,
inventory, evidence, and output. Treat registry edits like code-path changes.

| Exact symbol | Consumers and meaning |
|---|---|
| `CSV_DELIMITER` | `write_endpoint_csv()`; fixed to semicolon. |
| `CSV_IDENTITY_FIELDS` | `consolidate_endpoint_rows()`; exact six-field grouping and ordering contract. |
| `METHOD_ANNOTATION_LINE_FIELD` | Consolidation; seventh field chosen after evidence merge. |
| `CSV_FIELDS` | CLI/writer; six identity fields followed by the annotation-line field. |
| `SOURCE_TARGET_KINDS` | Evidence validator; only `method`, `record-component`, and `type` are accepted. |
| `IGNORED_SOURCE_DIRECTORIES` | Java/marker discovery and `web.xml` discovery; one shared pruned-directory vocabulary. |
| `SPRING_MAPPING_PACKAGE` | Spring analyzer and both inventory registries; exact MVC provenance package. |
| `SPRING_ALIAS_FOR_PACKAGE` | Source-defined Spring metadata classification/decoding. |
| `SPRING_MAPPING_METHODS` | Immutable mapping from Spring mapping annotation name to fixed method or generic `None`. |
| `SPRING_HTTP_METHODS` | Bounded Spring HTTP enum/token vocabulary. |
| `SPRING_REQUEST_MAPPING_ATTRIBUTES` | Allowed modeled Spring mapping attributes. |
| `SPRING_MAX_COMPOSED_ANNOTATION_DEPTH` | Bound for source composed-annotation traversal. |
| `JAX_RS_PACKAGES` | Exact Jakarta/Javax JAX-RS annotation namespaces. |
| `JAX_RS_CORE_PACKAGES` | Exact matching core namespaces. |
| `JAX_RS_HTTP_METHODS` | Modeled standard request designators. |
| `JAX_RS_HTTP_METHOD_STATIC_CONSTANTS` | Immutable known `HttpMethod` constants for custom-token evaluation. |
| `HTTP_METHOD_TOKEN` | Full-match grammar for custom HTTP designator tokens. |
| `METHOD_ANNOTATION_FAMILY_SPRING_VERB` | Highest-priority Spring verb-specific evidence family. |
| `METHOD_ANNOTATION_FAMILY_SPRING_GENERIC` | Spring generic mapping/exchange evidence family. |
| `METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE` | Spring messaging evidence family. |
| `METHOD_ANNOTATION_FAMILY_JAX_RS` | JAX-RS request-designator evidence family. |
| `METHOD_ANNOTATION_FAMILY_PRIORITY` | Immutable family-to-rank table used by final line selection. |
| `METHOD_ANNOTATION_FAMILY_BY_IDENTITY` | Immutable built-in identity-to-family truth table; contradictory caller hints are rejected. |

## 13. Publication and failure boundaries

The CLI prepares values first and publishes artifacts in this exact order:

```mermaid
sequenceDiagram
    participant C as cli.run_cli
    participant N as optional Noir input
    participant A as analysis
    participant P as pure render/projection
    participant CSV as endpoint CSV
    participant LOG as annotation and diagnostics log
    participant ABS as annotations-without-endpoints report
    participant CMP as optional comparison report

    C->>N: validate and load before output initialization
    C->>LOG: direct truncate/create
    C->>A: analyze with bound collector
    A-->>C: AnalysisResult
    C->>P: project, consolidate, render byte reports and completion text
    C->>CSV: direct overwrite
    C->>LOG: direct overwrite
    C->>ABS: atomic one-file replace
    opt Noir comparison enabled
        C->>CMP: atomic one-file replace
    end
    C-->>C: print completion summary
```

Consequences a maintainer must preserve:

- An invalid optional Noir report is rejected before the run creates/truncates
  the annotation and diagnostics log or analyzes Java.
- The annotation and diagnostics log is deliberately created empty before
  controlled analysis starts. A `RuntimeError` from `analyze()`—or from the
  immediately following announcement loop, which shares its handler—writes the
  currently available inventory and diagnostics before CLI argument-style
  failure is reported. A later `RuntimeError` follows the outer exception path.
- Projection, consolidation, annotations-without-endpoints rendering, optional comparison, and
  completion-summary rendering finish before the endpoint CSV is opened.
- Writes of the CSV and the annotation and diagnostics log are direct
  overwrites. Each byte report is atomic only with respect to its own previous
  file.
- A later `Exception`-class publication failure does not roll back artifacts
  already written. The outer exception path makes a best-effort rewrite of the
  annotation and diagnostics log, then re-raises the original failure.
  `BaseException` subclasses outside `Exception` still receive atomic-writer
  cleanup but bypass that CLI recovery handler.
- Framework announcements can already have been printed after successful
  analysis. The `noir-ts analysis completed.` inventory is printed only after
  every requested publication succeeds.
- Analyzer diagnostics are collector events; only the CLI invokes
  `write_annotation_diagnostic_log()`. That renderer/writer owns annotation and
  diagnostics log persistence; analyzers, evidence helpers, and side-effect-free
  byte renderers do not persist it.

## 14. How to follow one endpoint end to end

For a direct `@GET` method, use this inspection order:

1. `analyze_direct_jax_rs_unit()` finds the root and calls
   `resolve_jax_rs_request_designator()`.
2. The designator result supplies HTTP method, annotation node, canonical
   identity, and evidence family.
3. `resolve_jax_rs_method_path()` and
   `resolve_jax_rs_resource_prefix()` supply the remaining path layers.
4. `method_annotation_evidence_from_node()` validates the annotation's
   same-file line evidence; `represented_target_evidence()` identifies the
   whole handler method by byte span.
5. `EndpointFact` enters `AnalysisResult.endpoints`.
6. `endpoint_fact_to_row_candidate()` relativizes public source identity and
   rechecks ownership of both evidence streams.
7. `consolidate_endpoint_rows()` normalizes the endpoint and merges every
   candidate with the same six public values.
8. `select_method_annotation_evidence()` chooses the seventh CSV value;
   `merge_represented_targets()` retains all declarations represented by the
   surviving group.
9. `write_endpoint_csv()` publishes the row. Independently,
   `render_annotations_without_endpoints_report_bytes()` removes the matching
   final-trigger candidate by exact target identity.

For a hierarchy leaf, replace step 1 with
`_resolve_effective_jax_rs_methods()` and `_collect_subresource_endpoints()`.
Check whether `annotation_source.id == implementation.id`: if not, the route
can exist while the public annotation line is blank. For a WebSocket endpoint,
the represented target is a type and annotation evidence is always empty.

## 15. Change-impact map

| If changing… | Follow these production owners… |
|---|---|
| custom designator, direct resource, application path | `noir.jaxrs` → evidence → output |
| project ownership, descriptor parse, deployment selection | `noir.jaxrs_deployment` → `jaxrs_framework.prepare_jaxrs_analysis` → hierarchy/direct selectors |
| inheritance, bundle selection, locator traversal | `noir.java_hierarchy` → `noir.jaxrs_hierarchy` → endpoint evidence |
| `ServerEndpoint` gates or fact shape | `noir.java_websocket` → model → output |
| broad/final inventory, target extraction | `noir.inventory` → `AnalysisResult` → report renderers |
| evidence validation/merge or public consolidation | `noir.evidence` → `noir.output` → report subtraction |
| report rendering/publication/failure behavior | `noir.reports` / `noir.comparison` → `noir.cli` |
| shared constants/registries | every analyzer, inventory, and output importer; these constants deliberately have multiple consumers |

When diagnosing a missing row, inspect the first method returning `None` on
the relevant call graph and then read its diagnostic boundary. When diagnosing
a blank `method_annotation_line`, start with evidence ownership rather than
route extraction. When diagnosing an annotations-without-endpoints entry,
compare the candidate `SourceTarget` with `ConsolidatedEndpoints` targets;
paths, handler names, and source lines are deliberately irrelevant to that
membership check.

Continue with [15 — Method lookup and reading strategy](15-method-lookup.md),
or return to the [guide index](README.md).
