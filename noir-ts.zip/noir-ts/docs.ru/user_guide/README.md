# Руководство пользователя noir-ts

Выполняйте команды настройки и анализа из корня checkout'а `noir-ts`.
Замените пути в примерах путями на вашем компьютере. Каталог, в котором будет
находиться `--output`, должен уже существовать.

## 1. Подготовьте runtime-окружение

Предполагается, что `uv` уже установлен и доступен через `PATH`. Приведённая
ниже команда создания virtual environment использует Python 3.13; если эта
версия ещё не установлена, `uv` может загрузить её. Для
сканирования существующего дерева исходного кода JDK и сборка Java не нужны.

### Windows (`cmd.exe`)

Откройте `cmd.exe` в checkout'е `noir-ts` и выполните:

```bat
uv venv --python 3.13 ".venv"
.venv\Scripts\activate.bat
uv pip install --system-certs --python ".venv\Scripts\python.exe" -r requirements.txt
python src\noir_sbt.py --help
```

### Linux (`bash`)

Откройте shell в checkout'е `noir-ts` и выполните:

```bash
uv venv --python 3.13 ".venv"
source ".venv/bin/activate"
uv pip install --system-certs --python ".venv/bin/python" -r requirements.txt
python src/noir_sbt.py --help
```

Два runtime-пакета с зафиксированными версиями устанавливаются из
`requirements.txt`. После изменения этого файла повторите команду
`uv pip install`.

## 2. Подготовьте входные данные

Для каждого анализа обязательны следующие два входных параметра:

- `--path <directory>`: существующий каталог исходного кода приложения.
  noir-ts рекурсивно ищет в нём имена файлов, оканчивающиеся на `.java`, без
  учёта регистра;
- `--output <file>`: destination-файл для endpoint CSV. Относительный путь
  отсчитывается от каталога, из которого запущена команда. Родительский каталог
  автоматически не создаётся.

Не сканируются файлы исходного кода, находящиеся внутри компонента пути с
именем `node_modules`, `.git`, `dist`, `build`, `target`, `__pycache__`, `.venv`,
`venv`, `.idea`, `.vscode`, `tmp`, `.next`, `out`, `vendor` или `test`.

При анализе также можно использовать следующие необязательные входные
параметры:

- один или несколько параметров `--framework <value>`, описанных в
  следующем разделе;
- `--noir-report <file>`: существующий JSON report, совместимый с Noir v1.1,
  для сравнения с аннотациями, найденными noir-ts.

Только в режиме `auto` также читаются файлы с точным именем `pom.xml` в нижнем
регистре — для поиска framework-marker'ов. Они являются input'ом для marker'ов,
а не source-файлами Java endpoint'ов.

Ниже перечислены все файлы в дереве исходного кода, которые могут повлиять на
запуск:

| Файлы внутри `--path` | Когда используются | Влияние |
|---|---|---|
| `*.java` (суффикс без учёта регистра) | при каждом запуске | input для endpoint'ов и аннотаций |
| `application.properties`, `application.yml` или `application.yaml` в определённом корне проекта, `resources/` или `src/main/resources/` | когда выбран Spring | placeholder'ы маршрутов и настроенные base paths |
| обычные `web.xml`, не являющиеся symlink, размером до 10 MiB, кроме находящихся в игнорируемых каталогах, `src/test/` или `src/it/` | когда выбран `jaxrx` | префиксы servlet/deployment JAX-RS |
| файлы с точным именем `pom.xml` | только `auto` | уведомления о marker'ах генерации кода; никогда не являются input'ом для endpoint'ов |

### Допустимая структура Noir report'а

Минимальный допустимый report — `{"endpoints": []}`. Каждый присутствующий
endpoint должен содержать массив `details.code_paths`, а каждый его элемент —
непустое поле `path`:

```json
{
  "endpoints": [
    {
      "details": {
        "code_paths": [
          {
            "path": "src/main/java/example/ItemsApi.java",
            "line": 42
          }
        ]
      }
    }
  ]
}
```

`path` может быть абсолютным или относительным к `--path`. Отсутствующее поле
`line` или значение `null` допустимо, но не может совпасть с аннотацией. Любое
указанное значение line должно быть положительным целым числом, а не Boolean.
Report является input-файлом: noir-ts не изменяет и не копирует его. Его путь
должен отличаться от каждого генерируемого пути: `<output>`, `<output>.log`,
`<stem>-anno-without-endpoints.log` и, когда используется `--noir-report`,
`<stem>-anno-without-noir-endpoints.log`.

## 3. Выберите способ анализа исходного кода

У команды нет позиционных аргументов или subcommand'ов:

```text
python src/noir_sbt.py --path <source-directory> --output <output-file> [--framework <value> ...] [--noir-report <noir-report.json>]
```

В таблице ниже приведён полный список вариантов выбора framework'ов. Чтобы явно
выбрать несколько framework'ов, повторите параметр целиком, как показано в
таблице; не используйте значение со списком через запятую.

| Выбор | Фрагмент команды | Используемые analyzer'ы |
|---|---|---|
| По умолчанию | не указывать `--framework` | Spring и JAX-RS / Java WebSocket |
| Автоматически | `--framework auto` | Spring и/или `jaxrx` либо ни одного — в зависимости от marker'ов |
| Spring | `--framework spring` | только Spring |
| JAX-RS | `--framework jaxrx` | только JAX-RS и Java WebSocket |
| Wicket | `--framework wicket` | только stub Wicket; сейчас он не создаёт endpoint'ов |
| Spring + JAX-RS | `--framework spring --framework jaxrx` | ровно Spring и JAX-RS / Java WebSocket |
| Spring + Wicket | `--framework spring --framework wicket` | ровно Spring и пустой stub Wicket |
| JAX-RS + Wicket | `--framework jaxrx --framework wicket` | ровно JAX-RS / Java WebSocket и пустой stub Wicket |
| Все явно указанные семейства | `--framework spring --framework jaxrx --framework wicket` | Spring, JAX-RS / Java WebSocket и пустой stub Wicket |

Порядок явно указанных параметров не имеет значения. Каждое явно указанное
значение должно быть уникальным. `auto` должен встречаться ровно один раз, и
его нельзя сочетать с другим framework'ом. CLI token — `jaxrx`; значение `jaxrs`
не поддерживается.

Режим `auto` выбирает Spring, если текст Java содержит
`org.springframework.web.bind.annotation.` или
`org.springframework.web.reactive.function.server`. Он выбирает JAX-RS, если
текст Java содержит `jakarta.ws.rs` или `javax.ws.rs`. Это чувствительный к
регистру поиск в необработанном тексте, поэтому analyzer может быть выбран
также из-за комментариев и string literal'ов. Исходный код только с `jakarta.websocket` или
`javax.websocket` не выбирает `jaxrx` в режиме `auto`; для исходного кода только
с WebSocket используйте `--framework jaxrx`. Текст Java, содержащий
`org.apache.wicket`, и `pom.xml`, содержащий `openapi.codegen` или
`io.swagger.codegen`, создают только информационные сообщения и не выбирают ни
одного analyzer'а; Wicket необходимо выбрать явно. Если нужные семейства уже
известны, выберите их явно либо не указывайте `--framework`, чтобы запустить оба
семейства, кроме Wicket.

`--noir-report <file>` можно добавить к любой строке таблицы. Для каждого
варианта выбора framework'ов:

- без `--noir-report` noir-ts генерирует `<output>`, `<output>.log` и
  `<stem>-anno-without-endpoints.log`;
- с `--noir-report` noir-ts генерирует `<output>`, `<output>.log`,
  `<stem>-anno-without-endpoints.log` и
  `<stem>-anno-without-noir-endpoints.log`.

Здесь `<stem>` — путь `--output`, из которого удалён только последний суффикс
имени файла.

## 4. Изучите сгенерированные artifact'ы

Пусть `<output>` — фактический путь `--output` после раскрытия пути к домашнему
каталогу пользователя; относительные пути остаются относительными к текущему
каталогу. Пусть `<stem>` — этот путь, из которого удалён только последний
суффикс имени файла. Успешный запуск всегда заменяет `<output>`, `<output>.log`
и `<stem>-anno-without-endpoints.log`:

| Сгенерированный файл | Содержимое |
|---|---|
| `<output>` | Перечень endpoint'ов в формате CSV с разделителем «точка с запятой». Он содержит UTF-8 byte-order mark, один header и ноль или более строк с endpoint'ами. |
| `<output>.log` | По одному блоку перечня распознанных аннотаций на каждый обнаруженный файл Java, после чего следует раздел `Diagnostics:`. |
| `<stem>-anno-without-endpoints.log` | Вхождения распознанных endpoint-trigger-аннотаций, для которых точные аннотированные Java-declaration'ы не представлены сохранившейся строкой в CSV noir-ts. |

При указании `--noir-report` дополнительно создаётся ровно один файл —
`<stem>-anno-without-noir-endpoints.log`:

| Дополнительный сгенерированный файл | Содержимое |
|---|---|
| `<stem>-anno-without-noir-endpoints.log` | Количество и сведения о вхождениях endpoint-trigger-аннотаций noir-ts без точного совпадения `(canonical source file, annotation start line)` в предоставленном Noir report'е. |

Например, `--output results/endpoints.audit.csv` создаёт:

```text
results/endpoints.audit.csv
results/endpoints.audit.csv.log
results/endpoints.audit-anno-without-endpoints.log
results/endpoints.audit-anno-without-noir-endpoints.log  # only with --noir-report
```

Если у `--output` нет суффикса, имена файлов report'ов просто дописываются к нему.
Например, `--output results/endpoints` создаёт `results/endpoints`,
`results/endpoints.log` и `results/endpoints-anno-without-endpoints.log`. С
`--noir-report` также создаётся
`results/endpoints-anno-without-noir-endpoints.log`.

### Столбцы endpoint CSV

Header CSV:

```text
module_name;interface_type;endpoint;source_file_name;method_name;parameters;method_annotation_line
```

| Столбец | Значение |
|---|---|
| `module_name` | basename каталога, полученного после разрешения пути, переданного в `--path` |
| `interface_type` | protocol/surface и operation, например `http GET`, `http-client POST`, `http-gateway GET`, `http-static-handler GET`, `ws GET` или `ws SEND` |
| `endpoint` | нормализованный маршрут, URL или message destination |
| `source_file_name` | source-path относительно `--path` с разделителями `/` |
| `method_name` | выбранный analyzer'ом label handler'а, типа или producer'а |
| `parameters` | запись параметров handler'а в source-коде, предоставленная analyzer'ом |
| `method_annotation_line` | номер с единицы строки исходного кода, содержащей определяющую endpoint аннотацию метода, если noir-ts может её определить; иначе пустое значение |

Запуск, не нашедший endpoint'ов, всё равно создаёт `<output>` с этим header CSV
без строк данных.

Если файлы Java не обнаружены, `<stem>-anno-without-endpoints.log` имеет размер
ноль байт, а `<output>.log` всё равно содержит `Diagnostics:`. Если файлы Java и
выбранные analyzer'ы есть, но trigger-элементы отсутствуют,
`<stem>-anno-without-endpoints.log` вместо этого содержит для каждого файла и
framework'а раздел `Annotations without endpoints: none`.
`<stem>-anno-without-noir-endpoints.log` при успешном запуске никогда не имеет
размер ноль байт: даже при отсутствии trigger'ов или несовпавших trigger'ов он
содержит сводку по количеству и явный результат `none`.

### Log аннотаций и диагностики

`<output>.log` содержит более широкий набор данных, чем
`<stem>-anno-without-endpoints.log` и
`<stem>-anno-without-noir-endpoints.log`. В него входят распознанные trigger- и
вспомогательные аннотации для выбранных framework'ов. Для каждой аннотации
показаны её написание в source-коде, строка, resolved identity framework'а и
фрагмент source-кода. Для файлов без
распознанных аннотаций выводится `Annotations: none`. Сообщения с timestamp о
режиме, обнаружении, неоднозначности и других аспектах анализа выводятся после
`Diagnostics:`.

### Аннотации без строк endpoint'ов noir-ts

`<stem>-anno-without-endpoints.log` сравнивает способные срабатывать аннотации
со строками endpoint'ов, созданными тем же запуском noir-ts. Результаты
группируются по исходному файлу и выбранному framework'у; для каждого не
представленного trigger'а показываются `Annotation`, `Resolved`, `Applied to`,
`Line` и `Extract`. В разделе без таких элементов выводится
`Annotations without endpoints: none`.

`<stem>-anno-without-endpoints.log` не включает вспомогательные аннотации, а
само наличие элемента не доказывает, что reachable endpoint был пропущен.
Полный каталог trigger-аннотаций приведён в
[справочнике по report'ам аннотаций](misc.md).

### Аннотации без совпадения по source-location из Noir report'а

`<stem>-anno-without-noir-endpoints.log` сравнивает тот же набор способных
срабатывать аннотаций со всеми записями `details.code_paths` предоставленного
Noir report'а, в которых указан номер строки. Он содержит сводку по общему числу
аннотаций noir-ts, уникальным расположениям Noir, точным совпадениям и
несовпавшим вхождениям, после чего перечисляет каждую несовпавшую аннотацию с
её identity framework'а и фрагментом исходного кода.

Для сопоставления используются только canonical source file и номер начальной
строки аннотации с единицы. URL, HTTP method, имя аннотации, соседние строки и
содержащие её объявления не заменяют точное расположение.
Поэтому `<stem>-anno-without-noir-endpoints.log` может выявить различие в
расположении; само по себе оно не доказывает, что Noir пропустил reachable
endpoint.

## 5. Примеры запуска

Сначала создайте каталог для output, затем выберите один из описанных выше
режимов выбора framework'ов.

### Анализ Spring и JAX-RS по умолчанию

```text
mkdir results
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv"
```

Сгенерированные файлы:

- `results/endpoints.csv`;
- `results/endpoints.csv.log`;
- `results/endpoints-anno-without-endpoints.log`.

Файл `results/endpoints-anno-without-noir-endpoints.log` не генерируется и не
удаляется, поскольку в этом запуске нет `--noir-report`. Поиск marker'ов не
используется.

### Одно или несколько явно указанных семейств

```text
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv" --framework spring --framework jaxrx
```

Для другого явного выбора используйте фрагмент команды из соответствующей
строки таблицы. Выбранный набор определяет, какие endpoint-row'ы,
классификации аннотаций и разделы framework'ов могут появиться; при этом имена
генерируемых файлов не меняются. Этот запуск генерирует `results/endpoints.csv`,
`results/endpoints.csv.log` и
`results/endpoints-anno-without-endpoints.log`.
Он не генерирует и не удаляет
`results/endpoints-anno-without-noir-endpoints.log`, поскольку в команде нет
`--noir-report`.

### `auto` без `--noir-report`

```text
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv" --framework auto
```

Сгенерированные файлы:

- `results/endpoints.csv`: endpoint'ы от analyzer'ов Spring и/или JAX-RS,
  выбранных по marker'ам source-кода; содержит только header, если ни один
  analyzer не выбран или endpoint не найден;
- `results/endpoints.csv.log`: перечень аннотаций выбранных framework'ов,
  `Framework mode: auto`, события обнаружения marker'ов и другая диагностика;
- `results/endpoints-anno-without-endpoints.log`: trigger-аннотации, не
  представленные в сгенерированном CSV. Файл имеет размер ноль байт, если
  `auto` не выбрал ни одного поддерживаемого analyzer'а.

Файл `results/endpoints-anno-without-noir-endpoints.log` при таком запуске не
генерируется и не удаляется.

### `auto` с `--noir-report`

```text
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv" --framework auto --noir-report "<noir-report.json>"
```

Сгенерированные файлы:

- `results/endpoints.csv`: перечень автоматически выбранных endpoint'ов;
- `results/endpoints.csv.log`: перечень автоматически выбранных аннотаций и
  диагностика;
- `results/endpoints-anno-without-endpoints.log`: автоматически выбранные
  trigger-аннотации, не представленные в сгенерированном CSV noir-ts;
- `results/endpoints-anno-without-noir-endpoints.log`: сводка сравнения и
  автоматически выбранные trigger-аннотации без точного совпадения исходного
  файла/строки в предоставленном `<noir-report.json>`.

Предоставленный `noir-report.json` остаётся входным файлом и не включается в
список сгенерированных файлов. Если `auto` не выбирает ни одного
поддерживаемого analyzer'а, файл
`results/endpoints-anno-without-endpoints.log` имеет размер ноль байт, а
`results/endpoints-anno-without-noir-endpoints.log` всё равно генерируется с
нулевым количеством trigger'ов noir-ts.

## 6. Подтвердите завершение

Завершённый анализ возвращает status `0`, выводит
`noir-ts analysis completed.` и фактические пути `<output>`, `<output>.log`,
`<stem>-anno-without-endpoints.log` и, когда запрошено,
`<stem>-anno-without-noir-endpoints.log`. При ошибках аргументов возвращается
status `2`.

Ни в один из этих выходных файлов данные не дописываются. При успешном повторном
запуске заменяются `<output>`, `<output>.log` и
`<stem>-anno-without-endpoints.log`; при повторном запуске в режиме сравнения
также заменяется `<stem>-anno-without-noir-endpoints.log`. Запуск без
`--noir-report` не удаляет старый
`<stem>-anno-without-noir-endpoints.log`; используйте выведенный по завершении
перечень, чтобы отличить актуальные выходные файлы от устаревшего необязательного
файла.
