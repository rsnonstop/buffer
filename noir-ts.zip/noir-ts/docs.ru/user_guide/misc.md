# Report'ы по аннотациям

Вернитесь к [руководству пользователя noir-ts](README.md), где описаны
установка, запуск и правила формирования имён artifact'ов.

При `--output endpoints.csv` noir-ts записывает два разных представления
аннотаций:

- `endpoints.csv.log` — широкий inventory распознанных аннотаций, после которого
  следует диагностика. В него могут входить аннотации, которые настраивают,
  уточняют или привязывают endpoint, но сами по себе не являются
  trigger-аннотациями.
- `endpoints-anno-without-endpoints.log` содержит распознанные вхождения
  trigger-аннотаций, для которых точная аннотированная source-declaration не
  представлена ни одной сохранившейся endpoint-row noir-ts.

Если указан `--noir-report`, noir-ts также записывает
`endpoints-anno-without-noir-endpoints.log`. Этот report содержит распознанные
вхождения trigger-аннотаций, для которых нет точного совпадения source-location
в переданном Noir report'е.

Одного имени аннотации недостаточно, чтобы она попала в один из report'ов о
несовпавших аннотациях. Её identity должна разрешаться в поддерживаемую
framework-аннотацию, соответствующий framework должен быть включён, а
аннотация должна использоваться в месте, которое может представлять endpoint.
Например, mapping метода может быть trigger'ом, тогда как тот же mapping,
используемый только как path prefix уровня типа, trigger'ом не является.

## Фиксированный каталог trigger-аннотаций

Ниже перечислены все фиксированные встроенные identity аннотаций, которые
noir-ts может рассматривать как trigger'ы endpoint'ов.

### Spring MVC

- `org.springframework.web.bind.annotation.RequestMapping`
- `org.springframework.web.bind.annotation.GetMapping`
- `org.springframework.web.bind.annotation.PostMapping`
- `org.springframework.web.bind.annotation.PutMapping`
- `org.springframework.web.bind.annotation.DeleteMapping`
- `org.springframework.web.bind.annotation.PatchMapping`

### Spring HTTP Exchange

- `org.springframework.web.service.annotation.HttpExchange`
- `org.springframework.web.service.annotation.GetExchange`
- `org.springframework.web.service.annotation.PostExchange`
- `org.springframework.web.service.annotation.PutExchange`
- `org.springframework.web.service.annotation.DeleteExchange`
- `org.springframework.web.service.annotation.PatchExchange`

### Spring messaging

- `org.springframework.messaging.handler.annotation.MessageMapping`
- `org.springframework.messaging.handler.annotation.SubscribeMapping`

### Jakarta JAX-RS

- `jakarta.ws.rs.GET`
- `jakarta.ws.rs.POST`
- `jakarta.ws.rs.PUT`
- `jakarta.ws.rs.DELETE`
- `jakarta.ws.rs.PATCH`
- `jakarta.ws.rs.HEAD`
- `jakarta.ws.rs.OPTIONS`

### Javax JAX-RS

- `javax.ws.rs.GET`
- `javax.ws.rs.POST`
- `javax.ws.rs.PUT`
- `javax.ws.rs.DELETE`
- `javax.ws.rs.PATCH`
- `javax.ws.rs.HEAD`
- `javax.ws.rs.OPTIONS`

### Jakarta и Javax WebSocket

- `jakarta.websocket.server.ServerEndpoint`
- `javax.websocket.server.ServerEndpoint`

Выбираемая integration Wicket сейчас не определяет identity trigger-аннотаций.

## Source-defined trigger-аннотации

Помимо фиксированного каталога noir-ts может включать в report'ы две категории,
fully qualified names которых берутся из анализируемого source-tree и поэтому
не могут быть перечислены заранее:

- source-defined composed mapping Spring, definition которого разрешается через
  поддерживаемую composition model Spring MVC;
- source-defined аннотацию request method JAX-RS, definition которой содержит
  корректную Jakarta- или Javax-декларацию `@HttpMethod` с retention policy
  RUNTIME.

Для этих категорий report о несовпавших аннотациях указывает внешнюю аннотацию,
использованную в declaration, способной представлять endpoint, а не
`@RequestMapping`, `@HttpMethod`, `@Target`, `@Retention` или другие metadata
внутри её definition.

Вспомогательные аннотации не попадают ни в один report о несовпавших
аннотациях. Распознанные аннотации, такие как JAX-RS `Path`, `ApplicationPath`,
`Consumes`, `Produces`, `FormParam`, `PathParam` и `QueryParam`, остаются видимы
только в широком inventory файла `endpoints.csv.log`.
