# noir-ts

`noir-ts` is a conservative, source-only Java endpoint analyzer for Spring
Boot and JAX-RS. It parses source; it does not compile the application, load a
classpath, or start a framework runtime.

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python src/noir_sbt.py \
  --path "<application source directory>" \
  --output "endpoints.csv"
```

Omitting `--framework` runs both analyzer families. The optional values are
`spring`, `jaxrx`, and the narrower marker-detection mode `auto`.

Pass a Noir v1.1 JSON report to enable source-annotation comparison:

```bash
.venv/bin/python src/noir_sbt.py \
  --path "<application source directory>" \
  --output "endpoints.csv" \
  --noir-report "noir-report.json"
```

The report is loaded and structurally validated before any output is touched.
Comparison flattens every `details.code_paths` location that has a positive,
one-based integer `line`. A missing or null line cannot identify an annotation
and is skipped; a present Boolean, string, zero, or negative line makes the
report invalid.

## Architecture in one view

The current code, tests, and [`p6.logic`](p6.logic/README.md) describe the
running application. Planning folders are not runtime architecture.

```mermaid
flowchart LR
    CLI["noir.cli"] --> APP["noir.application"]
    APP --> PIPE["noir.pipeline"]
    PIPE --> SNAP["immutable source snapshot"]
    SNAP --> JAVA["java_frontend + java_workspace"]
    JAVA --> SPRING["Spring passes"]
    JAVA --> JAX["JAX-RS passes"]
    SPRING --> FACTS["immutable EndpointFacts"]
    JAX --> FACTS
    FACTS --> OUT["noir.output + noir.reports"]
```

The important boundaries are:

| Layer | Responsibility |
|---|---|
| `src/noir_sbt.py` | thin executable entry point |
| `src/noir/cli.py` | arguments, stdout, and the ordered artifact transaction |
| `src/noir/application.py` | one typed request/result and diagnostic scope |
| `src/noir/pipeline.py` | framework selection and explicit pass order |
| `src/noir/tree_sitter_runtime.py` | pinned parser dependency gate and query runtime |
| `src/noir/java_frontend.py` | syntax, captures, and compilation units |
| `src/noir/java_queries.py` | neutral compilation-unit and workspace query sources |
| `src/noir/java_workspace.py` | cross-file identity, visibility, and constants |
| `src/noir/model.py` | immutable application and endpoint vocabulary |
| `src/noir/output.py`, `reports.py` | the single lossy CSV/report boundary |

Every discovered Java source is read into one run snapshot and parsed exactly
once. All direct and project-wide analyzers reuse the same compilation unit.
Ambiguous imports, identities, inheritance, constants, configuration, or data
flow fail closed at the affected resolution or branch. Supported rejection
paths record diagnostics; deliberately silent conservative filters remain
visible through the annotation reports and missing rows.

## Outputs

For `--output endpoints.csv`, a successful run writes:

- `endpoints.csv`: UTF-8 BOM, semicolon-delimited, seven columns;
- `endpoints.csv.log`: recognized annotation inventory plus diagnostics;
- `endpoints-anno-without-endpoints.log`: trigger annotations whose exact
  source targets were not represented by a surviving endpoint row.

With `--noir-report`, it additionally writes
`endpoints-anno-without-noir-endpoints.log`. Every occurrence in the broad
recognized-annotation inventory is matched by the exact pair
`(canonical source path, one-based annotation line)` against Noir's flattened
code-path locations. The comparison log preserves the broad inventory details
for occurrences without a matching Noir endpoint location.

Its deterministic preamble uses occurrence and exact-location terminology:

```text
noir-ts annotation comparison against Noir

Annotations found by noir-ts: {total_count}

Unique Noir endpoint source locations: {noir_location_count}
  Unique canonical (source file, line) locations from
  endpoints[*].details.code_paths[*].
  Duplicate locations are counted once; locations without a line are excluded.

Annotations matched by exact source location: {matched_count}
  Match key: canonical source file and annotation start line.
  URLs, HTTP methods, annotation names, adjacent lines, and enclosing
  declarations are not used for matching.

Annotations without an exact Noir source-location match: {missing_count}
  These are annotation occurrences, not necessarily endpoints missed by Noir.
  Supporting annotations can also appear in this count.

noir-ts annotations, not reported by Noir:
```

When every occurrence matches, the last line instead ends with `: none`.

This comparison intentionally differs from the narrower internal
annotations-without-endpoints report. The broad inventory includes activation,
binding, path, media-type, parameter, and other supported annotations that are
not endpoint triggers, so such entries can legitimately appear missing from a
Noir report. Noir does not identify the annotation within a source line;
recognized annotations sharing one line are therefore indistinguishable.

The first six CSV columns define endpoint identity. The seventh,
`method_annotation_line`, is selected from validated same-source evidence and
is merged without changing identity.

Publication is ordered rather than globally atomic: the CSV and broad log are
direct writes, followed by atomic replacement of the annotations-without-
endpoints report and, in comparison mode, atomic replacement of the Noir
comparison report. Each byte report is atomic on its own; a later failure does
not roll back artifacts already published for that run.

After every requested artifact has published successfully, stdout ends with
`noir-ts analysis completed.` followed by a deterministic inventory of the
three baseline output paths and their meanings. With `--noir-report`, that
inventory also lists `*-anno-without-noir-endpoints.log` as generated output
and the resolved Noir report under `Comparison input (not generated by
noir-ts):`. Generated paths retain the effective `--output` spelling after
user-home expansion, including a relative spelling; report stems remove only
the final suffix. The validated Noir input is displayed as an absolute,
resolved path.

Existing `Found ...` framework announcements keep their wording and appear
before this completion block. Analysis, rendering, or publication failure
suppresses the entire completion block, although an earlier framework
announcement or error diagnostic may already be visible.

## Verification

```bash
.venv/bin/python -m unittest discover -s tests -p 'test_noir*.py'
```

Architecture, parse-once, output-byte, deterministic-order, semantic, and
black-box CLI tests are part of the normal suite. The runtime deliberately
accepts only the exact Tree-sitter versions pinned in
[`src/requirements.txt`](src/requirements.txt).

For a top-down explanation with branch diagrams and worked traces, start at
[`p6.logic/README.md`](p6.logic/README.md).
