#!/usr/bin/env python3
"""Run the noir-ts command-line application.

Logic guide: ``p6.logic/02-cli-and-orchestration.md``.
"""

from noir.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
