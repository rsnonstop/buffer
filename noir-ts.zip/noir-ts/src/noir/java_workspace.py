"""Framework-neutral Java workspace indexes and symbol resolution.

A workspace is built from already-selected Java sources and one explicit
front-end runtime.  This layer indexes declarations and resolves Java names,
accessibility, and bounded string constants.  Framework annotation meaning and
endpoint discovery are attached later by their Spring/JAX-RS owners.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

from .java_frontend import (
    JAVA_CONSTANT_MAX_LENGTH,
    annotation_single_value_node,
    annotation_value_nodes,
    binary_expression_is_addition,
    build_java_compilation_unit,
    child_by_field,
    declaration_modifier_names,
    decode_java_string_literal,
    first_capture,
    lexical_type_chain,
    nearest_enclosing_type,
    node_text,
    owner_name_for_node,
    qualified_type_name,
    resolve_known_annotation,
    resolve_known_type,
    tree_node_key,
    unwrap_parenthesized_node,
    visible_local_type_infos,
    visible_local_type_names,
)


# Resolution bounds are semantic safeguards: an expression that exceeds them
# contributes no route value instead of producing a partially proven result.
JAVA_CONSTANT_MAX_DEPTH = 12
# Only these genuine ``ElementType`` members are understood when validating
# source-defined annotation placement.
JAVA_ELEMENT_TYPES = frozenset(
    {
        "ANNOTATION_TYPE",
        "CONSTRUCTOR",
        "FIELD",
        "LOCAL_VARIABLE",
        "METHOD",
        "MODULE",
        "PACKAGE",
        "PARAMETER",
        "RECORD_COMPONENT",
        "TYPE",
        "TYPE_PARAMETER",
        "TYPE_USE",
    }
)


def static_member_resolves_to(
    unit, member_name, expected_owner, context_node=None
):
    """Prove an unqualified member denotes one expected external static owner.

    Exact imports stop lookup immediately.  A wildcard import succeeds only if
    no other imported source owner declares an accessible same-named member.
    """

    imports = unit["imports"]
    if member_name in imports["static_exact"]:
        return (
            imports["static_exact"][member_name]
            == f"{expected_owner}.{member_name}"
        )
    if expected_owner not in imports["static_wildcards"]:
        return False
    declarations = unit.get("workspace_static_member_declarations", {})
    consumer_owner_name = owner_name_for_node(unit, context_node)
    return not any(
        owner != expected_owner
        and any(
            workspace_static_member_declaration_accessible(
                record, unit, consumer_owner_name
            )
            for record in declarations.get((owner, member_name), [])
        )
        for owner in imports["static_wildcards"]
    )


def workspace_type_accessible(type_record, consumer_unit, consumer_owner_name):
    """Apply the supported Java access rules to one source type declaration.

    Access is checked across the full outer-type chain, private nests, package
    boundaries, and the named/unnamed-package boundary.  It answers only
    accessibility; callers separately require a unique declaration identity.
    """

    declaration_unit = type_record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    type_info = type_record["type_info"]
    chain = lexical_type_chain(tree_node_key(type_info["node"]), declaration_unit["type_infos"])
    access = []
    for current in chain:
        modifiers = declaration_modifier_names(current["node"])
        outer_node = nearest_enclosing_type(current["node"])
        implicitly_public = bool(
            outer_node is not None
            and outer_node.type
            in {"interface_declaration", "annotation_type_declaration"}
        )
        access.append(
            {
                "public": implicitly_public or "public" in modifiers,
                "private": "private" in modifiers,
            }
        )
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and type_info["display_name"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        return not any(part["private"] for part in access) or same_nest
    if any(part["private"] for part in access):
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return all(part["public"] for part in access)


def index_workspace_types(workspace):
    """Index every workspace-visible declaration without collapsing duplicates.

    Retaining all records per FQN is essential: resolvers can require exactly
    one declaration and fail closed instead of selecting by source order.
    """

    declarations = {}
    for unit in workspace["compilation_units"].values():
        for type_info in unit["type_infos"].values():
            if not type_info["workspace_visible"]:
                continue
            fqn = qualified_type_name(unit, type_info)
            declarations.setdefault(fqn, []).append(
                {"fqn": fqn, "unit": unit, "type_info": type_info}
            )
    workspace["type_declarations"] = declarations


def index_workspace_constants(workspace):
    """Build declaration and eligible-String indexes for member resolution.

    ``member_declarations`` contains even ineligible fields because they can
    shadow a lower lookup tier. ``constants_by_owner_member`` contains values
    the bounded evaluator may inspect. ``static_member_declarations`` also
    models enum/static-wildcard collisions.
    """

    by_owner_member = {}
    member_declarations = {}
    static_member_declarations = {}
    for unit in workspace["compilation_units"].values():
        records = []
        for _pattern_index, captures in unit["matches"]["field"]:
            type_node = first_capture(captures, "constant.type")
            name_node = first_capture(captures, "constant.name")
            value_node = first_capture(captures, "constant.value")
            field_node = first_capture(captures, "constant.field")
            if None in (type_node, name_node, field_node):
                continue
            owner_node = nearest_enclosing_type(field_node)
            owner_info = (
                unit["type_infos"].get(tree_node_key(owner_node))
                if owner_node is not None
                else None
            )
            if owner_info is None or not owner_info["workspace_visible"]:
                continue
            member_name = node_text(unit["source"], name_node)
            owner_fqn = qualified_type_name(unit, owner_info)
            declaration_id = (
                unit["source_path"],
                field_node.start_byte,
                field_node.end_byte,
                name_node.start_byte,
            )
            member_declarations.setdefault((owner_fqn, member_name), set()).add(
                declaration_id
            )
            modifiers = declaration_modifier_names(field_node)
            implicit_constant = field_node.type == "constant_declaration"
            owner_chain = lexical_type_chain(tree_node_key(owner_info["node"]), unit["type_infos"])
            owner_access = []
            for owner_part in owner_chain:
                owner_modifiers = declaration_modifier_names(owner_part["node"])
                outer_node = nearest_enclosing_type(owner_part["node"])
                implicitly_public = bool(
                    outer_node is not None
                    and outer_node.type
                    in {"interface_declaration", "annotation_type_declaration"}
                )
                owner_access.append(
                    {
                        "public": implicitly_public or "public" in owner_modifiers,
                        "private": "private" in owner_modifiers,
                    }
                )
            declaration_record = {
                "id": declaration_id,
                "owner": owner_info["display_name"],
                "owner_fqn": owner_fqn,
                "unit": unit,
                "static": implicit_constant or "static" in modifiers,
                "public": implicit_constant or "public" in modifiers,
                "private": "private" in modifiers,
                "owner_all_public": all(part["public"] for part in owner_access),
                "owner_has_private": any(part["private"] for part in owner_access),
            }
            if declaration_record["static"]:
                static_member_declarations.setdefault(
                    (owner_fqn, member_name), []
                ).append(declaration_record)
            if value_node is None:
                continue
            field_type = node_text(unit["source"], type_node).strip()
            if resolve_known_type(
                unit, field_type, "String", ("java.lang",), type_node
            ) != "java.lang":
                continue
            record = {
                **declaration_record,
                "name": member_name,
                "owner_type": owner_info["node"].type,
                "value_node": value_node,
                "final_constant": implicit_constant or "final" in modifiers,
                "static_final": implicit_constant
                or {"static", "final"}.issubset(modifiers),
                "protected": "protected" in modifiers,
            }
            records.append(record)
            by_owner_member.setdefault(
                (record["owner_fqn"], record["name"]), []
            ).append(record)
        for _pattern_index, captures in unit["matches"]["enum_constant"]:
            type_node = first_capture(captures, "enum.type.node")
            name_node = first_capture(captures, "enum.constant.name")
            constant_node = first_capture(captures, "enum.constant.node")
            type_info = (
                unit["type_infos"].get(tree_node_key(type_node))
                if type_node is not None
                else None
            )
            if (
                type_info is None
                or name_node is None
                or constant_node is None
                or not type_info["workspace_visible"]
            ):
                continue
            member_declarations.setdefault(
                (
                    qualified_type_name(unit, type_info),
                    node_text(unit["source"], name_node),
                ),
                set(),
            ).add(
                (
                    unit["source_path"],
                    constant_node.start_byte,
                    constant_node.end_byte,
                    name_node.start_byte,
                )
            )
            enum_owner_access = []
            for owner_part in lexical_type_chain(
                tree_node_key(type_info["node"]), unit["type_infos"]
            ):
                owner_modifiers = declaration_modifier_names(owner_part["node"])
                outer_node = nearest_enclosing_type(owner_part["node"])
                implicitly_public = bool(
                    outer_node is not None
                    and outer_node.type
                    in {"interface_declaration", "annotation_type_declaration"}
                )
                enum_owner_access.append(
                    {
                        "public": implicitly_public or "public" in owner_modifiers,
                        "private": "private" in owner_modifiers,
                    }
                )
            static_member_declarations.setdefault(
                (
                    qualified_type_name(unit, type_info),
                    node_text(unit["source"], name_node),
                ),
                [],
            ).append(
                {
                    "id": (
                        unit["source_path"],
                        constant_node.start_byte,
                        constant_node.end_byte,
                        name_node.start_byte,
                    ),
                    "owner": type_info["display_name"],
                    "owner_fqn": qualified_type_name(unit, type_info),
                    "unit": unit,
                    "static": True,
                    "public": True,
                    "private": False,
                    "owner_all_public": all(
                        part["public"] for part in enum_owner_access
                    ),
                    "owner_has_private": any(
                        part["private"] for part in enum_owner_access
                    ),
                }
            )
        unit["workspace_constant_records"] = records
    workspace["constants_by_owner_member"] = by_owner_member
    workspace["member_declarations"] = member_declarations
    workspace["static_member_declarations"] = static_member_declarations
    for unit in workspace["compilation_units"].values():
        unit["workspace_member_declarations"] = member_declarations
        unit["workspace_static_member_declarations"] = static_member_declarations


def workspace_constant_accessible(
    record,
    consumer_unit,
    consumer_owner_name,
    require_static_final=False,
    require_final_constant=False,
):
    """Check whether one indexed String value is usable from a consumer site."""

    if require_static_final and not record["static_final"]:
        return False
    if require_final_constant and not record["final_constant"]:
        return False
    declaration_unit = record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and record["owner"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        if record["private"] or record["owner_has_private"]:
            return same_nest
        return True
    if (
        not record["static_final"]
        or record["private"]
        or record["owner_has_private"]
    ):
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return record["public"] and record["owner_all_public"]


def workspace_member_records(
    workspace,
    consumer_unit,
    consumer_owner_name,
    owner_fqn,
    member_name,
    require_static_final=False,
    require_final_constant=False,
):
    """Return eligible values only for one unique, accessible source owner."""

    if len(workspace["type_declarations"].get(owner_fqn, [])) != 1:
        return []
    return [
        record
        for record in workspace["constants_by_owner_member"].get(
            (owner_fqn, member_name), []
        )
        if workspace_constant_accessible(
            record,
            consumer_unit,
            consumer_owner_name,
            require_static_final=require_static_final,
            require_final_constant=require_final_constant,
        )
    ]


def workspace_type_exists(workspace, fqn):
    """Report whether any source declaration shadows an external FQN."""

    return bool(workspace["type_declarations"].get(fqn))


def workspace_member_declared(workspace, owner_fqn, member_name):
    """Report declaration presence even when no usable String value exists."""

    return bool(
        workspace["member_declarations"].get((owner_fqn, member_name))
    )


def workspace_static_member_declaration_accessible(
    record, consumer_unit, consumer_owner_name
):
    """Check visibility of a static declaration used for wildcard ambiguity."""

    declaration_unit = record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and record["owner"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        if record["private"] or record["owner_has_private"]:
            return same_nest
        return True
    if record["private"] or record["owner_has_private"]:
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return record["public"] and record["owner_all_public"]


def workspace_static_member_declared(
    workspace, consumer_unit, consumer_owner_name, owner_fqn, member_name
):
    """Prove a unique source owner declares an accessible static member name."""

    if len(workspace["type_declarations"].get(owner_fqn, [])) != 1:
        return False
    return any(
        workspace_static_member_declaration_accessible(
            record, consumer_unit, consumer_owner_name
        )
        for record in workspace["static_member_declarations"].get(
            (owner_fqn, member_name), []
        )
    )


def workspace_type_fqn_accessible(
    workspace, consumer_unit, consumer_owner_name, owner_fqn
):
    """Prove an FQN has exactly one accessible source declaration."""

    declarations = workspace["type_declarations"].get(owner_fqn, [])
    return len(declarations) == 1 and workspace_type_accessible(
        declarations[0], consumer_unit, consumer_owner_name
    )


def lexical_owner_fqns(unit, owner_name):
    """Return inner-to-outer FQNs for lexical member lookup."""

    parts = owner_name.split(".") if owner_name else []
    owners = []
    while parts:
        display = ".".join(parts)
        owners.append(f"{unit['package']}.{display}" if unit["package"] else display)
        parts.pop()
    return owners


def resolve_workspace_owner_fqns(
    unit,
    qualifier,
    owner_name,
    workspace,
    external_type_fqns=None,
):
    """Return candidates from the first applicable Java type-lookup tier.

    Resolution checks closed external identity, lexical member types, exact
    imports, same-package/global source, then wildcard imports. Exact-import
    ambiguity is terminal, inaccessible declarations are excluded, and callers
    requiring one identity must reject any multi-candidate result.
    """

    external_type_fqns = set(external_type_fqns or ())
    if qualifier in external_type_fqns:
        return [] if workspace_type_exists(workspace, qualifier) else [qualifier]

    # Lexical member types have priority over every import/package tier.
    lexical = []
    owner_parts = owner_name.split(".") if owner_name else []
    while owner_parts:
        display = f"{'.'.join(owner_parts)}.{qualifier}"
        fqn = f"{unit['package']}.{display}" if unit["package"] else display
        if workspace_type_fqn_accessible(
            workspace, unit, owner_name, fqn
        ):
            lexical.append(fqn)
        if lexical:
            return lexical
        owner_parts.pop()

    first, dot, suffix = qualifier.partition(".")
    if first in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][first]
        if not imported:
            return []
        imported_fqn = f"{imported}.{suffix}" if dot else imported
        if imported_fqn in external_type_fqns:
            return (
                []
                if workspace_type_exists(workspace, imported_fqn)
                else [imported_fqn]
            )
        return (
            [imported_fqn]
            if workspace_type_fqn_accessible(
                workspace, unit, owner_name, imported_fqn
            )
            else []
        )

    same_package = f"{unit['package']}.{qualifier}" if unit["package"] else qualifier
    if same_package in external_type_fqns:
        return (
            []
            if workspace_type_exists(workspace, same_package)
            else [same_package]
        )
    if workspace_type_fqn_accessible(
        workspace, unit, owner_name, same_package
    ):
        return [same_package]

    global_declarations = workspace["type_declarations"].get(qualifier, [])
    if global_declarations and (
        not unit["package"]
        or all(record["unit"]["package"] for record in global_declarations)
    ) and workspace_type_fqn_accessible(
        workspace, unit, owner_name, qualifier
    ):
        return [qualifier]

    # Wildcards are the final supported tier and may legitimately produce more
    # than one candidate; callers that need identity require cardinality one.
    candidates = set()
    for package in unit["imports"]["wildcards"]:
        imported_fqn = f"{package}.{qualifier}"
        if imported_fqn in external_type_fqns:
            if not workspace_type_exists(workspace, imported_fqn):
                candidates.add(imported_fqn)
            continue
        if workspace_type_fqn_accessible(
            workspace, unit, owner_name, imported_fqn
        ):
            candidates.add(imported_fqn)
    return sorted(candidates)


def context_is_static_for_instance_constant(context_node):
    """Decide whether a use site lacks an enclosing instance for lookup."""

    current = getattr(context_node, "parent", None)
    while current is not None:
        if current.type in {"method_declaration", "field_declaration"}:
            return "static" in declaration_modifier_names(current)
        if current.type in {"static_initializer", "constant_declaration"}:
            return True
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            # A declaration annotation is outside the declared type's member scope.
            return True
        current = getattr(current, "parent", None)
    return True


def lexical_instance_constant_accessible(
    record, consumer_unit, consumer_owner_name, context_node
):
    """Check the enclosing-instance part of constant accessibility.

    After declaration visibility is checked, static-final values need no
    instance. Other final Strings must be same-file and non-static; a nested
    class may use an outer value only while no static nesting boundary breaks
    the enclosing-instance chain.
    """

    if record["static_final"]:
        return True
    if (
        record["unit"] is not consumer_unit
        or not consumer_owner_name
        or context_is_static_for_instance_constant(context_node)
    ):
        return False
    if record["owner"] == consumer_owner_name:
        return True
    if not consumer_owner_name.startswith(f"{record['owner']}."):
        return False

    infos_by_display = {
        info["display_name"]: info for info in consumer_unit["type_infos"].values()
    }
    current = infos_by_display.get(consumer_owner_name)
    while current is not None and current["display_name"] != record["owner"]:
        modifiers = declaration_modifier_names(current["node"])
        outer = (
            consumer_unit["type_infos"].get(current["outer_key"])
            if current["outer_key"] is not None
            else None
        )
        implicitly_static = current["node"].type in {
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        } or bool(
            outer is not None
            and outer["node"].type
            in {"interface_declaration", "annotation_type_declaration"}
        )
        if "static" in modifiers or implicitly_static:
            return False
        current = outer
    return current is not None and current["display_name"] == record["owner"]


def known_static_constant_record(owner_fqn, member_name, value):
    """Wrap one closed dependency constant in normal candidate provenance."""

    return {
        "id": ("known-static", owner_fqn, member_name),
        "owner_fqn": owner_fqn,
        "name": member_name,
        "resolved_value": value,
    }


def workspace_constant_candidates(
    unit,
    reference,
    owner_name,
    workspace,
    context_node=None,
    known_static_constants=None,
):
    """Resolve a String member reference through Java-like priority tiers.

    Unqualified names first search lexical owners and stop at the first owner
    that *declares* the name, even if its value is ineligible.  Only absence
    permits exact/static-wildcard imports.  Qualified references first require
    one resolved owner identity.  Every ambiguity returns an empty candidate
    set for the evaluator to reject.
    """

    known_static_constants = known_static_constants or {}
    reference = reference.strip()
    if reference.startswith("this."):
        return []

    if "." not in reference:
        # Declaration presence, rather than eligible-value presence, controls
        # whether lexical lookup may continue to static imports.
        for owner_fqn in lexical_owner_fqns(unit, owner_name):
            records = workspace_member_records(
                workspace,
                unit,
                owner_name,
                owner_fqn,
                reference,
                require_final_constant=True,
            )
            records = [
                record
                for record in records
                if lexical_instance_constant_accessible(
                    record, unit, owner_name, context_node
                )
            ]
            if workspace_member_declared(
                workspace, owner_fqn, reference
            ):
                return records

        if reference in unit["imports"]["static_exact"]:
            target = unit["imports"]["static_exact"][reference]
            if not target or "." not in target:
                return []
            owner_fqn, member_name = target.rsplit(".", 1)
            known_value = known_static_constants.get(owner_fqn, {}).get(
                member_name
            )
            if known_value is not None:
                if workspace_type_exists(workspace, owner_fqn):
                    return []
                return [
                    known_static_constant_record(
                        owner_fqn, member_name, known_value
                    )
                ]
            return workspace_member_records(
                workspace,
                unit,
                owner_name,
                owner_fqn,
                member_name,
                require_static_final=True,
            )

        # Wildcard imports are valid only when one imported owner declares the
        # member; multiple owners are ambiguity even if only one has a value.
        declaring_owners = []
        for owner_fqn in sorted(unit["imports"]["static_wildcards"]):
            known_declared = reference in known_static_constants.get(
                owner_fqn, {}
            )
            source_declared = workspace_static_member_declared(
                workspace, unit, owner_name, owner_fqn, reference
            )
            if known_declared or source_declared:
                declaring_owners.append(owner_fqn)
        if len(declaring_owners) != 1:
            return []
        declaring_owner = declaring_owners[0]
        known_value = known_static_constants.get(declaring_owner, {}).get(
            reference
        )
        if known_value is not None:
            if workspace_type_exists(workspace, declaring_owner):
                return []
            return [
                known_static_constant_record(
                    declaring_owner, reference, known_value
                )
            ]
        return workspace_member_records(
            workspace,
            unit,
            owner_name,
            declaring_owner,
            reference,
            require_static_final=True,
        )

    qualifier, member_name = reference.rsplit(".", 1)
    owner_fqns = resolve_workspace_owner_fqns(
        unit,
        qualifier,
        owner_name,
        workspace,
        external_type_fqns=known_static_constants,
    )
    if len(owner_fqns) != 1:
        return []
    owner_fqn = owner_fqns[0]
    known_value = known_static_constants.get(owner_fqn, {}).get(member_name)
    if known_value is not None:
        return [
            known_static_constant_record(owner_fqn, member_name, known_value)
        ]
    candidates = []
    candidates.extend(
        workspace_member_records(
            workspace,
            unit,
            owner_name,
            owner_fqn,
            member_name,
            require_static_final=True,
        )
    )
    return candidates


def resolve_workspace_string_expression(
    unit,
    expression_node,
    workspace,
    owner_name,
    stack=(),
    depth=0,
    known_static_constants=None,
):
    """Evaluate the bounded Java String subset used by route metadata.

    Supported evidence is a literal, parentheses, ``+`` concatenation, or one
    eligible member reference.  Recursion, output size, candidate cardinality,
    and declaration cycles are bounded; unsupported syntax returns ``None``.
    """

    if expression_node is None or depth > JAVA_CONSTANT_MAX_DEPTH:
        return None

    source = unit["source"]
    node_type = expression_node.type
    if node_type == "string_literal":
        return decode_java_string_literal(node_text(source, expression_node))
    if node_type == "parenthesized_expression":
        children = expression_node.named_children
        if len(children) != 1:
            return None
        return resolve_workspace_string_expression(
            unit,
            children[0],
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
    if node_type == "binary_expression":
        left = child_by_field(expression_node, "left")
        right = child_by_field(expression_node, "right")
        if (
            left is None
            or right is None
            or not binary_expression_is_addition(source, expression_node, left, right)
        ):
            return None
        left_value = resolve_workspace_string_expression(
            unit,
            left,
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
        right_value = resolve_workspace_string_expression(
            unit,
            right,
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
        if left_value is None or right_value is None:
            return None
        value = left_value + right_value
        return value if len(value) <= JAVA_CONSTANT_MAX_LENGTH else None
    if node_type in {"identifier", "field_access", "scoped_identifier"}:
        reference = node_text(source, expression_node)
        candidates = workspace_constant_candidates(
            unit,
            reference,
            owner_name,
            workspace,
            expression_node,
            known_static_constants,
        )
        unique = {record["id"]: record for record in candidates}
        if len(unique) != 1:
            return None
        record = next(iter(unique.values()))
        if "resolved_value" in record:
            return record["resolved_value"]
        if record["id"] in stack:
            return None
        return resolve_workspace_string_expression(
            record["unit"],
            record["value_node"],
            workspace,
            record["owner"],
            stack + (record["id"],),
            depth + 1,
            known_static_constants,
        )
    return None


def index_java_annotation_declarations(workspace):
    """Index all workspace-visible source annotation identities, duplicates intact."""

    declarations = {}
    for unit in workspace["compilation_units"].values():
        for info in unit["type_infos"].values():
            if (
                info["node"].type != "annotation_type_declaration"
                or not info["workspace_visible"]
            ):
                continue
            record = {
                "fqn": qualified_type_name(unit, info),
                "simple_name": info["simple_name"],
                "unit": unit,
                "type_info": info,
            }
            declarations.setdefault(record["fqn"], []).append(record)
    return declarations


def retention_is_runtime(unit, annotation_node):
    """Prove ``@Retention`` selects the genuine Java ``RUNTIME`` constant."""

    value_node, error = annotation_single_value_node(annotation_node)
    if error:
        return False
    current = unwrap_parenthesized_node(value_node)
    if current is None:
        return False
    spelling = node_text(unit["source"], current).strip()
    if spelling == "RUNTIME":
        return static_member_resolves_to(
            unit,
            "RUNTIME",
            "java.lang.annotation.RetentionPolicy",
            current,
        )
    if "." not in spelling or spelling.rsplit(".", 1)[-1] != "RUNTIME":
        return False
    qualifier = spelling.rsplit(".", 1)[0]
    return (
        resolve_known_type(
            unit,
            qualifier,
            "RetentionPolicy",
            ("java.lang.annotation",),
            current,
        )
        == "java.lang.annotation"
    )


def custom_annotation_identity_candidates(
    unit, spelling, workspace, context_node=None
):
    """Resolve source annotation declarations through Java priority tiers.

    The function deliberately returns a set: consumers combine cardinality
    with accessibility policy and reject duplicate or wildcard ambiguity.
    """

    declarations = workspace["annotation_declarations"]
    simple_name = spelling.rsplit(".", 1)[-1]
    if "." in spelling:
        identities = [spelling]
        if unit["package"]:
            identities.append(f"{unit['package']}.{spelling}")
        return {identity for identity in identities if identity in declarations}

    visible_infos = visible_local_type_infos(unit, context_node)
    visible_identities = {
        f"{unit['package']}.{info['display_name']}"
        if unit["package"]
        else info["display_name"]
        for info in visible_infos
        if info["simple_name"] == simple_name
    }
    if visible_identities:
        return visible_identities & set(declarations)

    if simple_name in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][simple_name]
        return {imported} if imported in declarations else set()

    same_package = (
        f"{unit['package']}.{simple_name}" if unit["package"] else simple_name
    )
    if same_package in declarations:
        return {same_package}
    if simple_name in unit.get("package_types", set()):
        return set()

    return {
        f"{package}.{simple_name}"
        for package in unit["imports"]["wildcards"]
        if f"{package}.{simple_name}" in declarations
    }


def unresolved_java_target_reference(unit, record):
    """Detect a plausible ``java.lang.annotation.Target`` whose identity is unclear.

    Definition validation uses this to distinguish no ``@Target`` (Java's broad
    default) from an ambiguous Target-like occurrence, which must fail closed.
    """

    spelling = node_text(unit["source"], record["name_node"]).strip()
    if spelling.rsplit(".", 1)[-1] != "Target":
        return False
    if "." in spelling:
        return spelling == "java.lang.annotation.Target"
    if "Target" in visible_local_type_names(unit, record["name_node"]):
        return False
    explicit = unit["imports"]["exact"].get("Target")
    if explicit is not None:
        return explicit in {"", "java.lang.annotation.Target"}
    if "Target" in unit.get("package_types", set()):
        return False
    return "java.lang.annotation" in unit["imports"]["wildcards"]


def resolve_java_element_type(unit, value_node):
    """Resolve one genuine ``ElementType`` enum constant from annotation syntax."""

    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = node_text(unit["source"], current).strip()
    element_type = spelling.rsplit(".", 1)[-1]
    if element_type not in JAVA_ELEMENT_TYPES:
        return None
    expected_owner = "java.lang.annotation.ElementType"
    if "." not in spelling:
        return (
            element_type
            if static_member_resolves_to(
                unit, element_type, expected_owner, current
            )
            else None
        )
    qualifier = spelling.rsplit(".", 1)[0]
    return (
        element_type
        if resolve_known_type(
            unit,
            qualifier,
            "ElementType",
            ("java.lang.annotation",),
            current,
        )
        == "java.lang.annotation"
        else None
    )


def annotation_definition_is_method_applicable(definition):
    """Prove a source annotation permits method use under Java ``@Target`` rules.

    No genuine ``@Target`` means Java's default applicability.  Multiple,
    ambiguous, malformed, duplicate, or non-METHOD target sets are rejected.
    """

    unit = definition["unit"]
    target_like = [
        record
        for record in definition["meta_annotations"]
        if node_text(unit["source"], record["name_node"])
        .strip()
        .rsplit(".", 1)[-1]
        == "Target"
    ]
    genuine = [
        record
        for record in target_like
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"Target"},
            ("java.lang.annotation",),
        )
        is not None
    ]
    if any(
        unresolved_java_target_reference(unit, record)
        for record in target_like
        if record not in genuine
    ):
        return False
    if not genuine:
        return True
    if len(genuine) != 1:
        return False

    value_node, error = annotation_single_value_node(genuine[0]["node"])
    if error:
        return False
    values = [
        resolve_java_element_type(unit, node)
        for node in annotation_value_nodes(value_node)
    ]
    return (
        bool(values)
        and all(value is not None for value in values)
        and len(values) == len(set(values))
        and "METHOD" in values
    )


def build_java_workspace(
    source_bytes_by_path,
    runtime,
    parsed_trees=None,
    *,
    match_query,
):
    """Parse each selected source once and derive shared cross-file indexes.

    Stage order is intentional: construct every unit from snapshot bytes; add
    package/wildcard collision facts; then index types, members/constants, and
    annotation declarations.  Framework indexes are attached later to this
    same workspace, so all passes see identical trees and source provenance.
    """

    parsed_trees = parsed_trees or {}
    normalized_sources = {
        str(source_path): source_bytes
        for source_path, source_bytes in source_bytes_by_path.items()
    }
    normalized_trees = {
        str(source_path): tree for source_path, tree in parsed_trees.items()
    }
    compilation_units = {}
    for source_path in sorted(normalized_sources):
        source_bytes = normalized_sources[source_path]
        if not isinstance(source_bytes, bytes):
            raise TypeError("Java workspace sources must be bytes")
        compilation_units[source_path] = build_java_compilation_unit(
            source_path,
            source_bytes,
            runtime,
            parsed_tree=normalized_trees.get(source_path),
            match_query=match_query,
        )

    # Per-package names let known-type resolution distinguish an absent library
    # class from a same-package or wildcard-imported source shadow.
    package_types = {}
    for unit in compilation_units.values():
        names = package_types.setdefault(unit["package"], set())
        names.update(
            info["simple_name"]
            for info in unit["type_infos"].values()
            if info["outer_key"] is None
        )
    for unit in compilation_units.values():
        own_top_level_names = {
            info["simple_name"]
            for info in unit["type_infos"].values()
            if info["outer_key"] is None
        }
        unit["package_types"] = package_types[unit["package"]] - own_top_level_names
        wildcard_source_types = {}
        for imported_package in unit["imports"]["wildcards"]:
            for simple_name in package_types.get(imported_package, set()):
                wildcard_source_types.setdefault(simple_name, set()).add(
                    f"{imported_package}.{simple_name}"
                )
        unit["wildcard_source_types"] = wildcard_source_types

    # Cross-file indexes are derived only after every unit exists; no source
    # order can make an earlier unit see a different declaration universe.
    workspace = {"runtime": runtime, "compilation_units": compilation_units}
    index_workspace_types(workspace)
    index_workspace_constants(workspace)
    workspace["annotation_declarations"] = index_java_annotation_declarations(
        workspace
    )
    return workspace





__all__ = [
    "JAVA_CONSTANT_MAX_DEPTH",
    "JAVA_ELEMENT_TYPES",
    "annotation_definition_is_method_applicable",
    "build_java_workspace",
    "context_is_static_for_instance_constant",
    "custom_annotation_identity_candidates",
    "index_java_annotation_declarations",
    "index_workspace_constants",
    "index_workspace_types",
    "known_static_constant_record",
    "lexical_instance_constant_accessible",
    "lexical_owner_fqns",
    "resolve_java_element_type",
    "resolve_workspace_owner_fqns",
    "resolve_workspace_string_expression",
    "retention_is_runtime",
    "static_member_resolves_to",
    "unresolved_java_target_reference",
    "workspace_constant_accessible",
    "workspace_constant_candidates",
    "workspace_member_declared",
    "workspace_member_records",
    "workspace_static_member_declaration_accessible",
    "workspace_static_member_declared",
    "workspace_type_accessible",
    "workspace_type_exists",
    "workspace_type_fqn_accessible",
]
