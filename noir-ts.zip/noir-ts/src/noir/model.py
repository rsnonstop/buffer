"""Immutable values passed between Noir's application pipeline stages.

This module contains vocabulary, not analysis behavior. It deliberately knows
nothing about Java, Spring, JAX-RS, CSV, logging, or file publication.

Logic guide: ``p6.logic/01-mental-model.md``,
``p6.logic/07-output-evidence-reports.md``, and
``p6.logic/11-naming-and-code-vocabulary.md``.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Literal, TypeAlias

from .immutability import freeze_data


# ``None`` is the broad explicit default (both families); it is intentionally
# distinct from the narrow marker-based ``auto`` mode.
FrameworkMode: TypeAlias = Literal["spring", "jaxrx", "auto"] | None


def _read_path(value: SourceFile | os.PathLike[str] | str) -> SourceFile:
    """Coerce a path-like value into the typed source-identity wrapper."""

    return value if isinstance(value, SourceFile) else SourceFile(os.fspath(value))


class FrameworkSelection(str, Enum):
    """One normalized analyzer family selected by orchestration.

    ``JAX_RS`` is the internal concept; its value is the externally supported
    ``jaxrx`` CLI token.
    """

    SPRING = "spring"
    JAX_RS = "jaxrx"


@dataclass(frozen=True, slots=True)
class AnalysisRequest:
    """Resolved analysis intent, independent of CLI and output destinations.

    This value normalizes identity but does not require the root to exist; the
    CLI owns that user-input validation, while programmatic callers may define
    their own source edge.
    """

    analysis_root: Path
    framework_mode: FrameworkMode = None

    def __post_init__(self) -> None:
        """Freeze a canonical root and validate the requested framework mode."""

        root = Path(self.analysis_root).expanduser().resolve()
        if self.framework_mode not in (None, "spring", "jaxrx", "auto"):
            raise ValueError(f"unsupported framework mode: {self.framework_mode!r}")
        object.__setattr__(self, "analysis_root", root)


@dataclass(frozen=True, slots=True)
class FrameworkPlan:
    """Requested framework policy and its effective ordered analyzer set.

    Keeping both answers makes it possible to distinguish an explicit/default
    run from ``auto`` even when they happen to select the same families.
    """

    requested_mode: FrameworkMode
    selected: tuple[FrameworkSelection, ...] = ()

    def __post_init__(self) -> None:
        """Normalize selections and reject duplicate analyzer execution."""

        if self.requested_mode not in (None, "spring", "jaxrx", "auto"):
            raise ValueError(f"unsupported framework mode: {self.requested_mode!r}")
        selected = tuple(FrameworkSelection(item) for item in self.selected)
        if len(set(selected)) != len(selected):
            raise ValueError("a framework may be selected only once")
        object.__setattr__(self, "selected", selected)


@dataclass(frozen=True, slots=True, order=True)
class SourceFile:
    """An analysis-owned source name before presentation relativizes it.

    The wrapper prevents a source identity from being confused with arbitrary
    strings while remaining accepted by normal path APIs.
    """

    path: str

    def __post_init__(self) -> None:
        """Normalize a path-like input to a non-empty string identity."""

        path = os.fspath(self.path)
        if not isinstance(path, str) or not path:
            raise ValueError("source file path must be a non-empty string")
        object.__setattr__(self, "path", path)

    def __fspath__(self) -> str:
        """Expose the source identity to standard filesystem APIs."""

        return self.path

    def __str__(self) -> str:
        """Expose the source identity as its ordinary string spelling."""

        return self.path


@dataclass(frozen=True, slots=True, order=True)
class SourceSpan:
    """An exact half-open byte span in one snapshotted source file.

    Byte offsets, rather than rows or names, provide stable declaration
    identity compatible with Tree-sitter and represented-target reports.
    """

    source_file: SourceFile
    start_byte: int
    end_byte: int

    def __post_init__(self) -> None:
        """Coerce source identity and enforce a real non-empty byte interval."""

        object.__setattr__(self, "source_file", _read_path(self.source_file))
        if (
            isinstance(self.start_byte, bool)
            or isinstance(self.end_byte, bool)
            or not isinstance(self.start_byte, int)
            or not isinstance(self.end_byte, int)
            or self.start_byte < 0
            or self.end_byte <= self.start_byte
        ):
            raise ValueError("source span must satisfy 0 <= start_byte < end_byte")


@dataclass(frozen=True, slots=True, order=True)
class SourceTarget:
    """A source declaration represented by an endpoint fact.

    Combining declaration kind with its exact span lets reports subtract a
    method, record component, or type without retaining parser objects or
    guessing from annotation/handler names.
    """

    kind: str
    span: SourceSpan

    def __post_init__(self) -> None:
        """Require an explicit declaration kind and already-validated span."""

        if not isinstance(self.kind, str) or not self.kind:
            raise ValueError("source target kind must be a non-empty string")
        if not isinstance(self.span, SourceSpan):
            raise TypeError("source target span must be a SourceSpan")


@dataclass(frozen=True, slots=True)
class AnnotationEvidence:
    """Scalar request-method provenance retained for CSV line selection.

    Validation of family, line, and same-file ownership occurs in
    :mod:`noir.evidence`; this value ensures parser nodes never cross the typed
    application boundary.
    """

    line: int
    identity: str
    family: str
    source_file: SourceFile

    def __post_init__(self) -> None:
        """Coerce the path-like source identity to :class:`SourceFile`."""

        object.__setattr__(self, "source_file", _read_path(self.source_file))


@dataclass(frozen=True, slots=True)
class EndpointFact:
    """One rich analyzer fact before the intentionally lossy output boundary.

    Route declaration, concrete handler, and configuration owner are separate
    provenance identities because inherited/project routes can span files.
    ``source_line`` is analyzer diagnostic context, not the CSV annotation
    line. ``annotation_evidence`` and ``represented_targets`` carry the two
    private correctness channels used after public projection. Spring
    HTTP-interface path layers remain explicit until project configuration
    resolves them.
    """

    path: str
    method: str
    parameters: str
    source_file: SourceFile
    handler_name: str
    source_line: int | None = None
    route_source_file: SourceFile | None = None
    route_source_line: int | None = None
    handler_source_file: SourceFile | None = None
    handler_source_line: int | None = None
    project_source_file: SourceFile | None = None
    technology: str | None = None
    protocol: str = "http"
    surface: str = "server"
    direction: str | None = None
    annotation_evidence: tuple[AnnotationEvidence, ...] = ()
    represented_targets: tuple[SourceTarget, ...] = ()
    spring_client_path_layers: tuple[str, ...] | None = None

    def __post_init__(self) -> None:
        """Normalize path-like identities and seal every nested collection."""

        object.__setattr__(self, "source_file", _read_path(self.source_file))
        for name in (
            "route_source_file",
            "handler_source_file",
            "project_source_file",
        ):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(self, name, _read_path(value))

        if isinstance(self.annotation_evidence, Mapping):
            raise TypeError("annotation evidence must contain AnnotationEvidence values")
        evidence = tuple(self.annotation_evidence)
        if not all(isinstance(item, AnnotationEvidence) for item in evidence):
            raise TypeError("annotation evidence must contain AnnotationEvidence values")

        if isinstance(self.represented_targets, Mapping):
            raise TypeError("represented targets must contain SourceTarget values")
        targets = tuple(self.represented_targets)
        if not all(isinstance(item, SourceTarget) for item in targets):
            raise TypeError("represented targets must contain SourceTarget values")

        path_layers = self.spring_client_path_layers
        if isinstance(path_layers, (str, bytes)):
            raise TypeError("Spring client path layers must be a sequence of strings")
        if path_layers is not None:
            path_layers = tuple(path_layers)
            if not all(isinstance(layer, str) for layer in path_layers):
                raise TypeError("Spring client path layers must contain strings")

        object.__setattr__(self, "annotation_evidence", evidence)
        object.__setattr__(self, "represented_targets", targets)
        object.__setattr__(self, "spring_client_path_layers", path_layers)


@dataclass(frozen=True, slots=True)
class AnalysisDiagnostic:
    """One presentation-neutral event produced while proving source facts.

    Timestamping and line rendering belong to run-local diagnostic capture;
    optional span/category data can therefore remain deterministic domain data.
    """

    message: str
    severity: str = "info"
    source: SourceSpan | None = None
    category: str | None = None


@dataclass(frozen=True, slots=True)
class AnalysisResult:
    """Complete immutable handoff from analysis to presentation boundaries.

    Endpoint facts and structured diagnostics are accompanied by the selected
    framework plan, broad annotation inventory, final-trigger inventory, raw
    auto detections, and stdout announcements.  These parallel views cannot be
    reconstructed from the intentionally lossy endpoint CSV alone.
    """

    endpoints: tuple[EndpointFact, ...] = ()
    diagnostics: tuple[AnalysisDiagnostic, ...] = ()
    framework_plan: FrameworkPlan | None = None
    annotation_audit_inventory: tuple[Any, ...] = ()
    final_trigger_inventory: tuple[Any, ...] = ()
    detections: tuple[Any, ...] = ()
    announcements: tuple[Any, ...] = ()

    def __post_init__(self) -> None:
        """Snapshot every collection so callers cannot mutate a completed run."""

        endpoints = tuple(self.endpoints)
        if not all(isinstance(item, EndpointFact) for item in endpoints):
            raise TypeError("analysis endpoints must contain EndpointFact values")
        diagnostics = tuple(self.diagnostics)
        if not all(isinstance(item, AnalysisDiagnostic) for item in diagnostics):
            raise TypeError("analysis diagnostics must contain AnalysisDiagnostic values")
        object.__setattr__(self, "endpoints", endpoints)
        object.__setattr__(self, "diagnostics", diagnostics)
        for name in (
            "annotation_audit_inventory",
            "final_trigger_inventory",
            "detections",
            "announcements",
        ):
            object.__setattr__(
                self,
                name,
                tuple(freeze_data(item) for item in getattr(self, name)),
            )


__all__ = [
    "AnalysisDiagnostic",
    "AnalysisRequest",
    "AnalysisResult",
    "AnnotationEvidence",
    "EndpointFact",
    "FrameworkMode",
    "FrameworkPlan",
    "FrameworkSelection",
    "SourceFile",
    "SourceSpan",
    "SourceTarget",
]
