"""Small framework-neutral helpers for reading the shared Java syntax tree.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

from typing import Any, Iterable, Mapping

from .java_frontend import child_by_field, resolve_known_type, tree_node_key


def source_text(unit: Mapping[str, Any], node: Any) -> str:
    """Read a syntax node from the exact Java source retained by its unit.

    ``unit`` represents one parsed ``.java`` file; ``node`` represents one
    source occurrence in that file, such as a route path literal.

    Example call:
        For a unit whose source is ``b'@Path("/items")'`` and the string-literal
        node spanning ``"/items"``, ``source_text(unit, node)`` returns
        ``'"/items"'``.
    """

    return unit["source"][node.start_byte : node.end_byte].decode("utf8")


def field(node: Any, name: str) -> Any:
    """Read one meaningful child role from a Java syntax node.

    A field name describes the child's application role, rather than its
    position among punctuation.  For example, ``"name"`` identifies the
    declared name of a method and ``"body"`` identifies its implementation.

    Example call:
        ``field(method_node, "name")`` returns the node spelling ``list`` for
        ``Response list() { ... }``; it returns ``None`` if recovery produced
        no trustworthy name field.
    """

    return child_by_field(node, name)


def walk_named(node: Any) -> Iterable[Any]:
    """Yield the meaningful nodes below one Java construct in source order.

    Named nodes represent application constructs such as annotations, calls,
    and declarations; punctuation-only children are omitted.

    Example call:
        ``list(walk_named(method_node))`` starts with ``method_node`` and then
        contains its return type, name, parameters, body, and nested constructs
        in deterministic preorder.
    """

    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


def raw_type_node(node: Any) -> Any:
    """Remove supported generic/annotation wrappers from a Java type use.

    Unsupported or excessively nested shapes return ``None`` so callers do
    not infer a framework type from a partially understood syntax tree.

    Example call:
        Given the type use ``@Valid List<String>``,
        ``raw_type_node(annotated_type_node)`` returns the node spelling
        ``List`` after removing the annotation and type arguments.  An
        ambiguous recovered wrapper returns ``None``.
    """

    current = node
    for _depth in range(16):
        if current is None:
            return None
        if current.type == "generic_type":
            children = list(current.named_children)
            current = children[0] if children else None
            continue
        if current.type == "annotated_type":
            candidates = [
                child for child in current.named_children if child.type != "annotation"
            ]
            current = candidates[-1] if len(candidates) == 1 else None
            continue
        return current
    return None


def known_type(
    unit: Mapping[str, Any],
    node: Any,
    simple_name: str,
    package: str,
) -> bool:
    """Prove that a type use denotes one exact known-library Java type.

    ``simple_name`` is the expected short spelling and ``package`` is its
    trusted library namespace.  Local types and conflicting imports prevent a
    match, even when the visible text happens to be the expected short name.

    Example call:
        With ``import java.util.List;`` in ``unit`` and ``node`` spelling
        ``List<String>``, ``known_type(unit, node, "List", "java.util")`` is
        ``True``.  It is ``False`` when the same unit declares its own ``List``.
    """

    raw = raw_type_node(node)
    return bool(
        raw is not None
        and resolve_known_type(
            unit, source_text(unit, raw), simple_name, (package,), raw
        )
        == package
    )


def direct_interface_types(type_node: Any) -> list[Any]:
    """Return interfaces named directly by one source type declaration.

    Inherited interfaces of parents are deliberately absent; hierarchy logic
    can traverse those separately without confusing direct source evidence.

    Example call:
        For ``class Items implements Api, Audited {}``,
        ``direct_interface_types(type_node)`` returns the nodes spelling
        ``Api`` and ``Audited``.
    """

    interfaces = field(type_node, "interfaces")
    if interfaces is None:
        return []
    children = list(interfaces.named_children)
    if len(children) == 1 and children[0].type == "type_list":
        return list(children[0].named_children)
    return children


def is_direct_invocation_statement(invocation: Any, body: Any) -> bool:
    """Prove a fluent invocation chain is a direct method-body statement.

    Route DSL analyzers use this boundary to exclude invocations nested in an
    assignment, return value, lambda, or another expression whose execution
    and ownership they cannot establish from local syntax.

    Example call:
        In ``void routes() { app.get("/items", handler); }``, calling
        ``is_direct_invocation_statement(get_call, routes_body)`` returns
        ``True``.  For ``var route = app.get("/items", handler);`` it returns
        ``False``.
    """

    current = invocation
    while getattr(current, "parent", None) is not None:
        parent = current.parent
        if parent.type != "method_invocation":
            break
        receiver = field(parent, "object")
        if receiver is None or (
            receiver.start_byte,
            receiver.end_byte,
        ) != (current.start_byte, current.end_byte):
            break
        current = parent
    statement = getattr(current, "parent", None)
    return bool(
        statement is not None
        and statement.type == "expression_statement"
        and getattr(statement, "parent", None) is not None
        and tree_node_key(statement.parent) == tree_node_key(body)
    )


__all__ = [
    "direct_interface_types",
    "field",
    "is_direct_invocation_statement",
    "known_type",
    "raw_type_node",
    "source_text",
    "walk_named",
]
