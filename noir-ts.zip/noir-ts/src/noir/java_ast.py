"""Small framework-neutral helpers for reading the shared Java syntax tree.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

from typing import Any, Iterable, Mapping

from .java_frontend import child_by_field, resolve_known_type, tree_node_key


def source_text(unit: Mapping[str, Any], node: Any) -> str:
    """Read a node from the exact source bytes retained by its unit."""

    return unit["source"][node.start_byte : node.end_byte].decode("utf8")


def field(node: Any, name: str) -> Any:
    """Read one guarded Tree-sitter field."""

    return child_by_field(node, name)


def walk_named(node: Any) -> Iterable[Any]:
    """Yield a syntax subtree in deterministic source-oriented preorder."""

    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


def raw_type_node(node: Any) -> Any:
    """Remove supported generic/annotation wrappers from a Java type use.

    Unsupported or excessively nested shapes return ``None`` so callers do
    not infer a framework type from a partially understood syntax tree.
    """

    current = node
    for _depth in range(16):
        if current is None:
            return None
        if current.type == "generic_type":
            children = list(current.named_children)
            current = children[0] if children else None
            continue
        if current.type == "annotated_type":
            candidates = [
                child for child in current.named_children if child.type != "annotation"
            ]
            current = candidates[-1] if len(candidates) == 1 else None
            continue
        return current
    return None


def known_type(
    unit: Mapping[str, Any],
    node: Any,
    simple_name: str,
    package: str,
) -> bool:
    """Prove that ``node`` denotes one exact known-library Java type."""

    raw = raw_type_node(node)
    return bool(
        raw is not None
        and resolve_known_type(
            unit, source_text(unit, raw), simple_name, (package,), raw
        )
        == package
    )


def direct_interface_types(type_node: Any) -> list[Any]:
    """Return only interfaces declared directly on one source type."""

    interfaces = field(type_node, "interfaces")
    if interfaces is None:
        return []
    children = list(interfaces.named_children)
    if len(children) == 1 and children[0].type == "type_list":
        return list(children[0].named_children)
    return children


def is_direct_invocation_statement(invocation: Any, body: Any) -> bool:
    """Prove a fluent invocation chain is a direct method-body statement.

    Route DSL analyzers use this boundary to exclude invocations nested in an
    assignment, return value, lambda, or another expression whose execution
    and ownership they cannot establish from local syntax.
    """

    current = invocation
    while getattr(current, "parent", None) is not None:
        parent = current.parent
        if parent.type != "method_invocation":
            break
        receiver = field(parent, "object")
        if receiver is None or (
            receiver.start_byte,
            receiver.end_byte,
        ) != (current.start_byte, current.end_byte):
            break
        current = parent
    statement = getattr(current, "parent", None)
    return bool(
        statement is not None
        and statement.type == "expression_statement"
        and getattr(statement, "parent", None) is not None
        and tree_node_key(statement.parent) == tree_node_key(body)
    )


__all__ = [
    "direct_interface_types",
    "field",
    "is_direct_invocation_statement",
    "known_type",
    "raw_type_node",
    "source_text",
    "walk_named",
]
