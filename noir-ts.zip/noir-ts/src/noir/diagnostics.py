"""Run-local diagnostic capture, independent of report persistence.

Collectors own their entries. The binding only selects the collector for the
current execution context, which keeps nested analyses and concurrent tasks
isolated from one another.

Logic guide: ``p6.logic/02-cli-and-orchestration.md`` (run-local diagnostics)
and ``p6.logic/07-output-evidence-reports.md``.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime
from threading import RLock
from typing import Callable, Iterator

from .model import AnalysisDiagnostic, EndpointFact


# Injected time is a presentation concern; AnalysisDiagnostic itself remains
# deterministic and timestamp-free.
Clock = Callable[[], datetime]
_TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"


@dataclass(frozen=True, slots=True)
class DiagnosticEntry:
    """One immutable, timestamped diagnostic captured during an analysis."""

    timestamp: datetime
    diagnostic: AnalysisDiagnostic

    @property
    def message(self) -> str:
        """Expose the captured domain message."""

        return self.diagnostic.message

    @property
    def rendered_line(self) -> str:
        """Render the byte-for-byte line shape used by the existing report."""

        return f"{self.timestamp.strftime(_TIMESTAMP_FORMAT)} {self.message}"


class DiagnosticCollector:
    """Thread-safe, in-memory diagnostic state owned by one analysis run."""

    def __init__(self, clock: Clock | None = None) -> None:
        """Create isolated capture state, optionally with a deterministic clock."""

        self._clock = datetime.now if clock is None else clock
        self._entries: list[DiagnosticEntry] = []
        self._lock = RLock()

    def record(self, message: str) -> DiagnosticEntry:
        """Capture ``message`` and return its structured immutable entry."""

        if not isinstance(message, str):
            raise TypeError("diagnostic message must be a string")
        with self._lock:
            entry = DiagnosticEntry(
                timestamp=self._clock(),
                diagnostic=AnalysisDiagnostic(message=message),
            )
            self._entries.append(entry)
            return entry

    @property
    def entries(self) -> tuple[DiagnosticEntry, ...]:
        """Return an immutable snapshot in capture order."""

        with self._lock:
            return tuple(self._entries)

    @property
    def rendered_lines(self) -> tuple[str, ...]:
        """Return report-compatible lines in capture order."""

        return tuple(entry.rendered_line for entry in self.entries)

    def captured(self, message: str) -> bool:
        """Whether this collector contains the exact diagnostic message."""

        with self._lock:
            return any(entry.message == message for entry in self._entries)

    def __len__(self) -> int:
        """Return the current entry count used to delimit nested run slices."""

        with self._lock:
            return len(self._entries)


# Context-local selection avoids the cross-run contamination of a process-wide
# active buffer; each selected collector still protects its own mutable list.
_current_collector: ContextVar[DiagnosticCollector | None] = ContextVar(
    "noir_current_diagnostic_collector",
    default=None,
)


def current() -> DiagnosticCollector | None:
    """Return the collector bound to this execution context, if any."""

    return _current_collector.get()


@contextmanager
def bind(collector: DiagnosticCollector) -> Iterator[DiagnosticCollector]:
    """Bind ``collector`` here and restore the previous binding on exit."""

    if not isinstance(collector, DiagnosticCollector):
        raise TypeError("collector must be a DiagnosticCollector")
    token = _current_collector.set(collector)
    try:
        yield collector
    finally:
        _current_collector.reset(token)


def record(message: str) -> None:
    """Capture in the bound collector, or harmlessly do nothing when unbound."""

    collector = current()
    if collector is None:
        return
    collector.record(message)


def format_endpoint_diagnostic(endpoint_fact: EndpointFact) -> str:
    """Render the stable accepted-endpoint diagnostic used by analyzers.

    This is intentionally based on analyzer-local ``source_line`` rather than
    the independently validated public ``method_annotation_line`` evidence.
    """

    if not isinstance(endpoint_fact, EndpointFact):
        raise TypeError("endpoint diagnostics require an EndpointFact")
    return " ".join(
        str(value)
        for value in (
            endpoint_fact.source_line,
            endpoint_fact.method,
            endpoint_fact.path,
            endpoint_fact.handler_name,
            endpoint_fact.parameters,
        )
    )


__all__ = [
    "DiagnosticCollector",
    "DiagnosticEntry",
    "bind",
    "current",
    "format_endpoint_diagnostic",
    "record",
]
