"""Run-local diagnostic capture, independent of report persistence.

Collectors own their entries. The binding only selects the collector for the
current execution context, which keeps nested analyses and concurrent tasks
isolated from one another.

Logic guide: ``p6.logic/02-cli-and-orchestration.md`` (run-local diagnostics)
and ``p6.logic/07-output-evidence-reports.md``.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime
from threading import RLock
from typing import Callable, Iterator

from .model import AnalysisDiagnostic, EndpointFact


# Injected time is a presentation concern; AnalysisDiagnostic itself remains
# deterministic and timestamp-free.
Clock = Callable[[], datetime]
_TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"


@dataclass(frozen=True, slots=True)
class DiagnosticEntry:
    """One immutable, timestamped diagnostic captured during an analysis."""

    # Capture time used only when the user-facing diagnostic line is rendered.
    timestamp: datetime
    # Presentation-neutral analysis event recorded at that instant.
    diagnostic: AnalysisDiagnostic

    # Example value:
    # DiagnosticEntry(datetime(2026, 9, 3, 12, 0),
    #                 AnalysisDiagnostic("Skipped ambiguous mapping"))

    @property
    def message(self) -> str:
        """Expose the captured application-analysis message.

        Example call:
            ``entry.message`` returns ``"Skipped ambiguous mapping"`` for an
            entry holding that ``AnalysisDiagnostic``.
        """

        return self.diagnostic.message

    @property
    def rendered_line(self) -> str:
        """Render the timestamped line written to the diagnostic report.

        Example call:
            ``entry.rendered_line`` returns
            ``"2026-09-03 12:00:00 Skipped ambiguous mapping"`` for the worked
            ``DiagnosticEntry`` value above.
        """

        return f"{self.timestamp.strftime(_TIMESTAMP_FORMAT)} {self.message}"


class DiagnosticCollector:
    """Thread-safe, in-memory diagnostic state owned by one analysis run.

    Application state:
        ``_clock`` timestamps rendered entries, ``_entries`` is the ordered
        run-local event buffer, and ``_lock`` prevents concurrent callers from
        observing a partial update.

    Example value:
        ``DiagnosticCollector(clock=lambda: datetime(2026, 9, 3, 12, 0))``
        is an empty collector for one analysis invocation.
    """

    def __init__(self, clock: Clock | None = None) -> None:
        """Create isolated capture state, optionally with a supplied clock.

        Example call:
            ``DiagnosticCollector(clock=lambda: datetime(2026, 9, 3, 12, 0))``
            creates an empty run-local collector with deterministic timestamps.
        """

        self._clock = datetime.now if clock is None else clock
        self._entries: list[DiagnosticEntry] = []
        self._lock = RLock()

    def record(self, message: str) -> DiagnosticEntry:
        """Capture one analysis event and return its immutable entry.

        Example call:
            ``collector.record("Skipped ambiguous mapping")`` appends one entry
            stamped by the collector's clock and returns that entry.
        """

        if not isinstance(message, str):
            raise TypeError("diagnostic message must be a string")
        with self._lock:
            entry = DiagnosticEntry(
                timestamp=self._clock(),
                diagnostic=AnalysisDiagnostic(message=message),
            )
            self._entries.append(entry)
            return entry

    @property
    def entries(self) -> tuple[DiagnosticEntry, ...]:
        """Return an immutable snapshot of run events in capture order.

        Example call:
            ``collector.entries`` returns ``(first_entry, second_entry)`` after
            those two events were recorded.
        """

        with self._lock:
            return tuple(self._entries)

    @property
    def rendered_lines(self) -> tuple[str, ...]:
        """Return timestamped report lines in event order.

        Example call:
            ``collector.rendered_lines`` returns a tuple such as
            ``("2026-09-03 12:00:00 GET /items Items.list",)``.
        """

        return tuple(entry.rendered_line for entry in self.entries)

    def captured(self, message: str) -> bool:
        """Report whether this run captured an exact analysis message.

        Example call:
            ``collector.captured("Skipped ambiguous mapping")`` returns ``True``
            only when that complete message has been recorded.
        """

        with self._lock:
            return any(entry.message == message for entry in self._entries)

    def __len__(self) -> int:
        """Return the event count used to delimit nested analysis slices.

        Example call:
            ``len(collector)`` returns ``2`` after two diagnostic events.
        """

        with self._lock:
            return len(self._entries)


# Context-local selection avoids the cross-run contamination of a process-wide
# active buffer; each selected collector still protects its own mutable list.
_current_collector: ContextVar[DiagnosticCollector | None] = ContextVar(
    "noir_current_diagnostic_collector",
    default=None,
)


def current() -> DiagnosticCollector | None:
    """Return this execution context's active run collector, if any.

    Example call:
        Inside ``with bind(collector):``, ``current()`` returns ``collector``;
        outside a binding it returns ``None``.
    """

    return _current_collector.get()


@contextmanager
def bind(collector: DiagnosticCollector) -> Iterator[DiagnosticCollector]:
    """Select a run collector here and restore the previous one on exit.

    Example call:
        ``with bind(collector): record("GET /items Items.list")`` captures the
        message in ``collector`` without changing another concurrent run.
    """

    if not isinstance(collector, DiagnosticCollector):
        raise TypeError("collector must be a DiagnosticCollector")
    token = _current_collector.set(collector)
    try:
        yield collector
    finally:
        _current_collector.reset(token)


def record(message: str) -> None:
    """Capture an event in the active run, or do nothing when unbound.

    Example call:
        ``record("42 GET /items ItemsController.list (String filter)")`` appends
        that accepted-endpoint event when a collector is currently bound.
    """

    collector = current()
    if collector is None:
        return
    collector.record(message)


def format_endpoint_diagnostic(endpoint_fact: EndpointFact) -> str:
    """Render the stable accepted-endpoint diagnostic used by analyzers.

    This is intentionally based on analyzer-local ``source_line`` rather than
    the independently validated public ``method_annotation_line`` evidence.

    Example call:
        ``format_endpoint_diagnostic(endpoint)`` returns a value such as
        ``"42 GET /items ItemsController.list (String filter)"`` for an
        ``EndpointFact`` carrying those application values.
    """

    if not isinstance(endpoint_fact, EndpointFact):
        raise TypeError("endpoint diagnostics require an EndpointFact")
    return " ".join(
        str(value)
        for value in (
            endpoint_fact.source_line,
            endpoint_fact.method,
            endpoint_fact.path,
            endpoint_fact.handler_name,
            endpoint_fact.parameters,
        )
    )


__all__ = [
    "DiagnosticCollector",
    "DiagnosticEntry",
    "bind",
    "current",
    "format_endpoint_diagnostic",
    "record",
]
