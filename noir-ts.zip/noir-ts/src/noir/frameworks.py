"""Static framework composition records used by the analysis pipeline.

The registry is deliberately explicit: adding a shipped framework means adding
one family facade and one visible entry here.  It provides deterministic order
without dynamic discovery, framework-to-framework imports, or a service
container.

Logic guides: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/16-adding-framework-support.md``.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, TypeAlias

from .jaxrs_framework import (
    analyze_jaxrs_framework,
    configure_jaxrs_workspace,
    prepare_jaxrs_analysis,
)
from .model import AnalysisRequest, EndpointFact, FrameworkPlan, FrameworkSelection
from .spring_framework import (
    analyze_spring_framework,
    configure_spring_workspace,
    prepare_spring_analysis,
)
from .wicket_framework import (
    analyze_wicket_framework,
    configure_wicket_workspace,
    prepare_wicket_analysis,
)


# ``Callable`` cannot express the keyword-only ``selected`` argument; the
# named alias and every facade signature make that one configuration contract
# visible without introducing protocol classes solely for typing machinery.
ConfigureWorkspace: TypeAlias = Callable[..., None]
PrepareAnalysis: TypeAlias = Callable[[AnalysisRequest, dict[str, Any]], None]
AnalyzeFramework: TypeAlias = Callable[
    [AnalysisRequest, tuple[str, ...], dict[str, Any]],
    tuple[EndpointFact, ...],
]


@dataclass(frozen=True, slots=True)
class FrameworkAdapter:
    """One framework family's complete composition-root contract.

    Every registered adapter has one public normalized selection identity.
    Configuration may run for either selection state; preparation and analysis
    belong only to selected adapters. Default and auto selection remain
    separate policy decisions.

    Example value:
        ``FrameworkAdapter("wicket", FrameworkSelection.WICKET,
        "Found Apache Wicket", False, analyze_wicket_framework)`` describes
        the selectable but non-default Wicket integration stub.
    """

    # Stable internal/report-section name, normally equal to the public token.
    name: str
    # Public normalized analyzer identity for this executable family.
    selection: FrameworkSelection
    # Announcement for a non-auto selection, including omitted/default mode.
    announcement: str
    # Whether omitted ``--framework`` includes this adapter.
    default_selected: bool
    # Family-owned endpoint orchestration; every registered adapter supplies it.
    analyze: AnalyzeFramework
    # Optional setup called for both selected and unselected registry entries.
    configure_workspace: ConfigureWorkspace | None = None
    # Optional project preparation called only after inventories for selections.
    prepare_analysis: PrepareAnalysis | None = None

    def __post_init__(self) -> None:
        """Normalize the identity and reject an unusable adapter record.

        Example call:
            Constructing an adapter with ``selection=None`` raises
            ``ValueError`` instead of creating an unreachable registry row.
        """

        if (
            not isinstance(self.name, str)
            or not self.name
            or self.name.strip() != self.name
        ):
            raise ValueError("framework adapter name must be a non-empty stable token")
        try:
            selection = FrameworkSelection(self.selection)
        except (TypeError, ValueError) as error:
            raise ValueError(
                "framework adapter requires a valid selection identity"
            ) from error
        object.__setattr__(self, "selection", selection)
        if not isinstance(self.announcement, str) or not self.announcement:
            raise ValueError("framework adapter announcement must be non-empty")
        if not callable(self.analyze):
            raise TypeError("framework adapter analyze hook must be callable")
        for name in ("configure_workspace", "prepare_analysis"):
            hook = getattr(self, name)
            if hook is not None and not callable(hook):
                raise TypeError(f"framework adapter {name} hook must be callable")


def _validated_adapters(
    adapters: tuple[FrameworkAdapter, ...],
) -> tuple[FrameworkAdapter, ...]:
    """Reject duplicate registry identities while preserving tuple order.

    Example call:
        ``_validated_adapters((spring_adapter, jaxrs_adapter))`` returns that
        same ordered tuple when their names and selection identities are unique.
    """

    if not all(isinstance(adapter, FrameworkAdapter) for adapter in adapters):
        raise TypeError("framework registry must contain FrameworkAdapter values")
    names = tuple(adapter.name for adapter in adapters)
    if len(set(names)) != len(names):
        raise ValueError("framework adapter names must be unique")
    selections = tuple(adapter.selection for adapter in adapters)
    if len(set(selections)) != len(selections):
        raise ValueError("framework adapter selection identities must be unique")
    return adapters


# This tuple is the sole execution/default order.  The separate marker registry
# in ``noir.discovery`` continues to own raw detector and auto-announcement order.
FRAMEWORK_ADAPTERS = _validated_adapters(
    (
        FrameworkAdapter(
            name="spring",
            selection=FrameworkSelection.SPRING,
            announcement="Found SpringBoot Annotation",
            default_selected=True,
            configure_workspace=configure_spring_workspace,
            prepare_analysis=prepare_spring_analysis,
            analyze=analyze_spring_framework,
        ),
        FrameworkAdapter(
            name="jaxrx",
            selection=FrameworkSelection.JAX_RS,
            announcement="Found JaxRS",
            default_selected=True,
            configure_workspace=configure_jaxrs_workspace,
            prepare_analysis=prepare_jaxrs_analysis,
            analyze=analyze_jaxrs_framework,
        ),
        FrameworkAdapter(
            name="wicket",
            selection=FrameworkSelection.WICKET,
            announcement="Found Apache Wicket",
            default_selected=False,
            configure_workspace=configure_wicket_workspace,
            prepare_analysis=prepare_wicket_analysis,
            analyze=analyze_wicket_framework,
        ),
    )
)


def default_framework_selections() -> tuple[FrameworkSelection, ...]:
    """Return default analyzer identities in execution-registry order.

    Example call:
        ``default_framework_selections()`` returns ``(SPRING, JAX_RS)`` and
        excludes the explicitly selectable, non-default Wicket stub.
    """

    return tuple(
        adapter.selection
        for adapter in FRAMEWORK_ADAPTERS
        if adapter.default_selected
    )


def adapters_for_plan(plan: FrameworkPlan) -> tuple[FrameworkAdapter, ...]:
    """Map a framework plan to adapters in authoritative registry order.

    A plan cannot silently select a family missing from the registry.  Its own
    tuple order is not execution order; this registry supplies that order.

    Example call:
        ``adapters_for_plan(FrameworkPlan("jaxrx", (JAX_RS,)))`` returns only
        the JAX-RS adapter, while an empty auto plan returns ``()``.
    """

    if not isinstance(plan, FrameworkPlan):
        raise TypeError("framework adapter lookup requires a FrameworkPlan")
    selected = set(plan.selected)
    adapters = tuple(
        adapter
        for adapter in FRAMEWORK_ADAPTERS
        if adapter.selection in selected
    )
    mapped = {adapter.selection for adapter in adapters}
    if mapped != selected:
        missing = ", ".join(sorted(item.value for item in selected - mapped))
        raise ValueError(f"framework plan contains unregistered selections: {missing}")
    return adapters


__all__ = [
    "FRAMEWORK_ADAPTERS",
    "FrameworkAdapter",
    "adapters_for_plan",
    "default_framework_selections",
]
