"""JAX-RS family setup, preparation, and ordered endpoint analysis.

The application pipeline calls these small facade functions through the
framework registry.  This module owns JAX-RS orchestration and imports no
Spring implementation, while the individual semantic analyzers retain their
existing responsibilities.

Logic guide: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/06-jax-rs.md``.
"""

from __future__ import annotations

from typing import Any

from .diagnostics import record
from .java_websocket import analyze_java_websocket_endpoints
from .jaxrs import (
    analyze_direct_jax_rs_unit,
    attach_workspace_indexes,
    clear_workspace_indexes,
)
from .jaxrs_deployment import build_jax_rs_deployment_model
from .jaxrs_hierarchy import analyze_jax_rs_hierarchy_and_subresources
from .model import AnalysisRequest, EndpointFact


def configure_jaxrs_workspace(
    workspace: dict[str, Any], *, selected: bool
) -> None:
    """Install the selected or disabled JAX-RS workspace shape.

    Every framework receives this configuration phase.  A selected JAX-RS
    adapter indexes custom request designators and application paths; an
    unselected adapter installs empty keys so neutral inventory code can read
    one stable workspace shape without importing this family.

    Example call:
        ``configure_jaxrs_workspace(workspace, selected=True)`` attaches the
        JAX-RS indexes to the already parsed shared Java workspace.
    """

    if selected:
        attach_workspace_indexes(workspace)
    else:
        clear_workspace_indexes(workspace)


def prepare_jaxrs_analysis(
    request: AnalysisRequest, workspace: dict[str, Any]
) -> None:
    """Build deployment evidence before any selected family starts analysis.

    The registry invokes preparation only for selected adapters.  Keeping
    deployment construction here preserves the combined-run invariant that
    Spring analysis cannot begin before JAX-RS ``web.xml`` and application
    prefix evidence is ready.

    Example call:
        ``prepare_jaxrs_analysis(request, workspace)`` attaches the deployment
        model scoped to ``request.analysis_root``.
    """

    build_jax_rs_deployment_model(workspace, str(request.analysis_root))


def analyze_jaxrs_framework(
    _request: AnalysisRequest,
    source_paths: tuple[str, ...],
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Run direct, hierarchy/subresource, then Java WebSocket recognizers.

    Direct analysis follows immutable snapshot order and records the same
    source heading as the former pipeline-owned loop.  Project-wide passes run
    once when the shared workspace contains compilation units.  ``_request``
    is intentionally unused today but keeps one common adapter signature for
    frameworks that need request-level configuration.

    Example call:
        ``analyze_jaxrs_framework(request, source_paths, workspace)`` returns
        all JAX-RS and Java WebSocket facts as one ordered immutable tuple.
    """

    endpoints: list[EndpointFact] = []
    units = workspace.get("compilation_units", {})
    for source_path in source_paths:
        unit = units.get(source_path)
        if unit is None:
            continue
        record(f"{source_path}:")
        endpoints.extend(analyze_direct_jax_rs_unit(unit, workspace))
    if units:
        endpoints.extend(analyze_jax_rs_hierarchy_and_subresources(workspace))
        endpoints.extend(analyze_java_websocket_endpoints(workspace))
    return tuple(endpoints)


__all__ = [
    "analyze_jaxrs_framework",
    "configure_jaxrs_workspace",
    "prepare_jaxrs_analysis",
]
