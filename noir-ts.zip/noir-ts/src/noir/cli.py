"""Command-line parsing and ordered artifact publication.

Logic guide: ``p6.logic/02-cli-and-orchestration.md``.
"""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
from typing import Callable, Sequence

from .application import analyze
from .comparison import (
    compare_final_trigger_inventory,
    derive_noir_comparison_report_path,
    load_noir_report_locations,
    render_noir_comparison_report_bytes,
)
from .contracts import CSV_FIELDS
from .diagnostics import DiagnosticCollector, bind, record
from .model import FRAMEWORK_MODE_CHOICES, AnalysisRequest
from .output import (
    consolidate_endpoint_rows,
    endpoint_fact_to_row_candidate,
    write_endpoint_csv,
)
from .reports import (
    derive_annotations_without_endpoints_report_path,
    publish_bytes_atomically,
    render_annotations_without_endpoints_report_bytes,
    write_annotation_diagnostic_log,
)


def _same_existing_file(first: Path, second: Path) -> bool:
    """Report whether two existing paths identify the same artifact.

    Example call:
        ``_same_existing_file(Path("/tmp/noir.json"),
        Path("/tmp/alias.json"))`` returns ``True`` when ``alias.json`` is a
        link to the same report, and ``False`` for missing or distinct files.
    """

    try:
        return first.samefile(second)
    except OSError:
        return False


def build_argument_parser() -> argparse.ArgumentParser:
    """Build the command parser without loading analysis dependencies.

    Example call:
        ``build_argument_parser().parse_args(["--path", "/workspace/shop",
        "--output", "/tmp/endpoints.csv", "--framework", "spring",
        "--framework", "wicket"])`` returns arguments whose ``framework``
        value is ``["spring", "wicket"]``.
    """

    parser = argparse.ArgumentParser(
        description=(
            "Identify Java Spring Boot and JAX-RS HTTP endpoints from source "
            "with Tree-sitter"
        )
    )
    parser.add_argument(
        "--path",
        required=True,
        help="directory containing the application source code",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="path of the endpoint CSV file to create",
    )
    parser.add_argument(
        "--framework",
        action="append",
        choices=FRAMEWORK_MODE_CHOICES,
        help=(
            "analyze one registered framework; repeat for multiple frameworks; "
            "use auto alone to detect markers; omit to run Spring and JAX-RS"
        ),
    )
    parser.add_argument(
        "--noir-report",
        help=(
            "Noir v1.1 JSON report to compare with potential endpoint-trigger "
            "annotations by source path and annotation line"
        ),
    )
    return parser


def render_completion_summary(
    output_path,
    diagnostic_log_path,
    annotations_without_endpoints_report_path,
    *,
    noir_comparison_report_path=None,
    noir_report_path=None,
) -> str:
    """Render the successful-run artifact inventory for stdout.

    Example call:
        ``render_completion_summary("/tmp/endpoints.csv",
        "/tmp/endpoints.csv.log", "/tmp/endpoints-anno-without-endpoints.log")``
        returns text naming the three generated artifacts. Supplying both
        ``noir_comparison_report_path`` and ``noir_report_path`` adds the
        optional comparison output and its input report.
    """

    comparison_enabled = noir_comparison_report_path is not None
    if comparison_enabled != (noir_report_path is not None):
        raise ValueError(
            "noir comparison output and input paths must be supplied together"
        )
    lines = [
        "noir-ts analysis completed.",
        "",
        "Generated output files:",
        "",
        "  Endpoint inventory (CSV)",
        f"    Path: {Path(output_path)}",
        "    Detected endpoint rows produced by noir-ts.",
        "",
        "  Annotation and diagnostics log",
        f"    Path: {Path(diagnostic_log_path)}",
        "    Recognized annotations, source extracts, framework information,",
        "    and diagnostic messages collected during analysis.",
        "",
        "  Annotations without noir-ts endpoint rows",
        f"    Path: {Path(annotations_without_endpoints_report_path)}",
        "    Endpoint-trigger annotations whose Java declarations are not represented",
        "    by a surviving endpoint row in the noir-ts CSV.",
    ]
    if comparison_enabled:
        lines.extend(
            [
                "",
                "  Annotations without an exact Noir source-location match",
                f"    Path: {Path(noir_comparison_report_path)}",
                "    Endpoint-trigger noir-ts annotation occurrences without an exact",
                "    (canonical source file, annotation start line) match in the supplied",
                "    Noir report.",
                "    These entries are not necessarily endpoints missed by Noir.",
                "    Supporting annotations are excluded from this report.",
                "",
                "Comparison input (not generated by noir-ts):",
                "",
                "  Noir report",
                f"    Path: {Path(noir_report_path)}",
            ]
        )
    return "\n".join(lines) + "\n"


def run_cli(
    argv: Sequence[str] | None = None,
    *,
    clock: Callable[[], datetime] = datetime.now,
) -> int:
    """Analyze one application and publish all requested artifacts in order.

    Example call:
        ``run_cli(["--path", "/workspace/shop", "--output",
        "/tmp/endpoints.csv", "--framework", "spring", "--framework",
        "wicket"],
        clock=lambda: datetime(2026, 9, 3, 12, 0))`` returns ``0`` after writing
        the endpoint CSV, annotation/diagnostic log, and absent-trigger report.
    """

    parser = build_argument_parser()
    arguments = parser.parse_args(argv)
    input_path = Path(arguments.path).expanduser().resolve()
    if not input_path.is_dir():
        parser.error("--path must be an existing directory")

    requested_frameworks = arguments.framework
    if requested_frameworks is None:
        framework_mode = None
    elif len(requested_frameworks) == 1:
        framework_mode = requested_frameworks[0]
    else:
        framework_mode = tuple(requested_frameworks)
    try:
        request = AnalysisRequest(input_path, framework_mode=framework_mode)
    except ValueError as error:
        # Reject duplicate or mixed-auto selections before opening any output.
        parser.error(str(error))

    noir_report_path = None
    noir_report_locations = None
    if arguments.noir_report is not None:
        noir_report_path = Path(arguments.noir_report).expanduser().resolve()
        if not noir_report_path.is_file():
            parser.error("--noir-report must be an existing file")
        try:
            noir_report_locations = load_noir_report_locations(
                noir_report_path, input_path
            )
        except (OSError, ValueError) as error:
            parser.error(f"invalid --noir-report: {error}")

    output_path = Path(arguments.output).expanduser()
    diagnostic_log_path = f"{output_path}.log"
    absent_report_path = derive_annotations_without_endpoints_report_path(
        output_path
    )
    comparison_report_path = (
        derive_noir_comparison_report_path(output_path)
        if noir_report_locations is not None
        else None
    )
    if noir_report_locations is not None:
        destinations = {
            output_path.resolve(),
            Path(diagnostic_log_path).resolve(),
            Path(absent_report_path).resolve(),
            Path(comparison_report_path).resolve(),
        }
        if noir_report_path in destinations or any(
            _same_existing_file(noir_report_path, destination)
            for destination in destinations
        ):
            parser.error("--noir-report must not also be an output destination")

    # A controlled dependency/analysis failure must still leave a current log.
    with open(diagnostic_log_path, "w", encoding="utf8"):
        pass

    annotation_inventory = ()
    trigger_inventory = ()
    collector = DiagnosticCollector(clock=clock)
    with bind(collector):
        try:
            selected_mode = request.framework_mode
            if selected_mode is None:
                framework_label = "spring and jaxrx"
            elif isinstance(selected_mode, tuple):
                framework_label = ", ".join(selected_mode)
            else:
                framework_label = selected_mode
            record(f"Framework mode: {framework_label}")
            try:
                result = analyze(request)
                annotation_inventory = result.annotation_audit_inventory
                trigger_inventory = result.final_trigger_inventory
                for announcement in result.announcements:
                    print(announcement)
            except RuntimeError as error:
                record(f"ERROR: {error}")
                write_annotation_diagnostic_log(
                    diagnostic_log_path,
                    annotation_inventory,
                    collector.rendered_lines,
                )
                parser.error(str(error))

            candidates = tuple(
                endpoint_fact_to_row_candidate(
                    endpoint, input_path.name, str(input_path)
                )
                for endpoint in result.endpoints
            )
            finalized = consolidate_endpoint_rows(candidates)
            absent_report = render_annotations_without_endpoints_report_bytes(
                trigger_inventory,
                finalized.represented_targets,
            )
            comparison_report = None
            if noir_report_locations is not None:
                comparison = compare_final_trigger_inventory(
                    trigger_inventory,
                    noir_report_locations,
                    input_path,
                )
                comparison_report = render_noir_comparison_report_bytes(comparison)
            summary = render_completion_summary(
                output_path,
                diagnostic_log_path,
                absent_report_path,
                noir_comparison_report_path=comparison_report_path,
                noir_report_path=noir_report_path,
            )

            write_endpoint_csv(output_path, CSV_FIELDS, finalized.rows)
            write_annotation_diagnostic_log(
                diagnostic_log_path,
                annotation_inventory,
                collector.rendered_lines,
            )
            publish_bytes_atomically(absent_report_path, absent_report)
            if comparison_report_path is not None:
                publish_bytes_atomically(
                    comparison_report_path,
                    comparison_report,
                )
            print(summary, end="")
            return 0
        except Exception:
            try:
                write_annotation_diagnostic_log(
                    diagnostic_log_path,
                    annotation_inventory,
                    collector.rendered_lines,
                )
            except Exception:
                pass
            raise


main = run_cli


__all__ = [
    "build_argument_parser",
    "main",
    "render_completion_summary",
    "run_cli",
]
