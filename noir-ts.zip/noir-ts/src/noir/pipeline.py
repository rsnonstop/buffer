"""One-way orchestration from Java sources to typed endpoint facts.

Logic guide: ``p6.logic/02-cli-and-orchestration.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from .diagnostics import record
from .discovery import discover_java_files, scan_framework_markers
from .inventory import (
    build_annotation_audit_inventory,
    build_final_trigger_inventory,
)
from .java_workspace import build_java_workspace
from .java_websocket import analyze_java_websocket_endpoints
from .jaxrs import (
    analyze_direct_jax_rs_unit,
    attach_workspace_indexes as attach_jaxrs_indexes,
    clear_workspace_indexes as clear_jaxrs_indexes,
)
from .jaxrs_deployment import build_jax_rs_deployment_model
from .jaxrs_hierarchy import analyze_jax_rs_hierarchy_and_subresources
from .model import (
    AnalysisRequest,
    AnalysisResult,
    EndpointFact,
    FrameworkPlan,
    FrameworkSelection,
)
from .spring_clients import analyze_spring_http_clients
from .spring_config import (
    analyze_spring_resource_handlers,
    apply_spring_path_configuration,
    build_spring_path_configuration,
)
from .spring_gateway import analyze_spring_gateway
from .spring_mvc import (
    analyze_direct_spring_mvc_unit,
    attach_workspace_indexes as attach_spring_indexes,
)
from .spring_mvc_hierarchy import analyze_spring_mvc_hierarchy
from .spring_route_registrations import analyze_spring_route_registrations
from .spring_websocket_messaging import analyze_spring_websocket_and_messaging
from .tree_sitter_runtime import (
    build_workspace_runtime,
    require_tree_sitter,
    run_query_matches,
)


_FRAMEWORK_ORDER = (FrameworkSelection.SPRING, FrameworkSelection.JAX_RS)
_ANNOUNCEMENTS = {
    FrameworkSelection.SPRING: "Found SpringBoot Annotation",
    FrameworkSelection.JAX_RS: "Found JaxRS",
}


@dataclass(frozen=True, slots=True)
class SourceSnapshot:
    """The deterministic paths and exact bytes shared by every analysis pass."""

    paths: tuple[str, ...]
    content: Mapping[str, bytes]

    def __post_init__(self) -> None:
        """Detach the path/content snapshot and enforce exact key agreement."""

        paths = tuple(self.paths)
        content = dict(self.content)
        if len(paths) != len(content) or set(paths) != set(content):
            raise ValueError("source paths and content must match exactly")
        object.__setattr__(self, "paths", paths)
        object.__setattr__(self, "content", MappingProxyType(content))


@dataclass(frozen=True, slots=True)
class FrameworkDecision:
    """The selected analyzers plus marker evidence and stdout announcements."""

    plan: FrameworkPlan
    detections: tuple[Any, ...] = ()
    announcements: tuple[str, ...] = ()


def _snapshot_sources(root: Path) -> SourceSnapshot:
    """Discover deterministic Java paths and read each source exactly once."""

    paths = tuple(discover_java_files(root))
    return SourceSnapshot(paths, {path: Path(path).read_bytes() for path in paths})


def _select_frameworks(
    request: AnalysisRequest,
    sources: SourceSnapshot,
) -> FrameworkDecision:
    """Resolve explicit/default selection or marker-driven ``auto`` selection."""

    if request.framework_mode != "auto":
        selected = (
            _FRAMEWORK_ORDER
            if request.framework_mode is None
            else (FrameworkSelection(request.framework_mode),)
        )
        return FrameworkDecision(
            FrameworkPlan(request.framework_mode, selected),
            announcements=tuple(_ANNOUNCEMENTS[item] for item in selected),
        )

    detection = scan_framework_markers(request.analysis_root, sources.content)
    occurrences = tuple(detection["occurrences"])
    for finding_name, relative_path in occurrences:
        record(f"Detected {finding_name} in {relative_path}")
    detected = {
        FrameworkSelection(item) for item in detection["selected_frameworks"]
    }
    selected = tuple(item for item in _FRAMEWORK_ORDER if item in detected)
    announcements = tuple(
        f"Found {finding['finding_name']}"
        + (f" {finding['report_hint']}" if finding["report_hint"] else "")
        for finding in detection["findings"]
    )
    return FrameworkDecision(
        FrameworkPlan("auto", selected),
        detections=occurrences,
        announcements=announcements,
    )


def _build_workspace(
    sources: SourceSnapshot,
    *,
    include_jaxrs: bool,
) -> dict[str, Any]:
    """Parse the snapshot once and attach the selected framework indexes."""

    runtime = build_workspace_runtime()
    workspace = build_java_workspace(
        sources.content,
        runtime,
        match_query=run_query_matches,
    )
    attach_spring_indexes(workspace)
    if include_jaxrs:
        attach_jaxrs_indexes(workspace)
    else:
        clear_jaxrs_indexes(workspace)
    return workspace


def _analyze_spring(
    request: AnalysisRequest,
    sources: SourceSnapshot,
    workspace: dict[str, Any],
) -> list[EndpointFact]:
    """Run Spring passes in dependency order and apply path configuration."""

    endpoints: list[EndpointFact] = []
    units = workspace.get("compilation_units", {})
    for source_path in sources.paths:
        unit = units.get(source_path)
        if unit is not None:
            endpoints.extend(analyze_direct_spring_mvc_unit(unit, workspace))
    if not units:
        return endpoints

    endpoints.extend(analyze_spring_route_registrations(workspace))
    endpoints.extend(analyze_spring_mvc_hierarchy(workspace))
    endpoints.extend(analyze_spring_gateway(workspace))
    endpoints.extend(analyze_spring_resource_handlers(workspace))
    endpoints.extend(analyze_spring_http_clients(workspace))
    configuration = build_spring_path_configuration(
        workspace, str(request.analysis_root)
    )
    endpoints.extend(
        analyze_spring_websocket_and_messaging(workspace, configuration)
    )
    return apply_spring_path_configuration(endpoints, configuration)


def _analyze_jaxrs(
    sources: SourceSnapshot,
    workspace: dict[str, Any],
) -> list[EndpointFact]:
    """Run direct and project-wide JAX-RS/WebSocket passes in order."""

    endpoints: list[EndpointFact] = []
    units = workspace.get("compilation_units", {})
    for source_path in sources.paths:
        unit = units.get(source_path)
        if unit is None:
            continue
        record(f"{source_path}:")
        endpoints.extend(analyze_direct_jax_rs_unit(unit, workspace))
    if units:
        endpoints.extend(analyze_jax_rs_hierarchy_and_subresources(workspace))
        endpoints.extend(analyze_java_websocket_endpoints(workspace))
    return endpoints


def run_analysis(request: AnalysisRequest) -> AnalysisResult:
    """Run validation, selection, parsing, inventories, and selected analyzers."""

    require_tree_sitter()
    sources = _snapshot_sources(request.analysis_root)
    decision = _select_frameworks(request, sources)
    include_jaxrs = FrameworkSelection.JAX_RS in decision.plan.selected
    workspace = _build_workspace(sources, include_jaxrs=include_jaxrs)
    selected = {item.value for item in decision.plan.selected}
    root = str(request.analysis_root)
    annotation_inventory = build_annotation_audit_inventory(
        workspace, root, selected
    )
    trigger_inventory = (
        build_final_trigger_inventory(workspace, root, selected) if selected else ()
    )
    if include_jaxrs:
        build_jax_rs_deployment_model(workspace, root)

    endpoints: list[EndpointFact] = []
    if FrameworkSelection.SPRING in decision.plan.selected:
        endpoints.extend(_analyze_spring(request, sources, workspace))
    if include_jaxrs:
        endpoints.extend(_analyze_jaxrs(sources, workspace))
    if not all(isinstance(endpoint, EndpointFact) for endpoint in endpoints):
        raise TypeError("analyzers must return EndpointFact values")

    return AnalysisResult(
        endpoints=tuple(endpoints),
        framework_plan=decision.plan,
        annotation_audit_inventory=tuple(annotation_inventory),
        final_trigger_inventory=tuple(trigger_inventory),
        detections=decision.detections,
        announcements=decision.announcements,
    )


__all__ = ["FrameworkDecision", "SourceSnapshot", "run_analysis"]
