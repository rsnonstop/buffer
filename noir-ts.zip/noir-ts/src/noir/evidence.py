"""Exact typed source provenance and endpoint-evidence operations.

Every analyzer uses these functions to describe which declaration it
represents. Keeping validation and merge rules here gives extraction,
consolidation, and the absent-trigger report one definition of identity.

Logic guide: ``p6.logic/07-output-evidence-reports.md`` (method evidence,
represented targets, and consolidation).
"""

from __future__ import annotations

import os
import unicodedata
from collections.abc import Callable, Iterable, Mapping
from dataclasses import replace
from typing import Any, TypeAlias

from .contracts import (
    METHOD_ANNOTATION_FAMILY_BY_IDENTITY,
    METHOD_ANNOTATION_FAMILY_PRIORITY,
    SOURCE_TARGET_KINDS,
)
from .model import (
    AnnotationEvidence,
    EndpointFact,
    SourceFile,
    SourceSpan,
    SourceTarget,
)


EndpointIdentity: TypeAlias = Callable[[EndpointFact], tuple[Any, ...]]


def _java_identifier_start(character: str) -> bool:
    """Report whether a character may start a Java source identifier.

    Example call:
        ``_java_identifier_start("I")`` and ``_java_identifier_start("_")``
        return ``True``; ``_java_identifier_start("1")`` returns ``False``.
    """

    category = unicodedata.category(character)
    return character in {"_", "$"} or category[0] == "L" or category in {
        "Nl",
        "Sc",
        "Pc",
    }


def _java_identifier_part(character: str) -> bool:
    """Report whether a character may continue a Java source identifier.

    Example call:
        ``_java_identifier_part("1")`` returns ``True`` for ``Item1`` while
        ``_java_identifier_part("-")`` returns ``False``.
    """

    return _java_identifier_start(character) or unicodedata.category(character) in {
        "Mn",
        "Mc",
        "Nd",
        "Cf",
    }


def _is_canonical_annotation_identity(identity: Any) -> bool:
    """Validate a complete dotted Java annotation identity.

    Example call:
        ``_is_canonical_annotation_identity(
        "org.springframework.web.bind.annotation.GetMapping")`` returns
        ``True``; ``"Get-Mapping"`` and non-text values return ``False``.
    """

    if not isinstance(identity, str):
        return False
    segments = identity.split(".")
    return bool(segments) and all(
        segment
        and _java_identifier_start(segment[0])
        and all(_java_identifier_part(character) for character in segment[1:])
        for segment in segments
    )


def canonical_source_file_name(source_file: Any) -> str | None:
    """Return the canonical path identity used for provenance ownership.

    Real, absolute, norm-cased names make syntactically different spellings of
    the same file compare equal. Unusable path-like values return ``None`` so
    callers drop uncertain evidence instead of guessing ownership.

    Example call:
        ``canonical_source_file_name("./src/ItemsController.java")`` returns an
        absolute normalized spelling such as
        ``"/workspace/app/src/ItemsController.java"``.
    """

    try:
        value = os.fspath(source_file)
    except TypeError:
        return None
    if isinstance(value, bytes):
        try:
            value = os.fsdecode(value)
        except UnicodeError:
            return None
    value = str(value).strip()
    if not value:
        return None
    try:
        return os.path.normcase(os.path.realpath(os.path.abspath(value)))
    except (OSError, ValueError):
        return None


def make_source_target(
    source_file: Any,
    target_kind: str,
    start_byte: int,
    end_byte: int,
) -> SourceTarget | None:
    """Validate and canonicalize one represented declaration identity.

    Identity includes file, declaration kind, and a non-empty half-open byte
    span. It intentionally does not use handler names or route strings, which
    are not unique enough for the annotations-without-endpoints subtraction.

    Example call:
        ``make_source_target("/workspace/app/ItemsController.java", "method",
        120, 180)`` returns a ``SourceTarget`` identifying that method's exact
        source span; an unknown kind or empty span returns ``None``.
    """

    canonical_source = canonical_source_file_name(source_file)
    if canonical_source is None or target_kind not in SOURCE_TARGET_KINDS:
        return None
    if (
        isinstance(start_byte, bool)
        or isinstance(end_byte, bool)
        or not isinstance(start_byte, int)
        or not isinstance(end_byte, int)
        or start_byte < 0
        or end_byte <= start_byte
    ):
        return None
    return SourceTarget(
        kind=target_kind,
        span=SourceSpan(SourceFile(canonical_source), start_byte, end_byte),
    )


def source_target_from_node(
    source_file: Any, target_kind: str, node: Any
) -> SourceTarget | None:
    """Build declaration evidence from one application syntax node.

    Example call:
        ``source_target_from_node("/workspace/app/ItemsController.java",
        "method", list_method_node)`` uses that conceptual parser node's byte
        range to identify the represented ``list`` handler.
    """

    if node is None:
        return None
    try:
        start_byte = node.start_byte
        end_byte = node.end_byte
    except (AttributeError, TypeError):
        return None
    return make_source_target(source_file, target_kind, start_byte, end_byte)


def represented_target_evidence(
    source_file: Any, target_kind: str, node: Any
) -> tuple[SourceTarget, ...]:
    """Package one represented declaration for an endpoint builder.

    Example call:
        ``represented_target_evidence("/workspace/app/ItemsController.java",
        "method", list_method_node)`` returns ``(list_target,)`` when the
        handler node has a valid source span, otherwise ``()``.
    """

    target = source_target_from_node(source_file, target_kind, node)
    return (target,) if target is not None else ()


def _canonical_source_target(target: SourceTarget) -> SourceTarget | None:
    """Revalidate and canonicalize one represented application declaration.

    Example call:
        ``_canonical_source_target(SourceTarget("method",
        SourceSpan(SourceFile("./Items.java"), 120, 180)))`` returns the same
        logical target with a canonical absolute source-file identity.
    """

    if not isinstance(target, SourceTarget):
        raise TypeError("represented target collections must contain SourceTarget values")
    return make_source_target(
        target.span.source_file,
        target.kind,
        target.span.start_byte,
        target.span.end_byte,
    )


def merge_represented_targets(
    *collections: Iterable[SourceTarget],
) -> tuple[SourceTarget, ...]:
    """Union represented application declarations in stable canonical order.

    Example call:
        ``merge_represented_targets((controller_method,), (api_method,
        controller_method))`` returns the two distinct declaration targets once
        each, ordered by file, kind, and byte span.
    """

    unique: dict[tuple[str, str, int, int], SourceTarget] = {}
    for collection in collections:
        if isinstance(collection, (Mapping, str, bytes)):
            raise TypeError("represented targets must be typed iterables")
        for record in collection:
            target = _canonical_source_target(record)
            if target is None:
                continue
            key = (
                target.span.source_file.path,
                target.kind,
                target.span.start_byte,
                target.span.end_byte,
            )
            unique[key] = target
    return tuple(unique[key] for key in sorted(unique))


def method_annotation_family(identity: Any, fallback: Any = None) -> str | None:
    """Resolve the trusted evidence family for one annotation identity.

    Built-in identities have a fixed family; a contradictory caller fallback
    is rejected. Source-defined composed/custom annotations may use a known
    fallback only after their analyzer has established canonical identity.

    Example call:
        ``method_annotation_family(
        "org.springframework.web.bind.annotation.GetMapping")`` returns
        ``"spring"``; a custom identity can return ``"jax-rs"`` when that
        recognized family is passed as ``fallback``.
    """

    configured = METHOD_ANNOTATION_FAMILY_BY_IDENTITY.get(identity)
    if configured is not None:
        return configured if fallback in (None, configured) else None
    return (
        fallback
        if isinstance(fallback, str)
        and fallback in METHOD_ANNOTATION_FAMILY_PRIORITY
        else None
    )


def make_method_annotation_evidence(
    line: Any,
    identity: Any,
    family: Any = None,
    *,
    annotation_source_file: Any,
    endpoint_source_file: Any,
) -> AnnotationEvidence | None:
    """Return owned typed method-annotation provenance or ``None``.

    A usable record needs a positive source line, canonical annotation
    identity, recognized family, and canonical annotation file equal to the
    endpoint's public source file. Cross-file route evidence may prove an
    endpoint but cannot populate that handler row's CSV annotation-line cell.

    Example call:
        ``make_method_annotation_evidence(42,
        "org.springframework.web.bind.annotation.GetMapping", "spring",
        annotation_source_file="/workspace/app/ItemsController.java",
        endpoint_source_file="/workspace/app/ItemsController.java")`` returns
        owned evidence for the handler's mapping annotation.
    """

    if isinstance(line, bool) or not isinstance(line, int) or line <= 0:
        return None
    if not _is_canonical_annotation_identity(identity):
        return None
    resolved_family = method_annotation_family(identity, family)
    if resolved_family is None:
        return None
    annotation_source = canonical_source_file_name(annotation_source_file)
    endpoint_source = canonical_source_file_name(endpoint_source_file)
    if annotation_source is None or annotation_source != endpoint_source:
        return None
    return AnnotationEvidence(
        line=line,
        identity=identity,
        family=resolved_family,
        source_file=SourceFile(annotation_source),
    )


def method_annotation_evidence_from_node(
    annotation_node: Any,
    identity: Any,
    family: Any,
    *,
    annotation_source_file: Any,
    endpoint_source_file: Any,
) -> tuple[AnnotationEvidence, ...]:
    """Convert one handler annotation node to zero-or-one owned evidence.

    Example call:
        ``method_annotation_evidence_from_node(get_mapping_node,
        "org.springframework.web.bind.annotation.GetMapping", "spring",
        annotation_source_file=items_file, endpoint_source_file=items_file)``
        returns evidence whose line is the conceptual node's one-based start.
    """

    if annotation_node is None:
        return ()
    try:
        line = annotation_node.start_point.row + 1
    except (AttributeError, TypeError):
        return ()
    evidence = make_method_annotation_evidence(
        line,
        identity,
        family,
        annotation_source_file=annotation_source_file,
        endpoint_source_file=endpoint_source_file,
    )
    return (evidence,) if evidence is not None else ()


def method_annotation_evidence_from_mapping(
    mapping: Any,
    *,
    annotation_source_file: Any,
    endpoint_source_file: Any,
) -> tuple[AnnotationEvidence, ...]:
    """Extract handler-annotation evidence from a decoded route mapping.

    Example call:
        ``method_annotation_evidence_from_mapping({"annotation_node":
        get_mapping_node, "annotation_identity":
        "org.springframework.web.bind.annotation.GetMapping",
        "annotation_family": "spring"}, annotation_source_file=items_file,
        endpoint_source_file=items_file)`` returns the owned line evidence.
    """

    if not isinstance(mapping, Mapping):
        return ()
    return method_annotation_evidence_from_node(
        mapping.get("annotation_node"),
        mapping.get("annotation_identity"),
        mapping.get("annotation_family"),
        annotation_source_file=annotation_source_file,
        endpoint_source_file=endpoint_source_file,
    )


def merge_method_annotation_evidence(
    *collections: Iterable[AnnotationEvidence],
) -> tuple[AnnotationEvidence, ...]:
    """Merge validated handler-annotation provenance in deterministic order.

    Example call:
        ``merge_method_annotation_evidence((get_mapping,),
        (request_mapping, get_mapping))`` returns the two distinct owned
        annotation records once each, ordered by family, line, and identity.
    """

    unique: dict[tuple[str, int, str, str], AnnotationEvidence] = {}
    for collection in collections:
        if isinstance(collection, (Mapping, str, bytes)):
            raise TypeError("annotation evidence must be typed iterables")
        for record in collection:
            if not isinstance(record, AnnotationEvidence):
                raise TypeError(
                    "annotation evidence collections must contain AnnotationEvidence values"
                )
            evidence = make_method_annotation_evidence(
                record.line,
                record.identity,
                record.family,
                annotation_source_file=record.source_file,
                endpoint_source_file=record.source_file,
            )
            if evidence is None:
                continue
            key = (
                evidence.family,
                evidence.line,
                evidence.identity,
                evidence.source_file.path,
            )
            unique[key] = evidence
    return tuple(unique[key] for key in sorted(unique))


def merge_endpoint_facts(
    current: EndpointFact, candidate: EndpointFact
) -> EndpointFact:
    """Keep a newer duplicate endpoint while combining both provenance sets.

    Example call:
        ``merge_endpoint_facts(interface_fact, controller_fact)`` returns the
        controller fact's route values with represented targets and annotation
        evidence from both declarations.
    """

    if not isinstance(current, EndpointFact) or not isinstance(candidate, EndpointFact):
        raise TypeError("endpoint merge requires EndpointFact values")
    return replace(
        candidate,
        annotation_evidence=merge_method_annotation_evidence(
            current.annotation_evidence,
            candidate.annotation_evidence,
        ),
        represented_targets=merge_represented_targets(
            current.represented_targets,
            candidate.represented_targets,
        ),
    )


def deduplicate_endpoint_facts(
    endpoints: Iterable[EndpointFact],
    identity: EndpointIdentity,
) -> tuple[EndpointFact, ...]:
    """Merge local duplicates in deterministic analyzer-identity order.

    Each analyzer declares its own pre-output identity with a typed callback.
    The public six-field consolidation remains a separate authoritative stage.

    Example call:
        ``deduplicate_endpoint_facts([first_get, repeated_get],
        lambda endpoint: (endpoint.method, endpoint.path,
        endpoint.handler_name))`` returns one ``GET /items`` fact with merged
        provenance when those identity values match.
    """

    if not callable(identity):
        raise TypeError("endpoint identity must be callable")
    unique: dict[tuple[Any, ...], EndpointFact] = {}
    for endpoint in endpoints:
        if not isinstance(endpoint, EndpointFact):
            raise TypeError("endpoint collections must contain EndpointFact values")
        key = identity(endpoint)
        if not isinstance(key, tuple):
            raise TypeError("endpoint identity must return a tuple")
        unique[key] = (
            merge_endpoint_facts(unique[key], endpoint)
            if key in unique
            else endpoint
        )
    return tuple(unique[key] for key in sorted(unique))


def owned_method_annotation_evidence(
    endpoint: EndpointFact,
) -> tuple[AnnotationEvidence, ...]:
    """Keep handler annotations owned by the endpoint's public source file.

    Example call:
        ``owned_method_annotation_evidence(endpoint)`` keeps the
        ``@GetMapping`` at ``ItemsController.java:42`` when that same file owns
        the endpoint row, while dropping an inherited interface-file annotation.
    """

    if not isinstance(endpoint, EndpointFact):
        raise TypeError("owned evidence requires an EndpointFact")
    endpoint_source = canonical_source_file_name(endpoint.source_file)
    if endpoint_source is None:
        return ()
    return tuple(
        evidence
        for evidence in merge_method_annotation_evidence(endpoint.annotation_evidence)
        if evidence.source_file.path == endpoint_source
    )


def owned_represented_targets(
    endpoint: EndpointFact,
) -> tuple[SourceTarget, ...]:
    """Keep represented declarations owned by the endpoint's public source.

    Example call:
        ``owned_represented_targets(endpoint)`` returns the concrete
        ``ItemsController.list`` method target and excludes a cross-file
        ``ItemsApi.list`` target from the row-owned set.
    """

    if not isinstance(endpoint, EndpointFact):
        raise TypeError("owned targets require an EndpointFact")
    endpoint_source = canonical_source_file_name(endpoint.source_file)
    if endpoint_source is None:
        return ()
    return tuple(
        target
        for target in merge_represented_targets(endpoint.represented_targets)
        if target.span.source_file.path == endpoint_source
    )


def select_method_annotation_evidence(
    evidence: Iterable[AnnotationEvidence],
) -> AnnotationEvidence | None:
    """Choose the public annotation line after duplicate evidence has merged.

    Example call:
        ``select_method_annotation_evidence([request_mapping, get_mapping])``
        returns the candidate with the highest configured family priority,
        then earliest line and identity; an empty collection returns ``None``.
    """

    candidates = merge_method_annotation_evidence(evidence)
    if not candidates:
        return None
    return min(
        candidates,
        key=lambda record: (
            METHOD_ANNOTATION_FAMILY_PRIORITY[record.family],
            record.line,
            record.identity,
        ),
    )


__all__ = [
    "EndpointIdentity",
    "canonical_source_file_name",
    "deduplicate_endpoint_facts",
    "make_method_annotation_evidence",
    "make_source_target",
    "merge_endpoint_facts",
    "merge_method_annotation_evidence",
    "merge_represented_targets",
    "method_annotation_evidence_from_mapping",
    "method_annotation_evidence_from_node",
    "method_annotation_family",
    "owned_method_annotation_evidence",
    "owned_represented_targets",
    "represented_target_evidence",
    "select_method_annotation_evidence",
    "source_target_from_node",
]
