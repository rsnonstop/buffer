"""Bounded Spring Cloud Gateway Java-DSL endpoint extraction.

The module uses the shared provenance-aware Java type and String-resolution
operations directly.

Only a published, direct ``@Bean RouteLocator`` construction is accepted.  A
route predicate can be written directly in its lambda or delegated through
one exact, same-owner ``PredicateSpec`` helper. Normal terminal ``filter`` or
``filters`` steps, a dynamic route ID, and a dynamic destination expression do
not affect route identity. Unsupported predicate algebra, control flow,
dynamic path values, or ambiguous source identity fail closed.

Logic guide: ``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable

from .contracts import SPRING_HTTP_METHODS
from .diagnostics import format_endpoint_diagnostic, record
from .evidence import deduplicate_endpoint_facts, represented_target_evidence
from .java_frontend import (
    direct_annotation_records,
    resolve_known_annotation,
    resolve_known_type,
)
from .java_methods import (
    MethodFact,
    MethodIndex,
    build_strict_method_index as _build_method_index,
    child_field as _field,
    invocation_arguments as _arguments,
    invocation_name as _invocation_name,
    known_type as _known_type,
    node_text as _text,
    only_named_child as _only_named_child,
    strict_formal_parameters as _formal_parameters,
    unwrap_parentheses as _unwrap_parentheses,
    walk_named_nodes as _walk,
)
from .java_workspace import (
    resolve_workspace_string_expression,
    static_member_resolves_to,
)
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths


SPRING_CONTEXT_ANNOTATION_PACKAGE = "org.springframework.context.annotation"
GATEWAY_ROUTE_PACKAGE = "org.springframework.cloud.gateway.route"
GATEWAY_BUILDER_PACKAGE = "org.springframework.cloud.gateway.route.builder"
SPRING_HTTP_PACKAGE = "org.springframework.http"


GatewayPathResolver = Callable[..., str | None]


@dataclass(frozen=True)
class GatewayRouteConditions:
    """Static inbound path and verb fan-out proven for one Gateway route."""

    paths: tuple[str, ...]
    methods: tuple[str, ...]


def _log(
    fact: MethodFact,
    message: str,
    node: Any = None,
) -> None:
    """Record why a Gateway publisher or route candidate failed closed."""

    expression = f": {_text(fact.unit, node).strip()}" if node is not None else ""
    record(
        "Skipped Spring Gateway "
        f"{message} in {fact.unit['source_path']} for {fact.owner_name}{expression}"
    )


def _known_direct_annotation(
    fact: MethodFact,
    simple_name: str,
    package: str,
) -> Any:
    """Select one genuine direct framework annotation without guessing ambiguity."""

    matches = []
    for annotation_record in direct_annotation_records(fact.node):
        if (
            resolve_known_annotation(
                fact.unit, annotation_record["name_node"], {simple_name}, (package,)
            )
            is not None
        ):
            matches.append(annotation_record)
    return matches[0] if len(matches) == 1 else None


def _owner_is_unique_concrete_class(
    workspace: dict[str, Any], fact: MethodFact
) -> bool:
    """Require a uniquely attributable, concrete source publisher owner."""

    if (
        fact.owner_info["node"].type != "class_declaration"
        or fact.owner_info["abstract"]
        or not fact.owner_info["workspace_visible"]
    ):
        return False
    declarations = workspace["type_declarations"].get(fact.owner_fqn, [])
    return bool(
        len(declarations) == 1
        and declarations[0]["unit"] is fact.unit
        and declarations[0]["type_info"] is fact.owner_info
    )


def _single_direct_return(
    fact: MethodFact, *, reject_nested_returns: bool = True
) -> Any:
    """Select the sole top-level publication expression under bounded flow."""

    returns = [node for node in _walk(fact.body_node) if node.type == "return_statement"]
    direct = [
        node for node in fact.body_node.named_children if node.type == "return_statement"
    ]
    if len(direct) != 1:
        return None
    if reject_nested_returns and (len(returns) != 1 or returns[0] != direct[0]):
        return None
    return _only_named_child(direct[0])


def _validated_route_locator_builder_name(fact: MethodFact) -> str | None:
    """Recognize a Bean RouteLocator publisher and its exact builder parameter."""

    if _known_direct_annotation(
        fact, "Bean", SPRING_CONTEXT_ANNOTATION_PACKAGE
    ) is None:
        return None
    if not _known_type(
        fact.unit,
        fact.return_type_node,
        "RouteLocator",
        GATEWAY_ROUTE_PACKAGE,
    ):
        return None
    builders = [
        parameter
        for parameter in fact.parameters
        if _known_type(
            fact.unit,
            parameter.type_node,
            "RouteLocatorBuilder",
            GATEWAY_BUILDER_PACKAGE,
        )
    ]
    return builders[0].name if len(builders) == 1 else None


def _decode_predicate_lambda_parameter(
    fact: MethodFact, node: Any
) -> str | None:
    """Prove the route lambda's single PredicateSpec receiver identity."""

    parameters = _field(node, "parameters")
    if parameters is None:
        return None
    if parameters.type == "identifier":
        return _text(fact.unit, parameters)
    if parameters.type == "inferred_parameters":
        children = list(parameters.named_children)
        return (
            _text(fact.unit, children[0])
            if len(children) == 1 and children[0].type == "identifier"
            else None
        )
    if parameters.type != "formal_parameters":
        return None
    formals = _formal_parameters(fact.unit, parameters)
    if formals is None or len(formals) != 1:
        return None
    formal = formals[0]
    return (
        formal.name
        if _known_type(
            fact.unit,
            formal.type_node,
            "PredicateSpec",
            GATEWAY_BUILDER_PACKAGE,
        )
        else None
    )


def _resolve_path(
    fact: MethodFact,
    workspace: dict[str, Any],
    node: Any,
    path_resolver: GatewayPathResolver | None,
) -> str | None:
    """Resolve one static route path and apply the owning project configuration."""

    value = resolve_workspace_string_expression(
        fact.unit, node, workspace, fact.owner_name
    )
    if value is None:
        return None
    path = join_endpoint_paths("", ensure_path_leading_slash(value))
    if path_resolver is not None:
        path = path_resolver(
            path,
            unit=fact.unit,
            owner_name=fact.owner_name,
            surface="gateway",
        )
    return path if isinstance(path, str) and path else None


def _resolve_http_method(fact: MethodFact, node: Any) -> str | None:
    """Resolve one genuine Spring HttpMethod or RequestMethod member."""

    current = _unwrap_parentheses(node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = _text(fact.unit, current).strip()
    method = spelling.rsplit(".", 1)[-1]
    if method not in {*SPRING_HTTP_METHODS, "CONNECT"}:
        return None
    expected = (
        (SPRING_HTTP_PACKAGE, "HttpMethod", {*SPRING_HTTP_METHODS, "CONNECT"}),
        (
            "org.springframework.web.bind.annotation",
            "RequestMethod",
            set(SPRING_HTTP_METHODS),
        ),
    )
    if "." not in spelling:
        owners = [
            f"{package}.{simple_name}"
            for package, simple_name, allowed in expected
            if method in allowed
            if static_member_resolves_to(
                fact.unit, method, f"{package}.{simple_name}", current
            )
        ]
        return method if len(owners) == 1 else None
    qualifier = spelling.rsplit(".", 1)[0]
    owners = [
        package
        for package, simple_name, allowed in expected
        if method in allowed
        if resolve_known_type(
            fact.unit,
            qualifier,
            simple_name,
            (package,),
            current,
        )
        == package
    ]
    return method if len(owners) == 1 else None


def _invocation_chain(fact: MethodFact, node: Any) -> tuple[Any, list[Any]] | None:
    """Flatten a bounded fluent chain into its root and source-ordered calls."""

    calls: list[Any] = []
    current = _unwrap_parentheses(node)
    for _depth in range(16):
        if current is None or current.type != "method_invocation":
            return current, list(reversed(calls))
        if _arguments(current) is None:
            return None
        calls.append(current)
        current = _unwrap_parentheses(_field(current, "object"))
    return None


def _decode_predicate_chain(
    fact: MethodFact,
    workspace: dict[str, Any],
    node: Any,
    root_name: str,
    path_resolver: GatewayPathResolver | None,
) -> GatewayRouteConditions | None:
    """Decode the supported path/method sequence and neutral filter suffix."""

    decoded = _invocation_chain(fact, node)
    if decoded is None:
        return None
    root, calls = decoded
    if (
        root is None
        or root.type != "identifier"
        or _text(fact.unit, root) != root_name
    ):
        return None
    names = [_invocation_name(fact.unit, call) for call in calls]
    filter_indexes = [
        index for index, name in enumerate(names) if name in {"filter", "filters"}
    ]
    if filter_indexes:
        first_filter = filter_indexes[0]
        if filter_indexes != list(range(first_filter, len(names))):
            return None
        for filter_call in calls[first_filter:]:
            filter_arguments = _arguments(filter_call)
            if filter_arguments is None or len(filter_arguments) != 1:
                return None
        calls = calls[:first_filter]
        names = names[:first_filter]
    if names not in (["path"], ["path", "and", "method"], ["method", "and", "path"]):
        return None

    paths: list[str] = []
    methods: list[str] = []
    for name, call in zip(names, calls):
        arguments = _arguments(call)
        if arguments is None:
            return None
        if name == "and":
            if arguments:
                return None
            continue
        if not arguments:
            return None
        if name == "path":
            for argument in arguments:
                path = _resolve_path(
                    fact, workspace, argument, path_resolver
                )
                if path is None:
                    return None
                paths.append(path)
            continue
        for argument in arguments:
            method = _resolve_http_method(fact, argument)
            if method is None:
                return None
            methods.append(method)

    return GatewayRouteConditions(
        paths=tuple(dict.fromkeys(paths)),
        methods=tuple(dict.fromkeys(methods or ["ANY"])),
    )


def _decode_predicate_helper(
    publisher: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    invocation: Any,
    lambda_parameter: str,
    path_resolver: GatewayPathResolver | None,
) -> GatewayRouteConditions | None:
    """Follow one exact same-owner helper that returns the route predicates."""

    helper_name = _invocation_name(publisher.unit, invocation)
    arguments = _arguments(invocation)
    receiver = _field(invocation, "object")
    if (
        helper_name is None
        or arguments is None
        or len(arguments) != 1
        or arguments[0].type != "identifier"
        or _text(publisher.unit, arguments[0]) != lambda_parameter
        or (
            receiver is not None
            and not (
                receiver.type == "this" and _text(publisher.unit, receiver) == "this"
            )
        )
    ):
        return None
    candidates = [
        candidate
        for candidate in method_index.by_owner_name.get(
            (publisher.owner_fqn, helper_name), ()
        )
        if len(candidate.parameters) == 1
        and _known_type(
            candidate.unit,
            candidate.parameters[0].type_node,
            "PredicateSpec",
            GATEWAY_BUILDER_PACKAGE,
        )
        and _known_type(
            candidate.unit,
            candidate.return_type_node,
            "BooleanSpec",
            GATEWAY_BUILDER_PACKAGE,
        )
    ]
    if len(candidates) != 1:
        return None
    helper = candidates[0]
    expression = _single_direct_return(helper)
    if expression is None:
        return None
    return _decode_predicate_chain(
        helper,
        workspace,
        expression,
        helper.parameters[0].name,
        path_resolver,
    )


def _decode_route_lambda(
    publisher: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    node: Any,
    path_resolver: GatewayPathResolver | None,
) -> GatewayRouteConditions | None:
    """Extract inbound conditions from a route lambda ending in ``uri``."""

    if node.type != "lambda_expression":
        return None
    parameter = _decode_predicate_lambda_parameter(publisher, node)
    body = _unwrap_parentheses(_field(node, "body"))
    if parameter is None or body is None or body.type != "method_invocation":
        return None
    if _invocation_name(publisher.unit, body) != "uri":
        return None
    uri_arguments = _arguments(body)
    predicate = _unwrap_parentheses(_field(body, "object"))
    if uri_arguments is None or len(uri_arguments) != 1 or predicate is None:
        return None
    # The destination does not participate in the inbound route identity.
    # Spring accepts dynamic URI expressions here and Noir deliberately
    # ignores them, so only the one-argument call shape is required.

    direct = _decode_predicate_chain(
        publisher,
        workspace,
        predicate,
        parameter,
        path_resolver,
    )
    if direct is not None:
        return direct
    if predicate.type != "method_invocation":
        return None
    return _decode_predicate_helper(
        publisher,
        workspace,
        method_index,
        predicate,
        parameter,
        path_resolver,
    )


def _route_lambda_argument(
    publisher: MethodFact,
    workspace: dict[str, Any],
    call: Any,
) -> Any:
    """Select the route lambda while deliberately ignoring an optional route ID."""

    arguments = _arguments(call)
    if arguments is None or len(arguments) not in {1, 2}:
        return None
    # The optional route ID is diagnostic/runtime bookkeeping, not inbound
    # endpoint identity. Dynamic IDs remain valid and are deliberately ignored.
    candidate = arguments[-1]
    return candidate if candidate.type == "lambda_expression" else None


def _decode_route_locator_publisher(
    publisher: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    builder_name: str,
    path_resolver: GatewayPathResolver | None,
) -> list[tuple[GatewayRouteConditions, Any]] | None:
    """Decode bounded ``routes().route(...).build()`` publication calls."""

    # A rejected route lambda may itself contain a return statement.  It must
    # not invalidate valid sibling route calls in the publisher chain.
    expression = _unwrap_parentheses(
        _single_direct_return(publisher, reject_nested_returns=False)
    )
    if expression is None or _invocation_name(publisher.unit, expression) != "build":
        return None
    if _arguments(expression) != []:
        return None

    route_calls: list[Any] = []
    current = _unwrap_parentheses(_field(expression, "object"))
    for _depth in range(256):
        name = _invocation_name(publisher.unit, current)
        if name == "route":
            route_calls.append(current)
            current = _unwrap_parentheses(_field(current, "object"))
            continue
        if name != "routes" or _arguments(current) != []:
            return None
        root = _unwrap_parentheses(_field(current, "object"))
        if (
            root is None
            or root.type != "identifier"
            or _text(publisher.unit, root) != builder_name
        ):
            return None
        break
    else:
        return None

    if not route_calls:
        return None
    decoded: list[tuple[GatewayRouteConditions, Any]] = []
    for call in reversed(route_calls):
        lambda_node = _route_lambda_argument(
            publisher, workspace, call
        )
        shape = (
            _decode_route_lambda(
                publisher,
                workspace,
                method_index,
                lambda_node,
                path_resolver,
            )
            if lambda_node is not None
            else None
        )
        if shape is None:
            _log(publisher, "unsupported route lambda", call)
            continue
        decoded.append((shape, call))
    return decoded


def _endpoint(
    publisher: MethodFact,
    route_call: Any,
    method: str,
    path: str,
) -> EndpointFact:
    """Create one Gateway fact attributed to its publishing Bean method."""

    # DSL registration has no request-method annotation; exact represented
    # target evidence still connects the fact to the publisher declaration.
    endpoint = EndpointFact(
        path=path,
        method=method,
        parameters="",
        source_file=publisher.unit["source_path"],
        source_line=route_call.start_point.row + 1,
        handler_name=f"{publisher.owner_name}.{publisher.name}",
        route_source_file=publisher.unit["source_path"],
        route_source_line=route_call.start_point.row + 1,
        handler_source_file=publisher.unit["source_path"],
        handler_source_line=publisher.node.start_point.row + 1,
        protocol="http",
        surface="gateway",
        direction="inbound",
        technology="spring",
        annotation_evidence=(),
        represented_targets=represented_target_evidence(
            publisher.unit["source_path"], "method", publisher.node
        ),
    )
    record(format_endpoint_diagnostic(endpoint))
    return endpoint


def _deduplicate(
    endpoints: Iterable[EndpointFact],
) -> tuple[EndpointFact, ...]:
    """Merge exact Gateway duplicates while unioning their private evidence."""

    return deduplicate_endpoint_facts(
        endpoints,
        lambda endpoint: (
            endpoint.path,
            endpoint.method,
            endpoint.parameters,
            endpoint.source_file,
            endpoint.source_line,
            endpoint.handler_name,
        ),
    )


def analyze_spring_gateway(
    workspace: dict[str, Any],
    *,
    path_resolver: GatewayPathResolver | None = None,
) -> tuple[EndpointFact, ...]:
    """Return source-proven Spring Cloud Gateway endpoint facts.

    ``workspace`` is the shared Java workspace. ``path_resolver`` is an
    optional integration callback for the owning project's placeholder and
    prefix layer. It receives ``(path, unit=..., owner_name=...,
    surface="gateway")`` and must return one final path or ``None``.
    """

    method_index = _build_method_index(workspace)
    endpoints: list[EndpointFact] = []
    for publisher in method_index.methods:
        if not _owner_is_unique_concrete_class(workspace, publisher):
            continue
        builder_name = _validated_route_locator_builder_name(publisher)
        if builder_name is None:
            continue
        decoded = _decode_route_locator_publisher(
            publisher,
            workspace,
            method_index,
            builder_name,
            path_resolver,
        )
        if decoded is None:
            _log(
                publisher,
                "unsupported RouteLocator publication",
                publisher.node,
            )
            continue
        for shape, route_call in decoded:
            for path in shape.paths:
                for method in shape.methods:
                    endpoints.append(
                        _endpoint(publisher, route_call, method, path)
                    )
    return _deduplicate(endpoints)


__all__ = ["analyze_spring_gateway"]
