"""Bounded Spring functional and programmatic route registrations.

The module consumes an already-built Java workspace and calls the shared
Java, evidence, path, and diagnostic operations through their native owners.

Supported source shapes are intentionally small:

* Servlet/WebFlux ``@Bean RouterFunction`` return expressions using direct
  predicates, ``andRoute``, or the fixed-verb fluent builder; and
* canonical Servlet MVC ``@Configuration`` + ``@Autowired`` calls to
  ``RequestMappingHandlerMapping.registerMapping``.

Every decoder fails closed when registration activation, Java identity, data
flow, path, verb, or handler binding is not statically unambiguous.

Logic guide: ``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from typing import Any, Iterable

from .diagnostics import format_endpoint_diagnostic, record as record_diagnostic
from .evidence import deduplicate_endpoint_facts, represented_target_evidence
from .java_frontend import (
    annotation_has_no_values,
    declaration_modifier_names,
    direct_annotation_records,
    parameter_list_source_text,
    resolve_known_annotation,
    resolve_known_type,
)
from .java_methods import (
    MethodFact,
    MethodIndex,
    build_varargs_method_index as _build_method_index,
    child_field as _field,
    invocation_arguments as _arguments,
    invocation_name as _invocation_name,
    known_type as _known_type_node,
    node_text as _text,
    only_named_child as _only_named_child,
    raw_type_node as _raw_type_node,
    unwrap_parentheses as _unwrap_parentheses,
    walk_named_nodes as _walk,
)
from .java_workspace import (
    resolve_workspace_owner_fqns,
    resolve_workspace_string_expression,
    workspace_type_accessible,
)
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths
from .spring_mvc import resolve_spring_request_method_expression


SPRING_CONTEXT_ANNOTATION_PACKAGE = "org.springframework.context.annotation"
SPRING_BEANS_ANNOTATION_PACKAGE = "org.springframework.beans.factory.annotation"

FUNCTIONAL_FAMILIES = {
    "webflux": "org.springframework.web.reactive.function.server",
    "servlet": "org.springframework.web.servlet.function",
}
FUNCTIONAL_VERBS = {
    "GET",
    "HEAD",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "OPTIONS",
}
FUNCTIONAL_MAX_CHAIN_STEPS = 256
FUNCTIONAL_MAX_NEST_DEPTH = 16
FUNCTIONAL_MAX_ROUTES = 4096

MVC_HANDLER_MAPPING_PACKAGE = "org.springframework.web.servlet.mvc.method.annotation"
MVC_REQUEST_MAPPING_INFO_PACKAGE = "org.springframework.web.servlet.mvc.method"
REFLECT_PACKAGE = "java.lang.reflect"

JAVA_LANG_TYPES = {
    "Boolean",
    "Byte",
    "Character",
    "Class",
    "Double",
    "Enum",
    "Float",
    "Integer",
    "Long",
    "Number",
    "Object",
    "Short",
    "String",
    "Throwable",
    "Void",
}

CONTROL_FLOW_NODES = {
    "do_statement",
    "enhanced_for_statement",
    "for_statement",
    "if_statement",
    "lambda_expression",
    "return_statement",
    "switch_expression",
    "switch_statement",
    "synchronized_statement",
    "throw_statement",
    "try_statement",
    "while_statement",
}


def _log(
    unit: dict[str, Any],
    owner: str,
    message: str,
    node: Any = None,
) -> None:
    """Record the candidate-scoped reason a registration failed closed."""

    expression = f": {_text(unit, node).strip()}" if node is not None else ""
    record_diagnostic(
        f"Skipped Spring route registration {message} in {unit['source_path']} for {owner}{expression}"
    )


def _known_direct_annotation(
    unit: dict[str, Any],
    declaration_node: Any,
    simple_name: str,
    package: str,
    *,
    marker_only: bool = False,
) -> Any:
    """Select exactly one genuine direct activation annotation."""

    matches = []
    for record in direct_annotation_records(declaration_node):
        if (
            resolve_known_annotation(
                unit, record["name_node"], {simple_name}, (package,)
            )
            is not None
        ):
            matches.append(record)
    if len(matches) != 1:
        return None
    if marker_only and not annotation_has_no_values(matches[0]["node"]):
        return None
    return matches[0]


def _owner_is_concrete_class(fact: MethodFact) -> bool:
    """Require a workspace-visible concrete class to publish routes."""

    return (
        fact.owner_info["node"].type == "class_declaration"
        and not fact.owner_info["abstract"]
        and fact.owner_info["workspace_visible"]
    )


def _owner_is_unique(workspace: dict[str, Any], fact: MethodFact) -> bool:
    """Prove exact source ownership before attributing a publisher."""

    declarations = workspace["type_declarations"].get(fact.owner_fqn, [])
    return bool(
        len(declarations) == 1
        and declarations[0]["unit"] is fact.unit
        and declarations[0]["type_info"] is fact.owner_info
    )


def _method_variable_names(fact: MethodFact) -> set[str]:
    """Collect method-scoped names that can shadow static/type references."""

    names = {parameter.name for parameter in fact.parameters}
    for node in _walk(fact.body_node):
        if node.type != "variable_declarator":
            continue
        name_node = _field(node, "name")
        if name_node is not None:
            names.add(_text(fact.unit, name_node))
    return names


def _unqualified_static_member_resolves(
    fact: MethodFact,
    member: str,
    expected_owner: str,
    method_index: MethodIndex,
) -> bool:
    """Prove an unqualified DSL call belongs to exactly the expected owner."""

    # A member declared in the lexical class wins over a static import.
    if method_index.by_owner_name.get((fact.owner_fqn, member)):
        return False
    imports = fact.unit["imports"]
    if member in imports["static_exact"]:
        return imports["static_exact"][member] == f"{expected_owner}.{member}"
    if expected_owner not in imports["static_wildcards"]:
        return False
    # Without dependency bytecode, two on-demand owners are ambiguous for a
    # static method name.  An exact source model must not guess which declares
    # the member.
    return imports["static_wildcards"] == {expected_owner}


def _call_has_owner(
    fact: MethodFact,
    invocation: Any,
    member: str,
    expected_owner: str,
    method_index: MethodIndex,
) -> bool:
    """Resolve a qualified or static-imported DSL call to one framework type."""

    if _invocation_name(fact.unit, invocation) != member:
        return False
    object_node = _field(invocation, "object")
    if object_node is None:
        return _unqualified_static_member_resolves(
            fact, member, expected_owner, method_index
        )
    if object_node.type not in {"identifier", "scoped_identifier"}:
        return False
    spelling = _text(fact.unit, object_node).strip()
    if object_node.type == "identifier" and spelling in _method_variable_names(fact):
        return False
    simple_name = expected_owner.rsplit(".", 1)[-1]
    package = expected_owner.rsplit(".", 1)[0]
    return (
        resolve_known_type(
            fact.unit, spelling, simple_name, (package,), object_node
        )
        == package
    )


def _router_function_family(fact: MethodFact) -> str | None:
    """Classify a publisher return as servlet or WebFlux RouterFunction."""

    raw = _raw_type_node(fact.return_type_node)
    if raw is None:
        return None
    spelling = _text(fact.unit, raw)
    packages = tuple(FUNCTIONAL_FAMILIES.values())
    package = resolve_known_type(
        fact.unit, spelling, "RouterFunction", packages, raw
    )
    for family, expected_package in FUNCTIONAL_FAMILIES.items():
        if package == expected_package:
            return family
    return None


def _single_direct_return(fact: MethodFact) -> Any:
    """Select the sole top-level route publication expression."""

    returns = [node for node in _walk(fact.body_node) if node.type == "return_statement"]
    direct = [
        node
        for node in fact.body_node.named_children
        if node.type == "return_statement"
    ]
    if len(returns) != 1 or len(direct) != 1 or returns[0] != direct[0]:
        return None
    return _only_named_child(direct[0])


def _resolve_path(
    fact: MethodFact,
    workspace: dict[str, Any],
    node: Any,
) -> str | None:
    """Resolve and normalize one static route path through the shared workspace."""

    value = resolve_workspace_string_expression(
        fact.unit, node, workspace, fact.owner_name
    )
    if value is None:
        return None
    return join_endpoint_paths("", ensure_path_leading_slash(value))


def _direct_variable_initializer(
    fact: MethodFact,
    name: str,
    simple_type: str,
    package: str,
) -> Any:
    """Resolve one directly declared, typed final-field initializer.

    This deliberately is not general Java data flow.  It exists so a common
    functional-route predicate such as ``static final RequestPredicate JSON =
    accept(...)`` can be proven route-identity-neutral without accepting an
    arbitrary identifier that might conceal another path or HTTP method.
    """
    candidates = []
    owner_body = _field(fact.owner_info["node"], "body")
    if owner_body is not None:
        for declaration in owner_body.named_children:
            if declaration.type != "field_declaration":
                continue
            if "final" not in declaration_modifier_names(declaration):
                continue
            type_node = _field(declaration, "type")
            if type_node is None or not _known_type_node(fact.unit, type_node, simple_type, package
            ):
                continue
            for declarator in declaration.named_children:
                if declarator.type != "variable_declarator":
                    continue
                name_node = _field(declarator, "name")
                value_node = _field(declarator, "value")
                if (
                    name_node is not None
                    and value_node is not None
                    and _text(fact.unit, name_node) == name
                ):
                    candidates.append(value_node)

    return candidates[0] if len(candidates) == 1 else None


def _is_route_identity_neutral_predicate(
    fact: MethodFact,
    family: str,
    node: Any,
    method_index: MethodIndex,
    *,
    depth: int = 0,
    resolving: frozenset[str] = frozenset(),
) -> bool:
    """Validate a predicate that cannot change the emitted path or verb."""
    if depth > FUNCTIONAL_MAX_NEST_DEPTH:
        return False
    current = _unwrap_parentheses(node)
    if current is None:
        return False
    package = FUNCTIONAL_FAMILIES[family]
    if current.type == "identifier":
        name = _text(fact.unit, current)
        if name in resolving or name in _method_variable_names(fact):
            return False
        initializer = _direct_variable_initializer(fact, name, "RequestPredicate", package
        )
        return bool(
            initializer is not None
            and _is_route_identity_neutral_predicate(fact,
                family,
                initializer,
                method_index,
                depth=depth + 1,
                resolving=resolving | {name},
            )
        )
    if current.type != "method_invocation":
        return False

    name = _invocation_name(fact.unit, current)
    arguments = _arguments(current)
    receiver = _field(current, "object")
    if name in {"and", "or"}:
        return bool(
            receiver is not None
            and arguments is not None
            and len(arguments) == 1
            and _is_route_identity_neutral_predicate(fact,
                family,
                receiver,
                method_index,
                depth=depth + 1,
                resolving=resolving,
            )
            and _is_route_identity_neutral_predicate(fact,
                family,
                arguments[0],
                method_index,
                depth=depth + 1,
                resolving=resolving,
            )
        )
    if name == "negate":
        return bool(
            receiver is not None
            and arguments == []
            and _is_route_identity_neutral_predicate(fact,
                family,
                receiver,
                method_index,
                depth=depth + 1,
                resolving=resolving,
            )
        )
    if name is None or arguments is None:
        return False
    # A second path/method predicate changes endpoint identity and cannot be
    # silently treated as metadata.  Header/media/query predicates are safe
    # to omit from the six-column endpoint identity.
    if name in FUNCTIONAL_VERBS or name in {"path", "method"}:
        return False
    expected_owner = f"{package}.RequestPredicates"
    return _call_has_owner(fact, current, name, expected_owner, method_index
    )


def _bind_this_handler(
    fact: MethodFact,
    node: Any,
    method_index: MethodIndex,
) -> MethodFact | None:
    """Bind an exact, unambiguous same-owner ``this::handler`` reference."""

    current = _unwrap_parentheses(node)
    if current is None or current.type != "method_reference":
        return None
    children = list(current.named_children)
    if (
        len(children) != 2
        or children[0].type != "this"
        or children[1].type != "identifier"
    ):
        return None
    name = _text(fact.unit, children[1])
    candidates = method_index.by_owner_name.get((fact.owner_fqn, name), ())
    # Even differently aritied overloads can participate in Java method-
    # reference inference.  The bounded analyzer does not emulate javac.
    if len(candidates) != 1:
        return None
    candidate = candidates[0]
    if len(candidate.parameters) != 1 or "static" in candidate.modifiers:
        return None
    return candidate


def _decode_handler(
    fact: MethodFact,
    node: Any,
    method_index: MethodIndex,
) -> tuple[bool, MethodFact | None]:
    """Accept valid bounded handler expressions and bind when exact.

    Cross-owner references and lambdas establish route publication but do not
    provide enough source identity to claim a concrete handler declaration.
    Those shapes intentionally return ``None`` so endpoint attribution falls
    back to the publishing ``@Bean`` method.
    """
    current = _unwrap_parentheses(node)
    if current is None:
        return False, None
    if current.type == "lambda_expression":
        return True, None
    if current.type != "method_reference":
        return False, None
    children = list(current.named_children)
    if len(children) != 2 or children[1].type != "identifier":
        return False, None
    if children[0].type == "this":
        name = _text(fact.unit, children[1])
        if not method_index.by_owner_name.get((fact.owner_fqn, name)):
            return False, None
        return True, _bind_this_handler(fact, current, method_index)
    if children[0].type == "identifier":
        qualifier = _text(fact.unit, children[0])
        if qualifier not in _method_variable_names(fact):
            return False, None
        return True, None
    return False, None


def _decode_selecting_predicate(
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
    selector: str,
) -> str | None:
    """Decode ``SELECTOR(path).and(route-neutral-predicate)...``."""
    current = _unwrap_parentheses(node)
    for _depth in range(FUNCTIONAL_MAX_NEST_DEPTH + 1):
        if current is None or current.type != "method_invocation":
            return None
        if _invocation_name(fact.unit, current) != "and":
            break
        arguments = _arguments(current)
        receiver = _field(current, "object")
        if (
            arguments is None
            or len(arguments) != 1
            or receiver is None
            or not _is_route_identity_neutral_predicate(fact, family, arguments[0], method_index
            )
        ):
            return None
        current = _unwrap_parentheses(receiver)
    else:
        return None

    expected_owner = f"{FUNCTIONAL_FAMILIES[family]}.RequestPredicates"
    if not _call_has_owner(fact, current, selector, expected_owner, method_index
    ):
        return None
    arguments = _arguments(current)
    if arguments is None or len(arguments) != 1:
        return None
    return _resolve_path(fact, workspace, arguments[0])


def _decode_predicate(
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
) -> tuple[str, str] | None:
    """Decode one functional selector into its fixed verb and static path."""

    invocation = _unwrap_parentheses(node)
    while (
        invocation is not None
        and invocation.type == "method_invocation"
        and _invocation_name(fact.unit, invocation) == "and"
    ):
        receiver = _field(invocation, "object")
        if receiver is None:
            return None
        invocation = _unwrap_parentheses(receiver)
    verb = _invocation_name(fact.unit, invocation)
    if verb not in FUNCTIONAL_VERBS:
        return None
    path = _decode_selecting_predicate(fact, workspace, family, node, method_index, verb
    )
    return (verb, path) if path is not None else None


def _lambda_parameter_and_body(
    fact: MethodFact, node: Any
) -> tuple[str, Any] | None:
    """Decode the single inferred alias used by a bounded nested builder."""

    current = _unwrap_parentheses(node)
    if current is None or current.type != "lambda_expression":
        return None
    parameters = _field(current, "parameters")
    body = _field(current, "body")
    if parameters is None or body is None or parameters.type != "identifier":
        return None
    return _text(fact.unit, parameters), body


def _decode_builder_route_arguments(
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    invocation: Any,
    method_index: MethodIndex,
) -> tuple[str, MethodFact | None] | None:
    """Decode a fixed-verb builder call's path, neutral predicate, and handler."""

    arguments = _arguments(invocation)
    if arguments is None or len(arguments) not in {2, 3}:
        return None
    if len(arguments) == 3 and not _is_route_identity_neutral_predicate(fact, family, arguments[1], method_index
    ):
        return None
    handler_node = arguments[-1]
    valid_handler, handler = _decode_handler(fact, handler_node, method_index
    )
    path = _resolve_path(fact, workspace, arguments[0])
    if not valid_handler or path is None:
        return None
    return path, handler


def _decode_builder_chain(
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
    *,
    prefix: str = "",
    base_alias: str | None = None,
    nest_depth: int = 0,
    budget: dict[str, int] | None = None,
) -> tuple[bool, list[tuple[str, str, MethodFact | None, Any]]]:
    """Walk a bounded fluent/nested builder and collect route publications."""

    budget = budget if budget is not None else {"steps": 0, "routes": 0}
    budget["steps"] += 1
    if (
        budget["steps"] > FUNCTIONAL_MAX_CHAIN_STEPS
        or nest_depth > FUNCTIONAL_MAX_NEST_DEPTH
    ):
        return False, []
    current = _unwrap_parentheses(node)
    if current is None:
        return False, []
    if current.type == "block" and base_alias is not None:
        routes: list[tuple[str, str, MethodFact | None, Any]] = []
        for statement in current.named_children:
            if statement.type in {"line_comment", "block_comment"}:
                continue
            if statement.type != "expression_statement":
                return False, []
            expression = _only_named_child(statement)
            if expression is None:
                return False, []
            valid, statement_routes = _decode_builder_chain(fact,
                workspace,
                family,
                expression,
                method_index,
                prefix=prefix,
                base_alias=base_alias,
                nest_depth=nest_depth,
                budget=budget,
            )
            if not valid:
                return False, []
            routes.extend(statement_routes)
        return True, routes
    if base_alias is not None and current.type == "identifier":
        return (_text(fact.unit, current) == base_alias), []
    if current.type != "method_invocation":
        return False, []

    name = _invocation_name(fact.unit, current)
    receiver = _field(current, "object")
    if name == "route" and base_alias is None:
        expected_owner = f"{FUNCTIONAL_FAMILIES[family]}.RouterFunctions"
        return bool(
            _call_has_owner(fact, current, "route", expected_owner, method_index
            )
            and _arguments(current) == []
        ), []
    if receiver is None:
        return False, []

    valid, decoded = _decode_builder_chain(fact,
        workspace,
        family,
        receiver,
        method_index,
        prefix=prefix,
        base_alias=base_alias,
        nest_depth=nest_depth,
        budget=budget,
    )
    if not valid:
        return False, []

    if name in FUNCTIONAL_VERBS:
        route = _decode_builder_route_arguments(fact, workspace, family, current, method_index
        )
        if route is None:
            return False, []
        path, handler = route
        budget["routes"] += 1
        if budget["routes"] > FUNCTIONAL_MAX_ROUTES:
            return False, []
        decoded.append(
            (name, join_endpoint_paths(prefix, path), handler, current)
        )
        return True, decoded

    if name != "nest":
        return False, []
    arguments = _arguments(current)
    if arguments is None or len(arguments) != 2:
        return False, []
    nested_path = _decode_selecting_predicate(fact,
        workspace,
        family,
        arguments[0],
        method_index,
        "path",
    )
    lambda_parts = _lambda_parameter_and_body(fact, arguments[1])
    if nested_path is None or lambda_parts is None:
        return False, []
    alias, body = lambda_parts
    nested_prefix = join_endpoint_paths(prefix, nested_path)
    nested_valid, nested_routes = _decode_builder_chain(fact,
        workspace,
        family,
        body,
        method_index,
        prefix=nested_prefix,
        base_alias=alias,
        nest_depth=nest_depth + 1,
        budget=budget,
    )
    if not nested_valid:
        return False, []
    return True, decoded + nested_routes


def _decode_builder(
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    build_call: Any,
    method_index: MethodIndex,
) -> tuple[bool, list[tuple[str, str, MethodFact | None, Any]]]:
    """Validate terminal ``build()`` and decode its preceding builder chain."""

    if _arguments(build_call) != []:
        return False, []
    receiver = _field(build_call, "object")
    if receiver is None:
        return False, []
    return _decode_builder_chain(fact, workspace, family, receiver, method_index
    )


def _decode_functional_expression(
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
    *,
    nest_depth: int = 0,
) -> tuple[bool, list[tuple[str, str, MethodFact | None, Any]]]:
    """Decode supported direct, andRoute, nest, or builder route expressions."""

    invocation = _unwrap_parentheses(node)
    if invocation is None or invocation.type != "method_invocation":
        return False, []
    name = _invocation_name(fact.unit, invocation)
    if name == "build":
        return _decode_builder(fact, workspace, family, invocation, method_index
        )
    if name == "andRoute":
        arguments = _arguments(invocation)
        receiver = _field(invocation, "object")
        if receiver is None or arguments is None or len(arguments) != 2:
            return False, []
        valid, routes = _decode_functional_expression(fact,
            workspace,
            family,
            receiver,
            method_index,
            nest_depth=nest_depth,
        )
        predicate = _decode_predicate(fact, workspace, family, arguments[0], method_index
        )
        valid_handler, handler = _decode_handler(fact, arguments[1], method_index
        )
        if not valid or predicate is None or not valid_handler:
            return False, []
        verb, path = predicate
        return True, routes + [(verb, path, handler, invocation)]
    expected_owner = f"{FUNCTIONAL_FAMILIES[family]}.RouterFunctions"
    if name == "nest":
        if nest_depth >= FUNCTIONAL_MAX_NEST_DEPTH or not _call_has_owner(fact, invocation, "nest", expected_owner, method_index
        ):
            return False, []
        arguments = _arguments(invocation)
        if arguments is None or len(arguments) != 2:
            return False, []
        nested_path = _decode_selecting_predicate(fact,
            workspace,
            family,
            arguments[0],
            method_index,
            "path",
        )
        if nested_path is None:
            return False, []
        valid, routes = _decode_functional_expression(fact,
            workspace,
            family,
            arguments[1],
            method_index,
            nest_depth=nest_depth + 1,
        )
        if not valid:
            return False, []
        return True, [
            (verb, join_endpoint_paths(nested_path, path), handler, route_node)
            for verb, path, handler, route_node in routes
        ]
    if name != "route":
        return False, []
    if not _call_has_owner(fact, invocation, "route", expected_owner, method_index
    ):
        return False, []
    arguments = _arguments(invocation)
    if arguments is None or len(arguments) != 2:
        return False, []
    predicate = _decode_predicate(fact, workspace, family, arguments[0], method_index
    )
    valid_handler, handler = _decode_handler(fact, arguments[1], method_index
    )
    if predicate is None or not valid_handler:
        return False, []
    verb, path = predicate
    return True, [(verb, path, handler, invocation)]


def _handler_endpoint(
    method: str,
    path: str,
    handler: MethodFact | None,
    *,
    publisher: MethodFact | None = None,
    route_node: Any = None,
) -> EndpointFact:
    """Create a route fact attributed to an exact handler or its publisher."""

    publisher = publisher or handler
    if publisher is None:
        raise ValueError("Spring route endpoint requires publisher evidence")
    effective_handler = handler or publisher
    route_node = publisher.node if route_node is None else route_node
    # Registrations have no request-method annotation. Route and handler
    # locations remain separate, while represented-target evidence identifies
    # the declaration that should disappear from the unmatched audit.
    endpoint = EndpointFact(
        path=path,
        method=method,
        parameters=parameter_list_source_text(
            effective_handler.unit["source"], effective_handler.parameters_node
        ),
        source_file=effective_handler.unit["source_path"],
        source_line=effective_handler.node.start_point.row + 1,
        handler_name=f"{effective_handler.owner_name}.{effective_handler.name}",
        route_source_file=publisher.unit["source_path"],
        route_source_line=route_node.start_point.row + 1,
        handler_source_file=effective_handler.unit["source_path"],
        handler_source_line=effective_handler.node.start_point.row + 1,
        project_source_file=publisher.unit["source_path"],
        technology="spring",
        protocol="http",
        surface="server",
        direction="inbound",
        annotation_evidence=(),
        represented_targets=represented_target_evidence(
            effective_handler.unit["source_path"], "method", effective_handler.node
        ),
    )
    record_diagnostic(format_endpoint_diagnostic(endpoint))
    return endpoint


def _analyze_functional_routes(
    workspace: dict[str, Any], method_index: MethodIndex
) -> list[EndpointFact]:
    """Collect bounded routes from genuine Bean RouterFunction publishers."""

    endpoints: list[EndpointFact] = []
    for fact in method_index.methods:
        if not _owner_is_concrete_class(fact) or not _owner_is_unique(
            workspace, fact
        ):
            continue
        bean = _known_direct_annotation(fact.unit,
            fact.node,
            "Bean",
            SPRING_CONTEXT_ANNOTATION_PACKAGE,
        )
        if bean is None:
            continue
        family = _router_function_family(fact)
        if family is None:
            _log(fact.unit, fact.owner_name, "@Bean with unsupported RouterFunction type", fact.return_type_node)
            continue
        return_expression = _single_direct_return(fact)
        if return_expression is None:
            _log(fact.unit, fact.owner_name, "functional route with non-direct return flow", fact.node)
            continue
        valid, routes = _decode_functional_expression(fact,
            workspace,
            family,
            return_expression,
            method_index,
        )
        if not valid or not routes:
            _log(fact.unit, fact.owner_name, "unsupported functional route expression", return_expression)
            continue
        for verb, path, handler, route_node in routes:
            endpoints.append(
                _handler_endpoint(verb,
                    path,
                    handler,
                    publisher=fact,
                    route_node=route_node,
                )
            )
    return endpoints


def _resolve_source_type(
    unit: dict[str, Any],
    type_node: Any,
    owner_name: str,
    workspace: dict[str, Any],
) -> str | None:
    """Resolve a type spelling to one accessible source declaration."""

    raw = _raw_type_node(type_node)
    if raw is None:
        return None
    candidates = resolve_workspace_owner_fqns(
        unit, _text(unit, raw).strip(), owner_name, workspace
    )
    if len(candidates) != 1:
        return None
    fqn = candidates[0]
    declarations = workspace["type_declarations"].get(fqn, [])
    if len(declarations) != 1:
        return None
    return (
        fqn
        if workspace_type_accessible(declarations[0], unit, owner_name)
        else None
    )


def _canonical_named_type(
    unit: dict[str, Any],
    node: Any,
    owner_name: str,
    workspace: dict[str, Any],
) -> str | None:
    """Canonicalize a named Java type for reflected-signature comparison."""

    spelling = _text(unit, node).strip()
    source_candidates = resolve_workspace_owner_fqns(
        unit, spelling, owner_name, workspace
    )
    if len(source_candidates) == 1:
        return source_candidates[0]
    if source_candidates:
        return None

    if "." in spelling:
        first, suffix = spelling.split(".", 1)
        imported = unit["imports"]["exact"].get(first)
        if imported:
            return f"{imported}.{suffix}"
        # A lower-case leading package segment is an explicitly qualified
        # external identity.  Upper-case relative nested types require source
        # resolution and were rejected above.
        if first and first[0].islower():
            return spelling
        return None

    imported = unit["imports"]["exact"].get(spelling)
    if imported:
        return imported
    if spelling in JAVA_LANG_TYPES:
        return f"java.lang.{spelling}"
    return None


def _canonical_type(
    unit: dict[str, Any],
    type_node: Any,
    owner_name: str,
    workspace: dict[str, Any],
    *,
    varargs: bool = False,
) -> str | None:
    """Canonicalize primitive, named, array, and varargs parameter shapes."""

    node = _raw_type_node(type_node)
    if node is None:
        return None
    suffix = "[]" if varargs else ""
    if node.type == "array_type":
        element = _field(node, "element")
        if element is None:
            return None
        base = _canonical_type(unit, element, owner_name, workspace)
        dimensions = sum(
            max(1, _text(unit, child).count("["))
            for child in node.named_children
            if child.type == "dimensions"
        )
        return f"{base}{'[]' * dimensions}{suffix}" if base is not None else None
    if node.type in {
        "boolean_type",
        "floating_point_type",
        "integral_type",
        "void_type",
    }:
        return f"{_text(unit, node).strip()}{suffix}"
    if node.type not in {"type_identifier", "scoped_type_identifier"}:
        return None
    base = _canonical_named_type(unit, node, owner_name, workspace)
    return f"{base}{suffix}" if base is not None else None


def _class_literal_type(
    unit: dict[str, Any],
    node: Any,
    owner_name: str,
    workspace: dict[str, Any],
) -> str | None:
    """Decode one class literal into its canonical reflected parameter type."""

    current = _unwrap_parentheses(node)
    if current is None or current.type != "class_literal":
        return None
    children = list(current.named_children)
    if len(children) != 1:
        return None
    return _canonical_type(unit, children[0], owner_name, workspace
    )


def _decode_reflected_method(
    registration_method: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    node: Any,
) -> tuple[MethodFact, str] | None:
    """Bind ``Class.getMethod`` to exactly one public source handler method."""

    invocation = _unwrap_parentheses(node)
    if _invocation_name(registration_method.unit, invocation) != "getMethod":
        return None
    object_node = _field(invocation, "object")
    arguments = _arguments(invocation)
    if (
        object_node is None
        or object_node.type != "class_literal"
        or arguments is None
        or not arguments
    ):
        return None
    owner_children = list(object_node.named_children)
    if len(owner_children) != 1:
        return None
    target_fqn = _resolve_source_type(registration_method.unit,
        owner_children[0],
        registration_method.owner_name,
        workspace,
    )
    if target_fqn is None:
        return None
    target_declarations = workspace["type_declarations"].get(target_fqn, [])
    target_info = target_declarations[0]["type_info"]
    if target_info["node"].type != "class_declaration" or target_info["abstract"]:
        return None

    method_name = resolve_workspace_string_expression(
        registration_method.unit,
        arguments[0],
        workspace,
        registration_method.owner_name,
    )
    if not method_name:
        return None
    reflected_parameters: list[str] = []
    for argument in arguments[1:]:
        canonical = _class_literal_type(registration_method.unit,
            argument,
            registration_method.owner_name,
            workspace,
        )
        if canonical is None:
            return None
        reflected_parameters.append(canonical)

    matches: list[MethodFact] = []
    for candidate in method_index.by_owner_name.get((target_fqn, method_name), ()):
        if "public" not in candidate.modifiers or "static" in candidate.modifiers:
            continue
        canonical_parameters = [
            _canonical_type(candidate.unit,
                parameter.type_node,
                candidate.owner_name,
                workspace,
                varargs=parameter.varargs,
            )
            for parameter in candidate.parameters
        ]
        if None in canonical_parameters:
            continue
        if canonical_parameters == reflected_parameters:
            matches.append(candidate)
    return (matches[0], target_fqn) if len(matches) == 1 else None


def _decode_request_mapping_info(
    registration_method: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    node: Any,
) -> tuple[list[str], list[str]] | None:
    """Decode the supported RequestMappingInfo path/method builder shape."""

    build_call = _unwrap_parentheses(node)
    if _invocation_name(registration_method.unit, build_call) != "build":
        return None
    if _arguments(build_call) != []:
        return None
    current = _field(build_call, "object")
    methods: list[str] = []
    if _invocation_name(registration_method.unit, current) == "methods":
        method_arguments = _arguments(current)
        if not method_arguments:
            return None
        for argument in method_arguments:
            value = resolve_spring_request_method_expression(
                registration_method.unit,
                argument,
            )
            if value is None:
                return None
            methods.append(value)
        current = _field(current, "object")
    if _invocation_name(registration_method.unit, current) != "paths":
        return None
    expected_owner = f"{MVC_REQUEST_MAPPING_INFO_PACKAGE}.RequestMappingInfo"
    if not _call_has_owner(registration_method,
        current,
        "paths",
        expected_owner,
        method_index,
    ):
        return None
    path_arguments = _arguments(current)
    if not path_arguments:
        return None
    paths: list[str] = []
    for argument in path_arguments:
        path = _resolve_path(registration_method, workspace, argument)
        if path is None:
            return None
        paths.append(path)
    return list(dict.fromkeys(paths)), list(dict.fromkeys(methods or ["ANY"]))


def _local_declarators(local: Any) -> list[Any]:
    """Return declarators used by the bounded registration-local data flow."""

    return [
        child for child in local.named_children if child.type == "variable_declarator"
    ]


def _tracked_local_kind(
    registration_method: MethodFact, local: Any
) -> str | None:
    """Classify a local as mapping-info or reflected-method evidence."""

    type_node = _field(local, "type")
    if type_node is None:
        return None
    if _known_type_node(registration_method.unit,
        type_node,
        "RequestMappingInfo",
        MVC_REQUEST_MAPPING_INFO_PACKAGE,
    ):
        return "info"
    if _known_type_node(registration_method.unit, type_node, "Method", REFLECT_PACKAGE
    ):
        return "method"
    return None


def _direct_expression(statement: Any) -> Any:
    """Select an expression only when it is a direct body statement."""

    if statement.type != "expression_statement":
        return None
    return _only_named_child(statement)


def _mapping_invocations(
    registration_method: MethodFact,
    mapping_name: str,
    call_name: str,
) -> list[Any]:
    """Find calls on the exact handler-mapping parameter by method name."""

    calls = []
    for node in _walk(registration_method.body_node):
        if _invocation_name(registration_method.unit, node) != call_name:
            continue
        receiver = _field(node, "object")
        if (
            receiver is not None
            and receiver.type == "identifier"
            and _text(registration_method.unit, receiver) == mapping_name
        ):
            calls.append(node)
    return calls


def _has_tracked_mutation(
    registration_method: MethodFact,
    tracked_names: set[str],
    direct_locals: set[tuple[int, int]],
) -> bool:
    """Reject reassignment/redeclaration that invalidates bounded data flow."""

    for node in _walk(registration_method.body_node):
        if node.type == "local_variable_declaration":
            for declarator in _local_declarators(node):
                name_node = _field(declarator, "name")
                if (
                    name_node is not None
                    and _text(registration_method.unit, name_node) in tracked_names
                    and (node.start_byte, node.end_byte) not in direct_locals
                ):
                    return True
        if node.type == "assignment_expression":
            left = _field(node, "left")
            if (
                left is not None
                and left.type == "identifier"
                and _text(registration_method.unit, left) in tracked_names
            ):
                return True
        if node.type == "update_expression":
            for child in node.named_children:
                if child.type == "identifier" and _text(registration_method.unit, child) in tracked_names:
                    return True
    return False


def _resolve_local_argument(
    unit: dict[str, Any],
    node: Any,
    expected_kind: str,
    locals_by_name: dict[str, tuple[str, Any, int]],
    statement_index: int,
) -> Any:
    """Inline one earlier uniquely typed local at a registration call site."""

    current = _unwrap_parentheses(node)
    if current is None or current.type != "identifier":
        return current
    record = locals_by_name.get(_text(unit, current))
    if record is None:
        return None
    kind, value, declaration_index = record
    return value if kind == expected_kind and declaration_index < statement_index else None


def _is_programmatic_registration_owner(
    fact: MethodFact
) -> bool:
    """Require genuine Configuration activation on a concrete owner."""

    return bool(
        _owner_is_concrete_class(fact)
        and _known_direct_annotation(fact.unit,
            fact.owner_info["node"],
            "Configuration",
            SPRING_CONTEXT_ANNOTATION_PACKAGE,
        )
        is not None
    )


def _analyze_programmatic_registration_method(
    workspace: dict[str, Any],
    method_index: MethodIndex,
    registration_method: MethodFact,
) -> list[EndpointFact]:
    """Extract sound registerMapping calls from one canonical Autowired method."""

    if "static" in registration_method.modifiers or _text(registration_method.unit, registration_method.return_type_node).strip() != "void":
        return []
    autowired = _known_direct_annotation(registration_method.unit,
        registration_method.node,
        "Autowired",
        SPRING_BEANS_ANNOTATION_PACKAGE,
        marker_only=True,
    )
    if autowired is None:
        return []
    mapping_parameters = [
        parameter
        for parameter in registration_method.parameters
        if _known_type_node(registration_method.unit,
            parameter.type_node,
            "RequestMappingHandlerMapping",
            MVC_HANDLER_MAPPING_PACKAGE,
        )
    ]
    if len(mapping_parameters) != 1:
        _log(registration_method.unit, registration_method.owner_name, "programmatic registration with ambiguous mapping parameter", registration_method.node)
        return []
    mapping_name = mapping_parameters[0].name
    register_calls = _mapping_invocations(registration_method, mapping_name, "registerMapping"
    )
    if not register_calls:
        return []
    if _mapping_invocations(registration_method, mapping_name, "unregisterMapping"):
        _log(registration_method.unit, registration_method.owner_name, "registration paired with unregisterMapping", registration_method.node)
        return []
    if any(
        node is not registration_method.body_node and node.type in CONTROL_FLOW_NODES
        for node in _walk(registration_method.body_node)
    ):
        _log(registration_method.unit, registration_method.owner_name, "registration with unsupported control flow", registration_method.node)
        return []

    statements = list(registration_method.body_node.named_children)
    direct_register: dict[tuple[int, int], int] = {}
    for index, statement in enumerate(statements):
        expression = _direct_expression(statement)
        if expression is not None and expression.type == "method_invocation":
            direct_register[(expression.start_byte, expression.end_byte)] = index
    if any(
        (call.start_byte, call.end_byte) not in direct_register
        for call in register_calls
    ):
        _log(registration_method.unit, registration_method.owner_name, "nested programmatic registration", registration_method.node)
        return []

    locals_by_name: dict[str, tuple[str, Any, int]] = {}
    direct_locals: set[tuple[int, int]] = set()
    invalid_locals = False
    for index, statement in enumerate(statements):
        if statement.type != "local_variable_declaration":
            continue
        kind = _tracked_local_kind(registration_method, statement)
        if kind is None:
            continue
        direct_locals.add((statement.start_byte, statement.end_byte))
        declarators = _local_declarators(statement)
        if len(declarators) != 1:
            invalid_locals = True
            continue
        name_node = _field(declarators[0], "name")
        value_node = _field(declarators[0], "value")
        if name_node is None or value_node is None:
            invalid_locals = True
            continue
        name = _text(registration_method.unit, name_node)
        if name in locals_by_name:
            invalid_locals = True
            continue
        locals_by_name[name] = (kind, value_node, index)
    tracked_names = set(locals_by_name)
    protected_names = tracked_names | {
        parameter.name for parameter in registration_method.parameters
    }
    if invalid_locals or _has_tracked_mutation(registration_method, protected_names, direct_locals
    ):
        _log(registration_method.unit, registration_method.owner_name, "mutated or ambiguous registration local", registration_method.node)
        return []

    formals_by_name = {parameter.name: parameter for parameter in registration_method.parameters}
    endpoints: list[EndpointFact] = []
    for call in register_calls:
        statement_index = direct_register[(call.start_byte, call.end_byte)]
        arguments = _arguments(call)
        if arguments is None or len(arguments) != 3:
            _log(registration_method.unit, registration_method.owner_name, "registerMapping with unsupported arguments", call)
            continue
        info_expression = _resolve_local_argument(
            registration_method.unit,
            arguments[0],
            "info",
            locals_by_name,
            statement_index,
        )
        method_expression = _resolve_local_argument(
            registration_method.unit,
            arguments[2],
            "method",
            locals_by_name,
            statement_index,
        )
        info = (
            _decode_request_mapping_info(registration_method,
                workspace,
                method_index,
                info_expression,
            )
            if info_expression is not None
            else None
        )
        reflected = (
            _decode_reflected_method(registration_method,
                workspace,
                method_index,
                method_expression,
            )
            if method_expression is not None
            else None
        )
        handler_argument = _unwrap_parentheses(arguments[1])
        if (
            info is None
            or reflected is None
            or handler_argument is None
            or handler_argument.type != "identifier"
        ):
            _log(registration_method.unit, registration_method.owner_name, "unresolved registerMapping arguments", call)
            continue
        handler_parameter = formals_by_name.get(
            _text(registration_method.unit, handler_argument)
        )
        handler_method, target_fqn = reflected
        handler_fqn = (
            _resolve_source_type(registration_method.unit,
                handler_parameter.type_node,
                registration_method.owner_name,
                workspace,
            )
            if handler_parameter is not None
            else None
        )
        if handler_fqn != target_fqn:
            _log(registration_method.unit, registration_method.owner_name, "handler/reflection type mismatch", call)
            continue
        paths, methods = info
        for path in paths:
            for method in methods:
                endpoints.append(
                    _handler_endpoint(method,
                        path,
                        handler_method,
                        publisher=registration_method,
                        route_node=call,
                    )
                )
    return endpoints


def _analyze_programmatic_mvc_registrations(
    workspace: dict[str, Any], method_index: MethodIndex
) -> list[EndpointFact]:
    """Collect imperative MVC registrations from unique configuration owners."""

    endpoints: list[EndpointFact] = []
    registration_owner_eligibility: dict[str, bool] = {}
    for fact in method_index.methods:
        eligible_owner = registration_owner_eligibility.setdefault(
            fact.owner_fqn,
            _owner_is_unique(workspace, fact) and _is_programmatic_registration_owner(fact),
        )
        if not eligible_owner:
            continue
        endpoints.extend(
            _analyze_programmatic_registration_method(workspace, method_index, fact)
        )
    return endpoints


def _deduplicate(
    endpoints: Iterable[EndpointFact],
) -> tuple[EndpointFact, ...]:
    """Merge exact registration facts while retaining typed evidence."""

    return deduplicate_endpoint_facts(
        endpoints,
        lambda endpoint: (
            endpoint.path,
            endpoint.method,
            endpoint.parameters,
            endpoint.source_file,
            endpoint.source_line,
            endpoint.handler_name,
        ),
    )


def analyze_spring_route_registrations(
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return bounded functional and programmatic Spring endpoints.

    ``workspace`` must be returned by ``build_java_workspace``
    (``include_jax_rs_indexes`` may be false). The function has no side
    effects other than recording into the bound run collector, and it never
    suppresses endpoints collected by the direct analyzer.
    """

    method_index = _build_method_index(workspace)
    endpoints = _analyze_functional_routes(workspace, method_index)
    endpoints.extend(
        _analyze_programmatic_mvc_registrations(
            workspace, method_index
        )
    )
    return _deduplicate(endpoints)


__all__ = ["analyze_spring_route_registrations"]
