"""Render and publish deterministic companion analysis reports.

This module is the presentation boundary for human-readable annotation
artifacts.  It depends only on normalized inventory/evidence data and has no
knowledge of Java parsing, framework analyzers, or the CLI entry point.

Logic guide: ``p6.logic/07-output-evidence-reports.md`` (companion views and
artifact failure boundaries).
"""

from __future__ import annotations

import os
from collections.abc import Iterable
from pathlib import Path
import tempfile
from typing import Any

from .evidence import merge_represented_targets
from .model import SourceTarget


def annotation_inventory_lines(inventory: Any) -> list[str]:
    """Render the broad audit inventory as newline-free deterministic lines.

    The inventory is intentionally broader than endpoint triggers: it answers
    what relevant framework annotation evidence was seen, independently of
    whether a later analyzer could prove an endpoint.
    """

    lines = []
    for file_index, file_record in enumerate(inventory):
        if file_index:
            lines.append("")
        lines.append(f"File: {file_record['file']}")
        annotations = file_record["annotations"]
        if not annotations:
            lines.append("Annotations: none")
            continue
        lines.append("Annotations:")
        for annotation_index, annotation in enumerate(annotations):
            if annotation_index:
                lines.append("")
            lines.append(f"  - Annotation: {annotation['name']}")
            lines.append(f"    Line: {annotation['line']}")
            lines.append("    Frameworks:")
            for framework in annotation["frameworks"]:
                lines.append(
                    f"      - Framework: {framework['framework']}"
                )
                lines.append(f"        Resolved: {framework['resolved']}")
            lines.append("    Extract:")
            lines.extend(
                f"      {source_line['line']}: {source_line['source']}"
                for source_line in annotation["extract"]
            )
    return lines


def write_annotation_diagnostic_log(
    path: Any,
    inventory: Any,
    diagnostics: Any,
) -> None:
    """Directly overwrite the broad inventory-and-diagnostics companion log.

    Diagnostics are already timestamp-rendered by their run-local collector;
    this function only establishes the artifact's inventory-first layout.
    """

    lines = annotation_inventory_lines(inventory)
    if lines:
        lines.append("")
    lines.append("Diagnostics:")
    lines.extend(diagnostics)
    with open(path, "w", encoding="utf8") as report:
        report.write("\n".join(lines) + "\n")


def render_annotations_without_endpoints_report_bytes(
    inventory: Any,
    represented_targets: Iterable[SourceTarget] = (),
) -> bytes:
    """Render final-trigger declarations not covered by surviving endpoints.

    Coverage is exact source-target identity, never a path/name heuristic.
    Invalid target evidence consequently cannot suppress an inventory entry.
    Rendering is side-effect free so the CLI can complete it before opening
    any output artifact.
    """

    # The shared validator canonicalizes, rejects malformed targets, and makes
    # membership independent of candidate order.
    represented = set(merge_represented_targets(represented_targets))
    file_blocks = []
    for file_record in sorted(inventory, key=lambda item: item["file"]):
        sections_by_framework = {
            section["framework"]: section
            for section in file_record.get("frameworks", ())
        }
        sections = []
        for framework in ("spring", "jaxrx"):
            section = sections_by_framework.get(framework)
            if section is None:
                continue
            annotations = sorted(
                (
                    annotation
                    for annotation in section.get("annotations", ())
                    if annotation.get("target") not in represented
                ),
                key=lambda annotation: (
                    annotation["start_byte"], annotation["end_byte"]
                ),
            )
            if not annotations:
                sections.append(
                    f"Framework: {framework}\n"
                    "Annotations without endpoints: none"
                )
                continue
            items = []
            for annotation in annotations:
                lines = [
                    f"  - Annotation: {annotation['name']}",
                    f"    Resolved: {annotation['resolved']}",
                    f"    Applied to: {annotation['applied_to']}",
                    f"    Line: {annotation['line']}",
                    "    Extract:",
                ]
                lines.extend(
                    f"      {source_line['line']}: {source_line['source']}"
                    for source_line in annotation["extract"]
                )
                items.append("\n".join(lines))
            sections.append(
                f"Framework: {framework}\n"
                "Annotations without endpoints:\n"
                + "\n\n".join(items)
            )
        file_blocks.append(
            f"File: {file_record['file']}"
            + ("\n" + "\n\n".join(sections) if sections else "")
        )
    if not file_blocks:
        return b""
    return ("\n\n".join(file_blocks) + "\n").encode("utf8")


def derive_annotations_without_endpoints_report_path(output_path: Any) -> Path:
    """Derive the companion path by replacing only the output's final suffix."""

    output = Path(output_path)
    base = output.with_suffix("") if output.suffix else output
    return base.with_name(base.name + "-anno-without-endpoints.log")


def publish_bytes_atomically(path: Any, payload: bytes) -> None:
    """Stage, flush, and atomically replace one prepared report payload.

    The temporary file lives beside the destination so ``os.replace`` stays on
    one filesystem.  Any ``BaseException`` triggers best-effort descriptor and
    staging-file cleanup, preserving the previous destination when replacement
    has not happened.  This guarantees one-file atomicity, not durability of
    the parent directory or rollback of artifacts published earlier by CLI.
    """

    destination = Path(path)
    descriptor = None
    temporary_path = None
    try:
        descriptor, temporary_name = tempfile.mkstemp(
            dir=str(destination.parent),
            prefix=f".{destination.name}.",
            suffix=".tmp",
        )
        temporary_path = Path(temporary_name)
        with os.fdopen(descriptor, "wb") as staged:
            descriptor = None
            staged.write(payload)
            staged.flush()
            os.fsync(staged.fileno())
        os.replace(temporary_path, destination)
        temporary_path = None
    except BaseException:
        # Cleanup must also run for cancellation/interrupt paths, while the
        # original BaseException is always re-raised unchanged.
        if descriptor is not None:
            try:
                os.close(descriptor)
            except OSError:
                pass
        if temporary_path is not None:
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                pass
        raise


__all__ = [
    "annotation_inventory_lines",
    "derive_annotations_without_endpoints_report_path",
    "publish_bytes_atomically",
    "render_annotations_without_endpoints_report_bytes",
    "write_annotation_diagnostic_log",
]
