"""Minimal executable Apache Wicket framework-integration example.

Any explicit selection containing ``--framework wicket`` runs these hooks
through the same registry lifecycle as a real family.  They intentionally
provide no Wicket endpoint semantics yet: the stub creates no annotation
classifications, workspace state, diagnostics, or endpoint facts from the
existing raw-text marker.

Logic guides: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/16-adding-framework-support.md``.
"""

from __future__ import annotations

from typing import Any

from .model import AnalysisRequest, EndpointFact


def configure_wicket_workspace(
    _workspace: dict[str, Any], *, selected: bool
) -> None:
    """Leave the neutral workspace unchanged for either selection state.

    Any explicit set containing Wicket calls this hook with ``selected=True``;
    omitted mode, auto mode, and explicit sets excluding Wicket call it with
    ``selected=False``.  The named state parameter demonstrates where future
    Wicket indexes would be attached or cleared without coupling another
    framework to them.

    Example call:
        ``configure_wicket_workspace(workspace, selected=True)`` returns
        ``None`` without adding or removing a workspace key.
    """

    return None


def prepare_wicket_analysis(
    _request: AnalysisRequest, _workspace: dict[str, Any]
) -> None:
    """Complete selected Wicket preparation without deriving semantic state.

    Example call:
        ``prepare_wicket_analysis(request, workspace)`` returns ``None`` and
        does not derive project configuration or record diagnostics.
    """

    return None


def analyze_wicket_framework(
    _request: AnalysisRequest,
    _source_paths: tuple[str, ...],
    _workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return no facts rather than treating marker text as endpoint proof.

    Any explicit set containing Wicket invokes this function, while the
    advisory Wicket marker does not auto-select it.  A future implementation
    may consume the shared source paths and workspace only after Wicket
    endpoint evidence and failure rules are specified.

    Example call:
        ``analyze_wicket_framework(request, source_paths, workspace)`` returns
        ``()`` without mutating input state or recording diagnostics.
    """

    return ()


__all__ = [
    "analyze_wicket_framework",
    "configure_wicket_workspace",
    "prepare_wicket_analysis",
]
