"""Typed application entry point with analysis-owned diagnostics.

The pipeline describes stage order; this boundary owns one diagnostic scope
and attaches its structured events to the immutable result.  It performs no
CLI parsing or artifact I/O.

Logic guide: ``p6.logic/02-cli-and-orchestration.md`` (typed application API
and run-local diagnostics).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace

from .diagnostics import DiagnosticCollector, bind, current
from .model import AnalysisRequest, AnalysisResult
from .pipeline import run_analysis


# An injectable runner keeps this small boundary independently testable while
# stage ownership remains in :mod:`noir.pipeline`.
AnalysisRunner = Callable[[AnalysisRequest], AnalysisResult]


def analyze(
    request: AnalysisRequest,
    *,
    diagnostic_collector: DiagnosticCollector | None = None,
    runner: AnalysisRunner = run_analysis,
) -> AnalysisResult:
    """Run the typed pipeline and attach only this invocation's diagnostics.

    A caller may supply or already bind a collector (the CLI does both).  In
    that case analysis participates in the existing run scope; otherwise this
    function creates a temporary scope for library use.  The entry offset is
    what prevents a nested call from claiming diagnostics recorded before it.

    This boundary deliberately leaves timestamped rendering to the collector
    and artifact persistence to :mod:`noir.cli` / :mod:`noir.reports`.
    """

    if not isinstance(request, AnalysisRequest):
        raise TypeError("request must be an AnalysisRequest")
    bound_collector = current()
    collector = (
        diagnostic_collector
        if diagnostic_collector is not None
        else bound_collector
        if bound_collector is not None
        else DiagnosticCollector()
    )
    # Snapshot the boundary, rather than clearing shared state, so a nested
    # analysis can safely append to its caller's collector.
    first_entry = len(collector)

    if current() is collector:
        result = runner(request)
    else:
        # ContextVar binding is restored even when the pipeline raises.
        with bind(collector):
            result = runner(request)

    captured = tuple(
        entry.diagnostic for entry in collector.entries[first_entry:]
    )
    # AnalysisResult is immutable; attach the slice without mutating either
    # the runner's result or the collector retained by an outer caller.
    return replace(result, diagnostics=(*result.diagnostics, *captured))


__all__ = ["AnalysisRunner", "analyze"]
