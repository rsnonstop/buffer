"""Framework-neutral Tree-sitter query sources for the shared Java frontend.

The composition edge compiles these strings once, and ``java_frontend`` runs
the resulting queries against each source's one shared syntax tree.  Captures
describe Java evidence only; Spring and JAX-RS meaning is attached later.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations


# The base set is sufficient to shape one compilation unit.  Each query keeps
# related captures in a single match so the front end never joins annotations,
# declarations, or members merely because their capture labels resemble one
# another.
JAVA_COMPILATION_UNIT_QUERY_SOURCES = {
    "annotation_declaration": r"""
        (annotation_type_declaration
            name: (identifier) @annotation.declaration.name) @annotation.declaration.node
    """,
    "field": r"""
        [
            (field_declaration
                type: (_) @constant.type
                declarator: (variable_declarator
                    name: (identifier) @constant.name
                    value: (_)? @constant.value) @constant.declarator)
            (constant_declaration
                type: (_) @constant.type
                declarator: (variable_declarator
                    name: (identifier) @constant.name
                    value: (_)? @constant.value) @constant.declarator)
        ] @constant.field
    """,
    "import": r"""
        (import_declaration) @import.node
    """,
    "type": r"""
        [
            (class_declaration name: (identifier) @type.name)
            (interface_declaration name: (identifier) @type.name)
            (enum_declaration name: (identifier) @type.name)
            (record_declaration name: (identifier) @type.name)
            (annotation_type_declaration name: (identifier) @type.name)
        ] @type.node
    """,
    "type_annotation": r"""
        (class_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @type.name
            body: (class_body) @type.body) @type.node
        (record_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @type.name
            body: (class_body) @type.body) @type.node
    """,
    "method_annotation": r"""
        (class_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
        (record_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
    """,
    "record_component_annotation": r"""
        (record_declaration
            name: (identifier) @type.name
            parameters: (formal_parameters
                (formal_parameter
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    type: (_) @component.type
                    name: (identifier) @component.name) @component.node)
            body: (class_body) @type.body) @type.node
        (record_declaration
            name: (identifier) @type.name
            parameters: (formal_parameters
                (spread_parameter
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    (variable_declarator
                        name: (identifier) @component.name) @component.declarator) @component.node)
            body: (class_body) @type.body) @type.node
    """,
    "record_method": r"""
        (record_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
    """,
}


# Audit inventory needs every occurrence, including annotations that are not
# endpoint triggers and annotations on declaration kinds not otherwise queried.
JAVA_ANNOTATION_USAGE_QUERY = r"""
    [
        (annotation
            name: [
                (identifier)
                (scoped_identifier)
            ] @annotation.name) @annotation.node
        (marker_annotation
            name: [
                (identifier)
                (scoped_identifier)
            ] @annotation.name) @annotation.node
    ]
"""


# The normal application runtime compiles this complete union.  Workspace-only
# queries add cross-file identity and source-defined annotation evidence without
# asking any later analyzer to reparse a file.
JAVA_WORKSPACE_QUERY_SOURCES = {
    **JAVA_COMPILATION_UNIT_QUERY_SOURCES,
    "annotation_usage": JAVA_ANNOTATION_USAGE_QUERY,
    "package": r"""
        (package_declaration
            [
                (identifier)
                (scoped_identifier)
            ] @package.name) @package.node
    """,
    "annotation_meta": r"""
        (annotation_type_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @annotation.declaration.name
            body: (annotation_type_body) @annotation.declaration.body
        ) @annotation.declaration.node
    """,
    "annotation_element": r"""
        (annotation_type_declaration
            name: (identifier) @annotation.declaration.name
            body: (annotation_type_body
                (annotation_type_element_declaration
                    type: (_) @annotation.element.type
                    name: (identifier) @annotation.element.name
                    value: (_)? @annotation.element.default
                ) @annotation.element.node
            )
        ) @annotation.declaration.node
    """,
    "enum_constant": r"""
        (enum_declaration
            name: (identifier) @enum.type.name
            body: (enum_body
                (enum_constant
                    name: (identifier) @enum.constant.name
                ) @enum.constant.node
            )
        ) @enum.type.node
    """,
}


__all__ = [
    "JAVA_ANNOTATION_USAGE_QUERY",
    "JAVA_COMPILATION_UNIT_QUERY_SOURCES",
    "JAVA_WORKSPACE_QUERY_SOURCES",
]
