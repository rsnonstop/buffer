"""Pinned Tree-sitter construction for Noir's Java analysis.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

from importlib import metadata
from typing import Any, Mapping

from .java_frontend import query_matches
from .java_queries import JAVA_WORKSPACE_QUERY_SOURCES


try:
    import tree_sitter_java as tsjava
    from tree_sitter import Language, Parser, Query, QueryCursor
except ModuleNotFoundError:
    # Argument parsing and ``--help`` must work without analysis dependencies.
    tsjava = None
    Language = Parser = Query = QueryCursor = None


SUPPORTED_VERSIONS = {
    "tree-sitter": "0.25.2",
    "tree-sitter-java": "0.23.5",
}


def require_tree_sitter() -> None:
    """Require the exact parser pair used to validate Noir's Java queries."""

    if tsjava is None or any(
        value is None for value in (Language, Parser, Query, QueryCursor)
    ):
        raise RuntimeError(
            "Spring/JAX-RS analysis requires the tree_sitter and "
            "tree_sitter_java Python packages"
        )
    installed = {}
    for distribution in SUPPORTED_VERSIONS:
        try:
            installed[distribution] = metadata.version(distribution)
        except metadata.PackageNotFoundError:
            installed[distribution] = None
    if installed != SUPPORTED_VERSIONS:
        actual = ", ".join(
            f"{name} {installed[name] or 'unknown'}" for name in SUPPORTED_VERSIONS
        )
        raise RuntimeError(
            f"unsupported Tree-sitter dependency pair ({actual}); install "
            "tree-sitter 0.25.2 with tree-sitter-java 0.23.5"
        )


def build_query_runtime(
    query_sources: Mapping[str, str],
    java_language: Any = None,
    parser: Any = None,
) -> dict[str, Any]:
    """Create one Java parser and compile a named query set once."""

    require_tree_sitter()
    java_language = java_language or Language(tsjava.language())
    return {
        "language": java_language,
        "parser": parser or Parser(java_language),
        "queries": {
            name: Query(java_language, source)
            for name, source in sorted(query_sources.items())
        },
    }


def build_workspace_runtime(
    java_language: Any = None,
    parser: Any = None,
) -> dict[str, Any]:
    """Build the shared Java parser and complete workspace query set."""

    return build_query_runtime(
        JAVA_WORKSPACE_QUERY_SOURCES,
        java_language=java_language,
        parser=parser,
    )


def run_query_matches(query: Any, root: Any, lifetime_owners=None):
    """Run a query while retaining its cursor for the lifetime of result nodes."""

    return query_matches(query, root, QueryCursor, lifetime_owners)


__all__ = [
    "SUPPORTED_VERSIONS",
    "build_query_runtime",
    "build_workspace_runtime",
    "require_tree_sitter",
    "run_query_matches",
]
