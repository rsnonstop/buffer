"""Pinned Tree-sitter construction for Noir's Java analysis.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

from importlib import metadata
from typing import Any, Mapping

from .java_frontend import query_matches
from .java_queries import JAVA_WORKSPACE_QUERY_SOURCES


try:
    import tree_sitter_java as tsjava
    from tree_sitter import Language, Parser, Query, QueryCursor
except ModuleNotFoundError:
    # Argument parsing and ``--help`` must work without analysis dependencies.
    tsjava = None
    Language = Parser = Query = QueryCursor = None


SUPPORTED_VERSIONS = {
    "tree-sitter": "0.25.2",
    "tree-sitter-java": "0.23.5",
}


def require_tree_sitter() -> None:
    """Require the exact parser pair used by Java application analysis.

    Example call:
        ``require_tree_sitter()`` returns ``None`` when ``tree-sitter 0.25.2``
        and ``tree-sitter-java 0.23.5`` are installed; otherwise it raises a
        ``RuntimeError`` describing the missing or unsupported pair.
    """

    if tsjava is None or any(
        value is None for value in (Language, Parser, Query, QueryCursor)
    ):
        raise RuntimeError(
            "Spring/JAX-RS analysis requires the tree_sitter and "
            "tree_sitter_java Python packages"
        )
    installed = {}
    for distribution in SUPPORTED_VERSIONS:
        try:
            installed[distribution] = metadata.version(distribution)
        except metadata.PackageNotFoundError:
            installed[distribution] = None
    if installed != SUPPORTED_VERSIONS:
        actual = ", ".join(
            f"{name} {installed[name] or 'unknown'}" for name in SUPPORTED_VERSIONS
        )
        raise RuntimeError(
            f"unsupported Tree-sitter dependency pair ({actual}); install "
            "tree-sitter 0.25.2 with tree-sitter-java 0.23.5"
        )


def build_query_runtime(
    query_sources: Mapping[str, str],
    java_language: Any = None,
    parser: Any = None,
) -> dict[str, Any]:
    """Create one Java parser and compile a named application-query set.

    Example call:
        ``build_query_runtime({"routes": "(method_declaration) @route"})``
        returns ``{"language": java_language, "parser": java_parser,
        "queries": {"routes": compiled_query}}``. Callers may pass conceptual
        ``java_language`` and ``parser`` instances to reuse existing runtime state.
    """

    require_tree_sitter()
    java_language = java_language or Language(tsjava.language())
    return {
        "language": java_language,
        "parser": parser or Parser(java_language),
        "queries": {
            name: Query(java_language, source)
            for name, source in sorted(query_sources.items())
        },
    }


def build_workspace_runtime(
    java_language: Any = None,
    parser: Any = None,
) -> dict[str, Any]:
    """Build the parser and complete query set shared by all Java passes.

    Example call:
        ``build_workspace_runtime()`` returns one runtime whose ``queries``
        mapping includes the named imports, types, annotations, constants, and
        invocation evidence used to construct a workspace.
    """

    return build_query_runtime(
        JAVA_WORKSPACE_QUERY_SOURCES,
        java_language=java_language,
        parser=parser,
    )


def run_query_matches(query: Any, root: Any, lifetime_owners=None):
    """Run one Java query while retaining its result-node lifetime owners.

    Example call:
        ``run_query_matches(compiled_route_query, java_tree.root_node,
        lifetime_owners)`` returns normalized match records for route-related
        syntax and appends the query cursor to the conceptual owner collection.
    """

    return query_matches(query, root, QueryCursor, lifetime_owners)


__all__ = [
    "SUPPORTED_VERSIONS",
    "build_query_runtime",
    "build_workspace_runtime",
    "require_tree_sitter",
    "run_query_matches",
]
