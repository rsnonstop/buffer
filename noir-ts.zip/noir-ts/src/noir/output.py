"""Endpoint projection, consolidation, and CSV rendering.

Analysis keeps rich endpoint facts. This module owns the single intentional
information-loss boundary: project facts to the stable CSV identity,
normalize paths, merge duplicate provenance, and render deterministic rows.
It does not know about Java or framework analyzer ordering. Companion report
rendering and publication live in :mod:`noir.reports`.

Logic guide: ``p6.logic/07-output-evidence-reports.md`` (the single lossy
projection, normalization, evidence merge, and exact CSV bytes).
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
import json
from pathlib import Path
import re
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Sequence

from .contracts import (
    CSV_DELIMITER,
    CSV_FIELDS,
    CSV_IDENTITY_FIELDS,
    METHOD_ANNOTATION_LINE_FIELD,
)
from .evidence import (
    merge_method_annotation_evidence,
    merge_represented_targets,
    owned_method_annotation_evidence,
    owned_represented_targets,
    select_method_annotation_evidence,
)
from .model import AnnotationEvidence, EndpointFact, SourceTarget
from .paths import relative_source_path


@dataclass(frozen=True, slots=True)
class EndpointRowCandidate:
    """One projected public identity with typed private correctness evidence."""

    # Public module label derived from the analyzed application's root name.
    module_name: str
    # Protocol/role and operation, for example ``http GET`` or ``http-client GET``.
    interface_type: str
    # Route path or message destination after public normalization.
    endpoint: str
    # Application-root-relative source identity shown to the report reader.
    source_file_name: str
    # Reader-facing type and handler/contract operation name.
    method_name: str
    # Java source spelling of the operation parameters.
    parameters: str
    # Owned scalar method annotations still eligible to supply the seventh column.
    annotation_evidence: tuple[AnnotationEvidence, ...] = ()
    # Exact declarations represented by this row candidate for absence reports.
    represented_targets: tuple[SourceTarget, ...] = ()

    # Example value:
    # EndpointRowCandidate("shop", "http GET", "/api/items",
    #                      "app/ItemsController.java", "ItemsController.list",
    #                      "String filter", (mapping_evidence,), (handler_target,))

    def __post_init__(self) -> None:
        """Seal and validate both private evidence collections.

        Example call:
            Constructing ``EndpointRowCandidate("shop", "http GET", "/items",
            "app/Items.java", "Items.list", "String filter",
            (mapping_evidence,), (handler_target,))`` invokes this validation and
            stores both evidence collections as tuples.
        """

        if isinstance(self.annotation_evidence, Mapping):
            raise TypeError("row annotation evidence must be typed")
        annotation_evidence = tuple(self.annotation_evidence)
        if not all(
            isinstance(item, AnnotationEvidence) for item in annotation_evidence
        ):
            raise TypeError(
                "row annotation evidence must contain AnnotationEvidence values"
            )
        if isinstance(self.represented_targets, Mapping):
            raise TypeError("row represented targets must be typed")
        represented_targets = tuple(self.represented_targets)
        if not all(isinstance(item, SourceTarget) for item in represented_targets):
            raise TypeError("row represented targets must contain SourceTarget values")
        object.__setattr__(self, "annotation_evidence", annotation_evidence)
        object.__setattr__(self, "represented_targets", represented_targets)

    def public_identity(self) -> dict[str, str]:
        """Return a fresh six-field endpoint identity in report order.

        Example call:
            ``candidate.public_identity()`` returns values such as
            ``{"module_name": "shop", "interface_type": "http GET",
            "endpoint": "/api/items", ...}`` without private evidence fields.
        """

        return {
            "module_name": self.module_name,
            "interface_type": self.interface_type,
            "endpoint": self.endpoint,
            "source_file_name": self.source_file_name,
            "method_name": self.method_name,
            "parameters": self.parameters,
        }


@dataclass(frozen=True, slots=True)
class ConsolidatedEndpoints:
    """Final public rows plus typed evidence retained for companion reports."""

    # Deterministically ordered seven-column endpoint rows ready for CSV output.
    rows: tuple[Mapping[str, str], ...]
    # Union of exact source declarations represented by all surviving row groups.
    represented_targets: tuple[SourceTarget, ...]

    # Example value:
    # ConsolidatedEndpoints((items_row,), (items_handler_target,))

    def __post_init__(self) -> None:
        """Detach and freeze final rows at the presentation boundary.

        Example call:
            Constructing ``ConsolidatedEndpoints((items_row,),
            (items_handler_target,))`` copies ``items_row`` into a read-only
            mapping and validates the represented declaration target.
        """

        rows = tuple(MappingProxyType(dict(row)) for row in self.rows)
        if not all(
            isinstance(key, str) and isinstance(value, str)
            for row in rows
            for key, value in row.items()
        ):
            raise TypeError("consolidated rows must contain only string cells")
        if isinstance(self.represented_targets, Mapping):
            raise TypeError("consolidated represented targets must be typed")
        represented_targets = tuple(self.represented_targets)
        if not all(isinstance(item, SourceTarget) for item in represented_targets):
            raise TypeError(
                "consolidated represented targets must contain SourceTarget values"
            )
        object.__setattr__(self, "rows", rows)
        object.__setattr__(self, "represented_targets", represented_targets)


def stringify_output_value(value: Any) -> str:
    """Convert one public identity or cell value to its public string spelling.

    Scalars preserve their ordinary spelling, ``None`` means an empty cell,
    and structured values prefer Unicode JSON. The last-resort
    ``str`` path keeps presentation robust for analyzer-specific objects without
    allowing them to mutate the source row.

    Example call:
        ``stringify_output_value({"verbs": ["GET", "POST"]})`` returns the
        Unicode JSON text ``'{"verbs": ["GET", "POST"]}'``;
        ``stringify_output_value(None)`` returns an empty cell.
    """

    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return str(value)
    try:
        return json.dumps(value, ensure_ascii=False)
    except Exception:
        return str(value)


def endpoint_fact_to_row_candidate(
    endpoint_fact: EndpointFact,
    module_name: str,
    analysis_root: Any,
) -> EndpointRowCandidate:
    """Project one rich endpoint fact to public identity plus owned evidence.

    This is the explicit information-loss boundary: route/handler/project
    provenance, technology, direction, and non-HTTP surface detail do not all
    fit the CSV. Typed evidence survives so it can be validated and merged
    before choosing the seventh public column and producing the absent-trigger
    report.

    Example call:
        ``endpoint_fact_to_row_candidate(endpoint_fact, "shop",
        "/workspace/shop")`` projects an inbound Spring ``GET /api/items`` fact
        to ``EndpointRowCandidate("shop", "http GET", "/api/items",
        "src/ItemsController.java", "ItemsController.list", ...)``.
    """

    if not isinstance(endpoint_fact, EndpointFact):
        raise TypeError("endpoint projection requires an EndpointFact")
    protocol = endpoint_fact.protocol
    surface = endpoint_fact.surface
    # HTTP exposes specialized surface names publicly; non-HTTP protocols
    # intentionally compress surface/direction to the protocol alone.
    interface_kind = (
        protocol
        if protocol != "http" or surface in {"", "server"}
        else f"{protocol}-{surface}"
    )
    return EndpointRowCandidate(
        module_name=module_name,
        interface_type=interface_kind + " " + endpoint_fact.method,
        endpoint=endpoint_fact.path,
        source_file_name=relative_source_path(
            endpoint_fact.source_file, analysis_root
        ),
        method_name=endpoint_fact.handler_name,
        parameters=endpoint_fact.parameters,
        annotation_evidence=owned_method_annotation_evidence(endpoint_fact),
        represented_targets=owned_represented_targets(endpoint_fact),
    )


def normalize_spring_regex_templates(path: Any) -> str:
    """Drop balanced Spring ``{name:regex}`` constraints from public identity.

    Regexes may contain escaped or nested braces, so a simple regular
    expression would truncate valid templates.  Unbalanced/unsupported input is
    preserved rather than guessed, maintaining fail-closed identity behavior.

    Example call:
        ``normalize_spring_regex_templates("/items/{id:[0-9]{1,8}}")`` returns
        ``"/items/{id}"``; an unbalanced ``"/items/{id:[0-9]+"`` is preserved.
    """

    value = str(path or "")
    output: list[str] = []
    cursor = 0
    length = len(value)
    name_pattern = re.compile(r"[A-Za-z_$][\w$]*")
    while cursor < length:
        if value[cursor] != "{" or (cursor > 0 and value[cursor - 1] == "$"):
            output.append(value[cursor])
            cursor += 1
            continue
        name_match = name_pattern.match(value, cursor + 1)
        if (
            name_match is None
            or name_match.end() >= length
            or value[name_match.end()] != ":"
        ):
            output.append(value[cursor])
            cursor += 1
            continue

        # Scan the constraint as a small balanced-brace language.  Escaped
        # braces and regex quantifiers must not close the outer template.
        depth = 1
        escaped = False
        end = name_match.end() + 1
        while end < length:
            character = value[end]
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == "{":
                depth += 1
            elif character == "}":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        if depth != 0:
            output.append(value[cursor])
            cursor += 1
            continue
        output.append("{" + name_match.group(0) + "}")
        cursor = end + 1
    return "".join(output)


def normalize_endpoint_path(path: Any, protocol: str = "http") -> str:
    """Canonicalize a projected endpoint before six-field identity grouping.

    Spring constraints and unresolved placeholders receive stable public
    spellings, repeated slashes collapse without damaging ``://``, and relative
    HTTP paths gain a leading slash.  Non-HTTP destinations remain relative.

    Example call:
        ``normalize_endpoint_path("api//items/${ITEM_ID}", "http")`` returns
        ``"/api/items/{ITEM_ID}"``; ``normalize_endpoint_path("orders", "amqp")``
        keeps the relative destination ``"orders"``.
    """

    value = normalize_spring_regex_templates(path)
    value = re.sub(
        r"\$\{([^{}]+)\}",
        lambda match: "{"
        + (re.findall(r"[A-Za-z_$][\w$]*", match.group(1)) or ["value"])[-1]
        + "}",
        value,
    )
    value = re.sub(r"(?<!:)/{2,}", "/", value)
    if (
        protocol == "http"
        and value
        and not value.startswith("/")
        and not value.lower().startswith(("http://", "https://"))
    ):
        value = f"/{value}"
    return value


def consolidate_endpoint_rows(
    rows: Iterable[EndpointRowCandidate],
    fieldnames: Sequence[str] = CSV_FIELDS,
) -> ConsolidatedEndpoints:
    """Apply the authoritative public identity, evidence union, and ordering.

    The first six CSV fields—after stringification and path normalization—form
    the exact grouping key.  The annotation line is deliberately excluded: all
    candidate evidence must merge before family-priority selection.  Inputs are
    never mutated; the returned value contains fresh frozen snapshots.

    Example call:
        ``consolidate_endpoint_rows([direct_get, inherited_get])`` returns one
        public row when both candidates identify ``shop / http GET /api/items /
        ItemsController.list / String filter``, with both provenance sets merged
        before the annotation line is selected.
    """

    grouped: dict[
        tuple[str, ...],
        tuple[
            dict[str, str],
            tuple[AnnotationEvidence, ...],
            tuple[SourceTarget, ...],
        ],
    ] = {}
    for candidate in rows:
        if not isinstance(candidate, EndpointRowCandidate):
            raise TypeError(
                "endpoint consolidation requires EndpointRowCandidate values"
            )
        public_identity = candidate.public_identity()
        normalized = {
            field: stringify_output_value(public_identity.get(field))
            for field in CSV_IDENTITY_FIELDS
        }
        interface = normalized.get("interface_type", "")
        protocol = interface.split(" ", 1)[0].split("-", 1)[0] or "http"
        normalized["endpoint"] = normalize_endpoint_path(
            normalized.get("endpoint", ""), protocol
        )
        key = tuple(normalized[field] for field in CSV_IDENTITY_FIELDS)
        if key not in grouped:
            grouped[key] = (
                normalized,
                merge_method_annotation_evidence(candidate.annotation_evidence),
                merge_represented_targets(candidate.represented_targets),
            )
        else:
            row, evidence, represented_targets = grouped[key]
            grouped[key] = (
                row,
                merge_method_annotation_evidence(
                    evidence,
                    candidate.annotation_evidence,
                ),
                merge_represented_targets(
                    represented_targets,
                    candidate.represented_targets,
                ),
            )

    # Sorting by the full public key makes row/evidence output independent of
    # analyzer and discovery iteration order.
    public_rows: list[Mapping[str, str]] = []
    target_collections: list[tuple[SourceTarget, ...]] = []
    for key in sorted(grouped):
        row, evidence, represented_targets = grouped[key]
        selected = select_method_annotation_evidence(evidence)
        public = {field: row.get(field, "") for field in fieldnames}
        if METHOD_ANNOTATION_LINE_FIELD in public:
            public[METHOD_ANNOTATION_LINE_FIELD] = (
                stringify_output_value(selected.line)
                if selected is not None
                else ""
            )
        public_rows.append(public)
        target_collections.append(represented_targets)
    # The companion absent report consumes one union across all surviving
    # public groups, not merely the target attached to a representative row.
    represented_targets = merge_represented_targets(*target_collections)
    return ConsolidatedEndpoints(
        rows=tuple(public_rows),
        represented_targets=represented_targets,
    )


def write_endpoint_csv(
    path: Path,
    fieldnames: Sequence[str],
    rows: Iterable[Mapping[str, Any]],
) -> None:
    """Directly overwrite the exact stable seven-column CSV artifact.

    ``utf-8-sig`` supplies the BOM, ``csv`` supplies CRLF/quoting semantics,
    and semicolon is the stable delimiter.  Only requested fields are copied
    into fresh dictionaries, so private evidence never leaks into the file.

    Example call:
        ``write_endpoint_csv(Path("/tmp/endpoints.csv"), CSV_FIELDS,
        consolidated.rows)`` overwrites the file with a BOM, the seven-column
        header, and semicolon-delimited endpoint rows.
    """

    with path.open("w", encoding="utf-8-sig", newline="") as csv_file:
        writer = csv.DictWriter(
            csv_file,
            fieldnames=fieldnames,
            delimiter=CSV_DELIMITER,
            extrasaction="ignore",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    field: stringify_output_value(row.get(field))
                    for field in fieldnames
                }
            )


__all__ = [
    "ConsolidatedEndpoints",
    "EndpointRowCandidate",
    "consolidate_endpoint_rows",
    "endpoint_fact_to_row_candidate",
    "normalize_endpoint_path",
    "normalize_spring_regex_templates",
    "stringify_output_value",
    "write_endpoint_csv",
]
