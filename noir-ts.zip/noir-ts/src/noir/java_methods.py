"""Framework-neutral Java method and invocation indexing primitives.

The specialized analyzers intentionally share this narrow syntax boundary.
Framework meaning stays in those analyzers; this module only walks named Java
nodes, reads common invocation shapes, and builds a deterministic method index.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from .java_frontend import (
    declaration_modifier_names,
    nearest_enclosing_type,
    qualified_type_name,
    tree_node_key,
)
from .java_ast import (
    field as child_field,
    known_type,
    raw_type_node,
    source_text as node_text,
    walk_named as walk_named_nodes,
)


@dataclass(frozen=True)
class FormalParameter:
    """One handler input accepted by the method index.

    Attributes:
        name: The argument name used by the Java handler, such as ``filter``.
        type_node: Parser evidence for the input's declared application type.
        node: Parser evidence for the complete parameter declaration.
        varargs: Whether callers may supply repeated values for this final input.

    Example construction:
        ``FormalParameter(name="ids", type_node=<node for ``String``>,
        node=<node for ``String... ids``>, varargs=True)`` represents the
        repeated ``ids`` input of a Java handler.
    """

    name: str
    type_node: Any
    node: Any
    varargs: bool = False


@dataclass(frozen=True)
class MethodFact:
    """Framework-neutral facts for one indexable source method.

    Attributes:
        unit: The parsed source file that contains the handler.
        owner_info: Application-type metadata for the declaring class or interface.
        owner_fqn: The declaring type's unique Java name.
        node: Parser evidence for the whole method declaration.
        name_node: Parser evidence for the handler's declared name.
        return_type_node: Parser evidence for the handler's result type.
        parameters_node: Parser evidence for the complete input list.
        body_node: Parser evidence for the executable handler body.
        parameters: Inputs accepted for overload and invocation matching.
        modifiers: Java behavior flags such as ``public`` or ``static``.

    The owning compilation unit remains attached because Tree-sitter node
    ranges are only meaningful against that unit's immutable source bytes.

    Example construction:
        ``MethodFact(unit={"source_path": "/workspace/Items.java", ...},
        owner_info={"display_name": "ItemsController", ...},
        owner_fqn="app.ItemsController", node=<node for ``list``>,
        name_node=<node for ``list``>, return_type_node=<node for ``List``>,
        parameters_node=<node for ``(String filter)``>,
        body_node=<node for the handler body>,
        parameters=(FormalParameter("filter", ...),),
        modifiers=frozenset({"public"}))`` describes the application handler
        ``ItemsController.list(String filter)``.
    """

    unit: dict[str, Any]
    owner_info: dict[str, Any]
    owner_fqn: str
    node: Any
    name_node: Any
    return_type_node: Any
    parameters_node: Any
    body_node: Any
    parameters: tuple[FormalParameter, ...]
    modifiers: frozenset[str]

    @property
    def name(self) -> str:
        """Return the declared method name from its owning source snapshot.

        Example call:
            ``method.name`` returns ``"list"`` for
            ``ItemsController.list(String filter)``.
        """

        return node_text(self.unit, self.name_node)

    @property
    def owner_name(self) -> str:
        """Return the source-level name of the type that owns the handler.

        Example call:
            ``method.owner_name`` returns ``"ItemsController"`` for a method
            declared directly by that controller.
        """

        return self.owner_info["display_name"]


@dataclass(frozen=True)
class MethodIndex:
    """Application methods organized for deterministic handler lookup.

    Attributes:
        methods: Every accepted source handler in stable source order.
        by_owner_name: Candidate overloads keyed by declaring type and method name.

    Example construction:
        ``MethodIndex(methods=(list_method,),
        by_owner_name={("app.ItemsController", "list"): (list_method,)})``
        lets a recognizer retrieve all ``ItemsController.list`` overloads.
    """

    methods: tuple[MethodFact, ...]
    by_owner_name: dict[tuple[str, str], tuple[MethodFact, ...]]


def only_named_child(node: Any) -> Any:
    """Return one semantic child, rejecting ambiguous recovered shapes.

    Example call:
        ``only_named_child(<node for ``(request)``>)`` returns the parser node
        for ``request``; ``(left + right)`` returns ``None`` because it does not
        contain one unambiguous semantic child.
    """

    children = [
        child
        for child in node.named_children
        if child.type not in {"line_comment", "block_comment"}
    ]
    return children[0] if len(children) == 1 else None


def unwrap_parentheses(node: Any) -> Any:
    """Reveal the application expression inside unambiguous parentheses.

    Example call:
        ``unwrap_parentheses(<node for ``((request))``>)`` returns the parser
        node for ``request``; an over-deep or ambiguous recovered expression
        returns ``None``.
    """

    current = node
    for _depth in range(16):
        if current is None or current.type != "parenthesized_expression":
            return current
        current = only_named_child(current)
    return None


def invocation_arguments(invocation: Any) -> list[Any] | None:
    """Return the application values passed by one Java method call.

    Example call:
        ``invocation_arguments(<node for ``route("/items", handler)``>)``
        returns nodes representing ``"/items"`` and ``handler``. A malformed
        invocation without an arguments field returns ``None``.
    """

    arguments = child_field(invocation, "arguments")
    return (
        [
            child
            for child in arguments.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
        if arguments is not None
        else None
    )


def invocation_name(
    unit: dict[str, Any],
    invocation: Any,
) -> str | None:
    """Read a called method's name without assigning framework meaning to it.

    Example call:
        ``invocation_name(items_unit, <node for ``router.get("/items")``>)``
        returns ``"get"``. ``items_unit`` supplies the source text belonging
        to the invocation node.
    """

    if invocation is None or invocation.type != "method_invocation":
        return None
    name_node = child_field(invocation, "name")
    return node_text(unit, name_node) if name_node is not None else None


def _formal_parameters(
    unit: dict[str, Any],
    parameters_node: Any,
    *,
    allow_varargs: bool,
) -> tuple[FormalParameter, ...] | None:
    """Parse the exact parameter subset requested by an index consumer.

    A single unsupported receiver, malformed parameter, or disallowed varargs
    form rejects the whole method signature; partial signatures must not enter
    overload lookup.

    Example call:
        ``_formal_parameters(items_unit, <node for ``(String filter)``>,
        allow_varargs=False)`` returns one ``FormalParameter`` named
        ``filter``. Passing ``(String... ids)`` with the same policy returns
        ``None``.
    """

    records: list[FormalParameter] = []
    for parameter in parameters_node.named_children:
        if parameter.type in {"line_comment", "block_comment"}:
            continue
        if parameter.type == "formal_parameter":
            type_node = child_field(parameter, "type")
            name_node = child_field(parameter, "name")
            if type_node is None or name_node is None:
                return None
            records.append(
                FormalParameter(node_text(unit, name_node), type_node, parameter)
            )
            continue
        if allow_varargs and parameter.type == "spread_parameter":
            declarators = [
                child
                for child in parameter.named_children
                if child.type == "variable_declarator"
            ]
            type_nodes = [
                child
                for child in parameter.named_children
                if child.type not in {"modifiers", "variable_declarator"}
            ]
            if len(declarators) != 1 or len(type_nodes) != 1:
                return None
            name_node = child_field(declarators[0], "name")
            if name_node is None:
                return None
            records.append(
                FormalParameter(
                    node_text(unit, name_node),
                    type_nodes[0],
                    parameter,
                    varargs=True,
                )
            )
            continue
        return None
    return tuple(records)


def strict_formal_parameters(
    unit: dict[str, Any], parameters_node: Any
) -> tuple[FormalParameter, ...] | None:
    """Read ordinary handler inputs, rejecting varargs and receiver forms.

    Example call:
        ``strict_formal_parameters(items_unit,
        <node for ``(String filter, int limit)``>)`` returns the ``filter`` and
        ``limit`` inputs; ``(String... ids)`` returns ``None``.
    """

    return _formal_parameters(unit, parameters_node, allow_varargs=False)


def varargs_formal_parameters(
    unit: dict[str, Any], parameters_node: Any
) -> tuple[FormalParameter, ...] | None:
    """Read ordinary handler inputs and the supported Java varargs shape.

    Example call:
        ``varargs_formal_parameters(items_unit,
        <node for ``(String prefix, String... ids)``>)`` returns two inputs,
        with ``ids.varargs`` set to ``True``.
    """

    return _formal_parameters(unit, parameters_node, allow_varargs=True)


# Selecting a reader makes each DSL's accepted signature shape an explicit
# index-construction policy instead of a conditional in framework code.
ParameterReader = Callable[
    [dict[str, Any], Any],
    tuple[FormalParameter, ...] | None,
]


def _build_method_index(
    workspace: dict[str, Any],
    read_parameters: ParameterReader,
) -> MethodIndex:
    """Index executable source methods under one parameter-shape policy.

    Example call:
        ``_build_method_index(workspace, strict_formal_parameters)`` returns an
        index containing source handlers such as ``app.ItemsController.list``
        while excluding declarations whose input list is unsupported.
    """

    methods: list[MethodFact] = []
    for source_path in sorted(workspace["compilation_units"]):
        unit = workspace["compilation_units"][source_path]
        for node in walk_named_nodes(unit["tree"].root_node):
            if node.type != "method_declaration":
                continue
            parent = getattr(node, "parent", None)
            owner_node = nearest_enclosing_type(node)
            # Index only methods declared directly in a named type body.  This
            # excludes local/anonymous declarations whose owner cannot be a
            # stable cross-file Java identity.
            if (
                parent is None
                or parent.type != "class_body"
                or owner_node is None
                or getattr(parent, "parent", None) is None
                or tree_node_key(parent.parent) != tree_node_key(owner_node)
            ):
                continue
            owner_info = unit["type_infos"].get(
                tree_node_key(owner_node)
            )
            if owner_info is None or not owner_info["workspace_visible"]:
                continue
            name_node = child_field(node, "name")
            return_type_node = child_field(node, "type")
            parameters_node = child_field(node, "parameters")
            body_node = child_field(node, "body")
            # These consumers analyze invocations, so a declaration without an
            # executable body is evidence for another layer, not this index.
            if None in (name_node, return_type_node, parameters_node, body_node):
                continue
            parameters = read_parameters(unit, parameters_node)
            if parameters is None:
                continue
            methods.append(
                MethodFact(
                    unit=unit,
                    owner_info=owner_info,
                    owner_fqn=qualified_type_name(unit, owner_info),
                    node=node,
                    name_node=name_node,
                    return_type_node=return_type_node,
                    parameters_node=parameters_node,
                    body_node=body_node,
                    parameters=parameters,
                    modifiers=frozenset(
                        declaration_modifier_names(node)
                    ),
                )
            )

    methods.sort(key=lambda fact: (fact.unit["source_path"], fact.node.start_byte))
    grouped: dict[tuple[str, str], list[MethodFact]] = {}
    for fact in methods:
        grouped.setdefault((fact.owner_fqn, fact.name), []).append(fact)
    return MethodIndex(
        methods=tuple(methods),
        by_owner_name={key: tuple(value) for key, value in grouped.items()},
    )


def build_strict_method_index(workspace: dict[str, Any]) -> MethodIndex:
    """Index handlers whose inputs use ordinary formal declarations only.

    Example call:
        ``build_strict_method_index(workspace)`` returns a ``MethodIndex`` in
        which ``("app.ItemsController", "list")`` identifies accepted
        ``list`` overloads, but a varargs-only handler is absent.
    """

    return _build_method_index(workspace, strict_formal_parameters)


def build_varargs_method_index(workspace: dict[str, Any]) -> MethodIndex:
    """Index handlers while accepting the supported Java varargs form.

    Example call:
        ``build_varargs_method_index(workspace)`` includes both
        ``send(String message)`` and ``send(String... messages)`` when their
        declarations otherwise have complete executable source evidence.
    """

    return _build_method_index(workspace, varargs_formal_parameters)


__all__ = [
    "FormalParameter",
    "MethodFact",
    "MethodIndex",
    "build_strict_method_index",
    "build_varargs_method_index",
    "child_field",
    "invocation_arguments",
    "invocation_name",
    "known_type",
    "node_text",
    "only_named_child",
    "raw_type_node",
    "strict_formal_parameters",
    "unwrap_parentheses",
    "varargs_formal_parameters",
    "walk_named_nodes",
]
