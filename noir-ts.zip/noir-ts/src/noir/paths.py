"""Framework-neutral source and endpoint path operations.

Logic guide: ``p6.logic/01-mental-model.md`` (layered route identity) and
``p6.logic/07-output-evidence-reports.md`` (public path normalization).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any


def join_endpoint_paths(base_path: str, endpoint_path: str) -> str:
    """Compose two decoded route layers without performing final normalization.

    Empty layers retain their established meaning and two empty layers denote
    the root route.  Placeholder evaluation and repeated-slash normalization
    belong to framework configuration and :mod:`noir.output`, respectively.

    Example call:
        ``join_endpoint_paths("/api", "/items/{id}")`` returns
        ``"/api/items/{id}"``; ``join_endpoint_paths("", "")`` returns the
        explicit root route ``"/"``.
    """

    if not base_path and not endpoint_path:
        return "/"
    if not base_path:
        return endpoint_path
    if not endpoint_path:
        return base_path
    return base_path.rstrip("/") + "/" + endpoint_path.lstrip("/")


def ensure_path_leading_slash(path: str) -> str:
    """Add the conventional route slash while preserving an absent path layer.

    The distinction between ``""`` (no contribution) and ``"/"`` (root) is
    needed while analyzers compose class, method, and configuration paths.

    Example call:
        ``ensure_path_leading_slash("api/items")`` returns ``"/api/items"``;
        ``ensure_path_leading_slash("")`` preserves the absent layer ``""``.
    """

    if not path:
        return ""
    return path if path.startswith("/") else f"/{path}"


def relative_source_path(source_path: Any, analysis_root: Any) -> str:
    """Project an owned source path to the portable public CSV spelling.

    This is presentation relativization, not an ownership or containment
    check; provenance validation canonicalizes paths separately in
    :mod:`noir.evidence`.

    Example call:
        ``relative_source_path("/workspace/shop/src/Items.java",
        "/workspace/shop")`` returns ``"src/Items.java"`` for the public row.
    """

    relative_path = os.path.relpath(
        os.path.abspath(source_path),
        start=os.fspath(analysis_root),
    )
    return Path(relative_path).as_posix()


__all__ = [
    "ensure_path_leading_slash",
    "join_endpoint_paths",
    "relative_source_path",
]
