"""Stable analyzer and report vocabulary shared across the application.

This module is deliberately declarative. Framework analyzers, evidence
validation, and endpoint consolidation import the same names instead of
maintaining parallel registries.

Logic guide: ``p6.logic/07-output-evidence-reports.md`` and
``p6.logic/11-naming-and-code-vocabulary.md``.
"""

from __future__ import annotations

import re
from types import MappingProxyType


# Public artifact contract.  Only the first six fields define identity; the
# annotation line is evidence chosen after candidates with that identity merge.
CSV_DELIMITER = ";"
CSV_IDENTITY_FIELDS = (
    "module_name",
    "interface_type",
    "endpoint",
    "source_file_name",
    "method_name",
    "parameters",
)
METHOD_ANNOTATION_LINE_FIELD = "method_annotation_line"
CSV_FIELDS = (*CSV_IDENTITY_FIELDS, METHOD_ANNOTATION_LINE_FIELD)

SOURCE_TARGET_KINDS = frozenset({"method", "record-component", "type"})

# Discovery prunes these *directory components* before snapshotting.  Keeping
# the registry shared prevents marker scans and semantic analysis from seeing
# different Java trees.
IGNORED_SOURCE_DIRECTORIES = frozenset(
    {
        "node_modules",
        ".git",
        "dist",
        "build",
        "target",
        "__pycache__",
        ".venv",
        "venv",
        ".idea",
        ".vscode",
        "tmp",
        ".next",
        "out",
        "vendor",
        "test",
    }
)

# Canonical Spring identities and bounded static-evaluation limits.  Simple
# annotation-name resemblance is never enough to establish framework identity.
SPRING_MAPPING_PACKAGE = "org.springframework.web.bind.annotation"
SPRING_ALIAS_FOR_PACKAGE = "org.springframework.core.annotation"
SPRING_MAPPING_METHODS = MappingProxyType(
    {
        "GetMapping": "GET",
        "PostMapping": "POST",
        "PutMapping": "PUT",
        "DeleteMapping": "DELETE",
        "PatchMapping": "PATCH",
        "RequestMapping": None,
    }
)
SPRING_HTTP_METHODS = (
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
    "TRACE",
)
SPRING_REQUEST_MAPPING_ATTRIBUTES = frozenset(
    {
        "name",
        "value",
        "path",
        "method",
        "params",
        "headers",
        "consumes",
        "produces",
        "version",
    }
)
SPRING_MAX_COMPOSED_ANNOTATION_DEPTH = 12

# Both supported namespaces are explicit; the external CLI mode token remains
# ``jaxrx`` elsewhere as a separate product-level contract.
JAX_RS_PACKAGES = ("jakarta.ws.rs", "javax.ws.rs")
JAX_RS_CORE_PACKAGES = ("jakarta.ws.rs.core", "javax.ws.rs.core")
JAX_RS_HTTP_METHODS = (
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
)
JAX_RS_HTTP_METHOD_STATIC_CONSTANTS = MappingProxyType(
    {
        f"{package}.HttpMethod": MappingProxyType(
            {method: method for method in JAX_RS_HTTP_METHODS}
        )
        for package in JAX_RS_PACKAGES
    }
)
HTTP_METHOD_TOKEN = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")

# Evidence family priority, not the smallest source line globally, determines
# which validated same-file annotation supplies the public CSV line.
METHOD_ANNOTATION_FAMILY_SPRING_VERB = "spring-verb-specific"
METHOD_ANNOTATION_FAMILY_SPRING_GENERIC = "spring-generic"
METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE = "spring-message"
METHOD_ANNOTATION_FAMILY_JAX_RS = "jax-rs-designator"
METHOD_ANNOTATION_FAMILY_PRIORITY = MappingProxyType(
    {
        METHOD_ANNOTATION_FAMILY_SPRING_VERB: 0,
        METHOD_ANNOTATION_FAMILY_SPRING_GENERIC: 1,
        METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE: 2,
        METHOD_ANNOTATION_FAMILY_JAX_RS: 3,
    }
)
METHOD_ANNOTATION_FAMILY_BY_IDENTITY = MappingProxyType(
    {
        **{
            f"{SPRING_MAPPING_PACKAGE}.{name}": (
                METHOD_ANNOTATION_FAMILY_SPRING_GENERIC
                if name == "RequestMapping"
                else METHOD_ANNOTATION_FAMILY_SPRING_VERB
            )
            for name in SPRING_MAPPING_METHODS
        },
        **{
            f"org.springframework.web.service.annotation.{name}": (
                METHOD_ANNOTATION_FAMILY_SPRING_GENERIC
                if name == "HttpExchange"
                else METHOD_ANNOTATION_FAMILY_SPRING_VERB
            )
            for name in (
                "GetExchange",
                "PostExchange",
                "PutExchange",
                "DeleteExchange",
                "PatchExchange",
                "HttpExchange",
            )
        },
        "org.springframework.messaging.handler.annotation.MessageMapping": (
            METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE
        ),
        "org.springframework.messaging.handler.annotation.SubscribeMapping": (
            METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE
        ),
        **{
            f"{package}.{method}": METHOD_ANNOTATION_FAMILY_JAX_RS
            for package in JAX_RS_PACKAGES
            for method in JAX_RS_HTTP_METHODS
        },
    }
)


__all__ = [
    "CSV_DELIMITER",
    "CSV_FIELDS",
    "CSV_IDENTITY_FIELDS",
    "HTTP_METHOD_TOKEN",
    "IGNORED_SOURCE_DIRECTORIES",
    "JAX_RS_CORE_PACKAGES",
    "JAX_RS_HTTP_METHODS",
    "JAX_RS_HTTP_METHOD_STATIC_CONSTANTS",
    "JAX_RS_PACKAGES",
    "METHOD_ANNOTATION_FAMILY_BY_IDENTITY",
    "METHOD_ANNOTATION_FAMILY_JAX_RS",
    "METHOD_ANNOTATION_FAMILY_PRIORITY",
    "METHOD_ANNOTATION_FAMILY_SPRING_GENERIC",
    "METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE",
    "METHOD_ANNOTATION_FAMILY_SPRING_VERB",
    "METHOD_ANNOTATION_LINE_FIELD",
    "SOURCE_TARGET_KINDS",
    "SPRING_ALIAS_FOR_PACKAGE",
    "SPRING_HTTP_METHODS",
    "SPRING_MAPPING_METHODS",
    "SPRING_MAPPING_PACKAGE",
    "SPRING_MAX_COMPOSED_ANNOTATION_DEPTH",
    "SPRING_REQUEST_MAPPING_ATTRIBUTES",
]
