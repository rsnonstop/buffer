"""Bounded Spring WebSocket handshake and message-destination identification.

The analyzer consumes an already-built Java workspace and calls shared Java
identity, annotation-provenance, and String-resolution operations through
their native owners.

Supported forms are intentionally source-backed:

* direct ``WebSocketMessageBrokerConfigurer`` implementations with canonical
  ``registerStompEndpoints(StompEndpointRegistry)`` registrations;
* direct ``WebSocketConfigurer`` implementations with canonical
  ``registerWebSocketHandlers(WebSocketHandlerRegistry)`` registrations;
* canonical ``setApplicationDestinationPrefixes`` calls on the same genuine
  STOMP configurer family; and
* genuine ``@Controller`` message handlers using ``@MessageMapping`` or
  ``@SubscribeMapping`` on concrete workspace classes/records.

Receiver aliases, mutation, nested registration flow, dynamic paths, fake
framework identities, and ambiguous project ownership fail closed.

Logic guide: ``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping

from .contracts import METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE
from .diagnostics import format_endpoint_diagnostic, record as record_diagnostic
from .evidence import (
    deduplicate_endpoint_facts,
    method_annotation_evidence_from_node,
    represented_target_evidence,
)
from .java_ast import (
    direct_interface_types as _direct_interface_types,
    field as _field,
    is_direct_invocation_statement as _direct_call_chain,
    known_type as _known_type,
    source_text as _text,
    walk_named as _walk,
)
from .java_frontend import (
    annotation_records,
    annotation_value_nodes,
    declaration_modifier_names,
    first_capture,
    get_annotation_arguments,
    lexical_type_chain,
    parameter_list_source_text,
    qualified_type_name,
    resolve_known_annotation,
    tree_node_key,
)
from .java_workspace import resolve_workspace_string_expression
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths


WEBSOCKET_CONFIG_PACKAGE = "org.springframework.web.socket.config.annotation"
WEBSOCKET_PACKAGE = "org.springframework.web.socket"
MESSAGE_CONFIG_PACKAGE = "org.springframework.messaging.simp.config"
MESSAGE_ANNOTATION_PACKAGE = "org.springframework.messaging.handler.annotation"
STEREOTYPE_PACKAGE = "org.springframework.stereotype"

PATH_NEUTRAL_REGISTRATION_CALLS = frozenset(
    {
        "addInterceptors",
        "setAllowedOrigins",
        "setAllowedOriginPatterns",
        "setHandshakeHandler",
    }
)
WEB_BIND_ANNOTATION_PACKAGE = "org.springframework.web.bind.annotation"


def _unique_concrete_configurers(
    workspace: Mapping[str, Any], interface_name: str
) -> Iterable[tuple[Mapping[str, Any], Mapping[str, Any], Any]]:
    """Yield uniquely attributable concrete classes implementing one configurer."""

    for source_path in sorted(workspace.get("compilation_units", {})):
        unit = workspace["compilation_units"][source_path]
        for type_info in sorted(
            unit["type_infos"].values(), key=lambda info: info["node"].start_byte
        ):
            node = type_info["node"]
            if (
                node.type != "class_declaration"
                or type_info["abstract"]
                or not type_info["workspace_visible"]
            ):
                continue
            owner_fqn = qualified_type_name(unit, type_info)
            declarations = workspace["type_declarations"].get(owner_fqn, [])
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                continue
            interfaces = [
                edge
                for edge in _direct_interface_types(node)
                if _known_type(unit,
                    edge,
                    interface_name,
                    WEBSOCKET_CONFIG_PACKAGE,
                )
            ]
            if len(interfaces) == 1:
                yield unit, type_info, node


def _formal_parameter(
    unit: Mapping[str, Any],
    method: Any,
    expected_type: str,
    package: str,
) -> tuple[str, Any] | None:
    """Prove the exact single framework registry parameter of a configurer hook."""

    parameters = _field(method, "parameters")
    if parameters is None:
        return None
    formals = [
        child
        for child in parameters.named_children
        if child.type not in {"line_comment", "block_comment"}
    ]
    if len(formals) != 1:
        return None
    parameter = formals[0]
    if parameter.type != "formal_parameter":
        return None
    type_node = _field(parameter, "type")
    name_node = _field(parameter, "name")
    if (
        type_node is None
        or name_node is None
        or not _known_type(unit, type_node, expected_type, package)
    ):
        return None
    return _text(unit, name_node), parameters


def _canonical_method(
    unit: Mapping[str, Any],
    method: Any,
    method_name: str,
    parameter_type: str,
    parameter_package: str,
) -> tuple[str, Any, Any] | None:
    """Recognize a public instance void configurer hook and stable receiver."""

    name = _field(method, "name")
    return_type = _field(method, "type")
    body = _field(method, "body")
    modifiers = declaration_modifier_names(method)
    if (
        name is None
        or return_type is None
        or body is None
        or _text(unit, name) != method_name
        or _text(unit, return_type).strip() != "void"
        or "public" not in modifiers
        or "static" in modifiers
    ):
        return None
    formal = _formal_parameter(unit, method, parameter_type, parameter_package
    )
    if formal is None:
        return None
    return formal[0], formal[1], body


def _receiver_mutated(
    unit: Mapping[str, Any],
    body: Any,
    receiver_name: str,
) -> bool:
    """Detect loss of registry-parameter identity anywhere in the method body."""

    for node in _walk(body):
        if node.type == "assignment_expression":
            left = _field(node, "left")
            if (
                left is not None
                and left.type == "identifier"
                and _text(unit, left) == receiver_name
            ):
                return True
        if node.type == "update_expression" and any(
            child.type == "identifier" and _text(unit, child) == receiver_name
            for child in node.named_children
        ):
            return True
    return False


def _invocation_name(
    unit: Mapping[str, Any], node: Any
) -> str:
    """Read a call name for bounded registration-chain recognition."""

    name = _field(node, "name")
    return _text(unit, name) if name is not None else ""


def _direct_receiver_calls(
    unit: Mapping[str, Any],
    body: Any,
    receiver_name: str,
    invocation_name: str,
) -> Iterable[Any]:
    """Yield receiver calls that are direct statements in the canonical hook."""

    for invocation in _receiver_calls(unit, body, receiver_name, invocation_name
    ):
        if _direct_call_chain(invocation, body):
            yield invocation


def _receiver_calls(
    unit: Mapping[str, Any],
    body: Any,
    receiver_name: str,
    invocation_name: str,
) -> Iterable[Any]:
    """Find calls made on the exact framework registry parameter."""

    for invocation in _walk(body):
        if (
            invocation.type != "method_invocation"
            or _invocation_name(unit, invocation) != invocation_name
        ):
            continue
        receiver = _field(invocation, "object")
        if (
            receiver is None
            or receiver.type != "identifier"
            or _text(unit, receiver) != receiver_name
        ):
            continue
        yield invocation


def _arguments(invocation: Any) -> list[Any]:
    """Return semantic invocation arguments without syntax comments."""

    arguments = _field(invocation, "arguments")
    return (
        [
            child
            for child in arguments.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
        if arguments is not None
        else []
    )


def _resolved_paths(
    unit: Mapping[str, Any],
    workspace: Mapping[str, Any],
    owner_name: str,
    nodes: Iterable[Any],
) -> list[str] | None:
    """Resolve and normalize an ordered set of static registration paths."""

    paths = []
    for node in nodes:
        value = resolve_workspace_string_expression(
            unit, node, workspace, owner_name
        )
        if value is None:
            return None
        paths.append(join_endpoint_paths("", ensure_path_leading_slash(value)))
    return list(dict.fromkeys(paths))


def _project_key(configuration: Any, source_path: str) -> str | None:
    """Map a source to the project scope that owns STOMP prefix state."""

    if configuration is None:
        return str(Path(source_path).resolve(strict=False))
    return configuration.project_root_by_source_file.get(
        str(Path(source_path).resolve(strict=False))
    )


def _stomp_configurer_methods(
    workspace: Mapping[str, Any]
) -> Iterable[
    tuple[Mapping[str, Any], Mapping[str, Any], Any, str, Any, Any, str, bool]
]:
    """Yield canonical STOMP endpoint/prefix hooks and mutation state."""

    for unit, type_info, type_node in _unique_concrete_configurers(
        workspace, "WebSocketMessageBrokerConfigurer"
    ):
        body = _field(type_node, "body")
        if body is None:
            continue
        for method in body.named_children:
            if method.type != "method_declaration":
                continue
            for method_name, parameter_type, parameter_package, call_name in (
                (
                    "registerStompEndpoints",
                    "StompEndpointRegistry",
                    WEBSOCKET_CONFIG_PACKAGE,
                    "addEndpoint",
                ),
                (
                    "configureMessageBroker",
                    "MessageBrokerRegistry",
                    MESSAGE_CONFIG_PACKAGE,
                    "setApplicationDestinationPrefixes",
                ),
            ):
                canonical = _canonical_method(unit,
                    method,
                    method_name,
                    parameter_type,
                    parameter_package,
                )
                if canonical is None:
                    continue
                receiver, parameters, method_body = canonical
                yield (
                    unit,
                    type_info,
                    method,
                    receiver,
                    parameters,
                    method_body,
                    call_name,
                    _receiver_mutated(unit, method_body, receiver),
                )


def _websocket_handler_configurer_methods(
    workspace: Mapping[str, Any]
) -> Iterable[
    tuple[Mapping[str, Any], Mapping[str, Any], Any, str, Any, bool]
]:
    """Yield canonical raw WebSocket handler registration hooks."""

    for unit, type_info, type_node in _unique_concrete_configurers(
        workspace, "WebSocketConfigurer"
    ):
        body = _field(type_node, "body")
        if body is None:
            continue
        for method in body.named_children:
            if method.type != "method_declaration":
                continue
            canonical = _canonical_method(unit,
                method,
                "registerWebSocketHandlers",
                "WebSocketHandlerRegistry",
                WEBSOCKET_CONFIG_PACKAGE,
            )
            if canonical is None:
                continue
            receiver, _parameters, method_body = canonical
            yield (
                unit,
                type_info,
                method,
                receiver,
                method_body,
                _receiver_mutated(unit, method_body, receiver),
            )


def _direct_call_with_allowed_chain(
    unit: Mapping[str, Any],
    invocation: Any,
    body: Any,
    allowed_chain_names: frozenset[str],
) -> bool:
    """Accept a direct registration plus only route-neutral fluent suffixes."""

    current = invocation
    while getattr(current, "parent", None) is not None:
        parent = current.parent
        if parent.type != "method_invocation":
            break
        object_node = _field(parent, "object")
        if object_node is None or (
            object_node.start_byte,
            object_node.end_byte,
        ) != (current.start_byte, current.end_byte):
            break
        if _invocation_name(unit, parent) not in allowed_chain_names:
            return False
        current = parent
    statement = getattr(current, "parent", None)
    return bool(
        statement is not None
        and statement.type == "expression_statement"
        and getattr(statement, "parent", None) is not None
        and tree_node_key(statement.parent) == tree_node_key(body)
    )


def _handler_field_name(
    unit: Mapping[str, Any], node: Any
) -> tuple[str, bool] | None:
    """Decode an unqualified or explicit-this handler field reference."""

    if node.type == "identifier":
        return _text(unit, node), False
    if node.type != "field_access":
        return None
    object_node = _field(node, "object")
    field_node = _field(node, "field")
    if (
        object_node is None
        or object_node.type != "this"
        or field_node is None
        or field_node.type != "identifier"
    ):
        return None
    return _text(unit, field_node), True


def _has_typed_websocket_handler_field(
    unit: Mapping[str, Any],
    type_info: Mapping[str, Any],
    method_body: Any,
    handler_node: Any,
) -> bool:
    """Prove one unshadowed WebSocketHandler field for registration attribution."""

    reference = _handler_field_name(unit, handler_node)
    if reference is None:
        return False
    name, explicit_this = reference

    # An unqualified name shadowed anywhere in the method is not exact enough
    # for this deliberately bounded symbol model.  ``this.field`` is explicit.
    if not explicit_this:
        for node in _walk(method_body):
            if node.type not in {
                "variable_declarator",
                "formal_parameter",
                "catch_formal_parameter",
            }:
                continue
            name_node = _field(node, "name")
            if name_node is not None and _text(unit, name_node) == name:
                return False

    owner_body = _field(type_info["node"], "body")
    if owner_body is None:
        return False
    candidates = []
    for declaration in owner_body.named_children:
        if declaration.type != "field_declaration":
            continue
        type_node = _field(declaration, "type")
        if type_node is None or not _known_type(unit,
            type_node,
            "WebSocketHandler",
            WEBSOCKET_PACKAGE,
        ):
            continue
        for declarator in declaration.named_children:
            if declarator.type != "variable_declarator":
                continue
            name_node = _field(declarator, "name")
            if name_node is not None and _text(unit, name_node) == name:
                candidates.append(declarator)
    return len(candidates) == 1


def _websocket_handler_handshake_endpoints(
    workspace: Mapping[str, Any]
) -> list[EndpointFact]:
    """Extract raw WebSocketHandler handshake paths from canonical configurers."""

    endpoints = []
    # These WebSocketHandlerRegistration operations configure the already
    # selected handler/path set; they do not replace or add endpoint paths.
    for unit, type_info, method, receiver, body, mutated in _websocket_handler_configurer_methods(
        workspace
    ):
        if mutated:
            continue
        owner = type_info["display_name"]
        function = f"{owner}.registerWebSocketHandlers"
        for invocation in _receiver_calls(unit, body, receiver, "addHandler"):
            if not _direct_call_with_allowed_chain(unit,
                invocation,
                body,
                PATH_NEUTRAL_REGISTRATION_CALLS,
            ):
                continue
            arguments = _arguments(invocation)
            if len(arguments) < 2 or not _has_typed_websocket_handler_field(unit, type_info, body, arguments[0]
            ):
                continue
            paths = _resolved_paths(unit,
                workspace,
                owner,
                arguments[1:],
            )
            if not paths:
                continue
            for path in paths:
                endpoint = EndpointFact(
                    path=path,
                    method="GET",
                    parameters="",
                    source_file=unit["source_path"],
                    source_line=invocation.start_point.row + 1,
                    handler_name=function,
                    route_source_file=unit["source_path"],
                    route_source_line=invocation.start_point.row + 1,
                    handler_source_file=unit["source_path"],
                    handler_source_line=method.start_point.row + 1,
                    project_source_file=unit["source_path"],
                    technology="spring",
                    protocol="ws",
                    surface="websocket-handshake",
                    direction="inbound",
                    annotation_evidence=(),
                    represented_targets=represented_target_evidence(
                        unit["source_path"], "method", method
                    ),
                )
                endpoints.append(endpoint)
                record_diagnostic(format_endpoint_diagnostic(endpoint))
    return endpoints


def _stomp_handshake_endpoints(
    workspace: Mapping[str, Any]
) -> list[EndpointFact]:
    """Extract STOMP handshake paths from direct addEndpoint registrations."""

    endpoints = []
    for unit, type_info, method, receiver, _parameters, body, call_name, mutated in _stomp_configurer_methods(
        workspace
    ):
        if call_name != "addEndpoint" or mutated:
            continue
        owner = type_info["display_name"]
        function = f"{owner}.registerStompEndpoints"
        for invocation in _receiver_calls(unit, body, receiver, call_name):
            if not _direct_call_with_allowed_chain(unit,
                invocation,
                body,
                PATH_NEUTRAL_REGISTRATION_CALLS,
            ):
                continue
            paths = _resolved_paths(unit,
                workspace,
                owner,
                _arguments(invocation),
            )
            if not paths:
                continue
            for path in paths:
                endpoint = EndpointFact(
                    path=path,
                    method="GET",
                    parameters="",
                    source_file=unit["source_path"],
                    source_line=invocation.start_point.row + 1,
                    handler_name=function,
                    route_source_file=unit["source_path"],
                    route_source_line=invocation.start_point.row + 1,
                    handler_source_file=unit["source_path"],
                    handler_source_line=method.start_point.row + 1,
                    project_source_file=unit["source_path"],
                    technology="spring",
                    protocol="ws",
                    surface="websocket-handshake",
                    direction="inbound",
                    annotation_evidence=(),
                    represented_targets=represented_target_evidence(
                        unit["source_path"], "method", method
                    ),
                )
                endpoints.append(endpoint)
                record_diagnostic(format_endpoint_diagnostic(endpoint))
    return endpoints


def _stomp_application_prefixes(
    workspace: Mapping[str, Any], configuration: Any
) -> tuple[dict[str, tuple[str, ...]], frozenset[str]]:
    """Select one coherent application-destination prefix set per project."""

    prefixes: dict[str, list[str]] = {}
    direct_call_counts: dict[str, int] = {}
    invalid_projects: set[str] = set()
    for unit, type_info, _method, receiver, _parameters, body, call_name, mutated in _stomp_configurer_methods(
        workspace
    ):
        if call_name != "setApplicationDestinationPrefixes":
            continue
        project = _project_key(configuration, unit["source_path"])
        if project is None:
            continue
        if mutated:
            invalid_projects.add(project)
            continue
        receiver_calls = list(
            _receiver_calls(unit, body, receiver, call_name)
        )
        calls = [
            invocation
            for invocation in receiver_calls
            if _direct_call_with_allowed_chain(unit, invocation, body, frozenset()
            )
        ]
        # An application prefix hidden in control flow is still a real
        # registration, but its runtime identity is not statically known.
        # Distinguish that from a canonical method with no registration.
        if len(calls) != len(receiver_calls):
            invalid_projects.add(project)
        direct_call_counts[project] = direct_call_counts.get(project, 0) + len(calls)
        if direct_call_counts[project] > 1:
            # This API replaces, rather than accumulates, the configured
            # prefixes. Source ordering across repeated calls/configurers is
            # not a sound endpoint-identity proof, so reject the project.
            invalid_projects.add(project)
        for invocation in calls:
            values = _resolved_paths(unit,
                workspace,
                type_info["display_name"],
                _arguments(invocation),
            )
            if not values:
                invalid_projects.add(project)
                continue
            prefixes.setdefault(project, []).extend(values)
    return (
        {
            project: tuple(dict.fromkeys(values))
            for project, values in prefixes.items()
            if project not in invalid_projects
        },
        frozenset(invalid_projects),
    )


def _annotation_paths(
    unit: Mapping[str, Any],
    workspace: Mapping[str, Any],
    annotation: Mapping[str, Any],
    owner_name: str,
    *,
    empty_default: bool = False,
) -> list[str] | None:
    """Decode coherent value/path aliases on a messaging annotation."""

    positional, named = get_annotation_arguments(annotation["node"])
    if set(named) - {"value", "path"} or len(positional) > 1:
        return None
    groups = []
    if positional:
        groups.append(positional[0])
    for attribute in ("value", "path"):
        if attribute in named:
            groups.append(named[attribute])
    if not groups:
        return [""] if empty_default else None
    decoded = []
    for group in groups:
        values = _resolved_paths(unit,
            workspace,
            owner_name,
            annotation_value_nodes(group),
        )
        if values is None:
            return None
        decoded.append(tuple(values))
    if len(set(decoded)) != 1:
        return None
    return list(decoded[0])


def _known_annotations(
    unit: Mapping[str, Any],
    candidates: Iterable[Mapping[str, list[Any]]],
    names: set[str],
    package: str,
) -> list[tuple[dict[str, Any], str]]:
    """Resolve genuine annotations of one package from captured candidates."""

    matches = []
    for record in annotation_records(candidates):
        resolved = resolve_known_annotation(
            unit, record["name_node"], names, (package,)
        )
        if resolved is not None:
            matches.append((record, resolved["name"]))
    return matches


def _lexical_controller_type_chain(
    unit: Mapping[str, Any],
    type_key: tuple[int, int],
) -> list[Mapping[str, Any]]:
    """Return outer-to-inner type layers for controller and message paths."""

    return lexical_type_chain(type_key, unit["type_infos"])


def _has_controller_marker_in_lexical_chain(
    unit: Mapping[str, Any],
    chain: Iterable[Mapping[str, Any]],
) -> bool:
    """Require genuine Controller activation on some lexical owner layer."""

    for info in chain:
        key = tree_node_key(info["node"])
        annotations = _known_annotations(unit,
            unit["type_candidates"].get(key, []),
            {"Controller"},
            STEREOTYPE_PACKAGE,
        )
        rest_annotations = _known_annotations(unit,
            unit["type_candidates"].get(key, []),
            {"RestController"},
            WEB_BIND_ANNOTATION_PACKAGE,
        )
        if annotations or rest_annotations:
            return True
    return False


def _lexical_message_mapping_paths(
    unit: Mapping[str, Any],
    workspace: Mapping[str, Any],
    chain: Iterable[Mapping[str, Any]],
) -> list[str] | None:
    """Compose source-ordered type-level message destination layers."""

    paths = [""]
    for info in chain:
        key = tree_node_key(info["node"])
        records = _known_annotations(unit,
            unit["type_candidates"].get(key, []),
            {"MessageMapping"},
            MESSAGE_ANNOTATION_PACKAGE,
        )
        if not records:
            continue
        current_paths = []
        for record, _name in records:
            decoded = _annotation_paths(unit,
                workspace,
                record,
                info["display_name"],
                empty_default=True,
            )
            if decoded is None:
                return None
            current_paths.extend(decoded)
        paths = [
            join_endpoint_paths(base, current)
            for base in paths
            for current in dict.fromkeys(current_paths)
        ]
    return list(dict.fromkeys(paths))


def _message_mapping_endpoints(
    workspace: Mapping[str, Any], configuration: Any
) -> list[EndpointFact]:
    """Extract SEND/SUBSCRIBE destinations with project prefix and evidence."""

    project_prefixes, invalid_prefix_projects = _stomp_application_prefixes(
        workspace, configuration
    )
    endpoints = []
    for source_path in sorted(workspace.get("compilation_units", {})):
        unit = workspace["compilation_units"][source_path]
        project = _project_key(configuration, source_path)
        if project is None or project in invalid_prefix_projects:
            continue
        app_prefixes = project_prefixes.get(project, ("",))
        for method_key in sorted(unit["method_candidates"]):
            candidates = unit["method_candidates"][method_key]
            representative = candidates[0]
            type_node = first_capture(representative, "type.node")
            method_node = first_capture(representative, "method.node")
            method_name_node = first_capture(representative, "method.name")
            parameters_node = first_capture(representative, "method.parameters")
            if None in (type_node, method_node, method_name_node, parameters_node):
                continue
            type_key = tree_node_key(type_node)
            info = unit["type_infos"].get(type_key)
            if (
                info is None
                or info["abstract"]
                or not info["workspace_visible"]
            ):
                continue
            chain = _lexical_controller_type_chain(unit, type_key)
            if not _has_controller_marker_in_lexical_chain(unit, chain):
                continue
            class_paths = _lexical_message_mapping_paths(unit, workspace, chain
            )
            if class_paths is None:
                continue
            owner = info["display_name"]
            function = f"{owner}.{_text(unit, method_name_node)}"
            annotations = _known_annotations(unit,
                candidates,
                {"MessageMapping", "SubscribeMapping"},
                MESSAGE_ANNOTATION_PACKAGE,
            )
            for record, name in annotations:
                method_paths = _annotation_paths(unit, workspace, record, function
                )
                if not method_paths:
                    continue
                verb = "SEND" if name == "MessageMapping" else "SUBSCRIBE"
                for app_prefix in app_prefixes:
                    for class_path in class_paths:
                        for method_path in method_paths:
                            endpoint_path = join_endpoint_paths(
                                join_endpoint_paths(app_prefix, class_path),
                                method_path,
                            )
                            endpoint = EndpointFact(
                                path=endpoint_path,
                                method=verb,
                                parameters=parameter_list_source_text(
                                    unit["source"], parameters_node
                                ),
                                source_file=source_path,
                                source_line=record["node"].start_point.row + 1,
                                handler_name=function,
                                route_source_file=source_path,
                                route_source_line=record["node"].start_point.row + 1,
                                handler_source_file=source_path,
                                handler_source_line=method_node.start_point.row + 1,
                                project_source_file=source_path,
                                technology="spring",
                                protocol="ws",
                                surface="message",
                                direction="inbound",
                                annotation_evidence=method_annotation_evidence_from_node(
                                    record["node"],
                                    f"{MESSAGE_ANNOTATION_PACKAGE}.{name}",
                                    METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE,
                                    annotation_source_file=source_path,
                                    endpoint_source_file=source_path,
                                ),
                                represented_targets=represented_target_evidence(
                                    source_path, "method", method_node
                                ),
                            )
                            endpoints.append(endpoint)
                            record_diagnostic(format_endpoint_diagnostic(endpoint))
    return endpoints


def _deduplicate(
    endpoints: Iterable[EndpointFact],
) -> tuple[EndpointFact, ...]:
    """Merge exact WebSocket/message facts while retaining typed evidence."""

    return deduplicate_endpoint_facts(
        endpoints,
        lambda endpoint: (
            endpoint.protocol,
            endpoint.surface,
            endpoint.method,
            endpoint.path,
            endpoint.source_file,
            endpoint.handler_name,
            endpoint.parameters,
        ),
    )


def analyze_spring_websocket_and_messaging(
    workspace: Mapping[str, Any],
    configuration: Any = None,
) -> tuple[EndpointFact, ...]:
    """Return Spring WebSocket handshake and message-destination facts."""

    return _deduplicate(
        [
            *_websocket_handler_handshake_endpoints(workspace),
            *_stomp_handshake_endpoints(workspace),
            *_message_mapping_endpoints(workspace, configuration),
        ],
    )


__all__ = ["analyze_spring_websocket_and_messaging"]
