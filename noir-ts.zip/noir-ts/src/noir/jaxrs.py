"""JAX-RS semantic analysis over the shared Java workspace.

This module owns JAX-RS annotation meaning, custom request-method and
ApplicationPath indexes, deployment-prefix association, resource resolution,
and direct endpoint facts.  Java parsing/indexes, deployment XML discovery,
hierarchy analysis, diagnostics persistence, and orchestration stay outside.

The analyzer calls package-owned neutral Java, deployment, path, evidence, and
diagnostic operations directly; it does not depend on Spring semantics.

Logic guide: ``p6.logic/06-jax-rs.md``.
"""

from __future__ import annotations

from typing import Any

from .contracts import (
    HTTP_METHOD_TOKEN,
    JAX_RS_CORE_PACKAGES,
    JAX_RS_HTTP_METHODS,
    JAX_RS_HTTP_METHOD_STATIC_CONSTANTS,
    JAX_RS_PACKAGES,
    METHOD_ANNOTATION_FAMILY_JAX_RS,
)
from .diagnostics import format_endpoint_diagnostic, record
from .evidence import (
    method_annotation_evidence_from_node,
    represented_target_evidence,
)
from .jaxrs_deployment import select_jax_rs_deployment_prefix
from .java_frontend import (
    annotation_has_no_values,
    annotation_records,
    annotation_single_value_node,
    child_by_field,
    find_first,
    first_capture,
    node_text,
    parameter_list_source_text,
    qualified_type_name,
    resolve_known_annotation,
    resolve_known_type,
    tree_node_key,
)
from .java_workspace import (
    custom_annotation_identity_candidates,
    resolve_workspace_string_expression,
    retention_is_runtime,
    source_annotation_use_is_method_applicable,
    workspace_type_accessible,
)
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths


def log_jax_rs_skip(source_path, owner_name, message, expression=None):
    """Record a source-owner reason that a JAX-RS candidate failed closed.

    Example call:
        ``log_jax_rs_skip(
            source_path="/workspace/shop/src/main/java/com/acme/ItemsController.java",
            owner_name="ItemsController",
            message="unresolved route path",
        )``
        records a source-owner reason that a JAX-RS candidate failed closed.
    """

    suffix = f": {expression}" if expression else ""
    record(
        f"Skipped JAX-RS {message} in {source_path} for {owner_name}{suffix}"
    )


def decode_jax_rs_path_annotation(
    unit,
    record,
    constant_owner,
    diagnostic_owner,
    kind,
    workspace,
):
    """Decode one genuine Path-family annotation to a static normalized layer.

    Example call:
        ``decode_jax_rs_path_annotation(
            unit=items_unit,
            record=path_annotation_record,
            constant_owner="ItemsController",
            diagnostic_owner="ItemsController.list",
            kind="method @Path",
            workspace=java_workspace,
        )``
        decodes one genuine Path-family annotation to a static normalized layer.
    """

    value_node, error = annotation_single_value_node(record["node"])
    if error:
        log_jax_rs_skip(
            unit["source_path"], diagnostic_owner, f"invalid {kind}", error
        )
        return None
    value = resolve_workspace_string_expression(
        unit,
        value_node,
        workspace,
        constant_owner,
    )
    if value is None:
        log_jax_rs_skip(
            unit["source_path"],
            diagnostic_owner,
            f"unresolved {kind}",
            node_text(unit["source"], value_node).strip(),
        )
        return None
    return ensure_path_leading_slash(value)


def resolve_direct_jax_rs_application_namespace(unit, type_info):
    """Resolve a direct core Application superclass to its Javax/Jakarta family.

    Example call:
        ``resolve_direct_jax_rs_application_namespace(
            unit=items_unit,
            type_info=items_controller_type_info,
        )``
        resolves a direct core Application superclass to its Javax/Jakarta family.
    """

    superclass = child_by_field(type_info["node"], "superclass")
    if superclass is None or len(superclass.named_children) != 1:
        return None
    spelling = node_text(unit["source"], superclass.named_children[0]).strip()
    core_package = resolve_known_type(
        unit,
        spelling,
        "Application",
        JAX_RS_CORE_PACKAGES,
        superclass.named_children[0],
    )
    return core_package.rsplit(".", 1)[0] if core_package is not None else None


def decode_custom_http_method(unit, annotation_record, owner_name, workspace):
    """Decode and validate the HTTP token declared by a custom designator.

    Example call:
        ``decode_custom_http_method(
            unit=items_unit,
            annotation_record=path_annotation_record,
            owner_name="ItemsController",
            workspace=java_workspace,
        )``
        decodes and validates the HTTP token declared by a custom designator.
    """

    value_node, error = annotation_single_value_node(annotation_record["node"])
    if error:
        log_jax_rs_skip(
            unit["source_path"],
            owner_name,
            "custom @HttpMethod value",
            error,
        )
        return None
    token = resolve_workspace_string_expression(
        unit,
        value_node,
        workspace,
        owner_name,
        known_static_constants=JAX_RS_HTTP_METHOD_STATIC_CONSTANTS,
    )
    if token is None or len(token) > 128 or HTTP_METHOD_TOKEN.fullmatch(token) is None:
        log_jax_rs_skip(
            unit["source_path"],
            owner_name,
            "invalid custom @HttpMethod value",
            node_text(unit["source"], value_node).strip(),
        )
        return None
    return token


def index_jax_rs_custom_designators(workspace):
    """Index valid runtime custom request-method declarations by source FQN.

    Example call:
        ``index_jax_rs_custom_designators(workspace=java_workspace)``
        indexes valid runtime custom request-method declarations by source FQN.
    """

    designator_candidates = set()
    designators_by_fqn = {}
    for unit in workspace["compilation_units"].values():
        for declaration_key, candidates in unit["meta_candidates"].items():
            type_info = unit["type_infos"].get(declaration_key)
            if type_info is None:
                continue
            owner_name = type_info["display_name"]
            fqn = qualified_type_name(unit, type_info)
            records = annotation_records(candidates)
            http_methods = []
            retentions = []
            for record in records:
                resolved_http_method = resolve_known_annotation(
                    unit, record["name_node"], {"HttpMethod"}, JAX_RS_PACKAGES
                )
                if resolved_http_method is not None:
                    http_methods.append((record, resolved_http_method))
                resolved_retention = resolve_known_annotation(
                    unit,
                    record["name_node"],
                    {"Retention"},
                    ("java.lang.annotation",),
                )
                if resolved_retention is not None:
                    retentions.append(record)

            if not http_methods:
                continue
            designator_candidates.add(fqn)
            if len(http_methods) != 1:
                log_jax_rs_skip(
                    unit["source_path"],
                    owner_name,
                    "ambiguous custom @HttpMethod declaration",
                )
                continue
            if len(retentions) != 1 or not retention_is_runtime(
                unit, retentions[0]["node"]
            ):
                log_jax_rs_skip(
                    unit["source_path"],
                    owner_name,
                    "non-runtime custom @HttpMethod declaration",
                )
                continue

            http_annotation, resolved = http_methods[0]
            token = decode_custom_http_method(
                unit,
                http_annotation,
                owner_name,
                workspace,
            )
            if token is None:
                continue
            designators_by_fqn.setdefault(fqn, []).append(
                {
                    "fqn": fqn,
                    "simple_name": type_info["simple_name"],
                    "namespace": resolved["namespace"],
                    "method": token,
                    "source_path": unit["source_path"],
                }
            )
    workspace["jax_rs_custom_designator_candidates"] = designator_candidates
    workspace["jax_rs_custom_designators"] = designators_by_fqn


def select_jax_rs_accessor_annotations(
    unit, candidates, workspace, owner_name
):
    """Keep component annotations that can legally describe an implicit method.

    Example call:
        ``select_jax_rs_accessor_annotations(
            unit=items_unit,
            candidates=mapping_candidates,
            workspace=java_workspace,
            owner_name="ItemsController",
        )``
        keeps component annotations that can legally describe an implicit method.
    """

    applicable = []
    for record in annotation_records(candidates):
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {*JAX_RS_HTTP_METHODS, "Path"},
            JAX_RS_PACKAGES,
        ) is not None or source_annotation_use_is_method_applicable(
            unit, record, workspace, owner_name
        ):
            applicable.append(record)
    return applicable


def resolve_custom_designator(unit, name_node, workspace, owner_name):
    """Resolve an applied custom designator without guessing source ambiguity.

    Example call:
        ``resolve_custom_designator(
            unit=items_unit,
            name_node=mapping_name_node,
            workspace=java_workspace,
            owner_name="ItemsController",
        )``
        resolves an applied custom designator without guessing source ambiguity.
    """

    spelling = node_text(unit["source"], name_node).strip()
    identities = custom_annotation_identity_candidates(
        unit, spelling, workspace, name_node
    )
    relevant = {
        identity
        for identity in identities
        if identity in workspace["jax_rs_custom_designator_candidates"]
        or identity in workspace["jax_rs_custom_designators"]
    }
    if not relevant:
        return {"status": "none", "record": None}
    if len(identities) != 1 or len(relevant) != 1:
        return {"status": "ambiguous", "record": None}
    identity = next(iter(relevant))
    definitions = workspace["annotation_definitions"].get(identity, [])
    if len(definitions) != 1 or not workspace_type_accessible(
        definitions[0], unit, owner_name
    ):
        return {"status": "invalid", "record": None}
    records = workspace["jax_rs_custom_designators"].get(identity, [])
    if len(records) == 1:
        return {"status": "resolved", "record": records[0]}
    return {
        "status": "invalid" if not records else "ambiguous",
        "record": None,
    }


def index_jax_rs_application_paths(workspace):
    """Index direct concrete ApplicationPath declarations for prefix selection.

    Example call:
        ``index_jax_rs_application_paths(workspace=java_workspace)``
        indexes direct concrete ApplicationPath declarations for prefix selection.
    """

    applications = []
    for unit in workspace["compilation_units"].values():
        for type_key, type_info in unit["type_infos"].items():
            if type_info["node"].type != "class_declaration":
                continue
            records = annotation_records(unit["type_candidates"].get(type_key, []))
            application_annotations = []
            for record in records:
                resolved = resolve_known_annotation(
                    unit,
                    record["name_node"],
                    {"ApplicationPath"},
                    JAX_RS_PACKAGES,
                )
                if resolved is not None:
                    application_annotations.append((record, resolved))
            if not application_annotations:
                continue
            owner_name = type_info["display_name"]
            if type_info["abstract"]:
                log_jax_rs_skip(
                    unit["source_path"],
                    owner_name,
                    "@ApplicationPath on an abstract Application",
                )
                continue
            if len(application_annotations) != 1:
                log_jax_rs_skip(
                    unit["source_path"],
                    owner_name,
                    "ambiguous @ApplicationPath annotations",
                )
                for _record, resolved in application_annotations:
                    applications.append(
                        {
                            "namespace": resolved["namespace"],
                            "package": unit["package"],
                            "path": None,
                            "source_path": unit["source_path"],
                            "simple_name": type_info["simple_name"],
                            "fqn": qualified_type_name(unit, type_info),
                        }
                    )
                continue

            record, resolved = application_annotations[0]
            application_namespace = resolve_direct_jax_rs_application_namespace(
                unit, type_info
            )
            if application_namespace != resolved["namespace"]:
                log_jax_rs_skip(
                    unit["source_path"],
                    owner_name,
                    "@ApplicationPath on a non-matching direct Application subclass",
                )
                continue
            path = decode_jax_rs_path_annotation(
                unit,
                record,
                owner_name,
                owner_name,
                "@ApplicationPath value",
                workspace,
            )
            applications.append(
                {
                    "namespace": resolved["namespace"],
                    "package": unit["package"],
                    "path": path,
                    "source_path": unit["source_path"],
                    "simple_name": type_info["simple_name"],
                    "fqn": qualified_type_name(unit, type_info),
                }
            )
    workspace["jax_rs_applications"] = applications


def package_is_ancestor(ancestor, package):
    """Test package-scope ownership for a resource and ApplicationPath.

    Example call:
        ``package_is_ancestor(ancestor="com.acme", package="com.acme.items")``
        tests package-scope ownership for a resource and ApplicationPath.
    """

    return not ancestor or package == ancestor or package.startswith(f"{ancestor}.")


def package_specificity(package):
    """Rank ApplicationPath candidates by package depth.

    Example call:
        ``package_specificity(package="com.acme.items")``
        ranks ApplicationPath candidates by package depth.
    """

    return len(package.split(".")) if package else 0


def resolve_jax_rs_resource_prefix(workspace, unit, namespace, owner_name):
    """Select one deployment prefix, suppressing ambiguous associations.

    Example call:
        ``resolve_jax_rs_resource_prefix(
            workspace=java_workspace,
            unit=items_unit,
            namespace="jakarta.ws.rs",
            owner_name="ItemsController",
        )``
        selects one deployment prefix, suppressing ambiguous associations.
    """

    deployment = workspace.get("jax_rs_deployment_model")
    if deployment is not None:
        return select_jax_rs_deployment_prefix(
            deployment,
            unit,
            namespace,
            owner_name,
        )
    applications = [
        application
        for application in workspace["jax_rs_applications"]
        if application["namespace"] == namespace
    ]
    if not applications:
        return ""

    valid_paths = {
        application["path"]
        for application in applications
        if application["path"] is not None
    }
    invalid_count = sum(application["path"] is None for application in applications)
    if not invalid_count and len(valid_paths) == 1:
        return next(iter(valid_paths))
    if len(applications) == 1:
        log_jax_rs_skip(
            unit["source_path"],
            owner_name,
            "unresolved @ApplicationPath association",
        )
        return None

    candidates = [
        application
        for application in applications
        if package_is_ancestor(application["package"], unit["package"])
    ]
    if candidates:
        specificity = max(
            package_specificity(application["package"]) for application in candidates
        )
        candidates = [
            application
            for application in candidates
            if package_specificity(application["package"]) == specificity
        ]
    candidate_paths = {
        application["path"]
        for application in candidates
        if application["path"] is not None
    }
    if (
        candidates
        and all(application["path"] is not None for application in candidates)
        and len(candidate_paths) == 1
    ):
        return next(iter(candidate_paths))

    log_jax_rs_skip(
        unit["source_path"],
        owner_name,
        "ambiguous @ApplicationPath association",
    )
    return None


def method_is_public(method_node):
    """Apply the explicit-public gate for direct JAX-RS resource methods.

    Example call:
        ``method_is_public(method_node=list_method_node)``
        applies the explicit-public gate for direct JAX-RS resource methods.
    """

    modifiers = find_first(method_node, "modifiers")
    return bool(
        modifiers and any(child.type == "public" for child in modifiers.children)
    )


def resolve_jax_rs_resource_root(unit, type_info, workspace):
    """Decode exactly one genuine type Path as a direct resource root.

    Example call:
        ``resolve_jax_rs_resource_root(
            unit=items_unit,
            type_info=items_controller_type_info,
            workspace=java_workspace,
        )``
        decodes exactly one genuine type Path as a direct resource root.
    """

    type_key = tree_node_key(type_info["node"])
    records = annotation_records(unit["type_candidates"].get(type_key, []))
    paths = []
    for record in records:
        resolved = resolve_known_annotation(
            unit, record["name_node"], {"Path"}, JAX_RS_PACKAGES
        )
        if resolved is not None:
            paths.append((record, resolved))
    if not paths:
        return None
    owner_name = type_info["display_name"]
    if len(paths) != 1:
        log_jax_rs_skip(
            unit["source_path"],
            owner_name,
            "ambiguous class @Path annotations",
        )
        return None
    record, resolved = paths[0]
    path = decode_jax_rs_path_annotation(
        unit,
        record,
        owner_name,
        owner_name,
        "class @Path value",
        workspace,
    )
    if path is None:
        return None
    return {"path": path, "namespace": resolved["namespace"]}


def resolve_jax_rs_request_designator(
    unit, records, workspace, namespace, owner_name
):
    """Select one valid same-family standard or custom request designator.

    Example call:
        ``resolve_jax_rs_request_designator(
            unit=items_unit,
            records=method_annotation_records,
            workspace=java_workspace,
            namespace="jakarta.ws.rs",
            owner_name="ItemsController",
        )``
        selects one valid same-family standard or custom request designator.
    """

    designators = []
    invalid = False
    for record in records:
        standard = resolve_known_annotation(
            unit, record["name_node"], set(JAX_RS_HTTP_METHODS), JAX_RS_PACKAGES
        )
        if standard is not None:
            if standard["namespace"] != namespace:
                invalid = True
                log_jax_rs_skip(
                    unit["source_path"],
                    owner_name,
                    "mixed Javax/Jakarta designator",
                )
                continue
            if not annotation_has_no_values(record["node"]):
                invalid = True
                log_jax_rs_skip(
                    unit["source_path"],
                    owner_name,
                    "invalid standard designator arguments",
                )
                continue
            designators.append(
                {
                    "method": standard["name"],
                    "node": record["node"],
                    "annotation_identity": (
                        f"{standard['namespace']}.{standard['name']}"
                    ),
                    "annotation_family": METHOD_ANNOTATION_FAMILY_JAX_RS,
                }
            )
            continue

        custom = resolve_custom_designator(
            unit, record["name_node"], workspace, owner_name
        )
        if custom["status"] == "none":
            continue
        if custom["status"] != "resolved":
            invalid = True
            log_jax_rs_skip(
                unit["source_path"],
                owner_name,
                f"{custom['status']} custom designator",
            )
            continue
        custom_record = custom["record"]
        if custom_record["namespace"] != namespace:
            invalid = True
            log_jax_rs_skip(
                unit["source_path"],
                owner_name,
                "mixed Javax/Jakarta custom designator",
            )
            continue
        designators.append(
            {
                "method": custom_record["method"],
                "node": record["node"],
                "annotation_identity": custom_record["fqn"],
                "annotation_family": METHOD_ANNOTATION_FAMILY_JAX_RS,
            }
        )

    if invalid:
        return None
    if len(designators) > 1:
        log_jax_rs_skip(
            unit["source_path"],
            owner_name,
            "multiple request-method designators",
        )
        return None
    return designators[0] if designators else None


def resolve_jax_rs_method_path(
    unit, records, namespace, type_owner, owner_name, workspace
):
    """Decode the optional single same-family method Path layer.

    Example call:
        ``resolve_jax_rs_method_path(
            unit=items_unit,
            records=method_annotation_records,
            namespace="jakarta.ws.rs",
            type_owner="ItemsResource",
            owner_name="ItemsController",
            workspace=java_workspace,
        )``
        decodes the optional single same-family method Path layer.
    """

    paths = []
    for record in records:
        resolved = resolve_known_annotation(
            unit, record["name_node"], {"Path"}, JAX_RS_PACKAGES
        )
        if resolved is not None:
            paths.append((record, resolved))
    if not paths:
        return ""
    if len(paths) != 1 or paths[0][1]["namespace"] != namespace:
        log_jax_rs_skip(
            unit["source_path"],
            owner_name,
            "ambiguous or mixed method @Path annotation",
        )
        return None
    return decode_jax_rs_path_annotation(
        unit,
        paths[0][0],
        type_owner,
        owner_name,
        "method @Path value",
        workspace,
    )


def analyze_direct_jax_rs_unit(
    unit: dict[str, Any],
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Emit direct method and implicit-record-accessor facts for one shared unit.

    Example call:
        ``analyze_direct_jax_rs_unit(unit=items_unit, workspace=java_workspace)``
        emits direct method and implicit-record-accessor facts for one shared unit.
    """

    roots = {}
    for type_key, type_info in unit["type_infos"].items():
        if (
            type_info["node"].type not in {"class_declaration", "record_declaration"}
            or type_info["abstract"]
            or not type_info["workspace_visible"]
        ):
            continue
        root = resolve_jax_rs_resource_root(unit, type_info, workspace)
        if root is not None:
            roots[type_key] = root

    endpoints = []
    for method_key in sorted(unit["method_candidates"]):
        candidates = unit["method_candidates"][method_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        method_node = first_capture(representative, "method.node")
        method_name_node = first_capture(representative, "method.name")
        parameters_node = first_capture(representative, "method.parameters")
        if None in (type_node, method_node, method_name_node, parameters_node):
            continue
        type_key = tree_node_key(type_node)
        root = roots.get(type_key)
        type_info = unit["type_infos"].get(type_key)
        if root is None or type_info is None:
            continue

        method_name = node_text(unit["source"], method_name_node)
        owner_name = f"{type_info['display_name']}.{method_name}"
        records = annotation_records(candidates)
        designator = resolve_jax_rs_request_designator(
            unit, records, workspace, root["namespace"], owner_name
        )
        if designator is None:
            continue
        if not method_is_public(method_node):
            log_jax_rs_skip(
                unit["source_path"],
                owner_name,
                "non-public resource method",
            )
            continue
        method_path = resolve_jax_rs_method_path(
            unit,
            records,
            root["namespace"],
            type_info["display_name"],
            owner_name,
            workspace,
        )
        if method_path is None:
            continue
        application_path = resolve_jax_rs_resource_prefix(
            workspace, unit, root["namespace"], owner_name
        )
        if application_path is None:
            continue

        endpoint_path = join_endpoint_paths(
            join_endpoint_paths(application_path, root["path"]), method_path
        )
        # Direct methods own both the applied designator evidence and the
        # represented handler target, so annotation reports can link exactly.
        endpoint = EndpointFact(
            path=endpoint_path,
            method=designator["method"],
            parameters=parameter_list_source_text(unit["source"], parameters_node),
            source_file=unit["source_path"],
            source_line=designator["node"].start_point.row + 1,
            handler_name=owner_name,
            technology="jax-rs",
            direction="inbound",
            annotation_evidence=method_annotation_evidence_from_node(
                designator["node"],
                designator["annotation_identity"],
                designator["annotation_family"],
                annotation_source_file=unit["source_path"],
                endpoint_source_file=unit["source_path"],
            ),
            represented_targets=represented_target_evidence(
                unit["source_path"], "method", method_node
            ),
        )
        endpoints.append(endpoint)
        record(format_endpoint_diagnostic(endpoint))

    for component_key in sorted(unit["record_component_candidates"]):
        candidates = unit["record_component_candidates"][component_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        component_node = first_capture(representative, "component.node")
        component_name_node = first_capture(representative, "component.name")
        if None in (type_node, component_node, component_name_node):
            continue
        type_key = tree_node_key(type_node)
        root = roots.get(type_key)
        type_info = unit["type_infos"].get(type_key)
        if root is None or type_info is None:
            continue

        component_name = node_text(unit["source"], component_name_node)
        if (type_key, component_name) in unit["record_explicit_accessors"]:
            continue
        owner_name = f"{type_info['display_name']}.{component_name}"
        records = select_jax_rs_accessor_annotations(
            unit, candidates, workspace, type_info["display_name"]
        )
        designator = resolve_jax_rs_request_designator(
            unit, records, workspace, root["namespace"], owner_name
        )
        if designator is None:
            continue
        method_path = resolve_jax_rs_method_path(
            unit,
            records,
            root["namespace"],
            type_info["display_name"],
            owner_name,
            workspace,
        )
        if method_path is None:
            continue
        application_path = resolve_jax_rs_resource_prefix(
            workspace, unit, root["namespace"], owner_name
        )
        if application_path is None:
            continue

        endpoint_path = join_endpoint_paths(
            join_endpoint_paths(application_path, root["path"]), method_path
        )
        # The route annotation is physically on the component, not a declared
        # method; only represented-component evidence is therefore claimed.
        endpoint = EndpointFact(
            path=endpoint_path,
            method=designator["method"],
            parameters="",
            source_file=unit["source_path"],
            source_line=designator["node"].start_point.row + 1,
            handler_name=owner_name,
            technology="jax-rs",
            direction="inbound",
            represented_targets=represented_target_evidence(
                unit["source_path"], "record-component", component_node
            ),
        )
        endpoints.append(endpoint)
        record(format_endpoint_diagnostic(endpoint))
    return tuple(endpoints)


def attach_workspace_indexes(workspace: dict[str, Any]) -> None:
    """Attach every JAX-RS index without rebuilding compilation units.

    Example call:
        ``attach_workspace_indexes(workspace=java_workspace)``
        attaches every JAX-RS index without rebuilding compilation units.
    """

    index_jax_rs_custom_designators(workspace)
    index_jax_rs_application_paths(workspace)


def clear_workspace_indexes(workspace: dict[str, Any]) -> None:
    """Install the empty JAX-RS workspace shape when analysis is disabled.

    Example call:
        ``clear_workspace_indexes(workspace=java_workspace)``
        installs the empty JAX-RS workspace shape when analysis is disabled.
    """

    workspace["jax_rs_custom_designator_candidates"] = set()
    workspace["jax_rs_custom_designators"] = {}
    workspace["jax_rs_applications"] = []


__all__ = [
    "analyze_direct_jax_rs_unit",
    "attach_workspace_indexes",
    "clear_workspace_indexes",
    "decode_custom_http_method",
    "decode_jax_rs_path_annotation",
    "index_jax_rs_application_paths",
    "index_jax_rs_custom_designators",
    "log_jax_rs_skip",
    "method_is_public",
    "package_is_ancestor",
    "package_specificity",
    "resolve_custom_designator",
    "resolve_direct_jax_rs_application_namespace",
    "resolve_jax_rs_method_path",
    "resolve_jax_rs_request_designator",
    "resolve_jax_rs_resource_prefix",
    "resolve_jax_rs_resource_root",
    "select_jax_rs_accessor_annotations",
]
