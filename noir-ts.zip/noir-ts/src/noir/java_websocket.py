"""Bounded Javax/Jakarta WebSocket handshake endpoint extraction.

The module is import-cycle free and consumes an already-built Java workspace.

Logic guide: ``p6.logic/06-jax-rs.md``.
"""

from __future__ import annotations

from typing import Any

from .diagnostics import format_endpoint_diagnostic, record
from .evidence import represented_target_evidence
from .java_frontend import (
    child_by_field,
    declaration_modifier_names,
    direct_annotation_records,
    get_annotation_arguments,
    nearest_enclosing_type,
    node_text,
    qualified_type_name,
    resolve_known_annotation,
    type_is_abstract,
)
from .java_workspace import resolve_workspace_string_expression
from .model import EndpointFact
from .paths import ensure_path_leading_slash


JAVA_WEBSOCKET_SERVER_ENDPOINT_PACKAGES = (
    "jakarta.websocket.server",
    "javax.websocket.server",
)

__all__ = [
    "JAVA_WEBSOCKET_SERVER_ENDPOINT_PACKAGES",
    "analyze_java_websocket_endpoints",
]


def _log_websocket_skip(
    unit: dict[str, Any],
    type_display_name: str,
    message: str,
) -> None:
    """Record a type-scoped reason that no handshake fact was emitted.

    Example call:
        ``_log_websocket_skip(
            unit=items_unit,
            type_display_name="ItemsEndpoint",
            message="unresolved route path",
        )``
        records a type-scoped reason that no handshake fact was emitted.
    """

    record(
        "Skipped WebSocket endpoint in "
        f"{unit['source_path']} for {type_display_name}: {message}"
    )


def _declared_constructors(type_node: Any) -> list[Any]:
    """Return explicit constructors used by the endpoint-instantiation gate.

    Example call:
        ``_declared_constructors(type_node=items_endpoint_type_node)``
        returns explicit constructors used by the endpoint-instantiation gate.
    """

    body = child_by_field(type_node, "body")
    if body is None:
        return []
    return [
        child for child in body.named_children if child.type == "constructor_declaration"
    ]


def _has_public_zero_arg_constructor(type_node: Any) -> bool:
    """Prove the bounded constructor shape required for endpoint classes.

    Example call:
        ``_has_public_zero_arg_constructor(type_node=items_endpoint_type_node)``
        proves the bounded constructor shape required for endpoint classes.
    """

    constructors = _declared_constructors(type_node)
    if not constructors:
        return True
    for constructor in constructors:
        if "public" not in declaration_modifier_names(constructor):
            continue
        parameters = child_by_field(constructor, "parameters")
        if parameters is not None and not any(
            child.type in {"formal_parameter", "spread_parameter"}
            for child in parameters.named_children
        ):
            return True
    return False


def _record_has_no_components(type_node: Any) -> bool:
    """Prove that a record has an invocable zero-argument canonical constructor.

    Example call:
        ``_record_has_no_components(type_node=items_endpoint_record_node)``
        proves that a record has an invocable zero-argument canonical constructor.
    """

    parameters = child_by_field(type_node, "parameters")
    return parameters is not None and not any(
        child.type in {"formal_parameter", "spread_parameter"}
        for child in parameters.named_children
    )


def _endpoint_type_rejection_reason(
    unit: dict[str, Any],
    type_info: dict[str, Any],
) -> str | None:
    """Apply visibility, nesting, concreteness, and construction viability gates.

    Example call:
        ``_endpoint_type_rejection_reason(
            unit=items_unit,
            type_info=items_endpoint_type_info,
        )``
        applies visibility, nesting, concreteness, and construction viability gates.
    """

    type_node = type_info["node"]
    modifiers = declaration_modifier_names(type_node)
    if not type_info.get("workspace_visible", False):
        return "type is not workspace-visible"
    if "public" not in modifiers:
        return "type is not public"
    outer = nearest_enclosing_type(type_node)
    while outer is not None:
        if "public" not in declaration_modifier_names(outer):
            return "enclosing type is not public"
        outer = nearest_enclosing_type(outer)
    if type_node.type == "class_declaration":
        if type_is_abstract(unit["source"], type_node):
            return "type is abstract"
        outer = nearest_enclosing_type(type_node)
        if outer is not None and "static" not in modifiers:
            return "nested class is not static"
        if not _has_public_zero_arg_constructor(type_node):
            return "class has no public zero-argument constructor"
        return None
    if type_node.type == "record_declaration":
        if not _record_has_no_components(type_node):
            return "record has components and no zero-argument canonical constructor"
        return None
    return f"unsupported annotated {type_node.type}"


def _resolve_server_endpoint_annotation(
    unit: dict[str, Any],
    type_node: Any,
) -> tuple[dict[str, Any] | None, str | None]:
    """Select exactly one genuine Javax/Jakarta ServerEndpoint annotation.

    Example call:
        ``_resolve_server_endpoint_annotation(
            unit=items_unit,
            type_node=items_endpoint_type_node,
        )``
        selects exactly one genuine Javax/Jakarta ServerEndpoint annotation.
    """

    genuine = []
    for annotation_record in direct_annotation_records(type_node):
        resolved = resolve_known_annotation(
            unit,
            annotation_record["name_node"],
            {"ServerEndpoint"},
            JAVA_WEBSOCKET_SERVER_ENDPOINT_PACKAGES,
        )
        if resolved is not None:
            genuine.append((annotation_record, resolved))
    if not genuine:
        return None, None
    if len(genuine) != 1:
        return None, "multiple genuine ServerEndpoint annotations"
    record, resolved = genuine[0]
    return {**record, **resolved}, None


def _extract_server_endpoint_path_node(
    annotation_node: Any,
) -> tuple[Any, str | None]:
    """Return the endpoint path while ignoring unrelated annotation options.

    ``ServerEndpoint`` also accepts encoders, decoders, subprotocols, and a
    configurator.  Those options do not change handshake-route identity, so
    rejecting them would lose an otherwise statically identifiable endpoint.

    Example call:
        ``_extract_server_endpoint_path_node(
            annotation_node=server_endpoint_annotation_node,
        )``
        returns the endpoint path while ignoring unrelated annotation options.
    """

    positional, named = get_annotation_arguments(annotation_node)
    if positional and "value" in named:
        return None, "both positional and named values"
    if "value" in named:
        return named["value"], None
    if len(positional) == 1:
        return positional[0], None
    if not positional:
        return None, "missing value"
    return None, "multiple positional values"


def analyze_java_websocket_endpoints(
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return one handshake endpoint fact per valid source declaration.

    Example call:
        ``analyze_java_websocket_endpoints(workspace=java_workspace)``
        returns one handshake endpoint fact per valid source declaration.
    """

    endpoints: list[EndpointFact] = []
    for source_path in sorted(workspace.get("compilation_units", {})):
        unit = workspace["compilation_units"][source_path]
        for type_key in sorted(unit.get("type_infos", {})):
            type_info = unit["type_infos"][type_key]
            type_node = type_info["node"]
            endpoint_annotation, annotation_error = _resolve_server_endpoint_annotation(
                unit, type_node
            )
            if endpoint_annotation is None:
                if annotation_error:
                    _log_websocket_skip(
                        unit, type_info["display_name"], annotation_error
                    )
                continue

            type_display_name = type_info["display_name"]
            type_fqn = qualified_type_name(unit, type_info)
            # A unique source identity keeps route and represented-type provenance exact.
            declarations = workspace.get("type_declarations", {}).get(
                type_fqn, []
            )
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                _log_websocket_skip(
                    unit,
                    type_display_name,
                    "duplicate or ambiguous source type identity",
                )
                continue
            rejection_reason = _endpoint_type_rejection_reason(unit, type_info)
            if rejection_reason:
                _log_websocket_skip(
                    unit, type_display_name, rejection_reason
                )
                continue

            path_node, value_error = _extract_server_endpoint_path_node(
                endpoint_annotation["node"]
            )
            if value_error:
                _log_websocket_skip(
                    unit,
                    type_display_name,
                    f"invalid annotation value: {value_error}",
                )
                continue
            resolved_path = resolve_workspace_string_expression(
                unit,
                path_node,
                workspace,
                type_display_name,
            )
            if resolved_path is None:
                expression = node_text(unit["source"], path_node).strip()
                _log_websocket_skip(
                    unit,
                    type_display_name,
                    f"unresolved path: {expression}",
                )
                continue
            resolved_path = resolved_path.strip()
            if (
                not resolved_path
                or "?" in resolved_path
                or "#" in resolved_path
            ):
                _log_websocket_skip(
                    unit,
                    type_display_name,
                    "path is empty or contains query/fragment syntax",
                )
                continue
            endpoint_path = ensure_path_leading_slash(resolved_path)
            # ServerEndpoint identifies a handshake route, not a Java method annotation.
            endpoint = EndpointFact(
                path=endpoint_path,
                method="GET",
                protocol="ws",
                surface="websocket",
                direction="inbound",
                technology="jax-websocket",
                parameters="",
                source_file=unit["source_path"],
                source_line=endpoint_annotation["node"].start_point.row + 1,
                handler_name=type_display_name,
                route_source_file=unit["source_path"],
                route_source_line=endpoint_annotation["node"].start_point.row + 1,
                handler_source_file=unit["source_path"],
                handler_source_line=type_node.start_point.row + 1,
                annotation_evidence=(),
                represented_targets=represented_target_evidence(
                    unit["source_path"], "type", type_node
                ),
            )
            endpoints.append(endpoint)
            record(format_endpoint_diagnostic(endpoint))
    return tuple(endpoints)
