"""Spring-family setup and ordered endpoint orchestration.

This facade is the only framework-level owner of the complete Spring pass
sequence.  Individual Spring modules keep their focused semantic work, while
the application pipeline can treat the family as one configured analyzer.
The facade depends only on Spring modules and framework-neutral application
values; it has no JAX-RS knowledge.

Logic guides: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from typing import Any

from .model import AnalysisRequest, EndpointFact
from .spring_clients import analyze_spring_http_clients
from .spring_config import (
    analyze_spring_resource_handlers,
    apply_spring_path_configuration,
    build_spring_path_configuration,
)
from .spring_gateway import analyze_spring_gateway
from .spring_mvc import analyze_direct_spring_mvc_unit
from .spring_mvc_hierarchy import analyze_spring_mvc_hierarchy
from .spring_route_registrations import analyze_spring_route_registrations
from .spring_websocket_messaging import analyze_spring_websocket_and_messaging


def configure_spring_workspace(
    workspace: dict[str, Any],
    *,
    selected: bool,
) -> None:
    """Leave the neutral workspace unchanged for either Spring state.

    Spring derives its meanings directly from neutral workspace indexes and
    therefore needs neither selected-only attachment nor an empty unselected
    shape.  The explicit no-op gives orchestration the same readable setup
    contract for every registered family.

    Example call:
        ``configure_spring_workspace(java_workspace, selected=True)`` returns
        ``None`` without adding or removing workspace entries.
    """

    return None


def prepare_spring_analysis(
    request: AnalysisRequest,
    workspace: dict[str, Any],
) -> None:
    """Perform no project-wide preparation before Spring analysis.

    Spring path configuration intentionally remains the final part of the
    family analysis sequence because it consumes the endpoint facts produced
    by every preceding Spring pass.  This hook exists only to satisfy the
    common prepare-all-before-analyze orchestration phase.

    Example call:
        ``prepare_spring_analysis(request, java_workspace)`` returns ``None``
        and leaves project configuration loading to ``analyze_spring_framework``.
    """

    return None


def analyze_spring_framework(
    request: AnalysisRequest,
    source_paths: tuple[str, ...],
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Run the complete Spring analyzer family in its established order.

    Direct MVC analysis visits the ordered source snapshot first.  When the
    workspace contains units, the project-wide route, hierarchy, Gateway,
    resource, client, and messaging passes follow exactly once.  Resolved
    Spring project paths are applied once to the combined facts at the end.

    Example call:
        ``analyze_spring_framework(request, source_snapshot.paths,
        java_workspace)`` returns Spring ``EndpointFact`` values after every
        selected Spring pass and project path layer has been applied.
    """

    endpoints: list[EndpointFact] = []
    units = workspace.get("compilation_units", {})
    for source_path in source_paths:
        unit = units.get(source_path)
        if unit is not None:
            endpoints.extend(analyze_direct_spring_mvc_unit(unit, workspace))
    if not units:
        return ()

    endpoints.extend(analyze_spring_route_registrations(workspace))
    endpoints.extend(analyze_spring_mvc_hierarchy(workspace))
    endpoints.extend(analyze_spring_gateway(workspace))
    endpoints.extend(analyze_spring_resource_handlers(workspace))
    endpoints.extend(analyze_spring_http_clients(workspace))
    configuration = build_spring_path_configuration(
        workspace,
        str(request.analysis_root),
    )
    endpoints.extend(
        analyze_spring_websocket_and_messaging(workspace, configuration)
    )
    return tuple(apply_spring_path_configuration(endpoints, configuration))


__all__ = [
    "analyze_spring_framework",
    "configure_spring_workspace",
    "prepare_spring_analysis",
]
