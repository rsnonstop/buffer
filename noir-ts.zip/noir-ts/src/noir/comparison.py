"""Compare the broad annotation audit with a Noir endpoint report.

The comparison boundary understands only the stable presentation records
produced by the annotation audit and the source locations carried by a Noir
v1.1 JSON report.  It does not participate in Java analysis or endpoint
emission.  See ``p6.logic/07-output-evidence-reports.md`` for the surrounding
report and publication boundaries.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
import json
import os
from pathlib import Path
from typing import Any

from .evidence import canonical_source_file_name


class NoirReportValidationError(ValueError):
    """Identify malformed JSON or an unsupported Noir report shape.

    Example value:
        ``NoirReportValidationError("Noir report.endpoints is required")``
        explains which external-report coordinate cannot be consumed.
    """


@dataclass(frozen=True, slots=True, order=True)
class SourceLocation:
    """One canonical source file and positive one-based source line."""

    # Canonical absolute spelling of the source file being compared.
    source_file: str
    # Positive one-based source line used as the comparison identity.
    line: int

    # Example value: SourceLocation("/workspace/app/ItemsController.java", 42)


@dataclass(frozen=True, slots=True, order=True)
class AnnotationFramework:
    """One framework classification retained from a P2 audit item."""

    # Framework label shown by the broad annotation inventory, such as Spring.
    framework: str
    # Proven annotation identity or resolution explanation retained for review.
    resolved: str

    # Example value:
    # AnnotationFramework("spring", "org.springframework...GetMapping")


@dataclass(frozen=True, slots=True, order=True)
class SourceExtractLine:
    """One physical source line retained in a P2 annotation extract."""

    # One-based number of a physical Java source line in the displayed extract.
    line: int
    # Original text of that physical line, without inventing normalized Java.
    source: str

    # Example value: SourceExtractLine(42, '    @GetMapping("/items")')


@dataclass(frozen=True, slots=True)
class AnnotationAuditItem:
    """One flattened broad-audit occurrence with exact source identity."""

    # Inventory-facing source path spelling supplied by the analysis result.
    file: str
    # Annotation spelling found in source, for example ``GetMapping``.
    name: str
    # Positive one-based line on which that annotation begins.
    line: int
    # Framework interpretations proven for this occurrence.
    frameworks: tuple[AnnotationFramework, ...]
    # Small physical-source excerpt that lets a reader inspect the occurrence.
    extract: tuple[SourceExtractLine, ...]
    # Canonical file/line identity used to compare with Noir code paths.
    location: SourceLocation

    # Example value:
    # AnnotationAuditItem("src/ItemsController.java", "GetMapping", 42,
    #                     (spring_mapping,), (extract_line,), location)


@dataclass(frozen=True, slots=True)
class AnnotationComparison:
    """Deterministic partition of P2 audit items by Noir location coverage."""

    # All flattened annotation occurrences considered by the comparison.
    annotations: tuple[AnnotationAuditItem, ...]
    # Occurrences whose exact canonical file/line appears in the Noir report.
    matched_annotations: tuple[AnnotationAuditItem, ...]
    # Occurrences with no matching Noir code-path location.
    missing_annotations: tuple[AnnotationAuditItem, ...]
    # Deduplicated external Noir source locations used as the coverage set.
    noir_locations: tuple[SourceLocation, ...]

    # Example value:
    # AnnotationComparison((mapping,), (mapping,), (), (mapping.location,))

    @property
    def total_count(self) -> int:
        """Return the number of flattened annotation occurrences.

        Example call:
            ``comparison.total_count`` returns ``2`` when two source annotation
            occurrences were included in ``comparison.annotations``.
        """

        return len(self.annotations)

    @property
    def matched_count(self) -> int:
        """Return how many annotation occurrences Noir covers by location.

        Example call:
            ``comparison.matched_count`` returns ``1`` when one annotation's
            canonical file and line occur in the Noir endpoint report.
        """

        return len(self.matched_annotations)

    @property
    def missing_count(self) -> int:
        """Return how many annotation occurrences Noir does not cover.

        Example call:
            ``comparison.missing_count`` returns ``1`` when one audited
            ``@GetMapping`` location is absent from Noir's code paths.
        """

        return len(self.missing_annotations)


def _sequence(value: Any, coordinate: str) -> Sequence[Any]:
    """Require an array-like value at one report coordinate.

    Example call:
        ``_sequence([{"path": "src/Items.java"}],
        "Noir report.endpoints")`` returns that list; passing ``"items"``
        raises ``NoirReportValidationError`` naming the coordinate.
    """

    if isinstance(value, Sequence) and not isinstance(
        value, (str, bytes, bytearray)
    ):
        return value
    raise NoirReportValidationError(f"{coordinate} must be an array")


def _mapping(value: Any, coordinate: str) -> Mapping[str, Any]:
    """Require an object-like value at one report coordinate.

    Example call:
        ``_mapping({"details": {}}, "Noir report.endpoints[0]")`` returns the
        endpoint object; passing a list raises a coordinate-specific error.
    """

    if isinstance(value, Mapping):
        return value
    raise NoirReportValidationError(f"{coordinate} must be an object")


def _positive_line(value: Any, coordinate: str) -> int:
    """Require a positive one-based application source line.

    Example call:
        ``_positive_line(42, "code_paths[0].line")`` returns ``42``; ``0`` or
        ``True`` raises ``NoirReportValidationError``.
    """

    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise NoirReportValidationError(
            f"{coordinate} must be a positive integer or null"
        )
    return value


def _analysis_root_path(analysis_root: Any) -> tuple[Path, frozenset[str]]:
    """Resolve the scanned application root and its usable basename spellings.

    Example call:
        ``_analysis_root_path("/workspace/sample-app")`` returns the resolved
        root plus ``frozenset({"sample-app"})`` for interpreting report paths.
    """

    try:
        supplied = Path(os.fspath(analysis_root)).expanduser()
    except (TypeError, ValueError) as error:
        raise ValueError("analysis_root must be a usable path") from error
    resolved = supplied.resolve(strict=False)
    names = frozenset(name for name in (supplied.name, resolved.name) if name)
    return resolved, names


def _canonical_location_path(
    source_file: Any,
    analysis_root: Path,
    analysis_root_names: frozenset[str],
    coordinate: str,
    *,
    allow_noir_root_prefix: bool = False,
) -> str:
    """Canonicalize an absolute or analysis-root-relative source spelling.

    Noir can retain the scanned root's basename in an otherwise relative path,
    for example ``sample-app/src/Api.java`` for a root named ``sample-app``.
    For Noir inputs only, an existing source disambiguates that spelling from
    a genuinely root-relative path beginning with the same component.  If both
    interpretations name existing files, validation fails closed; if neither
    exists, the retained-prefix interpretation is the deterministic fallback.
    P2 audit paths are always interpreted directly relative to the analysis
    root.

    Example call:
        ``_canonical_location_path("src/ItemsController.java",
        Path("/workspace/sample-app"), frozenset({"sample-app"}),
        "annotation.file")`` returns the canonical absolute source spelling
        ``"/workspace/sample-app/src/ItemsController.java"``.
    """

    if not isinstance(source_file, str) or not source_file.strip():
        raise NoirReportValidationError(f"{coordinate} must be a non-empty string")
    try:
        source_path = Path(source_file).expanduser()
    except (TypeError, ValueError) as error:
        raise NoirReportValidationError(f"{coordinate} is not a usable path") from error

    if source_path.is_absolute():
        candidate = source_path
    else:
        candidate = analysis_root / source_path
        parts = source_path.parts
        may_include_root_prefix = (
            allow_noir_root_prefix
            and parts
            and parts[0] in analysis_root_names
        )
        if may_include_root_prefix:
            root_prefixed_candidate = analysis_root.joinpath(*parts[1:])
            direct_exists = candidate.is_file()
            prefixed_exists = root_prefixed_candidate.is_file()
            if direct_exists and prefixed_exists:
                raise NoirReportValidationError(
                    f"{coordinate} is ambiguous: both root-relative and "
                    "root-prefixed source files exist"
                )
            if prefixed_exists or not direct_exists:
                candidate = root_prefixed_candidate
    canonical = canonical_source_file_name(candidate)
    if canonical is None:
        raise NoirReportValidationError(f"{coordinate} is not a usable path")
    return canonical


def _load_json_object(report_path: Any) -> Mapping[str, Any]:
    """Decode one UTF-8 Noir JSON report and require a top-level object.

    Example call:
        ``_load_json_object("/workspace/noir-output.json")`` returns a mapping
        such as ``{"endpoints": [...]}``; malformed JSON or a top-level array
        raises ``NoirReportValidationError``.
    """

    path = Path(report_path).expanduser()
    try:
        with path.open("r", encoding="utf-8-sig") as report:
            payload = json.load(report)
    except (json.JSONDecodeError, UnicodeError) as error:
        raise NoirReportValidationError(
            f"invalid Noir JSON report {path}: {error}"
        ) from error
    return _mapping(payload, "Noir report")


def load_noir_report_locations(
    report_path: Any,
    analysis_root: Any,
) -> frozenset[SourceLocation]:
    """Load and index all line-bearing code paths in a Noir v1.1 report.

    The supported report is a JSON object with an ``endpoints`` array.  Every
    endpoint must carry ``details.code_paths``.  A code-path record may omit
    ``line`` or set it to ``null``; those records provide no comparable
    annotation location and are skipped.  Present lines and paths are validated
    strictly, and duplicate canonical locations collapse into one set member.

    Example call:
        ``load_noir_report_locations("/workspace/noir-output.json",
        "/workspace/sample-app")`` returns values such as
        ``SourceLocation("/workspace/sample-app/src/Items.java", 42)`` from
        endpoint code paths that carry a line.
    """

    root, root_names = _analysis_root_path(analysis_root)
    payload = _load_json_object(report_path)
    if "endpoints" not in payload:
        raise NoirReportValidationError("Noir report.endpoints is required")
    endpoints = _sequence(payload["endpoints"], "Noir report.endpoints")

    locations: set[SourceLocation] = set()
    for endpoint_index, endpoint_value in enumerate(endpoints):
        endpoint_coordinate = f"Noir report.endpoints[{endpoint_index}]"
        endpoint = _mapping(endpoint_value, endpoint_coordinate)
        if "details" not in endpoint:
            raise NoirReportValidationError(
                f"{endpoint_coordinate}.details is required"
            )
        details = _mapping(endpoint["details"], f"{endpoint_coordinate}.details")
        if "code_paths" not in details:
            raise NoirReportValidationError(
                f"{endpoint_coordinate}.details.code_paths is required"
            )
        code_paths = _sequence(
            details["code_paths"], f"{endpoint_coordinate}.details.code_paths"
        )
        for code_path_index, code_path_value in enumerate(code_paths):
            code_path_coordinate = (
                f"{endpoint_coordinate}.details.code_paths[{code_path_index}]"
            )
            code_path = _mapping(code_path_value, code_path_coordinate)
            if "path" not in code_path:
                raise NoirReportValidationError(
                    f"{code_path_coordinate}.path is required"
                )
            # Validate the path even when a Noir technology omits line evidence;
            # this keeps accepted reports structurally predictable.
            canonical_path = _canonical_location_path(
                code_path["path"],
                root,
                root_names,
                f"{code_path_coordinate}.path",
                allow_noir_root_prefix=True,
            )
            line_value = code_path.get("line")
            if line_value is None:
                continue
            line = _positive_line(line_value, f"{code_path_coordinate}.line")
            locations.add(SourceLocation(canonical_path, line))
    return frozenset(locations)


def _inventory_sequence(value: Any, coordinate: str) -> Sequence[Any]:
    """Validate an annotation-inventory collection with its public error type.

    Example call:
        ``_inventory_sequence([{"file": "src/Items.java"}],
        "annotation inventory")`` returns the list; passing an object raises
        ``ValueError`` using the same coordinate.
    """

    try:
        return _sequence(value, coordinate)
    except NoirReportValidationError as error:
        raise ValueError(str(error)) from error


def _inventory_mapping(value: Any, coordinate: str) -> Mapping[str, Any]:
    """Validate one annotation-inventory record with its public error type.

    Example call:
        ``_inventory_mapping({"name": "GetMapping"},
        "annotation inventory[0].annotations[0]")`` returns the record;
        passing a list raises ``ValueError``.
    """

    try:
        return _mapping(value, coordinate)
    except NoirReportValidationError as error:
        raise ValueError(str(error)) from error


def _inventory_text(value: Any, coordinate: str, *, allow_empty: bool = False) -> str:
    """Require application-facing text in the annotation inventory.

    Example call:
        ``_inventory_text("GetMapping", "annotation.name")`` returns
        ``"GetMapping"``; ``_inventory_text("", "extract.source",
        allow_empty=True)`` accepts an intentionally blank source line.
    """

    if not isinstance(value, str) or (not allow_empty and not value):
        qualifier = "a string" if allow_empty else "a non-empty string"
        raise ValueError(f"{coordinate} must be {qualifier}")
    return value


def _inventory_line(value: Any, coordinate: str) -> int:
    """Require a positive source line in an annotation-inventory record.

    Example call:
        ``_inventory_line(42, "annotation.line")`` returns ``42``; ``None``
        raises ``ValueError`` naming ``annotation.line``.
    """

    try:
        return _positive_line(value, coordinate)
    except NoirReportValidationError as error:
        raise ValueError(str(error)) from error


def _flatten_frameworks(value: Any, coordinate: str) -> tuple[AnnotationFramework, ...]:
    """Normalize one annotation's framework interpretations for comparison.

    Example call:
        ``_flatten_frameworks([{"framework": "spring", "resolved":
        "org.springframework.web.bind.annotation.GetMapping"}],
        "annotation.frameworks")`` returns one sorted ``AnnotationFramework``.
    """

    frameworks: set[AnnotationFramework] = set()
    for index, framework_value in enumerate(_inventory_sequence(value, coordinate)):
        item_coordinate = f"{coordinate}[{index}]"
        framework = _inventory_mapping(framework_value, item_coordinate)
        for required in ("framework", "resolved"):
            if required not in framework:
                raise ValueError(f"{item_coordinate}.{required} is required")
        frameworks.add(
            AnnotationFramework(
                _inventory_text(
                    framework["framework"], f"{item_coordinate}.framework"
                ),
                _inventory_text(framework["resolved"], f"{item_coordinate}.resolved"),
            )
        )
    return tuple(sorted(frameworks))


def _flatten_extract(value: Any, coordinate: str) -> tuple[SourceExtractLine, ...]:
    """Normalize the physical source excerpt retained for one annotation.

    Example call:
        ``_flatten_extract([{"line": 42, "source":
        "    @GetMapping(\"/items\")"}], "annotation.extract")`` returns one
        ``SourceExtractLine(42, ...)`` in source order.
    """

    extract: set[SourceExtractLine] = set()
    for index, source_line_value in enumerate(_inventory_sequence(value, coordinate)):
        item_coordinate = f"{coordinate}[{index}]"
        source_line = _inventory_mapping(source_line_value, item_coordinate)
        for required in ("line", "source"):
            if required not in source_line:
                raise ValueError(f"{item_coordinate}.{required} is required")
        extract.add(
            SourceExtractLine(
                _inventory_line(source_line["line"], f"{item_coordinate}.line"),
                _inventory_text(
                    source_line["source"],
                    f"{item_coordinate}.source",
                    allow_empty=True,
                ),
            )
        )
    return tuple(sorted(extract))


def _annotation_sort_key(item: AnnotationAuditItem) -> tuple[Any, ...]:
    """Return the stable report ordering key for one annotation occurrence.

    Example call:
        ``_annotation_sort_key(mapping_item)`` returns a tuple beginning with
        ``("src/ItemsController.java", 42, "GetMapping")``.
    """

    return (
        item.file,
        item.line,
        item.name,
        item.frameworks,
        item.extract,
        item.location,
    )


def flatten_annotation_audit_inventory(
    inventory: Any,
    analysis_root: Any,
) -> tuple[AnnotationAuditItem, ...]:
    """Flatten the broad P2 per-file inventory into deterministic occurrences.

    Files with ``Annotations: none`` contribute no item.  Repeated annotation
    occurrences are retained because the P2 contract treats source occurrences,
    rather than names, as list members.  Framework classifications and extract
    lines are normalized for stable rendering.

    Example call:
        ``flatten_annotation_audit_inventory([{"file":
        "src/ItemsController.java", "annotations": [{"name": "GetMapping",
        "line": 42, "frameworks": [...], "extract": [...]}]}],
        "/workspace/sample-app")`` returns a tuple containing one canonical
        ``AnnotationAuditItem`` for that source occurrence.
    """

    root, root_names = _analysis_root_path(analysis_root)
    annotations: list[AnnotationAuditItem] = []
    for file_index, file_value in enumerate(
        _inventory_sequence(inventory, "annotation inventory")
    ):
        file_coordinate = f"annotation inventory[{file_index}]"
        file_record = _inventory_mapping(file_value, file_coordinate)
        for required in ("file", "annotations"):
            if required not in file_record:
                raise ValueError(f"{file_coordinate}.{required} is required")
        display_file = _inventory_text(
            file_record["file"], f"{file_coordinate}.file"
        )
        canonical_file = _canonical_location_path(
            display_file,
            root,
            root_names,
            f"{file_coordinate}.file",
        )
        annotation_values = _inventory_sequence(
            file_record["annotations"], f"{file_coordinate}.annotations"
        )
        for annotation_index, annotation_value in enumerate(annotation_values):
            annotation_coordinate = (
                f"{file_coordinate}.annotations[{annotation_index}]"
            )
            annotation = _inventory_mapping(annotation_value, annotation_coordinate)
            for required in ("name", "line", "frameworks", "extract"):
                if required not in annotation:
                    raise ValueError(f"{annotation_coordinate}.{required} is required")
            line = _inventory_line(
                annotation["line"], f"{annotation_coordinate}.line"
            )
            annotations.append(
                AnnotationAuditItem(
                    file=display_file,
                    name=_inventory_text(
                        annotation["name"], f"{annotation_coordinate}.name"
                    ),
                    line=line,
                    frameworks=_flatten_frameworks(
                        annotation["frameworks"],
                        f"{annotation_coordinate}.frameworks",
                    ),
                    extract=_flatten_extract(
                        annotation["extract"], f"{annotation_coordinate}.extract"
                    ),
                    location=SourceLocation(canonical_file, line),
                )
            )
    return tuple(sorted(annotations, key=_annotation_sort_key))


def compare_annotation_audit_inventory(
    inventory: Any,
    noir_locations: Iterable[SourceLocation],
    analysis_root: Any,
) -> AnnotationComparison:
    """Partition audited annotations by exact Noir file-and-line coverage.

    Example call:
        ``compare_annotation_audit_inventory(inventory,
        {SourceLocation("/workspace/app/Items.java", 42)}, "/workspace/app")``
        places the annotation at ``Items.java:42`` in ``matched_annotations``
        and all other occurrences in ``missing_annotations``.
    """

    annotations = flatten_annotation_audit_inventory(inventory, analysis_root)
    locations = set()
    for location in noir_locations:
        if not isinstance(location, SourceLocation):
            raise TypeError("noir_locations must contain SourceLocation values")
        locations.add(location)
    matched = tuple(item for item in annotations if item.location in locations)
    missing = tuple(item for item in annotations if item.location not in locations)
    return AnnotationComparison(
        annotations=annotations,
        matched_annotations=matched,
        missing_annotations=missing,
        noir_locations=tuple(sorted(locations)),
    )


def _render_annotation_item(item: AnnotationAuditItem) -> list[str]:
    """Render one uncovered annotation with its classifications and source.

    Example call:
        ``_render_annotation_item(mapping_item)`` returns report lines beginning
        with ``"  - Annotation: GetMapping"`` and ``"    Line: 42"``.
    """

    lines = [
        f"  - Annotation: {item.name}",
        f"    Line: {item.line}",
        "    Frameworks:",
    ]
    for framework in item.frameworks:
        lines.append(f"      - Framework: {framework.framework}")
        lines.append(f"        Resolved: {framework.resolved}")
    lines.append("    Extract:")
    lines.extend(
        f"      {source_line.line}: {source_line.source}"
        for source_line in item.extract
    )
    return lines


def render_noir_comparison_report_bytes(comparison: AnnotationComparison) -> bytes:
    """Render a deterministic coverage summary and every uncovered annotation.

    Example call:
        ``render_noir_comparison_report_bytes(comparison)`` returns UTF-8 bytes
        reporting counts such as ``Annotations found by noir-ts: 2`` and the
        retained details of each missing annotation.
    """

    if not isinstance(comparison, AnnotationComparison):
        raise TypeError("comparison must be an AnnotationComparison")
    lines = [
        "noir-ts annotation comparison against Noir",
        "",
        f"Annotations found by noir-ts: {comparison.total_count}",
        "",
        (
            "Unique Noir endpoint source locations: "
            f"{len(comparison.noir_locations)}"
        ),
        "  Unique canonical (source file, line) locations from",
        "  endpoints[*].details.code_paths[*].",
        (
            "  Duplicate locations are counted once; locations without a line "
            "are excluded."
        ),
        "",
        (
            "Annotations matched by exact source location: "
            f"{comparison.matched_count}"
        ),
        "  Match key: canonical source file and annotation start line.",
        (
            "  URLs, HTTP methods, annotation names, adjacent lines, and "
            "enclosing"
        ),
        "  declarations are not used for matching.",
        "",
        (
            "Annotations without an exact Noir source-location match: "
            f"{comparison.missing_count}"
        ),
        (
            "  These are annotation occurrences, not necessarily endpoints "
            "missed by Noir."
        ),
        "  Supporting annotations can also appear in this count.",
        "",
    ]
    if not comparison.missing_annotations:
        lines.append("noir-ts annotations, not reported by Noir: none")
        return ("\n".join(lines) + "\n").encode("utf8")

    lines.append("noir-ts annotations, not reported by Noir:")
    by_file: dict[str, list[AnnotationAuditItem]] = {}
    for item in comparison.missing_annotations:
        by_file.setdefault(item.file, []).append(item)
    for file_index, file_name in enumerate(sorted(by_file)):
        lines.append("")
        lines.append(f"File: {file_name}")
        lines.append("Annotations:")
        for annotation_index, item in enumerate(by_file[file_name]):
            if annotation_index:
                lines.append("")
            lines.extend(_render_annotation_item(item))
    return ("\n".join(lines) + "\n").encode("utf8")


def derive_noir_comparison_report_path(output_path: Any) -> Path:
    """Derive the annotation-comparison log beside the main output.

    Example call:
        ``derive_noir_comparison_report_path("/tmp/endpoints.json")`` returns
        ``Path("/tmp/endpoints-anno-without-noir-endpoints.log")``.
    """

    output = Path(output_path)
    base = output.with_suffix("") if output.suffix else output
    return base.with_name(base.name + "-anno-without-noir-endpoints.log")


__all__ = [
    "AnnotationAuditItem",
    "AnnotationComparison",
    "AnnotationFramework",
    "NoirReportValidationError",
    "SourceExtractLine",
    "SourceLocation",
    "compare_annotation_audit_inventory",
    "derive_noir_comparison_report_path",
    "flatten_annotation_audit_inventory",
    "load_noir_report_locations",
    "render_noir_comparison_report_bytes",
]
