"""Framework-aware annotation inventory over the neutral Java workspace.

Inventory owns recognition, source placement, and deterministic report facts.
It calls the package-owned Spring and JAX-RS semantic decoders directly.

Logic guides: ``p6.logic/03-shared-java-engine.md`` and
``p6.logic/07-output-evidence-reports.md``.
"""

from __future__ import annotations

from bisect import bisect_right
import re
from types import MappingProxyType
from .contracts import (
    JAX_RS_CORE_PACKAGES,
    JAX_RS_HTTP_METHODS,
    JAX_RS_PACKAGES,
    METHOD_ANNOTATION_FAMILY_JAX_RS,
    METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
    METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE,
    METHOD_ANNOTATION_FAMILY_SPRING_VERB,
    SPRING_ALIAS_FOR_PACKAGE,
    SPRING_MAPPING_METHODS,
    SPRING_MAPPING_PACKAGE,
)
from .evidence import source_target_from_node
from .java_frontend import (
    child_by_field,
    nearest_enclosing_type,
    node_text,
    qualified_type_name,
    resolve_known_annotation,
    tree_node_key,
)
from .java_workspace import source_annotation_use_is_method_applicable
from .paths import relative_source_path
from .jaxrs import resolve_custom_designator
from .spring_mvc import (
    source_annotation_definition,
    source_annotation_is_method_applicable,
    spring_composed_definition_is_supported,
)


# The broad audit registry includes route triggers plus activation and binding
# metadata useful to a human audit, whether or not an endpoint is eventually
# emitted from the occurrence.
SUPPORTED_ANNOTATION_REGISTRY = {
    "spring": (
        {
            "packages": (SPRING_MAPPING_PACKAGE,),
            "names": frozenset(SPRING_MAPPING_METHODS),
            "role": "mvc-mapping",
        },
        {
            "packages": ("org.springframework.stereotype",),
            "names": frozenset({"Controller"}),
            "role": "controller-activation",
        },
        {
            "packages": (SPRING_MAPPING_PACKAGE,),
            "names": frozenset({"RestController"}),
            "role": "controller-activation",
        },
        {
            "packages": ("org.springframework.context.annotation",),
            "names": frozenset({"Bean", "Configuration"}),
            "role": "programmatic-route-activation",
        },
        {
            "packages": ("org.springframework.beans.factory.annotation",),
            "names": frozenset({"Autowired"}),
            "role": "programmatic-route-activation",
        },
        {
            "packages": ("org.springframework.web.service.annotation",),
            "names": frozenset(
                {
                    "HttpExchange",
                    "GetExchange",
                    "PostExchange",
                    "PutExchange",
                    "DeleteExchange",
                    "PatchExchange",
                }
            ),
            "role": "http-client-mapping",
        },
        {
            "packages": ("org.springframework.cloud.openfeign",),
            "names": frozenset({"FeignClient"}),
            "role": "feign-client-activation",
        },
        {
            "packages": ("org.springframework.messaging.handler.annotation",),
            "names": frozenset({"MessageMapping", "SubscribeMapping"}),
            "role": "message-mapping",
        },
    ),
    "jaxrx": (
        {
            "packages": JAX_RS_PACKAGES,
            "names": frozenset(
                {
                    *JAX_RS_HTTP_METHODS,
                    "ApplicationPath",
                    "BeanParam",
                    "Consumes",
                    "CookieParam",
                    "DefaultValue",
                    "Encoded",
                    "FormParam",
                    "HeaderParam",
                    "HttpMethod",
                    "MatrixParam",
                    "Path",
                    "PathParam",
                    "Produces",
                    "QueryParam",
                }
            ),
            "role": "jax-rs-http-surface",
        },
        {
            "packages": JAX_RS_CORE_PACKAGES,
            "names": frozenset({"Context"}),
            "role": "jax-rs-binding-metadata",
        },
        {
            "packages": (
                "jakarta.ws.rs.container",
                "javax.ws.rs.container",
            ),
            "names": frozenset({"Suspended"}),
            "role": "jax-rs-binding-metadata",
        },
        {
            "packages": (
                "jakarta.websocket.server",
                "javax.websocket.server",
            ),
            "names": frozenset({"ServerEndpoint"}),
            "role": "websocket-handshake",
        },
    ),
}


# The narrower final-trigger registry contains only annotations whose supported
# placement can directly represent an endpoint declaration.  These records are
# later subtracted by exact represented-target evidence in the absent report.
FINAL_TRIGGER_ANNOTATION_REGISTRY = MappingProxyType(
    {
        "spring": (
            {
                "packages": (SPRING_MAPPING_PACKAGE,),
                "names": frozenset(SPRING_MAPPING_METHODS),
                "placement": "spring-mvc",
                "family_by_name": MappingProxyType(
                    {
                        name: (
                            METHOD_ANNOTATION_FAMILY_SPRING_GENERIC
                            if name == "RequestMapping"
                            else METHOD_ANNOTATION_FAMILY_SPRING_VERB
                        )
                        for name in SPRING_MAPPING_METHODS
                    }
                ),
            },
            {
                "packages": ("org.springframework.web.service.annotation",),
                "names": frozenset(
                    {
                        "HttpExchange",
                        "GetExchange",
                        "PostExchange",
                        "PutExchange",
                        "DeleteExchange",
                        "PatchExchange",
                    }
                ),
                "placement": "spring-http-exchange",
                "family_by_name": MappingProxyType(
                    {
                        name: (
                            METHOD_ANNOTATION_FAMILY_SPRING_GENERIC
                            if name == "HttpExchange"
                            else METHOD_ANNOTATION_FAMILY_SPRING_VERB
                        )
                        for name in (
                            "HttpExchange",
                            "GetExchange",
                            "PostExchange",
                            "PutExchange",
                            "DeleteExchange",
                            "PatchExchange",
                        )
                    }
                ),
            },
            {
                "packages": (
                    "org.springframework.messaging.handler.annotation",
                ),
                "names": frozenset({"MessageMapping", "SubscribeMapping"}),
                "placement": "spring-message",
                "family_by_name": MappingProxyType(
                    {
                        "MessageMapping": METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE,
                        "SubscribeMapping": METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE,
                    }
                ),
            },
        ),
        "jaxrx": (
            {
                "packages": JAX_RS_PACKAGES,
                "names": frozenset(JAX_RS_HTTP_METHODS),
                "placement": "jax-rs-designator",
                "family_by_name": MappingProxyType(
                    {
                        name: METHOD_ANNOTATION_FAMILY_JAX_RS
                        for name in JAX_RS_HTTP_METHODS
                    }
                ),
            },
            {
                "packages": (
                    "jakarta.websocket.server",
                    "javax.websocket.server",
                ),
                "names": frozenset({"ServerEndpoint"}),
                "placement": "jax-websocket",
                "family_by_name": MappingProxyType(
                    {"ServerEndpoint": "jax-websocket-server-endpoint"}
                ),
            },
        ),
    }
)


def annotation_owner_name(unit, annotation_node):
    """Return the application type that lexically owns an annotation use.

    Example call:
        ``annotation_owner_name(items_unit, get_mapping_node)`` returns
        ``"ItemsController"`` when the conceptual ``@GetMapping`` node is
        inside that controller, and ``""`` when no named type owns it.
    """

    type_node = nearest_enclosing_type(annotation_node)
    if type_node is None:
        return ""
    type_info = unit["type_infos"].get(tree_node_key(type_node))
    return type_info["display_name"] if type_info is not None else ""


def registered_annotation_classifications(
    unit, record, workspace, selected_frameworks
):
    """Classify a built-in annotation only when library provenance is exact.

    A source declaration at the expected FQN blocks the dependency shortcut;
    source-defined semantics must be proven by the separate definition lane.

    Example call:
        ``registered_annotation_classifications(items_unit,
        get_mapping_occurrence, workspace, {"spring"})`` returns
        ``[{"framework": "spring", "resolved":
        "org.springframework.web.bind.annotation.GetMapping"}]`` when exact
        library provenance is visible and not replaced by source.
    """

    classifications = []
    for framework in sorted(selected_frameworks):
        # A framework adapter may be executable before it has annotation-audit
        # semantics. Missing declarative rules therefore mean "classify none",
        # not a pipeline failure.
        for group in SUPPORTED_ANNOTATION_REGISTRY.get(framework, ()):
            resolved = resolve_known_annotation(
                unit,
                record["name_node"],
                group["names"],
                group["packages"],
            )
            if resolved is None:
                continue
            resolved_fqn = f"{resolved['namespace']}.{resolved['name']}"
            if workspace.get("type_declarations", {}).get(resolved_fqn):
                # A declaration inside the analyzed source tree owns this
                # identity, so package spelling alone cannot establish direct
                # framework provenance.  The separate source-definition pass
                # can still recognize supported Spring/JAX-RS
                continue
            classifications.append(
                {
                    "framework": framework,
                    "resolved": resolved_fqn,
                }
            )
    return classifications


def source_definition_for_annotation_metadata(unit, record, workspace):
    """Find the source annotation definition owning one metadata occurrence.

    Example call:
        ``source_definition_for_annotation_metadata(items_unit,
        retention_occurrence, workspace)`` returns the unique indexed
        ``app.ApiRoute`` definition when the conceptual ``@Retention`` occurs
        on that annotation type; ambiguous definitions return ``None``.
    """

    type_node = nearest_enclosing_type(record["node"])
    if type_node is None or type_node.type != "annotation_type_declaration":
        return None
    type_info = unit["type_infos"].get(tree_node_key(type_node))
    if type_info is None:
        return None
    fqn = qualified_type_name(unit, type_info)
    definitions = workspace["annotation_definitions"].get(fqn, [])
    return definitions[0] if len(definitions) == 1 else None


def source_defined_annotation_classifications(
    unit, record, workspace, selected_frameworks
):
    """Classify an applied source annotation through framework semantics.

    Example call:
        ``source_defined_annotation_classifications(items_unit,
        api_route_occurrence, workspace, {"spring"})`` returns
        ``[{"framework": "spring", "resolved": "app.ApiRoute"}]`` when
        ``@ApiRoute`` is a uniquely supported Spring composed mapping.
    """

    classifications = []
    owner_name = annotation_owner_name(unit, record["node"])
    if "spring" in selected_frameworks:
        resolved = source_annotation_definition(
            unit, record["name_node"], workspace, owner_name
        )
        if (
            resolved["status"] == "resolved"
            and spring_composed_definition_is_supported(
                resolved["definition"], workspace
            )
        ):
            classifications.append(
                {
                    "framework": "spring",
                    "resolved": resolved["definition"]["fqn"],
                }
            )
    if "jaxrx" in selected_frameworks:
        resolved = resolve_custom_designator(
            unit, record["name_node"], workspace, owner_name
        )
        if resolved["status"] == "resolved":
            classifications.append(
                {
                    "framework": "jaxrx",
                    "resolved": resolved["record"]["fqn"],
                }
            )
    return classifications


def contextual_metadata_classifications(
    unit, record, workspace, selected_frameworks
):
    """Attribute supported definition metadata to its framework purpose.

    ``@Retention``/``@Target`` and Spring ``@AliasFor`` are interesting only
    when they belong to a validated source-defined route annotation; identical
    metadata elsewhere remains outside Noir's framework audit inventory.

    Example call:
        ``contextual_metadata_classifications(items_unit, alias_for_occurrence,
        workspace, {"spring"})`` classifies ``@AliasFor`` as Spring metadata
        when it belongs to a supported ``app.ApiRoute`` definition, otherwise
        returns ``[]``.
    """

    definition = source_definition_for_annotation_metadata(
        unit, record, workspace
    )
    if definition is None:
        return []

    classifications = []
    occurrence_key = tree_node_key(record["node"])
    is_definition_meta_annotation = any(
        tree_node_key(meta_record["node"]) == occurrence_key
        for meta_record in definition["meta_annotations"]
    )
    is_definition_element_annotation = any(
        tree_node_key(element_annotation["node"]) == occurrence_key
        for elements in definition["elements"].values()
        for element in elements
        for element_annotation in element["annotations"]
    )
    java_metadata = (
        resolve_known_annotation(
            unit,
            record["name_node"],
            {"Retention", "Target"},
            ("java.lang.annotation",),
        )
        if is_definition_meta_annotation
        else None
    )
    spring_alias = (
        resolve_known_annotation(
            unit,
            record["name_node"],
            {"AliasFor"},
            (SPRING_ALIAS_FOR_PACKAGE,),
        )
        if is_definition_element_annotation
        else None
    )
    if (
        "spring" in selected_frameworks
        and (java_metadata is not None or spring_alias is not None)
        and spring_composed_definition_is_supported(definition, workspace)
    ):
        resolved = java_metadata or spring_alias
        classifications.append(
            {
                "framework": "spring",
                "resolved": f"{resolved['namespace']}.{resolved['name']}",
            }
        )
    if (
        "jaxrx" in selected_frameworks
        and java_metadata is not None
        and len(workspace["jax_rs_custom_designators"].get(definition["fqn"], [])) == 1
    ):
        classifications.append(
            {
                "framework": "jaxrx",
                "resolved": (
                    f"{java_metadata['namespace']}.{java_metadata['name']}"
                ),
            }
        )
    return classifications


def annotation_framework_classifications(
    unit, record, workspace, selected_frameworks
):
    """Merge all proven framework meanings for one annotation occurrence.

    Example call:
        ``annotation_framework_classifications(items_unit,
        get_mapping_occurrence, workspace, {"spring", "jaxrx"})`` returns the
        distinct sorted classifications, such as the single exact Spring
        ``GetMapping`` identity, after all three recognition lanes run.
    """

    classifications = [
        *registered_annotation_classifications(
            unit, record, workspace, selected_frameworks
        ),
        *source_defined_annotation_classifications(
            unit, record, workspace, selected_frameworks
        ),
        *contextual_metadata_classifications(
            unit, record, workspace, selected_frameworks
        ),
    ]
    unique = {
        (classification["framework"], classification["resolved"]): classification
        for classification in classifications
    }
    return [unique[key] for key in sorted(unique)]


def _annotation_source_extract_from_rows(
    lines, start_row, end_row, following_nonempty=10
):
    """Return annotation source rows plus bounded following application context.

    Example call:
        ``_annotation_source_extract_from_rows([
        '@GetMapping("/items")', 'List<Item> list() {', '}', ''], 0, 0, 2)``
        returns line dictionaries for the annotation and the next two non-empty
        handler lines, using one-based display numbers.
    """

    extract = [
        {"line": row + 1, "source": lines[row]}
        for row in range(start_row, min(end_row + 1, len(lines)))
    ]
    remaining = following_nonempty
    for row in range(end_row + 1, len(lines)):
        if not lines[row].strip():
            continue
        extract.append({"line": row + 1, "source": lines[row]})
        remaining -= 1
        if remaining == 0:
            break
    return extract


def annotation_source_extract(lines, annotation_node, following_nonempty=10):
    """Extract broad-audit context using Tree-sitter point rows.

    This syntax-facing view follows Tree-sitter rows and intentionally remains
    separate from byte-aligned final-trigger extraction.

    Example call:
        ``annotation_source_extract(source_lines, get_mapping_node,
        following_nonempty=2)`` returns the physical ``@GetMapping`` row and up
        to two following non-empty rows for the broad annotation audit.
    """

    start_row = annotation_node.start_point.row
    end_row = annotation_node.end_point.row
    if (
        annotation_node.end_point.column == 0
        and end_row > start_row
    ):
        end_row -= 1
    return _annotation_source_extract_from_rows(
        lines, start_row, end_row, following_nonempty
    )


def java_physical_source_lines(source):
    """Return Java physical lines and their exact byte starts.

    Tree-sitter point rows advance on LF, while Java sources can also contain
    CRLF or CR terminators and Python ``str.splitlines()`` additionally treats
    characters such as form-feed as boundaries. The absent report joins by
    byte spans, so it uses an explicit LF/CRLF/CR line model without changing
    the broad annotation inventory's row semantics.

    Example call:
        ``java_physical_source_lines(b'@GET\r\nItem get() {}\r\n')`` returns
        ``{"starts": (0, 6, 21), "lines": ("@GET", "Item get() {}", "")}``,
        preserving exact byte offsets across CRLF terminators.
    """

    if not isinstance(source, bytes):
        source = str(source).encode("utf8")
    starts = []
    lines = []
    line_start = 0
    cursor = 0
    while cursor < len(source):
        byte = source[cursor]
        if byte not in (10, 13):
            cursor += 1
            continue
        starts.append(line_start)
        lines.append(source[line_start:cursor].decode("utf8"))
        if byte == 13 and cursor + 1 < len(source) and source[cursor + 1] == 10:
            cursor += 2
        else:
            cursor += 1
        line_start = cursor
    starts.append(line_start)
    lines.append(source[line_start:].decode("utf8"))
    return {"starts": tuple(starts), "lines": tuple(lines)}


def annotation_physical_source_extract(
    line_model, annotation_node, following_nonempty=10
):
    """Extract final-trigger context from byte-aligned Java physical lines.

    Exact byte alignment lets represented-target reporting survive CRLF and CR
    files without conflating Python's broader notion of a line boundary.

    Example call:
        ``annotation_physical_source_extract(line_model, get_node,
        following_nonempty=2)`` uses the conceptual annotation node's byte span
        to return its physical line plus two following non-empty handler lines.
    """

    starts = line_model.get("starts", ())
    lines = line_model.get("lines", ())
    if not starts or len(starts) != len(lines) or annotation_node is None:
        return []
    try:
        start_byte = annotation_node.start_byte
        end_byte = annotation_node.end_byte
    except (AttributeError, TypeError):
        return []
    if start_byte < 0 or end_byte <= start_byte:
        return []
    start_row = max(0, bisect_right(starts, start_byte) - 1)
    end_row = max(start_row, bisect_right(starts, end_byte - 1) - 1)
    end_row = min(end_row, len(lines) - 1)
    return _annotation_source_extract_from_rows(
        lines, start_row, end_row, following_nonempty
    )


def _record_component_name_node(component_node):
    """Read the application name from an ordinary or varargs record component.

    Example call:
        ``_record_component_name_node(<node for ``String id``>)`` returns the
        parser node spelling ``id``; ``String... tags`` is handled through its
        variable-declarator child.
    """

    name_node = child_by_field(component_node, "name")
    if name_node is not None:
        return name_node
    for child in component_node.named_children:
        if child.type == "variable_declarator":
            name_node = child_by_field(child, "name")
            if name_node is not None:
                return name_node
    return None


def discover_applied_annotation_target(unit, record):
    """Return the exact declaration directly carrying an annotation.

    Only named methods, record components, and named types can become stable
    represented-target IDs.  Anonymous/enum-constant bodies and recovered
    shapes fail closed instead of borrowing the next lexical type owner.

    Example call:
        ``discover_applied_annotation_target(items_unit,
        get_mapping_occurrence)`` returns a mapping such as
        ``{"kind": "method", "node": list_method_node,
        "owner_info": items_controller_info, ...}`` for ``@GetMapping`` directly
        attached to ``ItemsController.list``.
    """

    annotation_node = record.get("node") if isinstance(record, dict) else None
    modifiers = getattr(annotation_node, "parent", None)
    if modifiers is None or modifiers.type != "modifiers":
        return None
    declaration = getattr(modifiers, "parent", None)
    if declaration is None:
        return None

    if declaration.type == "method_declaration":
        owner_node = None
        ancestor = getattr(declaration, "parent", None)
        while ancestor is not None:
            if ancestor.type in {
                "class_declaration",
                "interface_declaration",
                "record_declaration",
                "enum_declaration",
                "annotation_type_declaration",
            }:
                owner_node = ancestor
                break
            if ancestor.type in {"object_creation_expression", "enum_constant"}:
                # Anonymous-class and enum-constant bodies do not belong to
                # the next named type in the lexical ancestor chain.
                return None
            ancestor = getattr(ancestor, "parent", None)
        owner_info = (
            unit.get("type_infos", {}).get(tree_node_key(owner_node))
            if owner_node is not None
            else None
        )
        name_node = child_by_field(declaration, "name")
        parameters_node = child_by_field(declaration, "parameters")
        if None in (owner_node, owner_info, name_node, parameters_node):
            return None
        return {
            "kind": "method",
            "node": declaration,
            "owner_node": owner_node,
            "owner_info": owner_info,
            "name_node": name_node,
            "parameters_node": parameters_node,
        }

    if declaration.type in {"formal_parameter", "spread_parameter"}:
        parameters_node = getattr(declaration, "parent", None)
        owner_node = getattr(parameters_node, "parent", None)
        if (
            parameters_node is None
            or parameters_node.type != "formal_parameters"
            or owner_node is None
            or owner_node.type != "record_declaration"
        ):
            return None
        owner_info = unit.get("type_infos", {}).get(tree_node_key(owner_node))
        name_node = _record_component_name_node(declaration)
        if owner_info is None or name_node is None:
            return None
        return {
            "kind": "record-component",
            "node": declaration,
            "owner_node": owner_node,
            "owner_info": owner_info,
            "name_node": name_node,
        }

    if declaration.type in {
        "class_declaration",
        "interface_declaration",
        "record_declaration",
        "enum_declaration",
        "annotation_type_declaration",
    }:
        owner_info = unit.get("type_infos", {}).get(tree_node_key(declaration))
        if owner_info is None:
            return None
        return {
            "kind": "type",
            "node": declaration,
            "owner_node": declaration,
            "owner_info": owner_info,
            "name_node": child_by_field(declaration, "name"),
        }
    return None


def normalize_applied_to_parameters(source, parameters_node):
    """Create a stable one-line handler-input spelling for a target label.

    Example call:
        ``normalize_applied_to_parameters(source_bytes,
        <node for ``(String filter,\n int limit)``>)`` returns
        ``"String filter, int limit"``; a missing parameter node returns ``""``.
    """

    if parameters_node is None:
        return ""
    value = node_text(source, parameters_node)
    if value.startswith("(") and value.endswith(")"):
        value = value[1:-1]
    return re.sub(r"[ \t\f\r\n]+", " ", value).strip(" ")


def applied_annotation_target_label(unit, target):
    """Render a readable declaration label beside its exact source identity.

    Example call:
        ``applied_annotation_target_label(items_unit,
        {"kind": "method", "owner_info": items_controller_info,
        "name_node": list_name_node, "parameters_node": list_parameters_node})``
        returns ``"method ItemsController.list(String filter)"``.
    """

    if not isinstance(target, dict):
        return None
    owner_info = target.get("owner_info")
    owner_name = owner_info.get("display_name") if owner_info else None
    if not owner_name:
        return None
    if target.get("kind") == "method":
        method_name = node_text(unit["source"], target["name_node"])
        parameters = normalize_applied_to_parameters(
            unit["source"], target["parameters_node"]
        )
        return f"method {owner_name}.{method_name}({parameters})"
    if target.get("kind") == "record-component":
        component_name = node_text(unit["source"], target["name_node"])
        return f"record component {owner_name}.{component_name}"
    if target.get("kind") == "type":
        return f"type {owner_name}"
    return None


def final_trigger_placement_supported(placement, target):
    """Check whether an endpoint trigger is attached to a supported declaration.

    Example call:
        ``final_trigger_placement_supported("spring-http-exchange",
        api_method_target)`` returns ``True`` when the conceptual target is a
        method owned by an interface, and ``False`` for a class method.
    """

    kind = target.get("kind") if isinstance(target, dict) else None
    owner_node = target.get("owner_node") if isinstance(target, dict) else None
    owner_kind = getattr(owner_node, "type", None)
    if placement in {"spring-mvc", "jax-rs-designator"}:
        return (
            kind == "method"
            and owner_kind
            in {"class_declaration", "interface_declaration", "record_declaration"}
        ) or kind == "record-component"
    if placement == "spring-http-exchange":
        return kind == "method" and owner_kind == "interface_declaration"
    if placement == "spring-message":
        return kind == "method" and owner_kind in {
            "class_declaration",
            "record_declaration",
        }
    if placement == "jax-websocket":
        return kind == "type" and owner_kind in {
            "class_declaration",
            "record_declaration",
        }
    return False


def direct_final_trigger_classifications(
    unit, record, target, workspace, selected_frameworks
):
    """Classify built-in endpoint triggers at analyzer-supported placements.

    Example call:
        ``direct_final_trigger_classifications(items_unit,
        get_mapping_occurrence, list_method_target, workspace, {"spring"})``
        returns the exact Spring ``GetMapping`` identity and its verb-specific
        evidence family when the method placement is supported.
    """

    classifications = []
    for framework in selected_frameworks:
        # As with the broad inventory, a family without trigger rules has an
        # empty classification lane until it proves real annotation semantics.
        for group in FINAL_TRIGGER_ANNOTATION_REGISTRY.get(framework, ()):
            if not final_trigger_placement_supported(group["placement"], target):
                continue
            resolved = resolve_known_annotation(
                unit,
                record["name_node"],
                group["names"],
                group["packages"],
            )
            if resolved is None:
                continue
            resolved_fqn = f"{resolved['namespace']}.{resolved['name']}"
            if workspace.get("type_declarations", {}).get(resolved_fqn):
                continue
            classifications.append(
                {
                    "framework": framework,
                    "resolved": resolved_fqn,
                    "family": group["family_by_name"][resolved["name"]],
                }
            )
    return classifications


def source_defined_final_trigger_classifications(
    unit, record, target, workspace, selected_frameworks
):
    """Classify source-defined composed or request-designator endpoint triggers.

    Example call:
        ``source_defined_final_trigger_classifications(items_unit,
        api_route_occurrence, list_method_target, workspace, {"spring"})``
        returns ``{"framework": "spring", "resolved": "app.ApiRoute",
        "family": "spring-composed-mvc"}`` when its definition and placement
        are both proven.
    """

    classifications = []
    owner_info = target.get("owner_info") if isinstance(target, dict) else None
    owner_name = owner_info.get("display_name", "") if owner_info else ""

    if (
        "spring" in selected_frameworks
        and final_trigger_placement_supported("spring-mvc", target)
    ):
        resolved = source_annotation_definition(
            unit, record["name_node"], workspace, owner_name
        )
        component_applicable = (
            target["kind"] != "record-component"
            or source_annotation_is_method_applicable(
                unit, record, workspace, owner_name
            )
        )
        if (
            component_applicable
            and resolved["status"] == "resolved"
            and spring_composed_definition_is_supported(
                resolved["definition"], workspace
            )
        ):
            classifications.append(
                {
                    "framework": "spring",
                    "resolved": resolved["definition"]["fqn"],
                    "family": "spring-composed-mvc",
                }
            )

    if (
        "jaxrx" in selected_frameworks
        and final_trigger_placement_supported("jax-rs-designator", target)
    ):
        resolved = resolve_custom_designator(
            unit, record["name_node"], workspace, owner_name
        )
        component_applicable = (
            target["kind"] != "record-component"
            or source_annotation_use_is_method_applicable(
                unit, record, workspace, owner_name
            )
        )
        if component_applicable and resolved["status"] == "resolved":
            classifications.append(
                {
                    "framework": "jaxrx",
                    "resolved": resolved["record"]["fqn"],
                    "family": METHOD_ANNOTATION_FAMILY_JAX_RS,
                }
            )
    return classifications


def final_trigger_classifications(
    unit, record, target, workspace, selected_frameworks
):
    """Merge all proven trigger meanings by framework and annotation identity.

    Example call:
        ``final_trigger_classifications(items_unit, api_route_occurrence,
        list_method_target, workspace, {"spring"})`` returns one deterministic
        classification for ``app.ApiRoute`` even if recognition lanes repeat it.
    """

    classifications = [
        *direct_final_trigger_classifications(
            unit, record, target, workspace, selected_frameworks
        ),
        *source_defined_final_trigger_classifications(
            unit, record, target, workspace, selected_frameworks
        ),
    ]
    unique = {}
    for classification in classifications:
        key = (classification["framework"], classification["resolved"])
        unique[key] = classification
    return [unique[key] for key in sorted(unique)]


def build_final_trigger_inventory(workspace, analysis_root, selected_frameworks):
    """Build the narrow pre-analysis inventory used by the absent report.

    Each candidate carries a byte span/source extract, represented-target ID,
    and evidence family. Ambiguous framework identities and unsupported
    placements are omitted so later subtraction never guesses from names or
    paths.

    Example call:
        ``build_final_trigger_inventory(workspace, "/workspace/shop",
        {"spring"})`` returns per-file Spring sections whose annotations include
        values such as ``name="GetMapping"``, ``applied_to="method
        ItemsController.list()"``, an exact ``SourceTarget``, line, byte span,
        evidence family, and source extract.
    """

    if isinstance(selected_frameworks, (set, frozenset)):
        # Preserve compatibility for older direct callers that supplied an
        # unordered set; pipeline callers provide the authoritative tuple.
        registered = tuple(FINAL_TRIGGER_ANNOTATION_REGISTRY)
        framework_order = tuple(
            framework for framework in registered if framework in selected_frameworks
        ) + tuple(sorted(set(selected_frameworks) - set(registered)))
    else:
        framework_order = tuple(selected_frameworks)
    inventory = []
    for source_path in sorted(
        workspace.get("compilation_units", {}),
        key=lambda path: relative_source_path(path, analysis_root),
    ):
        unit = workspace["compilation_units"][source_path]
        source_line_model = java_physical_source_lines(unit["source"])
        by_framework = {framework: {} for framework in framework_order}
        for record in unit["annotation_occurrences"]:
            target = discover_applied_annotation_target(unit, record)
            if target is None:
                continue
            source_target = source_target_from_node(
                source_path, target["kind"], target["node"]
            )
            applied_to = applied_annotation_target_label(unit, target)
            if source_target is None or applied_to is None:
                continue
            classifications = final_trigger_classifications(
                unit, record, target, workspace, selected_frameworks
            )
            by_selected_framework = {}
            for classification in classifications:
                by_selected_framework.setdefault(
                    classification["framework"], []
                ).append(classification)
            for framework, framework_classifications in by_selected_framework.items():
                resolved_identities = {
                    classification["resolved"]
                    for classification in framework_classifications
                }
                # One occurrence cannot safely represent two identities within
                # the same selected framework, even if both look trigger-like.
                if len(resolved_identities) != 1:
                    continue
                classification = min(
                    framework_classifications,
                    key=lambda item: (item["resolved"], item["family"]),
                )
                occurrence_key = tree_node_key(record["node"])
                spelling = node_text(unit["source"], record["name_node"]).strip()
                extract = annotation_physical_source_extract(
                    source_line_model, record["node"]
                )
                if not extract:
                    continue
                candidate = {
                    "name": spelling.rsplit(".", 1)[-1],
                    "resolved": classification["resolved"],
                    "family": classification["family"],
                    "target": source_target,
                    "applied_to": applied_to,
                    "line": extract[0]["line"],
                    "start_byte": record["node"].start_byte,
                    "end_byte": record["node"].end_byte,
                    "extract": extract,
                }
                by_framework[framework][occurrence_key] = candidate
        inventory.append(
            {
                "file": relative_source_path(source_path, analysis_root),
                "frameworks": [
                    {
                        "framework": framework,
                        "annotations": [
                            by_framework[framework][key]
                            for key in sorted(by_framework[framework])
                        ],
                    }
                    for framework in framework_order
                ],
            }
        )
    return inventory


def build_annotation_audit_inventory(workspace, analysis_root, selected_frameworks):
    """Build the broad, endpoint-independent annotation audit inventory.

    This inventory records supported framework occurrences even when a later
    analyzer rejects or never considers them as endpoint triggers.  Ordering is
    normalized here so report rendering remains a presentation-only step.

    Example call:
        ``build_annotation_audit_inventory(workspace, "/workspace/shop",
        {"spring", "jaxrx"})`` returns per-file records containing every proven
        relevant annotation occurrence, for example ``GetMapping`` at line 42
        with its Spring identity and bounded source extract.
    """

    inventory = []
    for source_path in sorted(
        workspace["compilation_units"],
        key=lambda path: relative_source_path(path, analysis_root),
    ):
        unit = workspace["compilation_units"][source_path]
        source_lines = unit["source"].decode("utf8").splitlines()
        occurrences = {}
        for record in unit["annotation_occurrences"]:
            classifications = annotation_framework_classifications(
                unit, record, workspace, selected_frameworks
            )
            if not classifications:
                continue
            key = tree_node_key(record["node"])
            spelling = node_text(unit["source"], record["name_node"]).strip()
            occurrences[key] = {
                "name": spelling.rsplit(".", 1)[-1],
                "line": record["node"].start_point.row + 1,
                "frameworks": classifications,
                "extract": annotation_source_extract(
                    source_lines, record["node"]
                ),
            }
        inventory.append(
            {
                "file": relative_source_path(source_path, analysis_root),
                "annotations": [occurrences[key] for key in sorted(occurrences)],
            }
        )
    return inventory



__all__ = [
    "FINAL_TRIGGER_ANNOTATION_REGISTRY",
    "SUPPORTED_ANNOTATION_REGISTRY",
    "annotation_framework_classifications",
    "annotation_owner_name",
    "annotation_physical_source_extract",
    "annotation_source_extract",
    "applied_annotation_target_label",
    "build_annotation_audit_inventory",
    "build_final_trigger_inventory",
    "contextual_metadata_classifications",
    "direct_final_trigger_classifications",
    "discover_applied_annotation_target",
    "final_trigger_classifications",
    "final_trigger_placement_supported",
    "java_physical_source_lines",
    "normalize_applied_to_parameters",
    "registered_annotation_classifications",
    "source_defined_annotation_classifications",
    "source_defined_final_trigger_classifications",
    "source_definition_for_annotation_metadata",
]
