"""Framework-neutral Java syntax and compilation-unit construction.

This module owns the smallest useful front-end vocabulary: source text, tree
navigation, query-capture shaping, imports and lexical types.  It deliberately
knows nothing about Spring, JAX-RS, endpoint facts, diagnostics, or orchestration.
Parser/version policy stays at the application boundary and is
supplied here through an explicit query matcher.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

import re


# This shared bound applies both while decoding a literal and while composing
# workspace constants, so no analyzer can obtain an oversized route value.
JAVA_CONSTANT_MAX_LENGTH = 8192


def query_matches(query, root, cursor_factory, lifetime_owners=None):
    """Run one compiled Java query while keeping its captured evidence alive.

    ``query`` describes application constructs to find (for example annotated
    methods), ``root`` is one parsed source file, and ``cursor_factory`` creates
    the version-specific matcher.  ``lifetime_owners`` retains parser objects
    whose nodes are reused by later endpoint passes.

    Example call:
        ``query_matches(method_query, tree.root_node, make_cursor, owners)``
        returns matches for the source methods and appends ``(cursor, matches)``
        to ``owners``.
    """

    cursor = cursor_factory(query)
    matches = cursor.matches(root)
    if lifetime_owners is not None:
        lifetime_owners.append((cursor, matches))
    return matches


def node_text(source: bytes, node) -> str:
    """Read the original Java spelling represented by one syntax node.

    Example call:
        With ``source=b'class Items {}'`` and the declaration-name node,
        ``node_text(source, node)`` returns ``"Items"``.
    """

    return source[node.start_byte : node.end_byte].decode("utf8")


def find_first(node, type_name: str):
    """Return the first direct child having one Java syntax kind.

    ``type_name`` is a parser construct such as ``"modifiers"``; grandchildren
    do not count because callers need evidence attached to this declaration.

    Example call:
        ``find_first(method_node, "modifiers")`` returns the node containing
        ``public static`` for ``public static void routes()``.
    """

    for child in node.children:
        if child.type == type_name:
            return child
    return None


def child_by_field(node, field_name: str):
    """Read a child's application role and fail closed on parser recovery.

    Field names identify roles such as an invocation's ``"object"`` or a
    method's ``"body"`` instead of depending on punctuation positions.

    Example call:
        ``child_by_field(call_node, "arguments")`` returns the argument-list
        node for ``router.get("/items")``; malformed recovered syntax yields
        ``None`` rather than endpoint evidence.
    """

    try:
        return node.child_by_field_name(field_name)
    except Exception:
        return None


def parameter_list_source_text(source: bytes, parameters_node) -> str:
    """Preserve the human-readable parameter declaration of an endpoint.

    Parentheses are removed, while annotations, types, names, and source
    spacing inside the list remain available as endpoint provenance.

    Example call:
        For ``list(@QueryParam("q") String query, int page)``,
        ``parameter_list_source_text(source, parameters_node)`` returns
        ``'@QueryParam("q") String query, int page'``.
    """

    if not parameters_node:
        return ""

    parameters_text = node_text(source, parameters_node)
    if parameters_text.startswith("(") and parameters_text.endswith(")"):
        parameters_text = parameters_text[1:-1]

    return parameters_text.strip()


def get_annotation_arguments(annotation_node):
    """Separate positional and named values from one annotation occurrence.

    This helper shapes syntax only. Framework decoders decide which keys and
    cardinalities have meaning for their annotation family.

    Example call:
        For ``@GetMapping(path="/items", produces="application/json")``,
        ``get_annotation_arguments(annotation_node)`` returns no positional
        nodes and a mapping whose ``"path"`` and ``"produces"`` values are
        the corresponding Java expression nodes.  For ``@Path("/items")`` the
        literal node is in the positional list.
    """

    positional_values = []
    named_values = {}
    arguments = child_by_field(annotation_node, "arguments")

    if not arguments:
        return positional_values, named_values

    for child in arguments.named_children:
        # Tree-sitter exposes comments as named children. They are trivia, not
        # additional annotation values (for example @GetMapping("/x" /*...*/)).
        if child.type in {"line_comment", "block_comment"}:
            continue
        if child.type == "element_value_pair":
            key_node = child_by_field(child, "key")
            value_node = child_by_field(child, "value")
            if key_node and value_node:
                key = key_node.text.decode("utf8")
                named_values[key] = value_node
        else:
            positional_values.append(child)

    return positional_values, named_values


def first_capture(captures, name):
    """Return the first captured occurrence playing one query-defined role.

    Query labels have application meanings such as ``"method.name"`` or
    ``"annotation.node"``.  A missing role means the match is incomplete.

    Example call:
        If ``captures["method.name"]`` contains the node spelling ``list``,
        ``first_capture(captures, "method.name")`` returns that node; an absent
        label returns ``None``.
    """

    nodes = captures.get(name, [])
    return nodes[0] if nodes else None


def tree_node_key(node):
    """Return the stable within-file identity of one syntax occurrence.

    The pair is meaningful only with the compilation unit that owns the node;
    it lets indexes join multiple query matches for the same declaration.

    Example call:
        A method node spanning bytes 40 through 91 gives
        ``tree_node_key(method_node) == (40, 91)``.
    """

    return (node.start_byte, node.end_byte)


def nearest_enclosing_type(node):
    """Find the nearest class-like declaration that lexically owns a use.

    "Lexically owns" means the source declaration surrounding the occurrence,
    not a runtime receiver or inherited declaring class.

    Example call:
        For a ``@GetMapping`` node inside ``ItemsController.list``,
        ``nearest_enclosing_type(annotation_node)`` returns the declaration node
        for ``ItemsController``.
    """

    current = getattr(node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return current
        current = getattr(current, "parent", None)
    return None


def type_is_abstract(source, type_node):
    """Report whether a source class is explicitly declared ``abstract``.

    Interfaces and merely non-instantiated classes are not reported as
    explicitly abstract by this source-level fact.

    Example call:
        ``type_is_abstract(source, type_node)`` is ``True`` for
        ``abstract class BaseController`` and ``False`` for ``class Items``.
    """

    modifiers = find_first(type_node, "modifiers")
    return bool(
        type_node.type == "class_declaration"
        and modifiers
        and any(child.type == "abstract" for child in modifiers.children)
    )


def type_is_workspace_visible(type_node):
    """Decide whether a named type can receive a cross-file source identity.

    Member types remain workspace-visible, while declarations inside methods,
    lambdas, constructors, blocks, and initializers are lexical shadows only.

    Example call:
        ``type_is_workspace_visible(api_type_node)`` returns ``True`` for the
        ``Api`` in ``class Outer { interface Api {} }`` because another source
        can name ``Outer.Api``.  It returns ``False`` for a local ``class Api
        {}`` declared inside a method.
    """

    current = getattr(type_node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return True
        if current.type in {
            "method_declaration",
            "constructor_declaration",
            "compact_constructor_declaration",
            "lambda_expression",
            "block",
            "constructor_body",
            "static_initializer",
        }:
            return False
        current = getattr(current, "parent", None)
    return True


def build_type_infos(source, type_matches):
    """Build source-ordered lexical identities for every named type in a unit.

    Outer declarations are processed first so nested display names and
    workspace visibility are inherited from a known lexical owner.

    Each returned record describes one application type:
    ``node`` is its declaration evidence; ``simple_name`` is its local name;
    ``display_name`` includes lexical owners; ``outer_key`` links a member type
    to its owner; ``abstract`` records explicit abstractness;
    ``workspace_visible`` says whether other files may name it; and ``mapping``
    is reserved for a later framework mapping attached to the type.

    Example call:
        For ``class Outer { interface Api {} }``,
        ``build_type_infos(source, matches)`` includes a record like
        ``{"simple_name": "Api", "display_name": "Outer.Api",
        "outer_key": outer_range, "abstract": False,
        "workspace_visible": True, "mapping": None, "node": api_node}``.
    """

    infos = {}
    ordered = []
    for _pattern_index, captures in type_matches:
        type_node = first_capture(captures, "type.node")
        name_node = first_capture(captures, "type.name")
        if type_node is None or name_node is None:
            continue
        ordered.append((type_node.start_byte, type_node, node_text(source, name_node)))

    for _start_byte, type_node, simple_name in sorted(ordered):
        outer_node = nearest_enclosing_type(type_node)
        outer_key = tree_node_key(outer_node) if outer_node is not None else None
        outer_info = infos.get(outer_key)
        display_name = (
            f"{outer_info['display_name']}.{simple_name}"
            if outer_info is not None
            else simple_name
        )
        key = tree_node_key(type_node)
        infos[key] = {
            "node": type_node,
            "simple_name": simple_name,
            "display_name": display_name,
            "outer_key": outer_key if outer_info is not None else None,
            "abstract": type_is_abstract(source, type_node),
            "workspace_visible": type_is_workspace_visible(type_node)
            and (outer_info is None or outer_info["workspace_visible"]),
            "mapping": None,
        }
    return infos


def visible_local_type_infos(unit, context_node=None):
    """Return source types whose short names take priority at one use site.

    A lexical shadow is a locally declared type that makes a same-spelled
    imported/library type unsafe to assume.  With no context, only globally
    visible top-level types are considered.

    Example call:
        Inside ``class Controller { class Path {} }``,
        ``visible_local_type_infos(unit, annotation_node)`` includes the record
        for ``Controller.Path``, so ``Path`` cannot be assumed to mean JAX-RS.
    """
    infos = unit.get("type_infos", {})
    visible_keys = {
        key
        for key, info in infos.items()
        if info["outer_key"] is None and info["workspace_visible"]
    }
    if context_node is None:
        return [infos[key] for key in visible_keys]

    current = nearest_enclosing_type(context_node)
    scope_keys = set()
    while current is not None:
        key = tree_node_key(current)
        info = infos.get(key)
        if info is None:
            break
        scope_keys.add(key)
        visible_keys.add(key)
        current = (
            infos[info["outer_key"]]["node"]
            if info["outer_key"] in infos
            else None
        )
    visible_keys.update(
        key
        for key, info in infos.items()
        if info["workspace_visible"] and info["outer_key"] in scope_keys
    )
    return [infos[key] for key in visible_keys]


def visible_local_type_names(unit, context_node=None):
    """Return short type names that block library-name shortcuts here.

    Example call:
        If a surrounding source type declares ``class RequestMapping {}``,
        ``visible_local_type_names(unit, use_node)`` contains
        ``"RequestMapping"``.
    """

    return {
        info["simple_name"]
        for info in visible_local_type_infos(unit, context_node)
    }


def parse_java_imports(source, import_matches):
    """Shape imports into exact/wildcard and static/non-static lookup tiers.

    Conflicting exact imports are stored as ``""``.  That marker deliberately
    blocks fallback to lower-priority tiers during later name resolution.

    The result's ``exact`` and ``wildcards`` entries describe imported types;
    ``static_exact`` and ``static_wildcards`` describe imported members or
    member owners.  Values are fully qualified Java identities.

    Example call:
        For ``import java.util.List; import static api.Paths.ROOT;``,
        ``parse_java_imports(source, matches)`` returns an ``exact`` entry
        ``{"List": "java.util.List"}`` and a ``static_exact`` entry
        ``{"ROOT": "api.Paths.ROOT"}``.
    """

    exact = {}
    wildcards = set()
    static_exact = {}
    static_wildcards = set()
    for _pattern_index, captures in import_matches:
        import_node = first_capture(captures, "import.node")
        if import_node is None:
            continue
        declaration = node_text(source, import_node).strip()
        match = re.fullmatch(r"import\s+(static\s+)?([^;]+)\s*;", declaration)
        if not match:
            continue
        target = match.group(2).strip()
        if match.group(1):
            if target.endswith(".*"):
                static_wildcards.add(target[:-2])
                continue
            simple_name = target.rsplit(".", 1)[-1]
            previous = static_exact.get(simple_name)
            static_exact[simple_name] = (
                target if previous in (None, target) else ""
            )
            continue
        if target.endswith(".*"):
            wildcards.add(target[:-2])
            continue
        simple_name = target.rsplit(".", 1)[-1]
        previous = exact.get(simple_name)
        exact[simple_name] = target if previous in (None, target) else ""
    return {
        "exact": exact,
        "wildcards": wildcards,
        "static_exact": static_exact,
        "static_wildcards": static_wildcards,
    }


def declared_annotation_names(source, declaration_matches):
    """Return locally declared annotation names that can shadow libraries.

    Example call:
        For ``@interface Path {}``,
        ``declared_annotation_names(source, matches)`` returns ``{"Path"}``,
        preventing that spelling from being treated automatically as JAX-RS.
    """

    names = set()
    for _pattern_index, captures in declaration_matches:
        name_node = first_capture(captures, "annotation.declaration.name")
        if name_node is not None:
            names.add(node_text(source, name_node))
    return names


def decode_java_string_literal(literal, max_length=JAVA_CONSTANT_MAX_LENGTH):
    """Decode the bounded escape forms valid in an ordinary Java string.

    Text blocks, malformed escapes, invalid surrogate pairs, and values beyond
    the shared bound remain unresolved rather than becoming route evidence.

    Example call:
        ``decode_java_string_literal('"/api\\u002fitems"')`` returns
        ``"/api/items"``.  ``decode_java_string_literal('"unterminated')`` and
        a value longer than ``max_length`` return ``None``.
    """
    if len(literal) < 2 or not (literal.startswith('"') and literal.endswith('"')):
        return None

    result = []
    index = 1
    end = len(literal) - 1
    simple_escapes = {
        "b": "\b",
        "t": "\t",
        "n": "\n",
        "f": "\f",
        "r": "\r",
        "s": " ",
        '"': '"',
        "'": "'",
        "\\": "\\",
    }
    while index < end:
        char = literal[index]
        if char != "\\":
            result.append(char)
            index += 1
            continue

        index += 1
        if index >= end:
            return None
        escaped = literal[index]
        if escaped in simple_escapes:
            result.append(simple_escapes[escaped])
            index += 1
            continue
        if escaped == "u":
            while index < end and literal[index] == "u":
                index += 1
            digits = literal[index:index + 4]
            if len(digits) != 4 or not re.fullmatch(r"[0-9a-fA-F]{4}", digits):
                return None
            result.append(chr(int(digits, 16)))
            index += 4
            continue
        if escaped in "01234567":
            max_digits = 3 if escaped in "0123" else 2
            digits = escaped
            index += 1
            while index < end and len(digits) < max_digits and literal[index] in "01234567":
                digits += literal[index]
                index += 1
            result.append(chr(int(digits, 8)))
            continue
        return None

    try:
        value = (
            "".join(result)
            .encode("utf-16-le", errors="surrogatepass")
            .decode("utf-16-le")
        )
    except UnicodeDecodeError:
        return None
    return value if len(value) <= max_length else None


def binary_expression_is_addition(source, node, left, right):
    """Prove that a Java binary expression joins route-value fragments.

    ``node`` is the whole expression and ``left``/``right`` are its operand
    nodes.  The source-byte fallback handles parser versions that do not expose
    an explicit operator field.

    Example call:
        For ``ROOT + "/items"``,
        ``binary_expression_is_addition(source, expression, root, suffix)`` is
        ``True``; for ``count * 2`` it is ``False``.
    """

    operator = child_by_field(node, "operator")
    if operator is not None:
        return node_text(source, operator).strip() == "+"
    return any(child.type == "+" for child in node.children) or (
        source[left.end_byte:right.start_byte].decode("utf8").strip() == "+"
    )


def annotation_value_nodes(value_node):
    """Normalize one annotation value into the ordered values it contributes.

    A scalar contributes one value; a Java annotation array contributes each
    non-comment element.  Framework logic can therefore decode both spellings
    with one loop.

    Example call:
        For ``@RequestMapping(method={GET, POST})``, passing the array node to
        ``annotation_value_nodes(array_node)`` returns the ``GET`` and ``POST``
        nodes.  ``annotation_value_nodes(get_node)`` returns ``[get_node]``.
    """

    if value_node.type == "element_value_array_initializer":
        return [
            child
            for child in value_node.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
    return [value_node]


def unwrap_parenthesized_node(node):
    """Remove harmless parentheses around one Java value expression.

    Example call:
        For ``((ElementType.METHOD))``,
        ``unwrap_parenthesized_node(outer_node)`` returns the scoped-identifier
        node for ``ElementType.METHOD``.  A recovered pair containing multiple
        named children returns ``None``.
    """

    current = node
    while current is not None and current.type == "parenthesized_expression":
        children = current.named_children
        if len(children) != 1:
            return None
        current = children[0]
    return current


def owner_name_for_node(unit, context_node):
    """Return the source type name from which member lookup starts.

    The result is package-relative and includes enclosing member types; it is
    not a fully qualified name.

    Example call:
        For a constant reference inside ``class Outer { class Routes {...} }``,
        ``owner_name_for_node(unit, reference_node)`` returns
        ``"Outer.Routes"``.  File-level context returns ``None``.
    """

    owner_node = nearest_enclosing_type(context_node) if context_node is not None else None
    owner_info = (
        unit.get("type_infos", {}).get(tree_node_key(owner_node))
        if owner_node is not None
        else None
    )
    return owner_info["display_name"] if owner_info is not None else None


def lexical_type_chain(type_key, type_infos):
    """Return the enclosing source-type chain from outermost to selected type.

    ``type_key`` is a declaration byte-range identity and ``type_infos`` is the
    unit's mapping produced by :func:`build_type_infos`.

    Example call:
        For the key of ``Outer.Routes.Handler``,
        ``lexical_type_chain(key, unit["type_infos"])`` returns records whose
        display names are ``Outer``, ``Outer.Routes``, and
        ``Outer.Routes.Handler``.
    """

    chain = []
    current_key = type_key
    while current_key is not None and current_key in type_infos:
        info = type_infos[current_key]
        chain.append(info)
        current_key = info["outer_key"]
    return list(reversed(chain))


def java_package_name(source, package_matches):
    """Return the Java namespace declared unambiguously by one source file.

    The empty string represents the Java unnamed package and is also the
    fail-closed result for conflicting recovered declarations.

    Example call:
        For ``package com.acme.api;``,
        ``java_package_name(source, matches)`` returns ``"com.acme.api"``.
    """

    names = []
    for _pattern_index, captures in package_matches:
        name_node = first_capture(captures, "package.name")
        if name_node is not None:
            names.append(node_text(source, name_node).strip())
    return names[0] if len(set(names)) == 1 else ""


def group_query_captures(matches, capture_name):
    """Group query evidence that belongs to the same Java declaration.

    ``capture_name`` selects the declaration role used as the grouping key;
    each value remains a list because one method or type can carry several
    annotations.

    Example call:
        ``group_query_captures(method_annotation_matches, "method.node")`` maps
        one method's byte range to all captures for its ``@Path`` and ``@GET``
        occurrences.
    """

    grouped = {}
    for _pattern_index, captures in matches:
        node = first_capture(captures, capture_name)
        if node is not None:
            grouped.setdefault(tree_node_key(node), []).append(captures)
    return grouped


def annotation_records(candidates):
    """Deduplicate annotations while retaining occurrence and name evidence.

    Each result has ``node`` for the complete annotation (arguments included)
    and ``name_node`` for the spelling whose Java identity is resolved.

    Example call:
        Captures for ``@GetMapping("/items")`` produce
        ``{"node": annotation_node, "name_node": get_mapping_name_node}``;
        duplicate query paths to that same byte range produce only one record.
    """

    records = {}
    for captures in candidates:
        annotation_node = first_capture(captures, "annotation.node")
        name_node = first_capture(captures, "annotation.name")
        if annotation_node is None or name_node is None:
            continue
        records[tree_node_key(annotation_node)] = {
            "node": annotation_node,
            "name_node": name_node,
        }
    return [records[key] for key in sorted(records)]


def record_explicit_zero_parameter_accessors(source, matches):
    """Identify explicit record accessors that replace generated accessors.

    The returned key pairs the owning record's node identity with the method
    name.  Endpoint logic uses this to avoid treating both an explicit method
    and Java's implicit component accessor as separate declarations.

    Example call:
        For ``record Route(String path) { public String path() {...} }``,
        ``record_explicit_zero_parameter_accessors(source, matches)`` contains
        ``(tree_node_key(route_record_node), "path")``.
    """

    accessors = set()
    for _pattern_index, captures in matches:
        type_node = first_capture(captures, "type.node")
        method_name_node = first_capture(captures, "method.name")
        parameters_node = first_capture(captures, "method.parameters")
        if None in (type_node, method_name_node, parameters_node):
            continue
        if any(
            child.type in {"formal_parameter", "spread_parameter"}
            for child in parameters_node.named_children
        ):
            continue
        accessors.add(
            (tree_node_key(type_node), node_text(source, method_name_node))
        )
    return accessors


def parse_java_query_set(source_bytes, runtime, parsed_tree=None, *, match_query):
    """Parse one Java source and run every query in a compiled runtime.

    Keeping the tree, cursors, and raw matches together is part of the Java
    frontend contract: Tree-sitter nodes can retain cursor-owned state.  A
    feature analyzer may consume a smaller query runtime, but it must not own
    parser invocation or these lifetimes itself.

    ``runtime`` contains the shared Java parser and named compiled queries;
    ``parsed_tree`` optionally reuses the caller's parse of the same bytes;
    ``match_query`` adapts query execution for the installed parser version.

    Example call:
        ``parse_java_query_set(b'class Items {}', runtime,
        match_query=run_query)`` returns ``(tree, matches, owners)`` where
        ``matches["type"]`` contains the ``Items`` declaration and ``owners``
        retains the tree and query cursors.
    """
    tree = parsed_tree or runtime["parser"].parse(source_bytes)
    root = tree.root_node
    lifetime_owners = [tree]
    matches = {
        name: match_query(query, root, lifetime_owners)
        for name, query in runtime["queries"].items()
    }
    return tree, matches, lifetime_owners


def build_java_compilation_unit(
    source_path, source_bytes, runtime, parsed_tree=None, *, match_query
):
    """Create the complete reusable syntax product for one Java source.

    The returned unit keeps bytes, tree/query lifetimes, imports, lexical types,
    annotation occurrences, constants, and grouped candidate evidence together.
    Later framework passes reuse this exact object instead of parsing again.

    Important unit members and their application meanings are:

    * ``source_path`` / ``source``: endpoint provenance and immutable Java text;
    * ``tree`` / ``lifetime_owners``: reusable syntax evidence and its owners;
    * ``matches``: named raw evidence sets such as fields, methods, and imports;
    * ``type_infos``: lexical source-type identities and nesting relationships;
    * ``imports`` / ``package``: Java name-resolution context;
    * ``annotation_occurrences`` / ``local_annotations``: annotation uses and
      declarations needed for recognition and shadowing;
    * ``local_types``: short source type names present in this file;
    * ``type_candidates``, ``method_candidates``, and
      ``record_component_candidates``: annotation evidence grouped by the
      declaration that could contribute endpoint metadata;
    * ``record_explicit_accessors``: generated record accessors suppressed by
      an explicit zero-argument method; and
    * ``meta_candidates`` / ``element_candidates``: evidence used to understand
      source-defined annotations and their declared elements.

    Example call:
        ``unit = build_java_compilation_unit("/src/Items.java",
        b'package app; class Items {}', runtime, match_query=run_query)``
        produces a unit with ``unit["source_path"] == "/src/Items.java"``,
        ``unit["package"] == "app"``, a type-info record for ``Items``, and
        imports/candidate mappings that are empty for this minimal source.
    """

    tree, matches, lifetime_owners = parse_java_query_set(
        source_bytes,
        runtime,
        parsed_tree,
        match_query=match_query,
    )
    type_infos = build_type_infos(source_bytes, matches["type"])
    return {
        "source_path": source_path,
        "source": source_bytes,
        "tree": tree,
        "lifetime_owners": lifetime_owners,
        "matches": matches,
        "type_infos": type_infos,
        "imports": parse_java_imports(source_bytes, matches["import"]),
        "package": java_package_name(source_bytes, matches["package"]),
        "annotation_occurrences": annotation_records(
            captures for _pattern_index, captures in matches["annotation_usage"]
        ),
        "local_annotations": declared_annotation_names(
            source_bytes, matches["annotation_declaration"]
        ),
        "local_types": {info["simple_name"] for info in type_infos.values()},
        "type_candidates": group_query_captures(matches["type_annotation"], "type.node"),
        "method_candidates": group_query_captures(
            matches["method_annotation"], "method.node"
        ),
        "record_component_candidates": group_query_captures(
            matches["record_component_annotation"], "component.node"
        ),
        "record_explicit_accessors": record_explicit_zero_parameter_accessors(
            source_bytes, matches["record_method"]
        ),
        "meta_candidates": group_query_captures(
            matches["annotation_meta"], "annotation.declaration.node"
        ),
        "element_candidates": group_query_captures(
            matches["annotation_element"], "annotation.declaration.node"
        ),
    }


def resolve_known_source_name(unit, spelling, simple_name, packages, local_names):
    """Resolve one expected library identity through conservative Java tiers.

    Qualified spelling, lexical shadowing, exact imports, same-package source
    declarations, implicit packages, and wildcard collisions are considered in
    priority order.  Ambiguity at any active tier returns ``None``; lower tiers
    are never used to rescue an uncertain identity.

    ``spelling`` is the text at one syntax occurrence, ``simple_name`` is the
    expected short name, ``packages`` lists allowed library owners, and
    ``local_names`` lists source declarations visible at that exact location.

    Example call:
        With ``unit`` importing ``jakarta.ws.rs.Path`` and no local ``Path``,
        ``resolve_known_source_name(unit, "Path", "Path",
        ("jakarta.ws.rs",), set())`` returns ``"jakarta.ws.rs"``.  Supplying
        ``{"Path"}`` as ``local_names`` returns ``None`` because the local type
        shadows the import.
    """

    if spelling.rsplit(".", 1)[-1] != simple_name:
        return None
    if "." in spelling:
        for package in packages:
            if spelling == f"{package}.{simple_name}":
                return package
        return None

    # A local/member declaration wins over every import or implicit package.
    if simple_name in local_names:
        return None
    if simple_name in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][simple_name]
        for package in packages:
            if imported == f"{package}.{simple_name}":
                return package
        return None
    if simple_name in unit.get("package_types", set()):
        return None

    # Only after higher-priority source tiers are absent may known implicit or
    # wildcard packages contribute candidates.
    candidates = set()
    if "java.lang" in packages:
        candidates.add("java.lang")
    if unit["package"] in packages:
        candidates.add(unit["package"])
    candidates.update(
        package for package in packages if package in unit["imports"]["wildcards"]
    )
    expected_source_types = {
        f"{package}.{simple_name}" for package in candidates
    }
    if unit.get("wildcard_source_types", {}).get(simple_name, set()) - expected_source_types:
        return None
    return next(iter(candidates)) if len(candidates) == 1 else None


def resolve_known_annotation(unit, name_node, simple_names, packages):
    """Return a proven library annotation identity and its source spelling.

    ``simple_names`` can accept aliases within one annotation family, while
    ``packages`` restricts which external namespaces are trusted.

    Example call:
        For a name node spelling ``GetMapping`` with the Spring import,
        ``resolve_known_annotation(unit, name_node, {"GetMapping"},
        ("org.springframework.web.bind.annotation",))`` returns
        ``{"name": "GetMapping", "namespace":
        "org.springframework.web.bind.annotation", "spelling": "GetMapping"}``.
    """

    spelling = node_text(unit["source"], name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in simple_names:
        return None
    package = resolve_known_source_name(
        unit,
        spelling,
        simple_name,
        packages,
        visible_local_type_names(unit, name_node),
    )
    if package is None:
        return None
    return {"name": simple_name, "namespace": package, "spelling": spelling}


def resolve_known_type(unit, spelling, simple_name, packages, context_node=None):
    """Resolve one expected Java type at an exact lexical use site.

    ``context_node`` matters because a member or local type visible there can
    shadow an otherwise matching library import.

    Example call:
        With ``import java.lang.annotation.ElementType`` and no shadow,
        ``resolve_known_type(unit, "ElementType", "ElementType",
        ("java.lang.annotation",), value_node)`` returns
        ``"java.lang.annotation"``.
    """

    return resolve_known_source_name(
        unit,
        spelling.strip(),
        simple_name,
        packages,
        visible_local_type_names(unit, context_node),
    )


def annotation_single_value_node(annotation_node):
    """Select one annotation value or return a human-readable rejection.

    This accepts Java's equivalent ``@Path("/items")`` and
    ``@Path(value="/items")`` forms.  Other named attributes or competing
    values cannot represent a single-value annotation contract.

    Example call:
        For ``@Path("/items")``, ``annotation_single_value_node(node)`` returns
        ``(literal_node, None)``.  For ``@Path(value="/a", other="/b")`` it
        returns ``(None, "unsupported named attribute")``.
    """

    positional, named = get_annotation_arguments(annotation_node)
    if set(named) - {"value"}:
        return None, "unsupported named attribute"
    if positional and "value" in named:
        return None, "both positional and named values"
    if "value" in named:
        return named["value"], None
    if len(positional) == 1:
        return positional[0], None
    if not positional:
        return None, "missing value"
    return None, "multiple positional values"


def annotation_has_no_values(annotation_node):
    """Report whether an annotation supplies no application values.

    Example call:
        ``annotation_has_no_values(node)`` is ``True`` for ``@GET`` and
        ``@GetMapping()``, and ``False`` for ``@Path("/items")``.
    """

    arguments = child_by_field(annotation_node, "arguments")
    return arguments is None or not arguments.named_children


def qualified_type_name(unit, type_info):
    """Build the fully qualified identity of one source type declaration.

    Example call:
        If ``unit["package"] == "com.acme"`` and
        ``type_info["display_name"] == "Outer.Api"``, then
        ``qualified_type_name(unit, type_info)`` returns
        ``"com.acme.Outer.Api"``.
    """

    display_name = type_info["display_name"]
    return f"{unit['package']}.{display_name}" if unit["package"] else display_name


def declaration_modifier_names(declaration_node):
    """Return Java modifiers that affect visibility or constant eligibility.

    Annotation modifiers are not application access facts; keywords such as
    ``public``, ``private``, ``static``, and ``final`` are retained.

    Example call:
        For ``private static final String ROOT = "/api";``,
        ``declaration_modifier_names(field_node)`` contains
        ``{"private", "static", "final"}``.
    """

    modifiers = find_first(declaration_node, "modifiers")
    return {
        child.type
        for child in modifiers.children
        if child.is_named or child.type in {"public", "protected", "private", "static", "final"}
    } if modifiers is not None else set()


def direct_annotation_records(declaration_node):
    """Return annotations attached directly to one Java declaration.

    Annotations inherited from parents or nested inside the declaration are
    excluded.  Each record has the whole ``node`` plus ``name_node`` for Java
    identity resolution.

    Example call:
        For ``@Path("/items") @Produces(JSON) class Items {}``,
        ``direct_annotation_records(type_node)`` returns two records in that
        source order, for ``Path`` and ``Produces``.
    """

    modifiers = find_first(declaration_node, "modifiers")
    if modifiers is None:
        return []
    records = []
    for annotation_node in modifiers.named_children:
        if annotation_node.type not in {"annotation", "marker_annotation"}:
            continue
        name_node = child_by_field(annotation_node, "name")
        if name_node is not None:
            records.append({"node": annotation_node, "name_node": name_node})
    return sorted(records, key=lambda record: record["node"].start_byte)


__all__ = [
    "JAVA_CONSTANT_MAX_LENGTH",
    "annotation_has_no_values",
    "annotation_records",
    "annotation_single_value_node",
    "annotation_value_nodes",
    "binary_expression_is_addition",
    "build_java_compilation_unit",
    "build_type_infos",
    "child_by_field",
    "declaration_modifier_names",
    "declared_annotation_names",
    "decode_java_string_literal",
    "direct_annotation_records",
    "find_first",
    "first_capture",
    "get_annotation_arguments",
    "group_query_captures",
    "java_package_name",
    "lexical_type_chain",
    "nearest_enclosing_type",
    "node_text",
    "owner_name_for_node",
    "parameter_list_source_text",
    "parse_java_imports",
    "parse_java_query_set",
    "qualified_type_name",
    "query_matches",
    "record_explicit_zero_parameter_accessors",
    "resolve_known_annotation",
    "resolve_known_source_name",
    "resolve_known_type",
    "tree_node_key",
    "type_is_abstract",
    "type_is_workspace_visible",
    "unwrap_parenthesized_node",
    "visible_local_type_infos",
    "visible_local_type_names",
]
