"""Framework-neutral Java syntax and compilation-unit construction.

This module owns the smallest useful front-end vocabulary: source text, tree
navigation, query-capture shaping, imports and lexical types.  It deliberately
knows nothing about Spring, JAX-RS, endpoint facts, diagnostics, or orchestration.
Parser/version policy stays at the application boundary and is
supplied here through an explicit query matcher.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

import re


# This shared bound applies both while decoding a literal and while composing
# workspace constants, so no analyzer can obtain an oversized route value.
JAVA_CONSTANT_MAX_LENGTH = 8192


def query_matches(query, root, cursor_factory, lifetime_owners=None):
    """Run one compiled query while keeping cursor-owned nodes alive."""

    cursor = cursor_factory(query)
    matches = cursor.matches(root)
    if lifetime_owners is not None:
        lifetime_owners.append((cursor, matches))
    return matches


def node_text(source: bytes, node) -> str:
    """Decode a node from the immutable bytes used to build its syntax tree."""

    return source[node.start_byte : node.end_byte].decode("utf8")


def find_first(node, type_name: str):
    """Return the first direct child of a syntax kind, without descending."""

    for child in node.children:
        if child.type == type_name:
            return child
    return None


def child_by_field(node, field_name: str):
    """Read a named field and treat parser-recovery failures as no evidence."""

    try:
        return node.child_by_field_name(field_name)
    except Exception:
        return None


def parameter_list_source_text(source: bytes, parameters_node) -> str:
    """Preserve a declaration's parameter spelling for endpoint provenance."""

    if not parameters_node:
        return ""

    parameters_text = node_text(source, parameters_node)
    if parameters_text.startswith("(") and parameters_text.endswith(")"):
        parameters_text = parameters_text[1:-1]

    return parameters_text.strip()


def get_annotation_arguments(annotation_node):
    """Separate positional and named values from one annotation occurrence.

    This helper shapes syntax only. Framework decoders decide which keys and
    cardinalities have meaning for their annotation family.
    """

    positional_values = []
    named_values = {}
    arguments = child_by_field(annotation_node, "arguments")

    if not arguments:
        return positional_values, named_values

    for child in arguments.named_children:
        # Tree-sitter exposes comments as named children. They are trivia, not
        # additional annotation values (for example @GetMapping("/x" /*...*/)).
        if child.type in {"line_comment", "block_comment"}:
            continue
        if child.type == "element_value_pair":
            key_node = child_by_field(child, "key")
            value_node = child_by_field(child, "value")
            if key_node and value_node:
                key = key_node.text.decode("utf8")
                named_values[key] = value_node
        else:
            positional_values.append(child)

    return positional_values, named_values


def first_capture(captures, name):
    """Return the first node for one capture label within the same query match."""

    nodes = captures.get(name, [])
    return nodes[0] if nodes else None


def tree_node_key(node):
    """Return a unit-local byte-range identity for a Tree-sitter node."""

    return (node.start_byte, node.end_byte)


def nearest_enclosing_type(node):
    """Find the lexical named type that owns a syntax occurrence."""

    current = getattr(node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return current
        current = getattr(current, "parent", None)
    return None


def type_is_abstract(source, type_node):
    """Record whether a class declaration is explicitly abstract."""

    modifiers = find_first(type_node, "modifiers")
    return bool(
        type_node.type == "class_declaration"
        and modifiers
        and any(child.type == "abstract" for child in modifiers.children)
    )


def type_is_workspace_visible(type_node):
    """Decide whether a named type can receive a cross-file source identity.

    Member types remain workspace-visible, while declarations inside methods,
    lambdas, constructors, blocks, and initializers are lexical shadows only.
    """

    current = getattr(type_node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return True
        if current.type in {
            "method_declaration",
            "constructor_declaration",
            "compact_constructor_declaration",
            "lambda_expression",
            "block",
            "constructor_body",
            "static_initializer",
        }:
            return False
        current = getattr(current, "parent", None)
    return True


def build_type_infos(source, type_matches):
    """Build source-ordered lexical identities for every named type in a unit.

    Outer declarations are processed first so nested display names and
    workspace visibility are inherited from a known lexical owner.
    """

    infos = {}
    ordered = []
    for _pattern_index, captures in type_matches:
        type_node = first_capture(captures, "type.node")
        name_node = first_capture(captures, "type.name")
        if type_node is None or name_node is None:
            continue
        ordered.append((type_node.start_byte, type_node, node_text(source, name_node)))

    for _start_byte, type_node, simple_name in sorted(ordered):
        outer_node = nearest_enclosing_type(type_node)
        outer_key = tree_node_key(outer_node) if outer_node is not None else None
        outer_info = infos.get(outer_key)
        display_name = (
            f"{outer_info['display_name']}.{simple_name}"
            if outer_info is not None
            else simple_name
        )
        key = tree_node_key(type_node)
        infos[key] = {
            "node": type_node,
            "simple_name": simple_name,
            "display_name": display_name,
            "outer_key": outer_key if outer_info is not None else None,
            "abstract": type_is_abstract(source, type_node),
            "workspace_visible": type_is_workspace_visible(type_node)
            and (outer_info is None or outer_info["workspace_visible"]),
            "mapping": None,
        }
    return infos


def visible_local_type_infos(unit, context_node=None):
    """Return source types that can lexically shadow a simple import."""
    infos = unit.get("type_infos", {})
    visible_keys = {
        key
        for key, info in infos.items()
        if info["outer_key"] is None and info["workspace_visible"]
    }
    if context_node is None:
        return [infos[key] for key in visible_keys]

    current = nearest_enclosing_type(context_node)
    scope_keys = set()
    while current is not None:
        key = tree_node_key(current)
        info = infos.get(key)
        if info is None:
            break
        scope_keys.add(key)
        visible_keys.add(key)
        current = (
            infos[info["outer_key"]]["node"]
            if info["outer_key"] in infos
            else None
        )
    visible_keys.update(
        key
        for key, info in infos.items()
        if info["workspace_visible"] and info["outer_key"] in scope_keys
    )
    return [infos[key] for key in visible_keys]


def visible_local_type_names(unit, context_node=None):
    """Return simple names that block known-library/import shortcuts here."""

    return {
        info["simple_name"]
        for info in visible_local_type_infos(unit, context_node)
    }


def parse_java_imports(source, import_matches):
    """Shape imports into exact/wildcard and static/non-static lookup tiers.

    Conflicting exact imports are stored as ``""``.  That marker deliberately
    blocks fallback to lower-priority tiers during later name resolution.
    """

    exact = {}
    wildcards = set()
    static_exact = {}
    static_wildcards = set()
    for _pattern_index, captures in import_matches:
        import_node = first_capture(captures, "import.node")
        if import_node is None:
            continue
        declaration = node_text(source, import_node).strip()
        match = re.fullmatch(r"import\s+(static\s+)?([^;]+)\s*;", declaration)
        if not match:
            continue
        target = match.group(2).strip()
        if match.group(1):
            if target.endswith(".*"):
                static_wildcards.add(target[:-2])
                continue
            simple_name = target.rsplit(".", 1)[-1]
            previous = static_exact.get(simple_name)
            static_exact[simple_name] = (
                target if previous in (None, target) else ""
            )
            continue
        if target.endswith(".*"):
            wildcards.add(target[:-2])
            continue
        simple_name = target.rsplit(".", 1)[-1]
        previous = exact.get(simple_name)
        exact[simple_name] = target if previous in (None, target) else ""
    return {
        "exact": exact,
        "wildcards": wildcards,
        "static_exact": static_exact,
        "static_wildcards": static_wildcards,
    }


def declared_annotation_names(source, declaration_matches):
    """Return source annotation simple names used for local shadowing checks."""

    names = set()
    for _pattern_index, captures in declaration_matches:
        name_node = first_capture(captures, "annotation.declaration.name")
        if name_node is not None:
            names.add(node_text(source, name_node))
    return names


def decode_java_string_literal(literal, max_length=JAVA_CONSTANT_MAX_LENGTH):
    """Decode the bounded escape forms valid in an ordinary Java string.

    Text blocks, malformed escapes, invalid surrogate pairs, and values beyond
    the shared bound remain unresolved rather than becoming route evidence.
    """
    if len(literal) < 2 or not (literal.startswith('"') and literal.endswith('"')):
        return None

    result = []
    index = 1
    end = len(literal) - 1
    simple_escapes = {
        "b": "\b",
        "t": "\t",
        "n": "\n",
        "f": "\f",
        "r": "\r",
        "s": " ",
        '"': '"',
        "'": "'",
        "\\": "\\",
    }
    while index < end:
        char = literal[index]
        if char != "\\":
            result.append(char)
            index += 1
            continue

        index += 1
        if index >= end:
            return None
        escaped = literal[index]
        if escaped in simple_escapes:
            result.append(simple_escapes[escaped])
            index += 1
            continue
        if escaped == "u":
            while index < end and literal[index] == "u":
                index += 1
            digits = literal[index:index + 4]
            if len(digits) != 4 or not re.fullmatch(r"[0-9a-fA-F]{4}", digits):
                return None
            result.append(chr(int(digits, 16)))
            index += 4
            continue
        if escaped in "01234567":
            max_digits = 3 if escaped in "0123" else 2
            digits = escaped
            index += 1
            while index < end and len(digits) < max_digits and literal[index] in "01234567":
                digits += literal[index]
                index += 1
            result.append(chr(int(digits, 8)))
            continue
        return None

    try:
        value = (
            "".join(result)
            .encode("utf-16-le", errors="surrogatepass")
            .decode("utf-16-le")
        )
    except UnicodeDecodeError:
        return None
    return value if len(value) <= max_length else None


def binary_expression_is_addition(source, node, left, right):
    """Prove a binary expression uses ``+`` despite parser API variations."""

    operator = child_by_field(node, "operator")
    if operator is not None:
        return node_text(source, operator).strip() == "+"
    return any(child.type == "+" for child in node.children) or (
        source[left.end_byte:right.start_byte].decode("utf8").strip() == "+"
    )


def annotation_value_nodes(value_node):
    """Normalize one annotation scalar or array initializer to value nodes."""

    if value_node.type == "element_value_array_initializer":
        return [
            child
            for child in value_node.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
    return [value_node]


def unwrap_parenthesized_node(node):
    """Unwrap only structurally unambiguous parenthesized expressions."""

    current = node
    while current is not None and current.type == "parenthesized_expression":
        children = current.named_children
        if len(children) != 1:
            return None
        current = children[0]
    return current


def owner_name_for_node(unit, context_node):
    """Return the lexical display name used for owner-relative Java lookup."""

    owner_node = nearest_enclosing_type(context_node) if context_node is not None else None
    owner_info = (
        unit.get("type_infos", {}).get(tree_node_key(owner_node))
        if owner_node is not None
        else None
    )
    return owner_info["display_name"] if owner_info is not None else None


def lexical_type_chain(type_key, type_infos):
    """Return a type's outer-to-inner declaration chain within one unit."""

    chain = []
    current_key = type_key
    while current_key is not None and current_key in type_infos:
        info = type_infos[current_key]
        chain.append(info)
        current_key = info["outer_key"]
    return list(reversed(chain))


def java_package_name(source, package_matches):
    """Return one unambiguous package declaration, else the unnamed package."""

    names = []
    for _pattern_index, captures in package_matches:
        name_node = first_capture(captures, "package.name")
        if name_node is not None:
            names.append(node_text(source, name_node).strip())
    return names[0] if len(set(names)) == 1 else ""


def group_query_captures(matches, capture_name):
    """Group complete query matches by a captured declaration's unit-local key."""

    grouped = {}
    for _pattern_index, captures in matches:
        node = first_capture(captures, capture_name)
        if node is not None:
            grouped.setdefault(tree_node_key(node), []).append(captures)
    return grouped


def annotation_records(candidates):
    """Deduplicate annotation occurrences while retaining name-node provenance."""

    records = {}
    for captures in candidates:
        annotation_node = first_capture(captures, "annotation.node")
        name_node = first_capture(captures, "annotation.name")
        if annotation_node is None or name_node is None:
            continue
        records[tree_node_key(annotation_node)] = {
            "node": annotation_node,
            "name_node": name_node,
        }
    return [records[key] for key in sorted(records)]


def record_explicit_zero_parameter_accessors(source, matches):
    """Identify record accessors that suppress an implicit component accessor."""

    accessors = set()
    for _pattern_index, captures in matches:
        type_node = first_capture(captures, "type.node")
        method_name_node = first_capture(captures, "method.name")
        parameters_node = first_capture(captures, "method.parameters")
        if None in (type_node, method_name_node, parameters_node):
            continue
        if any(
            child.type in {"formal_parameter", "spread_parameter"}
            for child in parameters_node.named_children
        ):
            continue
        accessors.add(
            (tree_node_key(type_node), node_text(source, method_name_node))
        )
    return accessors


def parse_java_query_set(source_bytes, runtime, parsed_tree=None, *, match_query):
    """Parse one Java source and run every query in a compiled runtime.

    Keeping the tree, cursors, and raw matches together is part of the Java
    frontend contract: Tree-sitter nodes can retain cursor-owned state.  A
    feature analyzer may consume a smaller query runtime, but it must not own
    parser invocation or these lifetimes itself.
    """
    tree = parsed_tree or runtime["parser"].parse(source_bytes)
    root = tree.root_node
    lifetime_owners = [tree]
    matches = {
        name: match_query(query, root, lifetime_owners)
        for name, query in runtime["queries"].items()
    }
    return tree, matches, lifetime_owners


def build_java_compilation_unit(
    source_path, source_bytes, runtime, parsed_tree=None, *, match_query
):
    """Create the complete reusable syntax product for one Java source.

    The returned unit keeps bytes, tree/query lifetimes, imports, lexical types,
    annotation occurrences, constants, and grouped candidate evidence together.
    Later framework passes reuse this exact object instead of parsing again.
    """

    tree, matches, lifetime_owners = parse_java_query_set(
        source_bytes,
        runtime,
        parsed_tree,
        match_query=match_query,
    )
    type_infos = build_type_infos(source_bytes, matches["type"])
    return {
        "source_path": source_path,
        "source": source_bytes,
        "tree": tree,
        "lifetime_owners": lifetime_owners,
        "matches": matches,
        "type_infos": type_infos,
        "imports": parse_java_imports(source_bytes, matches["import"]),
        "package": java_package_name(source_bytes, matches["package"]),
        "annotation_occurrences": annotation_records(
            captures for _pattern_index, captures in matches["annotation_usage"]
        ),
        "local_annotations": declared_annotation_names(
            source_bytes, matches["annotation_declaration"]
        ),
        "local_types": {info["simple_name"] for info in type_infos.values()},
        "type_candidates": group_query_captures(matches["type_annotation"], "type.node"),
        "method_candidates": group_query_captures(
            matches["method_annotation"], "method.node"
        ),
        "record_component_candidates": group_query_captures(
            matches["record_component_annotation"], "component.node"
        ),
        "record_explicit_accessors": record_explicit_zero_parameter_accessors(
            source_bytes, matches["record_method"]
        ),
        "meta_candidates": group_query_captures(
            matches["annotation_meta"], "annotation.declaration.node"
        ),
        "element_candidates": group_query_captures(
            matches["annotation_element"], "annotation.declaration.node"
        ),
    }


def resolve_known_source_name(unit, spelling, simple_name, packages, local_names):
    """Resolve one expected library identity through conservative Java tiers.

    Qualified spelling, lexical shadowing, exact imports, same-package source
    declarations, implicit packages, and wildcard collisions are considered in
    priority order.  Ambiguity at any active tier returns ``None``; lower tiers
    are never used to rescue an uncertain identity.
    """

    if spelling.rsplit(".", 1)[-1] != simple_name:
        return None
    if "." in spelling:
        for package in packages:
            if spelling == f"{package}.{simple_name}":
                return package
        return None

    # A local/member declaration wins over every import or implicit package.
    if simple_name in local_names:
        return None
    if simple_name in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][simple_name]
        for package in packages:
            if imported == f"{package}.{simple_name}":
                return package
        return None
    if simple_name in unit.get("package_types", set()):
        return None

    # Only after higher-priority source tiers are absent may known implicit or
    # wildcard packages contribute candidates.
    candidates = set()
    if "java.lang" in packages:
        candidates.add("java.lang")
    if unit["package"] in packages:
        candidates.add(unit["package"])
    candidates.update(
        package for package in packages if package in unit["imports"]["wildcards"]
    )
    expected_source_types = {
        f"{package}.{simple_name}" for package in candidates
    }
    if unit.get("wildcard_source_types", {}).get(simple_name, set()) - expected_source_types:
        return None
    return next(iter(candidates)) if len(candidates) == 1 else None


def resolve_known_annotation(unit, name_node, simple_names, packages):
    """Return exact known-annotation identity plus its source spelling."""

    spelling = node_text(unit["source"], name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in simple_names:
        return None
    package = resolve_known_source_name(
        unit,
        spelling,
        simple_name,
        packages,
        visible_local_type_names(unit, name_node),
    )
    if package is None:
        return None
    return {"name": simple_name, "namespace": package, "spelling": spelling}


def resolve_known_type(unit, spelling, simple_name, packages, context_node=None):
    """Resolve an expected type identity at one lexical syntax location."""

    return resolve_known_source_name(
        unit,
        spelling.strip(),
        simple_name,
        packages,
        visible_local_type_names(unit, context_node),
    )


def annotation_single_value_node(annotation_node):
    """Select the sole positional/``value`` argument or explain rejection."""

    positional, named = get_annotation_arguments(annotation_node)
    if set(named) - {"value"}:
        return None, "unsupported named attribute"
    if positional and "value" in named:
        return None, "both positional and named values"
    if "value" in named:
        return named["value"], None
    if len(positional) == 1:
        return positional[0], None
    if not positional:
        return None, "missing value"
    return None, "multiple positional values"


def annotation_has_no_values(annotation_node):
    """Report whether an annotation has no argument list or an empty one."""

    arguments = child_by_field(annotation_node, "arguments")
    return arguments is None or not arguments.named_children


def qualified_type_name(unit, type_info):
    """Combine a unit package and lexical display name into source identity."""

    display_name = type_info["display_name"]
    return f"{unit['package']}.{display_name}" if unit["package"] else display_name


def declaration_modifier_names(declaration_node):
    """Return modifiers used by accessibility and constant-eligibility rules."""

    modifiers = find_first(declaration_node, "modifiers")
    return {
        child.type
        for child in modifiers.children
        if child.is_named or child.type in {"public", "protected", "private", "static", "final"}
    } if modifiers is not None else set()


def direct_annotation_records(declaration_node):
    """Return source-ordered annotations directly attached to a declaration."""

    modifiers = find_first(declaration_node, "modifiers")
    if modifiers is None:
        return []
    records = []
    for annotation_node in modifiers.named_children:
        if annotation_node.type not in {"annotation", "marker_annotation"}:
            continue
        name_node = child_by_field(annotation_node, "name")
        if name_node is not None:
            records.append({"node": annotation_node, "name_node": name_node})
    return sorted(records, key=lambda record: record["node"].start_byte)


__all__ = [
    "JAVA_CONSTANT_MAX_LENGTH",
    "annotation_has_no_values",
    "annotation_records",
    "annotation_single_value_node",
    "annotation_value_nodes",
    "binary_expression_is_addition",
    "build_java_compilation_unit",
    "build_type_infos",
    "child_by_field",
    "declaration_modifier_names",
    "declared_annotation_names",
    "decode_java_string_literal",
    "direct_annotation_records",
    "find_first",
    "first_capture",
    "get_annotation_arguments",
    "group_query_captures",
    "java_package_name",
    "lexical_type_chain",
    "nearest_enclosing_type",
    "node_text",
    "owner_name_for_node",
    "parameter_list_source_text",
    "parse_java_imports",
    "parse_java_query_set",
    "qualified_type_name",
    "query_matches",
    "record_explicit_zero_parameter_accessors",
    "resolve_known_annotation",
    "resolve_known_source_name",
    "resolve_known_type",
    "tree_node_key",
    "type_is_abstract",
    "type_is_workspace_visible",
    "unwrap_parenthesized_node",
    "visible_local_type_infos",
    "visible_local_type_names",
]
