"""Project path configuration and static-resource analysis.

The analyzer receives an already-built Java workspace and reuses the shared
Java name and String-constant resolution rules. The supported
source/configuration shapes are intentionally bounded:

* ``application.properties``, ``application.yml``, and ``application.yaml``
  at the three documented project locations;
* mapping-only YAML with String/integer leaves;
* nested Spring ``${key:default}`` path placeholders; and
* direct ``WebMvcConfigurer.addResourceHandlers`` registrations on a genuine
  ``ResourceHandlerRegistry`` parameter.

Unsupported configuration and Java control/data-flow shapes fail closed.  No
dependency metadata, runtime bean graph, profile activation, or physical
resource enumeration is attempted.

Logic guide: ``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import json
from pathlib import Path
import re
from typing import Any, Callable, Iterable, Mapping

from .diagnostics import format_endpoint_diagnostic, record
from .evidence import deduplicate_endpoint_facts, represented_target_evidence
from .java_ast import (
    direct_interface_types as _direct_interface_types,
    field as _field,
    is_direct_invocation_statement as _direct_registration_chain,
    known_type as _known_type_in_package,
    source_text as _text,
    walk_named as _walk,
)
from .java_frontend import (
    declaration_modifier_names,
    qualified_type_name,
)
from .java_workspace import resolve_workspace_string_expression
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths


WEB_MVC_CONFIG_PACKAGE = "org.springframework.web.servlet.config.annotation"
CONFIGURATION_FILENAMES = (
    "application.properties",
    "application.yml",
    "application.yaml",
)
MAX_PLACEHOLDER_SUBSTITUTIONS = 100
MAX_CONFIGURED_PATH_LENGTH = 8192
ELIGIBLE_HTTP_SURFACES = frozenset(
    {"server", "proxy", "gateway", "resource", "static-handler"}
)
ELIGIBLE_WS_SURFACES = frozenset({"websocket-handshake", "message"})

_PLACEHOLDER = re.compile(r"\$\{([^{}]+)\}")
_INTEGER = re.compile(r"[+-]?[0-9]+")
_FLOATISH = re.compile(
    r"[+-]?(?:[0-9]+\.[0-9]*|[0-9]*\.[0-9]+)(?:[eE][+-]?[0-9]+)?"
)
_PLAIN_YAML_KEY = re.compile(r"[A-Za-z0-9_.-]+")
_UNSUPPORTED_YAML_SCALARS = frozenset(
    {"null", "~", "true", "false", ".nan", ".inf", "+.inf", "-.inf"}
)


@dataclass(frozen=True)
class SpringProjectPathConfiguration:
    """Resolved bounded configuration for one inferred source project."""

    # Canonical root whose configuration applies to one group of Java sources.
    project_root: str
    # Flattened property names and values available to route placeholders.
    placeholder_values: Mapping[str, str]
    # Composed servlet/context base path prepended to eligible inbound routes.
    server_base_path: str
    # Configuration files actually read, in deterministic precedence order.
    loaded_configuration_files: tuple[str, ...]

    # Example value:
    # SpringProjectPathConfiguration("/workspace/shop", {"routes.api": "/api"},
    #                                "/edge", ("application.properties",))


@dataclass(frozen=True)
class SpringWorkspacePathConfiguration:
    """Project/configuration ownership for one analyzer invocation."""

    # Canonical source-tree root for the complete analysis invocation.
    analysis_root: str
    # Per-project resolved path configuration, keyed by canonical project root.
    projects_by_root: Mapping[str, SpringProjectPathConfiguration]
    # Ownership decision mapping every Java source to one project or ambiguity.
    project_root_by_source_file: Mapping[str, str | None]

    # Example value:
    # SpringWorkspacePathConfiguration("/workspace", {"/workspace/shop": shop_cfg},
    #     {"/workspace/shop/src/main/java/Items.java": "/workspace/shop"})


def _canonical_path(path: str | Path) -> str:
    """Canonicalize source keys so configuration ownership survives spelling changes.

    Example call:
        ``_canonical_path(
            path="/workspace/shop/src/main/java/com/acme/ItemsController.java",
        )``
        canonicalizes source keys so configuration ownership survives spelling changes.
    """

    return str(Path(path).expanduser().resolve(strict=False))


def _log(message: str) -> None:
    """Record a configuration/resource rejection for the current run.

    Example call:
        ``_log(message="unresolved route path")``
        records a configuration/resource rejection for the current run.
    """

    record(f"Skipped Spring configuration/resource {message}")


def _known_type(unit: Mapping[str, Any], node: Any, simple_name: str) -> bool:
    """Prove one exact Spring MVC configuration type identity.

    Example call:
        ``_known_type(
            unit=items_unit,
            node=web_mvc_configurer_type_node,
            simple_name="WebMvcConfigurer",
        )``
        proves one exact Spring MVC configuration type identity.
    """

    return _known_type_in_package(
        unit, node, simple_name, WEB_MVC_CONFIG_PACKAGE
    )


def _infer_project_root(source_file: str, analysis_root: Path) -> Path | None:
    """Infer one project root, rejecting repeated/ambiguous source markers.

    Example call:
        ``_infer_project_root(
            source_file="/workspace/shop/src/main/java/com/acme/Items.java",
            analysis_root=Path("/workspace"),
        )``
        infers one project root, rejecting repeated/ambiguous source markers.
    """

    source_path = Path(source_file).expanduser().resolve(strict=False)
    try:
        source_path.relative_to(analysis_root)
    except ValueError:
        return None

    parts = source_path.parts
    main_java_cuts = [
        index
        for index in range(max(0, len(parts) - 2))
        if parts[index : index + 3] == ("src", "main", "java")
    ]
    if main_java_cuts:
        if len(main_java_cuts) != 1:
            return None
        cut = main_java_cuts[0]
    else:
        src_cuts = [index for index, part in enumerate(parts[:-1]) if part == "src"]
        if len(src_cuts) > 1:
            return None
        if not src_cuts:
            return analysis_root
        cut = src_cuts[0]

    return Path(*parts[:cut]).resolve(strict=False)


def _parse_properties(text: str) -> dict[str, str]:
    """Extract the bounded key/value subset used for Spring route paths.

    Example call:
        ``_parse_properties(text="server.servlet.context-path=/shop")``
        extracts the bounded key/value subset used for Spring route paths.
    """

    values: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", "!")):
            continue
        separators = [
            index for index in (stripped.find("="), stripped.find(":")) if index >= 0
        ]
        if not separators:
            continue
        separator = min(separators)
        key = stripped[:separator].strip()
        if key:
            values[key] = stripped[separator + 1 :].strip()
    return values


def _strip_yaml_comment(line: str) -> str | None:
    """Remove an unquoted YAML comment, rejecting unterminated quoted scalars.

    Example call:
        ``_strip_yaml_comment(line="server: # application settings")``
        removes an unquoted YAML comment, rejecting unterminated quoted scalars.
    """

    quote: str | None = None
    escaped = False
    for index, character in enumerate(line):
        if quote == '"':
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if quote == "'":
            if character == quote:
                if index + 1 < len(line) and line[index + 1] == quote:
                    continue
                quote = None
            continue
        if character in {'"', "'"}:
            quote = character
        elif character == "#" and (index == 0 or line[index - 1].isspace()):
            return line[:index].rstrip()
    return None if quote is not None else line.rstrip()


def _split_yaml_mapping(line: str) -> tuple[str, str] | None:
    """Split one supported YAML mapping entry at its first unquoted colon.

    Example call:
        ``_split_yaml_mapping(line="context-path: /shop")``
        splits one supported YAML mapping entry at its first unquoted colon.
    """

    quote: str | None = None
    escaped = False
    for index, character in enumerate(line):
        if quote == '"':
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if quote == "'":
            if character == quote:
                if index + 1 < len(line) and line[index + 1] == quote:
                    continue
                quote = None
            continue
        if character in {'"', "'"}:
            quote = character
        elif character == ":":
            return line[:index].strip(), line[index + 1 :].strip()
    return None


def _yaml_string(token: str, *, key: bool = False) -> str | None:
    """Decode a supported YAML key or scalar without general YAML evaluation.

    Example call:
        ``_yaml_string(token="/shop")``
        decodes a supported YAML key or scalar without general YAML evaluation.
    """

    if token.startswith('"'):
        if not token.endswith('"') or len(token) < 2:
            return None
        try:
            value = json.loads(token)
        except (json.JSONDecodeError, TypeError):
            return None
        return value if isinstance(value, str) else None
    if token.startswith("'"):
        if not token.endswith("'") or len(token) < 2:
            return None
        return token[1:-1].replace("''", "'")
    if key:
        return token if _PLAIN_YAML_KEY.fullmatch(token) else None
    lowered = token.lower()
    if (
        not token
        or lowered in _UNSUPPORTED_YAML_SCALARS
        or _FLOATISH.fullmatch(token)
        or token.startswith(("[", "{", "&", "*", "!", "|", ">"))
    ):
        return None
    return token


def _parse_mapping_yaml(text: str) -> dict[str, str] | None:
    """Parse only the mapping/scalar subset used by Spring path settings.

    Example call:
        ``_parse_mapping_yaml(text="server:\n  servlet:\n    context-path: /shop")``
        parses only the mapping/scalar subset used by Spring path settings.
    """

    values: dict[str, str] = {}
    stack: list[tuple[int, str]] = []
    scalar_paths: set[str] = set()
    saw_content = False

    for raw_line in text.splitlines():
        if "\t" in raw_line[: len(raw_line) - len(raw_line.lstrip())]:
            return None
        without_comment = _strip_yaml_comment(raw_line)
        if without_comment is None:
            return None
        if not without_comment.strip():
            continue
        stripped = without_comment.strip()
        if stripped in {"---", "..."} or stripped.startswith("-"):
            return None
        saw_content = True
        indent = len(without_comment) - len(without_comment.lstrip(" "))
        pair = _split_yaml_mapping(stripped)
        if pair is None:
            return None
        raw_key, raw_value = pair
        key = _yaml_string(raw_key, key=True)
        if key is None:
            return None

        while stack and indent <= stack[-1][0]:
            stack.pop()
        if stack and indent <= stack[-1][0]:
            return None
        prefix = ".".join(part for _level, part in stack)
        path = f"{prefix}.{key}" if prefix else key
        if any(path == scalar or path.startswith(f"{scalar}.") for scalar in scalar_paths):
            return None

        if not raw_value:
            stack.append((indent, key))
            continue
        if "&" in raw_value or raw_value.startswith("*"):
            return None
        value = _yaml_string(raw_value)
        if value is None:
            if _INTEGER.fullmatch(raw_value):
                value = raw_value
            else:
                # Unsupported YAML scalar kinds are ignored rather than
                # coerced into path strings.
                continue
        values[path] = value
        scalar_paths.add(path)

    if not saw_content:
        return {}
    if any(
        key == "spring.config.activate.on-profile"
        or key == "spring.profiles"
        or key.startswith("spring.profiles.")
        for key in values
    ):
        return None
    return values


def _normalize_optional_path(path: str | None) -> str:
    """Normalize configured path layers while preserving absolute client URLs.

    Example call:
        ``_normalize_optional_path(path="/api/items")``
        normalizes configured path layers while preserving absolute client URLs.
    """

    if path is None:
        return ""
    trimmed = path.strip()
    if not trimmed or trimmed == "/":
        return ""
    if trimmed.lower().startswith(("http://", "https://")):
        return trimmed
    return trimmed if trimmed.startswith("/") else f"/{trimmed}"


def _read_project_path_configuration(root: Path) -> SpringProjectPathConfiguration:
    """Load deterministic configuration precedence for one inferred project.

    Example call:
        ``_read_project_path_configuration(root=Path("/workspace/shop"))``
        loads deterministic configuration precedence for one inferred project.
    """

    values: dict[str, str] = {}
    loaded_configuration_files: list[str] = []
    resource_dirs = (root / "src/main/resources", root / "resources", root)
    for directory in dict.fromkeys(resource_dirs):
        for filename in CONFIGURATION_FILENAMES:
            path = directory / filename
            if not path.is_file():
                continue
            try:
                text = path.read_text(encoding="utf8")
            except (OSError, UnicodeError):
                _log(f"unreadable file {path}")
                continue
            if filename.endswith(".properties"):
                parsed = _parse_properties(text)
            else:
                parsed = _parse_mapping_yaml(text)
                if parsed is None:
                    _log(f"unsupported or malformed YAML file {path}")
                    continue
            values.update(parsed)
            loaded_configuration_files.append(str(path))

    servlet = _normalize_optional_path(values.get("server.servlet.context-path"))
    webflux = _normalize_optional_path(values.get("spring.webflux.base-path"))
    return SpringProjectPathConfiguration(
        project_root=str(root),
        placeholder_values=dict(values),
        server_base_path=webflux or servlet,
        loaded_configuration_files=tuple(loaded_configuration_files),
    )


def build_spring_path_configuration(
    workspace: Mapping[str, Any],
    analysis_root: str | Path,
) -> SpringWorkspacePathConfiguration:
    """Load bounded, project-owned Spring path configuration for a workspace.

    Example call:
        ``build_spring_path_configuration(
            workspace=java_workspace,
            analysis_root=Path("/workspace"),
        )``
        loads bounded, project-owned Spring path configuration for a workspace.
    """

    root = Path(analysis_root).expanduser().resolve(strict=False)
    project_root_by_source_file: dict[str, str | None] = {}
    project_roots: set[str] = set()
    for source_path in sorted(workspace.get("compilation_units", {})):
        project_root = _infer_project_root(source_path, root)
        canonical_file = _canonical_path(source_path)
        if project_root is None:
            project_root_by_source_file[canonical_file] = None
            _log(f"ambiguous project ownership for {source_path}")
            continue
        canonical_root = str(project_root)
        project_root_by_source_file[canonical_file] = canonical_root
        project_roots.add(canonical_root)

    projects_by_root = {
        project_root: _read_project_path_configuration(Path(project_root))
        for project_root in sorted(project_roots)
    }
    return SpringWorkspacePathConfiguration(
        str(root), projects_by_root, project_root_by_source_file
    )


def _resolve_placeholders(path: str, values: Mapping[str, str]) -> str | None:
    """Resolve bounded nested Spring placeholders, failing closed on exhaustion.

    Example call:
        ``_resolve_placeholders(
            path="${routes.base}/items",
            values={"routes.base": "/api"},
        )``
        resolves bounded nested Spring placeholders, failing closed on exhaustion.
    """

    result = path
    for _iteration in range(MAX_PLACEHOLDER_SUBSTITUTIONS):
        match = _PLACEHOLDER.search(result)
        if match is None:
            return result if "${" not in result else None
        expression = match.group(1)
        key, separator, default = expression.partition(":")
        if not key:
            return None
        value = values.get(key, default if separator else "")
        result = result[: match.start()] + value + result[match.end() :]
        if len(result) > MAX_CONFIGURED_PATH_LENGTH:
            return None
    return result if _PLACEHOLDER.search(result) is None and "${" not in result else None


def _collapse_path_slashes(path: str) -> str:
    """Collapse repeated path separators without damaging a URL authority.

    Example call:
        ``_collapse_path_slashes(path="https://api.example.com//items")``
        collapses repeated path separators without damaging a URL authority.
    """

    return re.sub(r"(?<!:)/{2,}", "/", path)


def resolve_spring_endpoint_path(
    path: str,
    source_file: str,
    configuration: SpringWorkspacePathConfiguration,
    *,
    technology: str = "spring",
    protocol: str = "http",
    surface: str = "server",
    direction: str = "inbound",
) -> str | None:
    """Apply one source project's prefix/placeholders to one eligible path.

    The helper is intentionally public so the Gateway analyzer can use the
    same project/configuration layer when it constructs raw proxy facts.

    Example call:
        ``resolve_spring_endpoint_path(
            path="/api/items",
            source_file="/workspace/shop/src/main/java/com/acme/ItemsController.java",
            configuration=spring_path_configuration,
        )``
        applies one source project's prefix/placeholders to one eligible path.
    """

    eligible_http = (
        protocol == "http"
        and direction == "inbound"
        and surface in ELIGIBLE_HTTP_SURFACES
    )
    eligible_client = (
        protocol == "http" and direction == "outbound" and surface == "client"
    )
    eligible_ws = (
        protocol == "ws"
        and direction == "inbound"
        and surface in ELIGIBLE_WS_SURFACES
    )
    if technology != "spring" or not (
        eligible_http or eligible_client or eligible_ws
    ):
        return path
    project_root = configuration.project_root_by_source_file.get(
        _canonical_path(source_file)
    )
    project = configuration.projects_by_root.get(project_root) if project_root else None
    values: Mapping[str, str] = (
        project.placeholder_values if project is not None else {}
    )
    # Spring's deployment base applies to HTTP surfaces and the HTTP upgrade
    # path used by a STOMP/WebSocket handshake. Message destinations are not
    # servlet paths, but still consume the owning project's placeholders.
    server_base_path = (
        project.server_base_path
        if project is not None
        and (eligible_http or surface == "websocket-handshake")
        else ""
    )
    # Resolve before path normalization.  A client URL may be rooted in a
    # placeholder (for example ``${remote.base}/items``); adding ``/`` first
    # would corrupt an absolute value into ``/https://...``.
    resolved_path = _resolve_placeholders(path, values)
    resolved_base = _resolve_placeholders(server_base_path, values)
    if resolved_path is None or resolved_base is None:
        return None
    normalized = _normalize_optional_path(resolved_path)
    normalized_base = _normalize_optional_path(resolved_base)
    joined = join_endpoint_paths(normalized_base, normalized)
    return _collapse_path_slashes(joined)


def _apply_spring_client_paths(
    path_layers: Iterable[str],
    source_file: str,
    configuration: SpringWorkspacePathConfiguration,
) -> str | None:
    """Resolve HTTP-interface layers before deciding absolute precedence.

    Example call:
        ``_apply_spring_client_paths(
            path_layers=("https://api.example.com", "/items"),
            source_file="/workspace/shop/src/main/java/com/acme/ItemsController.java",
            configuration=spring_path_configuration,
        )``
        resolves HTTP-interface layers before deciding absolute precedence.
    """

    project_root = configuration.project_root_by_source_file.get(
        _canonical_path(source_file)
    )
    project = configuration.projects_by_root.get(project_root) if project_root else None
    values: Mapping[str, str] = (
        project.placeholder_values if project is not None else {}
    )
    combined = ""
    for path_layer in path_layers:
        resolved = _resolve_placeholders(path_layer, values)
        if resolved is None:
            return None
        normalized = _normalize_optional_path(resolved)
        # Any inner absolute URL is complete and replaces all lexical outer
        # prefixes, including when its scheme came from configuration.
        combined = (
            normalized
            if normalized.lower().startswith(("http://", "https://"))
            else join_endpoint_paths(combined, normalized)
        )
    return _collapse_path_slashes(combined)


def make_spring_path_resolver(
    configuration: SpringWorkspacePathConfiguration,
) -> Callable[..., str | None]:
    """Return a configuration-bound path callback for sibling analyzers.

    Callers may provide ``source_file`` directly or pass the shared Java
    ``unit`` mapping used by the Gateway analyzer. Diagnostic-only metadata
    such as ``owner_name`` is accepted and ignored.

    Example call:
        ``make_spring_path_resolver(configuration=spring_path_configuration)``
        returns a configuration-bound path callback for sibling analyzers.
    """

    def apply(
        path: str,
        source_file: str | None = None,
        **metadata: Any,
    ) -> str | None:
        """Resolve one analyzer path using its source and endpoint surface metadata.

        Example call:
            ``resolver(
                path="/items",
                source_file="/workspace/shop/src/main/java/com/acme/ItemsController.java",
                surface="server",
            )``
            resolves one analyzer path using its source and endpoint surface metadata.
        """

        unit = metadata.pop("unit", None)
        metadata.pop("owner_name", None)
        if source_file is None and isinstance(unit, Mapping):
            source_file = unit.get("source_path")
        if not isinstance(source_file, str) or not source_file:
            return None
        endpoint_metadata = {
            key: metadata[key]
            for key in ("technology", "protocol", "surface", "direction")
            if key in metadata
        }
        return resolve_spring_endpoint_path(
            path, source_file, configuration, **endpoint_metadata
        )

    return apply


def apply_spring_path_configuration(
    endpoints: Iterable[EndpointFact],
    configuration: SpringWorkspacePathConfiguration,
) -> tuple[EndpointFact, ...]:
    """Return Spring facts with project configuration applied exactly once.

    Example call:
        ``apply_spring_path_configuration(
            endpoints=(items_endpoint, duplicate_items_endpoint),
            configuration=spring_path_configuration,
        )``
        returns Spring facts with project configuration applied exactly once.
    """

    configured: list[EndpointFact] = []
    for endpoint in endpoints:
        if endpoint.technology != "spring":
            configured.append(endpoint)
            continue
        source_file = str(endpoint.project_source_file or endpoint.source_file)
        client_path_layers = endpoint.spring_client_path_layers
        if (
            endpoint.protocol == "http"
            and endpoint.surface == "client"
            and endpoint.direction == "outbound"
            and client_path_layers is not None
        ):
            resolved = _apply_spring_client_paths(
                client_path_layers,
                source_file,
                configuration,
            )
        else:
            resolved = resolve_spring_endpoint_path(
                endpoint.path,
                source_file,
                configuration,
                technology=endpoint.technology,
                protocol=endpoint.protocol,
                surface=endpoint.surface,
                direction=endpoint.direction or "inbound",
            )
        if resolved is None:
            _log(
                "malformed or exhausted placeholder path in "
                f"{endpoint.source_file} for {endpoint.handler_name}",
            )
            continue
        configured.append(
            replace(
                endpoint,
                path=resolved,
                spring_client_path_layers=None,
            )
        )
    return tuple(configured)


def _iter_resource_handler_configurer_methods(
    workspace: Mapping[str, Any],
) -> Iterable[tuple[Mapping[str, Any], Mapping[str, Any], Any, Any, str, Any]]:
    """Yield canonical WebMvcConfigurer registration methods with exact ownership.

    Example call:
        ``_iter_resource_handler_configurer_methods(workspace=java_workspace)``
        yields canonical WebMvcConfigurer registration methods with exact ownership.
    """

    for source_path in sorted(workspace.get("compilation_units", {})):
        unit = workspace["compilation_units"][source_path]
        for type_info in sorted(
            unit["type_infos"].values(), key=lambda info: info["node"].start_byte
        ):
            type_node = type_info["node"]
            if (
                type_node.type != "class_declaration"
                or type_info["abstract"]
                or not type_info["workspace_visible"]
            ):
                continue
            owner_fqn = qualified_type_name(unit, type_info)
            declarations = workspace["type_declarations"].get(owner_fqn, [])
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                continue
            genuine_interfaces = [
                node
                for node in _direct_interface_types(type_node)
                if _known_type(unit, node, "WebMvcConfigurer")
            ]
            if len(genuine_interfaces) != 1:
                continue
            body = _field(type_node, "body")
            if body is None:
                continue
            for method in body.named_children:
                if method.type != "method_declaration":
                    continue
                name_node = _field(method, "name")
                return_type = _field(method, "type")
                parameters = _field(method, "parameters")
                method_body = _field(method, "body")
                if (
                    None in (name_node, return_type, parameters, method_body)
                    or _text(unit, name_node) != "addResourceHandlers"
                    or _text(unit, return_type).strip() != "void"
                    or "public" not in declaration_modifier_names(method)
                    or "static" in declaration_modifier_names(method)
                ):
                    continue
                formals = [
                    child
                    for child in parameters.named_children
                    if child.type == "formal_parameter"
                ]
                if len(formals) != 1 or len(parameters.named_children) != 1:
                    continue
                parameter_type = _field(formals[0], "type")
                parameter_name = _field(formals[0], "name")
                if (
                    parameter_type is None
                    or parameter_name is None
                    or not _known_type(
                        unit, parameter_type, "ResourceHandlerRegistry"
                    )
                ):
                    continue
                yield (
                    unit,
                    type_info,
                    method,
                    method_body,
                    _text(unit, parameter_name),
                    parameters,
                )


def _invocation_name(unit: Mapping[str, Any], invocation: Any) -> str:
    """Read a candidate invocation name for bounded registration matching.

    Example call:
        ``_invocation_name(unit=items_unit, invocation=registration_call_node)``
        reads a candidate invocation name for bounded registration matching.
    """

    name = _field(invocation, "name")
    return _text(unit, name) if name is not None else ""


def _registry_is_mutated(
    unit: Mapping[str, Any],
    body: Any,
    registry_name: str,
) -> bool:
    """Reject methods where the proven registry parameter loses stable identity.

    Example call:
        ``_registry_is_mutated(
            unit=items_unit,
            body=configure_method_body_node,
            registry_name="registry",
        )``
        rejects methods where the proven registry parameter loses stable identity.
    """

    for node in _walk(body):
        if node.type == "assignment_expression":
            left = _field(node, "left")
            if (
                left is not None
                and left.type == "identifier"
                and _text(unit, left) == registry_name
            ):
                return True
        if node.type == "update_expression" and any(
            child.type == "identifier" and _text(unit, child) == registry_name
            for child in node.named_children
        ):
            return True
    return False


def _deduplicate(
    endpoints: Iterable[EndpointFact],
) -> tuple[EndpointFact, ...]:
    """Merge exact static-handler duplicates while retaining private evidence.

    Example call:
        ``_deduplicate(endpoints=(items_endpoint, duplicate_items_endpoint))``
        merges exact static-handler duplicates while retaining private evidence.
    """

    return deduplicate_endpoint_facts(
        endpoints,
        lambda endpoint: (
            endpoint.path,
            endpoint.method,
            endpoint.parameters,
            endpoint.source_file,
            endpoint.source_line,
            endpoint.handler_name,
        ),
    )


def analyze_spring_resource_handlers(
    workspace: Mapping[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return provenance-bound direct Spring MVC static-handler patterns.

    Example call:
        ``analyze_spring_resource_handlers(workspace=java_workspace)``
        returns provenance-bound direct Spring MVC static-handler patterns.
    """

    endpoints: list[EndpointFact] = []
    for unit, owner_info, method, body, registry_name, _parameters in _iter_resource_handler_configurer_methods(
        workspace
    ):
        owner = owner_info["display_name"]
        function = f"{owner}.addResourceHandlers"
        if _registry_is_mutated(unit, body, registry_name):
            _log(f"mutated ResourceHandlerRegistry in {unit['source_path']} for {function}")
            continue
        candidates = []
        for invocation in _walk(body):
            if (
                invocation.type != "method_invocation"
                or _invocation_name(unit, invocation) != "addResourceHandler"
            ):
                continue
            receiver = _field(invocation, "object")
            if (
                receiver is None
                or receiver.type != "identifier"
                or _text(unit, receiver) != registry_name
            ):
                continue
            candidates.append(invocation)

        for invocation in candidates:
            if not _direct_registration_chain(invocation, body):
                _log(f"nested resource registration in {unit['source_path']} for {function}")
                continue
            arguments = _field(invocation, "arguments")
            argument_nodes = list(arguments.named_children) if arguments is not None else []
            if not argument_nodes:
                _log(f"resource registration without paths in {unit['source_path']} for {function}")
                continue
            for argument in argument_nodes:
                value = resolve_workspace_string_expression(
                    unit, argument, workspace, owner
                )
                if value is None:
                    _log(
                        "unresolved resource-handler path in "
                        f"{unit['source_path']} for {function}: {_text(unit, argument).strip()}",
                    )
                    continue
                path = join_endpoint_paths("", ensure_path_leading_slash(value))
                # The configurer method publishes the route but carries no
                # request-method annotation; represented-target evidence still
                # links the surviving endpoint back to that exact method.
                endpoint = EndpointFact(
                    path=path,
                    method="GET",
                    parameters="",
                    source_file=unit["source_path"],
                    source_line=invocation.start_point.row + 1,
                    handler_name=function,
                    route_source_file=unit["source_path"],
                    route_source_line=invocation.start_point.row + 1,
                    handler_source_file=unit["source_path"],
                    handler_source_line=method.start_point.row + 1,
                    technology="spring",
                    protocol="http",
                    surface="static-handler",
                    direction="inbound",
                    annotation_evidence=(),
                    represented_targets=represented_target_evidence(
                        unit["source_path"], "method", method
                    ),
                )
                endpoints.append(endpoint)
                record(format_endpoint_diagnostic(endpoint))
    return _deduplicate(endpoints)


__all__ = [
    "SpringProjectPathConfiguration",
    "SpringWorkspacePathConfiguration",
    "analyze_spring_resource_handlers",
    "apply_spring_path_configuration",
    "build_spring_path_configuration",
    "make_spring_path_resolver",
    "resolve_spring_endpoint_path",
]
