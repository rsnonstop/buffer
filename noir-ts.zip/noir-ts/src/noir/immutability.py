"""Recursive snapshots for data crossing immutable application boundaries.

Logic guide: ``p6.logic/01-mental-model.md`` (immutable internal fact view) and
``p6.logic/07-output-evidence-reports.md`` (non-mutating consolidation).
"""

from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType
from typing import Any


def freeze_data(value: Any) -> Any:
    """Detach and recursively freeze data crossing an application boundary.

    Mappings become read-only proxies, sequences become tuples, and sets become
    frozensets. Unknown scalar/object leaves are intentionally preserved as-is.
    The snapshot has no reverse conversion: a mutable presentation value must
    be constructed explicitly at the boundary that needs it.

    Example call:
        ``freeze_data({"frameworks": ["spring"], "lines": {42}})`` returns a
        read-only mapping whose ``frameworks`` value is ``("spring",)`` and
        whose ``lines`` value is ``frozenset({42})``.
    """

    if isinstance(value, Mapping):
        return MappingProxyType(
            {key: freeze_data(item) for key, item in value.items()}
        )
    if isinstance(value, (list, tuple)):
        return tuple(freeze_data(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(freeze_data(item) for item in value)
    return value


__all__ = ["freeze_data"]
