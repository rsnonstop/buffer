"""Build and query the project-scoped JAX-RS deployment model.

The shared Java workspace owns annotation/type provenance. This module consumes
only its already validated ``ApplicationPath`` facts, associates them with
source projects, overlays bounded ``web.xml`` servlet mappings, and selects
one base path for a resource. Both the direct and hierarchy/subresource
analyzers call the deployment selector, so one configured workspace is
authoritative for all JAX-RS HTTP endpoint facts. Source ``ApplicationPath``
declarations and bounded ``web.xml`` servlet mappings are coalesced into
deployment prefixes; this module does not discover resource or method routes
itself.

Logic guide: ``p6.logic/06-jax-rs.md``.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree

from .contracts import IGNORED_SOURCE_DIRECTORIES
from .diagnostics import record


PROJECT_MARKERS = (
    ("src", "main", "java"),
    ("src", "main", "resources"),
    ("src", "main", "webapp"),
)
APPLICATION_INIT_PARAMS = {
    "javax.ws.rs.Application",
    "jakarta.ws.rs.Application",
}
CORE_APPLICATION_CLASSES = {
    "javax.ws.rs.core.Application",
    "jakarta.ws.rs.core.Application",
}
MAX_WEB_XML_BYTES = 10 * 1024 * 1024

__all__ = [
    "APPLICATION_INIT_PARAMS",
    "CORE_APPLICATION_CLASSES",
    "MAX_WEB_XML_BYTES",
    "PROJECT_MARKERS",
    "build_jax_rs_deployment_model",
    "discover_web_xml_files",
    "infer_application_package_from_class_name",
    "infer_jax_rs_project_root",
    "is_jax_rs_application_class_name",
    "is_jax_rs_servlet_class",
    "normalize_servlet_mapping_prefix",
    "parse_jax_rs_web_xml_mappings",
    "select_jax_rs_deployment_prefix",
]


def _absolute_path(path: str | os.PathLike[str], analysis_root: str) -> str:
    """Anchor a descriptor/source path to the explicit analysis root."""

    value = os.fspath(path)
    if not os.path.isabs(value):
        value = os.path.join(analysis_root, value)
    return os.path.normpath(os.path.abspath(value))


def infer_jax_rs_project_root(
    path: str | os.PathLike[str], analysis_root: str | os.PathLike[str]
) -> str:
    """Return the source project containing ``path``.

    A standard main-source marker owns the path.  Nonstandard layouts fall
    back to the explicit analysis root instead of borrowing configuration from
    a sibling source directory.
    """

    fallback = os.path.normpath(os.path.abspath(os.fspath(analysis_root)))
    absolute = Path(_absolute_path(path, fallback))
    parts = absolute.parts
    for index in range(max(0, len(parts) - 2)):
        if tuple(parts[index : index + 3]) in PROJECT_MARKERS:
            prefix = parts[:index]
            return os.path.normpath(os.fspath(Path(*prefix))) if prefix else os.path.sep
    return fallback


def _is_test_path(path: str, analysis_root: str) -> bool:
    """Exclude test and integration-test descriptors from deployment evidence."""

    relative = os.path.relpath(path, start=analysis_root).replace("\\", "/")
    wrapped = f"/{relative.strip('/')}/"
    return "/src/test/" in wrapped or "/src/it/" in wrapped


def discover_web_xml_files(
    analysis_root: str | os.PathLike[str], ignored_dirs: Iterable[str] = ()
) -> list[str]:
    """Find regular, non-test files whose basename is exactly ``web.xml``."""

    root = os.path.normpath(os.path.abspath(os.fspath(analysis_root)))
    ignored = set(ignored_dirs)
    discovered: list[str] = []
    for current_root, directory_names, file_names in os.walk(root):
        directory_names[:] = sorted(
            name for name in directory_names if name not in ignored
        )
        if _is_test_path(current_root, root):
            directory_names[:] = []
            continue
        if "web.xml" not in file_names:
            continue
        candidate = os.path.join(current_root, "web.xml")
        if _is_test_path(candidate, root) or os.path.islink(candidate):
            continue
        try:
            if not os.path.isfile(candidate) or os.path.getsize(candidate) > MAX_WEB_XML_BYTES:
                continue
        except OSError:
            continue
        discovered.append(os.path.normpath(candidate))
    return sorted(discovered)


def _local_name(tag: object) -> str:
    """Discard XML namespace spelling before matching modeled web.xml tags."""

    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1].rsplit(":", 1)[-1]


def _children(node: ElementTree.Element, local_name: str):
    """Return direct descriptor children with the requested namespace-free name."""

    return [child for child in list(node) if _local_name(child.tag) == local_name]


def _child_text(node: ElementTree.Element, local_name: str) -> str:
    """Read the first direct modeled child as normalized descriptor text."""

    children = _children(node, local_name)
    if not children:
        return ""
    return "".join(children[0].itertext()).strip()


def is_jax_rs_servlet_class(class_name: str) -> bool:
    """Recognize the bounded servlet families that can publish JAX-RS routes."""

    if not class_name:
        return False
    return (
        "jersey" in class_name
        or "resteasy" in class_name
        or "RestEasy" in class_name
        or "JAXRSServlet" in class_name
        or "JAXRS" in class_name
        or "CxfNonSpringJaxrsServlet" in class_name
        or "CXFNonSpringJaxrsServlet" in class_name
        or class_name.endswith(".ServletContainer")
        or class_name.endswith(".HttpServletDispatcher")
    )


def is_jax_rs_application_class_name(class_name: str) -> bool:
    """Recognize a bounded source/dependency Application class spelling."""

    return bool(
        class_name
        and (
            class_name in CORE_APPLICATION_CLASSES
            or ".Application" in class_name
            or class_name.endswith("Application")
        )
    )


def infer_application_package_from_class_name(class_name: str) -> str | None:
    """Derive package-scoped deployment ownership from an Application class."""

    if (
        not is_jax_rs_application_class_name(class_name)
        or class_name in CORE_APPLICATION_CLASSES
        or is_jax_rs_servlet_class(class_name)
        or "." not in class_name
    ):
        return None
    package_name = class_name.rsplit(".", 1)[0]
    return package_name or None


def normalize_servlet_mapping_prefix(pattern: str) -> str:
    """Match Noir's bounded servlet-pattern-to-prefix normalization."""

    cleaned = pattern.strip()
    if cleaned.endswith("/*"):
        cleaned = cleaned[:-2]
    if len(cleaned) > 1 and cleaned.endswith("/"):
        cleaned = cleaned[:-1]
    if cleaned in {"/", "/*"}:
        return ""
    return cleaned if cleaned.startswith("/") else f"/{cleaned}"


def parse_jax_rs_web_xml_mappings(content: bytes | str) -> list[dict[str, Any]]:
    """Parse direct servlet declarations/mappings from one deployment file.

    The caller owns non-fatal error handling so standalone tests can assert
    malformed XML precisely.
    """

    root = ElementTree.fromstring(content)
    if _local_name(root.tag) != "web-app":
        web_apps = [node for node in list(root) if _local_name(node.tag) == "web-app"]
        if web_apps:
            root = web_apps[0]

    servlets: dict[str, dict[str, Any]] = {}
    for servlet in _children(root, "servlet"):
        name = _child_text(servlet, "servlet-name")
        if not name:
            continue
        servlet_class = _child_text(servlet, "servlet-class")
        application_classes = [servlet_class] if servlet_class else []
        for parameter in _children(servlet, "init-param"):
            if _child_text(parameter, "param-name") not in APPLICATION_INIT_PARAMS:
                continue
            value = _child_text(parameter, "param-value")
            if value:
                application_classes.append(value)
        servlets[name] = {
            "application_classes": application_classes,
            "jaxrs_servlet": is_jax_rs_servlet_class(servlet_class)
            or any(
                is_jax_rs_application_class_name(value)
                for value in application_classes
            ),
        }

    mappings: list[dict[str, Any]] = []
    for mapping in _children(root, "servlet-mapping"):
        name = _child_text(mapping, "servlet-name")
        servlet = servlets.get(name)
        if not name or servlet is None:
            continue
        for pattern_node in _children(mapping, "url-pattern"):
            pattern = "".join(pattern_node.itertext()).strip()
            if pattern:
                mappings.append(
                    {
                        "pattern": pattern,
                        "application_classes": list(servlet["application_classes"]),
                        "jaxrs_servlet": servlet["jaxrs_servlet"],
                    }
                )
    return mappings


def _application_key(application: dict[str, Any], analysis_root: str):
    """Identify a source application by project, package, and API namespace."""

    return (
        infer_jax_rs_project_root(application["source_path"], analysis_root),
        application["package"],
        application["namespace"],
    )


def _has_project_marker(path: str | os.PathLike[str]) -> bool:
    """Report whether standard layout evidence identifies a source project."""

    parts = Path(os.path.abspath(os.fspath(path))).parts
    return any(
        tuple(parts[index : index + 3]) in PROJECT_MARKERS
        for index in range(max(0, len(parts) - 2))
    )


def _coalesce_source_application_prefixes(
    applications: list[dict[str, Any]], analysis_root: str
):
    """Merge equal source ApplicationPath facts and retain ambiguity as None."""

    grouped: dict[tuple[str, str, str], list[str | None]] = {}
    for application in applications:
        grouped.setdefault(_application_key(application, analysis_root), []).append(
            application.get("path")
        )
    result: dict[tuple[str, str, str | None], str | None] = {}
    for key, paths in grouped.items():
        valid = {path for path in paths if path is not None}
        result[key] = (
            next(iter(valid))
            if len(valid) == 1 and all(path is not None for path in paths)
            else None
        )
    return result


def _index_source_applications_by_class_name(
    applications: list[dict[str, Any]], analysis_root: str
) -> dict[str, tuple[tuple[str, str, str], ...]]:
    """Map servlet class references back to exact source application keys."""

    index: dict[str, set[tuple[str, str, str]]] = {}
    for application in applications:
        key = _application_key(application, analysis_root)
        for name in (application.get("simple_name"), application.get("fqn")):
            if name:
                index.setdefault(name, set()).add(key)
    return {name: tuple(sorted(keys)) for name, keys in sorted(index.items())}


def _resolve_mapping_application_keys(
    class_names: Iterable[str],
    class_index: dict[str, tuple[tuple[str, str, str], ...]],
    project_root: str,
) -> set[tuple[str, str, str | None]]:
    """Associate one servlet mapping with project-local application identities."""

    keys: set[tuple[str, str, str | None]] = set()
    for class_name in class_names:
        known = class_index.get(class_name)
        if known is not None:
            matching = {key for key in known if key[0] == project_root}
            if matching:
                keys.update(matching)
                continue
            # A same-named source application in another project must not
            # suppress this project's web.xml package-name association.  The
            # configured class can come from a dependency rather than source.
        package_name = infer_application_package_from_class_name(class_name)
        if package_name:
            keys.add((project_root, package_name, None))
    return keys


def build_jax_rs_deployment_model(
    workspace: dict[str, Any], analysis_root: str | os.PathLike[str]
) -> dict[str, Any]:
    """Build and attach the project/application/servlet-prefix index."""

    normalized_analysis_root = os.path.normpath(
        os.path.abspath(os.fspath(analysis_root))
    )
    applications = list(workspace.get("jax_rs_applications", ()))
    deployment_prefixes_by_application_key = _coalesce_source_application_prefixes(
        applications, normalized_analysis_root
    )
    applications_by_class_name = _index_source_applications_by_class_name(
        applications, normalized_analysis_root
    )
    xml_configured_application_keys: set[tuple[str, str, str | None]] = set()
    explicit_prefixes_by_application_key: dict[
        tuple[str, str, str | None], set[str]
    ] = {}
    unassociated_prefixes_by_project: dict[str, list[str]] = {}

    for xml_file in discover_web_xml_files(
        normalized_analysis_root, IGNORED_SOURCE_DIRECTORIES
    ):
        project_root = infer_jax_rs_project_root(xml_file, normalized_analysis_root)
        try:
            with open(xml_file, "rb") as source_file:
                mappings = parse_jax_rs_web_xml_mappings(source_file.read())
        except (OSError, ElementTree.ParseError, ValueError) as error:
            record(
                f"Skipped JAX-RS malformed web.xml {xml_file}: {error}"
            )
            continue

        for mapping in mappings:
            deployment_prefix = normalize_servlet_mapping_prefix(mapping["pattern"])
            keys = _resolve_mapping_application_keys(
                mapping["application_classes"],
                applications_by_class_name,
                project_root,
            )
            if not keys:
                if mapping["jaxrs_servlet"]:
                    unassociated_prefixes_by_project.setdefault(
                        project_root, []
                    ).append(deployment_prefix)
                continue
            for key in keys:
                explicit_prefixes_by_application_key.setdefault(key, set()).add(
                    deployment_prefix
                )
                xml_configured_application_keys.add(key)

    for key, prefixes in explicit_prefixes_by_application_key.items():
        # Explicit servlet mappings override source ApplicationPath, but only
        # an agreed prefix remains usable; disagreement is represented by None.
        deployment_prefixes_by_application_key[key] = (
            next(iter(prefixes)) if len(prefixes) == 1 else None
        )

    for project_root, prefixes in unassociated_prefixes_by_project.items():
        unique_prefixes = set(prefixes)
        if len(unique_prefixes) != 1:
            continue
        if any(key[0] == project_root for key in xml_configured_application_keys):
            continue
        fallback_prefix = next(iter(unique_prefixes))
        for keys in applications_by_class_name.values():
            for key in keys:
                if key[0] == project_root:
                    deployment_prefixes_by_application_key[key] = fallback_prefix

    deployment_model = {
        "analysis_root": normalized_analysis_root,
        "deployment_prefixes": deployment_prefixes_by_application_key,
        "applications_by_class_name": applications_by_class_name,
        "xml_configured_application_keys": xml_configured_application_keys,
    }
    workspace["jax_rs_deployment_model"] = deployment_model
    return deployment_model


def _package_is_ancestor(ancestor: str, package: str) -> bool:
    """Test whether an application package may own the resource package."""

    return not ancestor or package == ancestor or package.startswith(f"{ancestor}.")


def _package_specificity(package: str) -> int:
    """Rank candidate applications by the number of package segments."""

    return len(package.split(".")) if package else 0


def select_jax_rs_deployment_prefix(
    deployment_model: dict[str, Any],
    unit: dict[str, Any],
    namespace: str,
    owner_name: str,
) -> str | None:
    """Select the longest package-scoped prefix inside the resource project."""

    project_root = infer_jax_rs_project_root(
        unit["source_path"], deployment_model["analysis_root"]
    )
    candidates = [
        (key, path)
        for key, path in deployment_model["deployment_prefixes"].items()
        if key[0] == project_root
        and key[2] in {None, namespace}
        and _package_is_ancestor(key[1], unit["package"])
    ]
    if not candidates:
        # Preserve the established single-application fallback for a
        # nonstandard source layout. Once multiple projects are identifiable,
        # never leak one module's deployment base into another.
        project_roots = {
            key[0] for key in deployment_model["deployment_prefixes"]
        }
        all_candidates = [
            (key, path)
            for key, path in deployment_model["deployment_prefixes"].items()
            if key[2] in {None, namespace}
        ]
        valid_paths = {
            path for _key, path in all_candidates if path is not None
        }
        if (
            not _has_project_marker(unit["source_path"])
            and len(project_roots) == 1
            and project_roots == {project_root}
            and len(valid_paths) == 1
            and all(path is not None for _key, path in all_candidates)
        ):
            return next(iter(valid_paths))
        return ""
    specificity = max(_package_specificity(key[1]) for key, _path in candidates)
    candidates = [
        (key, path)
        for key, path in candidates
        if _package_specificity(key[1]) == specificity
    ]
    explicit = [
        item
        for item in candidates
        if item[0] in deployment_model["xml_configured_application_keys"]
    ]
    # Descriptor evidence wins at equal package specificity; otherwise the
    # exact Javax/Jakarta family wins over namespace-neutral XML inference.
    if explicit:
        candidates = explicit
    else:
        exact_namespace = [item for item in candidates if item[0][2] == namespace]
        if exact_namespace:
            candidates = exact_namespace
    paths = {path for _key, path in candidates if path is not None}
    if len(paths) == 1 and all(path is not None for _key, path in candidates):
        return next(iter(paths))
    record(
        "Skipped JAX-RS ambiguous JAX-RS deployment prefix in "
        f"{unit['source_path']} for {owner_name}"
    )
    return None
