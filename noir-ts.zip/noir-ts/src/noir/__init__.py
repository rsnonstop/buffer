"""Noir's small application core.

Framework extraction and artifact rendering live at the package edges; the
types exported here are the stable vocabulary shared between those stages.

Logic guide: ``p6.logic/01-mental-model.md`` and
``p6.logic/11-naming-and-code-vocabulary.md``.
"""

from .model import (
    AnalysisDiagnostic,
    AnalysisRequest,
    AnalysisResult,
    AnnotationEvidence,
    EndpointFact,
    FrameworkMode,
    FrameworkPlan,
    FrameworkSelection,
    SourceFile,
    SourceSpan,
    SourceTarget,
)
from .application import analyze
from .output import EndpointRowCandidate

__all__ = [
    "AnalysisDiagnostic",
    "AnalysisRequest",
    "AnalysisResult",
    "analyze",
    "AnnotationEvidence",
    "EndpointFact",
    "EndpointRowCandidate",
    "FrameworkMode",
    "FrameworkPlan",
    "FrameworkSelection",
    "SourceFile",
    "SourceSpan",
    "SourceTarget",
]
