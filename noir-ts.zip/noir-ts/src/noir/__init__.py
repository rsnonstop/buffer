"""Noir's small application core.

Framework extraction and artifact rendering live at the package edges. The
stable model vocabulary loads eagerly; the application and output convenience
exports load only when a caller asks for them, so importing a neutral submodule
does not initialize every analyzer.

Logic guide: ``p6.logic/01-mental-model.md`` and
``p6.logic/11-naming-and-code-vocabulary.md``.
"""

from typing import TYPE_CHECKING, Any

from .model import (
    AnalysisDiagnostic,
    AnalysisRequest,
    AnalysisResult,
    AnnotationEvidence,
    EndpointFact,
    FrameworkMode,
    FrameworkPlan,
    FrameworkSelection,
    SourceFile,
    SourceSpan,
    SourceTarget,
)

if TYPE_CHECKING:
    from .application import analyze as analyze
    from .output import EndpointRowCandidate as EndpointRowCandidate


def __getattr__(name: str) -> Any:
    """Load the two non-model package exports only when explicitly requested.

    The resolved object is cached in the module globals, so later access is an
    ordinary attribute lookup. Unknown names retain Python's normal package
    behavior, including explicit imports such as ``from noir import jaxrs``.

    Example call:
        ``from noir import analyze`` loads :mod:`noir.application` and returns
        its typed ``analyze`` boundary; ``import noir.model`` does not.
    """

    if name == "analyze":
        from .application import analyze

        value = analyze
    elif name == "EndpointRowCandidate":
        from .output import EndpointRowCandidate

        value = EndpointRowCandidate
    else:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Advertise lazy public exports before their first attribute access.

    Example call:
        ``dir(noir)`` includes ``"analyze"`` and ``"EndpointRowCandidate"``
        without importing their application and output modules.
    """

    return sorted(set(globals()) | set(__all__))


__all__ = [
    "AnalysisDiagnostic",
    "AnalysisRequest",
    "AnalysisResult",
    "analyze",
    "AnnotationEvidence",
    "EndpointFact",
    "EndpointRowCandidate",
    "FrameworkMode",
    "FrameworkPlan",
    "FrameworkSelection",
    "SourceFile",
    "SourceSpan",
    "SourceTarget",
]
