"""Spring MVC mapping and composed-annotation semantics.

This module owns Spring's direct mapping language and its interpretation of
source-defined annotations and AliasFor graphs. Framework-neutral Java
structure, resolution, and run-local diagnostics come directly from their
owning modules.

Logic guide: ``p6.logic/04-spring-mvc.md``.
"""

from __future__ import annotations

import re
from typing import Any

from .contracts import (
    METHOD_ANNOTATION_FAMILY_BY_IDENTITY,
    SPRING_ALIAS_FOR_PACKAGE,
    SPRING_HTTP_METHODS,
    SPRING_MAPPING_METHODS,
    SPRING_MAPPING_PACKAGE,
    SPRING_MAX_COMPOSED_ANNOTATION_DEPTH,
    SPRING_REQUEST_MAPPING_ATTRIBUTES,
)
from .diagnostics import format_endpoint_diagnostic, record
from .evidence import (
    method_annotation_evidence_from_mapping,
    represented_target_evidence,
)
from .java_frontend import (
    annotation_value_nodes,
    first_capture,
    get_annotation_arguments,
    lexical_type_chain,
    node_text,
    parameter_list_source_text,
    resolve_known_annotation,
    resolve_known_type,
    tree_node_key,
    unwrap_parenthesized_node,
    visible_local_type_names,
)
from .java_workspace import (
    annotation_definition_is_method_applicable,
    custom_annotation_identity_candidates,
    retention_is_runtime,
    resolve_workspace_string_expression,
    static_member_resolves_to,
    workspace_type_accessible,
)
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths


def resolve_spring_mapping_name(
    unit,
    annotation_name_node,
):
    """Resolve an annotation spelling to one genuine built-in Spring mapping.

    Example call:
        ``resolve_spring_mapping_name(unit=items_unit, annotation_name_node=mapping_name_node)``
        resolves an annotation spelling to one genuine built-in Spring mapping.
    """

    source = unit["source"]
    imports = unit["imports"]
    spelling = node_text(source, annotation_name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in SPRING_MAPPING_METHODS:
        return None

    expected = f"{SPRING_MAPPING_PACKAGE}.{simple_name}"
    if "." in spelling:
        return simple_name if spelling == expected else None
    if simple_name in visible_local_type_names(unit, annotation_name_node):
        return None

    explicit = imports["exact"].get(simple_name)
    if explicit is not None:
        return simple_name if explicit == expected else None
    if simple_name in unit.get("package_types", set()):
        return None
    if SPRING_MAPPING_PACKAGE in imports["wildcards"]:
        wildcard_sources = unit.get("wildcard_source_types", {}).get(
            simple_name, set()
        )
        if wildcard_sources - {expected}:
            return None
        return simple_name
    return None


def get_spring_annotation_paths(
    unit,
    annotation_node,
    workspace,
    owner_name,
):
    """Decode coherent positional/value/path aliases into ordered path fan-out.

    Example call:
        ``get_spring_annotation_paths(
            unit=items_unit,
            annotation_node=mapping_annotation_node,
            workspace=java_workspace,
            owner_name="ItemsController",
        )``
        decodes coherent positional/value/path aliases into ordered path fan-out.
    """

    source = unit["source"]

    positional, named = get_annotation_arguments(annotation_node)
    if len(positional) > 1 or (positional and "value" in named):
        return {
            "values": [],
            "unresolved": ["invalid positional/value alias declaration"],
            "present": True,
        }

    explicit_nodes = []
    if positional:
        explicit_nodes.append(("value", positional[0]))
    for attribute in ("value", "path"):
        if attribute in named:
            explicit_nodes.append((attribute, named[attribute]))
    if not explicit_nodes:
        return {"values": [""], "unresolved": [], "present": False}

    resolved_aliases = []
    unresolved = []
    for attribute, explicit_node in explicit_nodes:
        current_values = []
        value_nodes = annotation_value_nodes(explicit_node)
        if not value_nodes:
            current_values.append("")
        for value_node in value_nodes:
            value = resolve_workspace_string_expression(
                unit,
                value_node,
                workspace,
                owner_name,
            )
            if value is None:
                unresolved.append(node_text(source, value_node).strip())
            else:
                current_values.append(value)
        resolved_aliases.append((attribute, tuple(current_values)))

    if unresolved:
        return {"values": [], "unresolved": unresolved, "present": True}
    if len({values for _attribute, values in resolved_aliases}) != 1:
        return {
            "values": [],
            "unresolved": ["conflicting explicit path/value aliases"],
            "present": True,
        }
    raw_values = resolved_aliases[0][1]
    return {
        "values": list(
            dict.fromkeys(ensure_path_leading_slash(value) for value in raw_values)
        ) or [""],
        "unresolved": [],
        "present": True,
    }


def resolve_spring_request_method_expression(
    unit,
    value_node,
):
    """Resolve one genuine RequestMethod enum member without guessing imports.

    Example call:
        ``resolve_spring_request_method_expression(
            unit=items_unit,
            value_node=route_value_node,
        )``
        resolves one genuine RequestMethod enum member without guessing imports.
    """

    source = unit["source"]
    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = node_text(source, current).strip()
    method_name = spelling.rsplit(".", 1)[-1]
    if method_name not in SPRING_HTTP_METHODS:
        return None
    expected_owner = f"{SPRING_MAPPING_PACKAGE}.RequestMethod"
    if "." not in spelling:
        return (
            method_name
            if static_member_resolves_to(unit, method_name, expected_owner, current)
            else None
        )

    qualifier = spelling.rsplit(".", 1)[0]
    return (
        method_name
        if resolve_known_type(
            unit,
            qualifier,
            "RequestMethod",
            (SPRING_MAPPING_PACKAGE,),
            current,
        )
        == SPRING_MAPPING_PACKAGE
        else None
    )


def get_spring_request_methods(
    unit,
    annotation_node,
):
    """Decode RequestMapping's optional method condition and unresolved members.

    Example call:
        ``get_spring_request_methods(unit=items_unit, annotation_node=mapping_annotation_node)``
        decodes RequestMapping's optional method condition and unresolved members.
    """

    source = unit["source"]
    _positional, named = get_annotation_arguments(annotation_node)
    method_node = named.get("method")
    if method_node is None:
        return {"values": [], "unresolved": [], "present": False}

    value_nodes = annotation_value_nodes(method_node)
    if not value_nodes:
        return {"values": [], "unresolved": [], "present": True}

    methods = []
    unresolved = []
    for value_node in value_nodes:
        expression = node_text(source, value_node).strip()
        method_name = resolve_spring_request_method_expression(unit, value_node)
        if method_name is not None:
            methods.append(method_name)
        else:
            unresolved.append(expression)
    return {"values": ordered_http_methods(methods), "unresolved": unresolved, "present": True}


def ordered_http_methods(methods):
    """Deduplicate request methods in the stable Spring analyzer order.

    Example call:
        ``ordered_http_methods(methods=("GET", "POST"))``
        deduplicates request methods in the stable Spring analyzer order.
    """

    method_set = set(methods)
    return [method for method in SPRING_HTTP_METHODS if method in method_set]


def union_request_method_conditions(class_methods, method_methods):
    """Compose type/method conditions using Noir's documented ordered union.

    Example call:
        ``union_request_method_conditions(class_methods=("GET",), method_methods=("POST",))``
        composes type/method conditions using Noir's documented ordered union.
    """

    if not class_methods:
        return list(method_methods)
    if not method_methods:
        return list(class_methods)
    return ordered_http_methods([*class_methods, *method_methods])


def log_unresolved_mapping(source_path, owner_name, mapping_name, value_kind, expressions):
    """Record every unresolved value that invalidates or narrows a mapping.

    Example call:
        ``log_unresolved_mapping(
            source_path="/workspace/shop/src/main/java/com/acme/ItemsController.java",
            owner_name="ItemsController",
            mapping_name="mappingInfo",
            value_kind="path",
            expressions=("ROOT",),
        )``
        records every unresolved value that invalidates or narrows a mapping.
    """

    for expression in expressions:
        record(
            f"Skipped unresolved Spring {value_kind} in {source_path} "
            f"for {owner_name} @{mapping_name}: {expression}"
        )


def decode_builtin_spring_mapping(
    unit,
    annotation_name_node,
    annotation_node,
    workspace,
    lexical_owner_name,
    diagnostic_owner_name=None,
):
    """Decode one proven built-in mapping into paths, verbs, validity, and evidence.

    Example call:
        ``decode_builtin_spring_mapping(
            unit=items_unit,
            annotation_name_node=mapping_name_node,
            annotation_node=mapping_annotation_node,
            workspace=java_workspace,
            lexical_owner_name="ItemsController",
        )``
        decodes one proven built-in mapping into paths, verbs, validity, and evidence.
    """

    source_path = unit["source_path"]

    mapping_name = resolve_spring_mapping_name(
        unit,
        annotation_name_node,
    )
    if mapping_name is None:
        return None

    paths = get_spring_annotation_paths(
        unit,
        annotation_node,
        workspace,
        lexical_owner_name,
    )
    diagnostic_owner_name = diagnostic_owner_name or lexical_owner_name
    if paths["unresolved"]:
        log_unresolved_mapping(
            source_path,
            diagnostic_owner_name,
            mapping_name,
            "path",
            paths["unresolved"],
        )

    if mapping_name == "RequestMapping":
        methods = get_spring_request_methods(unit, annotation_node)
        if methods["unresolved"]:
            log_unresolved_mapping(
                source_path,
                diagnostic_owner_name,
                mapping_name,
                "method",
                methods["unresolved"],
            )
    else:
        methods = {
            "values": [SPRING_MAPPING_METHODS[mapping_name]],
            "unresolved": [],
            "present": False,
        }

    valid = bool(paths["values"]) and not (
        methods["present"] and methods["unresolved"] and not methods["values"]
    )
    return {
        "name": mapping_name,
        "paths": paths["values"],
        "methods": methods["values"],
        "valid": valid,
        "annotation_node": annotation_node,
        "annotation_identity": f"{SPRING_MAPPING_PACKAGE}.{mapping_name}",
        "annotation_family": METHOD_ANNOTATION_FAMILY_BY_IDENTITY[
            f"{SPRING_MAPPING_PACKAGE}.{mapping_name}"
        ],
    }


def first_spring_mapping(
    unit,
    candidates,
    workspace,
    lexical_owner_name,
    diagnostic_owner_name=None,
):
    """Select the first recognized built-in/composed mapping in source order.

    Example call:
        ``first_spring_mapping(
            unit=items_unit,
            candidates=mapping_candidates,
            workspace=java_workspace,
            lexical_owner_name="ItemsController",
        )``
        selects the first recognized built-in/composed mapping in source order.
    """

    for captures in sorted(
        candidates,
        key=lambda item: first_capture(item, "annotation.node").start_byte,
    ):
        mapping = decode_builtin_spring_mapping(
            unit,
            first_capture(captures, "annotation.name"),
            first_capture(captures, "annotation.node"),
            workspace,
            lexical_owner_name,
            diagnostic_owner_name,
        )
        if mapping is not None:
            # Recognized-invalid is still the first mapping and suppresses any
            # later valid annotation on this declaration.
            return mapping
        composed = decode_spring_composed_mapping(
            unit["source_path"],
            unit,
            first_capture(captures, "annotation.name"),
            first_capture(captures, "annotation.node"),
            lexical_owner_name,
            diagnostic_owner_name or lexical_owner_name,
            workspace,
        )
        if composed is not None:
            return composed
    return None


def compose_lexical_type_mapping(type_key, type_infos):
    """Compose outer-to-inner type path layers and ordered method conditions.

    Example call:
        ``compose_lexical_type_mapping(
            type_key=(40, 180),
            type_infos=items_unit["type_infos"],
        )``
        composes outer-to-inner type path layers and ordered method conditions.
    """

    paths = [""]
    methods = []
    for info in lexical_type_chain(type_key, type_infos):
        mapping = info["mapping"]
        if mapping is None:
            continue
        if not mapping["valid"]:
            # One invalid recognized lexical layer suppresses every endpoint below it.
            return None
        paths = [
            join_endpoint_paths(base_path, current_path)
            for base_path in paths
            for current_path in mapping["paths"]
        ]
        methods = union_request_method_conditions(methods, mapping["methods"])
    return {"paths": list(dict.fromkeys(paths)), "methods": methods}


def analyze_direct_spring_mvc_unit(
    unit: dict[str, Any],
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Extract supported Spring MVC routes from one shared compilation unit.

    Example call:
        ``analyze_direct_spring_mvc_unit(unit=items_unit, workspace=java_workspace)``
        extracts supported Spring MVC routes from one shared compilation unit.
    """

    source_path = unit["source_path"]
    record(f"{source_path}:")
    source = unit["source"]
    # Mapping composition is analysis-local mutable state. Copy the records
    # while retaining their immutable Tree-sitter node identities.
    type_infos = {key: dict(info) for key, info in unit["type_infos"].items()}
    type_candidates = unit["type_candidates"]
    method_candidates = unit["method_candidates"]
    record_component_candidates = unit["record_component_candidates"]
    record_explicit_accessors = unit["record_explicit_accessors"]

    for type_key, info in type_infos.items():
        info["mapping"] = first_spring_mapping(
            unit,
            type_candidates.get(type_key, []),
            workspace,
            info["display_name"],
        )

    endpoints = []
    for method_key in sorted(method_candidates):
        candidates = method_candidates[method_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        method_node = first_capture(representative, "method.node")
        method_name_node = first_capture(representative, "method.name")
        parameters_node = first_capture(representative, "method.parameters")
        if None in (type_node, method_node, method_name_node, parameters_node):
            continue

        owner_key = tree_node_key(type_node)
        owner_info = type_infos.get(owner_key)
        if (
            owner_info is None
            or owner_info["abstract"]
            or not owner_info["workspace_visible"]
        ):
            continue
        method_name = node_text(source, method_name_node)
        owner_name = f"{owner_info['display_name']}.{method_name}"
        mapping = first_spring_mapping(
            unit,
            candidates,
            workspace,
            owner_info["display_name"],
            owner_name,
        )
        if mapping is None or not mapping["valid"]:
            continue

        type_mapping = compose_lexical_type_mapping(owner_key, type_infos)
        if type_mapping is None:
            continue
        effective_methods = union_request_method_conditions(
            type_mapping["methods"], mapping["methods"]
        ) or ["ANY"]
        parameters = parameter_list_source_text(source, parameters_node)
        line = mapping["annotation_node"].start_point.row + 1

        for base_path in type_mapping["paths"]:
            for method_path in mapping["paths"]:
                endpoint_path = join_endpoint_paths(base_path, method_path)
                for http_method in effective_methods:
                    endpoint = EndpointFact(
                        path=endpoint_path,
                        method=http_method,
                        parameters=parameters,
                        source_file=source_path,
                        source_line=line,
                        handler_name=owner_name,
                        technology="spring",
                        direction="inbound",
                        annotation_evidence=method_annotation_evidence_from_mapping(
                            mapping,
                            annotation_source_file=source_path,
                            endpoint_source_file=source_path,
                        ),
                        represented_targets=represented_target_evidence(
                            source_path, "method", method_node
                        ),
                    )
                    endpoints.append(endpoint)
                    record(format_endpoint_diagnostic(endpoint))

    for component_key in sorted(record_component_candidates):
        candidates = record_component_candidates[component_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        component_node = first_capture(representative, "component.node")
        component_name_node = first_capture(representative, "component.name")
        if None in (type_node, component_node, component_name_node):
            continue

        owner_key = tree_node_key(type_node)
        owner_info = type_infos.get(owner_key)
        if (
            owner_info is None
            or owner_info["abstract"]
            or not owner_info["workspace_visible"]
        ):
            continue
        component_name = node_text(source, component_name_node)
        if (owner_key, component_name) in record_explicit_accessors:
            continue

        owner_name = f"{owner_info['display_name']}.{component_name}"
        applicable_candidates = spring_method_applicable_component_candidates(
            unit,
            candidates,
            workspace,
            owner_info["display_name"],
        )
        mapping = first_spring_mapping(
            unit,
            applicable_candidates,
            workspace,
            owner_info["display_name"],
            owner_name,
        )
        if mapping is None or not mapping["valid"]:
            continue

        type_mapping = compose_lexical_type_mapping(owner_key, type_infos)
        if type_mapping is None:
            continue
        effective_methods = union_request_method_conditions(
            type_mapping["methods"], mapping["methods"]
        ) or ["ANY"]
        line = mapping["annotation_node"].start_point.row + 1

        for base_path in type_mapping["paths"]:
            for method_path in mapping["paths"]:
                endpoint_path = join_endpoint_paths(base_path, method_path)
                for http_method in effective_methods:
                    endpoint = EndpointFact(
                        path=endpoint_path,
                        method=http_method,
                        parameters="",
                        source_file=source_path,
                        source_line=line,
                        handler_name=owner_name,
                        technology="spring",
                        direction="inbound",
                        represented_targets=represented_target_evidence(
                            source_path, "record-component", component_node
                        ),
                    )
                    endpoints.append(endpoint)
                    record(format_endpoint_diagnostic(endpoint))

    return tuple(endpoints)


def spring_definition_runtime_retained(definition):
    """Require exactly one genuine runtime Retention on a composed layer.

    Example call:
        ``spring_definition_runtime_retained(definition=route_annotation_definition)``
        requires exactly one genuine runtime Retention on a composed layer.
    """

    unit = definition["unit"]
    retentions = [
        record
        for record in definition["meta_annotations"]
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"Retention"},
            ("java.lang.annotation",),
        )
        is not None
    ]
    return len(retentions) == 1 and retention_is_runtime(
        unit, retentions[0]["node"]
    )


def resolve_spring_mapping_spelling(unit, spelling, context_node=None):
    """Resolve a built-in mapping spelling inside one shared compilation unit.

    Example call:
        ``resolve_spring_mapping_spelling(unit=items_unit, spelling="GetMapping")``
        resolves a built-in mapping spelling inside one shared compilation unit.
    """

    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in SPRING_MAPPING_METHODS:
        return None
    expected = f"{SPRING_MAPPING_PACKAGE}.{simple_name}"
    if "." in spelling:
        return simple_name if spelling == expected else None
    if simple_name in visible_local_type_names(unit, context_node):
        return None
    explicit = unit["imports"]["exact"].get(simple_name)
    if explicit is not None:
        return simple_name if explicit == expected else None
    if simple_name in unit.get("package_types", set()):
        return None
    if SPRING_MAPPING_PACKAGE not in unit["imports"]["wildcards"]:
        return None
    if unit.get("wildcard_source_types", {}).get(simple_name, set()) - {expected}:
        return None
    return simple_name


def source_annotation_definition(
    unit,
    name_node,
    workspace,
    consumer_owner_name,
):
    """Resolve an applied custom annotation to one accessible source definition.

    Example call:
        ``source_annotation_definition(
            unit=items_unit,
            name_node=mapping_name_node,
            workspace=java_workspace,
            consumer_owner_name="ItemsController",
        )``
        resolves an applied custom annotation to one accessible source definition.
    """

    spelling = node_text(unit["source"], name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if (
        "." not in spelling
        and simple_name in SPRING_MAPPING_METHODS
        and simple_name not in unit["imports"]["exact"]
        and SPRING_MAPPING_PACKAGE in unit["imports"]["wildcards"]
        and unit.get("wildcard_source_types", {}).get(simple_name, set())
        - {f"{SPRING_MAPPING_PACKAGE}.{simple_name}"}
    ):
        return {"status": "ambiguous", "definition": None}
    identities = custom_annotation_identity_candidates(
        unit, spelling, workspace, name_node
    )
    if not identities:
        return {"status": "none", "definition": None}
    if len(identities) != 1:
        return {"status": "ambiguous", "definition": None}
    identity = next(iter(identities))
    definitions = workspace["annotation_definitions"].get(identity, [])
    if len(definitions) != 1:
        return {
            "status": "ambiguous" if definitions else "missing",
            "definition": None,
        }
    if not workspace_type_accessible(
        definitions[0], unit, consumer_owner_name
    ):
        return {"status": "inaccessible", "definition": None}
    return {"status": "resolved", "definition": definitions[0]}


def source_annotation_is_method_applicable(
    unit, annotation_record, workspace, consumer_owner_name
):
    """Prove a custom component annotation can target the implicit accessor.

    Example call:
        ``source_annotation_is_method_applicable(
            unit=items_unit,
            annotation_record=path_annotation_record,
            workspace=java_workspace,
            consumer_owner_name="ItemsController",
        )``
        proves a custom component annotation can target the implicit accessor.
    """

    resolved = source_annotation_definition(
        unit,
        annotation_record["name_node"],
        workspace,
        consumer_owner_name,
    )
    return (
        resolved["status"] == "resolved"
        and annotation_definition_is_method_applicable(resolved["definition"])
    )


def spring_method_applicable_component_candidates(
    unit,
    candidates,
    workspace,
    owner_name,
):
    """Filter record-component captures to mappings applicable to a method.

    Example call:
        ``spring_method_applicable_component_candidates(
            unit=items_unit,
            candidates=mapping_candidates,
            workspace=java_workspace,
            owner_name="ItemsController",
        )``
        filters record-component captures to mappings applicable to a method.
    """

    applicable = []
    for captures in candidates:
        name_node = first_capture(captures, "annotation.name")
        annotation_node = first_capture(captures, "annotation.node")
        if name_node is None or annotation_node is None:
            continue
        if resolve_spring_mapping_name(unit, name_node) is not None:
            applicable.append(captures)
            continue
        if source_annotation_is_method_applicable(
            unit,
            {"node": annotation_node, "name_node": name_node},
            workspace,
            owner_name,
        ):
            applicable.append(captures)
    return applicable


def collect_spring_mapping_branches(definition, workspace, stack=(), depth=0):
    """Trace bounded composed meta-annotation branches to RequestMapping leaves.

    Example call:
        ``collect_spring_mapping_branches(
            definition=route_annotation_definition,
            workspace=java_workspace,
        )``
        traces bounded composed meta-annotation branches to RequestMapping leaves.
    """

    if depth > SPRING_MAX_COMPOSED_ANNOTATION_DEPTH:
        return [], ["composed-annotation depth limit"]
    if definition["fqn"] in stack:
        return [], ["composed-annotation cycle"]

    branches = []
    errors = []
    for meta_record in definition["meta_annotations"]:
        unit = definition["unit"]
        spelling = node_text(unit["source"], meta_record["name_node"]).strip()
        mapping_name = resolve_spring_mapping_spelling(
            unit, spelling, meta_record["name_node"]
        )
        if mapping_name is not None:
            if mapping_name != "RequestMapping":
                errors.append(
                    f"@{mapping_name} cannot target an annotation declaration"
                )
                continue
            branches.append(
                {
                    "definitions": [definition],
                    "instances": [],
                    "leaf_record": meta_record,
                    "leaf_name": mapping_name,
                    "leaf_fqn": f"{SPRING_MAPPING_PACKAGE}.{mapping_name}",
                }
            )
            continue

        resolved = source_annotation_definition(
            unit,
            meta_record["name_node"],
            workspace,
            definition["type_info"]["display_name"],
        )
        if resolved["status"] == "none":
            continue
        if resolved["status"] != "resolved":
            errors.append(
                f"{resolved['status']} composed meta-annotation {spelling}"
            )
            continue
        tails, tail_errors = collect_spring_mapping_branches(
            resolved["definition"],
            workspace,
            stack + (definition["fqn"],),
            depth + 1,
        )
        errors.extend(tail_errors)
        for tail in tails:
            branches.append(
                {
                    **tail,
                    "definitions": [definition, *tail["definitions"]],
                    "instances": [
                        {
                            "record": meta_record,
                            "unit": definition["unit"],
                            "owner_name": definition["type_info"]["display_name"],
                        },
                        *tail["instances"],
                    ],
                }
            )
    return branches, errors


def decode_alias_string(unit, value_node, workspace, owner_name):
    """Resolve one AliasFor attribute name through workspace String semantics.

    Example call:
        ``decode_alias_string(
            unit=items_unit,
            value_node=route_value_node,
            workspace=java_workspace,
            owner_name="ItemsController",
        )``
        resolves one AliasFor attribute name through workspace String semantics.
    """

    value = resolve_workspace_string_expression(
        unit, value_node, workspace, owner_name
    )
    return value if value is not None else None


def resolve_alias_annotation_target(definition, value_node, workspace):
    """Resolve AliasFor.annotation to one built-in or source annotation FQN.

    Example call:
        ``resolve_alias_annotation_target(
            definition=route_annotation_definition,
            value_node=route_value_node,
            workspace=java_workspace,
        )``
        resolves AliasFor.annotation to one built-in or source annotation FQN.
    """

    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type != "class_literal" or not current.named_children:
        return None
    spelling = node_text(definition["unit"]["source"], current.named_children[0]).strip()
    mapping_name = resolve_spring_mapping_spelling(
        definition["unit"], spelling, current.named_children[0]
    )
    if mapping_name is not None:
        return f"{SPRING_MAPPING_PACKAGE}.{mapping_name}"
    identities = custom_annotation_identity_candidates(
        definition["unit"], spelling, workspace, current.named_children[0]
    )
    if len(identities) != 1:
        return None
    identity = next(iter(identities))
    definitions = workspace["annotation_definitions"].get(identity, [])
    if len(definitions) != 1 or not workspace_type_accessible(
        definitions[0],
        definition["unit"],
        definition["type_info"]["display_name"],
    ):
        return None
    return identity


def parse_spring_alias_edge(definition, element, workspace):
    """Decode one genuine AliasFor declaration as a typed graph edge.

    Example call:
        ``parse_spring_alias_edge(
            definition=route_annotation_definition,
            element=path_element_definition,
            workspace=java_workspace,
        )``
        decodes one genuine AliasFor declaration as a typed graph edge.
    """

    unit = definition["unit"]
    alias_like = [
        record
        for record in element["annotations"]
        if node_text(unit["source"], record["name_node"])
        .strip()
        .rsplit(".", 1)[-1]
        == "AliasFor"
    ]
    if not alias_like:
        return {"status": "none", "target": None, "attribute": None}
    genuine = [
        record
        for record in alias_like
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"AliasFor"},
            (SPRING_ALIAS_FOR_PACKAGE,),
        )
        is not None
    ]
    if len(alias_like) != 1 or len(genuine) != 1:
        return {"status": "invalid", "reason": "invalid @AliasFor provenance"}

    positional, named = get_annotation_arguments(genuine[0]["node"])
    if set(named) - {"value", "attribute", "annotation"} or len(positional) > 1:
        return {"status": "invalid", "reason": "unsupported @AliasFor arguments"}
    if positional and "value" in named:
        return {"status": "invalid", "reason": "duplicate @AliasFor value"}
    if "attribute" in named and (positional or "value" in named):
        return {
            "status": "invalid",
            "reason": "@AliasFor value and attribute are mutually exclusive",
        }

    value_node = named.get("value") or (positional[0] if positional else None)
    attribute_node = named.get("attribute")
    value_name = (
        decode_alias_string(unit, value_node, workspace, definition["type_info"]["display_name"])
        if value_node is not None
        else ""
    )
    attribute_name = (
        decode_alias_string(
            unit,
            attribute_node,
            workspace,
            definition["type_info"]["display_name"],
        )
        if attribute_node is not None
        else ""
    )
    if value_name is None or attribute_name is None:
        return {"status": "invalid", "reason": "unresolved @AliasFor attribute"}
    if value_name and attribute_name and value_name != attribute_name:
        return {"status": "invalid", "reason": "conflicting @AliasFor attributes"}
    target_attribute = value_name or attribute_name or element["name"]

    annotation_node = named.get("annotation")
    target = definition["fqn"]
    if annotation_node is not None:
        target = resolve_alias_annotation_target(definition, annotation_node, workspace)
        if target is None:
            return {"status": "invalid", "reason": "unresolved @AliasFor annotation"}
    return {
        "status": "resolved",
        "target": target,
        "attribute": target_attribute,
    }


def spring_alias_element_type_valid(element, canonical_attribute, definition):
    """Check that a route-output alias has the required String/RequestMethod type.

    Example call:
        ``spring_alias_element_type_valid(
            element=path_element_definition,
            canonical_attribute="path",
            definition=route_annotation_definition,
        )``
        checks that a route-output alias has the required String/RequestMethod type.
    """

    compact = re.sub(r"\s+", "", element["type_text"])
    base_type = compact[:-2] if compact.endswith("[]") else compact
    if canonical_attribute == "path":
        return resolve_known_type(
            definition["unit"],
            base_type,
            "String",
            ("java.lang",),
            element["type_node"],
        ) == "java.lang"
    if canonical_attribute != "method":
        return False
    return resolve_known_type(
        definition["unit"],
        base_type,
        "RequestMethod",
        (SPRING_MAPPING_PACKAGE,),
        element["type_node"],
    ) == SPRING_MAPPING_PACKAGE


def spring_alias_non_output_type_valid(element, expected_type, definition):
    """Validate ignored RequestMapping attribute aliases without emitting them.

    Example call:
        ``spring_alias_non_output_type_valid(
            element=path_element_definition,
            expected_type="java.lang.String[]",
            definition=route_annotation_definition,
        )``
        validates ignored RequestMapping attribute aliases without emitting them.
    """

    compact = re.sub(r"\s+", "", element["type_text"])
    if expected_type == "string_array":
        if compact.endswith("[]"):
            compact = compact[:-2]
    elif compact.endswith("[]"):
        return False
    return resolve_known_type(
        definition["unit"],
        compact,
        "String",
        ("java.lang",),
        element["type_node"],
    ) == "java.lang"


def spring_alias_value_cardinality_valid(element, value_node):
    """Ensure an alias value fits its scalar-versus-array declaration.

    Example call:
        ``spring_alias_value_cardinality_valid(
            element=path_element_definition,
            value_node=route_value_node,
        )``
        ensures an alias value fits its scalar-versus-array declaration.
    """

    compact = re.sub(r"\s+", "", element["type_text"])
    if compact.endswith("[]"):
        return True
    current = unwrap_parenthesized_node(value_node)
    return bool(
        current is not None
        and current.type != "element_value_array_initializer"
        and len(annotation_value_nodes(value_node)) == 1
    )


def spring_alias_known_type_shape(element, definition):
    """Canonicalize supported alias element types for compatibility checks.

    Example call:
        ``spring_alias_known_type_shape(
            element=path_element_definition,
            definition=route_annotation_definition,
        )``
        canonicalizes supported alias element types for compatibility checks.
    """

    compact = re.sub(r"\s+", "", element["type_text"])
    is_array = compact.endswith("[]")
    base_type = compact[:-2] if is_array else compact
    if base_type in {
        "boolean",
        "byte",
        "short",
        "int",
        "long",
        "char",
        "float",
        "double",
    }:
        return (base_type, is_array)
    if resolve_known_type(
        definition["unit"],
        base_type,
        "String",
        ("java.lang",),
        element["type_node"],
    ) == "java.lang":
        return ("java.lang.String", is_array)
    if resolve_known_type(
        definition["unit"],
        base_type,
        "RequestMethod",
        (SPRING_MAPPING_PACKAGE,),
        element["type_node"],
    ) == SPRING_MAPPING_PACKAGE:
        return (f"{SPRING_MAPPING_PACKAGE}.RequestMethod", is_array)
    return None


def spring_alias_custom_types_compatible(
    source_element, source_definition, target_element, target_definition
):
    """Check safe value flow between two source-defined alias elements.

    Example call:
        ``spring_alias_custom_types_compatible(
            source_element=source_path_element,
            source_definition=source_annotation_definition,
            target_element=target_path_element,
            target_definition=target_annotation_definition,
        )``
        checks safe value flow between two source-defined alias elements.
    """

    source_shape = spring_alias_known_type_shape(source_element, source_definition)
    target_shape = spring_alias_known_type_shape(target_element, target_definition)
    if source_shape is None or target_shape is None:
        return False
    source_type, source_array = source_shape
    target_type, target_array = target_shape
    return source_type == target_type and (
        source_array == target_array or (target_array and not source_array)
    )


def resolve_ignored_sibling_alias_target(
    definition, target_fqn, target_attribute, workspace
):
    """Validate a direct non-route sibling alias while excluding it from output.

    Example call:
        ``resolve_ignored_sibling_alias_target(
            definition=route_annotation_definition,
            target_fqn="org.springframework.web.bind.annotation.RequestMapping",
            target_attribute="path",
            workspace=java_workspace,
        )``
        validates a direct non-route sibling alias while excluding it from output.
    """

    definitions = workspace["annotation_definitions"].get(target_fqn, [])
    if len(definitions) != 1:
        return {"status": "invalid", "reason": "ambiguous sibling alias target"}
    target_definition = definitions[0]
    if not workspace_type_accessible(
        target_definition,
        definition["unit"],
        definition["type_info"]["display_name"],
    ) or not spring_definition_runtime_retained(target_definition):
        return {"status": "invalid", "reason": "invalid sibling alias target"}

    target_records = []
    for record in definition["meta_annotations"]:
        spelling = node_text(
            definition["unit"]["source"], record["name_node"]
        ).strip()
        identities = custom_annotation_identity_candidates(
            definition["unit"], spelling, workspace, record["name_node"]
        )
        if identities == {target_fqn}:
            target_records.append(record)
    if len(target_records) != 1:
        return {"status": "invalid", "reason": "alias target is not a unique direct meta-annotation"}

    _values, instance_error = annotation_instance_values(
        target_definition, target_records[0]
    )
    target_elements = target_definition["elements"].get(target_attribute, [])
    if instance_error or len(target_elements) != 1:
        return {"status": "invalid", "reason": "missing sibling alias target element"}
    target_element = target_elements[0]
    if parse_spring_alias_edge(
        target_definition, target_element, workspace
    )["status"] != "none":
        return {"status": "invalid", "reason": "nested sibling alias is outside the bounded graph"}
    return {
        "status": "ignored_custom",
        "element": target_element,
        "definition": target_definition,
        "target_key": f"{target_fqn}#{target_attribute}",
    }


def resolve_spring_alias_terminal(
    definition,
    element_name,
    branch_definitions,
    branch_positions,
    leaf_fqn,
    leaf_name,
    workspace,
    stack=(),
):
    """Follow one AliasFor graph path to a canonical, ignored, or invalid terminal.

    Example call:
        ``resolve_spring_alias_terminal(
            definition=route_annotation_definition,
            element_name="path",
            branch_definitions=mapping_branch_definitions,
            branch_positions=mapping_branch_positions,
            leaf_fqn="org.springframework.web.bind.annotation.RequestMapping",
            leaf_name="RequestMapping",
            workspace=java_workspace,
        )``
        follows one AliasFor graph path to a canonical, ignored, or invalid terminal.
    """

    key = (definition["fqn"], element_name)
    if key in stack:
        return {"status": "invalid", "reason": "@AliasFor element cycle"}
    elements = definition["elements"].get(element_name, [])
    if len(elements) != 1:
        return {"status": "invalid", "reason": "missing or ambiguous alias element"}
    element = elements[0]
    edge = parse_spring_alias_edge(definition, element, workspace)
    if edge["status"] != "resolved":
        if edge["status"] == "none" and stack:
            return {
                "status": "ignored_custom",
                "element": element,
                "definition": definition,
                "target_key": f"{definition['fqn']}#{element_name}",
            }
        return (
            edge
            if edge["status"] == "invalid"
            else {"status": "invalid", "reason": "alias does not reach a mapping"}
        )

    if edge["target"] == leaf_fqn:
        target_attribute = edge["attribute"]
        if target_attribute in {"value", "path"}:
            canonical = "path"
        elif leaf_name == "RequestMapping" and target_attribute == "method":
            canonical = "method"
        elif (
            leaf_name == "RequestMapping"
            and target_attribute in SPRING_REQUEST_MAPPING_ATTRIBUTES
        ):
            expected_type = (
                "string"
                if target_attribute in {"name", "version"}
                else "string_array"
            )
            if not spring_alias_non_output_type_valid(
                element, expected_type, definition
            ):
                return {"status": "invalid", "reason": "incompatible alias element type"}
            return {
                "status": "ignored",
                "attribute": target_attribute,
                "expected_type": expected_type,
            }
        else:
            return {"status": "invalid", "reason": "unsupported mapping alias target"}
        if not spring_alias_element_type_valid(element, canonical, definition):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return {"status": "resolved", "attribute": canonical}

    if edge["target"] == definition["fqn"]:
        target_elements = definition["elements"].get(edge["attribute"], [])
        if len(target_elements) != 1 or edge["attribute"] == element_name:
            return {
                "status": "invalid",
                "reason": "invalid local @AliasFor target",
            }
        target_element = target_elements[0]
        reverse = parse_spring_alias_edge(definition, target_element, workspace)
        if (
            reverse["status"] != "resolved"
            or reverse["target"] != definition["fqn"]
            or reverse["attribute"] != element_name
        ):
            return {
                "status": "invalid",
                "reason": "local @AliasFor pair is not reciprocal",
            }
        if not spring_alias_custom_types_compatible(
            element, definition, target_element, definition
        ):
            return {
                "status": "invalid",
                "reason": "incompatible local alias element type",
            }

        # A reciprocal local pair on a composed RequestMapping can override a
        # meta-attribute by convention when one member bears that attribute's
        # name.  Collapse the pair before values/defaults are reconciled so a
        # single explicit member is propagated to its omitted mate.
        component_names = {element_name, edge["attribute"]}
        canonical = None
        if component_names & {"value", "path"}:
            canonical = "path"
        elif "method" in component_names and leaf_name == "RequestMapping":
            canonical = "method"
        if canonical is not None:
            if not all(
                spring_alias_element_type_valid(
                    current_element, canonical, definition
                )
                for current_element in (element, target_element)
            ):
                return {
                    "status": "invalid",
                    "reason": "incompatible local alias element type",
                }
            return {"status": "resolved", "attribute": canonical}

        ignored_attributes = component_names & SPRING_REQUEST_MAPPING_ATTRIBUTES
        if leaf_name == "RequestMapping" and len(ignored_attributes) == 1:
            ignored_attribute = next(iter(ignored_attributes))
            expected_type = (
                "string"
                if ignored_attribute in {"name", "version"}
                else "string_array"
            )
            if not all(
                spring_alias_non_output_type_valid(
                    current_element, expected_type, definition
                )
                for current_element in (element, target_element)
            ):
                return {
                    "status": "invalid",
                    "reason": "incompatible local alias element type",
                }
            return {
                "status": "ignored",
                "attribute": ignored_attribute,
                "expected_type": expected_type,
            }
        if ignored_attributes:
            return {
                "status": "invalid",
                "reason": "ambiguous local alias mapping target",
            }
        return {
            "status": "ignored_custom",
            "element": element,
            "definition": definition,
            "target_key": "local:"
            + definition["fqn"]
            + "#"
            + ",".join(sorted(component_names)),
        }
    target_definition = branch_definitions.get(edge["target"])
    if target_definition is None:
        terminal = resolve_ignored_sibling_alias_target(
            definition, edge["target"], edge["attribute"], workspace
        )
        if terminal["status"] != "ignored_custom":
            return terminal
        if not spring_alias_custom_types_compatible(
            element,
            definition,
            terminal["element"],
            terminal["definition"],
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if branch_positions[edge["target"]] <= branch_positions[definition["fqn"]]:
        return {"status": "invalid", "reason": "alias targets an outer annotation"}
    target_elements = target_definition["elements"].get(edge["attribute"], [])
    if len(target_elements) != 1 or not spring_alias_custom_types_compatible(
        element,
        definition,
        target_elements[0] if target_elements else element,
        target_definition,
    ):
        return {"status": "invalid", "reason": "incompatible alias element type"}
    terminal = resolve_spring_alias_terminal(
        target_definition,
        edge["attribute"],
        branch_definitions,
        branch_positions,
        leaf_fqn,
        leaf_name,
        workspace,
        stack + (key,),
    )
    if terminal["status"] == "ignored_custom":
        if not spring_alias_custom_types_compatible(
            element,
            definition,
            terminal["element"],
            terminal["definition"],
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if terminal["status"] == "ignored":
        if not spring_alias_non_output_type_valid(
            element, terminal["expected_type"], definition
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if terminal["status"] != "resolved":
        return terminal
    if not spring_alias_element_type_valid(
        element, terminal["attribute"], definition
    ):
        return {"status": "invalid", "reason": "incompatible alias element type"}
    return terminal


def annotation_instance_values(definition, annotation_record):
    """Bind an annotation occurrence to declared elements and required defaults.

    Example call:
        ``annotation_instance_values(
            definition=route_annotation_definition,
            annotation_record=path_annotation_record,
        )``
        binds an annotation occurrence to declared elements and required defaults.
    """

    positional, named = get_annotation_arguments(annotation_record["node"])
    if set(named) - set(definition["elements"]):
        return None, "unknown composed-annotation attribute"
    values = dict(named)
    if positional:
        if len(positional) != 1 or "value" not in definition["elements"] or "value" in values:
            return None, "invalid positional composed-annotation value"
        values["value"] = positional[0]
    missing_required = [
        element_name
        for element_name, elements in definition["elements"].items()
        if element_name not in values
        and any(element["default_node"] is None for element in elements)
    ]
    if missing_required:
        return None, "missing required composed-annotation attribute"
    return values, None


def decode_spring_alias_path_value(
    value_unit, value_owner_name, value_node, workspace
):
    """Decode an alias-selected path value into ordered static alternatives.

    Example call:
        ``decode_spring_alias_path_value(
            value_unit=items_unit,
            value_owner_name="ValueOwner",
            value_node=route_value_node,
            workspace=java_workspace,
        )``
        decodes an alias-selected path value into ordered static alternatives.
    """

    values = []
    for current in annotation_value_nodes(value_node):
        value = resolve_workspace_string_expression(
            value_unit,
            current,
            workspace,
            value_owner_name,
        )
        if value is None:
            return None
        values.append(value)
    return tuple(dict.fromkeys(values))


def decode_spring_alias_method_value(value_unit, value_node):
    """Decode an alias-selected RequestMethod value into ordered conditions.

    Example call:
        ``decode_spring_alias_method_value(value_unit=items_unit, value_node=route_value_node)``
        decodes an alias-selected RequestMethod value into ordered conditions.
    """

    methods = []
    for current in annotation_value_nodes(value_node):
        method_name = resolve_spring_request_method_expression(value_unit, current)
        if method_name is None:
            return None
        methods.append(method_name)
    return tuple(methods)


def invalid_spring_composed_mapping(annotation_node):
    """Represent a recognized-but-invalid composed mapping for suppression.

    Example call:
        ``invalid_spring_composed_mapping(annotation_node=mapping_annotation_node)``
        represents a recognized-but-invalid composed mapping for suppression.
    """

    return {
        "name": "ComposedMapping",
        "paths": [],
        "methods": [],
        "valid": False,
        "annotation_node": annotation_node,
    }


def log_spring_composed_issue(source_path, owner_name, spelling, reason):
    """Record why a recognized composed mapping could not safely emit.

    Example call:
        ``log_spring_composed_issue(
            source_path="/workspace/shop/src/main/java/com/acme/ItemsController.java",
            owner_name="ItemsController",
            spelling="GetMapping",
            reason=reason,
        )``
        records why a recognized composed mapping could not safely emit.
    """

    record(
        f"Skipped invalid Spring composed mapping in {source_path} for "
        f"{owner_name} @{spelling}: {reason}"
    )


def decode_spring_composed_mapping(
    source_path,
    use_unit,
    annotation_name_node,
    annotation_node,
    lexical_owner_name,
    diagnostic_owner_name,
    workspace,
):
    """Decode one applied source annotation through its mapping and AliasFor graph.

    Example call:
        ``decode_spring_composed_mapping(
            source_path="/workspace/shop/src/main/java/com/acme/ItemsController.java",
            use_unit=items_unit,
            annotation_name_node=mapping_name_node,
            annotation_node=mapping_annotation_node,
            lexical_owner_name="ItemsController",
            diagnostic_owner_name="ItemsController.list",
            workspace=java_workspace,
        )``
        decodes one applied source annotation through its mapping and AliasFor graph.
    """

    spelling = node_text(use_unit["source"], annotation_name_node).strip()
    resolved = source_annotation_definition(
        use_unit,
        annotation_name_node,
        workspace,
        lexical_owner_name,
    )
    if resolved["status"] == "none":
        return None
    if resolved["status"] != "resolved":
        log_spring_composed_issue(
            source_path, diagnostic_owner_name, spelling, resolved["status"]
        )
        return invalid_spring_composed_mapping(annotation_node)

    definition = resolved["definition"]
    branches, errors = collect_spring_mapping_branches(definition, workspace)
    if not branches and not errors:
        return None
    if errors or len(branches) != 1:
        reason = errors[0] if errors else "multiple mapping leaves"
        log_spring_composed_issue(
            source_path, diagnostic_owner_name, spelling, reason
        )
        return invalid_spring_composed_mapping(annotation_node)

    branch = branches[0]
    if any(
        not spring_definition_runtime_retained(current)
        for current in branch["definitions"]
    ):
        log_spring_composed_issue(
            source_path, diagnostic_owner_name, spelling, "non-runtime annotation"
        )
        return invalid_spring_composed_mapping(annotation_node)

    leaf_definition = branch["definitions"][-1]
    leaf_unit = leaf_definition["unit"]
    leaf_record = branch["leaf_record"]
    mapping = decode_builtin_spring_mapping(
        leaf_unit,
        leaf_record["name_node"],
        leaf_record["node"],
        workspace,
        leaf_definition["type_info"]["display_name"],
        diagnostic_owner_name,
    )
    if mapping is None or not mapping["valid"]:
        log_spring_composed_issue(
            source_path, diagnostic_owner_name, spelling, "invalid mapping leaf"
        )
        return invalid_spring_composed_mapping(annotation_node)

    definitions_by_fqn = {
        current["fqn"]: current for current in branch["definitions"]
    }
    definition_positions = {
        current["fqn"]: index
        for index, current in enumerate(branch["definitions"])
    }
    terminals = {}
    for current in branch["definitions"]:
        for element_name, elements in current["elements"].items():
            for element in elements:
                edge = parse_spring_alias_edge(current, element, workspace)
                if edge["status"] == "none":
                    continue
                if edge["status"] == "invalid":
                    log_spring_composed_issue(
                        source_path,
                        diagnostic_owner_name,
                        spelling,
                        edge["reason"],
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                terminal = resolve_spring_alias_terminal(
                    current,
                    element_name,
                    definitions_by_fqn,
                    definition_positions,
                    branch["leaf_fqn"],
                    branch["leaf_name"],
                    workspace,
                )
                if terminal["status"] == "ignored":
                    terminals[(current["fqn"], element_name)] = (
                        f"ignored:{terminal['attribute']}"
                    )
                    continue
                if terminal["status"] == "ignored_custom":
                    terminals[(current["fqn"], element_name)] = (
                        f"ignored-custom:{terminal['target_key']}"
                    )
                    continue
                if terminal["status"] != "resolved":
                    log_spring_composed_issue(
                        source_path,
                        diagnostic_owner_name,
                        spelling,
                        terminal["reason"],
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                terminals[(current["fqn"], element_name)] = terminal["attribute"]

    for current in branch["definitions"]:
        terminal_attributes = {
            terminal_attribute
            for (definition_fqn, _element_name), terminal_attribute in terminals.items()
            if definition_fqn == current["fqn"]
        }
        for terminal_attribute in terminal_attributes:
            aliased_elements = [
                current["elements"][element_name][0]
                for definition_fqn, element_name in terminals
                if definition_fqn == current["fqn"]
                and terminals[(definition_fqn, element_name)] == terminal_attribute
                and len(current["elements"].get(element_name, [])) == 1
            ]
            if len(aliased_elements) < 2:
                continue
            declared_types = {
                re.sub(r"\s+", "", element["type_text"])
                for element in aliased_elements
            }
            if len(declared_types) != 1:
                log_spring_composed_issue(
                    source_path,
                    diagnostic_owner_name,
                    spelling,
                    "implicit alias return types differ",
                )
                return invalid_spring_composed_mapping(annotation_node)
            defaults = []
            for element in aliased_elements:
                if element["default_node"] is None:
                    defaults = None
                    break
                if not spring_alias_value_cardinality_valid(
                    element, element["default_node"]
                ):
                    defaults = None
                    break
                default = (
                    decode_spring_alias_path_value(
                        current["unit"],
                        current["type_info"]["display_name"],
                        element["default_node"],
                        workspace,
                    )
                    if terminal_attribute != "method"
                    else decode_spring_alias_method_value(
                        current["unit"], element["default_node"]
                    )
                )
                if default is None:
                    defaults = None
                    break
                defaults.append(default)
            if defaults is None or len(set(defaults)) != 1:
                log_spring_composed_issue(
                    source_path,
                    diagnostic_owner_name,
                    spelling,
                    "implicit alias defaults differ",
                )
                return invalid_spring_composed_mapping(annotation_node)

    instances = [
        {
            "record": {"node": annotation_node, "name_node": annotation_name_node},
            "unit": use_unit,
            "owner_name": lexical_owner_name,
        },
        *branch["instances"],
    ]
    overrides = {}
    for current, instance_info in reversed(list(zip(branch["definitions"], instances))):
        explicit, error = annotation_instance_values(
            current, instance_info["record"]
        )
        if error:
            log_spring_composed_issue(
                source_path, diagnostic_owner_name, spelling, error
            )
            return invalid_spring_composed_mapping(annotation_node)
        layer = {}
        grouped_elements = {}
        for element_name, elements in current["elements"].items():
            if len(elements) != 1:
                log_spring_composed_issue(
                    source_path,
                    diagnostic_owner_name,
                    spelling,
                    "ambiguous composed-annotation element",
                )
                return invalid_spring_composed_mapping(annotation_node)
            terminal_attribute = terminals.get((current["fqn"], element_name))
            if terminal_attribute is None:
                continue
            if terminal_attribute.startswith("ignored-custom:"):
                continue
            element = elements[0]
            grouped_elements.setdefault(terminal_attribute, []).append(
                (element_name, element)
            )

        for terminal_attribute, group in grouped_elements.items():
            supplied = [
                (element_name, element, explicit[element_name])
                for element_name, element in group
                if element_name in explicit
            ]
            selected = supplied or [
                (element_name, element, element["default_node"])
                for element_name, element in group
                if element["default_node"] is not None
            ]
            decoded_values = []
            for element_name, element, value_node in selected:
                if not spring_alias_value_cardinality_valid(element, value_node):
                    log_spring_composed_issue(
                        source_path,
                        diagnostic_owner_name,
                        spelling,
                        "invalid composed-annotation value cardinality",
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                if supplied:
                    value_unit = instance_info["unit"]
                    value_owner_name = instance_info["owner_name"]
                else:
                    value_unit = current["unit"]
                    value_owner_name = current["type_info"]["display_name"]
                value = (
                    decode_spring_alias_path_value(
                        value_unit, value_owner_name, value_node, workspace
                    )
                    if terminal_attribute != "method"
                    else decode_spring_alias_method_value(value_unit, value_node)
                )
                if value is None:
                    log_spring_composed_issue(
                        source_path,
                        diagnostic_owner_name,
                        spelling,
                        "unresolved composed-annotation value",
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                if value and any(value):
                    decoded_values.append(value)
            if len(set(decoded_values)) > 1:
                log_spring_composed_issue(
                    source_path,
                    diagnostic_owner_name,
                    spelling,
                    "conflicting composed-annotation values",
                )
                return invalid_spring_composed_mapping(annotation_node)
            if decoded_values:
                layer[terminal_attribute] = decoded_values[0]
        overrides.update(layer)

    if "path" in overrides:
        mapping["paths"] = [
            ensure_path_leading_slash(value) for value in overrides["path"]
        ]
    if "method" in overrides:
        mapping["methods"] = ordered_http_methods(overrides["method"])
    mapping["annotation_node"] = annotation_node
    mapping["annotation_identity"] = definition["fqn"]
    return mapping


def spring_composed_definition_is_supported(definition, workspace):
    """Validate the source-definition graph without decoding a use site.

    The endpoint decoder additionally validates values supplied by each use.
    Recognition deliberately stops at definition support, so an occurrence can
    remain auditable even when its placement or arguments emit no endpoint.

    Example call:
        ``spring_composed_definition_is_supported(
            definition=route_annotation_definition,
            workspace=java_workspace,
        )``
        validates the source-definition graph without decoding a use site.
    """

    cache = workspace.setdefault("spring_inventory_definition_support", {})
    fqn = definition["fqn"]
    if fqn in cache:
        return cache[fqn]

    # Seed the cache before traversal so unexpected recursive alias graphs fail
    # closed even though the bounded composition walker already detects cycles.
    cache[fqn] = False
    branches, errors = collect_spring_mapping_branches(definition, workspace)
    if errors or len(branches) != 1:
        return False
    branch = branches[0]
    if any(
        not spring_definition_runtime_retained(current)
        for current in branch["definitions"]
    ):
        return False

    leaf_definition = branch["definitions"][-1]
    leaf_unit = leaf_definition["unit"]
    leaf_record = branch["leaf_record"]
    leaf_paths = get_spring_annotation_paths(
        leaf_unit,
        leaf_record["node"],
        workspace,
        leaf_definition["type_info"]["display_name"],
    )
    leaf_methods = get_spring_request_methods(leaf_unit, leaf_record["node"])
    if not leaf_paths["values"] or (
        leaf_methods["present"]
        and leaf_methods["unresolved"]
        and not leaf_methods["values"]
    ):
        return False

    definitions_by_fqn = {
        current["fqn"]: current for current in branch["definitions"]
    }
    definition_positions = {
        current["fqn"]: index
        for index, current in enumerate(branch["definitions"])
    }
    terminals = {}
    for current in branch["definitions"]:
        for element_name, elements in current["elements"].items():
            if len(elements) != 1:
                return False
            edge = parse_spring_alias_edge(current, elements[0], workspace)
            if edge["status"] == "none":
                continue
            if edge["status"] != "resolved":
                return False
            terminal = resolve_spring_alias_terminal(
                current,
                element_name,
                definitions_by_fqn,
                definition_positions,
                branch["leaf_fqn"],
                branch["leaf_name"],
                workspace,
            )
            if terminal["status"] == "resolved":
                terminals[(current["fqn"], element_name)] = terminal["attribute"]
            elif terminal["status"] == "ignored":
                terminals[(current["fqn"], element_name)] = (
                    f"ignored:{terminal['attribute']}"
                )
            elif terminal["status"] == "ignored_custom":
                terminals[(current["fqn"], element_name)] = (
                    f"ignored-custom:{terminal['target_key']}"
                )
            else:
                return False

    for current in branch["definitions"]:
        terminal_attributes = {
            terminal_attribute
            for (definition_fqn, _element_name), terminal_attribute in terminals.items()
            if definition_fqn == current["fqn"]
        }
        for terminal_attribute in terminal_attributes:
            aliased_elements = [
                current["elements"][element_name][0]
                for definition_fqn, element_name in terminals
                if definition_fqn == current["fqn"]
                and terminals[(definition_fqn, element_name)] == terminal_attribute
            ]
            if len(aliased_elements) < 2:
                continue
            if len(
                {
                    re.sub(r"\s+", "", element["type_text"])
                    for element in aliased_elements
                }
            ) != 1:
                return False
            defaults = []
            for element in aliased_elements:
                default_node = element["default_node"]
                if default_node is None or not spring_alias_value_cardinality_valid(
                    element, default_node
                ):
                    return False
                default = (
                    decode_spring_alias_method_value(current["unit"], default_node)
                    if terminal_attribute == "method"
                    else decode_spring_alias_path_value(
                        current["unit"],
                        current["type_info"]["display_name"],
                        default_node,
                        workspace,
                    )
                )
                if default is None:
                    return False
                defaults.append(default)
            if len(set(defaults)) != 1:
                return False

    # Meta-annotation instances between source-defined layers are part of the
    # definition graph.  Validate those fixed uses while deliberately leaving
    # the outer consumer occurrence to the endpoint decoder.
    for current, instance_info in zip(
        branch["definitions"][1:], branch["instances"]
    ):
        explicit, error = annotation_instance_values(
            current, instance_info["record"]
        )
        if error:
            return False
        grouped_elements = {}
        for element_name, elements in current["elements"].items():
            terminal_attribute = terminals.get((current["fqn"], element_name))
            if terminal_attribute is None or terminal_attribute.startswith(
                "ignored-custom:"
            ):
                continue
            grouped_elements.setdefault(terminal_attribute, []).append(
                (element_name, elements[0])
            )
        for terminal_attribute, group in grouped_elements.items():
            supplied = [
                (element_name, element, explicit[element_name])
                for element_name, element in group
                if element_name in explicit
            ]
            selected = supplied or [
                (element_name, element, element["default_node"])
                for element_name, element in group
                if element["default_node"] is not None
            ]
            decoded_values = []
            for _element_name, element, value_node in selected:
                if not spring_alias_value_cardinality_valid(element, value_node):
                    return False
                if supplied:
                    value_unit = instance_info["unit"]
                    value_owner_name = instance_info["owner_name"]
                else:
                    value_unit = current["unit"]
                    value_owner_name = current["type_info"]["display_name"]
                value = (
                    decode_spring_alias_method_value(value_unit, value_node)
                    if terminal_attribute == "method"
                    else decode_spring_alias_path_value(
                        value_unit, value_owner_name, value_node, workspace
                    )
                )
                if value is None:
                    return False
                if value and any(value):
                    decoded_values.append(value)
            if len(set(decoded_values)) > 1:
                return False

    cache[fqn] = True
    return True

__all__ = [
    "analyze_direct_spring_mvc_unit",
    "annotation_instance_values",
    "collect_spring_mapping_branches",
    "compose_lexical_type_mapping",
    "decode_builtin_spring_mapping",
    "decode_spring_composed_mapping",
    "get_spring_annotation_paths",
    "get_spring_request_methods",
    "ordered_http_methods",
    "resolve_spring_mapping_name",
    "resolve_spring_mapping_spelling",
    "resolve_spring_request_method_expression",
    "source_annotation_definition",
    "source_annotation_is_method_applicable",
    "spring_composed_definition_is_supported",
    "spring_method_applicable_component_candidates",
    "union_request_method_conditions",
]
