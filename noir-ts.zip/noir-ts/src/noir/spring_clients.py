"""Bounded source-only Spring HTTP client contract identification.

The analyzer receives an already-built Java workspace and identifies outbound
Spring HTTP Interface declarations and Feign interfaces without
reclassifying them as inbound server handlers. Only direct, genuinely
resolved framework annotations on unique source interfaces participate;
unresolved or ambiguous endpoint identity fails closed.

Logic guide: ``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from typing import Any, Iterable

from .contracts import (
    HTTP_METHOD_TOKEN,
    METHOD_ANNOTATION_FAMILY_BY_IDENTITY,
    SPRING_HTTP_METHODS,
)
from .diagnostics import format_endpoint_diagnostic, record
from .evidence import (
    deduplicate_endpoint_facts,
    method_annotation_evidence_from_mapping,
    represented_target_evidence,
)
from .java_frontend import (
    annotation_value_nodes,
    child_by_field,
    declaration_modifier_names,
    direct_annotation_records,
    get_annotation_arguments,
    lexical_type_chain,
    node_text,
    parameter_list_source_text,
    resolve_known_annotation,
    tree_node_key,
)
from .java_workspace import resolve_workspace_string_expression
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths
from .spring_mvc import (
    decode_builtin_spring_mapping,
    decode_spring_composed_mapping,
    union_request_method_conditions,
)


HTTP_EXCHANGE_PACKAGE = "org.springframework.web.service.annotation"
FEIGN_CLIENT_PACKAGE = "org.springframework.cloud.openfeign"

HTTP_EXCHANGE_METHODS = {
    "GetExchange": "GET",
    "PostExchange": "POST",
    "PutExchange": "PUT",
    "DeleteExchange": "DELETE",
    "PatchExchange": "PATCH",
    "HttpExchange": None,
}

HTTP_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "method", "contentType", "accept", "headers"}
)
FIXED_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "contentType", "accept", "headers"}
)


def _log(unit: dict[str, Any], owner: str, message: str) -> None:
    """Record why an outbound contract candidate failed closed."""

    record(
        f"Skipped Spring client in {unit['source_path']} for {owner}: {message}"
    )


def _direct_methods(interface_node: Any) -> list[Any]:
    """Return source-ordered methods declared by one client interface."""

    body = child_by_field(interface_node, "body")
    if body is None:
        return []
    return sorted(
        (
            child
            for child in body.named_children
            if child.type == "method_declaration"
        ),
        key=lambda node: node.start_byte,
    )


def _usable_contract_method(method_node: Any) -> bool:
    """Exclude private/static declarations that cannot be client operations."""

    modifiers = declaration_modifier_names(method_node)
    return "private" not in modifiers and "static" not in modifiers


def _resolved_exchange_annotations(
    unit: dict[str, Any], declaration_node: Any
) -> list[tuple[dict[str, Any], str]]:
    """Resolve genuine direct Spring HTTP Exchange annotations on a declaration."""

    resolved: list[tuple[dict[str, Any], str]] = []
    for annotation_record in direct_annotation_records(declaration_node):
        identity = resolve_known_annotation(
            unit,
            annotation_record["name_node"],
            set(HTTP_EXCHANGE_METHODS),
            (HTTP_EXCHANGE_PACKAGE,),
        )
        if identity is not None:
            resolved.append((annotation_record, identity["name"]))
    return resolved


def _resolve_string_values(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    value_node: Any,
) -> tuple[str, ...] | None:
    """Resolve one annotation value/array into ordered static String alternatives."""

    values: list[str] = []
    for current in annotation_value_nodes(value_node):
        value = resolve_workspace_string_expression(
            unit, current, workspace, owner
        )
        if value is None:
            return None
        values.append(value)
    # Noir's Java mapping decoder fans out array-shaped annotation input even
    # for annotations whose library declaration is scalar.  Retain that
    # source-recovery behavior, but only after genuine annotation provenance.
    return tuple(dict.fromkeys(values)) if values else ("",)


def _normalize_client_path(value: str) -> str:
    """Normalize a client path without corrupting absolute or configured bases."""

    return (
        value
        if value.lower().startswith(("http://", "https://"))
        # Configuration is applied after extraction. Keep a root placeholder
        # unprefixed so a later absolute configured base remains a valid URL.
        or value.startswith("${")
        else ensure_path_leading_slash(value)
    )


def _combine_client_paths(type_path: str, method_path: str) -> str:
    """Compose lexical client paths with inner absolute-URL precedence."""

    # A method-level absolute client URL is already complete and must not be
    # appended to a type-level contract prefix.
    if method_path.lower().startswith(("http://", "https://")):
        return method_path
    return join_endpoint_paths(type_path, method_path)


def _decode_exchange_paths(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_node: Any,
) -> list[str] | None:
    """Decode coherent value/url aliases into ordered client path fan-out."""

    positional, named = get_annotation_arguments(annotation_node)
    if len(positional) > 1 or (positional and "value" in named):
        _log(unit, owner, "invalid positional/value URL aliases")
        return None

    explicit: list[tuple[str, Any]] = []
    if positional:
        explicit.append(("value", positional[0]))
    for attribute in ("value", "url"):
        if attribute in named:
            explicit.append((attribute, named[attribute]))
    if not explicit:
        return [""]

    aliases: list[tuple[str, tuple[str, ...]]] = []
    for attribute, node in explicit:
        values = _resolve_string_values(unit, workspace, owner, node)
        if values is None:
            _log(
                unit,
                owner,
                f"unresolved @{attribute} client path: "
                f"{node_text(unit['source'], node).strip()}",
            )
            return None
        aliases.append((attribute, values))
    if len({values for _attribute, values in aliases}) != 1:
        _log(unit, owner, "conflicting explicit value/url aliases")
        return None
    return list(
        dict.fromkeys(
            _normalize_client_path(value) for value in aliases[0][1]
        )
    )


def _decode_exchange_methods(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_name: str,
    annotation_node: Any,
) -> list[str] | None:
    """Decode fixed or custom HTTP Exchange method conditions."""

    _positional, named = get_annotation_arguments(annotation_node)
    if annotation_name != "HttpExchange":
        if "method" in named:
            _log(unit, owner, f"invalid method on @{annotation_name}")
            return None
        return [HTTP_EXCHANGE_METHODS[annotation_name]]

    method_node = named.get("method")
    if method_node is None:
        return []
    resolved = _resolve_string_values(unit, workspace, owner, method_node)
    if resolved is None:
        _log(
            unit,
            owner,
            "unresolved @HttpExchange method: "
            f"{node_text(unit['source'], method_node).strip()}",
        )
        return None

    methods: list[str] = []
    for value in resolved:
        token = value.strip().upper()
        if not token:
            continue
        if len(token) > 128 or HTTP_METHOD_TOKEN.fullmatch(token) is None:
            _log(unit, owner, f"invalid @HttpExchange method token: {value}")
            return None
        methods.append(token)
    return list(dict.fromkeys(methods))


def _decode_exchange_mapping(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    record: dict[str, Any],
    annotation_name: str,
) -> dict[str, Any] | None:
    """Turn one proven Exchange annotation into paths, verbs, and provenance."""

    _positional, named = get_annotation_arguments(record["node"])
    allowed = (
        HTTP_EXCHANGE_ATTRIBUTES
        if annotation_name == "HttpExchange"
        else FIXED_EXCHANGE_ATTRIBUTES
    )
    unsupported = sorted(set(named) - allowed)
    if unsupported:
        _log(
            unit,
            owner,
            "unsupported @"
            f"{annotation_name} attributes: {', '.join(unsupported)}",
        )
        return None
    paths = _decode_exchange_paths(unit, workspace, owner, record["node"])
    methods = _decode_exchange_methods(
        unit,
        workspace,
        owner,
        annotation_name,
        record["node"],
    )
    if paths is None or methods is None:
        return None
    return {
        "paths": paths,
        "methods": methods,
        "annotation_node": record["node"],
        "annotation_identity": f"{HTTP_EXCHANGE_PACKAGE}.{annotation_name}",
        "annotation_family": METHOD_ANNOTATION_FAMILY_BY_IDENTITY[
            f"{HTTP_EXCHANGE_PACKAGE}.{annotation_name}"
        ],
    }


def _ordered_methods(methods: Iterable[str]) -> list[str]:
    """Deduplicate verbs using Spring's stable order before custom tokens."""

    unique = set(methods)
    known = [method for method in SPRING_HTTP_METHODS if method in unique]
    return known + sorted(unique - set(known))


def _union_exchange_methods(
    type_methods: Iterable[str],
    method_methods: Iterable[str],
) -> list[str]:
    """Combine type/method Exchange conditions using Noir's ordered-union rule."""

    type_methods = list(type_methods)
    method_methods = list(method_methods)
    if not type_methods:
        return _ordered_methods(method_methods)
    if not method_methods:
        return _ordered_methods(type_methods)
    return _ordered_methods([*type_methods, *method_methods])


def _endpoint(
    unit: dict[str, Any],
    owner: str,
    method_node: Any,
    parameters_node: Any,
    mapping: dict[str, Any],
    path: str,
    http_method: str,
    *,
    path_layers: tuple[str, ...] | None = None,
) -> EndpointFact:
    """Create one outbound client fact with exact mapping and method evidence."""

    mapping_node = mapping["annotation_node"]
    endpoint = EndpointFact(
        path=path,
        method=http_method,
        parameters=parameter_list_source_text(unit["source"], parameters_node),
        source_file=unit["source_path"],
        source_line=mapping_node.start_point.row + 1,
        handler_name=owner,
        route_source_file=unit["source_path"],
        route_source_line=mapping_node.start_point.row + 1,
        handler_source_file=unit["source_path"],
        handler_source_line=method_node.start_point.row + 1,
        project_source_file=unit["source_path"],
        technology="spring",
        protocol="http",
        surface="client",
        direction="outbound",
        annotation_evidence=method_annotation_evidence_from_mapping(
            mapping,
            annotation_source_file=unit["source_path"],
            endpoint_source_file=unit["source_path"],
        ),
        represented_targets=represented_target_evidence(
            unit["source_path"], "method", method_node
        ),
        spring_client_path_layers=path_layers,
    )
    record(format_endpoint_diagnostic(endpoint))
    return endpoint


def _http_interface_endpoints(
    workspace: dict[str, Any],
    declaration: dict[str, Any],
) -> list[EndpointFact]:
    """Extract Spring HTTP Interface operations with lexical contract layers."""

    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_owner = type_info["display_name"]
    type_node = type_info["node"]
    path_layers: list[tuple[str, ...]] = []
    type_methods: list[str] = []
    for layer in lexical_type_chain(
        tree_node_key(type_node), unit["type_infos"]
    ):
        type_annotations = [
            (record, name)
            for record, name in _resolved_exchange_annotations(
                unit, layer["node"]
            )
            if name == "HttpExchange"
        ]
        if len(type_annotations) > 1:
            _log(
                unit,
                type_owner,
                "multiple type-level @HttpExchange mappings",
            )
            return []
        if not type_annotations:
            continue
        mapping = _decode_exchange_mapping(
            unit,
            workspace,
            layer["display_name"],
            type_annotations[0][0],
            type_annotations[0][1],
        )
        if mapping is None:
            return []
        path_layers.append(tuple(mapping["paths"]))
        type_methods = _union_exchange_methods(type_methods, mapping["methods"])
    if not path_layers:
        path_layers = [("",)]

    endpoints: list[EndpointFact] = []
    for method_node in _direct_methods(type_node):
        if not _usable_contract_method(method_node):
            continue
        name_node = child_by_field(method_node, "name")
        parameters_node = child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        mappings = _resolved_exchange_annotations(
            unit, method_node
        )
        for record, annotation_name in mappings:
            mapping = _decode_exchange_mapping(
                unit,
                workspace,
                owner,
                record,
                annotation_name,
            )
            if mapping is None:
                continue
            methods = _union_exchange_methods(type_methods, mapping["methods"]) or [
                "ANY"
            ]
            combinations: list[tuple[str, ...]] = [()]
            for layer_paths in [*path_layers, tuple(mapping["paths"])]:
                combinations = [
                    (*prefix, current)
                    for prefix in combinations
                    for current in layer_paths
                ]
            for layers in combinations:
                path = ""
                for current in layers:
                    path = _combine_client_paths(path, current)
                for http_method in methods:
                    endpoints.append(
                        _endpoint(
                            unit,
                            owner,
                            method_node,
                            parameters_node,
                            mapping,
                            path,
                            http_method,
                            path_layers=layers,
                        )
                    )
    return endpoints


def _resolved_feign_client_markers(
    unit: dict[str, Any], type_node: Any
) -> list[dict[str, Any]]:
    """Resolve direct FeignClient markers used only to classify an interface."""

    markers = []
    for annotation_record in direct_annotation_records(type_node):
        resolved = resolve_known_annotation(
            unit,
            annotation_record["name_node"],
            {"FeignClient"},
            (FEIGN_CLIENT_PACKAGE,),
        )
        if resolved is not None:
            markers.append(annotation_record)
    return markers


def _decode_mvc_mapping(
    workspace: dict[str, Any],
    unit: dict[str, Any],
    record: dict[str, Any],
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    """Decode a built-in or source-composed MVC mapping for a Feign contract."""

    mapping = decode_builtin_spring_mapping(
        unit,
        record["name_node"],
        record["node"],
        workspace,
        lexical_owner,
        diagnostic_owner,
    )
    if mapping is not None:
        return mapping
    return decode_spring_composed_mapping(
        unit["source_path"],
        unit,
        record["name_node"],
        record["node"],
        lexical_owner,
        diagnostic_owner,
        workspace,
    )


def _first_mvc_mapping(
    workspace: dict[str, Any],
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    """Select the first recognized MVC mapping on a Feign type layer."""

    for annotation_record in direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            unit,
            annotation_record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            return mapping
    return None


def _all_mvc_mappings(
    workspace: dict[str, Any],
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> list[dict[str, Any]]:
    """Return every recognized method mapping that can fan out Feign routes."""

    mappings = []
    for annotation_record in direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            unit,
            annotation_record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            mappings.append(mapping)
    return mappings


def _feign_endpoints(
    workspace: dict[str, Any],
    declaration: dict[str, Any],
) -> list[EndpointFact]:
    """Extract outbound Feign operations from MVC mapping semantics."""

    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_node = type_info["node"]
    type_owner = type_info["display_name"]
    markers = _resolved_feign_client_markers(unit, type_node)
    if not markers:
        return []
    if len(markers) != 1:
        _log(unit, type_owner, "multiple @FeignClient annotations")
        return []

    # FeignClient.value/path are classification metadata in Noir's Spring
    # analyzer and deliberately do not contribute a container path.  Ordinary
    # MVC mappings on all lexical type layers do contribute.
    type_paths = [""]
    type_methods: list[str] = []
    for layer in lexical_type_chain(
        tree_node_key(type_node), unit["type_infos"]
    ):
        mapping = _first_mvc_mapping(
            workspace,
            unit,
            layer["node"],
            layer["display_name"],
            type_owner,
        )
        if mapping is None:
            continue
        if not mapping["valid"]:
            return []
        type_paths = [
            join_endpoint_paths(prefix, current)
            for prefix in type_paths
            for current in mapping["paths"]
        ]
        type_methods = union_request_method_conditions(
            type_methods, mapping["methods"]
        )

    endpoints: list[EndpointFact] = []
    for method_node in _direct_methods(type_node):
        if not _usable_contract_method(method_node):
            continue
        name_node = child_by_field(method_node, "name")
        parameters_node = child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        for mapping in _all_mvc_mappings(
            workspace, unit, method_node, type_owner, owner
        ):
            if not mapping["valid"]:
                continue
            methods = union_request_method_conditions(
                type_methods, mapping["methods"]
            ) or ["ANY"]
            for type_path in type_paths:
                for method_path in mapping["paths"]:
                    path = join_endpoint_paths(type_path, method_path)
                    for http_method in methods:
                        endpoints.append(
                            _endpoint(
                                unit,
                                owner,
                                method_node,
                                parameters_node,
                                mapping,
                                path,
                                http_method,
                            )
                        )
    return endpoints


def _deduplicate(
    endpoints: Iterable[EndpointFact],
) -> tuple[EndpointFact, ...]:
    """Merge exact client facts without losing mapping/target evidence."""

    return deduplicate_endpoint_facts(
        endpoints,
        lambda endpoint: (
            endpoint.path,
            endpoint.method,
            endpoint.parameters,
            endpoint.source_file,
            endpoint.source_line,
            endpoint.handler_name,
            endpoint.surface,
            endpoint.direction,
            endpoint.spring_client_path_layers,
        ),
    )


def analyze_spring_http_clients(
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return outbound Spring HTTP Interface and Feign endpoint facts."""

    endpoints: list[EndpointFact] = []
    for fqn in sorted(workspace.get("type_declarations", {})):
        declarations = workspace["type_declarations"][fqn]
        # Duplicate source identities are not safe client containers.
        if len(declarations) != 1:
            continue
        declaration = declarations[0]
        type_info = declaration["type_info"]
        if (
            type_info["node"].type != "interface_declaration"
            or not type_info["workspace_visible"]
        ):
            continue
        endpoints.extend(_http_interface_endpoints(workspace, declaration))
        endpoints.extend(_feign_endpoints(workspace, declaration))
    return _deduplicate(endpoints)


__all__ = ["analyze_spring_http_clients"]
