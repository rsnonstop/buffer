"""Framework-neutral Java source type and hierarchy graph.

The graph owns source declarations, generic adaptation, erased signatures,
inheritance traversal, default-method resolution, and maximally-specific
interface selection. Framework analyzers layer route or mapping semantics on
top; this module does not classify Spring or JAX-RS annotations.

Logic guide: ``p6.logic/03-shared-java-engine.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .java_frontend import (
    child_by_field,
    direct_annotation_records,
    node_text,
    resolve_known_annotation,
)
from .java_workspace import (
    lexical_owner_fqns,
    resolve_workspace_owner_fqns,
    workspace_type_fqn_accessible,
)


# These are proof bounds, not tuning knobs.  A traversal that exceeds either
# marks its hierarchy incomplete so a framework pass cannot infer a route from
# a graph the source engine did not fully establish.
MAX_HIERARCHY_DEPTH = 12
MAX_HIERARCHY_STATES = 256

# Closed implicit ``java.lang`` vocabulary used only for signature identity;
# this is not a classpath loader or a claim that every dependency type exists.
JAVA_LANG_TYPES = {
    "Boolean",
    "Byte",
    "Character",
    "CharSequence",
    "Class",
    "Comparable",
    "Double",
    "Enum",
    "Float",
    "Integer",
    "Iterable",
    "Long",
    "Number",
    "Object",
    "Short",
    "String",
    "Throwable",
    "Void",
}

# Tree-sitter represents Java primitive families with grammar node kinds rather
# than ordinary identifiers, so they bypass source-owner resolution.
PRIMITIVE_NODE_TYPES = {
    "boolean_type",
    "floating_point_type",
    "integral_type",
    "void_type",
}


@dataclass(frozen=True)
class JavaTypeReference:
    """One application type used in a method signature or hierarchy edge.

    Attributes:
        kind: How to interpret the name: declared type, type variable, primitive,
            or an erasure-only bound.
        name: The declared type identity (for example ``java.lang.String``) or
            generic variable name (for example ``T``).
        args: Concrete generic arguments supplied to the application type.
        dimensions: Array nesting; ``1`` means one value such as ``String[]``.

    Example construction:
        ``JavaTypeReference("decl", "java.util.List",
        (JavaTypeReference("decl", "java.lang.String"),), dimensions=0)``
        represents the application type ``List<String>``.
    """

    kind: str
    name: str
    args: tuple["JavaTypeReference", ...] = ()
    dimensions: int = 0


@dataclass
class JavaMethodRecord:
    """One source handler candidate and the facts needed for inheritance.

    Attributes:
        id: Stable source identity for this declaration within the workspace.
        owner: The application type that declares the method.
        node: Parser evidence for the complete method declaration.
        name: The declared method name used in signature matching.
        parameters_node: Parser evidence for the complete input list.
        return_node: Parser evidence for the declared result type.
        parameter_nodes: Parser evidence for each individual input declaration.
        annotations: The method's direct annotation bundle.
        parameter_annotations: Direct annotations attached to method inputs.
        modifiers: Java behavior flags such as ``public`` or ``default``.
        method_type_parameters: Generic variables introduced by this method.
        method_type_bounds: Declared/default bounds for those variables.
        parameter_refs: Parsed application input types, or ``None`` when the
            complete overload signature cannot be proven.
        return_ref: Parsed application result type, or ``None`` when unresolved.

    Example construction:
        ``JavaMethodRecord(id=("/workspace/Items.java", 120, 180),
        owner=items_type, node=<node for ``list``>, name="list",
        parameters_node=<node for ``(String filter)``>,
        return_node=<node for ``List<Item>``>,
        parameter_nodes=(<node for ``String filter``>,),
        annotations=({"name": "GET", ...},), parameter_annotations=(),
        modifiers=frozenset({"public"}), method_type_parameters=(),
        method_type_bounds={},
        parameter_refs=(JavaTypeReference("decl", "java.lang.String"),),
        return_ref=JavaTypeReference("decl", "java.util.List", ...))`` models
        the endpoint handler ``ItemsController.list``.
    """

    id: tuple[Any, ...]
    owner: "JavaTypeRecord"
    node: Any
    name: str
    parameters_node: Any
    return_node: Any
    parameter_nodes: tuple[Any, ...]
    annotations: tuple[dict[str, Any], ...]
    parameter_annotations: tuple[dict[str, Any], ...]
    modifiers: frozenset[str]
    method_type_parameters: tuple[str, ...]
    method_type_bounds: dict[str, JavaTypeReference]
    parameter_refs: tuple[JavaTypeReference, ...] | None
    return_ref: JavaTypeReference | None


@dataclass
class JavaTypeRecord:
    """One application class/interface and its source inheritance facts.

    Attributes:
        fqn: Unique Java identity, such as ``app.ItemsController``.
        unit: Parsed source file containing the type declaration.
        type_info: Source visibility, nesting, and declaration metadata.
        kind: Whether the application type is a class, interface, or record.
        type_parameters: Generic variables declared by the type.
        type_bounds: Bounds/default erasures for those generic variables.
        methods: Source methods declared directly by this type.
        superclass: Direct superclass use after parsing, if proven.
        superclass_declared: Whether source syntax attempted a superclass edge.
        interfaces: Proven direct implemented/extended interface uses.
        interfaces_valid: Whether every declared interface edge was understood.

    Example construction:
        ``JavaTypeRecord(fqn="app.ItemsController", unit=items_unit,
        type_info={"display_name": "ItemsController", ...},
        kind="class_declaration", type_parameters=(), type_bounds={},
        methods=[list_method],
        superclass=JavaTypeReference("decl", "app.BaseController"),
        superclass_declared=True,
        interfaces=(JavaTypeReference("decl", "app.ItemsApi"),),
        interfaces_valid=True)`` represents a concrete controller whose route
        contract may be inherited from ``ItemsApi``.
    """

    fqn: str
    unit: dict[str, Any]
    type_info: dict[str, Any]
    kind: str
    type_parameters: tuple[str, ...]
    type_bounds: dict[str, JavaTypeReference] = field(default_factory=dict)
    methods: list[JavaMethodRecord] = field(default_factory=list)
    superclass: JavaTypeReference | None = None
    superclass_declared: bool = False
    interfaces: tuple[JavaTypeReference, ...] = ()
    interfaces_valid: bool = True


@dataclass
class JavaHierarchyContext:
    """The proven inheritance view used to bind one concrete application type.

    Attributes:
        class_states: Concrete class chain paired with each generic substitution.
        interface_roots: Direct reachable interface branches and substitutions.
        complete: Whether every relevant edge was resolved without ambiguity.

    Example construction:
        ``JavaHierarchyContext(class_states=[(items_controller, {})],
        interface_roots=[(items_api, {})], complete=True)`` says the concrete
        controller and its API contract can safely participate in method binding.
    """

    class_states: list[tuple[JavaTypeRecord, dict[str, JavaTypeReference]]]
    interface_roots: list[tuple[JavaTypeRecord, dict[str, JavaTypeReference]]]
    complete: bool


class JavaSourceHierarchyGraph:
    """Build and query the source relationships behind application handlers.

    Attributes:
        workspace: Shared parsed Java files and cross-file declaration indexes.
        types: Unique traversable application types keyed by fully qualified name.
        _signature_cache: Previously adapted handler signatures keyed by method
            provenance and generic environment.

    The underscore-prefixed graph operations are an intentional package-private
    specialization seam for the Spring and JAX-RS hierarchy analyzers. They are
    documented logic contracts, but not a public package API.

    Example construction:
        ``graph = JavaSourceHierarchyGraph(workspace)`` may produce
        ``graph.types["app.ItemsController"]`` with a superclass edge to
        ``app.BaseController`` and an interface edge to ``app.ItemsApi``.
    """

    def __init__(self, workspace: dict[str, Any]):
        """Build one reusable hierarchy view over a shared Java workspace.

        Example call:
            ``JavaSourceHierarchyGraph(workspace)`` indexes the parsed
            ``ItemsController`` and ``ItemsApi`` declarations for later handler
            and annotation inheritance queries.
        """

        self.workspace = workspace
        # Only unique source identities enter this traversable map; duplicate
        # declarations remain visible in the workspace but make graph edges fail.
        self.types: dict[str, JavaTypeRecord] = {}
        # Erasure depends on the generic environment at the traversal state, so
        # cache keys include both method provenance and the adapted environment.
        self._signature_cache: dict[
            tuple[Any, ...], tuple[str, tuple[str, ...]] | None
        ] = {}
        self._build_java_type_index()

    def _build_java_type_index(self) -> None:
        """Index unique traversable types, then parse all edges and methods.

        Duplicate FQNs and non-class/interface/record declarations remain out
        of the graph.  An edge to either category is therefore incomplete rather
        than resolved by source order.

        Example call:
            ``graph._build_java_type_index()`` rebuilds ``graph.types`` from
            ``graph.workspace``; a unique ``app.ItemsController`` is included,
            while two declarations of that same identity are not traversable.
        """

        # Only unique workspace-visible identities can take part.  Duplicate
        # declarations stay absent, so every edge to one fails closed.
        for fqn, declarations in self.workspace.get("type_declarations", {}).items():
            if len(declarations) != 1:
                continue
            declaration = declarations[0]
            info = declaration["type_info"]
            if info["node"].type not in {
                "class_declaration",
                "interface_declaration",
                "record_declaration",
            }:
                continue
            parameters, _bound_nodes = self._type_parameter_nodes(info["node"])
            self.types[fqn] = JavaTypeRecord(
                fqn=fqn,
                unit=declaration["unit"],
                type_info=info,
                kind=info["node"].type,
                type_parameters=tuple(parameters),
            )

        # Parse after every identity exists, so cross-file edges and method
        # types use one consistent resolver.
        for record in self.types.values():
            parameters, bound_nodes = self._type_parameter_nodes(record.type_info["node"])
            type_vars = set(parameters)
            record.type_bounds = {
                name: (
                    self._parse_type_ref(record, bound_nodes.get(name), type_vars)
                    or JavaTypeReference("decl", "java.lang.Object")
                )
                for name in parameters
            }
            self._parse_inheritance_edges(record, type_vars)
            self._parse_methods(record, type_vars)

    def _type_parameter_nodes(self, declaration_node: Any) -> tuple[list[str], dict[str, Any]]:
        """Collect a type's generic variables and first supported bounds.

        Example call:
            ``graph._type_parameter_nodes(<node for ``class Box<T extends Item>``>)``
            returns ``(["T"], {"T": <node for ``Item``>})``.
        """

        parameters_node = next(
            (child for child in declaration_node.named_children if child.type == "type_parameters"),
            None,
        )
        names: list[str] = []
        bounds: dict[str, Any] = {}
        if parameters_node is None:
            return names, bounds
        for parameter in parameters_node.named_children:
            if parameter.type != "type_parameter" or not parameter.named_children:
                continue
            name_node = parameter.named_children[0]
            name = node_text(self._unit_source_for_node(declaration_node), name_node)
            names.append(name)
            bound = next(
                (child for child in parameter.named_children if child.type == "type_bound"),
                None,
            )
            if bound is not None and bound.named_children:
                bounds[name] = bound.named_children[0]
        return names, bounds

    def _unit_source_for_node(self, node: Any) -> bytes:
        """Recover the owning unit bytes for a retained Tree-sitter node.

        Node byte ranges are only unit-local, so hierarchy parsing identifies
        provenance through the node's root rather than a bare range key.

        Example call:
            ``graph._unit_source_for_node(<method node from Items.java>)``
            returns the immutable source bytes for ``Items.java``.
        """

        # Nodes are kept alive by their workspace unit.  Byte ranges alone are
        # not globally unique, so locate the containing tree by ancestry.
        current = node
        while getattr(current, "parent", None) is not None:
            current = current.parent
        for unit in self.workspace["compilation_units"].values():
            if unit["tree"].root_node == current:
                return unit["source"]
        raise KeyError("Tree-sitter node is not owned by the supplied workspace")

    @staticmethod
    def _modifier_names(node: Any) -> frozenset[str]:
        """Return Java behavior flags used by implementation policy.

        Example call:
            ``JavaSourceHierarchyGraph._modifier_names(
            <node for ``public default Item get()``>)`` returns
            ``frozenset({"public", "default"})``.
        """

        modifiers = next((child for child in node.children if child.type == "modifiers"), None)
        if modifiers is None:
            return frozenset()
        return frozenset(child.type for child in modifiers.children)

    def _parse_methods(self, record: JavaTypeRecord, owner_type_vars: set[str]) -> None:
        """Attach source methods with annotations and parseable signature types.

        Invalid parameter types are retained as an unresolvable signature, so
        later hierarchy consumers can mark affected overload families incomplete
        instead of silently discarding evidence that shadows an ancestor method.

        Example call:
            ``graph._parse_methods(items_type, {"T"})`` appends direct methods
            such as ``list(T filter)`` to ``items_type.methods`` and records its
            parameter as the owner's generic ``T``.
        """

        body = child_by_field(record.type_info["node"], "body")
        if body is None:
            return
        for method_node in body.named_children:
            if method_node.type != "method_declaration":
                continue
            name_node = child_by_field(method_node, "name")
            parameters_node = child_by_field(method_node, "parameters")
            return_node = child_by_field(method_node, "type")
            if name_node is None or parameters_node is None or return_node is None:
                continue
            method_params, method_bound_nodes = self._type_parameter_nodes(method_node)
            all_type_vars = owner_type_vars | set(method_params)
            method_bounds = {
                name: (
                    self._parse_type_ref(record, method_bound_nodes.get(name), all_type_vars)
                    or JavaTypeReference("decl", "java.lang.Object")
                )
                for name in method_params
            }
            parameter_nodes = tuple(
                child
                for child in parameters_node.named_children
                if child.type in {"formal_parameter", "spread_parameter"}
            )
            parameter_refs: list[JavaTypeReference] = []
            parameters_valid = True
            for parameter in parameter_nodes:
                ref = self._parse_parameter_ref(record, parameter, all_type_vars)
                if ref is None:
                    parameters_valid = False
                    break
                parameter_refs.append(ref)
            annotations = tuple(direct_annotation_records(method_node))
            parameter_annotations = tuple(
                annotation
                for parameter in parameter_nodes
                for annotation in direct_annotation_records(parameter)
            )
            record.methods.append(
                JavaMethodRecord(
                    id=(record.unit["source_path"], method_node.start_byte, method_node.end_byte),
                    owner=record,
                    node=method_node,
                    name=node_text(record.unit["source"], name_node),
                    parameters_node=parameters_node,
                    return_node=return_node,
                    parameter_nodes=parameter_nodes,
                    annotations=annotations,
                    parameter_annotations=parameter_annotations,
                    modifiers=self._modifier_names(method_node),
                    method_type_parameters=tuple(method_params),
                    method_type_bounds=method_bounds,
                    parameter_refs=tuple(parameter_refs) if parameters_valid else None,
                    return_ref=self._parse_type_ref(record, return_node, all_type_vars),
                )
            )

    def _parse_inheritance_edges(self, record: JavaTypeRecord, type_vars: set[str]) -> None:
        """Parse direct application inheritance and remember malformed edges.

        Example call:
            ``graph._parse_inheritance_edges(items_type, set())`` records
            ``BaseController`` as its superclass and ``ItemsApi`` as an
            interface; an unresolved interface makes ``interfaces_valid`` false.
        """

        node = record.type_info["node"]
        superclass_node = child_by_field(node, "superclass")
        record.superclass_declared = superclass_node is not None
        if superclass_node is not None and len(superclass_node.named_children) == 1:
            record.superclass = self._parse_type_ref(
                record, superclass_node.named_children[0], type_vars
            )

        interfaces_node = child_by_field(node, "interfaces")
        if interfaces_node is None and record.kind == "interface_declaration":
            interfaces_node = next(
                (child for child in node.named_children if child.type == "extends_interfaces"),
                None,
            )
        if interfaces_node is None:
            return
        type_list = next(
            (child for child in interfaces_node.named_children if child.type == "type_list"),
            None,
        )
        edge_nodes = type_list.named_children if type_list is not None else interfaces_node.named_children
        edges: list[JavaTypeReference] = []
        for edge_node in edge_nodes:
            ref = self._parse_type_ref(record, edge_node, type_vars)
            if ref is None:
                record.interfaces_valid = False
            else:
                edges.append(ref)
        record.interfaces = tuple(edges)

    def _parse_parameter_ref(
        self, record: JavaTypeRecord, parameter: Any, type_vars: set[str]
    ) -> JavaTypeReference | None:
        """Parse one handler input type, including varargs/array dimensions.

        Example call:
            ``graph._parse_parameter_ref(items_type,
            <node for ``String... ids``>, set())`` returns a reference to
            ``java.lang.String[]`` (one application input accepting many IDs).
        """

        type_node = child_by_field(parameter, "type")
        extra_dimensions = 0
        if parameter.type == "spread_parameter":
            extra_dimensions = 1
            type_node = next(
                (
                    child
                    for child in parameter.named_children
                    if child.type not in {"modifiers", "identifier", "dimensions"}
                ),
                None,
            )
        dimensions = child_by_field(parameter, "dimensions")
        if dimensions is not None:
            extra_dimensions += node_text(record.unit["source"], dimensions).count("[")
        ref = self._parse_type_ref(record, type_node, type_vars)
        return self._with_dimensions(ref, extra_dimensions)

    @staticmethod
    def _with_dimensions(ref: JavaTypeReference | None, extra: int) -> JavaTypeReference | None:
        """Add array nesting to an application type when its base is known.

        Example call:
            ``JavaSourceHierarchyGraph._with_dimensions(
            JavaTypeReference("decl", "java.lang.String"), 1)`` returns the
            reference representing ``String[]``; a ``None`` base stays ``None``.
        """

        if ref is None:
            return None
        return JavaTypeReference(ref.kind, ref.name, ref.args, ref.dimensions + extra)

    def _parse_type_ref(
        self, owner: JavaTypeRecord, node: Any | None, type_vars: set[str]
    ) -> JavaTypeReference | None:
        """Parse the restricted Java type subset needed for erased signatures.

        Primitives, arrays, annotations, ordinary generics, variables, and
        declared identities are supported. Wildcards and malformed/recovered
        shapes remain unresolved because generic adaptation would be uncertain.

        Example call:
            ``graph._parse_type_ref(items_type,
            <node for ``List<String>``>, set())`` returns a declared
            ``java.util.List`` reference with one ``java.lang.String`` argument.
        """

        if node is None:
            return None
        if node.type in PRIMITIVE_NODE_TYPES:
            return JavaTypeReference("primitive", node_text(owner.unit["source"], node).strip())
        if node.type == "array_type":
            base = next((child for child in node.named_children if child.type != "dimensions"), None)
            dimensions = sum(
                node_text(owner.unit["source"], child).count("[")
                for child in node.named_children
                if child.type == "dimensions"
            )
            return self._with_dimensions(self._parse_type_ref(owner, base, type_vars), dimensions)
        if node.type == "annotated_type":
            children = [
                child
                for child in node.named_children
                if child.type not in {"annotation", "marker_annotation"}
            ]
            return self._parse_type_ref(owner, children[-1] if len(children) == 1 else None, type_vars)
        if node.type == "generic_type":
            base = next((child for child in node.named_children if child.type != "type_arguments"), None)
            arguments_node = next(
                (child for child in node.named_children if child.type == "type_arguments"),
                None,
            )
            if base is None or arguments_node is None:
                return None
            base_ref = self._parse_type_ref(owner, base, type_vars)
            if base_ref is None or base_ref.kind != "decl" or base_ref.dimensions:
                return None
            arguments: list[JavaTypeReference] = []
            for argument in arguments_node.named_children:
                if argument.type in {"wildcard", "type_bound"}:
                    return None
                parsed = self._parse_type_ref(owner, argument, type_vars)
                if parsed is None:
                    return None
                arguments.append(parsed)
            return JavaTypeReference("decl", base_ref.name, tuple(arguments))
        if node.type not in {"type_identifier", "scoped_type_identifier", "identifier"}:
            return None
        spelling = node_text(owner.unit["source"], node).strip()
        if node.type in {"type_identifier", "identifier"} and spelling in type_vars:
            return JavaTypeReference("variable", spelling)
        identity = self._resolve_type_identity(owner, spelling)
        return JavaTypeReference("decl", identity) if identity is not None else None

    def _resolve_type_identity(self, owner: JavaTypeRecord, spelling: str) -> str | None:
        """Resolve a signature type by Java priority, preserving external identity.

        Source declarations must be unique and accessible.  A fully qualified
        absent external spelling may participate in erasure comparison, but it
        never becomes a source hierarchy traversal target.

        Example call:
            ``graph._resolve_type_identity(items_type, "ItemsApi")`` returns
            ``"app.ItemsApi"`` when that is the single visible source identity;
            competing wildcard-import candidates make the result ``None``.
        """

        unit = owner.unit
        owner_name = owner.type_info["display_name"]
        # Qualified source or explicit external spelling.
        if "." in spelling:
            candidates = resolve_workspace_owner_fqns(
                unit, spelling, owner_name, self.workspace
            )
            if len(candidates) == 1:
                return candidates[0]
            # A fully qualified external type has usable identity for method
            # signatures, but never becomes a traversal target.
            if spelling[0].islower() and not candidates:
                return spelling
            return None

        # Lexical member types have the highest source tier.
        for lexical_owner in lexical_owner_fqns(unit, owner_name):
            candidate = f"{lexical_owner}.{spelling}"
            if workspace_type_fqn_accessible(
                self.workspace, unit, owner_name, candidate
            ):
                return candidate

        exact = unit["imports"]["exact"].get(spelling)
        if exact is not None:
            if not exact:
                return None
            declarations = self.workspace["type_declarations"].get(exact, [])
            if declarations:
                return exact if workspace_type_fqn_accessible(
                    self.workspace, unit, owner_name, exact
                ) else None
            return exact

        same_package = f"{unit['package']}.{spelling}" if unit["package"] else spelling
        if workspace_type_fqn_accessible(
            self.workspace, unit, owner_name, same_package
        ):
            return same_package

        candidates = {
            f"{package}.{spelling}"
            for package in unit["imports"]["wildcards"]
            if workspace_type_fqn_accessible(
                self.workspace, unit, owner_name, f"{package}.{spelling}"
            )
        }
        if spelling in JAVA_LANG_TYPES:
            candidates.add(f"java.lang.{spelling}")
        return next(iter(candidates)) if len(candidates) == 1 else None

    # ------------------------------------------------------------------
    # Generic adaptation and signatures

    def _default_type_environment(self, record: JavaTypeRecord) -> dict[str, JavaTypeReference]:
        """Create bound-based substitutions for a raw application type use.

        Example call:
            ``graph._default_type_environment(<record for ``Box<T extends Item>``>)``
            returns ``{"T": JavaTypeReference("erasure", "app.Item")}``, so
            raw ``Box`` methods can still participate in erased matching.
        """

        return {
            parameter: self._as_erasure_only_ref(
                self._substitute_type_ref(
                    record.type_bounds.get(
                        parameter, JavaTypeReference("decl", "java.lang.Object")
                    ),
                    {},
                )
                or JavaTypeReference("decl", "java.lang.Object")
            )
            for parameter in record.type_parameters
        }

    @staticmethod
    def _as_erasure_only_ref(ref: JavaTypeReference) -> JavaTypeReference:
        """Mark a generic bound as signature evidence, not a runtime target.

        Example call:
            ``JavaSourceHierarchyGraph._as_erasure_only_ref(
            JavaTypeReference("decl", "app.Item"))`` returns the same named
            application type with ``kind="erasure"``.
        """

        return JavaTypeReference("erasure", ref.name, ref.args, ref.dimensions)

    def _substitute_type_ref(
        self, ref: JavaTypeReference | None, env: dict[str, JavaTypeReference], stack: tuple[str, ...] = ()
    ) -> JavaTypeReference | None:
        """Adapt an application type through a cycle-safe generic environment.

        Example call:
            ``graph._substitute_type_ref(JavaTypeReference("variable", "T"),
            {"T": JavaTypeReference("decl", "app.Item")})`` returns the
            reference for ``app.Item``; a cycle such as ``T -> T`` returns
            ``None``.
        """

        if ref is None:
            return None
        if ref.kind == "variable":
            if ref.name in stack:
                return None
            replacement = env.get(ref.name)
            if replacement is None:
                return None
            adapted = self._substitute_type_ref(replacement, env, stack + (ref.name,))
            return self._with_dimensions(adapted, ref.dimensions)
        args: list[JavaTypeReference] = []
        for argument in ref.args:
            adapted = self._substitute_type_ref(argument, env, stack)
            if adapted is None:
                return None
            args.append(adapted)
        return JavaTypeReference(ref.kind, ref.name, tuple(args), ref.dimensions)

    @staticmethod
    def _erased_type_name(ref: JavaTypeReference | None) -> str | None:
        """Project an adapted type to the identity used for override matching.

        Example call:
            ``JavaSourceHierarchyGraph._erased_type_name(
            JavaTypeReference("decl", "java.util.List",
            (JavaTypeReference("decl", "app.Item"),)))`` returns
            ``"java.util.List"`` because generic arguments erase.
        """

        if ref is None or ref.kind == "variable":
            return None
        suffix = "[]" * ref.dimensions
        return f"{ref.name}{suffix}"

    @staticmethod
    def _type_environment_key(env: dict[str, JavaTypeReference]) -> tuple[tuple[str, JavaTypeReference], ...]:
        """Make a stable identity for one generic substitution environment.

        Example call:
            ``JavaSourceHierarchyGraph._type_environment_key({"T": item_ref})``
            returns ``(("T", item_ref),)`` for cache and cycle keys.
        """

        return tuple(sorted(env.items()))

    def _method_env(self, method: JavaMethodRecord, owner_env: dict[str, JavaTypeReference]) -> dict[str, JavaTypeReference]:
        """Add a handler's own generic bounds to its owner's substitutions.

        Example call:
            ``graph._method_env(convert_method, {"T": item_ref})`` may return
            ``{"T": item_ref, "R": response_ref}`` for
            ``<R extends Response> R convert(T value)``.
        """

        env = dict(owner_env)
        for parameter in method.method_type_parameters:
            bound = method.method_type_bounds.get(
                parameter, JavaTypeReference("decl", "java.lang.Object")
            )
            env[parameter] = self._substitute_type_ref(bound, env) or JavaTypeReference(
                "decl", "java.lang.Object"
            )
        return env

    def _erased_method_signature(
        self, method: JavaMethodRecord, owner_env: dict[str, JavaTypeReference]
    ) -> tuple[str, tuple[str, ...]] | None:
        """Return the adapted erased signature used to match overrides.

        Results, including unresolved signatures, are cached per method and
        owner environment because the same declaration can be reached through
        multiple generic inheritance paths.

        Example call:
            ``graph._erased_method_signature(list_method, {"T": string_ref})``
            returns ``("list", ("java.lang.String",))`` for ``list(T)`` under
            that inherited type substitution.
        """

        key = (method.id, self._type_environment_key(owner_env))
        if key in self._signature_cache:
            return self._signature_cache[key]
        if method.parameter_refs is None:
            self._signature_cache[key] = None
            return None
        env = self._method_env(method, owner_env)
        parameters: list[str] = []
        for ref in method.parameter_refs:
            erased = self._erased_type_name(self._substitute_type_ref(ref, env))
            if erased is None:
                self._signature_cache[key] = None
                return None
            parameters.append(erased)
        result = (method.name, tuple(parameters))
        self._signature_cache[key] = result
        return result

    def _resolve_inheritance_edge(
        self, edge: JavaTypeReference, env: dict[str, JavaTypeReference]
    ) -> tuple[JavaTypeRecord, dict[str, JavaTypeReference]] | None:
        """Adapt one inheritance edge to a concrete source type state.

        Example call:
            ``graph._resolve_inheritance_edge(
            JavaTypeReference("decl", "app.ItemsApi", (item_ref,)), {})``
            returns ``(items_api_record, {"T": item_ref})`` when the source
            interface uniquely exists in the workspace.
        """

        adapted = self._substitute_type_ref(edge, env)
        if adapted is None or adapted.kind != "decl" or adapted.dimensions:
            return None
        target = self.types.get(adapted.name)
        if target is None:
            return None
        if adapted.args:
            if len(adapted.args) != len(target.type_parameters):
                return None
            target_env = dict(zip(target.type_parameters, adapted.args))
        else:
            target_env = self._default_type_environment(target)
        return target, target_env

    # ------------------------------------------------------------------
    # Hierarchy graph and effective method binding

    def _build_hierarchy_context(self, root: JavaTypeRecord, root_env: dict[str, JavaTypeReference]) -> JavaHierarchyContext:
        """Build a bounded class chain and reachable interface graph for a root.

        ``complete`` becomes false on missing/invalid source parents, cycles,
        incompatible repeated generic environments, or traversal bounds.  The
        framework consumer uses that flag to suppress uncertain inherited routes.

        Example call:
            ``graph._build_hierarchy_context(items_controller, {})`` returns a
            context whose class states include ``ItemsController`` and whose
            interface roots include ``ItemsApi``; ``complete`` is false if a
            declared parent cannot be resolved.
        """

        complete = True
        class_states: list[tuple[JavaTypeRecord, dict[str, JavaTypeReference]]] = []
        seen_classes: set[str] = set()
        current = (root, root_env)
        while current is not None:
            record, env = current
            if record.fqn in seen_classes or len(class_states) >= MAX_HIERARCHY_DEPTH:
                complete = False
                break
            seen_classes.add(record.fqn)
            class_states.append(current)
            if not record.superclass_declared:
                break
            if record.superclass is None:
                complete = False
                break
            following = self._resolve_inheritance_edge(record.superclass, env)
            if following is None or following[0].kind != "class_declaration":
                complete = False
                break
            current = following

        interface_roots: list[tuple[JavaTypeRecord, dict[str, JavaTypeReference]]] = []
        state_envs: dict[str, tuple[tuple[str, JavaTypeReference], ...]] = {}
        expanded = 0

        def visit(record: JavaTypeRecord, env: dict[str, JavaTypeReference], depth: int, active: frozenset[str]) -> None:
            """Validate and memoize one reachable interface traversal state.

            Example call:
                ``visit(items_api, {"T": item_ref}, 1, frozenset())`` records
                that adapted interface branch, or marks the enclosing context
                incomplete when it encounters a cycle or unresolved edge.
            """

            nonlocal complete, expanded
            if depth > MAX_HIERARCHY_DEPTH or expanded >= MAX_HIERARCHY_STATES:
                complete = False
                return
            if record.fqn in active:
                complete = False
                return
            env_key = self._type_environment_key(env)
            previous = state_envs.get(record.fqn)
            if previous is not None:
                if previous != env_key:
                    complete = False
                return
            state_envs[record.fqn] = env_key
            expanded += 1
            if not record.interfaces_valid:
                complete = False
                return
            for edge in record.interfaces:
                following = self._resolve_inheritance_edge(edge, env)
                if following is None or following[0].kind != "interface_declaration":
                    complete = False
                    continue
                visit(following[0], following[1], depth + 1, active | {record.fqn})

        for class_record, class_env in class_states:
            if not class_record.interfaces_valid:
                complete = False
                continue
            for edge in class_record.interfaces:
                following = self._resolve_inheritance_edge(edge, class_env)
                if following is None or following[0].kind != "interface_declaration":
                    complete = False
                    continue
                interface_roots.append(following)
                visit(following[0], following[1], 1, frozenset())
        return JavaHierarchyContext(class_states, interface_roots, complete)

    @staticmethod
    def _is_public_implementation(method: JavaMethodRecord) -> bool:
        """Identify a method eligible to implement an application handler.

        Example call:
            ``JavaSourceHierarchyGraph._is_public_implementation(list_method)``
            returns ``True`` for a public concrete class method, but ``False``
            for a static, private, abstract, or body-less interface declaration.
        """

        if "static" in method.modifiers or "private" in method.modifiers or "abstract" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return "default" in method.modifiers and method.node.child_by_field_name("body") is not None
        return "public" in method.modifiers

    @staticmethod
    def _is_ancestor_annotation_method(method: JavaMethodRecord) -> bool:
        """Identify an ancestor declaration allowed to supply handler metadata.

        Example call:
            ``JavaSourceHierarchyGraph._is_ancestor_annotation_method(api_get)``
            returns ``True`` for an interface method carrying ``@GET`` and
            ``False`` for a private superclass helper.
        """

        if "static" in method.modifiers or "private" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return True
        return "public" in method.modifiers or "protected" in method.modifiers

    def _methods_for_signature(
        self,
        record: JavaTypeRecord,
        env: dict[str, JavaTypeReference],
        signature: tuple[str, tuple[str, ...]],
    ) -> list[JavaMethodRecord]:
        """Return owner methods matching one adapted application signature.

        Example call:
            ``graph._methods_for_signature(items_api, {"T": string_ref},
            ("list", ("java.lang.String",)))`` returns the matching ``list(T)``
            declaration after substituting ``T`` with ``String``.
        """

        return [method for method in record.methods if self._erased_method_signature(method, env) == signature]

    def _is_genuine_override(self, method: JavaMethodRecord, annotation: dict[str, Any]) -> bool:
        """Recognize only exact ``java.lang.Override`` as non-route metadata.

        Example call:
            ``graph._is_genuine_override(list_method,
            {"name_node": <node for ``Override``>})`` returns ``True`` when
            Java resolution proves ``java.lang.Override``; a user annotation
            also named ``Override`` returns ``False``.
        """

        return resolve_known_annotation(
            method.owner.unit,
            annotation["name_node"],
            {"Override"},
            ("java.lang",),
        ) is not None

    def _has_atomic_annotation_bundle(self, method: JavaMethodRecord) -> bool:
        """Report whether a declaration supplies its own handler metadata.

        Example call:
            ``graph._has_atomic_annotation_bundle(api_list)`` returns ``True``
            when ``api_list`` declares ``@GET`` or an annotated parameter, and
            ``False`` when its only annotation is genuine ``@Override``.
        """

        # A declaration's direct annotation bundle is atomic for hierarchy
        # selection. Genuine @Override is the sole ignored marker.
        if any(not self._is_genuine_override(method, annotation) for annotation in method.annotations):
            return True
        return bool(method.parameter_annotations)

    def _interface_branches(
        self,
        state: tuple[JavaTypeRecord, dict[str, JavaTypeReference]],
        signature: tuple[str, tuple[str, ...]],
        mode: str,
        depth: int = 0,
        active: frozenset[str] = frozenset(),
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] | None = None,
    ) -> tuple[set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]], bool]:
        """Collect candidates from one interface branch with stop-at-declaration rules.

        ``mode='default'`` selects concrete default implementations; annotation
        mode selects an atomic direct annotation bundle. Multiple declarations,
        invalid edges, cycles, or depth overflow set the returned invalid flag so
        consumers cannot choose from a partially understood branch.

        Example call:
            ``graph._interface_branches((items_api, {}),
            ("list", ("java.lang.String",)), "annotation")`` returns candidate
            source keys for the closest ``list(String)`` annotation bundle plus
            a flag saying whether that branch was incomplete.
        """

        if memo is None:
            memo = {}
        record, env = state
        memo_key = (record.fqn, self._type_environment_key(env), signature, mode)
        if memo_key in memo:
            cached_candidates, cached_invalid = memo[memo_key]
            return set(cached_candidates), cached_invalid
        if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
            return set(), True
        matches = self._methods_for_signature(record, env, signature)
        if len(matches) > 1:
            return set(), True
        if matches:
            method = matches[0]
            if mode == "default":
                if self._is_public_implementation(method):
                    result = ({(method.id, self._type_environment_key(env))}, False)
                    memo[memo_key] = result
                    return set(result[0]), result[1]
                return set(), True
            if self._has_atomic_annotation_bundle(method):
                result = ({(method.id, self._type_environment_key(env))}, False)
                memo[memo_key] = result
                return set(result[0]), result[1]
            # An unannotated interface redeclaration does not suppress an
            # annotation bundle on its parent declaration.
        if not record.interfaces_valid:
            return set(), True
        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]] = set()
        blocked = False
        for edge in record.interfaces:
            following = self._resolve_inheritance_edge(edge, env)
            if following is None or following[0].kind != "interface_declaration":
                blocked = True
                continue
            found, invalid = self._interface_branches(
                following,
                signature,
                mode,
                depth + 1,
                active | {record.fqn},
                memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        memo[memo_key] = (set(candidates), blocked)
        return candidates, blocked

    def _resolve_method_candidate(
        self,
        candidate: tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]],
    ) -> tuple[JavaMethodRecord, dict[str, JavaTypeReference]] | None:
        """Restore a handler declaration and substitutions from its stable key.

        Example call:
            ``graph._resolve_method_candidate((api_list.id, (("T", item_ref),)))``
            returns ``(api_list, {"T": item_ref})`` when that declaration still
            belongs to the graph.
        """

        method_id, env_key = candidate
        for record in self.types.values():
            for method in record.methods:
                if method.id == method_id:
                    return method, dict(env_key)
        return None

    def _interface_subtype(
        self,
        child: tuple[JavaMethodRecord, dict[str, JavaTypeReference]],
        ancestor_fqn: str,
    ) -> tuple[bool, bool]:
        """Prove whether a candidate owner is below another interface identity.

        The second result distinguishes a definite non-subtype from an invalid or
        bounded traversal; maximal-specificity selection must reject the latter.

        Example call:
            ``graph._interface_subtype((special_items_method, {}),
            "app.ItemsApi")`` returns ``(True, False)`` when
            ``SpecialItemsApi extends ItemsApi``; the second value is ``True``
            if the relationship could not be safely traversed.
        """

        record = child[0].owner
        env = child[1]
        pending = [(record, env, 0)]
        visited: set[tuple[str, tuple[tuple[str, JavaTypeReference], ...]]] = set()
        while pending:
            current, current_env, depth = pending.pop()
            state_key = (current.fqn, self._type_environment_key(current_env))
            if state_key in visited:
                continue
            visited.add(state_key)
            if depth > MAX_HIERARCHY_DEPTH or len(visited) > MAX_HIERARCHY_STATES:
                return False, True
            if current.fqn == ancestor_fqn and current.fqn != record.fqn:
                return True, False
            if not current.interfaces_valid:
                return False, True
            for edge in current.interfaces:
                following = self._resolve_inheritance_edge(edge, current_env)
                if following is None or following[0].kind != "interface_declaration":
                    return False, True
                pending.append((following[0], following[1], depth + 1))
        return False, False

    def _select_maximally_specific_candidates(
        self,
        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]],
    ) -> tuple[set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]], bool]:
        """Remove candidates dominated by a more specific interface declaration.

        If any candidate provenance or subtype relationship cannot be proven,
        return an invalid result rather than selecting an arbitrary survivor.

        Example call:
            ``graph._select_maximally_specific_candidates({items_key,
            special_items_key})`` returns ``({special_items_key}, False)`` when
            ``SpecialItemsApi`` is proven to extend ``ItemsApi``.
        """

        resolved = {
            candidate: self._resolve_method_candidate(candidate)
            for candidate in candidates
        }
        if any(value is None for value in resolved.values()):
            return set(), True
        dominated: set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]] = set()
        for candidate, value in resolved.items():
            for other, other_value in resolved.items():
                if candidate == other:
                    continue
                is_subtype, invalid = self._interface_subtype(
                    other_value, value[0].owner.fqn
                )
                if invalid:
                    return set(), True
                if is_subtype:
                    dominated.add(candidate)
                    break
        return candidates - dominated, False
__all__ = [
    "JAVA_LANG_TYPES",
    "JavaHierarchyContext",
    "JavaMethodRecord",
    "JavaSourceHierarchyGraph",
    "JavaTypeRecord",
    "JavaTypeReference",
    "MAX_HIERARCHY_DEPTH",
    "MAX_HIERARCHY_STATES",
    "PRIMITIVE_NODE_TYPES",
]
