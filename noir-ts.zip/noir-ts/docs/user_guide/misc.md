# Annotation reports

Return to the [noir-ts user guide](README.md) for installation, invocation, and
artifact naming.

For `--output endpoints.csv`, noir-ts writes two different annotation views:

- `endpoints.csv.log` is the broad recognized-annotation inventory followed by
  diagnostics. It can include annotations that configure, qualify, or bind an
  endpoint without triggering one themselves.
- `endpoints-anno-without-endpoints.log` contains recognized trigger-capable
  annotation occurrences whose exact annotated source declaration is not
  represented by a surviving noir-ts endpoint row.

When `--noir-report` is supplied, noir-ts also writes
`endpoints-anno-without-noir-endpoints.log`. This report contains recognized
trigger-capable annotation occurrences that have no exact source-location
match in the supplied Noir report.

An annotation name is not enough to enter either unmatched-annotation report.
Its identity must resolve to a supported framework annotation, the relevant
framework must be enabled, and the annotation must be used in a placement that
can represent an endpoint. For example, a method mapping can be a trigger,
while the same mapping used only as a type-level path prefix is not one.

## Fixed trigger annotation catalog

The following are all fixed, built-in annotation identities that noir-ts can
treat as endpoint triggers.

### Spring MVC

- `org.springframework.web.bind.annotation.RequestMapping`
- `org.springframework.web.bind.annotation.GetMapping`
- `org.springframework.web.bind.annotation.PostMapping`
- `org.springframework.web.bind.annotation.PutMapping`
- `org.springframework.web.bind.annotation.DeleteMapping`
- `org.springframework.web.bind.annotation.PatchMapping`

### Spring HTTP Exchange

- `org.springframework.web.service.annotation.HttpExchange`
- `org.springframework.web.service.annotation.GetExchange`
- `org.springframework.web.service.annotation.PostExchange`
- `org.springframework.web.service.annotation.PutExchange`
- `org.springframework.web.service.annotation.DeleteExchange`
- `org.springframework.web.service.annotation.PatchExchange`

### Spring messaging

- `org.springframework.messaging.handler.annotation.MessageMapping`
- `org.springframework.messaging.handler.annotation.SubscribeMapping`

### Jakarta JAX-RS

- `jakarta.ws.rs.GET`
- `jakarta.ws.rs.POST`
- `jakarta.ws.rs.PUT`
- `jakarta.ws.rs.DELETE`
- `jakarta.ws.rs.PATCH`
- `jakarta.ws.rs.HEAD`
- `jakarta.ws.rs.OPTIONS`

### Javax JAX-RS

- `javax.ws.rs.GET`
- `javax.ws.rs.POST`
- `javax.ws.rs.PUT`
- `javax.ws.rs.DELETE`
- `javax.ws.rs.PATCH`
- `javax.ws.rs.HEAD`
- `javax.ws.rs.OPTIONS`

### Jakarta and Javax WebSocket

- `jakarta.websocket.server.ServerEndpoint`
- `javax.websocket.server.ServerEndpoint`

The selectable Wicket integration currently defines no trigger annotation
identities.

## Source-defined trigger annotations

In addition to the fixed catalog, noir-ts can report two categories whose
fully qualified names come from the analyzed source tree and therefore cannot
be listed in advance:

- a source-defined Spring composed mapping whose definition resolves through
  the supported Spring MVC composition model; and
- a source-defined JAX-RS request-method annotation whose definition has a
  valid runtime-retained Jakarta or Javax `@HttpMethod` declaration.

For these categories, the unmatched report identifies the outer annotation
used on the endpoint-capable declaration, not `@RequestMapping`, `@HttpMethod`,
`@Target`, `@Retention`, or other metadata inside its definition.

Supporting annotations do not appear in either unmatched-annotation report.
Recognized annotations such as JAX-RS `Path`, `ApplicationPath`, `Consumes`,
`Produces`, `FormParam`, `PathParam`, and `QueryParam` remain visible only in
the broad `endpoints.csv.log` inventory.
