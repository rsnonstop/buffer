# noir-ts user guide

Run the setup and analysis commands from the root of the `noir-ts` checkout.
Replace the example paths with paths on your machine. The directory that will
contain `--output` must already exist.

## 1. Install the runtime prerequisites

`uv` is assumed to be installed and available on `PATH`. The
virtual-environment command below uses Python 3.13 and can let `uv` download it
when Python 3.13 is not already installed. A JDK and a Java build are not
required to scan an existing source tree.

### Windows (`cmd.exe`)

Open `cmd.exe` in the `noir-ts` checkout and run:

```bat
uv venv --python 3.13 ".venv"
.venv\Scripts\activate.bat
uv pip install --system-certs --python ".venv\Scripts\python.exe" -r requirements.txt
python src\noir_sbt.py --help
```

### Linux (`bash`)

Open a shell in the `noir-ts` checkout and run:

```bash
uv venv --python 3.13 ".venv"
source ".venv/bin/activate"
uv pip install --system-certs --python ".venv/bin/python" -r requirements.txt
python src/noir_sbt.py --help
```

The two pinned runtime packages are installed from `requirements.txt`. Repeat
the `uv pip install` command after that file changes.

## 2. Prepare the inputs

Every analysis uses these two required inputs:

- `--path <directory>`: an existing application source directory. noir-ts
  searches it recursively for filenames ending in `.java`, case-insensitively.
- `--output <file>`: the endpoint CSV destination. A relative path is relative
  to the directory from which the command is run. The parent directory is not
  created automatically.

Source files below a directory component named `node_modules`, `.git`, `dist`,
`build`, `target`, `__pycache__`, `.venv`, `venv`, `.idea`, `.vscode`, `tmp`,
`.next`, `out`, `vendor`, or `test` are not scanned.

An analysis can also use these optional inputs:

- one or more `--framework <value>` options, as listed in the next section;
- `--noir-report <file>`, an existing Noir v1.1-compatible JSON report to
  compare with the annotations found by noir-ts.

In `auto` mode only, exact lowercase `pom.xml` files are also read for framework
markers. They are marker inputs, not Java endpoint sources.

These are all source-tree file inputs that can affect a run:

| Files below `--path` | When used | Effect |
|---|---|---|
| `*.java` (case-insensitive suffix) | every run | endpoint and annotation input |
| `application.properties`, `application.yml`, or `application.yaml` at an inferred project root, `resources/`, or `src/main/resources/` | when Spring is selected | route placeholders and configured base paths |
| regular, non-symlink `web.xml` files up to 10 MiB, except below ignored directories, `src/test/`, or `src/it/` | when `jaxrx` is selected | JAX-RS servlet/deployment prefixes |
| exact `pom.xml` files | `auto` only | code-generation marker notices; never endpoint input |

### Accepted Noir report shape

The smallest accepted report is `{"endpoints": []}`. Each endpoint that is
present must have a `details.code_paths` array, and every code-path item must
have a non-empty `path`:

```json
{
  "endpoints": [
    {
      "details": {
        "code_paths": [
          {
            "path": "src/main/java/example/ItemsApi.java",
            "line": 42
          }
        ]
      }
    }
  ]
}
```

`path` can be absolute or relative to `--path`. A missing or `null` `line` is
accepted but cannot match an annotation. Any supplied line must be a positive
integer, not a Boolean. The report is an input: noir-ts does not modify or copy
it. It must differ from every generated path: `<output>`, `<output>.log`,
`<stem>-anno-without-endpoints.log`, and, when `--noir-report` is used,
`<stem>-anno-without-noir-endpoints.log`.

## 3. Choose how to analyze the source

The command has no positional arguments or subcommands:

```text
python src/noir_sbt.py --path <source-directory> --output <output-file> [--framework <value> ...] [--noir-report <noir-report.json>]
```

The following table is the exhaustive framework-selection list. For an
explicit multi-framework selection, repeat the entire option as shown; do not
use a comma-separated value.

| Selection | Command fragment | Analyzers used |
|---|---|---|
| Default | omit `--framework` | Spring and JAX-RS / Java WebSocket |
| Automatic | `--framework auto` | Spring and/or `jaxrx`, or neither, according to markers |
| Spring | `--framework spring` | Spring only |
| JAX-RS | `--framework jaxrx` | JAX-RS and Java WebSocket only |
| Wicket | `--framework wicket` | Wicket stub only; it currently produces no endpoints |
| Spring + JAX-RS | `--framework spring --framework jaxrx` | exactly Spring and JAX-RS / Java WebSocket |
| Spring + Wicket | `--framework spring --framework wicket` | exactly Spring and the empty Wicket stub |
| JAX-RS + Wicket | `--framework jaxrx --framework wicket` | exactly JAX-RS/Java WebSocket and the empty Wicket stub |
| All explicit families | `--framework spring --framework jaxrx --framework wicket` | Spring, JAX-RS / Java WebSocket, and the empty Wicket stub |

The explicit option order does not matter. Each explicit value must be unique.
`auto` must appear exactly once and cannot be combined with another framework.
The CLI token is `jaxrx`; `jaxrs` is not accepted.

`auto` selects Spring when Java text contains
`org.springframework.web.bind.annotation.` or
`org.springframework.web.reactive.function.server`. It selects JAX-RS when
Java text contains `jakarta.ws.rs` or `javax.ws.rs`. This is case-sensitive raw
text detection, so comments and string literals can also select an analyzer.
Pure `jakarta.websocket` or `javax.websocket` source does not select `jaxrx` in
`auto`; use `--framework jaxrx` for WebSocket-only source. Java text containing
`org.apache.wicket` and a `pom.xml` containing `openapi.codegen` or
`io.swagger.codegen` produce advisory findings only and select no analyzer;
Wicket must be selected explicitly. If the desired families are already known,
use an explicit selection or omit `--framework` to run both non-Wicket families.

`--noir-report <file>` can be added to every row in the table. For every
framework selection:

- without `--noir-report`, noir-ts generates `<output>`, `<output>.log`, and
  `<stem>-anno-without-endpoints.log`;
- with `--noir-report`, noir-ts generates `<output>`, `<output>.log`,
  `<stem>-anno-without-endpoints.log`, and
  `<stem>-anno-without-noir-endpoints.log`.

Here, `<stem>` is the `--output` path with only its final filename suffix
removed.

## 4. Read the generated artifacts

Let `<output>` be the effective `--output` path after user-home expansion;
relative paths remain relative to the current directory. Let `<stem>` be that
path with only its final filename suffix removed. A successful run always
replaces `<output>`, `<output>.log`, and
`<stem>-anno-without-endpoints.log`:

| Generated file | Contents |
|---|---|
| `<output>` | Semicolon-delimited endpoint inventory CSV. It has a UTF-8 byte-order mark, one header, and zero or more endpoint rows. |
| `<output>.log` | One recognized-annotation inventory block per discovered Java file, followed by a `Diagnostics:` section. |
| `<stem>-anno-without-endpoints.log` | Recognized endpoint-trigger annotation occurrences whose exact annotated Java declarations are not represented by a surviving row in the noir-ts CSV. |

Supplying `--noir-report` adds exactly
`<stem>-anno-without-noir-endpoints.log`:

| Additional generated file | Contents |
|---|---|
| `<stem>-anno-without-noir-endpoints.log` | Counts and details for noir-ts endpoint-trigger annotation occurrences without an exact `(canonical source file, annotation start line)` match in the supplied Noir report. |

For example, `--output results/endpoints.audit.csv` produces:

```text
results/endpoints.audit.csv
results/endpoints.audit.csv.log
results/endpoints.audit-anno-without-endpoints.log
results/endpoints.audit-anno-without-noir-endpoints.log  # only with --noir-report
```

If `--output` has no suffix, the report names are simply appended. For example,
`--output results/endpoints` produces `results/endpoints`,
`results/endpoints.log`, and
`results/endpoints-anno-without-endpoints.log`. With `--noir-report`, it also
produces `results/endpoints-anno-without-noir-endpoints.log`.

### Endpoint CSV columns

The CSV header is:

```text
module_name;interface_type;endpoint;source_file_name;method_name;parameters;method_annotation_line
```

| Column | Meaning |
|---|---|
| `module_name` | basename of the resolved directory passed to `--path` |
| `interface_type` | protocol/surface plus operation, such as `http GET`, `http-client POST`, `http-gateway GET`, `http-static-handler GET`, `ws GET`, or `ws SEND` |
| `endpoint` | normalized route, URL, or message destination |
| `source_file_name` | source path relative to `--path`, using `/` separators |
| `method_name` | analyzer-selected handler, type, or producer label |
| `parameters` | source-level handler parameter spelling supplied by the analyzer |
| `method_annotation_line` | one-based source line of the endpoint-defining method annotation when noir-ts can identify one; otherwise blank |

A run that finds no endpoints still creates `<output>` with this CSV header and
no data rows.

With no discovered Java files, `<stem>-anno-without-endpoints.log` is zero bytes
and `<output>.log` still contains `Diagnostics:`. With Java files and selected
analyzers but no trigger items, `<stem>-anno-without-endpoints.log` instead has
per-file, per-framework `Annotations without endpoints: none` sections.
`<stem>-anno-without-noir-endpoints.log` is never zero bytes on success: even
with zero triggers or no unmatched triggers, it contains its count summary and
an explicit `none` result.

### Annotation and diagnostics log

`<output>.log` is broader than `<stem>-anno-without-endpoints.log` and
`<stem>-anno-without-noir-endpoints.log`. It includes recognized trigger and
supporting annotations for the selected frameworks. Each annotation item shows
its source spelling, line, resolved framework identity, and source extract.
Files without recognized annotations show `Annotations: none`. Timestamped
mode, detection, ambiguity, and other analysis messages appear after
`Diagnostics:`.

### Annotations without noir-ts endpoint rows

`<stem>-anno-without-endpoints.log` compares trigger-capable annotations with
the endpoint rows produced by the same noir-ts run. It groups results by source
file and selected framework and shows `Annotation`, `Resolved`, `Applied to`,
`Line`, and `Extract` for every unrepresented trigger. A section with no such
item says `Annotations without endpoints: none`.

`<stem>-anno-without-endpoints.log` does not include supporting annotations,
and an item does not by itself prove that a reachable endpoint was missed. See
the [annotation report reference](misc.md) for the complete trigger catalog.

### Annotations without a Noir source-location match

`<stem>-anno-without-noir-endpoints.log` compares the same trigger-capable
annotation set with every line-bearing `details.code_paths` location in the
supplied Noir report. It summarizes total noir-ts annotations, unique Noir
locations, exact matches, and unmatched occurrences, then lists each unmatched
annotation with its framework identity and source extract.

Matching uses only canonical source file and one-based annotation start line.
URL, HTTP method, annotation name, adjacent lines, and enclosing declarations
do not substitute for that exact location.
`<stem>-anno-without-noir-endpoints.log` can therefore identify a location
difference; it does not by itself prove that Noir missed a reachable endpoint.

## 5. Invocation examples

Create the output directory first, then choose one of the framework modes above.

### Default Spring and JAX-RS analysis

```text
mkdir results
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv"
```

Generated files:

- `results/endpoints.csv`;
- `results/endpoints.csv.log`;
- `results/endpoints-anno-without-endpoints.log`.

No `results/endpoints-anno-without-noir-endpoints.log` is generated or removed
because this invocation has no `--noir-report`. No marker detection is used.

### One or several explicit families

```text
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv" --framework spring --framework jaxrx
```

Replace the repeated framework fragments with any explicit row from the
selection table. The selected set controls which endpoint rows, annotation
classifications, and framework sections can appear; it does not change the
generated filenames. This invocation generates `results/endpoints.csv`,
`results/endpoints.csv.log`, and
`results/endpoints-anno-without-endpoints.log`.
It does not generate or remove
`results/endpoints-anno-without-noir-endpoints.log` because the command has no
`--noir-report`.

### `auto` without `--noir-report`

```text
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv" --framework auto
```

Generated files:

- `results/endpoints.csv`: endpoints from the Spring and/or JAX-RS analyzers
  selected by source markers; header-only when neither analyzer is selected or
  no endpoint is found.
- `results/endpoints.csv.log`: the selected-framework annotation inventory,
  `Framework mode: auto`, marker-detection events, and other diagnostics.
- `results/endpoints-anno-without-endpoints.log`: trigger annotations not
  represented by the generated CSV. It is zero bytes when `auto` selects no
  supported analyzer.

No `results/endpoints-anno-without-noir-endpoints.log` is generated or removed
by this invocation.

### `auto` with `--noir-report`

```text
python src/noir_sbt.py --path "<application-source-directory>" --output "results/endpoints.csv" --framework auto --noir-report "<noir-report.json>"
```

Generated files:

- `results/endpoints.csv`: the auto-selected endpoint inventory.
- `results/endpoints.csv.log`: the auto-selected annotation inventory and
  diagnostics.
- `results/endpoints-anno-without-endpoints.log`: auto-selected trigger
  annotations not represented by the generated noir-ts CSV.
- `results/endpoints-anno-without-noir-endpoints.log`: comparison summary and
  auto-selected trigger annotations without an exact source-file/line match in
  the supplied `<noir-report.json>`.

The supplied `noir-report.json` remains an input and is not listed as a
generated file. If `auto` selects neither supported analyzer,
`results/endpoints-anno-without-endpoints.log` is zero bytes, while
`results/endpoints-anno-without-noir-endpoints.log` is still generated with
zero noir-ts trigger counts.

## 6. Confirm completion

A completed analysis exits with status `0`, prints
`noir-ts analysis completed.`, and prints the effective paths for `<output>`,
`<output>.log`, `<stem>-anno-without-endpoints.log`, and, when requested,
`<stem>-anno-without-noir-endpoints.log`. Argument errors exit with status `2`.

None of these output files is appended. Successful reruns replace `<output>`,
`<output>.log`, and `<stem>-anno-without-endpoints.log`; comparison-mode reruns
also replace `<stem>-anno-without-noir-endpoints.log`. A run without
`--noir-report` does not remove an older
`<stem>-anno-without-noir-endpoints.log`; use the printed completion inventory
to distinguish current outputs from a stale optional file.
