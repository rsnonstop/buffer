#!/usr/bin/env python3
# Usage examples:
#
# Analyze Spring Boot and JAX-RS sources:
# python3 src/noir_sbt.py \
#   --path "/mnt/app1" \
#   --output "endpoints.csv"
#
# Analyze only Spring Boot sources:
# python3 src/noir_sbt.py \
#   --path "/mnt/app1" \
#   --output "endpoints.csv" \
#   --framework spring
#
# Analyze only JAX-RS sources:
# python3 src/noir_sbt.py \
#   --path "/mnt/app1" \
#   --output "endpoints.csv" \
#   --framework jaxrx
#
# Arguments:
#   --path       application source directory (required)
#   --output     endpoint CSV path (required)
#   --framework  spring or jaxrx; omit to analyze with both

from __future__ import annotations

import csv
import json
import os
import re
import sys
from importlib import metadata
from pathlib import Path
import argparse
from datetime import datetime
from typing import Any, Dict, Iterable, List

from noir_sbt_jax_recall import analyze_jax_recall
from noir_sbt_jax_config import (
    build_jax_deployment_configuration,
    select_jax_deployment_path,
)
from noir_sbt_jax_websocket import analyze_jax_websocket
from noir_sbt_spring_config import (
    analyze_spring_resource_handlers,
    apply_spring_configuration,
    build_spring_configuration,
)
from noir_sbt_spring_clients import analyze_spring_clients
from noir_sbt_spring_gateway import analyze_spring_gateway
from noir_sbt_spring_hierarchy import analyze_spring_hierarchy
from noir_sbt_spring_recall import analyze_spring_recall
from noir_sbt_spring_websocket import analyze_spring_websocket

try:
    import tree_sitter_java as tsjava
    from tree_sitter import Language, Parser, Query, QueryCursor
except ModuleNotFoundError:
    # Keep imports side-effect free so helpers and CLI help remain usable in
    # environments where the analysis dependencies have not been installed.
    tsjava = None
    Language = Parser = Query = QueryCursor = None

#from tree_sitter_languages import get_parser


DELIM = ";"
CSV_FIELDNAMES = [
    "module_name",
    "interface_type",
    "endpoint",
    "source_file_name",
    "method_name",
    "parameters",
]
IGNORED_DIRS = {
    "node_modules",
    ".git",
    "dist",
    "build",
    "target",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "tmp",
    ".next",
    "out",
    "vendor",
    "test",
}
SPRING_MAPPING_PACKAGE = "org.springframework.web.bind.annotation"
SPRING_ALIAS_FOR_PACKAGE = "org.springframework.core.annotation"
SPRING_MAPPING_METHODS = {
    "GetMapping": "GET",
    "PostMapping": "POST",
    "PutMapping": "PUT",
    "DeleteMapping": "DELETE",
    "PatchMapping": "PATCH",
    "RequestMapping": None,
}
SPRING_HTTP_METHODS = (
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
    "TRACE",
)
SPRING_REQUEST_MAPPING_ATTRIBUTES = {
    "name",
    "value",
    "path",
    "method",
    "params",
    "headers",
    "consumes",
    "produces",
    "version",
}
SPRING_MAX_CONSTANT_DEPTH = 12
SPRING_MAX_CONSTANT_LENGTH = 8192
JAX_RS_PACKAGES = ("jakarta.ws.rs", "javax.ws.rs")
JAX_RS_CORE_PACKAGES = ("jakarta.ws.rs.core", "javax.ws.rs.core")
JAX_RS_HTTP_METHODS = (
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
)
JAX_HTTP_METHOD_STATIC_CONSTANTS = {
    f"{package}.HttpMethod": {
        method: method for method in JAX_RS_HTTP_METHODS
    }
    for package in JAX_RS_PACKAGES
}
HTTP_METHOD_TOKEN = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")
JAVA_ELEMENT_TYPES = {
    "ANNOTATION_TYPE",
    "CONSTRUCTOR",
    "FIELD",
    "LOCAL_VARIABLE",
    "METHOD",
    "MODULE",
    "PACKAGE",
    "PARAMETER",
    "RECORD_COMPONENT",
    "TYPE",
    "TYPE_PARAMETER",
    "TYPE_USE",
}

log_file = "noir_sbt.log"
input_srcdir = ""
module_name = ""
SUPPORTED_TREE_SITTER_VERSIONS = {
    "tree-sitter": "0.25.2",
    "tree-sitter-java": "0.23.5",
}

SPRING_QUERY_SOURCES = {
    "annotation_declaration": r"""
        (annotation_type_declaration
            name: (identifier) @annotation.declaration.name) @annotation.declaration.node
    """,
    "field": r"""
        [
            (field_declaration
                type: (_) @constant.type
                declarator: (variable_declarator
                    name: (identifier) @constant.name
                    value: (_)? @constant.value) @constant.declarator)
            (constant_declaration
                type: (_) @constant.type
                declarator: (variable_declarator
                    name: (identifier) @constant.name
                    value: (_)? @constant.value) @constant.declarator)
        ] @constant.field
    """,
    "import": r"""
        (import_declaration) @import.node
    """,
    "type": r"""
        [
            (class_declaration name: (identifier) @type.name)
            (interface_declaration name: (identifier) @type.name)
            (enum_declaration name: (identifier) @type.name)
            (record_declaration name: (identifier) @type.name)
            (annotation_type_declaration name: (identifier) @type.name)
        ] @type.node
    """,
    "type_annotation": r"""
        (class_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @type.name
            body: (class_body) @type.body) @type.node
        (record_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @type.name
            body: (class_body) @type.body) @type.node
    """,
    "method_annotation": r"""
        (class_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
        (record_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
    """,
    "record_component_annotation": r"""
        (record_declaration
            name: (identifier) @type.name
            parameters: (formal_parameters
                (formal_parameter
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    type: (_) @component.type
                    name: (identifier) @component.name) @component.node)
            body: (class_body) @type.body) @type.node
        (record_declaration
            name: (identifier) @type.name
            parameters: (formal_parameters
                (spread_parameter
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    (variable_declarator
                        name: (identifier) @component.name) @component.declarator) @component.node)
            body: (class_body) @type.body) @type.node
    """,
    "record_method": r"""
        (record_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
    """,
}

JAX_QUERY_SOURCES = {
    **SPRING_QUERY_SOURCES,
    "package": r"""
        (package_declaration
            [
                (identifier)
                (scoped_identifier)
            ] @package.name) @package.node
    """,
    "annotation_meta": r"""
        (annotation_type_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @annotation.declaration.name
            body: (annotation_type_body) @annotation.declaration.body
        ) @annotation.declaration.node
    """,
    "annotation_element": r"""
        (annotation_type_declaration
            name: (identifier) @annotation.declaration.name
            body: (annotation_type_body
                (annotation_type_element_declaration
                    type: (_) @annotation.element.type
                    name: (identifier) @annotation.element.name
                    value: (_)? @annotation.element.default
                ) @annotation.element.node
            )
        ) @annotation.declaration.node
    """,
    "enum_constant": r"""
        (enum_declaration
            name: (identifier) @enum.type.name
            body: (enum_body
                (enum_constant
                    name: (identifier) @enum.constant.name
                ) @enum.constant.node
            )
        ) @enum.type.node
    """,
}


def JaxRS_Detector(fname,fcontent):
    # Every Java file is passed to the Tree-Sitter analyzer.
    # JAX-RS annotations, rather than text matching, decide whether endpoints exist.
    return(Path(fname).suffix.lower() == ".java")


def SpringBoot_Detector(fname,fcontent):
    # Every Java file is passed to the Tree-Sitter analyzer.
    # Mapping annotations, rather than regex text matches, decide whether endpoints exist.
    return(Path(fname).suffix.lower() == ".java")

def node_text(source: bytes, node) -> str:
    return source[node.start_byte:node.end_byte].decode("utf8")

def find_first(node, type_name: str):
    for child in node.children:
        if child.type == type_name:
            return child
    return None

def child_by_field(node, field_name: str):
    """Tree-sitter поля стабильнее структуры children."""
    try:
        return node.child_by_field_name(field_name)
    except Exception:
        return None

def combine_paths(basepath, endpoint_path):
    if not basepath and not endpoint_path:
        return("/")
    if not basepath:
        return(endpoint_path)
    if not endpoint_path:
        return(basepath)
    return(basepath.rstrip('/')+'/'+endpoint_path.lstrip('/'))

def get_callable_parameters_as_is(source: bytes, params_node) -> str:
    if not params_node:
        return ""

    params_text=node_text(source, params_node)
    if params_text.startswith("(") and params_text.endswith(")"):
        params_text=params_text[1:-1]

    return(params_text.strip())



def get_annotation_arguments(annotation_node):
    positional=[]
    named=dict()
    arguments=child_by_field(annotation_node, "arguments")

    if not arguments:
        return(positional, named)

    for child in arguments.named_children:
        # Tree-sitter exposes comments as named children. They are trivia, not
        # additional annotation values (for example @GetMapping("/x" /*...*/)).
        if child.type in {"line_comment", "block_comment"}:
            continue
        if child.type == "element_value_pair":
            key_node=child_by_field(child, "key")
            value_node=child_by_field(child, "value")
            if key_node and value_node:
                key=key_node.text.decode('utf8')
                named[key]=value_node
        else:
            positional.append(child)

    return(positional, named)

def require_tree_sitter():
    if tsjava is None or any(value is None for value in (Language, Parser, Query, QueryCursor)):
        raise RuntimeError(
            "Spring/JAX-RS analysis requires the tree_sitter and "
            "tree_sitter_java Python packages"
        )
    installed_versions = {}
    for distribution_name in SUPPORTED_TREE_SITTER_VERSIONS:
        try:
            installed_versions[distribution_name] = metadata.version(distribution_name)
        except metadata.PackageNotFoundError:
            installed_versions[distribution_name] = None
    if installed_versions != SUPPORTED_TREE_SITTER_VERSIONS:
        actual = ", ".join(
            f"{name} {installed_versions[name] or 'unknown'}"
            for name in SUPPORTED_TREE_SITTER_VERSIONS
        )
        raise RuntimeError(
            f"unsupported Tree-sitter dependency pair ({actual}); install "
            "tree-sitter 0.25.2 with tree-sitter-java 0.23.5"
        )


def build_java_runtime(query_sources, java_language=None, parser=None):
    """Create a reusable Java parser and compile a framework query set once."""
    require_tree_sitter()
    java_language = java_language or Language(tsjava.language())
    return {
        "language": java_language,
        "parser": parser or Parser(java_language),
        "queries": {
            name: Query(java_language, query_source)
            for name, query_source in sorted(query_sources.items())
        },
    }


def build_spring_runtime(java_language=None, parser=None):
    """Create one reusable Java parser and compile all Spring queries once."""
    return build_java_runtime(
        SPRING_QUERY_SOURCES, java_language=java_language, parser=parser
    )


def build_jax_runtime(java_language=None, parser=None):
    """Create one reusable Java parser and compile all JAX-RS queries once."""
    return build_java_runtime(
        JAX_QUERY_SOURCES, java_language=java_language, parser=parser
    )


def run_query_matches(query, root, lifetime_owners=None):
    """Keep each QueryCursor match as the association unit."""
    cursor = QueryCursor(query)
    matches = cursor.matches(root)
    if lifetime_owners is not None:
        lifetime_owners.append((cursor, matches))
    return matches


def first_capture(captures, name):
    nodes = captures.get(name, [])
    return nodes[0] if nodes else None


def tree_node_key(node):
    return (node.start_byte, node.end_byte)


def nearest_enclosing_type(node):
    current = getattr(node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return current
        current = getattr(current, "parent", None)
    return None


def type_is_abstract(source, type_node):
    modifiers = find_first(type_node, "modifiers")
    return bool(
        type_node.type == "class_declaration"
        and modifiers
        and any(child.type == "abstract" for child in modifiers.children)
    )


def type_is_workspace_visible(type_node):
    current = getattr(type_node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return True
        if current.type in {
            "method_declaration",
            "constructor_declaration",
            "compact_constructor_declaration",
            "lambda_expression",
            "block",
            "constructor_body",
            "static_initializer",
        }:
            return False
        current = getattr(current, "parent", None)
    return True


def build_type_infos(source, type_matches):
    infos = {}
    ordered = []
    for _pattern_index, captures in type_matches:
        type_node = first_capture(captures, "type.node")
        name_node = first_capture(captures, "type.name")
        if type_node is None or name_node is None:
            continue
        ordered.append((type_node.start_byte, type_node, node_text(source, name_node)))

    for _start_byte, type_node, simple_name in sorted(ordered):
        outer_node = nearest_enclosing_type(type_node)
        outer_key = tree_node_key(outer_node) if outer_node is not None else None
        outer_info = infos.get(outer_key)
        display_name = (
            f"{outer_info['display_name']}.{simple_name}"
            if outer_info is not None
            else simple_name
        )
        key = tree_node_key(type_node)
        infos[key] = {
            "node": type_node,
            "simple_name": simple_name,
            "display_name": display_name,
            "outer_key": outer_key if outer_info is not None else None,
            "abstract": type_is_abstract(source, type_node),
            "workspace_visible": type_is_workspace_visible(type_node)
            and (outer_info is None or outer_info["workspace_visible"]),
            "mapping": None,
        }
    return infos


def visible_local_type_infos(unit, context_node=None):
    """Return source types that can lexically shadow a simple import."""
    infos = unit.get("type_infos", {})
    visible_keys = {
        key
        for key, info in infos.items()
        if info["outer_key"] is None and info["workspace_visible"]
    }
    if context_node is None:
        return [infos[key] for key in visible_keys]

    current = nearest_enclosing_type(context_node)
    scope_keys = set()
    while current is not None:
        key = tree_node_key(current)
        info = infos.get(key)
        if info is None:
            break
        scope_keys.add(key)
        visible_keys.add(key)
        current = (
            infos[info["outer_key"]]["node"]
            if info["outer_key"] in infos
            else None
        )
    visible_keys.update(
        key
        for key, info in infos.items()
        if info["workspace_visible"] and info["outer_key"] in scope_keys
    )
    return [infos[key] for key in visible_keys]


def visible_local_type_names(unit, context_node=None):
    return {
        info["simple_name"]
        for info in visible_local_type_infos(unit, context_node)
    }


def parse_java_imports(source, import_matches):
    exact = {}
    wildcards = set()
    static_exact = {}
    static_wildcards = set()
    for _pattern_index, captures in import_matches:
        import_node = first_capture(captures, "import.node")
        if import_node is None:
            continue
        declaration = node_text(source, import_node).strip()
        match = re.fullmatch(r"import\s+(static\s+)?([^;]+)\s*;", declaration)
        if not match:
            continue
        target = match.group(2).strip()
        if match.group(1):
            if target.endswith(".*"):
                static_wildcards.add(target[:-2])
                continue
            simple_name = target.rsplit(".", 1)[-1]
            previous = static_exact.get(simple_name)
            static_exact[simple_name] = (
                target if previous in (None, target) else ""
            )
            continue
        if target.endswith(".*"):
            wildcards.add(target[:-2])
            continue
        simple_name = target.rsplit(".", 1)[-1]
        previous = exact.get(simple_name)
        exact[simple_name] = target if previous in (None, target) else ""
    return {
        "exact": exact,
        "wildcards": wildcards,
        "static_exact": static_exact,
        "static_wildcards": static_wildcards,
    }


def declared_annotation_names(source, declaration_matches):
    names = set()
    for _pattern_index, captures in declaration_matches:
        name_node = first_capture(captures, "annotation.declaration.name")
        if name_node is not None:
            names.add(node_text(source, name_node))
    return names


def resolve_spring_mapping_name(
    source,
    annotation_name_node,
    imports,
    local_annotations,
    unit=None,
):
    spelling = node_text(source, annotation_name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in SPRING_MAPPING_METHODS:
        return None

    expected = f"{SPRING_MAPPING_PACKAGE}.{simple_name}"
    if "." in spelling:
        return simple_name if spelling == expected else None
    if unit is None and simple_name in local_annotations:
        return None
    if unit is not None and simple_name in visible_local_type_names(
        unit, annotation_name_node
    ):
        return None

    explicit = imports["exact"].get(simple_name)
    if explicit is not None:
        return simple_name if explicit == expected else None
    if unit is not None and simple_name in unit.get("package_types", set()):
        return None
    if SPRING_MAPPING_PACKAGE in imports["wildcards"]:
        wildcard_sources = (
            unit.get("wildcard_source_types", {}).get(simple_name, set())
            if unit is not None
            else set()
        )
        if wildcard_sources - {expected}:
            return None
        return simple_name
    return None


def decode_java_string_literal(literal):
    """Decode the bounded escape forms valid in an ordinary Java string."""
    if len(literal) < 2 or not (literal.startswith('"') and literal.endswith('"')):
        return None

    result = []
    index = 1
    end = len(literal) - 1
    simple_escapes = {
        "b": "\b",
        "t": "\t",
        "n": "\n",
        "f": "\f",
        "r": "\r",
        "s": " ",
        '"': '"',
        "'": "'",
        "\\": "\\",
    }
    while index < end:
        char = literal[index]
        if char != "\\":
            result.append(char)
            index += 1
            continue

        index += 1
        if index >= end:
            return None
        escaped = literal[index]
        if escaped in simple_escapes:
            result.append(simple_escapes[escaped])
            index += 1
            continue
        if escaped == "u":
            while index < end and literal[index] == "u":
                index += 1
            digits = literal[index:index + 4]
            if len(digits) != 4 or not re.fullmatch(r"[0-9a-fA-F]{4}", digits):
                return None
            result.append(chr(int(digits, 16)))
            index += 4
            continue
        if escaped in "01234567":
            max_digits = 3 if escaped in "0123" else 2
            digits = escaped
            index += 1
            while index < end and len(digits) < max_digits and literal[index] in "01234567":
                digits += literal[index]
                index += 1
            result.append(chr(int(digits, 8)))
            continue
        return None

    try:
        value = (
            "".join(result)
            .encode("utf-16-le", errors="surrogatepass")
            .decode("utf-16-le")
        )
    except UnicodeDecodeError:
        return None
    return value if len(value) <= SPRING_MAX_CONSTANT_LENGTH else None


def build_same_file_constant_index(source, field_matches, type_infos):
    by_qualified = {}
    for _pattern_index, captures in field_matches:
        type_node = first_capture(captures, "constant.type")
        name_node = first_capture(captures, "constant.name")
        value_node = first_capture(captures, "constant.value")
        field_node = first_capture(captures, "constant.field")
        if None in (type_node, name_node, value_node, field_node):
            continue
        field_type = node_text(source, type_node).strip()
        if field_type not in {"String", "java.lang.String"}:
            continue
        owner_node = nearest_enclosing_type(field_node)
        owner_info = type_infos.get(tree_node_key(owner_node)) if owner_node is not None else None
        owner_name = owner_info["display_name"] if owner_info is not None else ""
        name = node_text(source, name_node)
        record = {
            "id": (field_node.start_byte, name_node.start_byte),
            "name": name,
            "owner": owner_name,
            "value_node": value_node,
        }
        if owner_name:
            by_qualified.setdefault(f"{owner_name}.{name}", []).append(record)
            by_qualified.setdefault(f"{owner_name.rsplit('.', 1)[-1]}.{name}", []).append(record)
    return {"by_qualified": by_qualified}


def constant_candidates(reference, owner_name, constant_index):
    reference = reference.strip()
    if reference.startswith("this."):
        reference = reference[5:]

    candidates = []
    if "." not in reference:
        owner_parts = owner_name.split(".") if owner_name else []
        while owner_parts:
            qualified = f"{'.'.join(owner_parts)}.{reference}"
            current = constant_index["by_qualified"].get(qualified, [])
            if current:
                candidates.extend(current)
                break
            owner_parts.pop()
    else:
        candidates.extend(constant_index["by_qualified"].get(reference, []))

    unique = {record["id"]: record for record in candidates}
    return list(unique.values())


def binary_expression_is_addition(source, node, left, right):
    operator = child_by_field(node, "operator")
    if operator is not None:
        return node_text(source, operator).strip() == "+"
    return any(child.type == "+" for child in node.children) or (
        source[left.end_byte:right.start_byte].decode("utf8").strip() == "+"
    )


def resolve_spring_string_expression(
    source,
    expression_node,
    constant_index,
    owner_name,
    stack=(),
    depth=0,
):
    if expression_node is None or depth > SPRING_MAX_CONSTANT_DEPTH:
        return None

    node_type = expression_node.type
    if node_type == "string_literal":
        return decode_java_string_literal(node_text(source, expression_node))
    if node_type == "parenthesized_expression":
        children = expression_node.named_children
        if len(children) != 1:
            return None
        return resolve_spring_string_expression(
            source, children[0], constant_index, owner_name, stack, depth + 1
        )
    if node_type == "binary_expression":
        left = child_by_field(expression_node, "left")
        right = child_by_field(expression_node, "right")
        if left is None or right is None or not binary_expression_is_addition(source, expression_node, left, right):
            return None
        left_value = resolve_spring_string_expression(
            source, left, constant_index, owner_name, stack, depth + 1
        )
        right_value = resolve_spring_string_expression(
            source, right, constant_index, owner_name, stack, depth + 1
        )
        if left_value is None or right_value is None:
            return None
        value = left_value + right_value
        return value if len(value) <= SPRING_MAX_CONSTANT_LENGTH else None
    if node_type in {"identifier", "field_access", "scoped_identifier"}:
        reference = node_text(source, expression_node)
        candidates = constant_candidates(reference, owner_name, constant_index)
        if len(candidates) != 1:
            return None
        constant = candidates[0]
        if constant["id"] in stack:
            return None
        return resolve_spring_string_expression(
            source,
            constant["value_node"],
            constant_index,
            constant["owner"],
            stack + (constant["id"],),
            depth + 1,
        )
    return None


def resolve_java_string_expression(
    source,
    expression_node,
    constant_index,
    owner_name,
    unit=None,
    workspace=None,
):
    """Resolve a bounded Java String expression in its declaration source."""
    if unit is not None and workspace is not None:
        return resolve_workspace_string_expression(
            unit, expression_node, workspace, owner_name
        )
    return resolve_spring_string_expression(
        source, expression_node, constant_index, owner_name
    )


def normalize_spring_path(path):
    if not path:
        return ""
    return path if path.startswith("/") else f"/{path}"


def annotation_value_nodes(value_node):
    if value_node.type == "element_value_array_initializer":
        return [
            child
            for child in value_node.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
    return [value_node]


def get_spring_annotation_paths(
    source,
    annotation_node,
    constant_index,
    owner_name,
    unit=None,
    workspace=None,
):
    positional, named = get_annotation_arguments(annotation_node)
    if len(positional) > 1 or (positional and "value" in named):
        return {
            "values": [],
            "unresolved": ["invalid positional/value alias declaration"],
            "present": True,
        }

    explicit_nodes = []
    if positional:
        explicit_nodes.append(("value", positional[0]))
    for attribute in ("value", "path"):
        if attribute in named:
            explicit_nodes.append((attribute, named[attribute]))
    if not explicit_nodes:
        return {"values": [""], "unresolved": [], "present": False}

    resolved_aliases = []
    unresolved = []
    for attribute, explicit_node in explicit_nodes:
        current_values = []
        value_nodes = annotation_value_nodes(explicit_node)
        if not value_nodes:
            current_values.append("")
        for value_node in value_nodes:
            value = resolve_java_string_expression(
                source,
                value_node,
                constant_index,
                owner_name,
                unit=unit,
                workspace=workspace,
            )
            if value is None:
                unresolved.append(node_text(source, value_node).strip())
            else:
                current_values.append(value)
        resolved_aliases.append((attribute, tuple(current_values)))

    if unresolved:
        return {"values": [], "unresolved": unresolved, "present": True}
    if len({values for _attribute, values in resolved_aliases}) != 1:
        return {
            "values": [],
            "unresolved": ["conflicting explicit path/value aliases"],
            "present": True,
        }
    raw_values = resolved_aliases[0][1]
    return {
        "values": list(
            dict.fromkeys(normalize_spring_path(value) for value in raw_values)
        ) or [""],
        "unresolved": [],
        "present": True,
    }


def unwrap_parenthesized_node(node):
    current = node
    while current is not None and current.type == "parenthesized_expression":
        children = current.named_children
        if len(children) != 1:
            return None
        current = children[0]
    return current


def owner_name_for_node(unit, context_node):
    owner_node = nearest_enclosing_type(context_node) if context_node is not None else None
    owner_info = (
        unit.get("type_infos", {}).get(tree_node_key(owner_node))
        if owner_node is not None
        else None
    )
    return owner_info["display_name"] if owner_info is not None else None


def static_member_resolves_to(
    unit, member_name, expected_owner, context_node=None
):
    imports = unit["imports"]
    if member_name in imports["static_exact"]:
        return (
            imports["static_exact"][member_name]
            == f"{expected_owner}.{member_name}"
        )
    if expected_owner not in imports["static_wildcards"]:
        return False
    declarations = unit.get("workspace_static_member_declarations", {})
    consumer_owner_name = owner_name_for_node(unit, context_node)
    return not any(
        owner != expected_owner
        and any(
            workspace_static_member_declaration_accessible(
                record, unit, consumer_owner_name
            )
            for record in declarations.get((owner, member_name), [])
        )
        for owner in imports["static_wildcards"]
    )


def resolve_spring_request_method_expression(
    source,
    value_node,
    imports,
    unit=None,
):
    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = node_text(source, current).strip()
    method_name = spelling.rsplit(".", 1)[-1]
    if method_name not in SPRING_HTTP_METHODS:
        return None
    expected_owner = f"{SPRING_MAPPING_PACKAGE}.RequestMethod"
    if "." not in spelling:
        if unit is not None:
            return (
                method_name
                if static_member_resolves_to(
                    unit, method_name, expected_owner, current
                )
                else None
            )
        imported = imports["static_exact"].get(method_name)
        if imported is not None:
            return method_name if imported == f"{expected_owner}.{method_name}" else None
        return method_name if expected_owner in imports["static_wildcards"] else None

    qualifier = spelling.rsplit(".", 1)[0]
    if unit is not None:
        return (
            method_name
            if resolve_known_type(
                unit,
                qualifier,
                "RequestMethod",
                (SPRING_MAPPING_PACKAGE,),
                current,
            )
            == SPRING_MAPPING_PACKAGE
            else None
        )
    if qualifier == expected_owner:
        return method_name
    if qualifier != "RequestMethod":
        return None
    explicit = imports["exact"].get("RequestMethod")
    if explicit is not None:
        return method_name if explicit == expected_owner else None
    return (
        method_name
        if SPRING_MAPPING_PACKAGE in imports["wildcards"]
        else None
    )


def get_spring_request_methods(
    source,
    annotation_node,
    imports,
    unit=None,
):
    _positional, named = get_annotation_arguments(annotation_node)
    method_node = named.get("method")
    if method_node is None:
        return {"values": [], "unresolved": [], "present": False}

    value_nodes = annotation_value_nodes(method_node)
    if not value_nodes:
        return {"values": [], "unresolved": [], "present": True}

    methods = []
    unresolved = []
    for value_node in value_nodes:
        expression = node_text(source, value_node).strip()
        method_name = resolve_spring_request_method_expression(
            source, value_node, imports, unit=unit
        )
        if method_name is not None:
            methods.append(method_name)
        else:
            unresolved.append(expression)
    return {"values": ordered_http_methods(methods), "unresolved": unresolved, "present": True}


def ordered_http_methods(methods):
    method_set = set(methods)
    return [method for method in SPRING_HTTP_METHODS if method in method_set]


def combine_request_method_conditions(class_methods, method_methods):
    if not class_methods:
        return list(method_methods)
    if not method_methods:
        return list(class_methods)
    return ordered_http_methods([*class_methods, *method_methods])


def log_unresolved_mapping(fname, owner_name, mapping_name, value_kind, expressions):
    for expression in expressions:
        write_log(
            f"Skipped unresolved Spring {value_kind} in {fname} "
            f"for {owner_name} @{mapping_name}: {expression}"
        )


def decode_spring_mapping(
    fname,
    source,
    annotation_name_node,
    annotation_node,
    imports,
    local_annotations,
    constant_index,
    lexical_owner_name,
    diagnostic_owner_name=None,
    unit=None,
    workspace=None,
):
    mapping_name = resolve_spring_mapping_name(
        source, annotation_name_node, imports, local_annotations, unit=unit
    )
    if mapping_name is None:
        return None

    paths = get_spring_annotation_paths(
        source,
        annotation_node,
        constant_index,
        lexical_owner_name,
        unit=unit,
        workspace=workspace,
    )
    diagnostic_owner_name = diagnostic_owner_name or lexical_owner_name
    if paths["unresolved"]:
        log_unresolved_mapping(
            fname,
            diagnostic_owner_name,
            mapping_name,
            "path",
            paths["unresolved"],
        )

    if mapping_name == "RequestMapping":
        methods = get_spring_request_methods(
            source, annotation_node, imports, unit=unit
        )
        if methods["unresolved"]:
            log_unresolved_mapping(
                fname,
                diagnostic_owner_name,
                mapping_name,
                "method",
                methods["unresolved"],
            )
    else:
        methods = {
            "values": [SPRING_MAPPING_METHODS[mapping_name]],
            "unresolved": [],
            "present": False,
        }

    valid = bool(paths["values"]) and not (
        methods["present"] and methods["unresolved"] and not methods["values"]
    )
    return {
        "name": mapping_name,
        "paths": paths["values"],
        "methods": methods["values"],
        "valid": valid,
        "annotation_node": annotation_node,
    }


def first_spring_mapping(
    fname,
    source,
    candidates,
    imports,
    local_annotations,
    constant_index,
    lexical_owner_name,
    diagnostic_owner_name=None,
    unit=None,
    workspace=None,
):
    for captures in sorted(
        candidates,
        key=lambda item: first_capture(item, "annotation.node").start_byte,
    ):
        mapping = decode_spring_mapping(
            fname,
            source,
            first_capture(captures, "annotation.name"),
            first_capture(captures, "annotation.node"),
            imports,
            local_annotations,
            constant_index,
            lexical_owner_name,
            diagnostic_owner_name,
            unit,
            workspace,
        )
        if mapping is not None:
            return mapping
        if unit is not None and workspace is not None:
            composed = decode_spring_composed_mapping(
                fname,
                unit,
                first_capture(captures, "annotation.name"),
                first_capture(captures, "annotation.node"),
                lexical_owner_name,
                diagnostic_owner_name or lexical_owner_name,
                workspace,
            )
            if composed is not None:
                return composed
    return None


def type_chain(type_key, type_infos):
    chain = []
    current_key = type_key
    while current_key is not None and current_key in type_infos:
        info = type_infos[current_key]
        chain.append(info)
        current_key = info["outer_key"]
    return list(reversed(chain))


def compose_type_mapping(type_key, type_infos):
    paths = [""]
    methods = []
    for info in type_chain(type_key, type_infos):
        mapping = info["mapping"]
        if mapping is None:
            continue
        if not mapping["valid"]:
            return None
        paths = [
            combine_paths(base_path, current_path)
            for base_path in paths
            for current_path in mapping["paths"]
        ]
        methods = combine_request_method_conditions(methods, mapping["methods"])
    return {"paths": list(dict.fromkeys(paths)), "methods": methods}


def SpringBoot_Analyzer(fname, fcontent=None, runtime=None, workspace=None):
    """Extract supported Spring MVC annotation routes from one Java source."""
    fname = str(fname)
    runtime = runtime or build_spring_runtime()
    if isinstance(fcontent, bytes):
        source = fcontent
    elif isinstance(fcontent, str):
        source = fcontent.encode("utf8")
    else:
        with open(fname, "rb") as source_file:
            source = source_file.read()

    write_log(f"{fname}:")
    tree = runtime["parser"].parse(source)
    root = tree.root_node
    query_lifetime_owners = [tree]
    matches = {
        name: run_query_matches(query, root, query_lifetime_owners)
        for name, query in runtime["queries"].items()
    }
    type_infos = build_type_infos(source, matches["type"])
    imports = parse_java_imports(source, matches["import"])
    local_annotations = declared_annotation_names(
        source, matches["annotation_declaration"]
    )
    constant_index = build_same_file_constant_index(
        source, matches["field"], type_infos
    )
    workspace_unit = (
        workspace.get("units", {}).get(fname)
        if workspace is not None
        else None
    )

    type_candidates = {}
    for _pattern_index, captures in matches["type_annotation"]:
        type_node = first_capture(captures, "type.node")
        if type_node is not None:
            type_candidates.setdefault(tree_node_key(type_node), []).append(captures)

    for type_key, info in type_infos.items():
        info["mapping"] = first_spring_mapping(
            fname,
            source,
            type_candidates.get(type_key, []),
            imports,
            local_annotations,
            constant_index,
            info["display_name"],
            unit=workspace_unit,
            workspace=workspace,
        )

    method_candidates = {}
    for _pattern_index, captures in matches["method_annotation"]:
        method_node = first_capture(captures, "method.node")
        if method_node is not None:
            method_candidates.setdefault(tree_node_key(method_node), []).append(captures)
    record_component_candidates = group_query_captures(
        matches["record_component_annotation"], "component.node"
    )
    record_explicit_accessors = record_explicit_zero_parameter_accessors(
        source, matches["record_method"]
    )

    endpoints = []
    for method_key in sorted(method_candidates):
        candidates = method_candidates[method_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        method_name_node = first_capture(representative, "method.name")
        parameters_node = first_capture(representative, "method.parameters")
        if None in (type_node, method_name_node, parameters_node):
            continue

        owner_key = tree_node_key(type_node)
        owner_info = type_infos.get(owner_key)
        if (
            owner_info is None
            or owner_info["abstract"]
            or not owner_info["workspace_visible"]
        ):
            continue
        method_name = node_text(source, method_name_node)
        owner_name = f"{owner_info['display_name']}.{method_name}"
        mapping = first_spring_mapping(
            fname,
            source,
            candidates,
            imports,
            local_annotations,
            constant_index,
            owner_info["display_name"],
            owner_name,
            workspace_unit,
            workspace,
        )
        if mapping is None or not mapping["valid"]:
            continue

        type_mapping = compose_type_mapping(owner_key, type_infos)
        if type_mapping is None:
            continue
        effective_methods = combine_request_method_conditions(
            type_mapping["methods"], mapping["methods"]
        ) or ["ANY"]
        parameters = get_callable_parameters_as_is(source, parameters_node)
        line = mapping["annotation_node"].start_point.row + 1

        for base_path in type_mapping["paths"]:
            for method_path in mapping["paths"]:
                uri = combine_paths(base_path, method_path)
                for http_method in effective_methods:
                    endpoint = {
                        "uri": uri,
                        "method": http_method,
                        "uri_params": parameters,
                        "SrcFile": fname,
                        "SrcLine": line,
                        "SFunction": owner_name,
                    }
                    endpoints.append(endpoint)
                    debug_log(endpoint)

    for component_key in sorted(record_component_candidates):
        candidates = record_component_candidates[component_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        component_name_node = first_capture(representative, "component.name")
        if type_node is None or component_name_node is None:
            continue

        owner_key = tree_node_key(type_node)
        owner_info = type_infos.get(owner_key)
        if (
            owner_info is None
            or owner_info["abstract"]
            or not owner_info["workspace_visible"]
        ):
            continue
        component_name = node_text(source, component_name_node)
        if (owner_key, component_name) in record_explicit_accessors:
            continue

        owner_name = f"{owner_info['display_name']}.{component_name}"
        applicable_candidates = spring_method_applicable_component_candidates(
            source,
            candidates,
            imports,
            local_annotations,
            workspace_unit,
            workspace,
            owner_info["display_name"],
        )
        mapping = first_spring_mapping(
            fname,
            source,
            applicable_candidates,
            imports,
            local_annotations,
            constant_index,
            owner_info["display_name"],
            owner_name,
            workspace_unit,
            workspace,
        )
        if mapping is None or not mapping["valid"]:
            continue

        type_mapping = compose_type_mapping(owner_key, type_infos)
        if type_mapping is None:
            continue
        effective_methods = combine_request_method_conditions(
            type_mapping["methods"], mapping["methods"]
        ) or ["ANY"]
        line = mapping["annotation_node"].start_point.row + 1

        for base_path in type_mapping["paths"]:
            for method_path in mapping["paths"]:
                uri = combine_paths(base_path, method_path)
                for http_method in effective_methods:
                    endpoint = {
                        "uri": uri,
                        "method": http_method,
                        "uri_params": "",
                        "SrcFile": fname,
                        "SrcLine": line,
                        "SFunction": owner_name,
                    }
                    endpoints.append(endpoint)
                    debug_log(endpoint)

    return endpoints

def java_source_bytes(fname, fcontent=None):
    if isinstance(fcontent, bytes):
        return fcontent
    if isinstance(fcontent, str):
        return fcontent.encode("utf8")
    with open(fname, "rb") as source_file:
        return source_file.read()


def java_package_name(source, package_matches):
    names = []
    for _pattern_index, captures in package_matches:
        name_node = first_capture(captures, "package.name")
        if name_node is not None:
            names.append(node_text(source, name_node).strip())
    return names[0] if len(set(names)) == 1 else ""


def group_query_captures(matches, capture_name):
    grouped = {}
    for _pattern_index, captures in matches:
        node = first_capture(captures, capture_name)
        if node is not None:
            grouped.setdefault(tree_node_key(node), []).append(captures)
    return grouped


def annotation_records(candidates):
    records = {}
    for captures in candidates:
        annotation_node = first_capture(captures, "annotation.node")
        name_node = first_capture(captures, "annotation.name")
        if annotation_node is None or name_node is None:
            continue
        records[tree_node_key(annotation_node)] = {
            "node": annotation_node,
            "name_node": name_node,
        }
    return [records[key] for key in sorted(records)]


def record_explicit_zero_parameter_accessors(source, matches):
    accessors = set()
    for _pattern_index, captures in matches:
        type_node = first_capture(captures, "type.node")
        method_name_node = first_capture(captures, "method.name")
        parameters_node = first_capture(captures, "method.parameters")
        if None in (type_node, method_name_node, parameters_node):
            continue
        if any(
            child.type in {"formal_parameter", "spread_parameter"}
            for child in parameters_node.named_children
        ):
            continue
        accessors.add(
            (tree_node_key(type_node), node_text(source, method_name_node))
        )
    return accessors


def build_jax_unit(fname, source, runtime, parsed_tree=None):
    tree = parsed_tree or runtime["parser"].parse(source)
    root = tree.root_node
    lifetime_owners = [tree]
    matches = {
        name: run_query_matches(query, root, lifetime_owners)
        for name, query in runtime["queries"].items()
    }
    type_infos = build_type_infos(source, matches["type"])
    return {
        "fname": fname,
        "source": source,
        "tree": tree,
        "lifetime_owners": lifetime_owners,
        "matches": matches,
        "type_infos": type_infos,
        "imports": parse_java_imports(source, matches["import"]),
        "package": java_package_name(source, matches["package"]),
        "local_annotations": declared_annotation_names(
            source, matches["annotation_declaration"]
        ),
        "local_types": {info["simple_name"] for info in type_infos.values()},
        "constant_index": build_same_file_constant_index(
            source, matches["field"], type_infos
        ),
        "type_candidates": group_query_captures(matches["type_annotation"], "type.node"),
        "method_candidates": group_query_captures(
            matches["method_annotation"], "method.node"
        ),
        "record_component_candidates": group_query_captures(
            matches["record_component_annotation"], "component.node"
        ),
        "record_explicit_accessors": record_explicit_zero_parameter_accessors(
            source, matches["record_method"]
        ),
        "meta_candidates": group_query_captures(
            matches["annotation_meta"], "annotation.declaration.node"
        ),
        "element_candidates": group_query_captures(
            matches["annotation_element"], "annotation.declaration.node"
        ),
    }


def resolve_known_source_name(unit, spelling, simple_name, packages, local_names):
    if spelling.rsplit(".", 1)[-1] != simple_name:
        return None
    if "." in spelling:
        for package in packages:
            if spelling == f"{package}.{simple_name}":
                return package
        return None

    if simple_name in local_names:
        return None
    if simple_name in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][simple_name]
        for package in packages:
            if imported == f"{package}.{simple_name}":
                return package
        return None
    if simple_name in unit.get("package_types", set()):
        return None

    candidates = set()
    if "java.lang" in packages:
        candidates.add("java.lang")
    if unit["package"] in packages:
        candidates.add(unit["package"])
    candidates.update(
        package for package in packages if package in unit["imports"]["wildcards"]
    )
    expected_source_types = {
        f"{package}.{simple_name}" for package in candidates
    }
    if unit.get("wildcard_source_types", {}).get(simple_name, set()) - expected_source_types:
        return None
    return next(iter(candidates)) if len(candidates) == 1 else None


def resolve_known_annotation(unit, name_node, simple_names, packages):
    spelling = node_text(unit["source"], name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in simple_names:
        return None
    package = resolve_known_source_name(
        unit,
        spelling,
        simple_name,
        packages,
        visible_local_type_names(unit, name_node),
    )
    if package is None:
        return None
    return {"name": simple_name, "namespace": package, "spelling": spelling}


def resolve_known_type(unit, spelling, simple_name, packages, context_node=None):
    return resolve_known_source_name(
        unit,
        spelling.strip(),
        simple_name,
        packages,
        visible_local_type_names(unit, context_node),
    )


def annotation_single_value_node(annotation_node):
    positional, named = get_annotation_arguments(annotation_node)
    if set(named) - {"value"}:
        return None, "unsupported named attribute"
    if positional and "value" in named:
        return None, "both positional and named values"
    if "value" in named:
        return named["value"], None
    if len(positional) == 1:
        return positional[0], None
    if not positional:
        return None, "missing value"
    return None, "multiple positional values"


def log_jax_issue(fname, owner_name, message, expression=None):
    suffix = f": {expression}" if expression else ""
    write_log(f"Skipped JAX-RS {message} in {fname} for {owner_name}{suffix}")


def decode_jax_path_annotation(
    unit,
    record,
    constant_owner,
    diagnostic_owner,
    kind,
    workspace=None,
):
    value_node, error = annotation_single_value_node(record["node"])
    if error:
        log_jax_issue(unit["fname"], diagnostic_owner, f"invalid {kind}", error)
        return None
    value = resolve_java_string_expression(
        unit["source"],
        value_node,
        unit["constant_index"],
        constant_owner,
        unit=unit,
        workspace=workspace,
    )
    if value is None:
        log_jax_issue(
            unit["fname"],
            diagnostic_owner,
            f"unresolved {kind}",
            node_text(unit["source"], value_node).strip(),
        )
        return None
    return normalize_spring_path(value)


def annotation_has_no_values(annotation_node):
    arguments = child_by_field(annotation_node, "arguments")
    return arguments is None or not arguments.named_children


def type_directly_extends_jax_application(unit, type_info):
    superclass = child_by_field(type_info["node"], "superclass")
    if superclass is None or len(superclass.named_children) != 1:
        return None
    spelling = node_text(unit["source"], superclass.named_children[0]).strip()
    core_package = resolve_known_type(
        unit,
        spelling,
        "Application",
        JAX_RS_CORE_PACKAGES,
        superclass.named_children[0],
    )
    return core_package.rsplit(".", 1)[0] if core_package is not None else None


def retention_is_runtime(unit, annotation_node):
    value_node, error = annotation_single_value_node(annotation_node)
    if error:
        return False
    current = unwrap_parenthesized_node(value_node)
    if current is None:
        return False
    spelling = node_text(unit["source"], current).strip()
    if spelling == "RUNTIME":
        return static_member_resolves_to(
            unit,
            "RUNTIME",
            "java.lang.annotation.RetentionPolicy",
            current,
        )
    if "." not in spelling or spelling.rsplit(".", 1)[-1] != "RUNTIME":
        return False
    qualifier = spelling.rsplit(".", 1)[0]
    return (
        resolve_known_type(
            unit,
            qualifier,
            "RetentionPolicy",
            ("java.lang.annotation",),
            current,
        )
        == "java.lang.annotation"
    )


def decode_custom_http_method(unit, annotation_record, owner_name, workspace):
    value_node, error = annotation_single_value_node(annotation_record["node"])
    if error:
        log_jax_issue(
            unit["fname"], owner_name, "custom @HttpMethod value", error
        )
        return None
    token = resolve_workspace_string_expression(
        unit,
        value_node,
        workspace,
        owner_name,
        known_static_constants=JAX_HTTP_METHOD_STATIC_CONSTANTS,
    )
    if (
        token is None
        or len(token) > 128
        or HTTP_METHOD_TOKEN.fullmatch(token) is None
    ):
        log_jax_issue(
            unit["fname"],
            owner_name,
            "invalid custom @HttpMethod value",
            node_text(unit["source"], value_node).strip(),
        )
        return None
    return token


def qualified_type_name(unit, type_info):
    display_name = type_info["display_name"]
    return f"{unit['package']}.{display_name}" if unit["package"] else display_name


def declaration_modifier_names(declaration_node):
    modifiers = find_first(declaration_node, "modifiers")
    return {
        child.type
        for child in modifiers.children
        if child.is_named or child.type in {"public", "protected", "private", "static", "final"}
    } if modifiers is not None else set()


def workspace_type_accessible(type_record, consumer_unit, consumer_owner_name):
    declaration_unit = type_record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    type_info = type_record["type_info"]
    chain = type_chain(tree_node_key(type_info["node"]), declaration_unit["type_infos"])
    access = []
    for current in chain:
        modifiers = declaration_modifier_names(current["node"])
        outer_node = nearest_enclosing_type(current["node"])
        implicitly_public = bool(
            outer_node is not None
            and outer_node.type
            in {"interface_declaration", "annotation_type_declaration"}
        )
        access.append(
            {
                "public": implicitly_public or "public" in modifiers,
                "private": "private" in modifiers,
            }
        )
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and type_info["display_name"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        return not any(part["private"] for part in access) or same_nest
    if any(part["private"] for part in access):
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return all(part["public"] for part in access)


def index_workspace_types(workspace):
    declarations = {}
    for unit in workspace["units"].values():
        for type_info in unit["type_infos"].values():
            if not type_info["workspace_visible"]:
                continue
            fqn = qualified_type_name(unit, type_info)
            declarations.setdefault(fqn, []).append(
                {"fqn": fqn, "unit": unit, "type_info": type_info}
            )
    workspace["type_declarations"] = declarations


def index_workspace_constants(workspace):
    by_owner_member = {}
    member_declarations = {}
    static_member_declarations = {}
    for unit in workspace["units"].values():
        records = []
        for _pattern_index, captures in unit["matches"]["field"]:
            type_node = first_capture(captures, "constant.type")
            name_node = first_capture(captures, "constant.name")
            value_node = first_capture(captures, "constant.value")
            field_node = first_capture(captures, "constant.field")
            if None in (type_node, name_node, field_node):
                continue
            owner_node = nearest_enclosing_type(field_node)
            owner_info = (
                unit["type_infos"].get(tree_node_key(owner_node))
                if owner_node is not None
                else None
            )
            if owner_info is None or not owner_info["workspace_visible"]:
                continue
            member_name = node_text(unit["source"], name_node)
            owner_fqn = qualified_type_name(unit, owner_info)
            declaration_id = (
                unit["fname"],
                field_node.start_byte,
                field_node.end_byte,
                name_node.start_byte,
            )
            member_declarations.setdefault((owner_fqn, member_name), set()).add(
                declaration_id
            )
            modifiers = declaration_modifier_names(field_node)
            implicit_constant = field_node.type == "constant_declaration"
            owner_chain = type_chain(tree_node_key(owner_info["node"]), unit["type_infos"])
            owner_access = []
            for owner_part in owner_chain:
                owner_modifiers = declaration_modifier_names(owner_part["node"])
                outer_node = nearest_enclosing_type(owner_part["node"])
                implicitly_public = bool(
                    outer_node is not None
                    and outer_node.type
                    in {"interface_declaration", "annotation_type_declaration"}
                )
                owner_access.append(
                    {
                        "public": implicitly_public or "public" in owner_modifiers,
                        "private": "private" in owner_modifiers,
                    }
                )
            declaration_record = {
                "id": declaration_id,
                "owner": owner_info["display_name"],
                "owner_fqn": owner_fqn,
                "unit": unit,
                "static": implicit_constant or "static" in modifiers,
                "public": implicit_constant or "public" in modifiers,
                "private": "private" in modifiers,
                "owner_all_public": all(part["public"] for part in owner_access),
                "owner_has_private": any(part["private"] for part in owner_access),
            }
            if declaration_record["static"]:
                static_member_declarations.setdefault(
                    (owner_fqn, member_name), []
                ).append(declaration_record)
            if value_node is None:
                continue
            field_type = node_text(unit["source"], type_node).strip()
            if resolve_known_type(
                unit, field_type, "String", ("java.lang",), type_node
            ) != "java.lang":
                continue
            record = {
                **declaration_record,
                "name": member_name,
                "owner_type": owner_info["node"].type,
                "value_node": value_node,
                "final_constant": implicit_constant or "final" in modifiers,
                "static_final": implicit_constant
                or {"static", "final"}.issubset(modifiers),
                "protected": "protected" in modifiers,
            }
            records.append(record)
            by_owner_member.setdefault(
                (record["owner_fqn"], record["name"]), []
            ).append(record)
        for _pattern_index, captures in unit["matches"]["enum_constant"]:
            type_node = first_capture(captures, "enum.type.node")
            name_node = first_capture(captures, "enum.constant.name")
            constant_node = first_capture(captures, "enum.constant.node")
            type_info = (
                unit["type_infos"].get(tree_node_key(type_node))
                if type_node is not None
                else None
            )
            if (
                type_info is None
                or name_node is None
                or constant_node is None
                or not type_info["workspace_visible"]
            ):
                continue
            member_declarations.setdefault(
                (
                    qualified_type_name(unit, type_info),
                    node_text(unit["source"], name_node),
                ),
                set(),
            ).add(
                (
                    unit["fname"],
                    constant_node.start_byte,
                    constant_node.end_byte,
                    name_node.start_byte,
                )
            )
            enum_owner_access = []
            for owner_part in type_chain(
                tree_node_key(type_info["node"]), unit["type_infos"]
            ):
                owner_modifiers = declaration_modifier_names(owner_part["node"])
                outer_node = nearest_enclosing_type(owner_part["node"])
                implicitly_public = bool(
                    outer_node is not None
                    and outer_node.type
                    in {"interface_declaration", "annotation_type_declaration"}
                )
                enum_owner_access.append(
                    {
                        "public": implicitly_public or "public" in owner_modifiers,
                        "private": "private" in owner_modifiers,
                    }
                )
            static_member_declarations.setdefault(
                (
                    qualified_type_name(unit, type_info),
                    node_text(unit["source"], name_node),
                ),
                [],
            ).append(
                {
                    "id": (
                        unit["fname"],
                        constant_node.start_byte,
                        constant_node.end_byte,
                        name_node.start_byte,
                    ),
                    "owner": type_info["display_name"],
                    "owner_fqn": qualified_type_name(unit, type_info),
                    "unit": unit,
                    "static": True,
                    "public": True,
                    "private": False,
                    "owner_all_public": all(
                        part["public"] for part in enum_owner_access
                    ),
                    "owner_has_private": any(
                        part["private"] for part in enum_owner_access
                    ),
                }
            )
        unit["workspace_constant_records"] = records
    workspace["constants_by_owner_member"] = by_owner_member
    workspace["member_declarations"] = member_declarations
    workspace["static_member_declarations"] = static_member_declarations
    for unit in workspace["units"].values():
        unit["workspace_member_declarations"] = member_declarations
        unit["workspace_static_member_declarations"] = static_member_declarations


def workspace_constant_accessible(
    record,
    consumer_unit,
    consumer_owner_name,
    require_static_final=False,
    require_final_constant=False,
):
    if require_static_final and not record["static_final"]:
        return False
    if require_final_constant and not record["final_constant"]:
        return False
    declaration_unit = record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and record["owner"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        if record["private"] or record["owner_has_private"]:
            return same_nest
        return True
    if (
        not record["static_final"]
        or record["private"]
        or record["owner_has_private"]
    ):
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return record["public"] and record["owner_all_public"]


def workspace_member_records(
    workspace,
    consumer_unit,
    consumer_owner_name,
    owner_fqn,
    member_name,
    require_static_final=False,
    require_final_constant=False,
):
    if len(workspace["type_declarations"].get(owner_fqn, [])) != 1:
        return []
    return [
        record
        for record in workspace["constants_by_owner_member"].get(
            (owner_fqn, member_name), []
        )
        if workspace_constant_accessible(
            record,
            consumer_unit,
            consumer_owner_name,
            require_static_final=require_static_final,
            require_final_constant=require_final_constant,
        )
    ]


def workspace_type_exists(workspace, fqn):
    return bool(workspace["type_declarations"].get(fqn))


def workspace_member_declared(workspace, owner_fqn, member_name):
    return bool(
        workspace["member_declarations"].get((owner_fqn, member_name))
    )


def workspace_static_member_declaration_accessible(
    record, consumer_unit, consumer_owner_name
):
    declaration_unit = record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and record["owner"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        if record["private"] or record["owner_has_private"]:
            return same_nest
        return True
    if record["private"] or record["owner_has_private"]:
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return record["public"] and record["owner_all_public"]


def workspace_static_member_declared(
    workspace, consumer_unit, consumer_owner_name, owner_fqn, member_name
):
    if len(workspace["type_declarations"].get(owner_fqn, [])) != 1:
        return False
    return any(
        workspace_static_member_declaration_accessible(
            record, consumer_unit, consumer_owner_name
        )
        for record in workspace["static_member_declarations"].get(
            (owner_fqn, member_name), []
        )
    )


def workspace_type_fqn_accessible(
    workspace, consumer_unit, consumer_owner_name, owner_fqn
):
    declarations = workspace["type_declarations"].get(owner_fqn, [])
    return len(declarations) == 1 and workspace_type_accessible(
        declarations[0], consumer_unit, consumer_owner_name
    )


def lexical_owner_fqns(unit, owner_name):
    parts = owner_name.split(".") if owner_name else []
    owners = []
    while parts:
        display = ".".join(parts)
        owners.append(f"{unit['package']}.{display}" if unit["package"] else display)
        parts.pop()
    return owners


def resolve_workspace_owner_fqns(
    unit,
    qualifier,
    owner_name,
    workspace,
    external_type_fqns=None,
):
    """Return the first Java name-resolution tier for a type qualifier."""
    external_type_fqns = set(external_type_fqns or ())
    if qualifier in external_type_fqns:
        return [] if workspace_type_exists(workspace, qualifier) else [qualifier]

    lexical = []
    owner_parts = owner_name.split(".") if owner_name else []
    while owner_parts:
        display = f"{'.'.join(owner_parts)}.{qualifier}"
        fqn = f"{unit['package']}.{display}" if unit["package"] else display
        if workspace_type_fqn_accessible(
            workspace, unit, owner_name, fqn
        ):
            lexical.append(fqn)
        if lexical:
            return lexical
        owner_parts.pop()

    first, dot, suffix = qualifier.partition(".")
    if first in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][first]
        if not imported:
            return []
        imported_fqn = f"{imported}.{suffix}" if dot else imported
        if imported_fqn in external_type_fqns:
            return (
                []
                if workspace_type_exists(workspace, imported_fqn)
                else [imported_fqn]
            )
        return (
            [imported_fqn]
            if workspace_type_fqn_accessible(
                workspace, unit, owner_name, imported_fqn
            )
            else []
        )

    same_package = f"{unit['package']}.{qualifier}" if unit["package"] else qualifier
    if same_package in external_type_fqns:
        return (
            []
            if workspace_type_exists(workspace, same_package)
            else [same_package]
        )
    if workspace_type_fqn_accessible(
        workspace, unit, owner_name, same_package
    ):
        return [same_package]

    global_declarations = workspace["type_declarations"].get(qualifier, [])
    if global_declarations and (
        not unit["package"]
        or all(record["unit"]["package"] for record in global_declarations)
    ) and workspace_type_fqn_accessible(
        workspace, unit, owner_name, qualifier
    ):
        return [qualifier]

    candidates = set()
    for package in unit["imports"]["wildcards"]:
        imported_fqn = f"{package}.{qualifier}"
        if imported_fqn in external_type_fqns:
            if not workspace_type_exists(workspace, imported_fqn):
                candidates.add(imported_fqn)
            continue
        if workspace_type_fqn_accessible(
            workspace, unit, owner_name, imported_fqn
        ):
            candidates.add(imported_fqn)
    return sorted(candidates)


def context_is_static_for_instance_constant(context_node):
    current = getattr(context_node, "parent", None)
    while current is not None:
        if current.type in {"method_declaration", "field_declaration"}:
            return "static" in declaration_modifier_names(current)
        if current.type in {"static_initializer", "constant_declaration"}:
            return True
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            # A declaration annotation is outside the declared type's member scope.
            return True
        current = getattr(current, "parent", None)
    return True


def lexical_instance_constant_accessible(
    record, consumer_unit, consumer_owner_name, context_node
):
    if record["static_final"]:
        return True
    if (
        record["unit"] is not consumer_unit
        or not consumer_owner_name
        or context_is_static_for_instance_constant(context_node)
    ):
        return False
    if record["owner"] == consumer_owner_name:
        return True
    if not consumer_owner_name.startswith(f"{record['owner']}."):
        return False

    infos_by_display = {
        info["display_name"]: info for info in consumer_unit["type_infos"].values()
    }
    current = infos_by_display.get(consumer_owner_name)
    while current is not None and current["display_name"] != record["owner"]:
        modifiers = declaration_modifier_names(current["node"])
        outer = (
            consumer_unit["type_infos"].get(current["outer_key"])
            if current["outer_key"] is not None
            else None
        )
        implicitly_static = current["node"].type in {
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        } or bool(
            outer is not None
            and outer["node"].type
            in {"interface_declaration", "annotation_type_declaration"}
        )
        if "static" in modifiers or implicitly_static:
            return False
        current = outer
    return current is not None and current["display_name"] == record["owner"]


def known_static_constant_record(owner_fqn, member_name, value):
    return {
        "id": ("known-static", owner_fqn, member_name),
        "owner_fqn": owner_fqn,
        "name": member_name,
        "resolved_value": value,
    }


def workspace_constant_candidates(
    unit,
    reference,
    owner_name,
    workspace,
    context_node=None,
    known_static_constants=None,
):
    known_static_constants = known_static_constants or {}
    reference = reference.strip()
    if reference.startswith("this."):
        return []

    if "." not in reference:
        for owner_fqn in lexical_owner_fqns(unit, owner_name):
            records = workspace_member_records(
                workspace,
                unit,
                owner_name,
                owner_fqn,
                reference,
                require_final_constant=True,
            )
            records = [
                record
                for record in records
                if lexical_instance_constant_accessible(
                    record, unit, owner_name, context_node
                )
            ]
            if workspace_member_declared(
                workspace, owner_fqn, reference
            ):
                return records

        if reference in unit["imports"]["static_exact"]:
            target = unit["imports"]["static_exact"][reference]
            if not target or "." not in target:
                return []
            owner_fqn, member_name = target.rsplit(".", 1)
            known_value = known_static_constants.get(owner_fqn, {}).get(
                member_name
            )
            if known_value is not None:
                if workspace_type_exists(workspace, owner_fqn):
                    return []
                return [
                    known_static_constant_record(
                        owner_fqn, member_name, known_value
                    )
                ]
            return workspace_member_records(
                workspace,
                unit,
                owner_name,
                owner_fqn,
                member_name,
                require_static_final=True,
            )

        declaring_owners = []
        for owner_fqn in sorted(unit["imports"]["static_wildcards"]):
            known_declared = reference in known_static_constants.get(
                owner_fqn, {}
            )
            source_declared = workspace_static_member_declared(
                workspace, unit, owner_name, owner_fqn, reference
            )
            if known_declared or source_declared:
                declaring_owners.append(owner_fqn)
        if len(declaring_owners) != 1:
            return []
        declaring_owner = declaring_owners[0]
        known_value = known_static_constants.get(declaring_owner, {}).get(
            reference
        )
        if known_value is not None:
            if workspace_type_exists(workspace, declaring_owner):
                return []
            return [
                known_static_constant_record(
                    declaring_owner, reference, known_value
                )
            ]
        return workspace_member_records(
            workspace,
            unit,
            owner_name,
            declaring_owner,
            reference,
            require_static_final=True,
        )

    qualifier, member_name = reference.rsplit(".", 1)
    owner_fqns = resolve_workspace_owner_fqns(
        unit,
        qualifier,
        owner_name,
        workspace,
        external_type_fqns=known_static_constants,
    )
    if len(owner_fqns) != 1:
        return []
    owner_fqn = owner_fqns[0]
    known_value = known_static_constants.get(owner_fqn, {}).get(member_name)
    if known_value is not None:
        return [
            known_static_constant_record(owner_fqn, member_name, known_value)
        ]
    candidates = []
    candidates.extend(
        workspace_member_records(
            workspace,
            unit,
            owner_name,
            owner_fqn,
            member_name,
            require_static_final=True,
        )
    )
    return candidates


def resolve_workspace_string_expression(
    unit,
    expression_node,
    workspace,
    owner_name,
    stack=(),
    depth=0,
    known_static_constants=None,
):
    if expression_node is None or depth > SPRING_MAX_CONSTANT_DEPTH:
        return None

    source = unit["source"]
    node_type = expression_node.type
    if node_type == "string_literal":
        return decode_java_string_literal(node_text(source, expression_node))
    if node_type == "parenthesized_expression":
        children = expression_node.named_children
        if len(children) != 1:
            return None
        return resolve_workspace_string_expression(
            unit,
            children[0],
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
    if node_type == "binary_expression":
        left = child_by_field(expression_node, "left")
        right = child_by_field(expression_node, "right")
        if (
            left is None
            or right is None
            or not binary_expression_is_addition(source, expression_node, left, right)
        ):
            return None
        left_value = resolve_workspace_string_expression(
            unit,
            left,
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
        right_value = resolve_workspace_string_expression(
            unit,
            right,
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
        if left_value is None or right_value is None:
            return None
        value = left_value + right_value
        return value if len(value) <= SPRING_MAX_CONSTANT_LENGTH else None
    if node_type in {"identifier", "field_access", "scoped_identifier"}:
        reference = node_text(source, expression_node)
        candidates = workspace_constant_candidates(
            unit,
            reference,
            owner_name,
            workspace,
            expression_node,
            known_static_constants,
        )
        unique = {record["id"]: record for record in candidates}
        if len(unique) != 1:
            return None
        record = next(iter(unique.values()))
        if "resolved_value" in record:
            return record["resolved_value"]
        if record["id"] in stack:
            return None
        return resolve_workspace_string_expression(
            record["unit"],
            record["value_node"],
            workspace,
            record["owner"],
            stack + (record["id"],),
            depth + 1,
            known_static_constants,
        )
    return None


def index_jax_annotation_declarations(workspace):
    declarations = {}
    for unit in workspace["units"].values():
        for info in unit["type_infos"].values():
            if (
                info["node"].type != "annotation_type_declaration"
                or not info["workspace_visible"]
            ):
                continue
            record = {
                "fqn": qualified_type_name(unit, info),
                "simple_name": info["simple_name"],
                "unit": unit,
                "type_info": info,
            }
            declarations.setdefault(record["fqn"], []).append(record)
    return declarations


def index_jax_custom_designators(workspace):
    custom_candidates = set()
    custom_designators = {}
    for unit in workspace["units"].values():
        for declaration_key, candidates in unit["meta_candidates"].items():
            type_info = unit["type_infos"].get(declaration_key)
            if type_info is None:
                continue
            owner_name = type_info["display_name"]
            fqn = qualified_type_name(unit, type_info)
            records = annotation_records(candidates)
            http_methods = []
            retentions = []
            for record in records:
                resolved_http_method = resolve_known_annotation(
                    unit, record["name_node"], {"HttpMethod"}, JAX_RS_PACKAGES
                )
                if resolved_http_method is not None:
                    http_methods.append((record, resolved_http_method))
                resolved_retention = resolve_known_annotation(
                    unit,
                    record["name_node"],
                    {"Retention"},
                    ("java.lang.annotation",),
                )
                if resolved_retention is not None:
                    retentions.append(record)

            if not http_methods:
                continue
            custom_candidates.add(fqn)
            if len(http_methods) != 1:
                log_jax_issue(
                    unit["fname"], owner_name, "ambiguous custom @HttpMethod declaration"
                )
                continue
            if len(retentions) != 1 or not retention_is_runtime(
                unit, retentions[0]["node"]
            ):
                log_jax_issue(
                    unit["fname"], owner_name, "non-runtime custom @HttpMethod declaration"
                )
                continue

            http_annotation, resolved = http_methods[0]
            token = decode_custom_http_method(
                unit,
                http_annotation,
                owner_name,
                workspace,
            )
            if token is None:
                continue
            custom_designators.setdefault(fqn, []).append(
                {
                    "fqn": fqn,
                    "simple_name": type_info["simple_name"],
                    "namespace": resolved["namespace"],
                    "method": token,
                    "fname": unit["fname"],
                }
            )
    workspace["custom_candidates"] = custom_candidates
    workspace["custom_designators"] = custom_designators


def custom_annotation_identity_candidates(
    unit, spelling, workspace, context_node=None
):
    declarations = workspace["annotation_declarations"]
    simple_name = spelling.rsplit(".", 1)[-1]
    if "." in spelling:
        identities = [spelling]
        if unit["package"]:
            identities.append(f"{unit['package']}.{spelling}")
        return {identity for identity in identities if identity in declarations}

    visible_infos = visible_local_type_infos(unit, context_node)
    visible_identities = {
        f"{unit['package']}.{info['display_name']}"
        if unit["package"]
        else info["display_name"]
        for info in visible_infos
        if info["simple_name"] == simple_name
    }
    if visible_identities:
        return visible_identities & set(declarations)

    if simple_name in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][simple_name]
        return {imported} if imported in declarations else set()

    same_package = (
        f"{unit['package']}.{simple_name}" if unit["package"] else simple_name
    )
    if same_package in declarations:
        return {same_package}
    if simple_name in unit.get("package_types", set()):
        return set()

    return {
        f"{package}.{simple_name}"
        for package in unit["imports"]["wildcards"]
        if f"{package}.{simple_name}" in declarations
    }


def direct_annotation_records(declaration_node):
    modifiers = find_first(declaration_node, "modifiers")
    if modifiers is None:
        return []
    records = []
    for annotation_node in modifiers.named_children:
        if annotation_node.type not in {"annotation", "marker_annotation"}:
            continue
        name_node = child_by_field(annotation_node, "name")
        if name_node is not None:
            records.append({"node": annotation_node, "name_node": name_node})
    return sorted(records, key=lambda record: record["node"].start_byte)


def build_spring_annotation_definitions(workspace):
    definitions = {}
    for fqn, declarations in workspace["annotation_declarations"].items():
        for declaration in declarations:
            unit = declaration["unit"]
            type_info = declaration["type_info"]
            type_key = tree_node_key(type_info["node"])
            elements = {}
            for captures in unit["element_candidates"].get(type_key, []):
                element_node = first_capture(captures, "annotation.element.node")
                name_node = first_capture(captures, "annotation.element.name")
                type_node = first_capture(captures, "annotation.element.type")
                default_node = first_capture(captures, "annotation.element.default")
                if None in (element_node, name_node, type_node):
                    continue
                name = node_text(unit["source"], name_node)
                elements.setdefault(name, []).append(
                    {
                        "name": name,
                        "node": element_node,
                        "type_node": type_node,
                        "type_text": node_text(unit["source"], type_node).strip(),
                        "default_node": default_node,
                        "annotations": direct_annotation_records(element_node),
                    }
                )
            definitions.setdefault(fqn, []).append(
                {
                    **declaration,
                    "meta_annotations": annotation_records(
                        unit["meta_candidates"].get(type_key, [])
                    ),
                    "elements": elements,
                }
            )
    workspace["spring_annotation_definitions"] = definitions


def spring_definition_runtime_retained(definition):
    unit = definition["unit"]
    retentions = [
        record
        for record in definition["meta_annotations"]
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"Retention"},
            ("java.lang.annotation",),
        )
        is not None
    ]
    return len(retentions) == 1 and retention_is_runtime(
        unit, retentions[0]["node"]
    )


def resolve_spring_mapping_spelling(unit, spelling, context_node=None):
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in SPRING_MAPPING_METHODS:
        return None
    expected = f"{SPRING_MAPPING_PACKAGE}.{simple_name}"
    if "." in spelling:
        return simple_name if spelling == expected else None
    if simple_name in visible_local_type_names(unit, context_node):
        return None
    explicit = unit["imports"]["exact"].get(simple_name)
    if explicit is not None:
        return simple_name if explicit == expected else None
    if simple_name in unit.get("package_types", set()):
        return None
    if SPRING_MAPPING_PACKAGE not in unit["imports"]["wildcards"]:
        return None
    if unit.get("wildcard_source_types", {}).get(simple_name, set()) - {expected}:
        return None
    return simple_name


def source_annotation_definition(
    unit,
    name_node,
    workspace,
    consumer_owner_name,
):
    spelling = node_text(unit["source"], name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if (
        "." not in spelling
        and simple_name in SPRING_MAPPING_METHODS
        and simple_name not in unit["imports"]["exact"]
        and SPRING_MAPPING_PACKAGE in unit["imports"]["wildcards"]
        and unit.get("wildcard_source_types", {}).get(simple_name, set())
        - {f"{SPRING_MAPPING_PACKAGE}.{simple_name}"}
    ):
        return {"status": "ambiguous", "definition": None}
    identities = custom_annotation_identity_candidates(
        unit, spelling, workspace, name_node
    )
    if not identities:
        return {"status": "none", "definition": None}
    if len(identities) != 1:
        return {"status": "ambiguous", "definition": None}
    identity = next(iter(identities))
    definitions = workspace["spring_annotation_definitions"].get(identity, [])
    if len(definitions) != 1:
        return {
            "status": "ambiguous" if definitions else "missing",
            "definition": None,
        }
    if not workspace_type_accessible(
        definitions[0], unit, consumer_owner_name
    ):
        return {"status": "inaccessible", "definition": None}
    return {"status": "resolved", "definition": definitions[0]}


def unresolved_java_target_reference(unit, record):
    spelling = node_text(unit["source"], record["name_node"]).strip()
    if spelling.rsplit(".", 1)[-1] != "Target":
        return False
    if "." in spelling:
        return spelling == "java.lang.annotation.Target"
    if "Target" in visible_local_type_names(unit, record["name_node"]):
        return False
    explicit = unit["imports"]["exact"].get("Target")
    if explicit is not None:
        return explicit in {"", "java.lang.annotation.Target"}
    if "Target" in unit.get("package_types", set()):
        return False
    return "java.lang.annotation" in unit["imports"]["wildcards"]


def resolve_java_element_type(unit, value_node):
    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = node_text(unit["source"], current).strip()
    element_type = spelling.rsplit(".", 1)[-1]
    if element_type not in JAVA_ELEMENT_TYPES:
        return None
    expected_owner = "java.lang.annotation.ElementType"
    if "." not in spelling:
        return (
            element_type
            if static_member_resolves_to(
                unit, element_type, expected_owner, current
            )
            else None
        )
    qualifier = spelling.rsplit(".", 1)[0]
    return (
        element_type
        if resolve_known_type(
            unit,
            qualifier,
            "ElementType",
            ("java.lang.annotation",),
            current,
        )
        == "java.lang.annotation"
        else None
    )


def annotation_definition_is_method_applicable(definition):
    unit = definition["unit"]
    target_like = [
        record
        for record in definition["meta_annotations"]
        if node_text(unit["source"], record["name_node"])
        .strip()
        .rsplit(".", 1)[-1]
        == "Target"
    ]
    genuine = [
        record
        for record in target_like
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"Target"},
            ("java.lang.annotation",),
        )
        is not None
    ]
    if any(
        unresolved_java_target_reference(unit, record)
        for record in target_like
        if record not in genuine
    ):
        return False
    if not genuine:
        return True
    if len(genuine) != 1:
        return False

    value_node, error = annotation_single_value_node(genuine[0]["node"])
    if error:
        return False
    values = [
        resolve_java_element_type(unit, node)
        for node in annotation_value_nodes(value_node)
    ]
    return (
        bool(values)
        and all(value is not None for value in values)
        and len(values) == len(set(values))
        and "METHOD" in values
    )


def source_annotation_is_method_applicable(
    unit, annotation_record, workspace, consumer_owner_name
):
    resolved = source_annotation_definition(
        unit,
        annotation_record["name_node"],
        workspace,
        consumer_owner_name,
    )
    return (
        resolved["status"] == "resolved"
        and annotation_definition_is_method_applicable(resolved["definition"])
    )


def spring_method_applicable_component_candidates(
    source,
    candidates,
    imports,
    local_annotations,
    unit,
    workspace,
    owner_name,
):
    applicable = []
    for captures in candidates:
        name_node = first_capture(captures, "annotation.name")
        annotation_node = first_capture(captures, "annotation.node")
        if name_node is None or annotation_node is None:
            continue
        if resolve_spring_mapping_name(
            source, name_node, imports, local_annotations, unit=unit
        ) is not None:
            applicable.append(captures)
            continue
        if unit is None or workspace is None:
            continue
        if source_annotation_is_method_applicable(
            unit,
            {"node": annotation_node, "name_node": name_node},
            workspace,
            owner_name,
        ):
            applicable.append(captures)
    return applicable


def jax_method_applicable_component_records(unit, candidates, workspace, owner_name):
    applicable = []
    for record in annotation_records(candidates):
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {*JAX_RS_HTTP_METHODS, "Path"},
            JAX_RS_PACKAGES,
        ) is not None or source_annotation_is_method_applicable(
            unit, record, workspace, owner_name
        ):
            applicable.append(record)
    return applicable


def collect_spring_mapping_branches(definition, workspace, stack=(), depth=0):
    if depth > SPRING_MAX_CONSTANT_DEPTH:
        return [], ["composed-annotation depth limit"]
    if definition["fqn"] in stack:
        return [], ["composed-annotation cycle"]

    branches = []
    errors = []
    for meta_record in definition["meta_annotations"]:
        unit = definition["unit"]
        spelling = node_text(unit["source"], meta_record["name_node"]).strip()
        mapping_name = resolve_spring_mapping_spelling(
            unit, spelling, meta_record["name_node"]
        )
        if mapping_name is not None:
            if mapping_name != "RequestMapping":
                errors.append(
                    f"@{mapping_name} cannot target an annotation declaration"
                )
                continue
            branches.append(
                {
                    "definitions": [definition],
                    "instances": [],
                    "leaf_record": meta_record,
                    "leaf_name": mapping_name,
                    "leaf_fqn": f"{SPRING_MAPPING_PACKAGE}.{mapping_name}",
                }
            )
            continue

        resolved = source_annotation_definition(
            unit,
            meta_record["name_node"],
            workspace,
            definition["type_info"]["display_name"],
        )
        if resolved["status"] == "none":
            continue
        if resolved["status"] != "resolved":
            errors.append(
                f"{resolved['status']} composed meta-annotation {spelling}"
            )
            continue
        tails, tail_errors = collect_spring_mapping_branches(
            resolved["definition"],
            workspace,
            stack + (definition["fqn"],),
            depth + 1,
        )
        errors.extend(tail_errors)
        for tail in tails:
            branches.append(
                {
                    **tail,
                    "definitions": [definition, *tail["definitions"]],
                    "instances": [
                        {
                            "record": meta_record,
                            "unit": definition["unit"],
                            "owner_name": definition["type_info"]["display_name"],
                        },
                        *tail["instances"],
                    ],
                }
            )
    return branches, errors


def decode_alias_string(unit, value_node, workspace, owner_name):
    value = resolve_workspace_string_expression(
        unit, value_node, workspace, owner_name
    )
    return value if value is not None else None


def resolve_alias_annotation_target(definition, value_node, workspace):
    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type != "class_literal" or not current.named_children:
        return None
    spelling = node_text(definition["unit"]["source"], current.named_children[0]).strip()
    mapping_name = resolve_spring_mapping_spelling(
        definition["unit"], spelling, current.named_children[0]
    )
    if mapping_name is not None:
        return f"{SPRING_MAPPING_PACKAGE}.{mapping_name}"
    identities = custom_annotation_identity_candidates(
        definition["unit"], spelling, workspace, current.named_children[0]
    )
    if len(identities) != 1:
        return None
    identity = next(iter(identities))
    declarations = workspace["annotation_declarations"].get(identity, [])
    if len(declarations) != 1 or not workspace_type_accessible(
        declarations[0],
        definition["unit"],
        definition["type_info"]["display_name"],
    ):
        return None
    return identity


def parse_spring_alias_edge(definition, element, workspace):
    unit = definition["unit"]
    alias_like = [
        record
        for record in element["annotations"]
        if node_text(unit["source"], record["name_node"])
        .strip()
        .rsplit(".", 1)[-1]
        == "AliasFor"
    ]
    if not alias_like:
        return {"status": "none", "target": None, "attribute": None}
    genuine = [
        record
        for record in alias_like
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"AliasFor"},
            (SPRING_ALIAS_FOR_PACKAGE,),
        )
        is not None
    ]
    if len(alias_like) != 1 or len(genuine) != 1:
        return {"status": "invalid", "reason": "invalid @AliasFor provenance"}

    positional, named = get_annotation_arguments(genuine[0]["node"])
    if set(named) - {"value", "attribute", "annotation"} or len(positional) > 1:
        return {"status": "invalid", "reason": "unsupported @AliasFor arguments"}
    if positional and "value" in named:
        return {"status": "invalid", "reason": "duplicate @AliasFor value"}
    if "attribute" in named and (positional or "value" in named):
        return {
            "status": "invalid",
            "reason": "@AliasFor value and attribute are mutually exclusive",
        }

    value_node = named.get("value") or (positional[0] if positional else None)
    attribute_node = named.get("attribute")
    value_name = (
        decode_alias_string(unit, value_node, workspace, definition["type_info"]["display_name"])
        if value_node is not None
        else ""
    )
    attribute_name = (
        decode_alias_string(
            unit,
            attribute_node,
            workspace,
            definition["type_info"]["display_name"],
        )
        if attribute_node is not None
        else ""
    )
    if value_name is None or attribute_name is None:
        return {"status": "invalid", "reason": "unresolved @AliasFor attribute"}
    if value_name and attribute_name and value_name != attribute_name:
        return {"status": "invalid", "reason": "conflicting @AliasFor attributes"}
    target_attribute = value_name or attribute_name or element["name"]

    annotation_node = named.get("annotation")
    target = definition["fqn"]
    if annotation_node is not None:
        target = resolve_alias_annotation_target(definition, annotation_node, workspace)
        if target is None:
            return {"status": "invalid", "reason": "unresolved @AliasFor annotation"}
    return {
        "status": "resolved",
        "target": target,
        "attribute": target_attribute,
    }


def spring_alias_element_type_valid(element, canonical_attribute, definition):
    compact = re.sub(r"\s+", "", element["type_text"])
    base_type = compact[:-2] if compact.endswith("[]") else compact
    if canonical_attribute == "path":
        return resolve_known_type(
            definition["unit"],
            base_type,
            "String",
            ("java.lang",),
            element["type_node"],
        ) == "java.lang"
    if canonical_attribute != "method":
        return False
    return resolve_known_type(
        definition["unit"],
        base_type,
        "RequestMethod",
        (SPRING_MAPPING_PACKAGE,),
        element["type_node"],
    ) == SPRING_MAPPING_PACKAGE


def spring_alias_non_output_type_valid(element, expected_type, definition):
    compact = re.sub(r"\s+", "", element["type_text"])
    if expected_type == "string_array":
        if compact.endswith("[]"):
            compact = compact[:-2]
    elif compact.endswith("[]"):
        return False
    return resolve_known_type(
        definition["unit"],
        compact,
        "String",
        ("java.lang",),
        element["type_node"],
    ) == "java.lang"


def spring_alias_value_cardinality_valid(element, value_node):
    compact = re.sub(r"\s+", "", element["type_text"])
    if compact.endswith("[]"):
        return True
    current = unwrap_parenthesized_node(value_node)
    return bool(
        current is not None
        and current.type != "element_value_array_initializer"
        and len(annotation_value_nodes(value_node)) == 1
    )


def spring_alias_known_type_shape(element, definition):
    compact = re.sub(r"\s+", "", element["type_text"])
    is_array = compact.endswith("[]")
    base_type = compact[:-2] if is_array else compact
    if base_type in {
        "boolean",
        "byte",
        "short",
        "int",
        "long",
        "char",
        "float",
        "double",
    }:
        return (base_type, is_array)
    if resolve_known_type(
        definition["unit"],
        base_type,
        "String",
        ("java.lang",),
        element["type_node"],
    ) == "java.lang":
        return ("java.lang.String", is_array)
    if resolve_known_type(
        definition["unit"],
        base_type,
        "RequestMethod",
        (SPRING_MAPPING_PACKAGE,),
        element["type_node"],
    ) == SPRING_MAPPING_PACKAGE:
        return (f"{SPRING_MAPPING_PACKAGE}.RequestMethod", is_array)
    return None


def spring_alias_custom_types_compatible(
    source_element, source_definition, target_element, target_definition
):
    source_shape = spring_alias_known_type_shape(source_element, source_definition)
    target_shape = spring_alias_known_type_shape(target_element, target_definition)
    if source_shape is None or target_shape is None:
        return False
    source_type, source_array = source_shape
    target_type, target_array = target_shape
    return source_type == target_type and (
        source_array == target_array or (target_array and not source_array)
    )


def resolve_ignored_sibling_alias_target(
    definition, target_fqn, target_attribute, workspace
):
    definitions = workspace["spring_annotation_definitions"].get(target_fqn, [])
    if len(definitions) != 1:
        return {"status": "invalid", "reason": "ambiguous sibling alias target"}
    target_definition = definitions[0]
    if not workspace_type_accessible(
        target_definition,
        definition["unit"],
        definition["type_info"]["display_name"],
    ) or not spring_definition_runtime_retained(target_definition):
        return {"status": "invalid", "reason": "invalid sibling alias target"}

    target_records = []
    for record in definition["meta_annotations"]:
        spelling = node_text(
            definition["unit"]["source"], record["name_node"]
        ).strip()
        identities = custom_annotation_identity_candidates(
            definition["unit"], spelling, workspace, record["name_node"]
        )
        if identities == {target_fqn}:
            target_records.append(record)
    if len(target_records) != 1:
        return {"status": "invalid", "reason": "alias target is not a unique direct meta-annotation"}

    _values, instance_error = annotation_instance_values(
        target_definition, target_records[0]
    )
    target_elements = target_definition["elements"].get(target_attribute, [])
    if instance_error or len(target_elements) != 1:
        return {"status": "invalid", "reason": "missing sibling alias target element"}
    target_element = target_elements[0]
    if parse_spring_alias_edge(
        target_definition, target_element, workspace
    )["status"] != "none":
        return {"status": "invalid", "reason": "nested sibling alias is outside the bounded graph"}
    return {
        "status": "ignored_custom",
        "element": target_element,
        "definition": target_definition,
        "target_key": f"{target_fqn}#{target_attribute}",
    }


def resolve_spring_alias_terminal(
    definition,
    element_name,
    branch_definitions,
    branch_positions,
    leaf_fqn,
    leaf_name,
    workspace,
    stack=(),
):
    key = (definition["fqn"], element_name)
    if key in stack:
        return {"status": "invalid", "reason": "@AliasFor element cycle"}
    elements = definition["elements"].get(element_name, [])
    if len(elements) != 1:
        return {"status": "invalid", "reason": "missing or ambiguous alias element"}
    element = elements[0]
    edge = parse_spring_alias_edge(definition, element, workspace)
    if edge["status"] != "resolved":
        if edge["status"] == "none" and stack:
            return {
                "status": "ignored_custom",
                "element": element,
                "definition": definition,
                "target_key": f"{definition['fqn']}#{element_name}",
            }
        return (
            edge
            if edge["status"] == "invalid"
            else {"status": "invalid", "reason": "alias does not reach a mapping"}
        )

    if edge["target"] == leaf_fqn:
        target_attribute = edge["attribute"]
        if target_attribute in {"value", "path"}:
            canonical = "path"
        elif leaf_name == "RequestMapping" and target_attribute == "method":
            canonical = "method"
        elif (
            leaf_name == "RequestMapping"
            and target_attribute in SPRING_REQUEST_MAPPING_ATTRIBUTES
        ):
            expected_type = (
                "string"
                if target_attribute in {"name", "version"}
                else "string_array"
            )
            if not spring_alias_non_output_type_valid(
                element, expected_type, definition
            ):
                return {"status": "invalid", "reason": "incompatible alias element type"}
            return {
                "status": "ignored",
                "attribute": target_attribute,
                "expected_type": expected_type,
            }
        else:
            return {"status": "invalid", "reason": "unsupported mapping alias target"}
        if not spring_alias_element_type_valid(element, canonical, definition):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return {"status": "resolved", "attribute": canonical}

    if edge["target"] == definition["fqn"]:
        target_elements = definition["elements"].get(edge["attribute"], [])
        if len(target_elements) != 1 or edge["attribute"] == element_name:
            return {
                "status": "invalid",
                "reason": "invalid local @AliasFor target",
            }
        target_element = target_elements[0]
        reverse = parse_spring_alias_edge(definition, target_element, workspace)
        if (
            reverse["status"] != "resolved"
            or reverse["target"] != definition["fqn"]
            or reverse["attribute"] != element_name
        ):
            return {
                "status": "invalid",
                "reason": "local @AliasFor pair is not reciprocal",
            }
        if not spring_alias_custom_types_compatible(
            element, definition, target_element, definition
        ):
            return {
                "status": "invalid",
                "reason": "incompatible local alias element type",
            }

        # A reciprocal local pair on a composed RequestMapping can override a
        # meta-attribute by convention when one member bears that attribute's
        # name.  Collapse the pair before values/defaults are reconciled so a
        # single explicit member is propagated to its omitted mate.
        component_names = {element_name, edge["attribute"]}
        canonical = None
        if component_names & {"value", "path"}:
            canonical = "path"
        elif "method" in component_names and leaf_name == "RequestMapping":
            canonical = "method"
        if canonical is not None:
            if not all(
                spring_alias_element_type_valid(
                    current_element, canonical, definition
                )
                for current_element in (element, target_element)
            ):
                return {
                    "status": "invalid",
                    "reason": "incompatible local alias element type",
                }
            return {"status": "resolved", "attribute": canonical}

        ignored_attributes = component_names & SPRING_REQUEST_MAPPING_ATTRIBUTES
        if leaf_name == "RequestMapping" and len(ignored_attributes) == 1:
            ignored_attribute = next(iter(ignored_attributes))
            expected_type = (
                "string"
                if ignored_attribute in {"name", "version"}
                else "string_array"
            )
            if not all(
                spring_alias_non_output_type_valid(
                    current_element, expected_type, definition
                )
                for current_element in (element, target_element)
            ):
                return {
                    "status": "invalid",
                    "reason": "incompatible local alias element type",
                }
            return {
                "status": "ignored",
                "attribute": ignored_attribute,
                "expected_type": expected_type,
            }
        if ignored_attributes:
            return {
                "status": "invalid",
                "reason": "ambiguous local alias mapping target",
            }
        return {
            "status": "ignored_custom",
            "element": element,
            "definition": definition,
            "target_key": "local:"
            + definition["fqn"]
            + "#"
            + ",".join(sorted(component_names)),
        }
    target_definition = branch_definitions.get(edge["target"])
    if target_definition is None:
        terminal = resolve_ignored_sibling_alias_target(
            definition, edge["target"], edge["attribute"], workspace
        )
        if terminal["status"] != "ignored_custom":
            return terminal
        if not spring_alias_custom_types_compatible(
            element,
            definition,
            terminal["element"],
            terminal["definition"],
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if branch_positions[edge["target"]] <= branch_positions[definition["fqn"]]:
        return {"status": "invalid", "reason": "alias targets an outer annotation"}
    target_elements = target_definition["elements"].get(edge["attribute"], [])
    if len(target_elements) != 1 or not spring_alias_custom_types_compatible(
        element,
        definition,
        target_elements[0] if target_elements else element,
        target_definition,
    ):
        return {"status": "invalid", "reason": "incompatible alias element type"}
    terminal = resolve_spring_alias_terminal(
        target_definition,
        edge["attribute"],
        branch_definitions,
        branch_positions,
        leaf_fqn,
        leaf_name,
        workspace,
        stack + (key,),
    )
    if terminal["status"] == "ignored_custom":
        if not spring_alias_custom_types_compatible(
            element,
            definition,
            terminal["element"],
            terminal["definition"],
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if terminal["status"] == "ignored":
        if not spring_alias_non_output_type_valid(
            element, terminal["expected_type"], definition
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if terminal["status"] != "resolved":
        return terminal
    if not spring_alias_element_type_valid(
        element, terminal["attribute"], definition
    ):
        return {"status": "invalid", "reason": "incompatible alias element type"}
    return terminal


def annotation_instance_values(definition, annotation_record):
    positional, named = get_annotation_arguments(annotation_record["node"])
    if set(named) - set(definition["elements"]):
        return None, "unknown composed-annotation attribute"
    values = dict(named)
    if positional:
        if len(positional) != 1 or "value" not in definition["elements"] or "value" in values:
            return None, "invalid positional composed-annotation value"
        values["value"] = positional[0]
    missing_required = [
        element_name
        for element_name, elements in definition["elements"].items()
        if element_name not in values
        and any(element["default_node"] is None for element in elements)
    ]
    if missing_required:
        return None, "missing required composed-annotation attribute"
    return values, None


def decode_spring_alias_path_value(
    value_unit, value_owner_name, value_node, workspace
):
    values = []
    for current in annotation_value_nodes(value_node):
        value = resolve_workspace_string_expression(
            value_unit,
            current,
            workspace,
            value_owner_name,
        )
        if value is None:
            return None
        values.append(value)
    return tuple(dict.fromkeys(values))


def decode_spring_alias_method_value(value_unit, value_node):
    methods = []
    for current in annotation_value_nodes(value_node):
        method_name = resolve_spring_request_method_expression(
            value_unit["source"],
            current,
            value_unit["imports"],
            unit=value_unit,
        )
        if method_name is None:
            return None
        methods.append(method_name)
    return tuple(methods)


def invalid_spring_composed_mapping(annotation_node):
    return {
        "name": "ComposedMapping",
        "paths": [],
        "methods": [],
        "valid": False,
        "annotation_node": annotation_node,
    }


def log_spring_composed_issue(fname, owner_name, spelling, reason):
    write_log(
        f"Skipped invalid Spring composed mapping in {fname} for "
        f"{owner_name} @{spelling}: {reason}"
    )


def decode_spring_composed_mapping(
    fname,
    use_unit,
    annotation_name_node,
    annotation_node,
    lexical_owner_name,
    diagnostic_owner_name,
    workspace,
):
    spelling = node_text(use_unit["source"], annotation_name_node).strip()
    resolved = source_annotation_definition(
        use_unit,
        annotation_name_node,
        workspace,
        lexical_owner_name,
    )
    if resolved["status"] == "none":
        return None
    if resolved["status"] != "resolved":
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, resolved["status"]
        )
        return invalid_spring_composed_mapping(annotation_node)

    definition = resolved["definition"]
    branches, errors = collect_spring_mapping_branches(definition, workspace)
    if not branches and not errors:
        return None
    if errors or len(branches) != 1:
        reason = errors[0] if errors else "multiple mapping leaves"
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, reason
        )
        return invalid_spring_composed_mapping(annotation_node)

    branch = branches[0]
    if any(
        not spring_definition_runtime_retained(current)
        for current in branch["definitions"]
    ):
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, "non-runtime annotation"
        )
        return invalid_spring_composed_mapping(annotation_node)

    leaf_definition = branch["definitions"][-1]
    leaf_unit = leaf_definition["unit"]
    leaf_record = branch["leaf_record"]
    mapping = decode_spring_mapping(
        leaf_unit["fname"],
        leaf_unit["source"],
        leaf_record["name_node"],
        leaf_record["node"],
        leaf_unit["imports"],
        leaf_unit["local_annotations"],
        leaf_unit["constant_index"],
        leaf_definition["type_info"]["display_name"],
        diagnostic_owner_name,
        leaf_unit,
        workspace,
    )
    if mapping is None or not mapping["valid"]:
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, "invalid mapping leaf"
        )
        return invalid_spring_composed_mapping(annotation_node)

    definitions_by_fqn = {
        current["fqn"]: current for current in branch["definitions"]
    }
    definition_positions = {
        current["fqn"]: index
        for index, current in enumerate(branch["definitions"])
    }
    terminals = {}
    for current in branch["definitions"]:
        for element_name, elements in current["elements"].items():
            for element in elements:
                edge = parse_spring_alias_edge(current, element, workspace)
                if edge["status"] == "none":
                    continue
                if edge["status"] == "invalid":
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        edge["reason"],
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                terminal = resolve_spring_alias_terminal(
                    current,
                    element_name,
                    definitions_by_fqn,
                    definition_positions,
                    branch["leaf_fqn"],
                    branch["leaf_name"],
                    workspace,
                )
                if terminal["status"] == "ignored":
                    terminals[(current["fqn"], element_name)] = (
                        f"ignored:{terminal['attribute']}"
                    )
                    continue
                if terminal["status"] == "ignored_custom":
                    terminals[(current["fqn"], element_name)] = (
                        f"ignored-custom:{terminal['target_key']}"
                    )
                    continue
                if terminal["status"] != "resolved":
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        terminal["reason"],
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                terminals[(current["fqn"], element_name)] = terminal["attribute"]

    for current in branch["definitions"]:
        terminal_attributes = {
            terminal_attribute
            for (definition_fqn, _element_name), terminal_attribute in terminals.items()
            if definition_fqn == current["fqn"]
        }
        for terminal_attribute in terminal_attributes:
            aliased_elements = [
                current["elements"][element_name][0]
                for definition_fqn, element_name in terminals
                if definition_fqn == current["fqn"]
                and terminals[(definition_fqn, element_name)] == terminal_attribute
                and len(current["elements"].get(element_name, [])) == 1
            ]
            if len(aliased_elements) < 2:
                continue
            declared_types = {
                re.sub(r"\s+", "", element["type_text"])
                for element in aliased_elements
            }
            if len(declared_types) != 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "implicit alias return types differ",
                )
                return invalid_spring_composed_mapping(annotation_node)
            defaults = []
            for element in aliased_elements:
                if element["default_node"] is None:
                    defaults = None
                    break
                if not spring_alias_value_cardinality_valid(
                    element, element["default_node"]
                ):
                    defaults = None
                    break
                default = (
                    decode_spring_alias_path_value(
                        current["unit"],
                        current["type_info"]["display_name"],
                        element["default_node"],
                        workspace,
                    )
                    if terminal_attribute != "method"
                    else decode_spring_alias_method_value(
                        current["unit"], element["default_node"]
                    )
                )
                if default is None:
                    defaults = None
                    break
                defaults.append(default)
            if defaults is None or len(set(defaults)) != 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "implicit alias defaults differ",
                )
                return invalid_spring_composed_mapping(annotation_node)

    instances = [
        {
            "record": {"node": annotation_node, "name_node": annotation_name_node},
            "unit": use_unit,
            "owner_name": lexical_owner_name,
        },
        *branch["instances"],
    ]
    overrides = {}
    for current, instance_info in reversed(list(zip(branch["definitions"], instances))):
        explicit, error = annotation_instance_values(
            current, instance_info["record"]
        )
        if error:
            log_spring_composed_issue(
                fname, diagnostic_owner_name, spelling, error
            )
            return invalid_spring_composed_mapping(annotation_node)
        layer = {}
        grouped_elements = {}
        for element_name, elements in current["elements"].items():
            if len(elements) != 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "ambiguous composed-annotation element",
                )
                return invalid_spring_composed_mapping(annotation_node)
            terminal_attribute = terminals.get((current["fqn"], element_name))
            if terminal_attribute is None:
                continue
            if terminal_attribute.startswith("ignored-custom:"):
                continue
            element = elements[0]
            grouped_elements.setdefault(terminal_attribute, []).append(
                (element_name, element)
            )

        for terminal_attribute, group in grouped_elements.items():
            supplied = [
                (element_name, element, explicit[element_name])
                for element_name, element in group
                if element_name in explicit
            ]
            selected = supplied or [
                (element_name, element, element["default_node"])
                for element_name, element in group
                if element["default_node"] is not None
            ]
            decoded_values = []
            for element_name, element, value_node in selected:
                if not spring_alias_value_cardinality_valid(element, value_node):
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        "invalid composed-annotation value cardinality",
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                if supplied:
                    value_unit = instance_info["unit"]
                    value_owner_name = instance_info["owner_name"]
                else:
                    value_unit = current["unit"]
                    value_owner_name = current["type_info"]["display_name"]
                value = (
                    decode_spring_alias_path_value(
                        value_unit, value_owner_name, value_node, workspace
                    )
                    if terminal_attribute != "method"
                    else decode_spring_alias_method_value(value_unit, value_node)
                )
                if value is None:
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        "unresolved composed-annotation value",
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                if value and any(value):
                    decoded_values.append(value)
            if len(set(decoded_values)) > 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "conflicting composed-annotation values",
                )
                return invalid_spring_composed_mapping(annotation_node)
            if decoded_values:
                layer[terminal_attribute] = decoded_values[0]
        overrides.update(layer)

    if "path" in overrides:
        mapping["paths"] = [
            normalize_spring_path(value) for value in overrides["path"]
        ]
    if "method" in overrides:
        mapping["methods"] = ordered_http_methods(overrides["method"])
    mapping["annotation_node"] = annotation_node
    return mapping


def resolve_custom_designator(unit, name_node, workspace, owner_name):
    spelling = node_text(unit["source"], name_node).strip()
    identities = custom_annotation_identity_candidates(
        unit, spelling, workspace, name_node
    )
    relevant = {
        identity
        for identity in identities
        if identity in workspace["custom_candidates"]
        or identity in workspace["custom_designators"]
    }
    if not relevant:
        return {"status": "none", "record": None}
    if len(identities) != 1 or len(relevant) != 1:
        return {"status": "ambiguous", "record": None}
    identity = next(iter(relevant))
    declarations = workspace["annotation_declarations"].get(identity, [])
    if len(declarations) != 1 or not workspace_type_accessible(
        declarations[0], unit, owner_name
    ):
        return {"status": "invalid", "record": None}
    records = workspace["custom_designators"].get(identity, [])
    if len(records) == 1:
        return {"status": "resolved", "record": records[0]}
    return {
        "status": "invalid" if not records else "ambiguous",
        "record": None,
    }


def index_jax_applications(workspace):
    applications = []
    for unit in workspace["units"].values():
        for type_key, type_info in unit["type_infos"].items():
            if type_info["node"].type != "class_declaration":
                continue
            records = annotation_records(unit["type_candidates"].get(type_key, []))
            application_annotations = []
            for record in records:
                resolved = resolve_known_annotation(
                    unit,
                    record["name_node"],
                    {"ApplicationPath"},
                    JAX_RS_PACKAGES,
                )
                if resolved is not None:
                    application_annotations.append((record, resolved))
            if not application_annotations:
                continue
            owner_name = type_info["display_name"]
            if type_info["abstract"]:
                log_jax_issue(
                    unit["fname"], owner_name, "@ApplicationPath on an abstract Application"
                )
                continue
            if len(application_annotations) != 1:
                log_jax_issue(
                    unit["fname"], owner_name, "ambiguous @ApplicationPath annotations"
                )
                for _record, resolved in application_annotations:
                    applications.append(
                        {
                            "namespace": resolved["namespace"],
                            "package": unit["package"],
                            "path": None,
                            "fname": unit["fname"],
                            "simple_name": type_info["simple_name"],
                            "fqn": qualified_type_name(unit, type_info),
                        }
                    )
                continue

            record, resolved = application_annotations[0]
            application_namespace = type_directly_extends_jax_application(
                unit, type_info
            )
            if application_namespace != resolved["namespace"]:
                log_jax_issue(
                    unit["fname"],
                    owner_name,
                    "@ApplicationPath on a non-matching direct Application subclass",
                )
                continue
            path = decode_jax_path_annotation(
                unit,
                record,
                owner_name,
                owner_name,
                "@ApplicationPath value",
                workspace,
            )
            applications.append(
                {
                    "namespace": resolved["namespace"],
                    "package": unit["package"],
                    "path": path,
                    "fname": unit["fname"],
                    "simple_name": type_info["simple_name"],
                    "fqn": qualified_type_name(unit, type_info),
                }
            )
    workspace["applications"] = applications


def build_jax_workspace(
    source_by_file,
    runtime=None,
    parsed_trees=None,
    include_jax=True,
):
    runtime = runtime or build_jax_runtime()
    parsed_trees = parsed_trees or {}
    normalized_sources = {
        str(fname): source for fname, source in source_by_file.items()
    }
    normalized_trees = {
        str(fname): tree for fname, tree in parsed_trees.items()
    }
    units = {}
    for fname in sorted(normalized_sources):
        source = java_source_bytes(fname, normalized_sources[fname])
        units[fname] = build_jax_unit(
            fname, source, runtime, parsed_tree=normalized_trees.get(fname)
        )
    package_types = {}
    for unit in units.values():
        names = package_types.setdefault(unit["package"], set())
        names.update(
            info["simple_name"]
            for info in unit["type_infos"].values()
            if info["outer_key"] is None
        )
    for unit in units.values():
        own_top_level_names = {
            info["simple_name"]
            for info in unit["type_infos"].values()
            if info["outer_key"] is None
        }
        unit["package_types"] = package_types[unit["package"]] - own_top_level_names
        wildcard_source_types = {}
        for imported_package in unit["imports"]["wildcards"]:
            for simple_name in package_types.get(imported_package, set()):
                wildcard_source_types.setdefault(simple_name, set()).add(
                    f"{imported_package}.{simple_name}"
                )
        unit["wildcard_source_types"] = wildcard_source_types
    workspace = {"runtime": runtime, "units": units}
    index_workspace_types(workspace)
    index_workspace_constants(workspace)
    workspace["annotation_declarations"] = index_jax_annotation_declarations(workspace)
    build_spring_annotation_definitions(workspace)
    if include_jax:
        index_jax_custom_designators(workspace)
        index_jax_applications(workspace)
    else:
        workspace["custom_candidates"] = set()
        workspace["custom_designators"] = {}
        workspace["applications"] = []
    return workspace


def package_is_ancestor(ancestor, package):
    return not ancestor or package == ancestor or package.startswith(f"{ancestor}.")


def package_specificity(package):
    return len(package.split(".")) if package else 0


def select_jax_application_path(workspace, unit, namespace, owner_name):
    deployment = workspace.get("jax_deployment")
    if deployment is not None:
        return select_jax_deployment_path(
            deployment, unit, namespace, owner_name, sys.modules[__name__]
        )
    applications = [
        application
        for application in workspace["applications"]
        if application["namespace"] == namespace
    ]
    if not applications:
        return ""

    valid_paths = {
        application["path"]
        for application in applications
        if application["path"] is not None
    }
    invalid_count = sum(application["path"] is None for application in applications)
    if not invalid_count and len(valid_paths) == 1:
        return next(iter(valid_paths))
    if len(applications) == 1:
        log_jax_issue(
            unit["fname"], owner_name, "unresolved @ApplicationPath association"
        )
        return None

    candidates = [
        application
        for application in applications
        if package_is_ancestor(application["package"], unit["package"])
    ]
    if candidates:
        specificity = max(
            package_specificity(application["package"])
            for application in candidates
        )
        candidates = [
            application
            for application in candidates
            if package_specificity(application["package"]) == specificity
        ]
    candidate_paths = {
        application["path"]
        for application in candidates
        if application["path"] is not None
    }
    if candidates and all(
        application["path"] is not None for application in candidates
    ) and len(candidate_paths) == 1:
        return next(iter(candidate_paths))

    log_jax_issue(
        unit["fname"], owner_name, "ambiguous @ApplicationPath association"
    )
    return None


def method_is_public(method_node):
    modifiers = find_first(method_node, "modifiers")
    return bool(modifiers and any(child.type == "public" for child in modifiers.children))


def resolve_jax_root(unit, type_info, workspace):
    type_key = tree_node_key(type_info["node"])
    records = annotation_records(unit["type_candidates"].get(type_key, []))
    paths = []
    for record in records:
        resolved = resolve_known_annotation(
            unit, record["name_node"], {"Path"}, JAX_RS_PACKAGES
        )
        if resolved is not None:
            paths.append((record, resolved))
    if not paths:
        return None
    owner_name = type_info["display_name"]
    if len(paths) != 1:
        log_jax_issue(unit["fname"], owner_name, "ambiguous class @Path annotations")
        return None
    record, resolved = paths[0]
    path = decode_jax_path_annotation(
        unit,
        record,
        owner_name,
        owner_name,
        "class @Path value",
        workspace,
    )
    if path is None:
        return None
    return {"path": path, "namespace": resolved["namespace"]}


def resolve_jax_method_designator(unit, records, workspace, namespace, owner_name):
    designators = []
    invalid = False
    for record in records:
        standard = resolve_known_annotation(
            unit, record["name_node"], set(JAX_RS_HTTP_METHODS), JAX_RS_PACKAGES
        )
        if standard is not None:
            if standard["namespace"] != namespace:
                invalid = True
                log_jax_issue(
                    unit["fname"], owner_name, "mixed Javax/Jakarta designator"
                )
                continue
            if not annotation_has_no_values(record["node"]):
                invalid = True
                log_jax_issue(
                    unit["fname"], owner_name, "invalid standard designator arguments"
                )
                continue
            designators.append(
                {"method": standard["name"], "node": record["node"]}
            )
            continue

        custom = resolve_custom_designator(
            unit, record["name_node"], workspace, owner_name
        )
        if custom["status"] == "none":
            continue
        if custom["status"] != "resolved":
            invalid = True
            log_jax_issue(
                unit["fname"], owner_name, f"{custom['status']} custom designator"
            )
            continue
        custom_record = custom["record"]
        if custom_record["namespace"] != namespace:
            invalid = True
            log_jax_issue(
                unit["fname"], owner_name, "mixed Javax/Jakarta custom designator"
            )
            continue
        designators.append(
            {"method": custom_record["method"], "node": record["node"]}
        )

    if invalid:
        return None
    if len(designators) > 1:
        log_jax_issue(
            unit["fname"], owner_name, "multiple request-method designators"
        )
        return None
    return designators[0] if designators else None


def resolve_jax_method_path(
    unit, records, namespace, type_owner, owner_name, workspace
):
    paths = []
    for record in records:
        resolved = resolve_known_annotation(
            unit, record["name_node"], {"Path"}, JAX_RS_PACKAGES
        )
        if resolved is not None:
            paths.append((record, resolved))
    if not paths:
        return ""
    if len(paths) != 1 or paths[0][1]["namespace"] != namespace:
        log_jax_issue(
            unit["fname"], owner_name, "ambiguous or mixed method @Path annotation"
        )
        return None
    return decode_jax_path_annotation(
        unit,
        paths[0][0],
        type_owner,
        owner_name,
        "method @Path value",
        workspace,
    )


def analyze_jax_unit(unit, workspace):
    roots = {}
    for type_key, type_info in unit["type_infos"].items():
        if (
            type_info["node"].type
            not in {"class_declaration", "record_declaration"}
            or type_info["abstract"]
            or not type_info["workspace_visible"]
        ):
            continue
        root = resolve_jax_root(unit, type_info, workspace)
        if root is not None:
            roots[type_key] = root

    endpoints = []
    for method_key in sorted(unit["method_candidates"]):
        candidates = unit["method_candidates"][method_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        method_node = first_capture(representative, "method.node")
        method_name_node = first_capture(representative, "method.name")
        parameters_node = first_capture(representative, "method.parameters")
        if None in (type_node, method_node, method_name_node, parameters_node):
            continue
        type_key = tree_node_key(type_node)
        root = roots.get(type_key)
        type_info = unit["type_infos"].get(type_key)
        if root is None or type_info is None:
            continue

        method_name = node_text(unit["source"], method_name_node)
        owner_name = f"{type_info['display_name']}.{method_name}"
        records = annotation_records(candidates)
        designator = resolve_jax_method_designator(
            unit, records, workspace, root["namespace"], owner_name
        )
        if designator is None:
            continue
        if not method_is_public(method_node):
            log_jax_issue(unit["fname"], owner_name, "non-public resource method")
            continue
        method_path = resolve_jax_method_path(
            unit,
            records,
            root["namespace"],
            type_info["display_name"],
            owner_name,
            workspace,
        )
        if method_path is None:
            continue
        application_path = select_jax_application_path(
            workspace, unit, root["namespace"], owner_name
        )
        if application_path is None:
            continue

        uri = combine_paths(
            combine_paths(application_path, root["path"]), method_path
        )
        endpoint = {
            "uri": uri,
            "method": designator["method"],
            "uri_params": get_callable_parameters_as_is(
                unit["source"], parameters_node
            ),
            "SrcFile": unit["fname"],
            "SrcLine": designator["node"].start_point.row + 1,
            "SFunction": owner_name,
        }
        endpoints.append(endpoint)
        debug_log(endpoint)

    for component_key in sorted(unit["record_component_candidates"]):
        candidates = unit["record_component_candidates"][component_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        component_name_node = first_capture(representative, "component.name")
        if type_node is None or component_name_node is None:
            continue
        type_key = tree_node_key(type_node)
        root = roots.get(type_key)
        type_info = unit["type_infos"].get(type_key)
        if root is None or type_info is None:
            continue

        component_name = node_text(unit["source"], component_name_node)
        if (type_key, component_name) in unit["record_explicit_accessors"]:
            continue
        owner_name = f"{type_info['display_name']}.{component_name}"
        records = jax_method_applicable_component_records(
            unit, candidates, workspace, type_info["display_name"]
        )
        designator = resolve_jax_method_designator(
            unit, records, workspace, root["namespace"], owner_name
        )
        if designator is None:
            continue
        method_path = resolve_jax_method_path(
            unit,
            records,
            root["namespace"],
            type_info["display_name"],
            owner_name,
            workspace,
        )
        if method_path is None:
            continue
        application_path = select_jax_application_path(
            workspace, unit, root["namespace"], owner_name
        )
        if application_path is None:
            continue

        uri = combine_paths(
            combine_paths(application_path, root["path"]), method_path
        )
        endpoint = {
            "uri": uri,
            "method": designator["method"],
            "uri_params": "",
            "SrcFile": unit["fname"],
            "SrcLine": designator["node"].start_point.row + 1,
            "SFunction": owner_name,
        }
        endpoints.append(endpoint)
        debug_log(endpoint)
    return endpoints


def JaxRS_Analyzer(fname, fcontent=None, runtime=None, workspace=None):
    """Extract direct JAX-RS resource methods from one workspace source."""
    fname = str(fname)
    if workspace is None:
        runtime = runtime or build_jax_runtime()
        source = java_source_bytes(fname, fcontent)
        workspace = build_jax_workspace({fname: source}, runtime=runtime)
    unit = workspace["units"].get(fname)
    if unit is None:
        return []
    write_log(f"{fname}:")
    return analyze_jax_unit(unit, workspace)

def debug_log(ep):
    line=ep["SrcLine"]
    uri=ep["uri"]
    verb=ep["method"]
    uri_params=ep["uri_params"]
    sf=ep["SFunction"]
    ep_s=f'{line } {verb} {uri} {sf} {uri_params}'
    write_log(ep_s)


def write_log(message):
    with open(log_file, "a", encoding="utf8") as rpt:
        now = datetime.now()
        dt = now.strftime('%Y-%m-%d %H:%M:%S')
        rpt.write(dt + ' ' + message + '\n')


def safe_str(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, (str, int, float, bool)):
        return str(x)
    try:
        return json.dumps(x, ensure_ascii=False)
    except Exception:
        return str(x)


def get_source_file_name(fname, analysis_root=None):
    root = analysis_root or input_srcdir
    relative_path = os.path.relpath(os.path.abspath(fname), start=root)
    return Path(relative_path).as_posix()


def format_endpoint(ep, current_module_name=None, analysis_root=None):
    protocol = ep.get("protocol", "http")
    surface = ep.get("surface", "server")
    interface_kind = (
        protocol
        if protocol != "http" or surface in {"", "server"}
        else f"{protocol}-{surface}"
    )
    return {
        "module_name": current_module_name or module_name,
        "interface_type": interface_kind + " " + ep["method"],
        "endpoint": ep["uri"],
        "source_file_name": get_source_file_name(ep["SrcFile"], analysis_root),
        "method_name": ep["SFunction"],
        "parameters": ep["uri_params"],
    }


def normalize_spring_regex_templates(path):
    """Drop bounded Spring ``{name:regex}`` constraints from a URI path.

    Regexes can contain their own brace quantifiers, so a flat regular
    expression cannot safely find the outer template delimiter.
    """

    value = str(path or "")
    output = []
    cursor = 0
    length = len(value)
    name_pattern = re.compile(r"[A-Za-z_$][\w$]*")
    while cursor < length:
        if value[cursor] != "{" or (cursor > 0 and value[cursor - 1] == "$"):
            output.append(value[cursor])
            cursor += 1
            continue
        name_match = name_pattern.match(value, cursor + 1)
        if name_match is None or name_match.end() >= length or value[name_match.end()] != ":":
            output.append(value[cursor])
            cursor += 1
            continue

        depth = 1
        escaped = False
        end = name_match.end() + 1
        while end < length:
            character = value[end]
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == "{":
                depth += 1
            elif character == "}":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        if depth != 0:
            output.append(value[cursor])
            cursor += 1
            continue
        output.append("{" + name_match.group(0) + "}")
        cursor = end + 1
    return "".join(output)


def normalize_endpoint_path(path, protocol="http"):
    """Apply endpoint-identity normalization shared with Noir's optimizer.

    Preserve non-path absolute URL authority delimiters, collapse repeated
    path separators, normalize Spring regex templates, and turn unresolved
    Spring placeholders into stable brace parameters.
    """

    value = normalize_spring_regex_templates(path)
    value = re.sub(
        r"\$\{([^{}]+)\}",
        lambda match: "{" + (
            re.findall(r"[A-Za-z_$][\w$]*", match.group(1)) or ["value"]
        )[-1] + "}",
        value,
    )
    value = re.sub(r"(?<!:)/{2,}", "/", value)
    if (
        protocol == "http"
        and value
        and not value.startswith("/")
        and not value.lower().startswith(("http://", "https://"))
    ):
        value = f"/{value}"
    return value


def deduplicate_and_sort_rows(rows, fieldnames=CSV_FIELDNAMES):
    unique = {}
    for row in rows:
        normalized = {
            field: "" if row.get(field) is None else safe_str(row.get(field))
            for field in fieldnames
        }
        interface = normalized.get("interface_type", "")
        protocol = interface.split(" ", 1)[0].split("-", 1)[0] or "http"
        normalized["endpoint"] = normalize_endpoint_path(
            normalized.get("endpoint", ""), protocol
        )
        key = tuple(normalized[field] for field in fieldnames)
        unique[key] = normalized
    return [unique[key] for key in sorted(unique)]


def write_csv(path: Path, fieldnames: List[str], rows: Iterable[Dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, delimiter=DELIM, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else safe_str(r.get(k))) for k in fieldnames})


def build_argument_parser():
    parser = argparse.ArgumentParser(
        description=(
            "Identify Java Spring Boot and JAX-RS HTTP endpoints from source "
            "with Tree-sitter"
        )
    )
    parser.add_argument(
        "--path",
        required=True,
        help="directory containing the application source code",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="path of the endpoint CSV file to create",
    )
    parser.add_argument(
        "--framework",
        choices=["spring", "jaxrx"],
        help="analyze only Spring or JAX-RS; omit to run both analyzers",
    )
    return parser


def is_ignored_source_file(file_path, analysis_root=None):
    root = analysis_root or input_srcdir
    relative_path = Path(os.path.relpath(file_path, start=root))
    return any(directory in IGNORED_DIRS for directory in relative_path.parts[:-1])


def discover_java_files(analysis_root):
    discovered = []
    for current_root, directory_names, file_names in os.walk(analysis_root):
        directory_names[:] = sorted(
            directory for directory in directory_names if directory not in IGNORED_DIRS
        )
        for file_name in sorted(file_names):
            if file_name.lower().endswith(".java"):
                discovered.append(os.path.join(current_root, file_name))
    return sorted(
        discovered,
        key=lambda file_name: get_source_file_name(file_name, analysis_root),
    )


def analyze_module(analysis_root, framework=None):
    require_tree_sitter()
    selected = {framework} if framework else {"spring", "jaxrx"}
    java_files = discover_java_files(analysis_root)
    source_by_file = {}
    for file_name in java_files:
        with open(file_name, "rb") as source_file:
            source_by_file[file_name] = source_file.read()
    endpoints = []
    workspace_runtime = build_jax_runtime()
    java_workspace = build_jax_workspace(
        source_by_file,
        runtime=workspace_runtime,
        include_jax="jaxrx" in selected,
    )
    if "jaxrx" in selected:
        build_jax_deployment_configuration(
            java_workspace, analysis_root, sys.modules[__name__]
        )

    spring_runtime = build_spring_runtime() if "spring" in selected else None
    if "spring" in selected:
        print("Found SpringBoot Annotation")
        spring_endpoints = []
        for file_name in java_files:
            spring_endpoints.extend(
                SpringBoot_Analyzer(
                    file_name,
                    source_by_file[file_name],
                    runtime=spring_runtime,
                    workspace=java_workspace,
                )
            )
        if java_workspace.get("units"):
            spring_endpoints.extend(
                analyze_spring_recall(java_workspace, sys.modules[__name__])
            )
            spring_endpoints.extend(
                analyze_spring_hierarchy(java_workspace, sys.modules[__name__])
            )
            spring_endpoints.extend(
                analyze_spring_gateway(java_workspace, sys.modules[__name__])
            )
            spring_endpoints.extend(
                analyze_spring_resource_handlers(
                    java_workspace, sys.modules[__name__]
                )
            )
            spring_endpoints.extend(
                analyze_spring_clients(java_workspace, sys.modules[__name__])
            )
            spring_configuration = build_spring_configuration(
                java_workspace, analysis_root, sys.modules[__name__]
            )
            spring_endpoints.extend(
                analyze_spring_websocket(
                    java_workspace,
                    sys.modules[__name__],
                    spring_configuration,
                )
            )
            spring_endpoints = apply_spring_configuration(
                spring_endpoints, spring_configuration, sys.modules[__name__]
            )
        endpoints.extend(spring_endpoints)

    if "jaxrx" in selected:
        print("Found JaxRS")
        for file_name in java_files:
            endpoints.extend(
                JaxRS_Analyzer(
                    file_name,
                    source_by_file[file_name],
                    runtime=workspace_runtime,
                    workspace=java_workspace,
                )
            )
        if java_workspace.get("units"):
            endpoints.extend(
                analyze_jax_recall(java_workspace, sys.modules[__name__])
            )
            endpoints.extend(
                analyze_jax_websocket(java_workspace, sys.modules[__name__])
            )

    return endpoints


def main(argv=None):
    global input_srcdir, module_name, log_file

    argument_parser = build_argument_parser()
    args = argument_parser.parse_args(argv)
    input_path = Path(args.path).expanduser().resolve()
    if not input_path.is_dir():
        argument_parser.error("--path must be an existing directory")

    input_srcdir = str(input_path)
    module_name = input_path.name
    output_path = Path(args.output).expanduser()
    log_file = f"{output_path}.log"
    with open(log_file, "w", encoding="utf8"):
        pass

    write_log(
        f"Framework mode: {args.framework}"
        if args.framework
        else "Framework mode: spring and jaxrx"
    )
    try:
        endpoints = analyze_module(input_srcdir, args.framework)
    except RuntimeError as error:
        argument_parser.error(str(error))

    formatted_rows = [
        format_endpoint(endpoint, module_name, input_srcdir)
        for endpoint in endpoints
    ]
    rows = deduplicate_and_sort_rows(formatted_rows)
    write_csv(output_path, CSV_FIELDNAMES, rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
