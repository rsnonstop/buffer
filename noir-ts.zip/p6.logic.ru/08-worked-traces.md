# 08 — Разобранные сквозные трассировки

[← Output и evidence](07-output-evidence-reports.md) · [Оглавление](README.md) · [Далее: Production-использование →](09-production-use.md)

В этих трассировках source evidence проходит через текущий native package flow:
единый Java workspace, типизированные значения `EndpointFact`, конфигурацию Spring,
public projection, объединение evidence и отчёты. Имена файлов и номера строк
приведены для примера; решения соответствуют реализации.

## Координаты в коде

| Трассировка | Начните здесь | Важные downstream-владельцы |
|---|---|---|
| A — прямой Spring | [`noir.spring_mvc`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` | [`noir.spring_config`](../src/noir/spring_config.py) :: `apply_spring_path_configuration()`; [`noir.output`](../src/noir/output.py) :: `normalize_endpoint_path()` |
| B — унаследованный Spring | [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) :: `analyze_spring_mvc_hierarchy()` | [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) :: `JavaSourceHierarchyGraph`; типизированный evidence в [`noir.evidence`](../src/noir/evidence.py) |
| C — условия методов | [`noir.spring_mvc`](../src/noir/spring_mvc.py) :: `union_request_method_conditions()` | `ordered_http_methods()` и fan-out прямых facts |
| D — JAX-RS deployment и locator | [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) :: `build_jax_rs_deployment_model()` | `select_jax_rs_deployment_prefix()`; [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) :: `analyze_jax_rs_hierarchy_and_subresources()` |
| E — поверхности Spring | [`noir.spring_framework`](../src/noir/spring_framework.py) :: `analyze_spring_framework()` | анализаторы client, configuration, WebSocket и messaging |
| F — первая mapping некорректна | [`noir.spring_mvc`](../src/noir/spring_mvc.py) :: `first_spring_mapping()` | декодирование built-in/composed и diagnostics в рамках run |
| G — сходящиеся producers | [`noir.output`](../src/noir/output.py) :: `consolidate_endpoint_rows()` | объединение annotation evidence и represented target |
| H — неполное покрытие | [`noir.inventory`](../src/noir/inventory.py) :: `build_final_trigger_inventory()` | [`noir.reports`](../src/noir/reports.py) :: `render_annotations_without_endpoints_report_bytes()` |

## 1. Прямой Spring MVC: конфигурация и public-нормализация

Предположим, корень анализа называется `shop`:

~~~properties
# src/main/resources/application.properties
server.servlet.context-path=/edge
routes.api=/v1
~~~

~~~java
package demo;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("${routes.api}/orders")
class OrderController {
    @GetMapping({"/{id:[0-9]{1,3}}", "/latest"})
    Object get(String id) { return null; }
}
~~~

`run_analysis()` строит для этого файла одну compilation unit. Выбранный facade
`spring_framework` вызывает
`analyze_direct_spring_mvc_unit(unit, workspace)`, который доказывает identity
mapping'ов и выдаёт два типизированных facts:

~~~text
GET /${routes.api}/orders/{id:[0-9]{1,3}}
GET /${routes.api}/orders/latest
~~~

Каждый fact связывает handler с `OrderController.get`, сохраняет исходное
написание параметра `String id` и несёт типизированный annotation evidence и
represented-target evidence. Для route eligibility прямому pass не требуется
`@RestController`.

`build_spring_path_configuration()` читает поддерживаемые properties принадлежащего
проекта, а `apply_spring_path_configuration()` разрешает placeholder и добавляет
в начало inbound server base:

~~~text
/edge/v1/orders/{id:[0-9]{1,3}}
/edge/v1/orders/latest
~~~

На public-границе `consolidate_endpoint_rows()` вызывает
`normalize_endpoint_path()`. Сбалансированное Spring regex-ограничение удаляется,
но имя переменной сохраняется:

~~~text
/edge/v1/orders/{id}
/edge/v1/orders/latest
~~~

Концептуально результат выглядит так:

~~~csv
module_name;interface_type;endpoint;source_file_name;method_name;parameters;method_annotation_line
shop;http GET;/edge/v1/orders/latest;src/main/java/demo/OrderController.java;OrderController.get;String id;<GetMapping line>
shop;http GET;/edge/v1/orders/{id};src/main/java/demo/OrderController.java;OrderController.get;String id;<GetMapping line>
~~~

Diagnostic log включает распознанные endpoint-trigger annotations. Final-trigger report
не перечисляет mapping trigger этого метода, поскольку сохранившаяся строка
представляет именно этот method target.

## 2. Spring mapping, унаследованная от interface

~~~java
// ApiContract.java
package demo;

import org.springframework.web.bind.annotation.*;

@RequestMapping("/contract")
public interface ApiContract {
    @GetMapping("/ping")
    String ping();
}
~~~

~~~java
// ApiController.java
package demo;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ApiController implements ApiContract {
    @Override
    public String ping() { return "ok"; }
}
~~~

Прямой pass не выдаёт ни одной из деклараций: у concrete method нет direct
mapping, а interface method не является concrete handler. Затем hierarchy pass:

1. доказывает наличие одного concrete controller и полного source hierarchy;
2. сопоставляет `ping()` по erased signature;
3. выбирает interface contract, поскольку ни одна более близкая method mapping не получает приоритета;
4. составляет `/api`, `/contract` и `/ping`.

Итоговый path — `/api/contract/ping`.

Владельцы route и handler различаются:

~~~mermaid
flowchart LR
    CONTRACT["ApiContract.java<br/>декларация route"] --> FACT["EndpointFact"]
    HANDLER["ApiController.java<br/>декларация handler"] --> FACT
    FACT --> CSV["source в CSV: ApiController.java"]
    FACT --> LINE["method_annotation_line: пусто"]
~~~

Public annotation line пуста, поскольку route annotation и handler находятся
в разных файлах. Represented target — concrete implementation method, поэтому
interface trigger всё ещё может появиться в final-trigger report. Это намеренная
source attribution, а не доказательство отсутствия annotation у route.

## 3. Объединение условий request method в Spring

~~~java
@RequestMapping(path = "/reports", method = RequestMethod.GET)
class ReportController {
    @RequestMapping(path = "/daily", method = RequestMethod.POST)
    Object daily() { return null; }
}
~~~

`union_request_method_conditions()` моделирует request conditions типа и метода
как упорядоченное объединение, а не как runtime-пересечение. Поэтому он выдаёт:

~~~text
GET  /reports/daily
POST /reports/daily
~~~

Это намеренная статическая аппроксимация и важный источник возможных строк,
существующих только в static view, при production reconciliation.

## 4. Override JAX-RS через `web.xml` и обход subresource

Source объявляет `/from-java`:

~~~java
@ApplicationPath("/from-java")
public class ApiApplication extends jakarta.ws.rs.core.Application {}
~~~

Принадлежащий ему descriptor явно связывает это application с `/rest/*`:

~~~xml
<web-app>
  <servlet>
    <servlet-name>jax</servlet-name>
    <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
    <init-param>
      <param-name>jakarta.ws.rs.Application</param-name>
      <param-value>demo.api.ApiApplication</param-value>
    </init-param>
  </servlet>
  <servlet-mapping>
    <servlet-name>jax</servlet-name>
    <url-pattern>/rest/*</url-pattern>
  </servlet-mapping>
</web-app>
~~~

Resources используют locator:

~~~java
@Path("/root")
public class Root {
    @Path("/accounts")
    public AccountResource accounts() { return new AccountResource(); }
}
~~~

~~~java
@Path("/standalone")
public class AccountResource {
    @GET
    @Path("/{id}")
    public Object get(String id) { return null; }
}
~~~

Явная XML-связь делает `/rest` deployment prefix для этого application.
У `Root.accounts` есть path, но нет request designator, поэтому это locator.
Traversal доказывает его точный concrete source return type и составляет:

~~~text
/rest + /root + /accounts + /{id}
= /rest/root/accounts/{id}
~~~

Path целевого типа `/standalone` намеренно не вставляется в locator chain.
Его собственный direct root остаётся независимым, поэтому прямой pass может
также создать `/rest/standalone/{id}`. Locator row связывается с
`AccountResource.get`, а строка `@GET` из того же файла подходит для CSV.

## 5. Домены Spring path не используют одно общее правило rewrite

При:

~~~properties
server.servlet.context-path=/edge
inventory.base=https://inventory.example
~~~

и broker application prefix `/app` четыре raw facts разрешаются по-разному:

| Fact | Итоговый path | Правило |
|---|---|---|
| inbound MVC `/orders` | `/edge/orders` | inbound HTTP получает server base |
| outbound client `${inventory.base}/items` | `https://inventory.example/items` | побеждает разрешённый absolute URL; server base не добавляется |
| WebSocket handshake `/socket` | `/edge/socket` | path HTTP upgrade получает server base |
| message destination `/refresh` | `/app/refresh` | broker application prefix; servlet base не добавляется |

Их public interface types остаются различными: `http ...`, `http-client ...`,
`ws GET` и `ws SEND`.

## 6. Первая распознанная Spring mapping некорректна

~~~java
class ProblemController {
    @GetMapping(dynamicPath())
    @PostMapping("/apparently-safe")
    Object run() { return null; }
}
~~~

`first_spring_mapping()` выбирает первую распознанную mapping в порядке source.
Static string evaluator не может разрешить `dynamicPath()`, поэтому распознанный
результат некорректен. Более поздняя `@PostMapping` не используется как fallback.

~~~mermaid
flowchart TD
    START["annotations в порядке source"] --> FIRST["первая распознанная: GetMapping"]
    FIRST --> RESOLVE{"path полностью разрешён?"}
    RESOLVE -- нет --> STOP["отклонить этот method candidate"]
    STOP --> DIAG["записать diagnostic"]
    STOP --> ABSENT["trigger target остаётся непредставленным"]
~~~

Поскольку ни один сохранившийся fact не представляет метод, оба вхождения trigger
могут появиться в final-trigger report. Вычитание выполняется по точному source
target, а не по написанию path или имени annotation.

## 7. Два producer path сходятся

~~~java
@Path("")
class Root {
    @Path("")
    public Leaf leaf() { return new Leaf(); }
}

@Path("")
class Leaf {
    @GET @Path("/same")
    public Object same() { return null; }
}
~~~

Прямой JAX-RS pass и locator traversal могут создать одинаковую public identity
для `Leaf.same`. Каждый analyzer выдаёт `EndpointFact`; projection создаёт два
значения `EndpointRowCandidate`. `consolidate_endpoint_rows()` группирует по
нормализованным первым шести полям CSV, затем объединяет типизированный annotation
evidence и represented targets перед выбором седьмого поля.

В результате остаётся одна строка, строка `@GET` сохраняется, а каждый допустимый
represented target из обоих candidates участвует в final-trigger subtraction.

## 8. Успешное завершение не означает полного runtime-покрытия

Предположим, source tree содержит десять принятых routes, а также:

- functional route за неподдерживаемым control flow;
- mapping, константу которой невозможно разрешить;
- custom annotation, определённую только в dependency;
- locator с динамическим runtime target type.

Run всё равно может опубликовать десять строк и вернуть status 0. Локальная для
candidate неоднозначность или неподдерживаемый синтаксис обычно отклоняет только
эту ветвь.

~~~text
exit 0 = analysis completed and requested artifacts were published
exit 0 ≠ every runtime endpoint was understood
~~~

Поэтому production review рассматривает CSV, diagnostics, final-trigger report,
предположения о source root и независимый build/runtime view.

Далее: [09 — Production-использование и контроль рисков](09-production-use.md).
