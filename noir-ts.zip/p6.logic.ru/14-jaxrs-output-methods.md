# 14 — От JAX-RS до artifacts: atlas логики на уровне методов

[← Методы Spring](13-spring-methods.md) · [Оглавление](README.md) ·
[Поиск методов →](15-method-lookup.md)

Эта глава дополняет module-level views из
[06 — JAX-RS и Java WebSocket](06-jax-rs.md) и
[07 — Output, evidence и reports](07-output-evidence-reports.md). Она следует
текущей реализации от passes JAX-RS/WebSocket до отдельных методов принятия
решений, а затем проводит их данные через validation evidence, consolidation,
rendering CSV/log и опциональное сравнение Noir.

Авторитетным источником служит source-код. Координата вида
[`src/noir/jaxrs.py`](../src/noir/jaxrs.py) ::
`resolve_jax_rs_request_designator()` означает: откройте этот файл и найдите
точный symbol. Private helpers включены, когда они владеют правилом ambiguity,
failure boundary, построением fact/evidence, recursion, validation или решением
publication.

## 1. Call graph сверху вниз

Запрошенные modules не владеют самой внешней orchestration. Их callers в
`noir.pipeline` и `noir.cli` показаны, чтобы не скрывать entry- и exit-edges.

```mermaid
flowchart TD
    CLI["cli.run_cli"] --> APP["application.analyze"]
    APP --> RUN["pipeline.run_analysis"]
    RUN --> WS["построить общий Java workspace"]
    RUN --> REG["framework registry"]
    REG -->|"JAX-RS выбран"| JI["jaxrs.build_jaxrs_state"]
    WS --> JI
    JI --> STATE["private JaxRsState"]
    JI --> CDI["index_jax_rs_custom_designators"]
    JI --> API["index_jax_rs_application_paths"]

    RUN --> BROAD["inventory.build_annotation_audit_inventory"]
    RUN -->|"выбрано хотя бы одно семейство"| TRIG["inventory.build_final_trigger_inventory"]
    RUN -->|"подготовить выбранные adapter'ы"| PREP["jaxrs_framework.prepare_jaxrs_analysis"]
    PREP --> DEP["jaxrs_deployment.build_jax_rs_deployment_model"]

    RUN -->|"анализировать выбранные adapter'ы"| JPASS["jaxrs_framework.analyze_jaxrs_framework"]
    JPASS --> DIRECT["jaxrs.analyze_direct_jax_rs_unit<br/>один раз для unit"]
    JPASS --> HIER["jaxrs_hierarchy.analyze_jax_rs_hierarchy_and_subresources<br/>один раз для workspace"]
    JPASS --> SOCK["java_websocket.analyze_java_websocket_endpoints<br/>один раз для workspace"]
    DIRECT --> FACT["EndpointFact"]
    HIER --> FACT
    SOCK --> FACT

    FACT --> RESULT["AnalysisResult.endpoints"]
    RESULT --> PROJECT["output.endpoint_fact_to_row_candidate<br/>один для каждого fact"]
    PROJECT --> CAND["EndpointRowCandidate"]
    CAND --> CONS["output.consolidate_endpoint_rows"]
    CONS --> FINAL["ConsolidatedEndpoints"]

    FINAL --> CSV["output.write_endpoint_csv"]
    TRIG --> LOGINV["reports.trigger_annotation_log_inventory"]
    LOGINV --> LOG["reports.write_annotation_diagnostic_log"]
    DIAG["строки rendered из bound DiagnosticCollector"] --> LOG
    TRIG --> ABSENT["reports.render_annotations_without_endpoints_report_bytes"]
    FINAL -->|"represented_targets"| ABSENT
    TRIG -->|"comparison включено"| COMP["comparison.compare_final_trigger_inventory"]
    NOIR["Locations из Noir v1.1 JSON"] --> COMP
    COMP --> CRENDER["comparison.render_noir_comparison_report_bytes"]
    ABSENT --> APUB["reports.publish_bytes_atomically"]
    CRENDER --> CPUB["reports.publish_bytes_atomically"]
```

Порядок внутри `pipeline.run_analysis()` имеет значение:

1. Строится нейтральный `JavaWorkspace`, затем выбранные adapter'ы создают
   отдельный family state. JAX-RS возвращает `JaxRsState`; family keys не
   добавляются в workspace, а невыбранные adapter'ы не получают setup callback.
2. Annotation-audit inventory всегда строится до endpoint analyzers.
   Final-trigger inventory также строится тогда же, если выбрано хотя бы одно
   семейство framework; если не выбрано ни одного, это пустой tuple. Оба
   описывают source evidence, а не успех analyzer.
3. Каждый выбранный adapter выполняет preparation до запуска любого выбранного
   analyzer'а. В этой фазе preparation hook JAX-RS устанавливает
   `state.deployment_model`.
4. Direct facts JAX-RS собираются в порядке source snapshot; затем по одному
   разу добавляются hierarchy facts и WebSocket facts.
5. `AnalysisResult` переходит в CLI, где все facts проходят projection и
   глобальную consolidation до открытия artifact для endpoint output.

## 2. Data contracts, проходящие по графу

| Значение | Кем создаётся | Кем потребляется | Contract, важный downstream |
|---|---|---|---|
| общий mapping `JavaWorkspace` | `java_workspace.build_java_workspace()` | inventories и каждый analyzer | Typed dictionary schema содержит только нейтральные Java facts; все compilation units используются повторно. |
| `JaxRsState` | `build_jaxrs_state(workspace)` | JAX-RS classifiers, preparation, direct analysis и hierarchy | Новый family state передаётся явно, отдельно от общих Java facts. |
| `state.custom_designators` | `index_jax_rs_custom_designators()` | direct/hierarchy resolution designator и inventories | Runtime records в форме деклараций сохраняются по FQN; дублирующиеся declarations остаются несколькими records, чтобы use-site resolution мог их отклонить. |
| `state.applications` | `index_jax_rs_application_paths()` | deployment builder и fallback selector без model | Record может намеренно содержать `path=None`, сохраняя ambiguity. |
| `state.deployment_model` | `build_jax_rs_deployment_model()` | `resolve_jax_rs_resource_prefix()` | Prefixes индексируются по project, package application и namespace Javax/Jakarta. |
| broad annotation inventory | `build_annotation_audit_inventory(workspace, analysis_root, recognizers)` | внутренние audit consumers через `AnalysisResult` | Включает поддерживаемые framework annotations, даже когда они не являются endpoint triggers. |
| final-trigger inventory | `build_final_trigger_inventory(workspace, analysis_root, recognizers)` | log annotations/diagnostics, report annotations-without-endpoints и опциональное сравнение Noir | Включает только поддерживаемые placements triggers и несёт точную identity `SourceTarget` вместе с byte spans аннотаций. |
| `EndpointFact` | direct, hierarchy, WebSocket и другие analyzers | `endpoint_fact_to_row_candidate()` | Богатый immutable fact; scalar route data и две типизированные коллекции provenance остаются разделены. |
| `AnnotationEvidence` | `make_method_annotation_evidence()` и helpers node/mapping | merge evidence и выбор значения для седьмой column | Same-file, positive-line, canonical identity annotation с доверенным family. |
| `SourceTarget` | `make_source_target()` и его node helper | merge evidence и subtraction annotations-without-endpoints | Canonical file + kind declaration + непустой полуоткрытый byte span. |
| `EndpointRowCandidate` | `endpoint_fact_to_row_candidate()` | `consolidate_endpoint_rows()` | Шесть public identity values вместе с private owned evidence. |
| `ConsolidatedEndpoints` | `consolidate_endpoint_rows()` | writer CSV и renderer annotations-without-endpoints | Замороженные public rows вместе с union targets, представленных surviving groups. |
| `AnnotationComparison` | `compare_final_trigger_inventory()` | renderer comparison report | Точное partition occurrences потенциальных trigger'ов по canonical `(source file, line)`, а не по reachability endpoint'а. |

Два потока evidence намеренно идут рядом:

```mermaid
flowchart LR
    A["node annotation request-method"] --> ME["AnnotationEvidence<br/>file + line + identity + family"]
    D["node представленной Java declaration"] --> ST["SourceTarget<br/>file + kind + byte span"]
    ME --> EF["EndpointFact"]
    ST --> EF
    EF --> RC["EndpointRowCandidate"]
    RC --> GROUP["consolidation по шести полям"]
    GROUP --> PICK["select_method_annotation_evidence"]
    PICK --> LINE["method_annotation_line"]
    GROUP --> UNION["merge_represented_targets"]
    UNION --> SUB["вычесть из final-trigger inventory"]
```

`source_line` в `EndpointFact` — diagnostic context. Он не становится
автоматически annotation line в CSV. Аналогично, annotation line не является
identity декларации и не может подавить entry в report
annotations-without-endpoints.

## 3. Direct-методы JAX-RS

Владелец: [`src/noir/jaxrs.py`](../src/noir/jaxrs.py).

### 3.1 Подготовка index

```mermaid
flowchart TD
    BUILD["build_jaxrs_state(workspace)"] --> CUSTOM["index_jax_rs_custom_designators"]
    BUILD --> APPS["index_jax_rs_application_paths"]
    CUSTOM --> DHTTP["decode_custom_http_method"]
    CUSTOM --> RUNTIME["retention_is_runtime"]
    APPS --> NS["resolve_direct_jax_rs_application_namespace"]
    APPS --> PATH["decode_jax_rs_path_annotation"]
    CUSTOM --> STATE["новый JaxRsState"]
    APPS --> STATE
```

`build_jaxrs_state(workspace)` — entry point выбранного семейства. Он читает
нейтральные Java facts и возвращает новый `JaxRsState` с indexes custom
designator и application. Невыбранное семейство не создаёт state. Inventory
получает callbacks, уже связанные с выбранным state; direct и hierarchy
analyzers явно требуют `state=`.

`index_jax_rs_custom_designators(workspace)` обходит metadata candidates для
объявленных в source annotations и возвращает два indexes. Candidate set
становится `state.custom_designator_candidates`; этот poison set позволяет
некорректной или ambiguous declaration оставаться релевантной при последующем
применении. Mapping валидных records становится `state.custom_designators`,
принимая record только после успешной проверки ровно одного genuine
`@HttpMethod`, ровно одного runtime `@Retention`, статически разрешённого value,
ограничения 128 characters и `HTTP_METHOD_TOKEN`.

`index_jax_rs_application_paths(workspace)` обходит class declarations с genuine
`@ApplicationPath`. Abstract classes исключаются. Множественные genuine
annotations диагностируются и сохраняются как одна record с `path=None` на
каждую genuine annotation, содержащую namespace этой annotation, без выбора
между ними по identity superclass. При наличии ровно одной annotation сам class
должен быть matching direct subclass core `Application`; несовпадающие и
indirect shapes исключаются. Unresolved value при такой valid shape создаёт
`path=None`, не позволяя последующему selector принять uncertainty за absence.

### 3.2 Одна direct unit

```mermaid
flowchart TD
    ENTRY["analyze_direct_jax_rs_unit(unit, workspace, state=state)"] --> ROOTS["resolve_jax_rs_resource_root<br/>для видимых concrete classes/records"]
    ROOTS --> METHODS["перебрать method_candidates"]
    METHODS --> DES["resolve_jax_rs_request_designator"]
    DES --> PUB["method_is_public"]
    PUB --> MPATH["resolve_jax_rs_method_path"]
    MPATH --> PREFIX["resolve_jax_rs_resource_prefix"]
    PREFIX --> JOIN["объединить deployment + root + method paths"]
    JOIN --> EVID["method_annotation_evidence_from_node<br/>represented_target_evidence"]
    EVID --> FACT["EndpointFact + diagnostic"]

    ROOTS --> COMPONENTS["перебрать record_component_candidates"]
    COMPONENTS --> SELECT["select_jax_rs_accessor_annotations"]
    SELECT --> DES
    COMPONENTS --> EXPLICIT["пропустить explicit accessor"]
```

У entry point два loop:

- Loop объявленных methods требует один designator, явный `public`, опциональный
  valid same-family method path и одно решение deployment-prefix. Он выдаёт
  method annotation evidence и represented method target.
- Loop record components моделирует implicit accessor без arguments, только
  когда его не скрывает explicit accessor. Участвуют component annotations,
  применимые к method. Он выдаёт represented record-component target, но не
  method annotation evidence, поскольку физически annotation находится не на method.

Каждый успешный fact имеет `technology="jax-rs"`, `direction="inbound"`;
HTTP server values берутся из defaults `EndpointFact`. Handler и public source
принадлежат concrete method/accessor. Функция возвращает immutable tuple и
записывает один endpoint diagnostic на каждый выданный fact.

### 3.3 Контракты symbols direct-методов

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `log_jax_rs_skip()` | Форматирует один owner-scoped fail-closed diagnostic и передаёт его collector'у diagnostics, привязанному к run. Не возбуждает исключение и не записывает файл. |
| `decode_jax_rs_path_annotation()` | Принимает одну уже доказанную record семейства `Path`, требует форму с одним value, разрешает Java string в правильном owner constant и возвращает layer с leading slash. Возвращает `None` и диагностирует malformed/unresolved values. |
| `resolve_direct_jax_rs_application_namespace()` | Читает ровно один direct superclass и разрешает core type `Application`. Возвращает `jakarta.ws.rs`/`javax.ws.rs`, иначе `None`. |
| `decode_custom_http_method()` | Разрешает value custom `@HttpMethod`, включая ограниченные static constants; возвращает token, только если его длина не превышает 128 characters и он соответствует `HTTP_METHOD_TOKEN`. |
| `index_jax_rs_custom_designators()` | Возвращает candidate poison set и описанный выше record index без изменения Java facts. Records хранятся в per-FQN lists; use-site resolution требует одну source declaration и одну record, поэтому дублирующиеся FQN обрабатываются по принципу fail-closed. |
| `select_jax_rs_accessor_annotations()` | Фильтрует annotations record component до стандартных JAX route annotations или source annotations с доказанной применимостью к methods. |
| `resolve_custom_designator()` | Разрешает применённое имя по candidates из явного `state` и нейтральной source accessibility. Возвращает mapping, чей `status` равен точно `none`, `resolved`, `invalid` или `ambiguous`; record присутствует только при статусе `resolved`. |
| `index_jax_rs_application_paths()` | Возвращает source application records для `state.applications`; сохраняет выбранные invalid path records, чтобы перенести uncertainty в selection prefix. |
| `package_is_ancestor()` | Реализует владение package: пустой ancestor, точный package или dotted prefix. Используется fallback selector, когда `state.deployment_model` равен `None`. |
| `package_specificity()` | Подсчитывает segments package, чтобы fallback selector мог сохранить самый глубокий owning application package. |
| `resolve_jax_rs_resource_prefix(unit, namespace, owner_name, *, state)` | Использует `state.deployment_model`, если он есть. Его fallback фильтрует same-family applications, предпочитает most-specific package ownership, требует agreement, возвращает `""` при доказанном absence и `None` при диагностированной ambiguity. |
| `method_is_public()` | Реализует gate явного `public` для direct pass из modifiers method; правила inherited implementation находятся в другом месте. |
| `resolve_jax_rs_resource_root()` | Требует ровно один genuine type `@Path`, декодирует его и возвращает `{path, namespace}`. Отсутствие path означает «не root»; invalid или multiple path evidence диагностируется и также возвращает `None`. |
| `resolve_jax_rs_request_designator()` | Сканирует все records method/component, обращаясь к custom records через обязательный `state=`. Он принимает не более одного marker-shaped standard или valid source custom designator в namespace root. Любой релевантный invalid/mixed designator отравляет весь selection; несколько valid designators также приводят к отклонению. |
| `resolve_jax_rs_method_path()` | Возвращает `""` при отсутствии, один decoded path при unique same-family или `None` после ambiguity/mixed/value failure. |
| `analyze_direct_jax_rs_unit(unit, workspace, *, state)` | Оркестрирует оба direct loops и является единственной функцией в этом module, которая строит endpoint facts. |
| `JaxRsState` | Отдельный mutable family state: identities custom candidates, validated custom records, source applications и необязательная подготовленная deployment model. |
| `build_jaxrs_state(workspace)` | Возвращает новые family indexes: сначала custom designators, затем application paths. Не изменяет Java facts и не разбирает source повторно. |

## 4. Методы deployment prefix

Владелец: [`src/noir/jaxrs_deployment.py`](../src/noir/jaxrs_deployment.py).

### 4.1 Построение model и lookup

```mermaid
flowchart TD
    BUILD["build_jax_rs_deployment_model"] --> COALESCE["_coalesce_source_application_prefixes"]
    BUILD --> CLASSIDX["_index_source_applications_by_class_name"]
    BUILD --> DISCOVER["discover_web_xml_files"]
    DISCOVER --> PROJECT["infer_jax_rs_project_root"]
    BUILD --> PARSE["parse_jax_rs_web_xml_mappings"]
    PARSE --> PRED["предикаты servlet/application"]
    BUILD --> KEYS["_resolve_mapping_application_keys"]
    BUILD --> NORMAL["normalize_servlet_mapping_prefix"]
    BUILD --> OVERLAY["explicit mappings переопределяют source paths"]
    OVERLAY --> MODEL["возвращаемая deployment model"]
    MODEL --> STATE["prepare_jaxrs_analysis сохраняет state.deployment_model"]
    MODEL --> SELECT["select_jax_rs_deployment_prefix"]
```

`build_jax_rs_deployment_model(applications, analysis_root)` начинает с
переданных source application records,
объединяет каждый key `(project root, package, namespace)`, а затем накладывает
ограниченные mappings `web.xml`. Конфликтующие source paths или explicit
mappings представлены как `None`. Единственный unassociated распознаваемый
servlet prefix может заполнить source application keys только в своём project,
если он однозначен и ни один application key в этом project не configured явно.

`select_jax_rs_deployment_prefix()` связывает одну resource unit с её inferred
project, совместимым namespace и ancestor application package. Он сохраняет
самый глубокий package. На одинаковой глубине он предпочитает explicit XML
evidence, иначе — точный namespace вместо namespace-neutral inference.
Возвращается один согласованный non-null path; ambiguity возвращает `None` с
diagnostic. При отсутствии matching candidate обычно возвращается `""`, с одним
строго ограниченным fallback для нестандартного layout.

### 4.2 Контракты symbols deployment

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `_absolute_path()` | Привязывает relative descriptor/source path к explicit analysis root и нормализует absolute spelling. |
| `infer_jax_rs_project_root()` | Находит ancestor непосредственно перед моделируемым marker `src/main/...`; иначе возвращает нормализованный analysis root. |
| `discover_web_xml_files()` | Детерминированно обходит analysis root, отсекает ignored и non-production source trees и возвращает sorted regular nonsymlink файлы `web.xml` размером не более `MAX_WEB_XML_BYTES`. Ошибки filesystem probe исключают candidates. |
| `_local_name()` | Удаляет XML namespace или написание prefix перед сравнением tags. |
| `_children()` | Выбирает direct XML children по local name без namespace. |
| `_child_text()` | Возвращает normalized text первого matching direct child или `""`. |
| `is_jax_rs_servlet_class()` | Применяет ограниченный registry написаний Jersey/RESTEasy/CXF/servlet-class. Это recognition evidence, а не общий servlet inference. |
| `is_jax_rs_application_class_name()` | Распознаёт написания core или application-like class, используемые ограниченной association descriptor. |
| `infer_application_package_from_class_name()` | Возвращает package только для non-core, nonservlet, application-like qualified class name. |
| `normalize_servlet_mapping_prefix()` | Сначала удаляет завершающий `/*`, затем не-root завершающий slash и при необходимости добавляет leading slash. Поэтому literal `/` превращается в `""`, а literal `/*` — в `/`; это упорядоченное правило является частью текущего contract. |
| `parse_jax_rs_web_xml_mappings()` | Парсит direct servlet declarations/init params и servlet mappings. Возвращает raw records pattern/application-class/recognition JAX-RS; malformed XML передаётся caller как исключение. |
| `_application_key()` | Создаёт source key `(project root, package, namespace)`. |
| `_has_project_marker()` | Определяет, содержит ли сам path какой-либо modeled marker стандартного layout; используется для защиты nonstandard fallback. |
| `_coalesce_source_application_prefixes()` | Группирует indexed source applications и возвращает один path, только когда каждый member разрешён и все согласны; иначе сохраняет `None`. |
| `_index_source_applications_by_class_name()` | Отображает и simple, и FQN application names в sorted exact source keys. |
| `_resolve_mapping_application_keys()` | Предпочитает project-local exact matches source class; иначе получает project/package/namespace-neutral keys из dependency-like application names. |
| `build_jax_rs_deployment_model()` | Читает ограниченные descriptors, диагностирует unreadable/malformed XML, накладывает prefixes и возвращает deployment model facade'у для хранения в JAX-RS state. Не создаёт endpoints. |
| `_package_is_ancestor()` | Private typed-эквивалент predicate владения package из JAX module. |
| `_package_specificity()` | Private typed ranker глубины package, используемый model selector. |
| `select_jax_rs_deployment_prefix()` | Выполняет selection project/package/namespace/evidence-priority и различает absent `""` и ambiguous `None`. |

Экспортируемые data contracts этого module: `PROJECT_MARKERS`,
`APPLICATION_INIT_PARAMS`, `CORE_APPLICATION_CLASSES` и
`MAX_WEB_XML_BYTES`. Изменение любого из них меняет scope discovery или
descriptor proof, а не только presentation.

## 5. Методы hierarchy и subresource

Владелец: [`src/noir/jaxrs_hierarchy.py`](../src/noir/jaxrs_hierarchy.py).
Framework-neutral inheritance, generic adaptation, erased signatures и выбор
maximally specific interface делегированы superclass'у, определённому в
`noir.java_hierarchy`; приведённые ниже symbols отвечают за layer JAX-RS.

### 5.1 Граф effective method и recursive locator

```mermaid
flowchart TD
    WRAP["analyze_jax_rs_hierarchy_and_subresources"] --> INIT["JaxRsHierarchyAnalyzer.__init__"]
    INIT --> ROUTES["analyze_jax_rs_routes"]
    ROUTES --> ROOT["resolve_jax_rs_resource_root"]
    ROOT --> PREFIX["resolve_jax_rs_resource_prefix"]
    PREFIX --> WALK["_collect_subresource_endpoints"]

    WALK --> EFFECTIVE["_resolve_effective_jax_rs_methods"]
    EFFECTIVE --> SOURCE["_select_jax_rs_annotation_source"]
    SOURCE --> BIND["_decode_jax_rs_method_binding"]
    BIND --> CLASSIFY["_classify_jax_rs_annotation<br/>_standard_jax_annotation_family"]
    WALK --> IPATH["_resolve_interface_contract_path"]
    WALK --> LEAF{"leaf или locator?"}
    LEAF -->|leaf достигнут через hierarchy/locator| FACT["_build_recalled_endpoint"]
    LEAF -->|locator| TARGET["_resolve_subresource_target"]
    TARGET --> WALK
    ROUTES --> DEDUP["_deduplicate"]
```

`_resolve_effective_jax_rs_methods()` — основной binding method. Он кеширует по
FQN resource, adapted type environment и namespace. Direct public usable
methods переживают несвязанную incomplete hierarchy, когда достаточно их
собственного atomic bundle. Для inherited additions требуются полный bounded
graph, одна erased signature, одна implementation/default и один atomic
annotation source. Его result связывает concrete implementation с declaration,
которая предоставляет route annotations.

`_collect_subresource_endpoints()` рекурсивен по ветвям. Его state содержит FQN
concrete resource и generic environment. Он отклоняет повторяющиеся active
types, повторяющиеся locator edges, глубину свыше `MAX_SUBRESOURCE_DEPTH`,
states при `MAX_SUBRESOURCE_STATES` и composed paths длиннее
`MAX_COMPOSED_PATH`. Leaf добавляется здесь, только если он был достигнут через
locator или его binding был введён hierarchy analysis; обычные direct leaves
остаются во владении direct pass.

`_build_recalled_endpoint()` всегда связывает fact и represented target с
выбранной concrete implementation. Он добавляет method annotation evidence,
только когда та же method declaration предоставила bundle. Interface или
superclass может доказать route, не присваивая себе line в CSV row другого файла.

<a id="52-hierarchy-symbol-contracts"></a>

### 5.2 Контракты symbols hierarchy

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `SubresourceTypeState` | Неизменяемая identity для обнаружения cycles: FQN resource вместе с deterministic key generic environment. |
| `JaxRsEffectiveMethod` | Mutable internal selection record, связывающая implementation, adapted environment, atomic annotation source, decoded binding, hierarchy-added flag и erased signature. |
| `_deduplicate()` | Analyzer-local merge с key из method, path, public source, handler и parameters. Он объединяет typed evidence через `deduplicate_endpoint_facts()`; public consolidation по шести полям всё равно происходит позднее. |
| `JaxRsHierarchyAnalyzer.__init__(workspace, *, state)` | Строит neutral Java graph, сохраняет явный JAX-RS state и создаёт cache effective method. |
| `JaxRsHierarchyAnalyzer._log_jax_rs_skip()` | Преобразует record Java method/type в diagnostic owner и делегирует `log_jax_rs_skip()`. |
| `JaxRsHierarchyAnalyzer._is_ancestor_annotation_method()` | Позволяет interface-, public- и protected-методам ancestors поставлять JAX-RS metadata; private и static methods исключаются. |
| `JaxRsHierarchyAnalyzer._is_genuine_override()` | Доказывает точный `java.lang.Override`; source annotation с тем же simple name не игнорируется. |
| `JaxRsHierarchyAnalyzer._has_atomic_annotation_bundle()` | Считает direct annotations метода, кроме настоящего `Override`, вместе с annotations параметров одним неделимым JAX-RS inheritance bundle. Нейтральный graph использует этот переданный caller'ом predicate, не владея его семантикой. |
| `JaxRsHierarchyAnalyzer._select_jax_rs_annotation_source()` | Выбирает неделимый bundle: сначала implementation, затем ближайший eligible superclass, затем один maximally specific interface origin. Ambiguity, blocked branches или несколько source identities возвращают `None`. |
| `JaxRsHierarchyAnalyzer._classify_jax_rs_annotation()` | Классифицирует поддерживаемые standard JAX/core/container annotations, затем source custom designators; возвращает имя route, `custom` или `other`. |
| `JaxRsHierarchyAnalyzer._standard_jax_annotation_family()` | Разрешает genuine поддерживаемую standard annotation в `jakarta.ws.rs` или `javax.ws.rs`; evidence не из JAX возвращает `None`. |
| `JaxRsHierarchyAnalyzer._decode_jax_rs_method_binding()` | Проверяет single family, designator и path atomic bundle. Возвращает binding `leaf`, binding `locator` с непустым path или `None`. |
| `JaxRsHierarchyAnalyzer._resolve_interface_contract_path()` | Добавляет один direct type-level path, только когда выбранный annotation source — interface, а endpoint является hierarchy-added. Отсутствие — `""`; invalid/mixed диагностируется как `None`. |
| `JaxRsHierarchyAnalyzer._resolve_effective_jax_rs_methods()` | Выбирает и кеширует пары concrete implementation/bundle с описанным выше сохранением direct method и более строгой inherited completeness. |
| nested `collect_interface_signatures()` | Рекурсивно добавляет erased signatures из ограниченных достижимых interface states в `_resolve_effective_jax_rs_methods()`; останавливается на общем depth bound или cycle. |
| `JaxRsHierarchyAnalyzer._resolve_subresource_target()` | Подставляет return type implementation, разворачивает `Class<T>` и требует один concrete source class/record. Возвращает type вместе с exact/default generic environment или `None`. |
| `JaxRsHierarchyAnalyzer._build_recalled_endpoint()` | Строит один HTTP `EndpointFact` hierarchy/locator во владении implementation с annotation evidence только той же declaration и точным represented method target. |
| `JaxRsHierarchyAnalyzer._collect_subresource_endpoints()` | Выполняет bounded branch-recursive traversal с branch-local cycle sets и общим для root state budget, выдаёт additive leaves, диагностирует failures locator и рекурсивно следует valid target states. |
| `JaxRsHierarchyAnalyzer.analyze_jax_rs_routes()` | Находит каждый доказанный root, выбирает его deployment prefix, выполняет traversal из default type environment и возвращает deterministic analyzer-local deduplicated additions. |
| `analyze_jax_rs_hierarchy_and_subresources()` | Public one-call wrapper, создающий fresh analyzer и возвращающий только additions hierarchy/subresource. |

Proof bounds уровня module: `MAX_SUBRESOURCE_DEPTH = 16`,
`MAX_SUBRESOURCE_STATES = 4096` и `MAX_COMPOSED_PATH = 8192`. Они ограничивают
traversal одного root; превышение bound подавляет работу затронутой branch/root,
а не уже доказанные direct facts.

## 6. Методы Java WebSocket

Владелец: [`src/noir/java_websocket.py`](../src/noir/java_websocket.py).

```mermaid
flowchart TD
    ENTRY["analyze_java_websocket_endpoints"] --> ANN["_resolve_server_endpoint_annotation"]
    ANN --> UNIQUE["unique identity type в workspace"]
    UNIQUE --> TYPE["_endpoint_type_rejection_reason"]
    TYPE --> VALUE["_extract_server_endpoint_path_node"]
    VALUE --> CONST["resolve_workspace_string_expression"]
    CONST --> TARGET["represented_target_evidence(type)"]
    TARGET --> FACT["GET ws/websocket EndpointFact"]
```

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `JAVA_WEBSOCKET_SERVER_ENDPOINT_PACKAGES` | Точный registry provenance Jakarta/Javax для `ServerEndpoint`. |
| `_log_websocket_skip()` | Записывает rejection уровня type, не записывая файлы и не возбуждая исключение. |
| `_declared_constructors()` | Возвращает explicit constructors из body type; отсутствие body/constructors даёт пустой list. |
| `_has_public_zero_arg_constructor()` | Считает отсутствие explicit constructor неявным usable constructor; иначе требует хотя бы один explicit public zero-argument constructor. |
| `_record_has_no_components()` | Доказывает, что canonical constructor record имеет ноль components. |
| `_endpoint_type_rejection_reason()` | Возвращает первую причину rejection visibility, enclosing visibility, type-kind, abstractness, static-nesting или construction; возвращает `None`, когда type жизнеспособен. |
| `_resolve_server_endpoint_annotation()` | Возвращает одну genuine annotation record, обогащённую resolved namespace/name, `(None, None)` при отсутствии candidate или ambiguity error. |
| `_extract_server_endpoint_path_node()` | Принимает ровно одно positional value или named `value`, игнорирует unrelated options и возвращает пару node/error. |
| `analyze_java_websocket_endpoints()` | Обходит deterministic units/types, требует unique source identity и viable construction, разрешает непустой path без query/fragment и выдаёт `GET`, `ws`, `websocket`, inbound `EndpointFact`. Представляет annotated type и намеренно не выдаёт method annotation evidence. |

Для WebSocket handshakes deployment prefix JAX-RS не учитывается. Точному path
добавляется slash-prefix, но в остальном он остаётся независимым от composition
HTTP resource.

## 7. Методы annotation inventory

Общий traversal и сборка reports: [`src/noir/inventory.py`](../src/noir/inventory.py).
Framework meaning: [`src/noir/jaxrs_annotations.py`](../src/noir/jaxrs_annotations.py)
и [`src/noir/spring_annotations.py`](../src/noir/spring_annotations.py).

Broad audit и final-trigger inventory отвечают на разные вопросы и не должны
выводиться друг из друга.

```mermaid
flowchart LR
    OCC["unit.annotation_occurrences"] --> BROAD["build_annotation_audit_inventory"]
    BROAD --> AFC["annotation_framework_classifications"]
    AFC --> FAMILY["classify_annotation callbacks выбранных семейств"]
    FAMILY --> REG["registered_annotation_classifications<br/>built-in groups от семейства"]
    FAMILY --> SRC["доказательство composed/custom/metadata внутри семейства"]
    BROAD --> ROWEX["annotation_source_extract"]
    ROWEX --> BI["broad per-file inventory"]

    OCC --> FINAL["build_final_trigger_inventory"]
    FINAL --> TARGET["discover_applied_annotation_target"]
    TARGET --> PLACE["final_trigger_placement_supported"]
    FINAL --> FTC["final_trigger_classifications"]
    FTC --> TFAMILY["classify_trigger callbacks выбранных семейств"]
    TFAMILY --> DIR["direct_final_trigger_classifications<br/>trigger groups от семейства"]
    TFAMILY --> SDEF["доказательство composed/custom triggers внутри семейства"]
    FINAL --> PHY["java_physical_source_lines<br/>annotation_physical_source_extract"]
    FINAL --> FI["narrow per-file/per-framework inventory"]
```

### 7.1 Ветка broad audit

`build_annotation_audit_inventory()` выдаёт одну file record для каждой parsed
unit, включая файлы без classified annotations. Он получает упорядоченные
пары `(family_name, callback)`, где каждый callback уже связан со state
выбранного семейства. Для каждого occurrence эти callbacks объединяют три
lane provenance:

- `registered_annotation_classifications()` доказывает точные identities
  built-in framework, не позволяя same-FQN source declaration выдавать себя за
  dependency annotation.
- `classify_spring_annotation()` и `classify_jaxrs_annotation()` распознают
  поддерживаемые composed annotations или custom designators, используя явный
  family state.
- Те же family callbacks включают `@Retention`, `@Target` или Spring `@AliasFor`,
  только когда occurrence принадлежит validated route annotation,
  определённой в source.

Occurrences уникальны по key их node Tree-sitter и сортируются в source order.
Extract использует rows Tree-sitter плюс до десяти следующих непустых lines.
Этот inventory остаётся доступным в `AnalysisResult` для внутренних audit
consumers; сгенерированные logs аннотаций используют final-trigger inventory.
Ни один из inventories не утверждает, что endpoint существует.

### 7.2 Ветка final-trigger inventory

`build_final_trigger_inventory()` принимает только annotations, применённые
непосредственно к stable method, record component или named type, и только в
placement, поддерживаемом соответствующим analyzer. Общий inventory определяет
структурные targets; выбранные callbacks `classify_spring_trigger()` /
`classify_jaxrs_trigger()` решают framework meaning через собственные trigger
groups и state. Каждый candidate содержит canonical `SourceTarget`, resolved
identity/family, byte span, понятную человеку
метку target и extract, выровненный по bytes. Если occurrence в рамках одного
выбранного framework разрешается в несколько identities, он исключается без
догадок.

Этот inventory строится до endpoint analysis. Log annotations/diagnostics
включает все его triggers через `trigger_annotation_log_inventory()`. Позднее
`render_annotations_without_endpoints_report_bytes()` вычитает exact targets,
объединённые из surviving consolidated rows. Поэтому rejected trigger остаётся
видимым; trigger, покрытый любым duplicate fact в surviving public group,
удаляется. Опциональное сравнение Noir использует тот же inventory, но
сопоставляет canonical source file и start line каждого trigger'а с Noir, а не
вычитает declaration targets noir-ts.

### 7.3 Контракты symbols inventory

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `SUPPORTED_ANNOTATIONS` семейства | Каждый family module владеет своими broad built-in provenance и audit-role groups. |
| `FINAL_TRIGGER_ANNOTATIONS` семейства | Каждый family module владеет narrow trigger groups со структурным placement и evidence family для каждой identity. |
| `classify_jaxrs_annotation()` / `classify_spring_annotation()` | Family callbacks объединяют built-ins, поддерживаемые source definitions и contextual metadata через явный family state. |
| `classify_jaxrs_trigger()` / `classify_spring_trigger()` | Family callbacks выбирают built-in и source-defined triggers в поддерживаемых placements, включая проверки method applicability для record components. |
| `annotation_owner_name()` | Находит ближайшего named type display owner для resolution source definition; отсутствие owner превращается в `""`. |
| `registered_annotation_classifications()` | Читает переданные caller'ом built-in groups и возвращает точные classifications `{resolved}`, если analyzed source не владеет ожидаемым FQN; имя family добавляет inventory. |
| `source_definition_for_annotation_metadata()` | Находит единственное нейтральное определение source-annotation, окружающее одно metadata occurrence. |
| `annotation_framework_classifications()` | Вызывает выбранные bound callbacks, добавляет их family names, выполняет deduplication по `(framework, resolved)` и возвращает deterministic order. |
| `_annotation_source_extract_from_rows()` | Строит span строки annotation вместе с ограниченным числом следующих непустых rows. |
| `annotation_source_extract()` | Преобразует point rows Tree-sitter в extract broad audit, корректируя exclusive zero-column end row. |
| `java_physical_source_lines()` | Разделяет bytes только по LF/CRLF/CR и возвращает точные byte starts вместе с decoded lines для target-aligned reporting. |
| `annotation_physical_source_extract()` | Отображает byte bounds annotation в model физических lines и делегирует rendering extract; malformed spans возвращают пустой extract. |
| `_record_component_name_node()` | Восстанавливает имена обычных или varargs record components. |
| `discover_applied_annotation_target()` | Возвращает точные metadata declaration для method, record-component или named-type. Для anonymous/recovered/unsupported shapes применяется fail-closed: возвращается `None`. |
| `normalize_applied_to_parameters()` | Удаляет parentheses и сворачивает Java whitespace для стабильного human label method; это не identity target. |
| `applied_annotation_target_label()` | Создаёт `method Owner.name(params)`, `record component Owner.name` или `type Owner`; отсутствие stable ownership возвращает `None`. |
| `final_trigger_placement_supported()` | Проверяет выбранный caller'ом структурный placement, например `method-or-component`, для neutral target. |
| `direct_final_trigger_classifications()` | Читает переданные caller'ом trigger groups, классифицирует точные built-ins в поддерживаемых placements и отклоняет dependency identities, затенённые source declarations. |
| `final_trigger_classifications()` | Вызывает выбранные bound trigger callbacks и объединяет их classifications по `(framework, resolved)` в deterministic order. |
| `build_final_trigger_inventory(workspace, analysis_root, recognizers)` | Строит narrow per-file/per-framework inventory с exact targets и byte-aligned extracts. |
| `build_annotation_audit_inventory(workspace, analysis_root, recognizers)` | Строит broad per-file audit inventory со всеми classifications occurrences выбранного framework. |

## 8. Методы evidence

Владелец: [`src/noir/evidence.py`](../src/noir/evidence.py).

Validation evidence намеренно централизована. Код analyzer может предложить
evidence на основе line или declaration, но эти методы решают, пересечёт ли это
evidence типизированную boundary.

### 8.1 Построение, ownership, merge, selection

```mermaid
flowchart TD
    NODE["Node annotation Tree-sitter"] --> MEN["method_annotation_evidence_from_node"]
    MAP["decoded mapping"] --> MEM["method_annotation_evidence_from_mapping"]
    MEN --> MAKE["make_method_annotation_evidence"]
    MEM --> MEN
    MAKE --> FAM["method_annotation_family"]
    MAKE --> CANON["canonical_source_file_name"]
    MAKE --> AE["AnnotationEvidence или None"]

    DECL["node declaration"] --> RTE["represented_target_evidence"]
    RTE --> STN["source_target_from_node"]
    STN --> MST["make_source_target"]
    MST --> ST["SourceTarget или None"]

    AE --> MERGEA["merge_method_annotation_evidence"]
    ST --> MERGET["merge_represented_targets"]
    MERGEA --> FACTMERGE["merge_endpoint_facts / deduplicate_endpoint_facts"]
    MERGET --> FACTMERGE
    FACTMERGE --> OWN["owned_method_annotation_evidence<br/>owned_represented_targets"]
    OWN --> SELECT["select_method_annotation_evidence"]
```

Ключ выбора annotation:

```text
(METHOD_ANNOTATION_FAMILY_PRIORITY[family], line, identity)
```

Он применяется только после merge evidence из всех candidates в одной public
group по шести полям. Поэтому самая ранняя line глобально не обязательно
побеждает.

### 8.2 Контракты symbols evidence

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `EndpointIdentity` | Type alias для callable, предоставленного analyzer'ом и возвращающего tuple identity для local deduplication. |
| `_java_identifier_start()` | Реализует принимаемые Unicode categories вместе с `_`/`$` для первого character Java identifier. |
| `_java_identifier_part()` | Расширяет start characters категориями Java combining, decimal и formatting. |
| `_is_canonical_annotation_identity()` | Требует dotted sequence полных Java identifiers; simple identities допустимы, частичные dotted segments — нет. |
| `canonical_source_file_name()` | Преобразует usable path-like input в absolute real normalized-case identity; unusable input или строка только из whitespace возвращает `None`. Значимые пробелы в filename сохраняются, поэтому разные declarations не объединяются из-за trimming. Не требует существования файла. |
| `make_source_target()` | Проверяет canonical source, supported kind, integer nonboolean bounds и `0 <= start < end`; возвращает typed target или `None`. |
| `source_target_from_node()` | Читает byte bounds из parser node и делегирует validation target. |
| `represented_target_evidence()` | Преобразует node в zero-or-one tuple, ожидаемый `EndpointFact`. |
| `_canonical_source_target()` | Проверяет type и повторно валидирует существующий `SourceTarget`; malformed typed fields могут быть отброшены, неверные types элементов collection возбуждают исключение. |
| `merge_represented_targets()` | Отклоняет mapping/string containers, канонизирует элементы, объединяет их по `(file, kind, start, end)` и возвращает sorted typed targets. |
| `method_annotation_family()` | Обеспечивает fixed family для built-ins. Source-defined identities могут использовать только family из priority registry; contradictions возвращают `None`. |
| `make_method_annotation_evidence()` | Требует positive nonboolean line, canonical identity, trusted family и равные canonical files annotation/endpoint. Возвращает typed evidence или `None`. |
| `method_annotation_evidence_from_node()` | Читает one-based start row и создаёт zero-or-one evidence tuple. |
| `method_annotation_evidence_from_mapping()` | Адаптирует analyzer-local mapping с node/identity/family; non-mappings возвращают пустой tuple. |
| `merge_method_annotation_evidence()` | Проверяет types, повторно валидирует, удаляет duplicates по family/line/identity/file и возвращает evidence в deterministic order. |
| `merge_endpoint_facts()` | Сохраняет scalar fields candidate fact'а, объединяя текущие и candidate evidence/targets в заменённый immutable fact. |
| `deduplicate_endpoint_facts()` | Требует elements `EndpointFact` и identity callback, создающий tuple; sorted local keys определяют порядок output, а duplicate facts объединяют evidence. |
| `owned_method_annotation_evidence()` | Повторно валидирует и сохраняет только evidence, чей canonical file равен public source file endpoint. |
| `owned_represented_targets()` | Повторно валидирует и сохраняет только represented declarations в public source file endpoint. |
| `select_method_annotation_evidence()` | Возвращает minimum candidate family-priority/line/identity или `None`. |

## 9. Методы projection и consolidation output

Владелец: [`src/noir/output.py`](../src/noir/output.py).

### 9.1 Lossy projection и authoritative grouping

```mermaid
flowchart TD
    FACT["EndpointFact"] --> PROJ["endpoint_fact_to_row_candidate"]
    PROJ --> OWN1["owned_method_annotation_evidence"]
    PROJ --> OWN2["owned_represented_targets"]
    PROJ --> CAND["EndpointRowCandidate"]
    CAND --> CONS["consolidate_endpoint_rows"]
    CONS --> STR["stringify_output_value"]
    CONS --> NORM["normalize_endpoint_path"]
    NORM --> SPR["normalize_spring_regex_templates"]
    CONS --> KEY["tuple key из шести полей"]
    KEY --> EM["merge evidence и targets"]
    EM --> PICK["select_method_annotation_evidence"]
    PICK --> FINAL["ConsolidatedEndpoints"]
    FINAL --> CSV["write_endpoint_csv"]
```

`endpoint_fact_to_row_candidate()` — явная boundary semantic compression. Он
отображает protocol/surface в public `interface_type`, делает public source file
relative и отбрасывает богатый route/configuration provenance, не помещающийся
в CSV. Вместе с шестью public values он сохраняет только owned typed evidence.

`consolidate_endpoint_rows()` преобразует первые шесть полей в strings,
нормализует endpoint согласно public protocol и группирует точно по:

```text
(module_name, interface_type, endpoint,
 source_file_name, method_name, parameters)
```

Внутри каждой group он объединяет оба потока evidence. Только после этого он
выбирает `method_annotation_line`. Sorted full keys делают output независимым
от iteration order analyzer. Его result `represented_targets` — union по каждой
surviving group и каждому duplicate candidate, а не только по одному
representative.

### 9.2 Контракты symbols output

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `EndpointRowCandidate` | Frozen projection шести полей вместе с private typed collections annotation/target. |
| `EndpointRowCandidate.__post_init__()` | Копирует обе collections в tuples и отклоняет mappings или неверные element types. |
| `EndpointRowCandidate.public_identity()` | Возвращает свежий dictionary из шести полей в contract order; callers не могут через него изменить candidate. |
| `ConsolidatedEndpoints` | Frozen rows вместе с union represented-target, сохранённым для companion reporting. |
| `ConsolidatedEndpoints.__post_init__()` | Копирует/замораживает каждую row, требует string keys/cells и запечатывает typed target tuple. |
| `stringify_output_value()` | Отображает `None` в пустоту, сохраняет spelling scalar, предпочитает Unicode JSON для structures и в конце использует `str()` для устойчивости presentation. |
| `endpoint_fact_to_row_candidate()` | Требует `EndpointFact`, вычисляет public interface/source values и переносит только evidence из того же public file. |
| `normalize_spring_regex_templates()` | Удаляет balanced constraints `{name:regex}`. Внутри распознанного constraint отслеживает escaped и nested braces, чтобы они не закрыли template раньше времени; unsupported или unbalanced syntax сохраняется без догадок. |
| `normalize_endpoint_path()` | Применяет normalization Spring template и placeholder, сворачивает повторные non-scheme slashes и добавляет leading slash только к relative HTTP paths. |
| `consolidate_endpoint_rows()` | Владеет точной public identity, union evidence, выбором annotation line, deterministic order и union surviving represented-target. |
| `write_endpoint_csv()` | Напрямую перезаписывает запрошенный path, используя UTF-8 BOM, delimiter semicolon, quoting `csv` и окончания records CRLF. Копирует только запрошенные fields; операция не атомарна. |

Public schema определена в `contracts.CSV_FIELDS` и не дублируется в writer.

## 10. Методы rendering и publication reports

Владелец: [`src/noir/reports.py`](../src/noir/reports.py).

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `trigger_annotation_log_inventory()` | Преобразует final-trigger sections в форму отображения аннотаций по файлам, объединяя cross-framework classifications по точному byte span аннотации. Опциональные paths `source_files` сохраняют файлы без triggers, даже когда не выбран ни один framework. |
| `annotation_inventory_lines()` | Presentation-only renderer для records отображения аннотаций по файлам. CLI передаёт преобразованный endpoint-trigger inventory. Выдаёт deterministic lines без newline, explicit empty-file state, classifications и extracts. |
| `write_annotation_diagnostic_log()` | Непосредственно выполняет rendering и перезаписывает log annotations/diagnostics (`<output>.log`) в UTF-8. Layout: endpoint-trigger inventory, пустой separator при необходимости, `Diagnostics:`, затем уже timestamp-rendered collector lines. Операция не атомарна. |
| `render_annotations_without_endpoints_report_bytes()` | Side-effect-free renderer. Канонизирует переданный union targets, вычитает targets по exact equality, сортирует files/frameworks/source spans и возвращает UTF-8 bytes. Invalid target evidence не может скрыть trigger. |
| `derive_annotations_without_endpoints_report_path()` | Удаляет только последний suffix output, если он есть, и добавляет `-anno-without-endpoints.log`. |
| `publish_bytes_atomically()` | Создаёт sibling temp file, записывает, выполняет flush и fsync, затем вызывает `os.replace()` для одного destination. Любой `BaseException` запускает best-effort cleanup descriptor/temp и повторно возбуждается без изменений. Даёт atomic replacement одного файла, но не multi-artifact rollback или durability directory. |

Side-effect-free byte renderers потребляют нормализованные data и никогда не
обращаются обратно к Java nodes или analyzers. Bytes annotations-without-endpoints,
опциональные comparison bytes и completion text готовятся до начала publication;
Rendering CSV и log annotations/diagnostics выполняется непосредственно во
время их записи.

## 11. Методы сравнения Noir

Владелец: [`src/noir/comparison.py`](../src/noir/comparison.py).

Потенциальные endpoint-trigger occurrences из final-trigger inventory
сравниваются с содержащими locations значениями
`endpoints[*].details.code_paths[*]` в JSON object Noir v1.1. Supporting annotations
из broad audit исключаются. Это не сравнение URL/method identities endpoint'ов,
а unmatched trigger сам по себе не доказывает, что Noir пропустил reachable
endpoint.

```mermaid
flowchart TD
    JSON["Path Noir JSON"] --> LOAD["load_noir_report_locations"]
    LOAD --> JPATH["_canonical_location_path<br/>разрешить сохранённый root prefix"]
    LOAD --> LOC["frozenset SourceLocation"]
    INV["final-trigger inventory"] --> FLAT["flatten_final_trigger_inventory"]
    FLAT --> IPATH["_canonical_location_path<br/>непосредственно root-relative"]
    FLAT --> ITEMS["sorted occurrences AnnotationAuditItem"]
    LOC --> CMP["compare_final_trigger_inventory"]
    ITEMS --> CMP
    CMP --> PART["matched / missing exact locations"]
    PART --> RENDER["render_noir_comparison_report_bytes"]
```

### 11.1 Контракты symbols comparison

| Точный symbol | Роль, result и поведение при ошибке |
|---|---|
| `NoirReportValidationError` | Public subtype `ValueError` для malformed JSON или unsupported structure/path/line values Noir. |
| `SourceLocation` | Ordered pair canonical source-file и positive one-based line. |
| `AnnotationFramework` | Упорядоченная сохранённая classification `{framework, resolved}`. |
| `SourceExtractLine` | Ordered retained physical line и source text. |
| `AnnotationAuditItem` | Одно flattened annotation occurrence с display data и canonical location match. Сгенерированные comparison reports заполняют его из final-trigger inventory. |
| `AnnotationComparison` | Deterministic partitions full/matched/missing вместе с sorted unique locations Noir и discriminator input scope. |
| `AnnotationComparison.total_count` | Число flattened annotation occurrences в переданном comparison scope. |
| `AnnotationComparison.matched_count` | Число occurrences, чья exact location входит в set locations Noir. |
| `AnnotationComparison.missing_count` | Число occurrences вне этого set. |
| `AnnotationComparison.trigger_only` | Отличает CLI-сравнение final-trigger от сохранённого neutral helper broad inventory, чтобы объяснения report'а оставались корректными для обоих inputs. |
| `_sequence()` | Строго требует non-string sequence в coordinate JSON; иначе возбуждает `NoirReportValidationError`. |
| `_mapping()` | Строго требует object/mapping в coordinate JSON. |
| `_positive_line()` | Требует positive nonboolean integer. Его message также описывает nullable locations Noir, поскольку callers обрабатывают `null` до его вызова. |
| `_analysis_root_path()` | Разрешает usable analysis root и сохраняет basename'ы supplied и resolved path как candidates для опционального retained-root spelling Noir. |
| `_canonical_location_path()` | Разрешает absolute/root-relative paths через общий canonicalizer. Только для inputs Noir устраняет ambiguity опционального root basename с помощью существования файла и применяет fail-closed, когда существуют обе интерпретации. |
| `_load_json_object()` | Читает UTF-8 JSON с опциональным BOM и требует top-level object; ошибки I/O передаются наружу, ошибки shape/decode используют `NoirReportValidationError`. |
| `load_noir_report_locations()` | Строго проверяет endpoints/details/code_paths и каждый присутствующий path. Missing/null lines не дают location; присутствующие lines валидируются, а canonical duplicates схлопываются. |
| `_inventory_sequence()` | Адаптирует structural failures sequence к `ValueError` для внутренней validation inventory. |
| `_inventory_mapping()` | Адаптирует structural failures mapping к `ValueError`. |
| `_inventory_text()` | Требует непустой text, если не указано `allow_empty=True`; используется для content source extract. |
| `_inventory_line()` | Требует positive inventory line и адаптирует error к `ValueError`. |
| `_inventory_byte_offset()` | Требует nonnegative, nonboolean byte offset аннотации и адаптирует failure к `ValueError`. |
| `_flatten_frameworks()` | Проверяет required fields, удаляет duplicates typed classifications и возвращает sorted values. |
| `_flatten_extract()` | Проверяет required fields line/source, удаляет duplicates и сортирует extract lines по source. |
| `_annotation_sort_key()` | Определяет deterministic order occurrences по display file, line, name, classifications, extract и canonical location. |
| `flatten_annotation_audit_inventory()` | Сохранённый neutral helper, который проверяет и преобразует в flat-форму records broad inventory; сгенерированные Noir comparison reports его не вызывают. |
| `compare_annotation_audit_inventory()` | Сохранённый neutral helper, который разделяет переданный broad inventory; CLI использует специальную для final-trigger точку входа ниже. |
| `flatten_final_trigger_inventory()` | Проверяет final-trigger sections, канонизирует identity файла, объединяет cross-framework classifications по точному byte span аннотации и возвращает sorted typed occurrences. |
| `_compare_annotations()` | Проверяет types переданных locations и разделяет нормализованные items по точному равенству `SourceLocation`. |
| `compare_final_trigger_inventory()` | Преобразует final-trigger inventory в flat-форму и делегирует его partition по exact location. |
| `_render_annotation_item()` | Выполняет render одного missing annotation occurrence со всеми classifications и extract lines. |
| `render_noir_comparison_report_bytes()` | Проверяет type comparison и выдаёт deterministic UTF-8 bytes summary/detail. Объяснение supporting annotations следует `trigger_only`; сгенерированные CLI reports указывают, что supporting annotations исключены. |
| `derive_noir_comparison_report_path()` | Удаляет только последний suffix output и добавляет `-anno-without-noir-endpoints.log`. |

## 12. Общие declarative contracts

Владелец: [`src/noir/contracts.py`](../src/noir/contracts.py). В этом module нет
методов; его экспортируемые constants задают поведение, совместно используемое
discovery, analyzers, inventory, evidence и output. Изменения registry следует
рассматривать как изменения code path.

| Точный symbol | Consumers и значение |
|---|---|
| `CSV_DELIMITER` | `write_endpoint_csv()`; фиксирован как semicolon. |
| `CSV_IDENTITY_FIELDS` | `consolidate_endpoint_rows()`; точный contract grouping и ordering по шести полям. |
| `METHOD_ANNOTATION_LINE_FIELD` | Consolidation; седьмое field выбирается после merge evidence. |
| `CSV_FIELDS` | CLI/writer; шесть identity fields, за которыми следует field annotation line. |
| `SOURCE_TARGET_KINDS` | Validator evidence; принимаются только `method`, `record-component` и `type`. |
| `IGNORED_SOURCE_DIRECTORIES` | Discovery Java/marker и `web.xml`; единый общий набор имён directories, отсекаемых discovery. |
| `SPRING_MAPPING_PACKAGE` | Analyzer Spring и оба registry inventory; точный package provenance MVC. |
| `SPRING_ALIAS_FOR_PACKAGE` | Classification и decoding metadata Spring, определённой в source. |
| `SPRING_MAPPING_METHODS` | Immutable mapping из имени Spring mapping annotation в fixed method или generic `None`. |
| `SPRING_HTTP_METHODS` | Ограниченный словарь Spring HTTP enum/token. |
| `SPRING_REQUEST_MAPPING_ATTRIBUTES` | Допустимые modeled attributes Spring mapping. |
| `SPRING_MAX_COMPOSED_ANNOTATION_DEPTH` | Bound для traversal composed annotations, определённых в source. |
| `JAX_RS_PACKAGES` | Точные namespaces annotations Jakarta/Javax JAX-RS. |
| `JAX_RS_CORE_PACKAGES` | Точно matching core namespaces. |
| `JAX_RS_HTTP_METHODS` | Моделируемые standard request designators. |
| `JAX_RS_HTTP_METHOD_STATIC_CONSTANTS` | Immutable known constants `HttpMethod` для evaluation custom token. |
| `HTTP_METHOD_TOKEN` | Full-match grammar для custom HTTP designator tokens. |
| `METHOD_ANNOTATION_FAMILY_SPRING_VERB` | Evidence family Spring verb-specific с наивысшим priority. |
| `METHOD_ANNOTATION_FAMILY_SPRING_GENERIC` | Evidence family generic mapping/exchange в Spring. |
| `METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE` | Evidence family messaging в Spring. |
| `METHOD_ANNOTATION_FAMILY_JAX_RS` | Evidence family request designator в JAX-RS. |
| `METHOD_ANNOTATION_FAMILY_PRIORITY` | Immutable table family-to-rank, используемая при итоговом выборе line. |
| `METHOD_ANNOTATION_FAMILY_BY_IDENTITY` | Immutable truth table identity-to-family built-ins; противоречивые hints caller отклоняются. |

## 13. Границы publication и failure

CLI сначала готовит values, а затем публикует artifacts в точном порядке:

```mermaid
sequenceDiagram
    participant C as cli.run_cli
    participant N as опциональный input Noir
    participant A as analysis
    participant P as pure render/projection
    participant CSV as endpoint CSV
    participant LOG as log annotations и diagnostics
    participant ABS as report annotations-without-endpoints
    participant CMP as опциональный comparison report

    C->>N: проверить и загрузить до инициализации output
    C->>LOG: прямой truncate/create
    C->>A: analysis с bound collector
    A-->>C: AnalysisResult
    C->>P: project, consolidate, render byte reports и completion text
    C->>CSV: прямая перезапись
    C->>LOG: прямая перезапись
    C->>ABS: atomic replacement одного файла
    opt Сравнение Noir включено
        C->>CMP: atomic replacement одного файла
    end
    C-->>C: вывести completion summary
```

Следствия, которые должен сохранять maintainer:

- Некорректный опциональный Noir report отклоняется до того, как run
  создаёт/обнуляет log annotations/diagnostics или анализирует Java.
- Log annotations/diagnostics намеренно создаётся пустым до начала controlled
  analysis. `RuntimeError` из `analyze()` или из непосредственно следующего
  loop печати announcements обрабатывается одним exception handler: он
  записывает доступные на тот момент inventory и diagnostics до сообщения о
  failure в стиле CLI argument. Более поздний `RuntimeError` следует по outer
  exception path.
- Projection и consolidation, формирование report'а annotations-without-endpoints,
  опциональное comparison и формирование итогового summary завершаются до открытия
  endpoint CSV.
- Запись CSV и log annotations/diagnostics — direct overwrites. Каждый byte
  report атомарен только относительно своей предыдущей версии файла.
- Более поздняя publication failure класса `Exception` не откатывает уже
  записанные artifacts. Outer exception path выполняет best-effort повторную
  запись log annotations/diagnostics, затем вновь возбуждает исходную failure.
  Для subclasses `BaseException`, не входящих в `Exception`, по-прежнему
  выполняется cleanup в atomic writer, но они минуют этот recovery handler CLI.
- Framework announcements уже могли быть напечатаны после успешного analysis.
  Inventory `noir-ts analysis completed.` печатается только после успешной
  publication каждого запрошенного artifact.
- Diagnostic'и analyzer'ов — events collector'а; только CLI вызывает
  `write_annotation_diagnostic_log()`. Этот renderer/writer отвечает за
  persistence log annotations/diagnostics; analyzers, helpers evidence и
  side-effect-free byte renderers его не сохраняют.

## 14. Как проследить один endpoint от начала до конца

Для direct method `@GET` используйте такой порядок inspection:

1. `analyze_direct_jax_rs_unit()` находит root и вызывает
   `resolve_jax_rs_request_designator()`.
2. Результат разрешения designator предоставляет HTTP method, annotation node, canonical
   identity и evidence family.
3. `resolve_jax_rs_method_path()` и
   `resolve_jax_rs_resource_prefix()` предоставляют остальные path layers.
4. `method_annotation_evidence_from_node()` валидирует same-file line evidence
   annotation; `represented_target_evidence()` идентифицирует весь handler
   method по byte span.
5. `EndpointFact` входит в `AnalysisResult.endpoints`.
6. `endpoint_fact_to_row_candidate()` делает public source identity relative и
   повторно проверяет ownership обоих потоков evidence.
7. `consolidate_endpoint_rows()` нормализует endpoint и объединяет каждый
   candidate с теми же шестью public values.
8. `select_method_annotation_evidence()` выбирает седьмое value CSV;
   `merge_represented_targets()` сохраняет все declarations, представленные
   surviving group.
9. `write_endpoint_csv()` публикует row. Независимо от этого,
   `render_annotations_without_endpoints_report_bytes()` удаляет matching
   final-trigger candidate по exact identity target.

Для hierarchy leaf замените step 1 на `_resolve_effective_jax_rs_methods()` и
`_collect_subresource_endpoints()`. Проверьте,
`annotation_source.id == implementation.id`: если нет, route может существовать,
а public annotation line оставаться пустой. Для WebSocket endpoint represented
target — это type, а annotation evidence всегда пуст.

## 15. Карта change impact

| Если меняется… | Следуйте по этим production owners… |
|---|---|
| custom designator, прямой resource, application path | `noir.jaxrs` → evidence → output |
| владение project, parse descriptor, selection deployment | `noir.jaxrs_deployment` → `jaxrs_framework.prepare_jaxrs_analysis` → hierarchy/direct selectors |
| inheritance, выбор bundle, traversal locator | `noir.java_hierarchy` → `noir.jaxrs_hierarchy` → endpoint evidence |
| Gates `ServerEndpoint` или shape fact | `noir.java_websocket` → model → output |
| broad/final inventory, извлечение target | `noir.inventory` → `AnalysisResult` → report renderers |
| validation/merge evidence или public consolidation | `noir.evidence` → `noir.output` → report subtraction |
| rendering/publication report и его failure behavior | `noir.reports` / `noir.comparison` → `noir.cli` |
| общие constants/registries | каждый importer в analyzers, inventory и output; у этих constants намеренно несколько consumers |

При диагностике missing row найдите первый method, возвращающий `None` на
релевантном call graph, затем прочитайте его diagnostic boundary. При диагностике
пустого `method_annotation_line` начните с ownership evidence, а не extraction
route. При диагностике entry annotations-without-endpoints сравните candidate
`SourceTarget` с targets `ConsolidatedEndpoints`; paths, имена handlers и source
lines намеренно не участвуют в этой membership-проверке.

Продолжите с [15 — Поиск методов и стратегия чтения](15-method-lookup.md)
или вернитесь к [оглавлению guide](README.md).
