# 03 — Общий Java engine

[← CLI и orchestration](02-cli-and-orchestration.md) · [Индекс](README.md) · [Spring MVC →](04-spring-mvc.md)

Java engine — нейтральный по отношению к framework'ам слой evidence, лежащий в
основе анализа Spring, JAX-RS, WebSocket, Gateway, client'ов и registration'ов. Он
разбирает source и отвечает на ограниченный набор вопросов о Java; он не
решает, является ли конструкция endpoint'ом.

Его центральное правило:

> Один запуск создаёт snapshot каждого найденного Java source, разбирает каждый
> source один раз и предоставляет всем выбранным analyzer'ам одни и те же
> compilation unit'ы и workspace index'ы.

Дополняющая глава уровня методов: [12 — Методы core runtime](12-core-runtime-methods.md)
сопоставляет parser, builder'ы unit'ов, resolver'ы, index'ы и hierarchy-методы
по точным именам symbol'ов.

## 1. Владение

~~~mermaid
flowchart TB
    P["noir.pipeline<br/>snapshot и порядок"] --> R["tree_sitter_runtime<br/>version gate и runtime"]
    P --> W["java_workspace<br/>один общий workspace"]
    R --> W
    W --> F["java_frontend<br/>compilation unit'ы"]
    W --> A["java_ast<br/>малые syntax proof'ы"]
    W --> M["java_methods<br/>index'ы методов"]
    W --> H["java_hierarchy<br/>graph типов"]
    W --> S["Интерпретация Spring"]
    W --> J["Интерпретация JAX-RS"]
    A --> S
    M --> S
    H --> S
    H --> J
~~~

| Владелец | Основные symbol'ы | Ответственность |
|---|---|---|
| [`noir.pipeline`](../src/noir/pipeline.py) | `SourceSnapshot`, `_snapshot_sources()`, `_build_workspace()` | неизменяемый input и его место в порядке stage'ей |
| [`noir.frameworks`](../src/noir/frameworks.py) | `FRAMEWORK_ADAPTERS` | статический bridge между нейтральным stage построения workspace и независимыми facade семейств |
| [`noir.tree_sitter_runtime`](../src/noir/tree_sitter_runtime.py) | `require_tree_sitter()`, `build_workspace_runtime()`, `run_query_matches()` | поддерживаемая пара parser'ов, построение parser/query и политика lifetime cursor'а |
| [`noir.java_queries`](../src/noir/java_queries.py) | `JAVA_COMPILATION_UNIT_QUERY_SOURCES`, `JAVA_WORKSPACE_QUERY_SOURCES` | полные нейтральные к framework'ам source query |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `parse_java_query_set()`, `build_java_compilation_unit()` | syntax-продукты одного файла и same-file fact'ы |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace()`, `resolve_workspace_owner_fqns()`, `resolve_workspace_string_expression()` | cross-file декларации, доступ и ограниченный resolution |
| [`noir.java_ast`](../src/noir/java_ast.py) | `field()`, `walk_named()`, `known_type()`, `is_direct_invocation_statement()` | многократно используемые syntax proof'ы |
| [`noir.java_methods`](../src/noir/java_methods.py) | `MethodFact`, `MethodIndex`, `build_strict_method_index()`, `build_varargs_method_index()` | ограниченные fact'ы методов и invocation |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaSourceHierarchyGraph` | graph source-типов, generic substitution, signature и inheritance |

Нейтральные модули не классифицируют annotation'ы Spring или JAX-RS.
Framework-модули напрямую импортируют эти helper'ы и добавляют значение route
только после доказательства Java identity.

## 2. Snapshot и parser runtime

`_snapshot_sources()` находит Java-файлы в детерминированном порядке по
project-relative пути, читает каждый строго один раз и создаёт
`SourceSnapshot`:

| Поле | Значение |
|---|---|
| `paths` | упорядоченный tuple строк source-path |
| `content` | read-only представление path-to-byte-content с точно теми же ключами |

Конструктор отклоняет любое несовпадение path/content. Marker selection,
построение workspace и порядок direct-pass'ов используют один и тот же
snapshot. Изменение source на диске после snapshotting не может разделить один
запуск на два представления byte'ов.

До discovery `require_tree_sitter()` принимает строго следующие версии:

| Дистрибутив | Поддерживаемая версия |
|---|---:|
| `tree-sitter` | `0.25.2` |
| `tree-sitter-java` | `0.23.5` |

Отсутствующие binding'и, отсутствующие metadata package или другая пара версий
останавливают анализ до parsing.

`build_workspace_runtime()` создаёт один Java language, один parser и полный
именованный набор query. Source'ы query компилируются в детерминированном
порядке имён. Набор workspace query захватывает:

- декларации package и import;
- class, interface, enum, record и annotation declaration;
- field'ы, interface constant'ы и enum constant'ы;
- annotation'ы на type, method и record component;
- все вхождения annotation, используемые inventory;
- meta-annotation, element и default annotation'ов;
- record method'ы.

`JAVA_COMPILATION_UNIT_QUERY_SOURCES` — база для каждого файла;
`JAVA_WORKSPACE_QUERY_SOURCES` добавляет capture, необходимые для project-wide
resolution.

## 3. Строго один parse на source

~~~mermaid
sequenceDiagram
    participant Pipeline as noir.pipeline
    participant Runtime as tree_sitter_runtime
    participant Workspace as java_workspace
    participant Frontend as java_frontend
    participant Parser as Tree-sitter
    participant Passes as framework pass'ы

    Pipeline->>Runtime: build_workspace_runtime()
    Pipeline->>Workspace: build_java_workspace(snapshot content)
    loop для каждого source path в отсортированном порядке
        Workspace->>Frontend: build_java_compilation_unit(bytes)
        Frontend->>Parser: parse(bytes)
        Parser-->>Frontend: syntax tree
        Frontend->>Frontend: выполнить скомпилированные query
        Frontend-->>Workspace: compilation unit
    end
    Workspace->>Workspace: построить cross-file index'ы
    Workspace-->>Pipeline: общий workspace
    Pipeline->>Passes: повторно использовать unit'ы и index'ы
~~~

На пути приложения приходится один вызов parser'а на каждый source из
snapshot. Direct Spring получает
`analyze_direct_spring_mvc_unit(unit, workspace)`, а direct JAX-RS —
`analyze_direct_jax_rs_unit(unit, workspace)`. Project-wide pass'ы получают тот
же workspace. Ни один framework analyzer не создаёт parser и не разбирает
source повторно.

`build_java_workspace()` может принимать уже разобранные tree для
низкоуровневых caller'ов. Для переданных path он принимает эти tree, а затем
выводит те же fact'ы compilation unit и workspace.

## 4. Fact'ы compilation unit

`build_java_compilation_unit()` сохраняет полный набор per-file evidence,
необходимый последующим pass'ам:

| Группа полей | Содержимое |
|---|---|
| identity | source path, точные byte'ы, имя package |
| lifetime syntax | tree, match'и query, владельцы cursor/result |
| import'ы | exact- и wildcard-import'ы типов; exact- и wildcard static import'ы |
| типы | записи lexical type, локальные имена типов, fact'ы collision в package |
| декларации | сырые capture field, interface-constant и enum, потребляемые workspace index'ами |
| annotation'ы | все occurrence, declaration, meta-annotation, element и default |
| кандидаты route | сгруппированные capture type, method и record-component |
| record'ы | явные fact'ы accessor'ов с нулём параметров |

Конкретный словарь compilation unit со всеми полями показан в разделе
[11 — данные `noir.java_frontend`](11-naming-and-code-vocabulary.md#noirjava_frontend).
Здесь термины **unit**, **parsed unit** и **compilation unit** обозначают один
и тот же словарь Noir; отдельный parsed tree Tree-sitter — лишь одно из его
значений.

Полный match Tree-sitter — единица association. Capture из несвязанных match'ей
никогда не объединяются лишь потому, что у них совпадает capture name.

Engine не отклоняет весь файл только потому, что syntax root содержит
восстановленную ошибку. Восстановленное subtree, удовлетворяющее query, всё ещё
может дать evidence; последующие resolver'ы локально отклоняют malformed или
неоднозначные формы.

### Видимость типов

Каждый именованный type записывает своё simple- и lexical-имя, внешний type,
node декларации, abstract flag и признак возможности участвовать в workspace
lookup.

- top-level type'ы видимы workspace;
- member type'ы видимы, если видима их цепочка outer;
- type'ы внутри method, constructor, lambda, block и initializer влияют на
  lexical shadowing, но не становятся workspace identity.

Byte range каждого node уникален только внутри одного compilation unit. Cross-file
записи сохраняют свой owning unit или source path.

### Lifetime tree и query

Index'ы хранят node Tree-sitter, поэтому их владельцы должны оставаться живы.
Compilation unit сохраняет:

- своё syntax tree;
- каждый query cursor и сырой match result, породивший сохранённые node;
- source-byte'ы, к которым относятся byte range node'ов.

Workspace сохраняет все compilation unit'ы. Любая project-wide запись,
хранящая node, также сохраняет identity своего unit.

## 5. Cross-file index'ы

После создания всех unit'ов `build_java_workspace()` выводит fact'ы, которые
невозможно установить по одному файлу:

~~~mermaid
flowchart LR
    U["Compilation unit'ы"] --> P["Имена package type"]
    U --> T["Декларации type по FQN"]
    U --> M["Member declaration"]
    U --> S["Static member declaration"]
    U --> C["Строковые константы по owner и member"]
    U --> A["Определения source-аннотаций"]
~~~

Подписи на диаграмме соответствуют следующим значениям приложения:

| Подпись | Что за ней находится | Пример |
|---|---|---|
| package type name | top-level simple name в наборе collision для того же package в unit | `"Fast"` в `unit["package_types"]` для другого source с `package app` |
| type declaration by FQN | запись декларации в bucket по FQN, сохраняющем дубликаты | `workspace["type_declarations"]["app.Items"] == [{"fqn": "app.Items", "unit": ..., "type_info": ...}]` |
| member declaration | identity существования field, interface constant или enum constant; не method | key `("routes.Paths", "ROOT")` |
| static member declaration | запись static field/interface/enum с fact'ами доступа | `workspace["static_member_declarations"][("routes.Paths", "ROOT")]` |
| source annotation definition | запись `@interface` из project source с её нейтральной syntax-структурой, а не применение вроде `@Fast` | `workspace["annotation_definitions"]["app.Fast"]` |

**Status member declaration** — не отдельный термин engine, а вероятная
опечатка вместо **static member declaration**. Полные структуры и разобранный
пример с несколькими файлами приведены в разделе
[Словарь workspace и index'ов](11-naming-and-code-vocabulary.md#workspace-and-index-vocabulary).

Важные различия:

- сохраняется каждая декларация fully qualified type name; дубликаты остаются
  неоднозначными;
- записи member declaration сохраняются, даже когда не могут предоставить String
  value, поскольку они способны затенить импортированные member'ы;
- записи констант сохраняют modifier, initializer, owner, unit и evidence
  доступа;
- записи static member declaration включают enum constant'ы, поэтому неоднозначность
  wildcard видима;
- определения source-аннотаций сохраняют meta-annotations, elements, types и
  defaults, но остаются нейтральными Java facts, пока framework не докажет их
  значение.

Source и записи обрабатываются в детерминированном порядке source. Consumer'ы,
которым нужна одна identity, требуют ровно одного доступного кандидата.

## 6. Fail-closed resolution имён

Engine моделирует лишь ту часть Java lookup, которая нужна поддерживаемым
analyzer'ам. Он никогда не выбирает удобного кандидата с более низким
приоритетом, если tier с более высоким приоритетом неоднозначен или
недопустим.

### Import'ы

Декларации import превращаются в четыре набора lookup:

~~~text
import a.b.Type;          -> exact type import
import a.b.*;             -> wildcard type import
import static a.b.C.X;    -> exact static member import
import static a.b.C.*;    -> wildcard static member import
~~~

Конфликтующие exact import'ы сохраняют явный marker неоднозначности. Malformed
import'ы игнорируются, а не угадываются.

### Identity известного annotation и type

`resolve_known_annotation()` и `resolve_known_type()` доказывают
поддерживаемые library identity через Java-подобные tier'ы:

- **spelling at one syntax node** — точный текст имени в этой позиции source,
  например `Path` или `jakarta.ws.rs.Path`;
- **unqualified** означает, что записано только simple name, например `Path`;
- **qualified** означает, что указан owner или namespace, например
  `RetentionPolicy.RUNTIME`; для известной annotation/type dotted spelling
  должна быть точным поддерживаемым FQN, например `jakarta.ws.rs.Path`;
- **visible lexical type** — доступная в этой позиции same-file декларация
  типа из enclosing type scope; она **shadows**, то есть затеняет одноимённый
  import, когда Java lookup отдаёт этой декларации приоритет.

~~~mermaid
flowchart TD
    Start["Написание в одном syntax node"] --> Q{"Qualified-форма?"}
    Q -- да --> Exact{"Точный поддерживаемый FQN?"}
    Exact -- нет --> Fail["Имя не разрешено"]
    Exact -- да --> Found["Одна identity"]
    Q -- нет --> Local{"Видимый lexical type затеняет её?"}
    Local -- да --> Fail
    Local -- нет --> Import{"Есть exact import?"}
    Import -- "неверный или неоднозначный" --> Fail
    Import -- "поддерживаемая identity" --> Found
    Import -- отсутствует --> Same{"Source type из того же package затеняет её?"}
    Same -- да --> Fail
    Same -- нет --> Candidates["Кандидаты implicit/current/wildcard"]
    Candidates --> One{"Ровно один без collision?"}
    One -- да --> Found
    One -- нет --> Fail
~~~

Например, следующая member annotation declaration затеняет wildcard import в
node `@Path`:

~~~java
import jakarta.ws.rs.*;

class ItemsResource {
    @interface Path { String value(); }

    @Path("/items")
    public void list() {}
}
~~~

Spelling является unqualified, но обозначает
`ItemsResource.Path`, а не `jakarta.ws.rs.Path`. Noir останавливается на этом
более сильном lexical tier и не создаёт JAX-RS route из этой annotation.
Соответствующее qualified spelling `@jakarta.ws.rs.Path("/items")` прямо
обозначает поддерживаемую identity. Общая терминология приведена в разделе
[Spelling имени, qualification и shadowing](11-naming-and-code-vocabulary.md#name-spelling-qualification-and-shadowing).

`java.lang` участвует только для ожидаемых там identity. Resolution package
wildcard проверяет source type'ы, способные конфликтовать с ожидаемой external
identity. Source-декларация с иначе поддерживаемым external FQN блокирует
shortcut.

Общий lookup source-owner рассматривает lexical nested type'ы, exact import'ы,
type'ы того же package и wildcard import'ы в порядке приоритета. Он применяет
правила доступа private nest, package, public outer-chain и named/unnamed
package. Дубликаты FQN никогда не обрабатываются по принципу first-wins.

## 7. Строковые константы и выражения

Lookup неквалифицированного member'а начинается с цепочки lexical owner. Если
этот tier объявляет имя, lookup останавливается, даже когда декларация
изменяема, имеет неправильный type или недоступна как value. Только отсутствие
lexical declaration разрешает lookup static import'ов.

Cross-file value требует доступный `static final String`. Interface constant'ы
получают неявную Java-семантику `public static final`. Поддерживаемое same-file
использование может читать final instance String; static method или initializer
не может. `this.member` находится вне evaluator'а workspace expression.

Static wildcard import разрешается, только если ровно один импортированный
owner объявляет member. Qualified reference сначала разрешает своего owner до
ровно одного FQN.

Поддерживаемый язык выражений намеренно мал:

~~~text
StringExpression := Java string literal
                  | ( StringExpression )
                  | StringExpression + StringExpression
                  | eligible identifier or member reference
~~~

Decoder литералов поддерживает обычные Java escape'ы, Unicode escape'ы с
повторным `u`, ограниченные octal escape'ы и корректные surrogate pair UTF-16.
Он отклоняет malformed escape'ы, непарные surrogate'ы, text block'и и слишком
большие результаты.

Единственные dependency-константы, разрешаемые без загрузки class'ов, —
закрытый набор token-констант JAX `HttpMethod`. Они всё равно проходят проверки
import, shadowing, owner, member и неоднозначности.

## 8. Многократно используемые представления методов и hierarchy

### `java_ast`

Этот модуль предоставляет небольшие proof'ы в пределах одного unit: source
text, защищённый доступ к field, обход named-node, ограниченное раскрытие raw
type, identity известного type, direct interface'ы и доказательство того, что
fluent invocation chain является непосредственным statement тела метода.

Модуль не строит второй объект AST. Например,
`java_ast.source_text(unit, java_ast.field(method_node, "name"))` возвращает
`"list"` из точных сохранённых byte'ов, а
`java_ast.is_direct_invocation_statement(call_node, body_node)` отвечает,
является ли этот fluent call непосредственным statement тела, а не вложенным
value.

### `java_methods`

`FormalParameter`, `MethodFact` и `MethodIndex` описывают source-методы в
стабильном порядке source. Strict- и varargs-builder'ы явно задают допустимые
формы formal parameter. Ключи index используют FQN owner'а и имя метода.
Analyzer'ы functional route, Gateway, registration, configuration и messaging
повторно используют эти fact'ы, добавляя собственные DSL-правила.

Например, `method_index.by_owner_name[("app.ItemsController", "list")]` — это
tuple всех принятых overload'ов `list` у данного owner. Каждый находящийся там
`MethodFact` сохраняет compilation unit, node тела, записи parameter'ов, node
return type и modifier'ы; сам index не придаёт им route-смысл.

### `java_hierarchy`

`JavaSourceHierarchyGraph` индексирует уникальные workspace-visible class'ы,
interface'ы и record'ы; разбирает ограниченные type reference; подставляет
generic parameter'ы; вычисляет erased signature методов; проходит inheritance
edge; выбирает effective или maximally specific interface method'ы.
Caller'ы явно передают правила selection interface-method'ов и остановки
traversal; политика наследования annotation'ов JAX-RS остаётся в его analyzer.
Generic declaration декодируются из byte'ов известного owning unit.

Дублирующиеся type identity не входят в traversable graph. Отсутствующие
source-parent'ы, некорректные generic-формы, cycle'ы, несовместимые type
environment'ы или несколько effective method candidate'ов делают
соответствующий traversal неполным. Hierarchy analyzer'ы Spring и JAX-RS не
выводят endpoint'ы из неполного proof.

Например, `graph.types["app.ItemsResource"]` — это `JavaTypeRecord`, в чьём
`interfaces` может находиться
`JavaTypeReference("decl", "app.ItemsApi", (...,))`, а в `methods` — значения
`JavaMethodRecord`. Перед сравнением erased signature вроде
`("find", ("java.lang.String",))` traversal подставляет generic argument.

Конкретные структуры compilation unit, AST-helper'ов, method index и hierarchy
record собраны в разделе
[Структуры данных по модулям](11-naming-and-code-vocabulary.md#java-data-structures-by-module).

## 9. Состояние framework рядом с общими Java facts

`JavaWorkspace` — это `TypedDict`, который именует существующие поля
нейтрального словаря: parser runtime, compilation unit'ы, types, members,
constants и определения source-аннотаций. Он документирует стабильную границу
построения для читателя и static checking; он не оборачивает словари и не
замораживает вложенные parser object'ы. Framework code использует эти facts, а
собственное изменяемое состояние интерпретации хранит отдельно.

~~~mermaid
flowchart TD
    Base["JavaWorkspace<br/>нейтральные Java facts"] --> Spring["SpringAnnotationState<br/>cache поддержки определений"]
    Base --> Jax["JaxRsState<br/>custom designator'ы и application'ы"]
    Spring --> Recognize["Callback'и recognition семейств"]
    Jax --> Recognize
    Recognize --> Inventories["Общая assembly inventory"]
    Jax --> Deploy["Подготовка deployment JAX-RS"]
    Base --> Passes["Endpoint-pass'ы framework"]
    Deploy --> Passes
    Inventories --> Passes
~~~

`java_workspace.index_java_annotation_definitions()` записывает
meta-annotations, elements, types, defaults и element annotations как
нейтральные source facts. Spring читает эти определения и отдельно доказывает
runtime retention, composed mapping branch'и и edge'и `AliasFor`.
`SpringAnnotationState` кеширует этот proof между broad- и final-trigger
recognition, не меняя Java index'ы.

`jaxrs.build_jaxrs_state(workspace)` строит кандидатов custom request-method,
допустимые designator'ы и записи `ApplicationPath`. После построения inventory
`jaxrs_framework.prepare_jaxrs_analysis(request, workspace, state)` присваивает
модель, возвращённую
`build_jax_rs_deployment_model(state.applications, root)`, полю
`state.deployment_model`. Direct- и hierarchy-pass'ы JAX-RS явно получают это
же состояние. Ни один невыбранный framework не создаёт пустые ключи в workspace.

Подготовка выбранных семейств завершается до извлечения endpoint'ов. Method
index'ы и hierarchy graph'ы строятся из существующих Java facts внутри тех
pass'ов, которым они нужны. Конкретные общие поля и примеры отдельного
состояния перечислены в разделе
[Словарь workspace и index'ов](11-naming-and-code-vocabulary.md#workspace-and-index-vocabulary).

## 10. Границы proof

| Аспект | Граница или правило | Если доказать не удалось |
|---|---|---|
| пара Tree-sitter | точные поддерживаемые версии | анализ останавливается до parsing |
| snapshot | уникальный набор path, равный ключам content | construction завершается ошибкой |
| рекурсия String expression | глубина 12 | value unresolved |
| декодированный или объединённый String | 8192 символа | value unresolved |
| cycle констант | повторная identity декларации | value unresolved |
| кандидат type/member | ровно одна доступная identity | identity unresolved |
| раскрытие raw type | 16 шагов | syntax не поддерживается |
| глубина hierarchy | 12 | traversal неполон |
| развёртывание hierarchy | 256 state'ов | traversal неполон |
| дублирующийся source FQN | сохраняются все декларации | зависимые от identity consumer'ы работают fail-closed |
| конфликтующий exact import | явный marker неоднозначности | после этого tier fallback отсутствует |

Это semantic proof limit'ы. Вернуть unresolved безопаснее, чем создать endpoint
по identity, которую engine не может установить.

## 11. Разобранный flow: константа Spring path

Предположим, snapshot содержит:

~~~java
// routes/Paths.java
package routes;
public final class Paths {
    public static final String ROOT = "/api";
}

// app/ItemsController.java
package app;
import static routes.Paths.ROOT;
import org.springframework.web.bind.annotation.GetMapping;

class ItemsController {
    @GetMapping(ROOT + "/items")
    void items() {}
}
~~~

Resolution выполняется так:

1. оба файла входят в один `SourceSnapshot`;
2. создаётся один parser runtime, и каждый файл разбирается один раз;
3. unit controller'а записывает exact import'ы `GetMapping` и static `ROOT`;
4. workspace записывает одну видимую декларацию `routes.Paths` и одну
   доступную константу `ROOT`;
5. Spring доказывает `GetMapping` относительно её точной поддерживаемой
   identity;
6. binary addition требует, чтобы разрешились оба operand'а;
7. ни одна lexical declaration не затеняет `ROOT`, поэтому проверяется exact
   static import;
8. его owner однозначно разрешается в `routes.Paths`, а initializer декодируется
   в `/api`;
9. второй literal декодируется в `/items`, и ограниченная concatenation даёт
   `/api/items`;
10. Spring создаёт типизированное endpoint evidence из того же unit
    controller'а.

~~~mermaid
flowchart TD
    Snap["Byte'ы snapshot"] --> Parse["Один parse на файл"]
    Parse --> Imports["Annotation- и static-import'ы"]
    Parse --> Decls["Декларации type и member"]
    Imports --> Ann{"GetMapping доказан?"}
    Decls --> Root{"ROOT однозначно доступен?"}
    Ann -- нет --> Stop["Endpoint отсутствует"]
    Root -- нет --> Stop
    Ann -- да --> Expr["Вычислить ограниченное выражение"]
    Root -- да --> Expr
    Expr -- unresolved --> Stop
    Expr -- /api/items --> Endpoint["Fact endpoint'а Spring"]
~~~

Flow останавливается, если `ROOT` затенён недопустимым lexical member'ом, его
import конфликтует, `routes.Paths` имеет дублирующиеся source declaration,
field недоступен или не является final при cross-file доступе, initializer
зациклен либо concatenation превышает границу. Он никогда не обходит
неудавшийся tier с более высоким приоритетом.

## 12. Намеренные ограничения

Общий engine — не Java compiler или interpreter. Он не моделирует:

- порядок classpath или произвольный bytecode dependency;
- полную typing, overload resolution или успешность компиляции;
- общий data flow локальных переменных или методов;
- method call'ы, builder'ы, `String.format`, condition'ы, ternary-выражения или
  runtime configuration в значениях annotation;
- полную семантику generic и wildcard;
- reflection, proxy, module visibility или runtime scanning framework'а.

Специализированные analyzer'ы могут реализовать ограниченный framework DSL над
общим tree, но они никогда не владеют Java parsing и не расширяют нейтральный
String resolver до общего исполнения.

Продолжение: [04 — Spring MVC](04-spring-mvc.md).
