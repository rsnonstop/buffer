# 01 — Ментальная модель

## 1. Что представляет собой программа — и чем она не является

`noir_sbt` — статический распознаватель по source-коду. Он использует
Java-синтаксис и намеренно ограниченную semantic model, чтобы доказывать
endpoint fact'ы. Он не использует Maven или Gradle для компиляции кода, не
загружает classpath, не создаёт Spring application context, не запускает
JAX-RS container, не исполняет configuration-методы и не вычисляет
произвольный Java-код.

Этот выбор объясняет центральное правило всей реализации:

> Создавать endpoint, когда identity framework'а, данные route, привязка к
source и явные проверки допустимости текущей ветви статически однозначны; в
противном случае записывать причину в log и пропускать его.

Это поведение «fail closed» на уровне кандидата. Некорректный кандидат обычно
не прерывает scan и не удаляет корректных соседних кандидатов.

## 2. Граница системы

```mermaid
flowchart TB
    subgraph Inputs["Входные данные"]
        J["Java source-файлы"]
        SP["Spring application.properties / yml / yaml"]
        WX["JAX-RS web.xml"]
        CLI["Параметры CLI"]
    end

    subgraph StaticAnalyzer["Статический анализатор noir_sbt"]
        D["Поиск файлов"]
        TS["Tree-sitter parse и query"]
        W["Semantic index'ы всего workspace"]
        SA["Семейство Spring analyzer'ов"]
        JA["Семейство JAX-RS analyzer'ов"]
        WA["Выбираемый пустой stub Wicket"]
        FN["Форматирование, нормализация, объединение evidence"]
    end

    subgraph Outputs["Выходные данные"]
        CSV["CSV endpoint'ов"]
        LOG["Log annotation'ов + diagnostic'ов"]
        ABS["Log annotations-without-endpoints"]
        STD["stdout / stderr / exit status"]
    end

    CLI --> D
    J --> D
    D --> TS --> W
    SP --> SA
    WX --> JA
    W --> SA
    W --> JA
    W --> WA
    SA --> FN
    JA --> FN
    WA -. пока нет fact'ов .-> FN
    FN --> CSV
    W --> LOG
    SA --> LOG
    JA --> LOG
    W --> ABS
    FN --> ABS
    D --> STD
```

Всё, что требует информации за пределами этих source/configuration-входов,
находится вне proof model. Примеры: runtime-условия bean'ов, active profile'и,
bytecode dependency, программно генерируемые строки, reflection за пределами
одной поддерживаемой формы registration, умолчания servlet-container'а, не
закодированные в поддерживаемой source/XML-модели, и route'ы, добавляемые
библиотеками в runtime.

## 3. Слои и направление dependency

[`src/noir_sbt.py`](../src/noir_sbt.py) — только исполняемый launcher. Читайте
приложение от границы команды внутрь:

```mermaid
flowchart TD
    F["noir_sbt.py\nlauncher"] --> C["noir.cli\nэффекты команды"]
    C --> A["noir.application\nтипизированный diagnostic scope"]
    A --> P["noir.pipeline\nоднонаправленный порядок stage'ей"]
    P --> M["noir.model\nнеизменяемые request/result/fact'ы"]
    P --> R["noir.frameworks\nстатическая execution table"]

    P --> J["java_frontend + java_workspace"]
    J --> N["java_ast + java_methods + java_hierarchy"]
    R --> S["Facade spring_framework"]
    R --> X["Facade jaxrs_framework"]
    R --> K["Выбираемый пустой stub wicket_framework"]
    J --> S
    J --> X
    J --> K

    S --> O["noir.output + noir.reports"]
    X --> O
    C --> O
```

Pipeline импортирует статическую execution table, а не конкретные pass'ы
семейств. Эта таблица связывает имя каждого adapter с facade соответствующего
семейства. Facade'ы Spring и JAX-RS принимают общий workspace и request context,
вызывают только собственные специализированные модули и возвращают значения
`EndpointFact`. Service locator, dynamic discovery и dependency между
framework'ами отсутствуют.

Execution table отделена от `discovery.FRAMEWORK_MARKER_RULES`. Detector rules
владеют raw findings и announcement'ами `auto`; execution adapters владеют
порядком выбранных семейств. Одно или несколько явных семейств можно запросить,
повторяя `--framework`; tuple request'а канонизируется в порядке enum, а
эффективный lifecycle независимо восстанавливается в порядке execution table.
Wicket имеет selection identity, поэтому `--framework wicket` запускает его
пустой lifecycle, а `--framework spring --framework wicket` объединяет его со
Spring, не связывая их facade'ы. Его adapter не является default, а marker
остаётся advisory, поэтому режимы с пропущенным параметром и auto его не
запускают.

Package root сразу предоставляет только стабильный model vocabulary. Его
convenience exports `analyze` и `EndpointRowCandidate` загружаются при первом
обращении, поэтому импорт нейтрального submodule не инициализирует parser и все
framework analyzer'ы. `__dir__` по-прежнему объявляет все имена из `__all__`
до разрешения любого из lazy exports.

Блоки диаграммы соответствуют следующим конкретным определениям:

| Понятие на диаграмме | Координата кода | Что там изучать |
|---|---|---|
| граница request и result | [`src/noir/model.py`](../src/noir/model.py) :: `AnalysisRequest`, `AnalysisResult` | Валидация, неизменяемость и данные, которым разрешено пересекать границу приложения |
| полный stage flow | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | Единственный верхнеуровневый порядок discovery, построения workspace и framework-pass'ов |
| execution composition | [`src/noir/frameworks.py`](../src/noir/frameworks.py) :: `FRAMEWORK_ADAPTERS` | Статические hooks семейств, явный/default selection и порядок выполнения Spring–JAX-RS–Wicket |
| orchestration семейств | [`src/noir/spring_framework.py`](../src/noir/spring_framework.py), [`src/noir/jaxrs_framework.py`](../src/noir/jaxrs_framework.py), [`src/noir/wicket_framework.py`](../src/noir/wicket_framework.py) | Точный порядок pass'ов или намеренно пустое поведение внутри каждого независимого семейства |
| представление source | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `SourceSnapshot` и `_snapshot_sources()` | Точный инвариант path/byte, обеспечивающий внутреннюю согласованность запуска |
| parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `build_workspace_runtime()` | Закреплённая dependency-gate и построение query/runtime |
| богатая identity endpoint'а | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` | Route, handler, project, protocol/surface и private evidence до потерь в CSV |
| граница публичной row | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` | Какие богатые поля сохраняются при projection, а какие намеренно отбрасываются |

## 4. Один общий workspace, много семейств endpoint'ов

Сначала `run_analysis()` создаёт неизменяемый `SourceSnapshot`. Затем
нейтральный `java_workspace.build_java_workspace()` создаёт каждый compilation
unit и общие index'ы, включая нейтральные определения source-аннотаций.
`build_workspace_runtime()` один раз компилирует полный общий набор query.

Pipeline создаёт отдельное состояние только для выбранных семейств:
`JaxRsState` владеет интерпретацией JAX-RS и deployment data, а
`SpringAnnotationState` — cache проверки source-определений. Общий
`JavaWorkspace` содержит только Java facts. Callback'и recognition каждого
семейства получают его собственное состояние и передают смыслы annotation'ов
нейтральному inventory builder. После построения обоих inventory каждый
выбранный adapter с preparation hook завершает подготовку project'а до запуска
любого analyzer'а.
Именно здесь строится deployment evidence JAX-RS. Затем выбранные facade'ы
выполняют анализ в порядке registry: Spring, JAX-RS и, если выбран, Wicket.
Порядок опций CLI и входной порядок программного tuple не меняют эту
последовательность. Если Wicket передан как единственный explicit mode,
выбирается только Wicket. Ни один framework-pass повторно не разбирает source,
уже находящийся в workspace.

Временные слои пути Spring client остаются внутри client pass. Выдаваемые им
значения `EndpointFact` содержат разрешённые client path и общее evidence;
общая model не содержит незавершённых полей конфигурации Spring.

```mermaid
flowchart LR
    F["Каждый найденный Java-файл"] --> U["Compilation unit"]
    U --> T["Типы и lexical nesting"]
    U --> I["Import'ы и package"]
    U --> C["Строковые константы"]
    U --> A["Вхождения и определения annotation'ов"]
    T --> W["Workspace index'ы"]
    I --> W
    C --> W
    A --> W
    W --> X1["Direct decoder'ы"]
    W --> X2["Hierarchy graph'ы"]
    W --> X3["Распознаватели Functional/DSL"]
    W --> X4["Audit inventory"]
```

Workspace охватывает всё source-дерево, а не один файл, потому что path'ы и
route annotation'ы могут зависеть от:

- констант, объявленных в других файлах;
- exact- и wildcard-import'ов;
- вложенных типов или типов из того же package;
- source-defined composed annotation'ов;
- custom JAX-RS annotation'ов HTTP-метода;
- generic interface'ов и abstract base class'ов;
- return type'ов subresource;
- принадлежности к project.

Четыре подписи справа на диаграмме обозначают разные представления логики
приложения над одним и тем же разобранным source:

- **Workspace index** — это lookup-таблица текущего запуска, построенная по
  всем разобранным файлам. Например, key `"demo.Paths"` может указывать на
  единственную source-декларацию типа, а key `("demo.Paths", "ROOT")` — на
  декларацию с initializer `"/api"`. Index не придумывает Java-семантику, а
  лишь позволяет искать между файлами уже найденные декларации.
- **Direct decoder** читает route evidence, прикреплённое непосредственно к
  декларации, о которой будет создан результат. Например, Spring decoder
  может сразу превратить `@GetMapping("/items") void list()` в `GET /items`,
  не переходя по edge наследования или registration.
- **Hierarchy graph** связывает видимые из source типы с их видимыми из source
  родителями и методами. Например, перед созданием endpoint он может связать
  interface method `ItemsApi.list()` с `@GetMapping("/items")` и concrete
  implementation `ItemsController.list()`.
- **Functional/DSL recognizer** интерпретирует одну явно поддерживаемую цепочку
  Java-вызовов как декларативные данные route. Например,
  `RouterFunctions.route(GET("/items"), handler::list)` задаёт route, хотя на
  `list()` нет route annotation.

Index хранит доступное для поиска evidence; decoder или recognizer придаёт
этому evidence framework-смысл; hierarchy graph обеспечивает source-level
binding между декларациями. Конкретные структуры index'ов и разобранные
значения собраны в
[главе со словарём](11-naming-and-code-vocabulary.md#workspace-and-index-vocabulary).

## 5. Каталог семейств endpoint'ов

Следующая таблица — высокоуровневая dispatch-карта. Подробные proof condition'ы
приведены в главах о framework'ах.

| Семейство | Распознаваемая source-форма | Внутренний surface | Форма публичного `interface_type` |
|---|---|---|---|
| Spring MVC direct | `@GetMapping`, другие shortcut'ы, `@RequestMapping`, поддерживаемые composed mapping'и | server | `http <verb>` |
| Spring MVC hierarchy | Mapping на interface/abstract contract, привязанный к методу concrete controller | server | `http <verb>` |
| Spring functional | Servlet/WebFlux `RouterFunction` в настоящем publisher'е `@Bean` | server | `http <verb>` |
| Spring programmatic MVC | Ограниченный graph `RequestMappingHandlerMapping.registerMapping` | server | `http <verb>` |
| Spring Cloud Gateway | Ограниченный Java DSL `@Bean RouteLocator` | gateway | `http-gateway <verb>` |
| Spring static resources | `WebMvcConfigurer.addResourceHandlers` | static-handler | `http-static-handler GET` |
| Spring HTTP Interface | `@HttpExchange` / фиксированные exchange annotation'ы на interface'ах | client | `http-client <verb>` |
| Spring OpenFeign | Interface с `@FeignClient` и MVC mapping'ами | client | `http-client <verb>` |
| Spring raw/STOMP handshake | Registration'ы `WebSocketConfigurer` или `WebSocketMessageBrokerConfigurer` | websocket-handshake | `ws GET` |
| Spring messaging | Controller с `@MessageMapping` / `@SubscribeMapping` | message | `ws SEND` / `ws SUBSCRIBE` |
| JAX-RS direct | Concrete class/record с `@Path` и public designator method | default server | `http <verb>` |
| JAX-RS hierarchy | Annotation bundle interface/abstract-контракта, привязанный по erased signature | default server | `http <verb>` |
| JAX-RS subresource | Один или несколько типизированных locator-edge'ей `@Path`, ведущих к leaf | default server | `http <verb>` |
| Java WebSocket | Javax/Jakarta class/record с `@ServerEndpoint` | websocket | `ws GET` |

Для protocol'ов, отличных от HTTP, formatter отбрасывает подтип surface.
Поэтому Spring handshake и JAX WebSocket handshake оба превращаются в CSV в
`ws GET`.

### Почему различаются HTTP interface types

Все четыре формы `http...` используют protocol HTTP. Суффикс не обозначает
другой wire protocol; он сохраняет роль endpoint'а в приложении в публичном
report из семи колонок:

| `interface_type` | Кто инициирует/обслуживает трафик | Пример |
|---|---|---|
| `http GET` | анализируемое приложение обслуживает обычный inbound HTTP route | `@GetMapping("/items")` |
| `http-gateway GET` | приложение работает как gateway, сопоставляет и перенаправляет inbound HTTP request | `route().GET("/items", ...).uri("lb://inventory")` |
| `http-static-handler GET` | Spring обслуживает настроенный static-resource path вместо вызова обычного endpoint controller'а | `addResourceHandler("/assets/**")` |
| `http-client GET` | код приложения объявляет outbound HTTP operation к другому service | `@GetExchange("/items")` на client interface |

Таким образом, `http` — это префикс protocol, а необязательный суффикс —
классификация surface. Благодаря ей outbound client contract, forwarding rule
или mapping static resource не выглядят как inbound business handler.

## 6. Три identity внутри одного endpoint fact

Некоторые analyzer'ы различают:

1. **route declaration** — место объявления path/verb;
2. **concrete handler** — method/type, сообщаемый как реализация endpoint'а;
3. **project owner** — тот, чья Spring/JAX configuration задаёт base path.

Эти identity соответствуют одноимённым полям `EndpointFact` следующим образом:

| Поле | Значение с точки зрения логики приложения | Значение в примере ниже |
|---|---|---|
| `source_file` | source identity, публикуемая в endpoint row; обычно concrete-декларация, которую следует открыть читателю | `ItemsController.java` |
| `route_source_file` | декларация, задавшая семантику route, например path и verb | `ItemsApi.java`, поскольку `@GetMapping` находится на его interface method |
| `handler_source_file` | concrete-декларация кода, которой приписана обработка operation | `ItemsController.java` |
| `project_source_file` | владелец source/configuration, по которому выбирается path configuration уровня project; route или handler могут находиться не в нём | `Routes.java` |

Для direct controller method все четыре поля могут указывать на один файл.
Они расходятся лишь тогда, когда в одном fact участвуют contract, concrete
implementation и project configuration. `source_line` служит локальным
diagnostic context; `route_source_line` и `handler_source_line` указывают на
соответствующие provenance-декларации.

У direct-метода все три обычно находятся в одном файле. Они могут расходиться:

```mermaid
flowchart LR
    C["Контракт interface\n@GetMapping('/items')"] -->|"source route"| E["Внутренний endpoint fact"]
    H["Конкретный controller\nItemsController.list()"] -->|"handler + source для CSV"| E
    P["Модуль publisher/configuration"] -->|"владелец base path"| E
    E --> R["Строка CSV"]
    R --> O["Остаются только concrete source/method"]
```

Типизированное значение может переносить все три identity, не предоставляя
наружу изменяемую row-форму:

```python
EndpointFact(
    path="/api/items",
    method="GET",
    parameters="String filter",
    source_file=SourceFile("/workspace/app/ItemsController.java"),
    source_line=42,
    handler_name="ItemsController.list",
    route_source_file=SourceFile("/workspace/contracts/ItemsApi.java"),
    route_source_line=12,
    handler_source_file=SourceFile("/workspace/app/ItemsController.java"),
    handler_source_line=42,
    project_source_file=SourceFile("/workspace/app/Routes.java"),
    technology="spring",
    protocol="http",
    surface="server",
    direction="inbound",
    annotation_evidence=(...),
    represented_targets=(...),
)
```

Не каждый analyzer заполняет каждое необязательное поле provenance или
classification. Projection принимает только `EndpointFact`, сохраняет
типизированное evidence до consolidation и не копирует `source_line` напрямую
в CSV.

### Значения `surface`

`surface` отвечает на вопрос: «какую роль в приложении представляет этот
endpoint fact?» Оно не зависит от `protocol` и вместе с `direction`
используется при построении публичного `interface_type`.

| Значение | Смысл | Типичные protocol/direction |
|---|---|---|
| `server` | обычный route, обслуживаемый анализируемым приложением | `http` / `inbound` |
| `gateway` | route Spring Cloud Gateway для match и forwarding | `http` / `inbound` |
| `static-handler` | mapping Spring handler'а для static resource | `http` / `inbound` |
| `client` | outbound contract Spring HTTP Interface или OpenFeign | `http` / `outbound` |
| `websocket-handshake` | registration HTTP upgrade/handshake в Spring | `ws` / `inbound` |
| `message` | STOMP-подобный message destination, а не HTTP request | `ws` / `inbound` |
| `websocket` | аннотированный Javax/Jakarta WebSocket server endpoint | `ws` / `inbound` |

Значение по умолчанию — `server`, поскольку обычные fact'ы Spring MVC и JAX-RS
встречаются чаще всего. Producer задаёт более точное значение лишь после
доказательства соответствующего framework surface.

Сейчас `surface` является строкой, а не закрытым enum. В таблице перечислены
все значения, выдаваемые production analyzer'ами; при программном создании
можно передать другую строку, и она будет спроецирована в дополнительную метку
`http-<surface>`. Spring path resolver также распознаёт compatibility-метки
`proxy` и `resource`, хотя ни один текущий endpoint producer их не выдаёт.

## 7. Pass'ы, работающие по принципу additions-only

Direct pass'ы Spring и JAX-RS покрывают простые concrete annotation'ы.
Hierarchy-, route-registration- и другие специализированные extraction-pass'ы
добавляют fact'ы, которые они могут доказать сверх этой основы; локальное для
кандидата отклонение в одном из таких pass'ов не удаляет несвязанный direct
fact. Для server и messaging описание additions-only заканчивается на
extraction: более поздний Spring configuration pass переписывает их path и
может удалить fact, чей настроенный path не удалось разрешить. Client pass
разрешает path внутри себя и выдаёт только успешно настроенные fact'ы.
Неожиданное исключение в любом pass'е прерывает весь запуск.

```mermaid
flowchart TD
    SD["Direct Spring fact'ы"] --> SA["Добавить Spring registration, hierarchy и server/messaging surface'ы"]
    SA --> C["Применить Spring configuration к server/messaging; fact'ы могут быть удалены"]
    CL["Spring client pass разрешает свои path"] --> M
    JD["Direct JAX-RS fact'ы"] --> JA["Добавить JAX-RS hierarchy, locator- и WebSocket-fact'ы"]
    C --> M["Объединить fact'ы выбранных framework'ов"]
    JA --> M
    M --> N["Нормализовать"]
    N --> G["Сгруппировать по публичной шестиполевой identity"]
    G --> R["Одна итоговая row на identity"]
```

Итоговая identity включает concrete source, имя метода и сырой текст
параметров. Два handler'а с одинаковыми method/path остаются двумя row'ами,
если эти поля различаются.

## 8. Два значения слова «строка»

Есть два несвязанных понятия строки:

- `source_line` — внутренняя diagnostic-строка analyzer'а; в зависимости от
  ветви это может быть route call, handler method, annotation или type.
- `method_annotation_line` позже выбирается из проверенного same-source
  evidence annotation'а метода.

Они не взаимозаменяемы. Non-annotation route'ы и унаследованные cross-file
mapping'и могут иметь осмысленный внутренний `source_line`, тогда как колонка
CSV остаётся пустой.

## 9. Детерминизм и полнота

Реализация уделяет большое внимание детерминированному порядку и отклонению
неоднозначностей:

- сортированный discovery;
- точные source identity;
- фиксированный порядок framework'ов и HTTP-методов;
- порядок по source-byte;
- детерминированная локальная и итоговая deduplication;
- ограниченный graph traversal;
- отклонение нескольких равноценных допустимых binding'ов.

Эти свойства делают повторные результаты доступными для audit, но не
доказывают полноту. Корректный Java-код, который анализатор не поддерживает или
считает неоднозначным, может быть пропущен. Поэтому diagnostic'и и
report annotations-without-endpoints являются частью результата, а не
необязательным шумом.

Далее: [02 — CLI и orchestration](02-cli-and-orchestration.md).
