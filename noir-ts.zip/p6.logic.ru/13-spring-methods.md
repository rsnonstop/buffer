# 13 — Выполнение и data flow Spring на уровне методов

[← Методы core runtime](12-core-runtime-methods.md) · [Оглавление](README.md) ·
[Методы JAX-RS, evidence и output →](14-jaxrs-output-methods.md)

Эта глава дополняет главы уровня модулей [Spring MVC](04-spring-mvc.md) и
[дополнительные поверхности Spring](05-spring-additional-surfaces.md) картой
важных функций и методов на уровне source. Для каждой ветви она отвечает на
четыре вопроса:

1. кто её вызывает;
2. какие данные входят и выходят;
3. какие решения приводят к выдаче результата или fail-closed; и
4. где создаются или объединяются endpoint facts, diagnostics и типизированное
   evidence.

Авторитетным источником служит source-код. Координаты используют `module.symbol`, поэтому
поиск точного Python symbol в этом файле приводит к описанию его contract, даже когда
несколько модулей используют helper-имена вроде `_resolve_path()` или
`_deduplicate()`.

## 1. Правила чтения

### 1.1 Общие формы данных

| Форма | Значение при чтении call graphs |
|---|---|
| `unit` | Один уже разобранный Java compilation unit: точные source bytes, узлы Tree-sitter, imports, записи лексических типов и query captures. |
| `workspace` | Общий parse-once workspace и его cross-file indexes. Spring passes потребляют те же identities узлов. |
| `MethodFact` / `MethodIndex` | Нормализованная identity source method и lookup tables, созданные `java_methods`; используются DSL- и reflection-analyzer'ами. |
| декодированный MVC `mapping` | Dictionary, содержащий `paths`, `methods`, `valid`, `annotation_node` и, для mappings, создающих evidence, `annotation_identity` и `annotation_family`. |
| `EndpointFact` | Неизменяемый богатый endpoint до переписывания configured path и lossy-границы CSV. Provenance route, handler, project, annotation и represented target остаются раздельными. |
| `spring_clients._ClientCandidate` | Локальная для client пара raw `EndpointFact` и optional лексических path layers HTTP Interface; из client pass выходят сконфигурированные обычные facts. |
| `SpringAnnotationState` | Принадлежащий Spring cache поддержки composed-definition, общий для broad и final распознавания аннотаций. |
| `None` | Обычно «не доказано» или «не распознано». На границах первого mapping распознанный невалидный mapping вместо этого возвращается с `valid=False`, чтобы более поздняя аннотация не могла его заменить. |
| пустой tuple/list | Успешный pass или branch, не выдавший дополнений. Он не удаляет facts, выданные другим analyzer. |

### 1.2 Инварианты, общие для этих модулей

- Parsing находится за пределами каждого Spring analyzer. Analyzers получают
  общий workspace и никогда не создают другой parser.
- Name resolution доказывает настоящую framework identity через imports,
  source declarations, accessibility и правила shadowing. Совпадения простого
  имени недостаточно.
- Static strings разрешаются общим ограниченным workspace resolver. Эти
  модули не исполняют Java.
- Неопределённость candidate обычно приводит к fail-closed на наименьшей
  безопасной границе. Неожиданное Python exception — другое дело: оно выходит
  наружу и прерывает run.
- Каждый созданный `EndpointFact` неизменяем. Configuration использует
  `dataclasses.replace()`, а не mutation.
- `source_line` — diagnostic context. Значение annotation-line в CSV берётся
  только из проверенного `annotation_evidence` на более поздней output-границе.
- Запись diagnostic — обычный side effect. Нейтральные определения annotation
  уже присутствуют к началу Spring; cache поддержки composed-definition
  принадлежит `SpringAnnotationState`, а загрузка configuration — намеренное
  чтение filesystem этим семейством. Java workspace остаётся нейтральным.

## 2. Сквозной call graph Spring

`spring_framework.analyze_spring_framework()` — production facade для
рассматриваемых Spring-модулей; он фиксирует их порядок:

```mermaid
flowchart TD
    P["spring_framework.analyze_spring_framework<br/>(request, source paths, workspace, state)"] --> D["для каждого unit:<br/>spring_mvc.analyze_direct_spring_mvc_unit"]
    D --> R["spring_route_registrations.<br/>analyze_spring_route_registrations"]
    R --> H["spring_mvc_hierarchy.<br/>analyze_spring_mvc_hierarchy"]
    H --> G["spring_gateway.<br/>analyze_spring_gateway"]
    G --> S["spring_config.<br/>analyze_spring_resource_handlers"]
    S --> B["spring_config.<br/>build_spring_path_configuration"]
    B --> C["spring_clients.<br/>analyze_spring_http_clients(workspace, configuration)"]
    C --> W["spring_websocket_messaging.<br/>analyze_spring_websocket_and_messaging"]
    W --> A["spring_config.<br/>apply_spring_path_configuration<br/>для групп server и messaging"]
    A --> O["сконфигурированный tuple[EndpointFact, ...]"]
```

Стадии server сначала собирают raw facts. Для clients нужна project configuration,
чтобы разрешить каждый лексический path до возврата обычных facts; messaging
использует её для группировки STOMP prefixes по project. Финальные вызовы
configuration переписывают только группы raw server и messaging facts.
Результат сохраняет установленный порядок server/client/messaging, а
configuration применяется один раз к каждому fact. Diagnostics загрузки
configuration появляются до extraction clients; client builders по-прежнему
записывают raw paths candidates до локального resolution или отклонения.

Необязательный callback `GatewayPathResolver` полезен автономным callers
`analyze_spring_gateway()`. Production facade его не передаёт; вместо этого
Gateway facts входят в общую однократную стадию configuration.

## 3. `spring_mvc.py`: прямые mappings и составные аннотации

### 3.1 Call graph прямого MVC

```mermaid
flowchart TD
    A["analyze_direct_spring_mvc_unit(unit, workspace)"] --> T["first_spring_mapping(аннотации type)"]
    A --> M["first_spring_mapping(аннотации method/component)"]
    T --> F["compose_lexical_type_mapping"]
    M --> B["decode_builtin_spring_mapping"]
    M --> C["decode_spring_composed_mapping"]
    B --> P["get_spring_annotation_paths"]
    B --> V["get_spring_request_methods"]
    P --> SR["resolve_workspace_string_expression"]
    V --> MR["resolve_spring_request_method_expression"]
    F --> X["Cartesian product paths + упорядоченный union методов"]
    X --> E["EndpointFact для каждой пары path/method"]
    E --> AE["method_annotation_evidence_from_mapping<br/>(только обычные методы)"]
    E --> RT["represented_target_evidence<br/>(method или record-component)"]
```

### 3.2 Контракты прямого mapping

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_mvc.resolve_spring_mapping_name()` | Встроенные decoders и фильтрация компонентов; узел имени аннотации → встроенное simple name или `None`. | Принимает только точный FQN, exact import или однозначный настоящий wildcard import Spring. Видимые лексические types, package types и wildcard collisions затеняют имя библиотеки. Без side effects. |
| `spring_mvc.get_spring_annotation_paths()` | Встроенные decoders и decoders поддержки inventory; occurrence аннотации → `{values, unresolved, present}`. | Согласует positional/`value`/`path`; aliases должны разрешиться в один упорядоченный tuple. Любое неразрешённое выбранное value удаляет всё размножение path. Values получают начальный slash и сохраняют порядок первого появления. |
| `spring_mvc.resolve_spring_request_method_expression()` | Decoders request-method и alias-value; enum expression → canonical verb или `None`. | Принимает только настоящие элементы `RequestMethod` через qualified identity или однозначный static import. Не делает вывод только по token. |
| `spring_mvc.get_spring_request_methods()` | Встроенные decoders и decoders поддержки inventory; occurrence `RequestMapping` → `{values, unresolved, present}`. | Отсутствующий/пустой `method` не ограничен. Сохраняет валидные элементы, сообщая caller о невалидных spellings; все явно заданные невалидные values могут сделать mapping невалидным. |
| `spring_mvc.ordered_http_methods()` | Decoders и composers методов; iterable → уникальные verbs в порядке `SPRING_HTTP_METHODS`. | Детерминированный pure helper; неподдерживаемые tokens исключаются, поскольку callers доказывают их заранее. |
| `spring_mvc.union_request_method_conditions()` | Композиция direct, hierarchy и Feign; списки type и method → стабильный упорядоченный union. | Пустая сторона нейтральна. Это намеренная union-модель Noir, а не intersection Spring runtime. |
| `spring_mvc.log_unresolved_mapping()` | `decode_builtin_spring_mapping()`; source/owner/kind/expressions → без return value. | Добавляет один run-local diagnostic для каждого неразрешённого expression; не вызывает exception и не редактирует mappings. |
| `spring_mvc.decode_builtin_spring_mapping()` | `first_spring_mapping()`, hierarchy и Feign; одна аннотация → mapping dictionary или `None`. | `None` означает, что это не настоящий built-in. Распознанная аннотация возвращает mapping даже при невалидности. Фиксированные verbs берутся из shortcut identity; verbs `RequestMapping` декодируются. Подключает canonical identity/family для последующего evidence. |
| `spring_mvc.first_spring_mapping()` | Прямой анализ type/method/component; захваченные аннотации → первый mapping или `None`. | Сортирует по позиции аннотации в source, пробует встроенное, затем составное декодирование и останавливается на первом распознанном результате. Поэтому recognized-invalid подавляет более поздние валидные аннотации declaration. |
| `spring_mvc.compose_lexical_type_mapping()` | Прямой анализ method/component; owner key плюс локальная копия type-info → составные type paths/methods или `None`. | Проходит лексические types снаружи внутрь. Отсутствующий mapping нейтрален; один recognized-invalid слой подавляет каждый target-потомок. Paths образуют Cartesian product, а methods — упорядоченный union. |
| `spring_mvc.spring_method_applicable_component_candidates()` | Ветка компонента record; захваченные аннотации component → отфильтрованные captures. | Built-ins принимаются; source-аннотации должны разрешиться и быть применимы к `METHOD`. Не позволяет переинтерпретировать аннотацию только для component/field как method-аннотацию неявного accessor. |
| `spring_mvc.analyze_direct_spring_mvc_unit()` | Production Spring loop; один unit плюс общий workspace → tuple прямых facts. | Копирует `type_infos` до подключения локальных для анализа mappings. Обычные методы конкретных видимых в workspace owners и подходящие неявные accessor record размножаются по лексическим/type/method paths и verbs. Abstract/invisible owners, явные accessors, отсутствующие/невалидные mappings или невалидные лексические слои пропускают только target. Каждый fact диагностируется. Локальная deduplication не выполняется. |

Для обычного метода `analyze_direct_spring_mvc_unit()` заполняет request
parameters raw-текстом списка параметров source, создаёт annotation evidence
из выбранного mapping и представляет точный span метода. Для неявного accessor
record он выдаёт пустые parameters, намеренно не создаёт evidence аннотации
метода и представляет span компонента record.

### 3.3 Call graph составной аннотации и `AliasFor`

```mermaid
flowchart TD
    I["workspace annotation_definitions"] --> SD["source_annotation_definition"]
    U["decode_spring_composed_mapping(применённая аннотация)"] --> SD["source_annotation_definition"]
    SD --> BR["collect_spring_mapping_branches"]
    BR -->|recursive meta-annotations| BR
    BR --> RR["spring_definition_runtime_retained"]
    RR --> LF["decode_builtin_spring_mapping(leaf RequestMapping)"]
    LF --> PE["parse_spring_alias_edge(каждый element)"]
    PE --> AT["resolve_spring_alias_terminal"]
    AT -->|edge custom-ветви| AT
    AT --> TV["validators type/cardinality/ignored-target"]
    TV --> IV["annotation_instance_values(каждый слой)"]
    IV --> DV["декодировать явные path/method values или defaults"]
    DV --> OV["fold override изнутри наружу"]
    OV --> CM["canonical mapping с внешним applied node + FQN"]

    INV["inventory аннотаций"] --> SUP["spring_composed_definition_is_supported"]
    SUP --> BR
    SUP --> PE
    SUP --> AT
```

### 3.4 Контракты составного mapping

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_mvc.spring_definition_runtime_retained()` | Validation составного use/support; definition → boolean. | Требует ровно один настоящий `java.lang.annotation.Retention` и доказуемое значение `RUNTIME`. |
| `spring_mvc.resolve_spring_mapping_spelling()` | Traversal meta-annotation и resolution class-literal; spelling → built-in name или `None`. | Та же collision-safe политика identity, что у resolution прямой аннотации, но работает с сохранённым spelling/context. |
| `spring_mvc.source_annotation_definition()` | Composed decoder, traversal и applicability component; applied name → status плюс definition. | Различает `none`, `missing`, `ambiguous`, `inaccessible` и `resolved`. Только одна source identity, одно declaration и доступный owner дают `resolved`. |
| `spring_mvc.source_annotation_is_method_applicable()` | Фильтрация component; occurrence аннотации → boolean. | Разрешает одно source definition и делегирует настоящую семантику `@Target` helper workspace. |
| `spring_mvc.collect_spring_mapping_branches()` | Composed decoder и validator inventory; definition → branches плюс errors. | Рекурсивно идёт через source meta-annotations к leaf `RequestMapping`, отвергает циклы и depth свыше `SPRING_MAX_COMPOSED_ANNOTATION_DEPTH`, а также verb shortcuts как leaves declaration аннотации. Несвязанные meta-annotations игнорируются. |
| `spring_mvc.resolve_alias_annotation_target()` | Parser alias edge; значение `AliasFor.annotation` → target FQN или `None`. | Требует class literal, называющий один настоящий built-in или одну доступную уникальную source-аннотацию. |
| `spring_mvc.parse_spring_alias_edge()` | Resolution terminal и validation definition; один annotation element → typed edge status. | Требует ровно один настоящий `AliasFor`; проверяет grammar positional/named arguments, reciprocal names, static String resolution и annotation target. Возвращает `none`, `resolved` или `invalid` с причиной. |
| `spring_mvc.resolve_ignored_sibling_alias_target()` | Resolver terminal; custom target вне ветви → ignored-custom terminal или invalid. | Допускает только одну доступную runtime-retained прямую sibling meta-annotation с одним non-recursive target element и валидным fixed occurrence. Значение проверяется, но исключается из route identity. |
| `spring_mvc.resolve_spring_alias_terminal()` | Composed decoder/support validator; definition element плюс branch maps → status terminal. | Рекурсивно следует alias edges; отвергает циклы elements, edges наружу, отсутствующие/неоднозначные elements, несовместимые формы и невзаимные local pairs. Canonical route terminals — `path` или `method`; известные non-route RequestMapping и ограниченные custom terminals проверяются и помечаются ignored. |
| `spring_mvc.annotation_instance_values()` | Composed use и sibling validation; definition плюс occurrence → explicit element map или error. | Связывает positional input с `value`, отвергает неизвестные/дублирующиеся формы и требует value/default для каждого обязательного element. Значения не декодирует. |
| `spring_mvc.decode_spring_alias_path_value()` | Fold составного value; value expression → упорядоченный tuple или `None`. | Каждый member array должен статически разрешаться как String; один неразрешённый member отвергает выбранное value. |
| `spring_mvc.decode_spring_alias_method_value()` | Fold составного value; value expression → tuple методов или `None`. | Каждый member должен быть настоящим Spring expression `RequestMethod`. |
| `spring_mvc.invalid_spring_composed_mapping()` | Error branches composed decoder; applied node → mapping `valid=False`. | Кодирует «распознано, но невалидно», сохраняя подавление по первому распознанному без выдуманной identity/evidence. |
| `spring_mvc.log_spring_composed_issue()` | Composed decoder; context плюс reason → без return value. | Записывает только diagnostic уровня candidate. |
| `spring_mvc.decode_spring_composed_mapping()` | `first_spring_mapping()`, hierarchy и Feign; применённая source-аннотация → mapping, invalid mapping или `None`. | Требует одно доступное definition, ровно одну ограниченную branch, runtime retention каждого custom layer, валидный leaf, согласованные alias terminals/types/defaults и instance values. Выполняет fold от fixed leaf через custom layers изнутри наружу, где explicit values предшествуют defaults. При успехе overrides path/method заменяют leaf, а identity/node evidence становятся внешней применённой аннотацией. |
| `spring_mvc.spring_composed_definition_is_supported()` | Callbacks аннотаций Spring; source definition и optional cache → boolean. | Повторяет validation graph, leaf, edge, type/default и fixed intermediate-instance на уровне definition, но намеренно не проверяет occurrence внешнего consumer. Устанавливает `False` до recursion и кеширует итоговый `True` в cache caller `SpringAnnotationState.definition_support`; автономные вызовы используют новый локальный cache. |

### 3.5 Helpers для validation alias

Эти helpers малы, но важны при диагностике того, почему правдоподобный
составной mapping завершился неудачно:

| Координата | Точная ответственность |
|---|---|
| `spring_mvc.decode_alias_string()` | Разрешить имя alias attribute с общей семантикой String. |
| `spring_mvc.spring_alias_element_type_valid()` | Требовать `String`/`String[]` для terminal path или `RequestMethod`/array для terminal method. |
| `spring_mvc.spring_alias_non_output_type_valid()` | Проверить форму String для route-neutral attributes RequestMapping. |
| `spring_mvc.spring_alias_value_cardinality_valid()` | Отвергнуть array initializer, переданный в scalar element; arrays принимают scalar или array input. |
| `spring_mvc.spring_alias_known_type_shape()` | Канонизировать поддерживаемые формы scalar/array для primitive, String и RequestMethod. |
| `spring_mvc.spring_alias_custom_types_compatible()` | Разрешить одинаковые формы и поток scalar-to-array, но не array-to-scalar. |

## 4. `spring_mvc_hierarchy.py`: привязка contracts к implementations

### 4.1 Call graph и data graph

```mermaid
flowchart TD
    E["analyze_spring_mvc_hierarchy(workspace)"] --> C["SpringMvcHierarchyAnalyzer(workspace)"]
    C --> A["analyze"]
    A --> R["_is_direct_mvc_controller(root)"]
    R --> CE["_controller_hierarchy_endpoints(root)"]
    CE --> HC["JavaSourceHierarchyGraph._build_hierarchy_context"]
    HC --> SG["_all_signatures"]
    SG --> IM["_implementation(signature)"]
    IM --> MS["_resolve_mapping_source"]
    MS --> IB["_interface_mapping_branches"]
    MS --> MM["caches _method_mapping / _type_mapping"]
    MM --> DA["_decode_annotations"]
    DA --> MVC["встроенный или составной MVC decoder"]
    MVC --> PC["type controller + type contract + условия method"]
    PC --> F["EndpointFact, приписанный конкретной implementation"]
```

### 4.2 Контракты методов

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer.__init__()` | Public wrapper; workspace → instance analyzer. | Строит один нейтральный `JavaSourceHierarchyGraph` и instance-local caches mapping type/method. Не выдаёт facts. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._is_direct_mvc_controller()` | `analyze()`; запись type → boolean. | Требует конкретный видимый в workspace class и настоящий прямой `Controller` или `RestController`. Records, составные stereotypes и наследуемые stereotypes не активируют этот pass. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._decode_annotations()` | Caches mapping; аннотации declaration → первый mapping или `None`. | Сортирует прямые аннотации по source и применяет то же поведение «встроенный, затем составной; первый recognized-invalid», что и прямой MVC. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._method_mapping()` | Выбор source/implementation; точный method → cached mapping. | Cache key — точная identity method, а не его имя. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._type_mapping()` | Композиция controller/contract; type → cached mapping. | Cache key — source FQN; участвуют только прямые аннотации type. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._interface_mapping_branches()` | `_resolve_mapping_source()`; адаптированное состояние interface и erased signature → candidate origins плюс blocked flag. | Ограниченный recursive traversal отвергает циклы/depth overflow, недоступные types/methods, дублирующиеся совпадающие declarations, невалидные interface edges и неоднозначные paths. Memoization локальна одному resolution. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._resolve_mapping_source()` | Loop endpoint controller; implementation/signature/hierarchy → одно mapped declaration/environment или `None`. | Прямой mapping на конкретном root оставляется прямому MVC. Иначе предпочитает подходящую mapped implementation, затем ближайший доступный abstract-class contract, затем один максимально специфичный interface origin. Blocked или конкурирующие origins пропускают signature. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._all_signatures()` | Loop endpoint controller; context hierarchy → erased signatures плюс unresolved names. | Обходит class states и ограниченные interface states с generic environments. Если какое-либо declaration имени метода не может дать erased signature, все same-name signatures консервативно пропускаются. Вложенные `add_methods()` и `visit()` владеют collection и предотвращением циклов. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._implementation()` | Loop endpoint controller; signature/hierarchy → одно состояние concrete/default implementation или `None`. | Выбирает первую пригодную class implementation, иначе один максимально специфичный default method interface. Private/static/abstract/bodyless или неоднозначные candidates делают эту signature неуспешной. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._mapping_conditions()` | Loop endpoint controller; optional mapping → слой path/method или `None`. | Отсутствие нейтрально: `([""], [])`; recognized-invalid подавляет; валидные values копируются. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._controller_hierarchy_endpoints()` | `analyze()`; активированный controller root → additions. | Требует полной hierarchy. Для каждой sound signature связывает implementation и source mapping, композит слои type controller, type contract-owner и method, затем создаёт facts. Handler/source/parameters/target берутся из implementation; route provenance — из contract; project provenance — из root. Если mapping annotation и implementation находятся на разных methods, evidence для mapping method намеренно остаётся пустым. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer.analyze()` | Public wrapper; состояние analyzer → tuple facts. | Детерминированно обходит source FQNs и анализирует только активированные roots. Единственные effects — diagnostics и instance caches. |
| `spring_mvc_hierarchy.analyze_spring_mvc_hierarchy()` | Pipeline; workspace → tuple дополнений hierarchy. | Создаёт один analyzer и возвращает `analyze()`. Никогда не подавляет уже собранные direct facts. |

Меньшие guards hierarchy тоже доступны для поиска здесь:
`SpringMvcHierarchyAnalyzer._log()` записывает rejection уровня root;
`SpringMvcHierarchyAnalyzer._is_mapping_contract_type()` допускает interfaces
и abstract classes; `SpringMvcHierarchyAnalyzer._type_accessible()` и
`SpringMvcHierarchyAnalyzer._method_accessible()` обеспечивают source
accessibility; а `SpringMvcHierarchyAnalyzer._implementation_usable()` требует
конкретное instance body (или default body interface).

## 5. `spring_route_registrations.py`: functional и imperative MVC DSL

Модуль строит один `MethodIndex`, запускает два независимых analyzers, добавляет
их facts и выполняет локальную для analyzer deduplication с сохранением
evidence.

### 5.1 Call graph для functional routes

```mermaid
flowchart TD
    E["analyze_spring_route_registrations"] --> IX["_build_method_index(workspace)"]
    IX --> AF["_analyze_functional_routes"]
    AF --> AG["owner + уникальный source + @Bean + семейство RouterFunction"]
    AG --> RET["_single_direct_return"]
    RET --> EX["_decode_functional_expression"]
    EX --> DR["route(predicate, handler)"]
    EX --> AR["andRoute(...)"]
    EX --> NE["nest(...)"]
    EX --> BU["_decode_builder -> _decode_builder_chain"]
    DR --> PR["_decode_predicate"]
    AR --> PR
    NE --> SP["_decode_selecting_predicate(path)"]
    BU --> BA["_decode_builder_route_arguments"]
    PR --> SP
    SP --> NP["_is_route_identity_neutral_predicate"]
    DR --> HD["_decode_handler"]
    AR --> HD
    BA --> HD
    HD --> HB["_bind_this_handler при точном совпадении"]
    EX --> EP["_handler_endpoint"]
    EP --> F["EndpointFact + represented target метода"]
```

### 5.2 Контракты functional route

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_route_registrations._known_direct_annotation()` | Оба семейства analyzer; declaration плюс ожидаемая identity → уникальная аннотация или `None`. | Требует ровно одну настоящую прямую аннотацию. Optional `marker_only` также отвергает arguments аннотации. |
| `spring_route_registrations._owner_is_concrete_class()` / `spring_route_registrations._owner_is_unique()` | Gates publisher/configuration; `MethodFact` → boolean. | Отделяют конкретную visibility от attribution ровно к одному declaration. Failure пропускает этот метод owner до декодирования DSL. |
| `spring_route_registrations._call_has_owner()` | Functional decoders и mapping-info; invocation/member/ожидаемый FQN → boolean. | Доказывает qualified type receiver или exact/однозначный static import. `_unqualified_static_member_resolves()` отвергает лексические source methods и неоднозначных wildcard owners; `_method_variable_names()` предотвращает shadowing receiver/type. |
| `spring_route_registrations._router_function_family()` | Gate functional publisher; return type → `servlet`, `webflux` или `None`. | Разрешает raw generic return type ровно в один поддерживаемый Spring package. |
| `spring_route_registrations._single_direct_return()` | Gate functional publisher; `MethodFact` → возвращаемое expression или `None`. | Требует ровно один return во всём body и чтобы он был прямым top-level statement. Failure отвергает publisher. |
| `spring_route_registrations._direct_variable_initializer()` | Validation нейтрального predicate; имя/type поля → один initializer или `None`. | Намеренно распознаёт только уникально объявленное typed `final` поле owner; это не общий Java data flow. |
| `spring_route_registrations._is_route_identity_neutral_predicate()` | Selecting/builders; узел predicate → boolean. | Допускает доказанные non-path/non-method calls `RequestPredicates`, ограниченные `and`/`or`/`negate` и одно безопасное final-field indirection. Любой дополнительный selector path/method, shadowing, cycle или depth свыше 16 делает route expression неуспешным. |
| `spring_route_registrations._bind_this_handler()` | Decoder handler; ссылка на метод → точный `MethodFact` или `None`. | Требует `this::name`, ровно один source method того же owner, один formal parameter и non-static identity. Неоднозначность overload отклоняет attribution. |
| `spring_route_registrations._decode_handler()` | Decoders route/builder; expression handler → `(valid_shape, exact_handler_or_None)`. | Lambdas и ссылки на methods через local receiver доказывают publication, но откатываются к attribution publisher. Отсутствующий same-owner `this::name` невалиден; существующая неоднозначная overload валидна без точного attribution. |
| `spring_route_registrations._decode_selecting_predicate()` | Decoders predicate/nest; selector expression → static path или `None`. | Снимает ограниченные suffixes `.and(neutral)`, доказывает Spring owner фиксированного selector, требует один argument, затем разрешает path. |
| `spring_route_registrations._decode_predicate()` | Прямые `route`/`andRoute`; node → `(fixed_verb, path)` или `None`. | Root selector должен быть одним из семи поддерживаемых functional verbs; все identity-neutral suffixes проверяет selecting decoder. |
| `spring_route_registrations._decode_builder_route_arguments()` | Walker builder; call с fixed-verb → `(path, handler)` или `None`. | Принимает только `(path, handler)` или `(path, neutral_predicate, handler)`. Path и handler должны быть sound. |
| `spring_route_registrations._decode_builder_chain()` | `_decode_builder()` и recursive nested blocks; fluent node → `(valid, routes)`. | Проверяет root `RouterFunctions.route()`, stages с fixed-verb и statements `nest(path(...), alias -> block)`. Общий budget отвергает более 256 посещённых steps, nesting глубже 16 или более 4096 выданных builder routes. Любой неподдерживаемый builder statement отвергает это builder expression. |
| `spring_route_registrations._decode_builder()` | Decoder functional expression; terminal `build()` → декодированные routes. | Требует ноль arguments и делегирует receiver chain ограниченному builder walker. |
| `spring_route_registrations._decode_functional_expression()` | Functional publisher; return expression → `(valid, routes)`. | Рекурсивно обрабатывает прямые `route`, `andRoute`, прямой `nest` и builder `build`. Depth прямого nest ограничен 16. Неподдерживаемая grammar отвергает expression publisher; частичная identity не угадывается. |
| `spring_route_registrations._handler_endpoint()` | Functional и programmatic ветви; verb/path/handler/publisher/route node → fact. | При наличии точного handler приписывает ему public row и represented target, иначе — fallback publisher. Provenance route/project остаётся на publisher. Calls registration имеют пустое annotation evidence. Записывает выданный fact. |
| `spring_route_registrations._analyze_functional_routes()` | Public entry; workspace/index → facts. | Применяет gates unique concrete owner, exact `@Bean`, family `RouterFunction`, direct-return и expression. Отвергнутое expression удаляет этот publisher; каждый декодированный route становится fact. |

Оставшиеся functional helpers намеренно узки:
`spring_route_registrations._log()` записывает scoped diagnostic;
`spring_route_registrations._resolve_path()` делегирует String resolution, затем
нормализует; `spring_route_registrations._lambda_parameter_and_body()` принимает
одну форму inferred alias/body, используемую вложенными builders.

### 5.3 Call graph программной registration

```mermaid
flowchart TD
    E["analyze_spring_route_registrations"] --> AP["_analyze_programmatic_mvc_registrations"]
    AP --> OG["уникальный конкретный owner @Configuration"]
    OG --> AM["_analyze_programmatic_registration_method"]
    AM --> MG["non-static void + marker @Autowired + один mapping parameter"]
    MG --> CF["нет unregister, nested call, control flow или tracked mutation"]
    CF --> LC["собрать прямые typed locals и прямые calls registerMapping"]
    LC --> RA["_resolve_local_argument"]
    RA --> MI["_decode_request_mapping_info"]
    RA --> RM["_decode_reflected_method"]
    RM --> CT["canonical types source/reflection parameter"]
    MI --> X["paths × methods"]
    CT --> X
    X --> HE["_handler_endpoint(точный reflected handler, publisher registration)"]
```

### 5.4 Контракты программной registration

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_route_registrations._resolve_source_type()` | Проверки reflection и handler; type node → один доступный source FQN или `None`. | Duplicate, external-only, unresolved или inaccessible owners не являются reflected handlers. |
| `spring_route_registrations._canonical_named_type()` | Canonical decoder parameter; named type → сопоставимый FQN или `None`. | Предпочитает одну source identity, затем exact imports, явно lower-case-qualified внешние имена или ограниченный набор `java.lang`. Неоднозначные relative nested names приводят к fail-closed. |
| `spring_route_registrations._canonical_type()` | Decoder reflection; Java type плюс varargs flag → canonical spelling scalar/array или `None`. | Рекурсивно проходит arrays и обрабатывает primitive, named и varargs shapes без class loading. |
| `spring_route_registrations._class_literal_type()` | Decoder reflection; `T.class` → canonical parameter type или `None`. | Требует class literal с ровно одним type child. |
| `spring_route_registrations._decode_reflected_method()` | Decoder registration-call; `Class.getMethod(...)` → `(exact MethodFact, target FQN)` или `None`. | Разрешает один конкретный source class, непустую статически разрешаемую String имени метода, canonical class-literal parameters и ровно одну public non-static совпадающую overload. |
| `spring_route_registrations._decode_request_mapping_info()` | Decoder registration-call; builder expression → `(paths, methods)` или `None`. | Принимает только `RequestMappingInfo.paths(...)[.methods(...)].build()`. Каждый path и настоящий request method должен разрешиться; отсутствие paths отвергается; отсутствие methods становится `ANY`. |
| `spring_route_registrations._mapping_invocations()` | Gate метода registration; mapping parameter/name → совпадающие calls receiver. | Сначала находит calls везде, позволяя caller отличить отсутствие от использования во вложенном/control-flow контексте. |
| `spring_route_registrations._has_tracked_mutation()` | Gate метода registration; tracked names и принятые locals → boolean. | Отвергает reassignment/update и неоднозначное nested redeclaration каждой релевантной local или formal parameter. |
| `spring_route_registrations._resolve_local_argument()` | Decoder per-call; argument, expected kind, local table, call position → inline expression или `None`. | Non-identifier проходит напрямую. Identifier должен называть одну более раннюю direct local точного tracked kind. |
| `spring_route_registrations._is_programmatic_registration_owner()` | Cache owner; `MethodFact` → boolean. | Требует concrete owner и ровно один настоящий direct `Configuration`. |
| `spring_route_registrations._analyze_programmatic_registration_method()` | Loop programmatic owner; workspace/index/method → facts. | Gates уровня method требуют non-static textual `void`, marker-only `Autowired`, ровно один настоящий mapping parameter, отсутствие unregister и моделируемого control flow, только direct calls и стабильные locals/parameters. После их прохождения malformed sibling calls диагностируются и пропускаются независимо. Валидный call должен согласовать mapping info, reflected method и handler formal того же source type. |
| `spring_route_registrations._analyze_programmatic_mvc_registrations()` | Public entry; workspace/index → facts. | Кеширует eligibility owner по FQN и анализирует каждый method подходящего unique configuration owner. |
| `spring_route_registrations._deduplicate()` | Public entry; facts registration → tuple. | Группирует по route, verb, parameters, public source/line и handler; делегирует `deduplicate_endpoint_facts()`, поэтому represented targets объединяются. |
| `spring_route_registrations.analyze_spring_route_registrations()` | Pipeline; workspace → tuple functional плюс programmatic facts. | Строит один varargs-aware method index, последовательно выполняет две ветви и локально дедублицирует. Единственные внешне наблюдаемые side effects — diagnostics. |

Малые data-flow helpers: `spring_route_registrations._local_declarators()`
(declarators в одном local statement),
`spring_route_registrations._tracked_local_kind()` (mapping-info или reflected
method) и `spring_route_registrations._direct_expression()` (один direct
expression statement).

## 6. `spring_clients.py`: outbound HTTP Interface и Feign contracts

### 6.1 Graph ветвей

```mermaid
flowchart TD
    E["analyze_spring_http_clients"] --> U["уникальные видимые source interfaces"]
    U --> HI["_http_interface_endpoints"]
    U --> FE["_feign_endpoints"]
    HI --> TE["лексические type-level слои HttpExchange"]
    TE --> ME["прямые аннотации Exchange метода"]
    ME --> DE["_decode_exchange_mapping"]
    DE --> DP["_decode_exchange_paths"]
    DE --> DM["_decode_exchange_methods"]
    DP --> PL["локальные _ClientCandidate.path_layers"]
    DM --> UF["_union_exchange_methods"]
    FE --> FM["один прямой marker FeignClient"]
    FM --> TM["первый MVC mapping каждого лексического type"]
    TM --> MM["все MVC mappings каждого прямого method"]
    MM --> MVC["встроенные/составные MVC decoders"]
    PL --> EP["_endpoint"]
    UF --> EP
    MVC --> EP
    EP --> DD["_deduplicate локальных candidates"]
    DD --> CFG["разрешить HTTP Interface layers или Feign path"]
    CFG --> OUT["сконфигурированный tuple[EndpointFact, ...]"]
```

### 6.2 Контракты методов

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_clients._resolved_exchange_annotations()` | Loops type/method HTTP Interface; declaration → настоящие прямые records и names Exchange. | Lookalikes игнорируются; участвует только точное семейство `org.springframework.web.service.annotation`. |
| `spring_clients._resolve_string_values()` | Декодирование Exchange path/method; value аннотации → упорядоченный tuple или `None`. | Разрешает каждый восстановленный member array. Одно неразрешённое value отвергает этот attribute; пустое восстановленное value становится одной пустой string. |
| `spring_clients._decode_exchange_paths()` | Decoder Exchange mapping; аннотация → paths или `None`. | Aliases positional/`value`/`url` должны быть синтаксически валидны и равны после resolution. Абсолютные URL и начальные placeholders остаются без prefix; обычные paths получают `/`. |
| `spring_clients._decode_exchange_methods()` | Decoder Exchange mapping; identity/occurrence аннотации → methods или `None`. | Аннотации с fixed `*Exchange` отвергают явный `method`. Generic `HttpExchange` принимает ограниченные uppercase HTTP tokens; отсутствие/пустота означает unconstrained. |
| `spring_clients._decode_exchange_mapping()` | Extraction HTTP Interface; доказанная аннотация → mapping или `None`. | Отвергает неизвестные named attributes, затем объединяет decoders path и method и подключает canonical annotation identity/family. Route-neutral attributes headers/media принимаются, но исключаются из identity endpoint. |
| `spring_clients._union_exchange_methods()` | Композиция HTTP Interface; verbs type/method → упорядоченный union. | Известные Spring verbs используют framework order; custom generic tokens следуют лексикографически через `_ordered_methods()`. Пустая сторона нейтральна. |
| `spring_clients._http_interface_endpoints()` | Public client loop; одно уникальное declaration interface → локальные candidates. | Проходит лексические types; каждый слой может иметь не более одного generic type-level `HttpExchange`. Невалидный type layer отвергает ветвь interface. Посещает только direct usable methods и независимо декодирует каждый настоящий method mapping. Alternatives lexical и method path остаются явными layer tuples candidate, пока configuration не разрешит их; verbs по умолчанию `ANY`. |
| `spring_clients._resolved_feign_client_markers()` | Ветка Feign; interface type → настоящие direct markers. | Attributes marker классифицируют contract, но не добавляют paths. Caller требует ровно один marker. |
| `spring_clients._decode_mvc_mapping()` | Selectors mapping Feign; одна record аннотации → MVC mapping или `None`. | Повторно использует authoritative семантику встроенного/составного Spring mapping. |
| `spring_clients._first_mvc_mapping()` | Лексический type loop Feign; declaration → первый распознанный mapping или `None`. | Слои type используют семантику first-recognized; recognized-invalid type mapping отвергает ветвь Feign. |
| `spring_clients._all_mvc_mappings()` | Method loop Feign; declaration → каждый распознанный mapping. | Аннотации метода могут размножаться в отдельные endpoint mappings; caller независимо пропускает invalid mappings. |
| `spring_clients._feign_endpoints()` | Public client loop; одно declaration interface → локальные candidates. | Требует ровно один direct Feign marker, композит первый mapping каждого лексического слоя type и применяет каждый mapping каждого direct usable method. Не обходит inheritance interface и не использует URL/path values marker Feign. |
| `spring_clients._ClientCandidate` | Client builders → временное значение Spring. | Хранит raw fact и optional path layers HTTP Interface. Feign использует составной path fact. Значение никогда не выходит за пределы `analyze_spring_http_clients()`. |
| `spring_clients._endpoint()` | Обе ветви client; unit/method/mapping/path/verb/layers → локальный candidate. | Создаёт outbound HTTP/client fact, точное evidence аннотации mapping, точный represented target метода и diagnostic raw path. Объединяет fact с HTTP Interface layers в `_ClientCandidate`; общий fact не имеет временного client field. |
| `spring_clients._deduplicate()` | Public entry; client candidates → tuple. | Локальная identity включает route fields, surface/direction client и лексические layers. При collisions candidates evidence facts объединяется через `merge_endpoint_facts()` до path resolution. |
| `spring_clients.analyze_spring_http_clients()` | Spring facade; workspace/configuration → сконфигурированные outbound facts. | Детерминированно обходит FQNs, отвергает duplicate declarations и запускает обе branches для видимых в workspace interfaces. После локальной deduplication разрешает HTTP Interface layers или Feign path, диагностирует/удаляет невалидные paths и выдаёт обычные значения `EndpointFact`, сохраняя evidence. |

Вспомогательные client symbols: `spring_clients._log()` (diagnostic),
`spring_clients._direct_methods()` (прямые declarations в source order),
`spring_clients._usable_contract_method()` (исключает private/static),
`spring_clients._normalize_client_path()` (нормализация с учётом
URL/placeholder), `spring_clients._combine_client_paths()` (побеждает внутренний
абсолютный URL) и `spring_clients._ordered_methods()` (стабильный порядок verbs:
сначала известные, затем custom).

## 7. `spring_config.py`: project paths и static resources

У этого модуля две отдельные ответственности: построение/применение immutable
path configuration и извлечение routes static-handler `WebMvcConfigurer`.

### 7.1 Data flow конфигурации

```mermaid
flowchart TD
    B["build_spring_path_configuration(workspace, analysis_root)"] --> IR["_infer_project_root(каждый Java source)"]
    IR --> RC["_read_project_path_configuration(каждый root)"]
    RC --> PP["_parse_properties"]
    RC --> PY["_parse_mapping_yaml"]
    PP --> PC["SpringProjectPathConfiguration"]
    PY --> PC
    PC --> WC["SpringWorkspacePathConfiguration"]

    WC --> AP["apply_spring_path_configuration(raw facts, configuration)"]
    AP --> RP["resolve_spring_endpoint_path"]
    WC --> CP["resolve_spring_client_path_layers<br/>вызывается внутри client extraction"]
    CP --> PH["_resolve_placeholders для каждого layer"]
    RP --> PH
    PH -->|разрешено| RE["replace(fact, path=...) с сохранением evidence"]
    PH -->|невалидно/исчерпано| DR["диагностировать и удалить этот fact"]
```

### 7.2 Контракты configuration

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_config.SpringProjectPathConfiguration` | Loader project → immutable project record. | Хранит canonical project root, все разобранные placeholder values, выбранный server base и имена загруженных файлов. |
| `spring_config.SpringWorkspacePathConfiguration` | Builder configuration → immutable run record. | Отображает canonical source files в optional project roots, а roots — в project records. |
| `spring_config._infer_project_root()` | Builder configuration; source и analysis root → project `Path` или `None`. | Требует, чтобы source находился под analysis root; предпочитает ровно один `src/main/java`, иначе не более одного `src`, иначе analysis root. Повторные markers неоднозначны. |
| `spring_config._parse_properties()` | Loader project; text → flat dictionary key/value. | Реализует только non-comment lines с первым разделителем `=` или `:`. Намеренно не эмулирует полную grammar Java properties. |
| `spring_config._strip_yaml_comment()` | Parser subset YAML; line → line без comment или `None`. | Отслеживает простые single/double quotes и отвергает незакрытые quotes. |
| `spring_config._split_yaml_mapping()` | Parser subset YAML; stripped line → tokens key/value или `None`. | Делит по первому colon вне quotes. |
| `spring_config._yaml_string()` | Parser subset YAML; token → поддерживаемая string или `None`. | Декодирует double quotes в стиле JSON и escaping single-quote YAML; plain keys ограничены; формы null/boolean/float/collection/anchor/block не являются path strings. |
| `spring_config._parse_mapping_yaml()` | Loader project; YAML text → flat dotted mapping или `None`. | Принимает только mapping indentation с leaves String/integer. Tabs, sequences/doc markers, malformed nesting, anchors и разобранные profile-activation keys отвергают весь файл; неподдерживаемые scalar leaves игнорируются. |
| `spring_config._read_project_path_configuration()` | Builder configuration; project root → project record. | Читает resource directories с документированным precedence и по порядку каждый файл properties/YML/YAML; нечитаемые или отвергнутые файлы диагностируются и пропускаются. Более поздние parsed keys перезаписывают ранние values. Base path WebFlux имеет приоритет над servlet context path. Это filesystem I/O. |
| `spring_config.build_spring_path_configuration()` | Pipeline; workspace/root → workspace configuration. | Определяет ownership каждого compilation unit, пишет log для неоднозначных sources, загружает каждый distinct root один раз в sorted order и возвращает immutable records. Workspace не мутирует. |
| `spring_config._resolve_placeholders()` | Все resolvers path; path и values → substituted string или `None`. | Поддерживает вложенные `${key}` и `${key:default}` с максимум 100 substitutions и 8192 output characters. Отсутствующие keys без defaults становятся пустыми. Остаточные/malformed placeholders приводят к fail-closed. |
| `spring_config.resolve_spring_endpoint_path()` | Общее применение и optional callbacks; path/source/configuration плюс классификация endpoint → path, неизменённый path или `None`. | Не-Spring/неподходящие facts проходят напрямую. Подходящие inbound HTTP и handshake paths получают server base владеющего project; message destinations и outbound clients — нет. Все подходящие paths потребляют placeholders, затем нормализуют и схлопывают slashes, не повреждая authority URL. |
| `spring_config.resolve_spring_client_path_layers()` | Client analyzer; lexical layers/source/configuration → final path или `None`. | Разрешает placeholders перед композицией каждого layer. Любой внутренний абсолютный HTTP(S) URL сбрасывает все предыдущие лексические prefixes. Clients никогда не получают server base. |
| `spring_config.make_spring_path_resolver()` | Optional sibling integration; configuration → callback. | Вложенный `apply()` принимает прямой `source_file` или `unit`, удаляет diagnostic-only `owner_name`, передаёт дальше classification endpoint и возвращает `None`, если input source ownership непригоден. Захватывает, но не меняет configuration. |
| `spring_config.apply_spring_path_configuration()` | Spring facade для групп raw server/messaging facts и client analyzer для Feign paths; iterable endpoint/configuration → tuple. | Не-Spring facts проходят без изменения. Spring facts используют common resolver с `project_source_file` раньше public source, диагностируют/удаляют только неразрешённые facts и вызывают `replace()` для успешных paths. Input facts остаются неизменными; metadata построения client не читаются. |

Pure seams нормализации `spring_config._canonical_path()`,
`spring_config._normalize_optional_path()` и
`spring_config._collapse_path_slashes()` соответственно канонизируют identity
filesystem, сохраняют абсолютные URL при нормализации optional prefixes и
схлопывают повторяющиеся separators. `spring_config._log()` записывает
rejections configuration или resource.

### 7.3 Call graph и контракты static resource

```mermaid
flowchart TD
    E["analyze_spring_resource_handlers"] --> IT["_iter_resource_handler_configurer_methods"]
    IT --> CG["уникальный конкретный прямой WebMvcConfigurer"]
    CG --> MG["canonical public instance void addResourceHandlers(registry)"]
    MG --> MU["_registry_is_mutated"]
    MU -->|стабилен| FI["найти calls registry.addResourceHandler"]
    FI --> DC["gate прямой top-level registration-chain"]
    DC --> AR["независимо разрешить каждый аргумент path"]
    AR --> F["EndpointFact: GET/static-handler/inbound"]
```

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_config._known_type()` | Распознавание resource configurer; node/simple name → boolean. | Доказывает точный type в package MVC configuration Spring. |
| `spring_config._iter_resource_handler_configurer_methods()` | Analyzer resource; workspace → tuples canonical метода configurer. | Требует одно source declaration, concrete visible class, ровно один настоящий direct interface `WebMvcConfigurer` и public non-static textual-`void` method с ровно одним настоящим formal `ResourceHandlerRegistry`. |
| `spring_config._invocation_name()` | Analyzer resource; invocation → написание имени method. | Только helper source-text; не доказывает identity owner. |
| `spring_config._registry_is_mutated()` | Gate resource method; unit/body/parameter name → boolean. | Assignment или update точного registry parameter отвергает этот configurer method. |
| `spring_config.analyze_spring_resource_handlers()` | Pipeline; workspace → facts static-handler. | Находит calls `addResourceHandler` на exact parameter, требует принадлежности каждого прямому top-level fluent registration statement и независимо разрешает каждый argument. Плохой argument диагностируется без отбрасывания хороших siblings. Каждый хороший path создаёт fact `GET`/HTTP/static-handler/inbound с пустым annotation evidence и method configurer как represented target. |
| `spring_config._deduplicate()` | Analyzer resource; facts → tuple. | Группирует route, method, parameters, source/line и handler, объединяя represented targets. |

## 8. `spring_gateway.py`: ограниченный DSL Spring Cloud Gateway

### 8.1 Call graph

```mermaid
flowchart TD
    E["analyze_spring_gateway"] --> IX["строгий MethodIndex"]
    IX --> OG["_owner_is_unique_concrete_class"]
    OG --> VG["_validated_route_locator_builder_name"]
    VG --> PUB["_decode_route_locator_publisher"]
    PUB --> RL["один _decode_route_lambda для каждого call route"]
    RL --> DP["_decode_predicate_chain"]
    RL --> HP["_decode_predicate_helper, если direct chain неуспешна"]
    HP --> DP
    DP --> IC["_invocation_chain"]
    DP --> PA["_resolve_path × _resolve_http_method"]
    PA --> GC["GatewayRouteConditions(paths, methods)"]
    GC --> EP["_endpoint для каждого path/method"]
    EP --> DD["_deduplicate"]
```

### 8.2 Контракты методов

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_gateway.GatewayPathResolver` | Public type alias для optional integration callback. | Получает path плюс metadata source/surface и возвращает resolved path или `None`. |
| `spring_gateway.GatewayRouteConditions` | Decoder predicate → immutable tuple paths/methods. | Представляет только inbound identity; route ID, destination и filters исключены. |
| `spring_gateway._known_direct_annotation()` | Gate publisher; method и ожидаемая аннотация → unique record или `None`. | Требует ровно одну настоящую direct annotation. |
| `spring_gateway._owner_is_unique_concrete_class()` | Public loop; workspace/publisher → boolean. | Требует одно visible non-abstract source declaration class, совпадающее с `MethodFact`. |
| `spring_gateway._single_direct_return()` | Decoders publisher/helper; method → expression или `None`. | Требует один direct top-level return. По умолчанию любой nested return отвергает; внешний publisher отключает только rejection nested-return, чтобы отвергнутая route lambda не могла удалить валидных siblings. |
| `spring_gateway._validated_route_locator_builder_name()` | Public loop; publisher → exact имя formal builder или `None`. | Требует один прямой настоящий `Bean`, настоящий return `RouteLocator` и ровно один настоящий parameter `RouteLocatorBuilder`. Другие formals допускаются. |
| `spring_gateway._decode_predicate_lambda_parameter()` | Decoder route lambda; lambda → один alias или `None`. | Принимает один inferred identifier или один явно typed настоящий formal `PredicateSpec`. |
| `spring_gateway._resolve_path()` | Chain predicate; expression path → configured normalized path или `None`. | Разрешает один static String, нормализует его и опционально вызывает `GatewayPathResolver`. Результаты callback `None`, empty или non-string делают route неуспешным. |
| `spring_gateway._resolve_http_method()` | Chain predicate; enum expression → verb или `None`. | Доказывает один настоящий `HttpMethod` или `RequestMethod`; `CONNECT` валиден только для `HttpMethod`. Неоднозначные unqualified owners приводят к fail-closed. |
| `spring_gateway._invocation_chain()` | Decoder predicate; fluent expression → root плюс calls в source order или `None`. | Использует bound receiver-chain в 16 iterations и отвергает malformed argument nodes либо chain, которая не достигает root в этом bound. |
| `spring_gateway._decode_predicate_chain()` | Decoder direct/helper route; expression/root alias → `GatewayRouteConditions` или `None`. | Принимает ровно `path`, `path.and.method` или `method.and.path`. Все trailing calls `filter`/`filters` должны быть последовательны и unary. Каждый argument path/method разрешается; отсутствие method становится `ANY`. |
| `spring_gateway._decode_predicate_helper()` | Fallback route lambda; invocation helper → conditions или `None`. | Требует unqualified/`this` same-owner call с передачей exact alias lambda и ровно один uniquely indexed helper с настоящим input `PredicateSpec`, настоящим output `BooleanSpec` и одним direct return. |
| `spring_gateway._decode_route_lambda()` | Decoder publisher; route lambda → conditions или `None`. | Требует поддерживаемый единственный parameter и body, заканчивающийся unary `uri(...)`. Destination expression намеренно игнорируется. Пробует direct predicate chain, затем ограниченную ветвь helper. |
| `spring_gateway._route_lambda_argument()` | Decoder publisher; call `route(...)` → lambda или `None`. | Принимает одну lambda или `(ignored route-id, lambda)`; dynamic route IDs нейтральны к route. |
| `spring_gateway._decode_route_locator_publisher()` | Public loop; publisher/index/builder/callback → список decoded routes или `None`. | Требует прямую chain `builder.routes().route(...).build()` с terminals без arguments и bound reverse-walk 256 iterations. Malformed внешняя publication отвергает publisher. Неподдерживаемая route lambda диагностируется и пропускается, а валидные siblings сохраняются. |
| `spring_gateway._endpoint()` | Public loop; publisher/call/verb/path → fact. | Создаёт inbound HTTP/gateway fact, приписанный publisher `Bean`, с пустыми parameters/annotation evidence и методом publisher как represented target; записывает diagnostic. |
| `spring_gateway._deduplicate()` | Public entry; Gateway facts → tuple. | Группирует route, method, parameters, source/line и handler; объединяет typed targets. |
| `spring_gateway.analyze_spring_gateway()` | Pipeline или standalone caller; workspace плюс optional resolver → tuple. | Строит строгий method index, применяет gates publisher, размножает decoded conditions, создаёт facts и локально дедублицирует. |

`spring_gateway._log()` — helper diagnostics, scoped одним candidate.

## 9. `spring_websocket_messaging.py`: handshakes, prefixes и destinations

### 9.1 Graph ветвей

```mermaid
flowchart TD
    E["analyze_spring_websocket_and_messaging"] --> WH["_websocket_handler_handshake_endpoints"]
    E --> SH["_stomp_handshake_endpoints"]
    E --> MM["_message_mapping_endpoints"]
    WH --> WC["_websocket_handler_configurer_methods"]
    SH --> SC["_stomp_configurer_methods"]
    WC --> UC["_unique_concrete_configurers"]
    SC --> UC
    WH --> HF["_has_typed_websocket_handler_field"]
    WH --> RP["_resolved_paths"]
    SH --> RP
    MM --> PF["_stomp_application_prefixes"]
    PF --> SC
    MM --> CT["лексический marker controller + paths type MessageMapping"]
    CT --> MA["method MessageMapping / SubscribeMapping"]
    MA --> F["EndpointFact + annotation evidence + target метода"]
    WH --> H["EndpointFact + пустое annotation evidence + target configurer"]
    SH --> H
    F --> DD["_deduplicate"]
    H --> DD
```

### 9.2 Общие контракты configurer и handshake

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_websocket_messaging._unique_concrete_configurers()` | Iterators configurer STOMP/raw; workspace/interface → tuples owner. | Требует unique concrete visible source class с ровно одной настоящей прямой implementation нужного interface configurer. |
| `spring_websocket_messaging._formal_parameter()` | Gate canonical method; method/type/package → `(name, parameters_node)` или `None`. | Требует ровно один uncommented formal настоящего framework type. |
| `spring_websocket_messaging._canonical_method()` | Iterators configurer; method и ожидаемая signature → receiver/parameters/body или `None`. | Требует public, non-static, textual `void`, точное name, body и ровно один framework parameter. |
| `spring_websocket_messaging._receiver_mutated()` | Iterators configurer; body метода и receiver name → boolean. | Assignment/update registry parameter делает этот canonical hook невалидным. |
| `spring_websocket_messaging._receiver_calls()` | Ветки handshake/prefix; exact receiver и call name → все совпадающие invocations. | Находит calls независимо от nesting, чтобы callers явно отвергали скрытый control flow. `_direct_receiver_calls()` фильтрует этот набор через общий gate direct-statement. |
| `spring_websocket_messaging._stomp_configurer_methods()` | Ветки handshake/prefix STOMP; workspace → tuples canonical hook. | Выдаёт и `registerStompEndpoints`/`addEndpoint`, и `configureMessageBroker`/`setApplicationDestinationPrefixes`, включая состояние mutation receiver. |
| `spring_websocket_messaging._websocket_handler_configurer_methods()` | Ветка raw handshake; workspace → tuples canonical hook. | Выдаёт canonical methods `registerWebSocketHandlers(WebSocketHandlerRegistry)` и состояние mutation. |
| `spring_websocket_messaging._direct_call_with_allowed_chain()` | Gates handshake/prefix; invocation/body/allowed suffixes → boolean. | Идёт наружу от registry call, принимает только перечисленные route-neutral fluent suffixes и требует, чтобы финальная chain была direct body statement. `withSockJS` не нейтрален и поэтому не проходит. |
| `spring_websocket_messaging._handler_field_name()` | Validator raw handler; expression → `(field_name, explicit_this)` или `None`. | Принимает только identifier или `this.field`. |
| `spring_websocket_messaging._has_typed_websocket_handler_field()` | Ветка raw handshake; expression handler → boolean. | Требует ровно одно owner field настоящего type `WebSocketHandler`. Unqualified reference не проходит, если её затеняет local/formal/catch name; `this.field` остаётся явной. |
| `spring_websocket_messaging._websocket_handler_handshake_endpoints()` | Public entry; workspace → raw handshake facts. | Требует стабильный configurer, direct allowed chain `addHandler(handler, paths...)`, точное typed handler field и все static paths. Каждый path создаёт fact `ws GET`/websocket-handshake/inbound с пустым annotation evidence и target метода configurer. |
| `spring_websocket_messaging._stomp_handshake_endpoints()` | Public entry; workspace → STOMP handshake facts. | Применяет те же gates stable/direct/allowed-chain/static-path к `addEndpoint`. Каждый path создаёт ту же классификацию handshake и target configurer. |

Малые общие helpers:
`spring_websocket_messaging._invocation_name()` (написание call),
`spring_websocket_messaging._arguments()` (semantic arguments без comments) и
`spring_websocket_messaging._resolved_paths()` (all-or-nothing resolution
статических String с последующей normalization).

### 9.3 Контракты prefix и message

| Координата | Caller; input → output | Решения, effects и граница failure |
|---|---|---|
| `spring_websocket_messaging._project_key()` | Ветки prefix/message; configuration и source → project key или `None`. | Использует configured canonical ownership; без configuration откатывается к canonical source path. |
| `spring_websocket_messaging._stomp_application_prefixes()` | Ветка message; workspace/configuration → valid prefix map плюс invalid-project set. | В каждом project mutation registry, nested calls, более одного direct setter либо unresolved/no-argument setter делают identity message prefix этого project невалидной. Canonical hook без setter оставляет default пустой prefix. |
| `spring_websocket_messaging._annotation_paths()` | Decoders message type/method; аннотация → paths или `None`. | Принимает только positional/`value`/`path`, требует согласованные aliases и разрешает каждое value. `empty_default=True` делает mapping type без arguments нейтральным; mapping method требует явную value group (явная пустая String нормализуется в root, а пустой array не выдаёт destination). |
| `spring_websocket_messaging._known_annotations()` | Decoders controller/type/method; query captures/names/package → resolved records. | Фильтрует captures по настоящей package identity, сохраняя source order. |
| `spring_websocket_messaging._lexical_controller_type_chain()` | Ветка message; method owner key → записи types от внешнего к внутреннему. | Тонкая именованная seam поверх общего traversal лексических типов. |
| `spring_websocket_messaging._has_controller_marker_in_lexical_chain()` | Ветка message; lexical chain → boolean. | Требует настоящий `Controller` или `RestController` хотя бы на одном лексическом layer owner; bean graph или inherited stereotype не выводится. |
| `spring_websocket_messaging._lexical_message_mapping_paths()` | Ветка message; lexical chain → fan-out type-path или `None`. | Композит каждый настоящий type-level `MessageMapping` в source order. Одна невалидная аннотация подавляет message facts под этой chain. |
| `spring_websocket_messaging._message_mapping_endpoints()` | Public entry; workspace/configuration → message facts. | Сначала строит состояние prefix project. Затем посещает concrete visible captured method owners в valid projects, требует lexical controller activation, композит destinations project/type/method и выдаёт `SEND` для `MessageMapping` или `SUBSCRIBE` для `SubscribeMapping`. Каждый fact имеет точное evidence аннотации метода и represented target метода. |
| `spring_websocket_messaging._deduplicate()` | Public entry; все WebSocket/message facts → tuple. | Локальная identity включает protocol, surface, verb, path, source, handler и parameters; общий merge объединяет annotation/target evidence. |
| `spring_websocket_messaging.analyze_spring_websocket_and_messaging()` | Pipeline; workspace/configuration → tuple. | Запускает raw handshakes, STOMP handshakes, затем message destinations и дедублицирует их объединённые facts. |

## 10. Где создаются и объединяются facts и evidence

### 10.1 Места построения fact

Общего Spring endpoint builder нет, поскольку у каждого source-механизма своя
attribution. Ниже перечислены все места построения Spring в семи модулях:

| Место построения | Attribution public/route/handler/project | Annotation evidence | Represented target |
|---|---|---|---|
| Ветка ordinary-method `spring_mvc.analyze_direct_spring_mvc_unit()` | Все identities используют source mapped method; diagnostic line — mapping-аннотация. | `method_annotation_evidence_from_mapping()` для выбранной встроенной или внешней составной аннотации. | Точный span метода. |
| Ветка record-component `spring_mvc.analyze_direct_spring_mvc_unit()` | Public source — source record; handler name — неявный accessor. | Пусто: аннотация component не является evidence аннотации метода. | Точный span компонента record. |
| `SpringMvcHierarchyAnalyzer._controller_hierarchy_endpoints()` | Public/handler identity — конкретная implementation; route identity — mapped contract; project identity — активированный concrete controller root. | Mapping evidence только когда source mapping и implementation — точный один и тот же method. | Точный method implementation. |
| `spring_route_registrations._handler_endpoint()` | Public/handler — точно связанный handler или fallback publisher; route/project — метод `Bean` или registration. | Пусто: path и verb происходят из calls, а не из аннотации method. | Эффективный handler method, включая fallback publisher. |
| `spring_clients._endpoint()` | Public, route, handler и project остаются на method contract interface. | Точный mapping Exchange или MVC метода. | Точный method interface. |
| `spring_config.analyze_spring_resource_handlers()` | Public/route/handler используют method/source configurer. | Пусто: identity route задаёт invocation registration. | Точный method `addResourceHandlers`. |
| `spring_gateway._endpoint()` | Все identities используют publisher `RouteLocator`; diagnostic route line использует call `route`. | Пусто: identity route задают calls predicate. | Точный method publisher. |
| `spring_websocket_messaging._websocket_handler_handshake_endpoints()` | Метод configurer владеет identities public, route, handler и project. | Пусто. | Точный method raw WebSocket configurer. |
| `spring_websocket_messaging._stomp_handshake_endpoints()` | Метод configurer владеет identities public, route, handler и project. | Пусто. | Точный method STOMP configurer. |
| `spring_websocket_messaging._message_mapping_endpoints()` | Аннотированный method controller владеет identities public, route, handler и project. | `method_annotation_evidence_from_node()` с точными identity и family аннотации Message/Subscribe. | Точный method controller. |

### 10.2 Flow с сохранением evidence

```mermaid
flowchart LR
    S["Узел Tree-sitter annotation/declaration"] --> AE["AnnotationEvidence?<br/>только same-file аннотации method"]
    S --> RT["SourceTarget?<br/>canonical file + kind + byte span"]
    AE --> F["immutable EndpointFact"]
    RT --> F
    F --> LD["локальная для analyzer _deduplicate"]
    LD --> ME["evidence.merge_endpoint_facts"]
    ME --> U["union annotation_evidence + represented_targets;<br/>сохранить более новые non-evidence fields"]
    U --> CFG["apply_spring_path_configuration:<br/>заменить path, сохранить evidence"]
    CFG --> OUT["более поздняя output consolidation по public identity из шести полей"]
    OUT --> LINE["выбрать annotation line из объединённого принадлежащего evidence"]
    OUT --> AUDIT["union represented targets для вычитания unmatched-аннотаций"]
```

Локальные функции deduplication в registrations, resources, Gateway и
WebSocket/messaging передают analyzer-specific tuples identity в
`evidence.deduplicate_endpoint_facts()`. Этот helper делегирует collisions в
`evidence.merge_endpoint_facts()`, который сохраняет ordinary fields более
позднего fact, но детерминированно объединяет и повторно проверяет обе
коллекции evidence. Clients группируют локальные candidates, включая
лексические path layers в identity, и используют ту же операцию
`merge_endpoint_facts()` при collisions. Direct MVC и MVC hierarchy возвращают
facts без локальной deduplication; duplicates между analyzers и на public-границе обрабатывает более
поздняя output consolidation.

Configuration не объединяет facts. Она либо сохраняет не-Spring fact, либо
создаёт Spring-копию с разрешённым path, либо диагностирует и исключает один
неразрешённый fact. Локальные для client path layers обрабатываются до выхода
обычных client facts из их analyzer. Поэтому represented
target удалённого fact не может заставить неуспешный endpoint выглядеть
представленным в итоговом report annotations-without-endpoints.

### 10.3 Почему sources route, handler и project перемещаются отдельно

```mermaid
flowchart TD
    RD["declaration route"] --> RS["route_source_file / route_source_line"]
    HD["конкретный или fallback handler"] --> PS["source_file + handler_name + parameters"]
    HD --> HS["handler_source_file / handler_source_line"]
    PJ["owner configuration"] --> PR["project_source_file"]
    RS --> F["EndpointFact"]
    PS --> F
    HS --> F
    PR --> F
    F --> C["configuration выбирает project_source_file,<br/>иначе public source_file"]
    F --> O["output проецирует public source/method/parameters"]
```

Это разделение особенно важно для functional handlers и hierarchy contracts:
файл, показываемый пользователю, может быть concrete handler, тогда как route
publisher выбирает ownership Spring configuration, а declaration mapping
задаёт route provenance.

## 11. Пошаговые traces от метода до output

### 11.1 Прямой составной MVC method

1. `analyze_direct_spring_mvc_unit()` берёт один captured method и вызывает
   `first_spring_mapping()`.
2. Встроенный decoder возвращает `None`; `decode_spring_composed_mapping()`
   разрешает source definition, branch, alias terminals и values occurrence.
3. Возвращённый mapping сохраняет итоговые paths/methods, но меняет
   `annotation_node` и `annotation_identity` на внешнюю применённую аннотацию.
4. `compose_lexical_type_mapping()` предоставляет слои type снаружи внутрь.
5. Прямой analyzer формирует каждую комбинацию path/method и создаёт fact.
6. `method_annotation_evidence_from_mapping()` записывает line и canonical
   identity внешней аннотации; `represented_target_evidence()` записывает byte
   span метода.
7. `apply_spring_path_configuration()` разрешает placeholders и добавляет
   server base владельца, не меняя ни один tuple evidence.
8. Output consolidation может объединить row с другой равной public identity;
   annotation line выбирается только после merge.

### 11.2 Functional route с точным `this::handler`

1. `analyze_spring_route_registrations()` строит один `MethodIndex`.
2. `_analyze_functional_routes()` доказывает unique concrete publisher
   `RouterFunction` с `Bean` и выбирает его один direct return.
3. `_decode_functional_expression()` доказывает path/verb predicate и просит
   `_decode_handler()` интерпретировать ссылку на метод.
4. `_bind_this_handler()` находит один non-static method того же owner с одним
   параметром, поэтому `_handler_endpoint()` сообщает source, name и parameters
   этого handler.
5. Provenance route и project по-прежнему указывают на publisher `Bean`. Это
   гарантирует использование его project configuration, даже если identity
   handler позднее отличается.
6. У fact нет annotation evidence, но его represented target — точное
   declaration handler.

Если ссылка является валидной lambda или ссылкой на method через local receiver,
шаг 4 откатывается к attribution publisher. Если `this::name` не называет ни
одного source method, route expression невалидно; если overloads делают точную
binding неоднозначной, route остаётся валидным с attribution publisher.

### 11.3 Наследуемый MVC contract

1. `SpringMvcHierarchyAnalyzer.analyze()` выбирает действительно активированный
   root конкретного controller'а.
2. `_controller_hierarchy_endpoints()` строит полную адаптированную hierarchy и
   получает erased signatures из `_all_signatures()`.
3. `_implementation()` выбирает concrete/default handler; затем
   `_resolve_mapping_source()` выбирает доступное declaration
   abstract/interface, владеющее mapping.
4. Условия controller-type, contract-type и method компонуются в public route.
5. Fact сообщает source/name/parameters implementation и представляет span
   implementation, а route provenance указывает на contract.
6. Другой method contract не может заполнить поле annotation line в CSV-row
   implementation, поэтому annotation evidence пусто, если две точные method
   identities не совпадают.

### 11.4 Client HTTP Interface со сконфигурированным абсолютным base

1. `_http_interface_endpoints()` декодирует аннотации Exchange лексического
   type и direct method.
2. `_endpoint()` объединяет raw outbound fact и его лексические варианты в
   локальный для Spring `_ClientCandidate`, сохраняя mapping evidence и точный
   target метода interface.
3. `_deduplicate()` включает эти layers в identity candidate, чтобы разные
   лексические варианты не потеряли evidence до resolution configuration.
4. `resolve_spring_client_path_layers()` разрешает placeholders по одному layer.
   Если разрешённый внутренний layer — абсолютный URL, он сбрасывает внешние
   prefixes.
5. `analyze_spring_http_clients()` заменяет path raw fact и выдаёт обычный
   `EndpointFact`; inbound server base никогда не применяется. Facade исключает
   эти сконфигурированные clients из последующего применения server/message
   path configuration.

## 12. Область fail-closed и карта side effects

| Неопределённость или невалидное состояние | Область подавления |
|---|---|
| Неразрешённый/невалидный первый direct MVC mapping или lexical type layer | Один target method/component либо потомки под этим невалидным lexical layer. |
| Невалидный composed graph/value use-site | Этот target применённого mapping; inventory всё ещё может независимо распознать валидное definition. |
| Неполная hierarchy типа MVC | Все дополнения hierarchy для этого активированного controller root; direct MVC facts остаются. |
| Неоднозначная implementation hierarchy или origin mapping | Одна erased signature. |
| Неподдерживаемое functional return expression или исчерпание budget builder | Один publisher `Bean`. |
| Control flow, mutation, nested call или плохая activation программной registration | Один method registration. |
| Malformed arguments `registerMapping` после прохождения gates метода | Один call; валидные sibling calls сохраняются. |
| Malformed внешняя publication chain Gateway | Один publisher `RouteLocator`. |
| Неподдерживаемая route lambda Gateway | Один call route; валидные sibling route calls сохраняются. |
| Mutated registry static-resource | Один method configurer. |
| Неразрешённый argument path static-resource | Один argument; другие arguments сохраняются. |
| Невалидный type layer HTTP Interface | Ветка HTTP Interface этого interface. |
| Невалидная аннотация метода HTTP Interface | Этот annotation mapping. |
| Невалидный lexical type mapping Feign | Ветка Feign этого interface. |
| Невалидный method mapping Feign | Этот mapping; валидные method mappings сохраняются. |
| Mutated registry WebSocket/STOMP или неподдерживаемая registration chain | Затронутый method/call configurer; alias flow не выводится. |
| Неоднозначные/вложенные/множественные setters application-prefix STOMP | Message endpoints этого project; handshake facts остаются независимыми. |
| Невалидный mapping message лексического type | Message facts под этой lexical chain. |
| Невалидный/неразрешённый destination method | Это occurrence аннотации. |
| Неразрешённый configured placeholder/base | Один финальный `EndpointFact`. |

| Операция | Наблюдаемый effect |
|---|---|
| `spring_mvc.spring_composed_definition_is_supported()` | Читает/записывает переданный cache состояния аннотаций Spring; автономные вызовы используют локальное состояние. Нейтральный workspace не изменяется. |
| Helpers mapping `SpringMvcHierarchyAnalyzer` | Заполняют только instance-local caches. |
| Каждый вызов `_log()`/`log_*()` и каждый успешно сработавший fact builder | Добавляет текст в текущий bound collector diagnostic. |
| `spring_config.build_spring_path_configuration()` | Читает поддерживаемые configuration files; возвращает immutable data. |
| Extraction, deduplication и применение configuration | Возвращают новые tuples/facts; не записывают output artifacts. |

## 13. Полный index покрытия symbols

Подробные таблицы выше покрывают orchestration, emission, gates ambiguity и
существенные decoders. Этот компактный index включает каждую top-level function
и каждый class method в семи semantic-модулях плюс их family facade, чтобы
поиск точного symbol никогда не заканчивался только на prose уровня module.

| Модуль | Symbols, представленные в этой главе |
|---|---|
| `spring_framework.py` | `spring_framework.analyze_spring_framework()`. |
| `spring_mvc.py` | `spring_mvc.resolve_spring_mapping_name()`, `spring_mvc.get_spring_annotation_paths()`, `spring_mvc.resolve_spring_request_method_expression()`, `spring_mvc.get_spring_request_methods()`, `spring_mvc.ordered_http_methods()`, `spring_mvc.union_request_method_conditions()`, `spring_mvc.log_unresolved_mapping()`, `spring_mvc.decode_builtin_spring_mapping()`, `spring_mvc.first_spring_mapping()`, `spring_mvc.compose_lexical_type_mapping()`, `spring_mvc.analyze_direct_spring_mvc_unit()`, `spring_mvc.spring_definition_runtime_retained()`, `spring_mvc.resolve_spring_mapping_spelling()`, `spring_mvc.source_annotation_definition()`, `spring_mvc.source_annotation_is_method_applicable()`, `spring_mvc.spring_method_applicable_component_candidates()`, `spring_mvc.collect_spring_mapping_branches()`, `spring_mvc.decode_alias_string()`, `spring_mvc.resolve_alias_annotation_target()`, `spring_mvc.parse_spring_alias_edge()`, `spring_mvc.spring_alias_element_type_valid()`, `spring_mvc.spring_alias_non_output_type_valid()`, `spring_mvc.spring_alias_value_cardinality_valid()`, `spring_mvc.spring_alias_known_type_shape()`, `spring_mvc.spring_alias_custom_types_compatible()`, `spring_mvc.resolve_ignored_sibling_alias_target()`, `spring_mvc.resolve_spring_alias_terminal()`, `spring_mvc.annotation_instance_values()`, `spring_mvc.decode_spring_alias_path_value()`, `spring_mvc.decode_spring_alias_method_value()`, `spring_mvc.invalid_spring_composed_mapping()`, `spring_mvc.log_spring_composed_issue()`, `spring_mvc.decode_spring_composed_mapping()`, `spring_mvc.spring_composed_definition_is_supported()`. |
| `spring_mvc_hierarchy.py` | `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer`, `SpringMvcHierarchyAnalyzer.__init__()`, `SpringMvcHierarchyAnalyzer._log()`, `SpringMvcHierarchyAnalyzer._is_direct_mvc_controller()`, `SpringMvcHierarchyAnalyzer._is_mapping_contract_type()`, `SpringMvcHierarchyAnalyzer._type_accessible()`, `SpringMvcHierarchyAnalyzer._method_accessible()`, `SpringMvcHierarchyAnalyzer._implementation_usable()`, `SpringMvcHierarchyAnalyzer._decode_annotations()`, `SpringMvcHierarchyAnalyzer._method_mapping()`, `SpringMvcHierarchyAnalyzer._type_mapping()`, `SpringMvcHierarchyAnalyzer._interface_mapping_branches()`, `SpringMvcHierarchyAnalyzer._resolve_mapping_source()`, `SpringMvcHierarchyAnalyzer._all_signatures()`, `SpringMvcHierarchyAnalyzer._implementation()`, `SpringMvcHierarchyAnalyzer._mapping_conditions()`, `SpringMvcHierarchyAnalyzer._controller_hierarchy_endpoints()`, `SpringMvcHierarchyAnalyzer.analyze()`, `spring_mvc_hierarchy.analyze_spring_mvc_hierarchy()`. |
| `spring_route_registrations.py` | `spring_route_registrations._log()`, `spring_route_registrations._known_direct_annotation()`, `spring_route_registrations._owner_is_concrete_class()`, `spring_route_registrations._owner_is_unique()`, `spring_route_registrations._method_variable_names()`, `spring_route_registrations._unqualified_static_member_resolves()`, `spring_route_registrations._call_has_owner()`, `spring_route_registrations._router_function_family()`, `spring_route_registrations._single_direct_return()`, `spring_route_registrations._resolve_path()`, `spring_route_registrations._direct_variable_initializer()`, `spring_route_registrations._is_route_identity_neutral_predicate()`, `spring_route_registrations._bind_this_handler()`, `spring_route_registrations._decode_handler()`, `spring_route_registrations._decode_selecting_predicate()`, `spring_route_registrations._decode_predicate()`, `spring_route_registrations._lambda_parameter_and_body()`, `spring_route_registrations._decode_builder_route_arguments()`, `spring_route_registrations._decode_builder_chain()`, `spring_route_registrations._decode_builder()`, `spring_route_registrations._decode_functional_expression()`, `spring_route_registrations._handler_endpoint()`, `spring_route_registrations._analyze_functional_routes()`, `spring_route_registrations._resolve_source_type()`, `spring_route_registrations._canonical_named_type()`, `spring_route_registrations._canonical_type()`, `spring_route_registrations._class_literal_type()`, `spring_route_registrations._decode_reflected_method()`, `spring_route_registrations._decode_request_mapping_info()`, `spring_route_registrations._local_declarators()`, `spring_route_registrations._tracked_local_kind()`, `spring_route_registrations._direct_expression()`, `spring_route_registrations._mapping_invocations()`, `spring_route_registrations._has_tracked_mutation()`, `spring_route_registrations._resolve_local_argument()`, `spring_route_registrations._is_programmatic_registration_owner()`, `spring_route_registrations._analyze_programmatic_registration_method()`, `spring_route_registrations._analyze_programmatic_mvc_registrations()`, `spring_route_registrations._deduplicate()`, `spring_route_registrations.analyze_spring_route_registrations()`. |
| `spring_clients.py` | `spring_clients._ClientCandidate`, `spring_clients._log()`, `spring_clients._direct_methods()`, `spring_clients._usable_contract_method()`, `spring_clients._resolved_exchange_annotations()`, `spring_clients._resolve_string_values()`, `spring_clients._normalize_client_path()`, `spring_clients._combine_client_paths()`, `spring_clients._decode_exchange_paths()`, `spring_clients._decode_exchange_methods()`, `spring_clients._decode_exchange_mapping()`, `spring_clients._ordered_methods()`, `spring_clients._union_exchange_methods()`, `spring_clients._endpoint()`, `spring_clients._http_interface_endpoints()`, `spring_clients._resolved_feign_client_markers()`, `spring_clients._decode_mvc_mapping()`, `spring_clients._first_mvc_mapping()`, `spring_clients._all_mvc_mappings()`, `spring_clients._feign_endpoints()`, `spring_clients._deduplicate()`, `spring_clients.analyze_spring_http_clients()`. |
| `spring_config.py` | `spring_config.SpringProjectPathConfiguration`, `spring_config.SpringWorkspacePathConfiguration`, `spring_config._canonical_path()`, `spring_config._log()`, `spring_config._known_type()`, `spring_config._infer_project_root()`, `spring_config._parse_properties()`, `spring_config._strip_yaml_comment()`, `spring_config._split_yaml_mapping()`, `spring_config._yaml_string()`, `spring_config._parse_mapping_yaml()`, `spring_config._normalize_optional_path()`, `spring_config._read_project_path_configuration()`, `spring_config.build_spring_path_configuration()`, `spring_config._resolve_placeholders()`, `spring_config._collapse_path_slashes()`, `spring_config.resolve_spring_endpoint_path()`, `spring_config.resolve_spring_client_path_layers()`, `spring_config.make_spring_path_resolver()`, nested `apply()`, `spring_config.apply_spring_path_configuration()`, `spring_config._iter_resource_handler_configurer_methods()`, `spring_config._invocation_name()`, `spring_config._registry_is_mutated()`, `spring_config._deduplicate()`, `spring_config.analyze_spring_resource_handlers()`. |
| `spring_gateway.py` | `spring_gateway.GatewayPathResolver`, `spring_gateway.GatewayRouteConditions`, `spring_gateway._log()`, `spring_gateway._known_direct_annotation()`, `spring_gateway._owner_is_unique_concrete_class()`, `spring_gateway._single_direct_return()`, `spring_gateway._validated_route_locator_builder_name()`, `spring_gateway._decode_predicate_lambda_parameter()`, `spring_gateway._resolve_path()`, `spring_gateway._resolve_http_method()`, `spring_gateway._invocation_chain()`, `spring_gateway._decode_predicate_chain()`, `spring_gateway._decode_predicate_helper()`, `spring_gateway._decode_route_lambda()`, `spring_gateway._route_lambda_argument()`, `spring_gateway._decode_route_locator_publisher()`, `spring_gateway._endpoint()`, `spring_gateway._deduplicate()`, `spring_gateway.analyze_spring_gateway()`. |
| `spring_websocket_messaging.py` | `spring_websocket_messaging._unique_concrete_configurers()`, `spring_websocket_messaging._formal_parameter()`, `spring_websocket_messaging._canonical_method()`, `spring_websocket_messaging._receiver_mutated()`, `spring_websocket_messaging._invocation_name()`, `spring_websocket_messaging._direct_receiver_calls()`, `spring_websocket_messaging._receiver_calls()`, `spring_websocket_messaging._arguments()`, `spring_websocket_messaging._resolved_paths()`, `spring_websocket_messaging._project_key()`, `spring_websocket_messaging._stomp_configurer_methods()`, `spring_websocket_messaging._websocket_handler_configurer_methods()`, `spring_websocket_messaging._direct_call_with_allowed_chain()`, `spring_websocket_messaging._handler_field_name()`, `spring_websocket_messaging._has_typed_websocket_handler_field()`, `spring_websocket_messaging._websocket_handler_handshake_endpoints()`, `spring_websocket_messaging._stomp_handshake_endpoints()`, `spring_websocket_messaging._stomp_application_prefixes()`, `spring_websocket_messaging._annotation_paths()`, `spring_websocket_messaging._known_annotations()`, `spring_websocket_messaging._lexical_controller_type_chain()`, `spring_websocket_messaging._has_controller_marker_in_lexical_chain()`, `spring_websocket_messaging._lexical_message_mapping_paths()`, `spring_websocket_messaging._message_mapping_endpoints()`, `spring_websocket_messaging._deduplicate()`, `spring_websocket_messaging.analyze_spring_websocket_and_messaging()`. |

## 14. Практический порядок чтения

При исследовании случайно выбранного Spring method:

1. найдите его точную координату в section 13;
2. прочитайте contract table его модуля, чтобы узнать caller, input/output и
   область rejection;
3. пройдите вверх по call graph этого модуля до production entry point;
4. если он создаёт fact, используйте section 10.1 для проверки attribution и
   evidence;
5. проследуйте по section 10.2 через локальную deduplication и path
   configuration; и
6. используйте section 12, чтобы отличить намеренно пропущенный candidate от
   exception всего run.

Это даёт оба view, нужных для maintenance: существующая карта уровня module
объясняет ownership, а эта глава делает отдельные methods и проходящие через
них data напрямую доступными для поиска.

Продолжите с
[14 — Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) или
используйте [method lookup](15-method-lookup.md) для точного source symbol.
