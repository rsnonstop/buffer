# 06 — Логика JAX-RS и Java WebSocket

[← Дополнительные поверхности Spring](05-spring-additional-surfaces.md) · [Оглавление](README.md) · [Далее: Output и evidence →](07-output-evidence-reports.md)

CLI token для этой ветки — `jaxrx`. Она создаёт два разных inbound-семейства
из одного parse-once Java workspace:

1. HTTP resources JAX-RS, включая методы из hierarchy и subresources.
2. Routes для Java WebSocket handshake, объявленные через `@ServerEndpoint`.

Все producers возвращают неизменяемые значения
[`EndpointFact`](../src/noir/model.py).

Дополнение на уровне методов:
[14 — Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) прослеживает
прямые resources, выбор deployment, привязку hierarchy, recursion subresource
и построение WebSocket fact.

## 1. Владение и порядок выполнения

| Владелец | Точка входа | Ответственность |
|---|---|---|
| [`noir.pipeline`](../src/noir/pipeline.py) | `run_analysis()` | Создаёт state выбранных семейств, строит inventories, подготавливает и запускает выбранные adapter'ы. |
| [`noir.frameworks`](../src/noir/frameworks.py) | `FRAMEWORK_ADAPTERS` | Связывает selection `jaxrx` с независимым facade этого семейства в детерминированном порядке. |
| [`noir.jaxrs_framework`](../src/noir/jaxrs_framework.py) | `prepare_jaxrs_analysis()` / `analyze_jaxrs_framework()` | Подготавливает private state JAX-RS и владеет порядком direct-, hierarchy- и WebSocket-анализа. |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `build_java_compilation_unit()` | Разбирает один snapshot source и записывает syntax/query facts. |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace()` | Строит нейтральные индексы type, member, annotation и constant. |
| [`noir.jaxrs`](../src/noir/jaxrs.py) | `JaxRsState` / `build_jaxrs_state()` / `analyze_direct_jax_rs_unit()` | Хранит значения designator/application отдельно от Java facts; анализирует прямые resources. |
| [`noir.jaxrs_annotations`](../src/noir/jaxrs_annotations.py) | `classify_jaxrs_annotation()` / `classify_jaxrs_trigger()` | Владеет broad- и trigger-значениями аннотаций, используя явный JAX-RS state; общий inventory владеет обходом source и reporting. |
| [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) | `build_jax_rs_deployment_model()` / `select_jax_rs_deployment_prefix()` | Объединяет source applications с ограниченным evidence `web.xml`. |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaSourceHierarchyGraph` | Владеет нейтральной hierarchy, generic adaptation и erased signatures. |
| [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) | `analyze_jax_rs_hierarchy_and_subresources()` | Разрешает annotation bundles, implementations и traversal locator. |
| [`noir.java_websocket`](../src/noir/java_websocket.py) | `analyze_java_websocket_endpoints()` | Извлекает handshakes WebSocket Javax/Jakarta. |

```mermaid
sequenceDiagram
    participant P as run_analysis
    participant F as facade jaxrs_framework
    participant W as общий Java workspace
    participant X as JaxRsState
    participant I as inventories
    participant D as deployment model
    participant J as прямой JAX-RS
    participant H as hierarchy/subresources
    participant S as Java WebSocket

    P->>W: один раз разобрать каждый source
    P->>X: build_jaxrs_state(workspace) для выбранного JAX-RS
    P->>I: классифицировать через выбранные callbacks, связанные со state
    P->>F: prepare_jaxrs_analysis(request, workspace, state)
    F->>D: объединить state.applications и evidence web.xml
    F->>X: установить state.deployment_model
    loop каждый compilation unit
        F->>J: analyze_direct_jax_rs_unit(unit, workspace, state=state)
    end
    F->>H: добавить inherited и locator-reached facts с использованием state
    F->>S: добавить facts ServerEndpoint
    F-->>P: упорядоченный tuple EndpointFact
    P-->>P: вернуть типизированный AnalysisResult
```

Когда работают обе framework-ветки, они разделяют нейтральный Java workspace;
свой deployment state потребляет только JAX-RS. Pipeline завершает подготовку
каждого выбранного семейства до analysis, затем Spring endpoint passes
предшествуют JAX endpoint passes. Ни одно семейство не импортирует другое и
не разбирает source повторно.

`build_jaxrs_state(workspace)` возвращает новый `JaxRsState`. Его index'ы —
интерпретация семейства, поэтому в нейтральный `JavaWorkspace` не добавляются
JAX-RS keys. Этот state создаётся только для выбранного JAX-RS analysis;
очистка отключённого семейства не требуется. Поля state:

| Поле state | Структура значения | Смысл |
|---|---|---|
| `state.custom_designator_candidates` | set FQN annotation, например `{"app.Fast"}` | релевантные identities source-аннотаций, включая невалидные candidates |
| `state.custom_designators` | FQN annotation → list записей `{namespace, method, source_path, ...}` | доказанные custom request-method designators |
| `state.applications` | list записей `{namespace, package, path, fqn, ...}` | source-evidence `@ApplicationPath`, включая неопределённость `path=None` |
| `state.deployment_model` | application key `(project root, package, family-or-None)` → prefix плюс lookup-представления source class и explicit descriptor | deployment keys project/application после объединения evidence source и descriptor |

Невалидные candidate'ы designator сохраняются намеренно: релевантная, но
невалидная аннотация должна блокировать выбор method, а не выглядеть
несвязанной.
Конкретные значения словарей для каждого neutral и JAX-specific index приведены
в разделе
[Словарь workspace и index'ов](11-naming-and-code-vocabulary.md#workspace-and-index-vocabulary).

## 2. Уравнения route

Для прямого root method:

```text
deployment prefix + root @Path + method @Path = endpoint path
```

Для inherited method или leaf subresource:

```text
deployment prefix
+ root @Path
+ selected interface contract @Path layers
+ locator @Path segments
+ leaf @Path
= endpoint path
```

Каждый включённый segment должен разрешаться статически. Request method
происходит ровно из одного валидного стандартного или custom designator.
Частичные paths никогда не выдаются.

## 3. Доказательство семейства Javax/Jakarta

Поддержка JAX-RS симметрична для `jakarta.ws.rs` и `javax.ws.rs`, а core types
находятся в соответствующем package `.core`.

| Источник evidence | Правило семейства |
|---|---|
| root `@Path` | задаёт семейство resource |
| стандартный designator | должен соответствовать root |
| custom designator | его настоящий `@HttpMethod` задаёт совпадающее семейство |
| method `@Path` | должен соответствовать root |
| `@ApplicationPath` | должен соответствовать непосредственно расширяемому core `Application` |
| annotation bundle hierarchy | каждая распознанная поддерживаемая JAX-аннотация должна принадлежать одному семейству |
| `@ServerEndpoint` | независимое семейство `jakarta.websocket` или `javax.websocket` |

Resolution учитывает imports и source. Локальные types, конфликты
exact/wildcard, недоступные declarations, смешанные семейства и дублирующиеся
fully qualified source identities приводят к fail-closed.

## 4. Custom request-method designators

[`index_jax_rs_custom_designators`](../src/noir/jaxrs.py) проверяет объявления
source-аннотаций до разрешения любого их использования. Валидное объявление
имеет:

1. ровно один настоящий Javax/Jakarta `@HttpMethod`;
2. ровно один настоящий `java.lang.annotation.Retention`;
3. `RetentionPolicy.RUNTIME`, разрешённый через правила Java name/static-member;
4. статически разрешённый String token;
5. token длиной не более 128 символов; и
6. token, соответствующий HTTP token grammar.

Общий constant resolver поддерживает ограниченные source constants,
concatenations, parentheses, точные static imports и однозначные static
wildcards. Он отвергает циклы, mutable/inaccessible fields, неправильные types,
неоднозначных owners и expressions сверх лимита.

[`resolve_custom_designator`](../src/noir/jaxrs.py) затем разрешает применённую
аннотацию ровно в одно доступное source declaration и одну валидную record
из обязательного аргумента `state=`. Нейтральные Java definitions по-прежнему
обеспечивают identity и доступность declaration. Результат — `none`, `resolved`,
`invalid` или `ambiguous`. Релевантный
невалидный или неоднозначный результат делает выбор request-method невалидным.

Custom-аннотации только из dependency нельзя доказать, поскольку их
declarations и retention evidence отсутствуют в workspace.

## 5. Стандартные designators и paths метода

Моделируются стандартные аннотации `GET`, `POST`, `PUT`, `DELETE`, `PATCH`,
`HEAD` и `OPTIONS`. Стандартный designator должен иметь marker-форму;
arguments, несколько designators, смешанные семейства или релевантный
невалидный custom designator отвергают метод.

`@Path` уровня метода необязателен. Если присутствует, должна разрешиться ровно
одна настоящая аннотация семейства root с одним значением. Принимается один
positional value или один named `value`; смешивание этих форм, дополнительные
attributes, отсутствие/несколько values или неразрешённые expressions приводят
к fail-closed. Если аннотация отсутствует, используется пустой segment.

## 6. Source index `@ApplicationPath`

[`index_jax_rs_application_paths`](../src/noir/jaxrs.py) принимает конкретный
source class с ровно одним настоящим `@ApplicationPath` и прямым superclass
соответствующего core type `Application`. Непрямое наследование не создаёт
application record; public visibility не требуется.

Формы failure намеренно различаются:

| Условие | Результат |
|---|---|
| abstract application | диагностируется и исключается |
| несовпадение семейства или неразрешённый/непрямой superclass | диагностируется и исключается |
| несколько настоящих аннотаций | сохраняются невалидные records с null-path |
| одна аннотация с неразрешённым value | сохраняется одна record с null-path |
| одна разрешённая аннотация | валидная application record |

Исключённое application может оставить пустой prefix. Сохранённый null path
участвует в неоднозначности и может подавлять затронутые endpoints.

## 7. Прямой анализ resource

[`analyze_direct_jax_rs_unit`](../src/noir/jaxrs.py) получает compilation unit
из общего workspace и явно требует выбранный `JaxRsState` через `state=`.
Эти source index'ы повторно используются для каждого unit.

### 7.1 Gate корня

Прямой root — видимый в workspace, нелокальный, конкретный class или record с
ровно одним настоящим разрешимым прямым `@Path`. Вложенный type с собственным
прямым path — независимый root; лексические внешние paths не наследуются.

Прямой pass не требует public root, уникальной fully qualified addressability
или доказанного runtime construction.

### 7.2 Gate метода

Для каждого прямого method под подходящим root:

1. разрешить ровно один request-method designator;
2. потребовать явный modifier `public`;
3. разрешить ноль или один `@Path` того же семейства;
4. выбрать один deployment prefix;
5. скомпоновать и выдать `EndpointFact`.

Метод с `@Path`, но без designator, не является прямым endpoint; анализ
hierarchy может использовать его как locator.

### 7.3 Accessor-методы компонентов record

Аннотации компонента могут описывать его неявный accessor без аргументов.
Участвуют только стандартные designators, `@Path` и source-аннотации с
доказанной применимостью к methods. Компонент игнорируется, если record
объявляет явный accessor того же имени без параметров.

Синтезированный fact использует имя компонента, пустые parameters и компонент
record как `represented_targets`. Его `annotation_evidence` пуст, потому что
request-аннотация находится не на declaration метода; поэтому строка CSV тоже
пуста.

## 8. Deployment model и `web.xml`

[`build_jax_rs_deployment_model`](../src/noir/jaxrs_deployment.py) объединяет
переданные application records с ограниченным evidence servlet descriptor.
Он возвращает model; `prepare_jaxrs_analysis(request, workspace, state)`
сохраняет результат в `state.deployment_model`. Builder не получает и не
изменяет Java workspace.

### 8.1 Владение project и source keys

Ближайший layout, содержащий `src/main/java`, `src/main/resources` или
`src/main/webapp`, определяет владение project. Без marker project считается
analysis root. Key source application имеет вид:

```text
(project root, application package, Javax/Jakarta family)
```

Records с общим key сливаются, только если каждый path разрешён и все paths
совпадают; иначе prefix key неизвестен.

### 8.2 Bounds descriptor

Рассматриваются только regular files с точным именем `web.xml`. Discovery
применяет настроенные правила отсечения directory, исключает symlink'и и файлы
больше 10 MiB, а также диагностирует нечитаемый или malformed XML.

Parser читает прямые servlet declarations, init parameters, mappings и URL
patterns. Mapping релевантен, если его servlet class совпадает с ограниченным
набором имён Jersey/RESTEasy/CXF или если его servlet/init parameters называют
поддерживаемый application class. Поддерживаемые имена init parameter:
`javax.ws.rs.Application` и `jakarta.ws.rs.Application`.

Нормализация URL pattern:

| Шаблон | Префикс |
|---|---|
| `/api/*`, `/api/`, `api/*` | `/api` |
| `/` | пустой |
| `/*` | `/` |

Явный mapping, связанный с application key, переопределяет Java
`@ApplicationPath`; конфликтующие явные values делают key неизвестным. Один
несвязанный распознаваемый servlet prefix может применяться к известным source
applications, только если все такие mappings совпадают и в project нет
explicit application key. Descriptor сам по себе не создаёт endpoints.

### 8.3 Выбор prefix

[`select_jax_rs_deployment_prefix`](../src/noir/jaxrs_deployment.py) фильтрует
candidates по project, которому принадлежит resource, по совместимому family и
по application packages, являющимся ancestors package resource'а. Он сохраняет
наиболее специфичный package, отдаёт предпочтение explicit descriptor evidence,
затем exact-family evidence и требует, чтобы все оставшиеся candidates задавали
один и тот же валидный path.

Отсутствие candidates означает пустой prefix, кроме узкого fallback для
единственного project с нестандартным layout: resource должен принадлежать
этому единственному project, а все совместимые entries — совпадать.
Неоднозначность диагностируется и подавляет endpoint.

Если `state.deployment_model` равен `None`,
`resolve_jax_rs_resource_prefix(unit, namespace, owner_name, state=state)`
использует `state.applications` с теми же принципами наиболее специфичного
package/agreement. Обычный pipeline подготавливает полную model до endpoint
analysis.

<a id="9-hierarchy-binding"></a>

## 9. Привязка hierarchy

[`noir.java_hierarchy`](../src/noir/java_hierarchy.py) владеет уникальными
видимыми source types, edges class/interface, generic substitutions, source
methods, erased signatures и выбором максимально специфичного/default
interface. Дублирующиеся fully qualified identities исключаются из graph.

[`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) добавляет классификацию
JAX-аннотаций, atomic inheritance bundle, binding implementation'ов, interface
path layers и traversal locator'ов. `JaxRsHierarchyAnalyzer(workspace,
state=jaxrs_state)` сохраняет явный state семейства рядом с нейтральным Java
graph; hierarchy и direct passes используют одно представление семейства.

### 9.1 Bounds и implementations

| Ограничение | Значение |
|---|---:|
| depth hierarchy | 12 |
| расширенные states hierarchy | 256 |
| generic environment для одного interface | одно согласованное environment |

Identity override — имя метода плюс erased parameter types; return type не
входит в signature. Generic environments подставляются до erasure.

Пригодная implementation является non-static, non-private, non-abstract и
либо явно public методом class/record, либо default методом interface с телом.
Дублирующиеся erased signatures, неразрешённые signature types, неоднозначные
classes/defaults и несопоставимые annotation origins приводят к fail-closed.

### 9.2 Неделимые annotation bundles

Annotation bundle выбранного метода неделим:

- любая прямая аннотация, кроме настоящего `java.lang.Override`, или любая
  прямая аннотация параметра делает implementation источником bundle;
- иначе побеждает ближайший подходящий bundle superclass;
- иначе может победить один максимально специфичный bundle interface;
- несколько или невалидные origins отвергают signature.

Весь поддерживаемый bundle проверяется на одно семейство Javax/Jakarta.
Поведение route происходит из `@Path` и request designator. Supporting
annotations, такие как consumes/produces, context, suspended и parameter
bindings, классифицируются, но их runtime behavior не моделируется.

Если метод interface предоставляет выбранный bundle, один настоящий
`@Path` уровня типа того же семейства на этом interface добавляет слой path.
Path уровня superclass этим правилом не добавляется.

### 9.3 Разобранное значение: binding interface contract к class

Предположим, эти декларации находятся в общем workspace, а deployment prefix
не применяется:

~~~java
// app/ItemsApi.java
package app;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;

@Path("/contract")
public interface ItemsApi {
    @GET
    @Path("/items/{id}")
    Item find(@PathParam("id") String id);
}
~~~

~~~java
// app/ItemsResource.java
package app;

import jakarta.ws.rs.Path;

@Path("/api")
public class ItemsResource implements ItemsApi {
    @Override
    public Item find(String id) { return null; }
}

record Item(String id) {}
~~~

Нейтральный graph содержит записи по FQN и адаптированный context traversal:

~~~python
graph.types == {
    "app.ItemsApi": api_type_record,
    "app.ItemsResource": resource_type_record,
    "app.Item": item_type_record,
}

context = JavaHierarchyContext(
    class_states=[(resource_type_record, {})],
    interface_roots=[(api_type_record, {})],
    complete=True,
)
~~~

Для erased signature `("find", ("java.lang.String",))` class method является
implementation, а interface method предоставляет неделимый annotation bundle:

~~~python
effective = JaxRsEffectiveMethod(
    implementation=resource_find_method,
    implementation_env={},
    annotation_source=api_find_method,
    binding={
        "kind": "leaf",
        "path": "/items/{id}",
        "method": "GET",
        "evidence_node": get_annotation_node,
        "annotation_identity": "jakarta.ws.rs.GET",
        "annotation_family": "jax-rs-designator",
    },
    hierarchy_added=True,
    signature=("find", ("java.lang.String",)),
)
~~~

Таким образом, path складывается из следующих слоёв:

~~~text
empty deployment prefix
+ concrete root /api
+ selected interface contract /contract
+ leaf /items/{id}
= /api/contract/items/{id}
~~~

Получившийся fact представляет inbound JAX-RS `GET`, приписанный concrete
handler `ItemsResource.find`, и содержит написание parameter `String id`.
Поскольку `@GET` находится на другом source method, а не на concrete
implementation, fact не заявляет evidence строки annotation того же method.
Полная семантика и формы constructor'ов `JavaTypeRecord`, `JavaHierarchyContext`
и `JaxRsEffectiveMethod` описаны в разделе
[Структуры данных по модулям](11-naming-and-code-vocabulary.md#java-data-structures-by-module).

## 10. Locators subresource

Эффективный метод является leaf, если имеет request designator, либо locator,
если имеет непустой `@Path` без designator.

Target locator должен однозначно разрешаться в конкретный source class или
record. Поддерживаются direct declared type, `Class<T>`, точный parameterized
source type и raw generic source type с его ограниченным default environment.
Отвергаются interfaces, abstract/external/duplicate/inaccessible types,
primitives, arrays и wildcards, неразрешённые variables, malformed arity и
формы не-resource.

Path метода locator определяет переход; собственный type-level `@Path` target
не добавляется.

Traversal является branch-local и ограничен depth'ом 16, 4096 states на root и
общей длиной составного path 8192 символа. Активные циклы type/edge останавливают эту
ветвь. Leaf hierarchy/subresource выдаётся только при достижении через locator
или добавлении через hierarchy binding, что предотвращает дублирование обычных
прямых leaves.

[`deduplicate_endpoint_facts`](../src/noir/evidence.py) удаляет локальные для
analyzer дубликаты по typed identity и объединяет их annotation/target
evidence. Public consolidation по шести полям остаётся более поздней границей.

## 11. Handshake'и Java WebSocket

[`analyze_java_websocket_endpoints`](../src/noir/java_websocket.py) распознаёт
`jakarta.websocket.server.ServerEndpoint` и
`javax.websocket.server.ServerEndpoint` на одном уникальном workspace type.

Тип и каждый enclosing type должны быть public и видимыми. Class должен быть
concrete и иметь неявный или явный public constructor без аргументов; вложенный
class также должен быть static. Record должен иметь ноль компонентов. Остальные
виды type'ов отвергаются.

Аннотация принимает один positional value или named `value`. Смешивание форм,
отсутствующие/несколько values, неразрешённые constants, пустые paths, queries
или fragments приводят к fail-closed. При отсутствии начального slash он
добавляется. Атрибуты encoder, decoder, subprotocol и configurator не влияют на
route identity.

JAX deployment prefix не применяется. Выданный fact использует:

| Поле | Значение |
|---|---|
| method | `GET` |
| protocol / surface / direction | `ws` / `websocket` / inbound |
| technology | `jax-websocket` |
| handler | endpoint type |
| annotation evidence | пустое |
| represented target | аннотированный type |

`@ServerEndpoint` не является request-method evidence, поэтому публичная
ячейка строки аннотации пуста.

## 12. Типизированный provenance и diagnostics

Прямые JAX methods записывают handler method как represented target, а
применённый стандартный/custom designator — как annotation evidence.
Синтезированные accessor'ы record представляют компонент и не несут method
evidence.

Facts hierarchy и subresource всегда приписывают public handler и target
выбранной implementation. Аннотация superclass/interface может доказать route,
но даёт evidence строки CSV только тогда, когда её source method является
method реализации. Поэтому evidence между declarations оставляет public line
пустой.

Diagnostics проходят через
[`noir.diagnostics.record`](../src/noir/diagnostics.py). Collector, подключённый
application/CLI, захватывает их; прямой call analyzer'а без подключённого
collector остаётся без file I/O и просто не захватывает сообщение. Diagnostics не восстанавливаются
из endpoint facts.

## 13. Bounds и пределы доказательства

| Ограничение или неопределённость | Предел / область сохранения |
|---|---|
| Java constant depth / разрешённый string | 12 / 8192 символов |
| custom HTTP token | 128 символов |
| размер descriptor | 10 MiB |
| hierarchy | depth 12, 256 states |
| traversal locator | depth 16, 4096 states на root |
| составной path locator | 8192 символов |
| плохой root `@Path` | прямые методы root |
| невалидный/множественный/смешанный designator | method или binding |
| non-public прямой метод | method |
| неоднозначный deployment prefix | связанные endpoints |
| неполная hierarchy | неопределённые inherited additions, но не direct facts |
| невалидный return locator'а / cycle / превышение limit | ветвь locator или budget root |
| невалидный type/path `@ServerEndpoint` | WebSocket type |
| malformed descriptor | descriptor; остальное evidence сохраняется |

Эта model не доказывает runtime scanning/registration, designators или
hierarchies из dependency bytecode, dynamic locator polymorphism,
constructor/injection viability для прямых roots, filters, proxies, hosts,
authentication, authorization, полную семантику parameter/media, WebSocket
callbacks или runtime deployment reachability за пределами ограниченного
source и descriptor evidence выше.

Далее: [07 — Output, evidence и reports](07-output-evidence-reports.md).
