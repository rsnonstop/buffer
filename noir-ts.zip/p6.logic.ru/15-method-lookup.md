# 15 — Поиск методов и стратегия чтения

[← Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) ·
[Оглавление](README.md) · [Добавление поддержки framework →](16-adding-framework-support.md)

Эта глава служит мостом между символом, выбранным в `src/`, и общей историей
приложения. Она не повторяет каждый алгоритм. Вместо этого она показывает,
какая углублённая глава владеет символом, в какой runtime-маршрут он входит и
какие другие представления отвечают на следующий вероятный вопрос читателя.

## 1. Контракт документации методов

Главы уровня методов (method-level) используют точные имена Python-символов.
Поэтому поиск по всему проекту для выбранной функции, класса или нетривиального
метода класса должен находить одно из двух:

- method card, которая объясняет caller, input, решения, output, effects и
  поведение при ошибке; или
- компактную запись в таблице helpers, которая объясняет небольшую операцию и
  называет семейство методов или call chain, задающую её контекст.

«Важным методом» считается любое определение, которое владеет хотя бы одним из
следующих аспектов:

- entry point приложения или analyzer;
- orchestration или порядок проходов;
- переход между domain values;
- доказательство Java identity, visibility, constant, hierarchy или
  ambiguity;
- декодирование framework semantics;
- создание, объединение или подавление endpoint/evidence;
- validation, diagnostics, filesystem publication или другой наблюдаемый
  effect; либо
- существенное ветвление, чей fail-closed результат влияет на coverage.

Миниатюрные accessors и синтаксические удобства не получают полных method
cards. Их точные имена всё равно присутствуют в сгруппированных таблицах рядом
с decision method, который их использует. Dunder-методы описываются вместе с
типом значения, которому они принадлежат, если они обеспечивают domain
invariant.

## 2. Выберите руководство, владеющее методом

| Выбранный source-файл | Method-level руководство | Основные данные, выходящие из модуля |
|---|---|---|
| `noir_sbt.py`, `application.py`, `cli.py` | [Методы core runtime](12-core-runtime-methods.md) | arguments, `AnalysisRequest`, artifacts, exit status |
| `noir/__init__.py` | [Методы core runtime](12-core-runtime-methods.md) для lazy alias application/output и re-export'ов domain | Alias'ы package API; `__getattr__` загружает non-model export'ы при первом обращении, а `__dir__` объявляет их без загрузки |
| `pipeline.py`, `frameworks.py`, `discovery.py`, `tree_sitter_runtime.py`, `diagnostics.py` | [Методы core runtime](12-core-runtime-methods.md) | `SourceSnapshot`, `FrameworkPlan`, lifecycle adapter'ов, diagnostics, `AnalysisResult` |
| `spring_framework.py`, `jaxrs_framework.py`, `wicket_framework.py` | [Методы core runtime](12-core-runtime-methods.md) и [добавление поддержки framework](16-adding-framework-support.md) | Hook'и configure/prepare/analyze, принадлежащие family; сейчас Wicket возвращает пустой tuple |
| `java_ast.py`, `java_frontend.py`, `java_queries.py`, `java_methods.py` | [Методы core runtime](12-core-runtime-methods.md) | facts compilation unit, query captures, indexes `MethodFact` |
| `java_workspace.py`, `java_hierarchy.py`, `model.py`, `immutability.py`, `paths.py` | [Методы core runtime](12-core-runtime-methods.md) | общие workspace indexes и immutable domain values |
| `spring_mvc.py`, `spring_mvc_hierarchy.py` | [Методы Spring](13-spring-methods.md) | прямые, composed, record-accessor и унаследованные MVC facts |
| `spring_route_registrations.py`, `spring_gateway.py` | [Методы Spring](13-spring-methods.md) | functional, programmatic и Gateway facts |
| `spring_clients.py`, `spring_config.py`, `spring_websocket_messaging.py` | [Методы Spring](13-spring-methods.md) | client, resource, handshake, messaging и настроенные Spring facts |
| `jaxrs.py`, `jaxrs_deployment.py`, `jaxrs_hierarchy.py`, `java_websocket.py` | [Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) | прямые, унаследованные, subresource, deployment-aware и WebSocket facts |
| `inventory.py`, `evidence.py`, `output.py`, `reports.py` | [Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) | audit inventories, owned evidence, consolidated rows, bytes отчётов |
| `comparison.py`, `contracts.py` | [Методы JAX-RS, evidence и output](14-jaxrs-output-methods.md) | проверенные Noir locations, элементы сравнения, стабильные contract values |

Предыдущие главы остаются представлением, ориентированным на поведение. Guides
методов — это представление, ориентированное на реализацию. Например,
используйте [Spring MVC](04-spring-mvc.md), чтобы понять policy composed
mapping, а руководство по методам Spring — чтобы проследить
`decode_spring_composed_mapping()` через его helper calls.

## 3. Начните с одного из четырёх runtime trunks

Большинство поисков методов упрощается, когда выбранный символ помещён на один
из четырёх основных runtime-маршрутов (trunks).

Руководство намеренно использует несколько ограниченных call graphs вместо
одного графа всего package. Граф всего package смешал бы orchestration,
синтаксические utilities, framework decisions и rendering в нечитаемую сеть.
Каждый trunk показывает стабильные границы stages; затем углублённая глава
раскрывает только соответствующую ветвь вплоть до decision methods и
преобразований данных.

### 3.1 Invocation и orchestration

~~~mermaid
flowchart LR
    CLI["run_cli()"] --> APP["analyze()"]
    APP --> PIPE["run_analysis()"]
    PIPE --> SNAP["_snapshot_sources()"]
    PIPE --> SELECT["_select_frameworks()"]
    PIPE --> WORK["_build_workspace()"]
    PIPE --> LOOKUP["frameworks.adapters_for_plan()"]
    WORK --> CFG["создать state выбранных семейств и связать recognizers"]
    CFG --> INV["построить inventory"]
    INV --> PREP["подготовить все выбранные adapter'ы"]
    LOOKUP --> PREP
    PREP --> RUN["анализировать выбранные adapter'ы в порядке registry"]
    RUN --> SP["spring_framework.analyze_spring_framework()"]
    RUN --> JP["jaxrs_framework.analyze_jaxrs_framework()"]
    RUN --> WP["wicket_framework.analyze_wicket_framework()"]
    SP --> RESULT["AnalysisResult"]
    JP --> RESULT
    WP -. пустой tuple .-> RESULT
~~~

Используйте этот trunk для вопросов о timing, выбранных frameworks, порядке
analyzers, области diagnostics или о том, почему ошибка изменила либо не
изменила artifact.

### 3.2 Java evidence и семантическое доказательство

~~~mermaid
flowchart LR
    BYTES["bytes из snapshot"] --> UNIT["build_java_compilation_unit()"]
    UNIT --> WORK["build_java_workspace()"]
    WORK --> IDX["indexes типов / constants / annotations / methods"]
    IDX --> RESOLVE["resolvers имён, значений, visibility и hierarchy"]
    RESOLVE --> DECODER["framework decoder"]
    DECODER --> FACT["EndpointFact или fail-closed skip"]
~~~

Используйте этот trunk, когда метод работает с Tree-sitter nodes, imports,
constants, type identity, hierarchy, source-defined annotations или ambiguity.

### 3.3 Извлечение framework

~~~mermaid
flowchart TD
    UNIT["общие compilation units"] --> DIRECT["прямой проход по каждому unit"]
    WORK["общие workspace indexes"] --> PROJECT["дополнительный проход по project"]
    DIRECT --> FACTS["кандидаты EndpointFact"]
    PROJECT --> FACTS
    FACTS --> CHOICE{"этот producer определяет<br/>локальную deduplication?"}
    CHOICE -->|"да"| LOCAL["локальная deduplication<br/>с сохранением typed evidence"]
    CHOICE -->|"нет"| PIPE["результат pipeline"]
    LOCAL --> PIPE
~~~

Используйте этот trunk, чтобы понять, как framework-specific кандидат проходит
gates, декодируется, получает attribution и превращается в typed evidence.
Руководства Spring и JAX-RS содержат отдельные call graphs для каждой
поддерживаемой surface; facade Wicket показывает lifecycle выбранного family,
но semantic producer пока отсутствует.

### 3.4 Presentation и publication

~~~mermaid
flowchart LR
    FACT["EndpointFact"] --> CAND["EndpointRowCandidate"]
    CAND --> GROUP["ConsolidatedEndpoints"]
    GROUP --> CSV["CSV с семью колонками"]
    GROUP -->|"represented targets"| ABSENT["annotations-without-endpoints report"]
    TRIGGER["final-trigger inventory"] --> ABSENT
    TRIGGER --> PROJ["trigger_annotation_log_inventory"]
    PROJ --> LOG["annotation and diagnostics log"]
    DIAG["run-local diagnostics"] --> LOG
    TRIGGER --> COMP["опциональное сравнение Noir"]
    NOIR["загруженные Noir locations"] --> COMP
    COMP --> REPORT["comparison report"]
~~~

Используйте этот trunk, когда выбранный метод нормализует paths, объединяет
identities, выбирает `method_annotation_line`, выполняет rendering текста,
сравнивает Noir locations или публикует bytes.

## 4. Читайте method card в таком порядке

Каждая полная method card отвечает на одни и те же вопросы:

1. **Почему метод вызывается?** Входящее ребро и владеющий runtime stage.
2. **Что он получает?** Важные типы и состояние значений: raw, parsed,
   resolved, normalized или уже consolidated.
3. **Какое доказательство требуется?** Identity, placement, visibility,
   uniqueness, bounds или gates активации framework.
4. **Что он может вернуть?** Domain value, ноль или несколько facts, sentinel
   пропуска, rendered bytes либо exception.
5. **Что он может изменить?** Workspace indexes, run-local diagnostics,
   stdout или output artifact. У большинства semantic helpers нет внешнего
   side effect.
6. **Как обрабатывается неопределённость?** Fail-closed skip, diagnostic,
   bounded fallback или fatal error.
7. **Куда результат идёт дальше?** Исходящее ребро и следующее представление.

Этот порядок предотвращает распространённую ошибку чтения: понимание локального
выражения без понимания того, собирает ли метод evidence, доказывает endpoint
или выполняет projection уже доказанного fact.

## 5. Метки состояний данных в call graphs

| Метка | Значение | Правило mutation/effect |
|---|---|---|
| raw source | точные Java bytes и paths, сохранённые в snapshot | каждый Java-файл читается pipeline один раз; marker-only POM input обрабатывается отдельно |
| syntax node | Tree-sitter node, связанный с одним сохранённым tree | никогда не действителен за пределами lifetime своего workspace |
| unit fact | запись dictionary для одного compilation unit | строится один раз, затем обогащается при workspace/framework indexing и повторно используется analyzer'ами |
| workspace index | межфайловая карта identity/value/hierarchy | за run-local mutation отвечают builders, framework attachers и явные support caches |
| decoded candidate | ограниченная framework semantics, ещё не обязательно endpoint | может быть отброшен при ambiguity или на последующем gate |
| `EndpointFact` | typed и подкреплённое source утверждение об endpoint | его создают analyzer'ы; output не может его придумать |
| owned evidence | проверенные `AnnotationEvidence` / `SourceTarget` | объединяются без изменения public identity |
| row candidate | шесть public fields плюс private evidence | создаётся только на границе presentation |
| consolidated result | отсортированные rows плюс union represented targets | immutable input для rendering artifacts |
| prepared payload | полные bytes отчётов и completion text, подготовленные в памяти | rendering byte reports не имеет filesystem effect; rendering CSV и `Annotation and diagnostics log` выполняется непосредственно во время их записи |

Стрелки в углублённых guides означают либо прямой вызов, либо передачу данных
(data hand-off). Ромб — это решение, которое может подавить candidate. Блок,
заканчивающийся словами «record diagnostic», всё ещё означает успешный
локальный return, если граф явно не показывает ребро exception.

## 6. Сопоставьте метод с другими представлениями

| Вопрос после чтения метода | Лучшая сопутствующая глава |
|---|---|
| Почему этот слой владеет методом? | [Ментальная модель](01-mental-model.md) |
| Где метод находится в порядке полного run? | [CLI и orchestration](02-cli-and-orchestration.md) |
| Как доказываются Java names и constants? | [Общий Java engine](03-shared-java-engine.md) |
| Каков behavioral contract Spring? | [Spring MVC](04-spring-mvc.md) или [дополнительные Spring surfaces](05-spring-additional-surfaces.md) |
| Каков behavioral contract JAX-RS/WebSocket? | [JAX-RS и Java WebSocket](06-jax-rs.md) |
| Почему evidence исчезает или сохраняется в output? | [Output, evidence и reports](07-output-evidence-reports.md) |
| Можно ли проследить конкретный source example? | [Практические traces](08-worked-traces.md) |
| Какой production risk создаёт этот limit? | [Production use](09-production-use.md) |
| Какие production definitions зависят от метода? | [Карта кода](10-code-map.md) |
| Что означает термин или имя типа? | [Словарь application logic](11-naming-and-code-vocabulary.md) |

## 7. Практический рецепт поиска

Если выбран символ `resolve_spring_alias_terminal()`:

1. его модуль `spring_mvc.py` направляет к руководству по методам Spring в
   таблице выше;
2. поиск точного имени приводит к его method card и call graph composed
   annotations;
3. входящие вызовы показывают, как рёбра `AliasFor` доходят до него;
4. его outputs ведут к `decode_spring_composed_mapping()`, а затем к созданию
   `EndpointFact`; и
5. behavioral chapter объясняет policy, а карта кода указывает production owner
   и downstream consumers.

Применяйте тот же рецепт к private methods, например
`JaxRsHierarchyAnalyzer._resolve_effective_jax_rs_methods()`: найдите точное
qualified name, прочитайте call graph уровня класса, затем проследуйте за
возвращаемым значением к следующей method card. Начальный underscore означает
module-private, но не «неважный».

## 8. Как сохранять это представление согласованным

Когда важный метод добавляется, переименовывается или меняет роль input/output:

1. обновите владеющее руководство методов, используя перечисленные выше поля
   method card;
2. обновите call graph, если изменилось входящее или исходящее runtime-ребро;
3. обновите behavioral chapter только при изменении правила приложения;
4. обновите карту кода, если изменились production ownership или dependencies; и
5. выполните поиск старого точного имени symbol в `p6.logic.ru`.

Так top-down история приложения остаётся стабильной, а method-level слой может
развиваться вместе с деталями реализации.

Продолжите с [16 — Добавление поддержки framework](16-adding-framework-support.md)
или вернитесь к [оглавлению logic guide](README.md).
