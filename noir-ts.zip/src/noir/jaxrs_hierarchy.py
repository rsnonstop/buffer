"""JAX-RS hierarchy binding and recursive subresource expansion.

Framework-neutral Java type parsing, generic adaptation, and hierarchy
selection live in :mod:`noir.java_hierarchy`. This module subclasses that
graph with JAX-RS annotation-family, method-binding, deployment, and locator
semantics.

Logic guide: ``p6.logic/06-jax-rs.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .contracts import (
    JAX_RS_CORE_PACKAGES,
    JAX_RS_HTTP_METHODS,
    JAX_RS_PACKAGES,
)
from .diagnostics import format_endpoint_diagnostic, record as record_diagnostic
from .evidence import (
    deduplicate_endpoint_facts,
    method_annotation_evidence_from_node,
    represented_target_evidence,
)
from .java_frontend import (
    child_by_field,
    parameter_list_source_text,
    resolve_known_annotation,
)
from .java_hierarchy import (
    MAX_HIERARCHY_DEPTH,
    JavaHierarchyContext,
    JavaMethodRecord,
    JavaSourceHierarchyGraph as _NeutralJavaSourceHierarchyGraph,
    JavaTypeRecord,
    JavaTypeReference,
)
from .jaxrs import (
    JaxRsState,
    decode_jax_rs_path_annotation,
    log_jax_rs_skip,
    resolve_custom_designator,
    resolve_jax_rs_method_path,
    resolve_jax_rs_request_designator,
    resolve_jax_rs_resource_prefix,
    resolve_jax_rs_resource_root,
)
from .java_workspace import JavaWorkspace
from .model import EndpointFact
from .paths import join_endpoint_paths


MAX_SUBRESOURCE_DEPTH = 16
MAX_SUBRESOURCE_STATES = 4096
MAX_COMPOSED_PATH = 8192

__all__ = [
    "JaxRsHierarchyAnalyzer",
    "analyze_jax_rs_hierarchy_and_subresources",
]

JAX_RS_METHOD_ANNOTATIONS = {
    "BeanParam",
    "Consumes",
    "CookieParam",
    "DefaultValue",
    "Encoded",
    "FormParam",
    "HeaderParam",
    "MatrixParam",
    "Path",
    "PathParam",
    "Produces",
    "QueryParam",
    "Context",
    "Suspended",
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
}


@dataclass(frozen=True)
class SubresourceTypeState:
    """Cycle identity for one concrete subresource application type.

    Attributes:
        record_fqn: Unique Java identity of the resource being expanded.
        env_key: Stable generic substitutions active for that resource use.

    Example construction:
        ``SubresourceTypeState("app.ItemResource",
        (("T", JavaTypeReference("decl", "app.Item")),))`` identifies an
        ``ItemResource<T>`` traversal where ``T`` is the application ``Item``.
    """

    record_fqn: str
    env_key: tuple[tuple[str, JavaTypeReference], ...]


@dataclass
class JaxRsEffectiveMethod:
    """A runnable handler paired with the selected JAX-RS route contract.

    Attributes:
        implementation: Concrete method that handles the incoming request.
        implementation_env: Generic substitutions at that concrete handler.
        annotation_source: Declaration that supplies the atomic JAX-RS metadata.
        binding: Decoded leaf/locator path, HTTP method, and annotation evidence.
        hierarchy_added: Whether inheritance supplied implementation or metadata.
        signature: Adapted erased signature used to pair declarations, or
            ``None`` when a direct method remains usable without that proof.

    Example construction:
        ``JaxRsEffectiveMethod(implementation=controller_list,
        implementation_env={"T": item_ref}, annotation_source=api_list,
        binding={"kind": "leaf", "path": "/items", "method": "GET",
        "evidence_node": get_node, "annotation_identity": "jakarta.ws.rs.GET",
        "annotation_family": "jax-rs"}, hierarchy_added=True,
        signature=("list", ("java.lang.String",)))`` means the concrete
        ``controller_list`` handler implements the inherited ``GET /items``
        contract declared by ``api_list``.
    """

    implementation: JavaMethodRecord
    implementation_env: dict[str, JavaTypeReference]
    annotation_source: JavaMethodRecord
    binding: dict[str, Any]
    hierarchy_added: bool
    signature: tuple[str, tuple[str, ...]] | None


def _deduplicate(
    endpoints: Iterable[EndpointFact],
) -> tuple[EndpointFact, ...]:
    """Merge duplicate route facts while retaining all supporting evidence.

    Example call:
        ``_deduplicate([get_items_from_interface, get_items_from_locator])``
        returns one endpoint when both facts identify the same ``GET /items``
        handler, with their annotation/target evidence combined.
    """

    return deduplicate_endpoint_facts(
        endpoints,
        lambda endpoint: (
            endpoint.method,
            endpoint.path,
            endpoint.source_file,
            endpoint.handler_name,
            endpoint.parameters,
        ),
    )


class JaxRsHierarchyAnalyzer(_NeutralJavaSourceHierarchyGraph):
    """Add JAX-RS route inheritance and subresources to the Java graph.

    Attributes:
        workspace: Shared parsed Java files and cross-file indexes (inherited).
        state: JAX-RS designators, applications, and prepared deployment facts.
        types: Traversable source resource types keyed by Java identity (inherited).
        _signature_cache: Adapted Java method signatures (inherited).
        _effective_cache: Previously selected JAX-RS handlers keyed by resource,
            generic environment, and Javax/Jakarta namespace.

    Example construction:
        ``analyzer = JaxRsHierarchyAnalyzer(workspace, state=jaxrs_state)`` may expose
        ``analyzer.types["app.ItemsResource"]`` and cache its effective
        ``GET /items`` method under the ``jakarta.ws.rs`` family.
    """

    def __init__(self, workspace: JavaWorkspace, *, state: JaxRsState):
        """Build the Java graph and initialize JAX-RS method-selection state.

        Example call:
            ``JaxRsHierarchyAnalyzer(workspace, state=jaxrs_state)`` prepares the parsed
            ``ItemsResource`` hierarchy for route and locator expansion; no
            endpoint fact is emitted until ``analyze_jax_rs_routes()``.
        """

        super().__init__(workspace)
        self.state = state
        self._effective_cache: dict[
            tuple[Any, ...], list[JaxRsEffectiveMethod]
        ] = {}

    def _log_jax_rs_skip(
        self,
        method_or_type: Any,
        message: str,
        expression: str | None = None,
    ) -> None:
        """Record why one resource type or handler could not prove a route.

        Example call:
            ``analyzer._log_jax_rs_skip(list_method,
            "mixed Javax/Jakarta effective annotation bundle", "@GET")`` logs
            that reason against ``ItemsResource.list`` and its source file.
        """

        if isinstance(method_or_type, JavaMethodRecord):
            unit = method_or_type.owner.unit
            owner = (
                f"{method_or_type.owner.type_info['display_name']}."
                f"{method_or_type.name}"
            )
        else:
            unit = method_or_type.unit
            owner = method_or_type.type_info["display_name"]
        log_jax_rs_skip(unit["source_path"], owner, message, expression)

    @staticmethod
    def _is_ancestor_annotation_method(method: JavaMethodRecord) -> bool:
        """Identify an ancestor declaration allowed to supply handler metadata.

        Example call:
            ``JaxRsHierarchyAnalyzer._is_ancestor_annotation_method(api_get)``
            returns ``True`` for an interface method carrying ``@GET`` and
            ``False`` for a private superclass helper.
        """

        if "static" in method.modifiers or "private" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return True
        return "public" in method.modifiers or "protected" in method.modifiers

    def _is_genuine_override(self, method: JavaMethodRecord, annotation: dict[str, Any]) -> bool:
        """Recognize only exact ``java.lang.Override`` as non-route metadata.

        Example call:
            ``analyzer._is_genuine_override(list_method,
            {"name_node": <node for ``Override``>})`` returns ``True`` when
            Java resolution proves ``java.lang.Override``; a user annotation
            also named ``Override`` returns ``False``.
        """

        return resolve_known_annotation(
            method.owner.unit,
            annotation["name_node"],
            {"Override"},
            ("java.lang",),
        ) is not None

    def _has_atomic_annotation_bundle(self, method: JavaMethodRecord) -> bool:
        """Report whether a declaration supplies its own handler metadata.

        Example call:
            ``analyzer._has_atomic_annotation_bundle(api_list)`` returns ``True``
            when ``api_list`` declares ``@GET`` or an annotated parameter, and
            ``False`` when its only annotation is genuine ``@Override``.
        """

        # A declaration's direct annotation bundle is atomic for JAX-RS hierarchy
        # selection. Genuine @Override is the sole ignored marker.
        if any(not self._is_genuine_override(method, annotation) for annotation in method.annotations):
            return True
        return bool(method.parameter_annotations)

    def _select_jax_rs_annotation_source(
        self,
        implementation: JavaMethodRecord,
        implementation_env: dict[str, JavaTypeReference],
        signature: tuple[str, tuple[str, ...]],
        hierarchy: JavaHierarchyContext,
        implementation_class_index: int | None,
    ) -> JavaMethodRecord | None:
        """Select one unambiguous JAX-RS metadata source for a handler.

        Example call:
            ``analyzer._select_jax_rs_annotation_source(controller_list, {},
            ("list", ("java.lang.String",)), hierarchy, 0)`` returns the
            closest single declaration such as ``ItemsApi.list`` that supplies
            the complete route annotation bundle, or ``None`` if branches clash.
        """

        if self._has_atomic_annotation_bundle(implementation):
            return implementation

        start = (implementation_class_index + 1) if implementation_class_index is not None else 0
        for record, env in hierarchy.class_states[start:]:
            matches = [
                method
                for method in self._methods_for_signature(record, env, signature)
                if self._is_ancestor_annotation_method(method)
            ]
            if len(matches) > 1:
                return None
            if matches and self._has_atomic_annotation_bundle(matches[0]):
                return matches[0]

        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            # An unannotated interface redeclaration does not suppress the
            # atomic JAX-RS annotation bundle on its parent declaration.
            found, invalid = self._interface_branches(
                interface_root, signature,
                accept_method=self._has_atomic_annotation_bundle,
                stop_at_declaration=False,
                memo=memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self._select_maximally_specific_candidates(candidates)
        blocked = blocked or specificity_invalid
        # A single source declaration reached through a diamond is one origin.
        source_ids = {candidate[0] for candidate in candidates}
        if blocked or len(source_ids) != 1:
            return None
        return self._resolve_method_candidate(next(iter(candidates)))[0]

    def _classify_jax_rs_annotation(self, method: JavaMethodRecord, annotation: dict[str, Any]) -> str:
        """Classify one method annotation by its JAX-RS application role.

        Example call:
            ``analyzer._classify_jax_rs_annotation(list_method,
            {"name_node": <node for ``GET``>, ...})`` returns ``"GET"`` when
            name resolution proves the standard JAX-RS annotation; a proven
            meta-annotated request designator returns ``"custom"``.
        """

        unit = method.owner.unit
        for package_group in (
            JAX_RS_PACKAGES,
            JAX_RS_CORE_PACKAGES,
            ("jakarta.ws.rs.container", "javax.ws.rs.container"),
        ):
            resolved = resolve_known_annotation(
                unit,
                annotation["name_node"],
                JAX_RS_METHOD_ANNOTATIONS,
                package_group,
            )
            if resolved is not None:
                return resolved["name"]
        custom = resolve_custom_designator(
            unit,
            annotation["name_node"],
            self.workspace,
            f"{method.owner.type_info['display_name']}.{method.name}",
            state=self.state,
        )
        return "custom" if custom["status"] != "none" else "other"

    def _standard_jax_annotation_family(
        self, method: JavaMethodRecord, annotation: dict[str, Any]
    ) -> str | None:
        """Resolve which standard JAX-RS namespace owns an annotation.

        Example call:
            ``analyzer._standard_jax_annotation_family(list_method,
            {"name_node": <node for ``GET``>, ...})`` returns
            ``"jakarta.ws.rs"`` for ``jakarta.ws.rs.GET``, ``"javax.ws.rs"``
            for the legacy identity, and ``None`` for an unrelated ``GET``.
        """

        unit = method.owner.unit
        package_groups = (
            JAX_RS_PACKAGES,
            JAX_RS_CORE_PACKAGES,
            ("jakarta.ws.rs.container", "javax.ws.rs.container"),
        )
        for packages in package_groups:
            resolved = resolve_known_annotation(
                unit,
                annotation["name_node"],
                JAX_RS_METHOD_ANNOTATIONS,
                packages,
            )
            if resolved is not None:
                return (
                    "jakarta.ws.rs"
                    if resolved["namespace"].startswith("jakarta.ws.rs")
                    else "javax.ws.rs"
                )
        return None

    def _decode_jax_rs_method_binding(
        self, method: JavaMethodRecord, namespace: str
    ) -> dict[str, Any] | None:
        """Decode one annotation bundle as a request leaf or subresource locator.

        Example call:
            ``analyzer._decode_jax_rs_method_binding(api_list,
            "jakarta.ws.rs")`` returns a value such as
            ``{"kind": "leaf", "path": "/items", "method": "GET", ...}``;
            a path-only method may return ``{"kind": "locator", ...}``, while
            mixed namespaces or uncertain values return ``None``.
        """

        owner_name = f"{method.owner.type_info['display_name']}.{method.name}"
        for annotation in method.annotations + method.parameter_annotations:
            family = self._standard_jax_annotation_family(method, annotation)
            if family is not None and family != namespace:
                self._log_jax_rs_skip(method, "mixed Javax/Jakarta effective annotation bundle")
                return None
        annotation_kinds = [self._classify_jax_rs_annotation(method, annotation) for annotation in method.annotations]
        designator_evidence = any(
            kind in set(JAX_RS_HTTP_METHODS) | {"custom"}
            for kind in annotation_kinds
        )
        path_evidence = "Path" in annotation_kinds
        designator = resolve_jax_rs_request_designator(
            method.owner.unit,
            list(method.annotations),
            self.workspace,
            namespace,
            owner_name,
            state=self.state,
        )
        if designator_evidence and designator is None:
            return None
        method_path = resolve_jax_rs_method_path(
            method.owner.unit,
            list(method.annotations),
            namespace,
            method.owner.type_info["display_name"],
            owner_name,
            self.workspace,
        )
        if method_path is None:
            return None
        if designator is not None:
            return {
                "kind": "leaf",
                "path": method_path,
                "method": designator["method"],
                "evidence_node": designator["node"],
                "annotation_identity": designator["annotation_identity"],
                "annotation_family": designator["annotation_family"],
            }
        if path_evidence and method_path:
            path_node = next(
                (
                    annotation["node"]
                    for annotation, kind in zip(method.annotations, annotation_kinds)
                    if kind == "Path"
                ),
                method.node,
            )
            return {"kind": "locator", "path": method_path, "evidence_node": path_node}
        return None

    def _resolve_interface_contract_path(
        self, effective: JaxRsEffectiveMethod, namespace: str
    ) -> str | None:
        """Return the selected interface contract's direct ``@Path`` layer.

        Noir composes an implemented interface's type path with the concrete
        root and method path.  Superclass type paths remain intentionally
        excluded.  Keep the stronger source identity and namespace checks of
        this analyzer while preserving that valid interface route layer.

        Example call:
            ``analyzer._resolve_interface_contract_path(effective_list,
            "jakarta.ws.rs")`` returns ``"/items"`` when ``ItemsApi`` supplies
            that direct type-level path, ``""`` when no interface layer applies,
            or ``None`` when competing or mixed path evidence is unsafe.
        """

        source_owner = effective.annotation_source.owner
        if (
            not effective.hierarchy_added
            or source_owner.kind != "interface_declaration"
        ):
            return ""
        unit = source_owner.unit
        modifiers = next(
            (
                child
                for child in source_owner.type_info["node"].named_children
                if child.type == "modifiers"
            ),
            None,
        )
        records = []
        if modifiers is not None:
            for annotation in modifiers.named_children:
                if annotation.type not in {"annotation", "marker_annotation"}:
                    continue
                name_node = child_by_field(annotation, "name")
                if name_node is not None:
                    records.append({"node": annotation, "name_node": name_node})
        candidates = []
        for record in records:
            resolved = resolve_known_annotation(
                unit,
                record["name_node"],
                {"Path"},
                JAX_RS_PACKAGES,
            )
            if resolved is not None:
                candidates.append((record, resolved))
        if not candidates:
            return ""
        if len(candidates) != 1 or candidates[0][1]["namespace"] != namespace:
            self._log_jax_rs_skip(
                effective.annotation_source,
                "ambiguous or mixed interface type @Path",
            )
            return None
        owner_name = source_owner.type_info["display_name"]
        return decode_jax_rs_path_annotation(
            unit,
            candidates[0][0],
            owner_name,
            owner_name,
            "interface type @Path value",
            self.workspace,
        )

    def _resolve_effective_jax_rs_methods(
        self, resource: JavaTypeRecord, env: dict[str, JavaTypeReference], namespace: str
    ) -> list[JaxRsEffectiveMethod]:
        """Bind runnable resource methods to direct or inherited route metadata.

        Example call:
            ``analyzer._resolve_effective_jax_rs_methods(items_resource, {},
            "jakarta.ws.rs")`` returns selections such as concrete
            ``ItemsResource.list`` paired with ``ItemsApi.list``'s ``@GET`` and
            ``@Path`` bundle; ambiguous override branches are omitted.
        """

        cache_key = (resource.fqn, self._type_environment_key(env), namespace)
        if cache_key in self._effective_cache:
            return self._effective_cache[cache_key]

        hierarchy = self._build_hierarchy_context(resource, env)
        effective: list[JaxRsEffectiveMethod] = []
        handled_direct_ids: set[tuple[Any, ...]] = set()
        direct_signature_counts: dict[tuple[str, tuple[str, ...]], int] = {}
        for method in resource.methods:
            signature = self._erased_method_signature(method, env)
            if signature is not None:
                direct_signature_counts[signature] = direct_signature_counts.get(signature, 0) + 1

        # Direct methods remain usable even when an unrelated hierarchy edge
        # cannot be resolved.  Only inherited binding requires a complete graph.
        for method in resource.methods:
            if not self._is_public_implementation(method):
                continue
            signature = self._erased_method_signature(method, env)
            if signature is not None and direct_signature_counts[signature] != 1:
                self._log_jax_rs_skip(method, "duplicate erased method signature")
                continue
            source = method
            if not self._has_atomic_annotation_bundle(method):
                if not hierarchy.complete or signature is None:
                    continue
                source = self._select_jax_rs_annotation_source(method, env, signature, hierarchy, 0)
                if source is None:
                    continue
            binding = self._decode_jax_rs_method_binding(source, namespace)
            if binding is None:
                continue
            effective.append(
                JaxRsEffectiveMethod(
                    implementation=method,
                    implementation_env=env,
                    annotation_source=source,
                    binding=binding,
                    hierarchy_added=source.id != method.id,
                    signature=signature,
                )
            )
            handled_direct_ids.add(method.id)

        if not hierarchy.complete:
            self._effective_cache[cache_key] = effective
            return effective

        signatures: set[tuple[str, tuple[str, ...]]] = set()
        unresolved_names = {method.name for method in resource.methods if self._erased_method_signature(method, env) is None}
        for record, state_env in hierarchy.class_states:
            signatures.update(
                signature
                for method in record.methods
                if (signature := self._erased_method_signature(method, state_env)) is not None
            )

        def collect_interface_signatures(
            state: tuple[JavaTypeRecord, dict[str, JavaTypeReference]],
            depth: int = 0,
            active: frozenset[str] = frozenset(),
        ) -> None:
            """Add inherited interface method shapes to the binding work set.

            Example call:
                ``collect_interface_signatures((items_api, {}))`` adds signatures
                such as ``("list", ("java.lang.String",))`` from ``ItemsApi``
                and its safely reachable parent interfaces.
            """

            record, state_env = state
            if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
                return
            signatures.update(
                signature
                for method in record.methods
                if (signature := self._erased_method_signature(method, state_env)) is not None
            )
            for edge in record.interfaces:
                following = self._resolve_inheritance_edge(edge, state_env)
                if following is not None:
                    collect_interface_signatures(
                        following, depth + 1, active | {record.fqn}
                    )

        for interface_root in hierarchy.interface_roots:
            collect_interface_signatures(interface_root)

        for signature in sorted(signatures):
            if signature[0] in unresolved_names:
                continue
            implementation: JavaMethodRecord | None = None
            implementation_env: dict[str, JavaTypeReference] | None = None
            implementation_index: int | None = None
            malformed = False
            for index, (record, state_env) in enumerate(hierarchy.class_states):
                matches = self._methods_for_signature(record, state_env, signature)
                if not matches:
                    continue
                if len(matches) != 1 or not self._is_public_implementation(matches[0]):
                    malformed = True
                    break
                implementation = matches[0]
                implementation_env = state_env
                implementation_index = index
                break
            if malformed:
                continue
            if implementation is None:
                candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]] = set()
                blocked = False
                memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
                for interface_root in hierarchy.interface_roots:
                    found, invalid = self._interface_branches(
                        interface_root, signature,
                        accept_method=self._is_public_implementation,
                        stop_at_declaration=True,
                        memo=memo,
                    )
                    candidates.update(found)
                    blocked = blocked or invalid
                candidates, specificity_invalid = self._select_maximally_specific_candidates(
                    candidates
                )
                blocked = blocked or specificity_invalid
                if blocked or len({candidate[0] for candidate in candidates}) != 1:
                    continue
                resolved = self._resolve_method_candidate(next(iter(candidates)))
                if resolved is None:
                    continue
                implementation, implementation_env = resolved
            if implementation.id in handled_direct_ids:
                continue
            source = self._select_jax_rs_annotation_source(
                implementation,
                implementation_env,
                signature,
                hierarchy,
                implementation_index,
            )
            if source is None:
                continue
            binding = self._decode_jax_rs_method_binding(source, namespace)
            if binding is None:
                continue
            effective.append(
                JaxRsEffectiveMethod(
                    implementation=implementation,
                    implementation_env=implementation_env,
                    annotation_source=source,
                    binding=binding,
                    hierarchy_added=True,
                    signature=signature,
                )
            )

        effective.sort(
            key=lambda item: (
                item.implementation.owner.fqn,
                item.implementation.name,
                item.signature or (item.implementation.name, ()),
                item.implementation.node.start_byte,
            )
        )
        self._effective_cache[cache_key] = effective
        return effective

    # ------------------------------------------------------------------
    # Recursive subresource collection

    def _resolve_subresource_target(
        self, effective: JaxRsEffectiveMethod
    ) -> tuple[JavaTypeRecord, dict[str, JavaTypeReference]] | None:
        """Resolve a locator's result to one concrete subresource type state.

        Example call:
            ``analyzer._resolve_subresource_target(item_locator)`` returns
            ``(item_resource, {"T": item_ref})`` when the locator returns the
            unique concrete ``ItemResource<Item>`` source type; abstract,
            ambiguous, or external-only result types yield ``None``.
        """

        method = effective.implementation
        env = self._method_env(method, effective.implementation_env)
        returned = self._substitute_type_ref(method.return_ref, env)
        if returned is None or returned.kind != "decl" or returned.dimensions:
            return None
        if returned.name == "java.lang.Class":
            if len(returned.args) != 1:
                return None
            returned = returned.args[0]
            if returned.kind != "decl" or returned.dimensions:
                return None
        target = self.types.get(returned.name)
        if (
            target is None
            or target.kind not in {"class_declaration", "record_declaration"}
            or target.type_info["abstract"]
        ):
            return None
        if returned.args:
            if len(returned.args) != len(target.type_parameters):
                return None
            target_env = dict(zip(target.type_parameters, returned.args))
        else:
            target_env = self._default_type_environment(target)
        return target, target_env

    def _build_recalled_endpoint(
        self, effective: JaxRsEffectiveMethod, endpoint_path: str
    ) -> EndpointFact:
        """Create a route fact attributed to the concrete recalled handler.

        Example call:
            ``analyzer._build_recalled_endpoint(effective_list, "/api/items")``
            returns an ``EndpointFact`` for inbound ``GET /api/items`` whose
            handler is the concrete implementation, even when an interface
            supplied the route annotations.
        """

        method = effective.implementation
        owner_name = f"{method.owner.type_info['display_name']}.{method.name}"
        annotation_evidence = ()
        if effective.annotation_source.id == effective.implementation.id:
            # Annotation-line evidence cannot be claimed for a distinct
            # inherited declaration; represented-target evidence still names
            # the concrete handler implementation in either case.
            annotation_evidence = method_annotation_evidence_from_node(
                effective.binding["evidence_node"],
                effective.binding["annotation_identity"],
                effective.binding["annotation_family"],
                annotation_source_file=effective.annotation_source.owner.unit[
                    "source_path"
                ],
                endpoint_source_file=method.owner.unit["source_path"],
            )
        return EndpointFact(
            path=endpoint_path,
            method=effective.binding["method"],
            parameters=parameter_list_source_text(
                method.owner.unit["source"], method.parameters_node
            ),
            source_file=method.owner.unit["source_path"],
            source_line=method.node.start_point.row + 1,
            handler_name=owner_name,
            technology="jax-rs",
            protocol="http",
            surface="server",
            direction="inbound",
            annotation_evidence=annotation_evidence,
            represented_targets=represented_target_evidence(
                method.owner.unit["source_path"], "method", method.node
            ),
        )

    def _collect_subresource_endpoints(
        self,
        resource: JavaTypeRecord,
        env: dict[str, JavaTypeReference],
        namespace: str,
        base_uri: str,
        via_locator: bool,
        depth: int,
        active_types: frozenset[SubresourceTypeState],
        active_edges: frozenset[tuple[Any, ...]],
        budget: dict[str, int],
    ) -> list[EndpointFact]:
        """Traverse one bounded subresource branch and emit its route leaves.

        Example call:
            ``analyzer._collect_subresource_endpoints(items_resource, {},
            "jakarta.ws.rs", "/api", False, 0, frozenset(), frozenset(),
            {"states": 0})`` follows locators such as ``/items/{id}`` and returns
            concrete leaf facts, while the active sets and budget stop cycles.
        """

        state = SubresourceTypeState(resource.fqn, self._type_environment_key(env))
        if state in active_types or depth > MAX_SUBRESOURCE_DEPTH:
            self._log_jax_rs_skip(resource, "cyclic or over-depth subresource traversal")
            return []
        if budget["states"] >= MAX_SUBRESOURCE_STATES:
            self._log_jax_rs_skip(resource, "over-state-limit subresource traversal")
            return []
        budget["states"] += 1
        branch_types = active_types | {state}
        endpoints: list[EndpointFact] = []
        for effective in self._resolve_effective_jax_rs_methods(resource, env, namespace):
            interface_path = self._resolve_interface_contract_path(effective, namespace)
            if interface_path is None:
                continue
            composed = join_endpoint_paths(
                join_endpoint_paths(base_uri, interface_path),
                effective.binding["path"],
            )
            if len(composed) > MAX_COMPOSED_PATH:
                self._log_jax_rs_skip(effective.implementation, "over-length subresource path")
                continue
            if effective.binding["kind"] == "leaf":
                if via_locator or effective.hierarchy_added:
                    endpoint = self._build_recalled_endpoint(effective, composed)
                    endpoints.append(endpoint)
                    record_diagnostic(format_endpoint_diagnostic(endpoint))
                continue

            target_state = self._resolve_subresource_target(effective)
            if target_state is None:
                self._log_jax_rs_skip(effective.implementation, "unresolved subresource locator return type")
                continue
            target, target_env = target_state
            edge_key = (
                effective.implementation.id,
                effective.signature,
                target.fqn,
                self._type_environment_key(target_env),
            )
            if edge_key in active_edges:
                self._log_jax_rs_skip(effective.implementation, "cyclic subresource locator edge")
                continue
            endpoints.extend(
                self._collect_subresource_endpoints(
                    target,
                    target_env,
                    namespace,
                    composed,
                    True,
                    depth + 1,
                    branch_types,
                    active_edges | {edge_key},
                    budget,
                )
            )
        return endpoints

    def analyze_jax_rs_routes(self) -> tuple[EndpointFact, ...]:
        """Expand inherited bindings and locators from every proven resource root.

        Example call:
            ``analyzer.analyze_jax_rs_routes()`` may return the concrete
            ``GET /api/items/{id}`` fact reached through an ``ItemsResource``
            root and an ``ItemResource`` locator, with duplicates merged.
        """

        endpoints: list[EndpointFact] = []
        for fqn in sorted(self.types):
            record = self.types[fqn]
            if (
                record.kind not in {"class_declaration", "record_declaration"}
                or record.type_info["abstract"]
                or not record.type_info["workspace_visible"]
            ):
                continue
            root_resource = resolve_jax_rs_resource_root(
                record.unit, record.type_info, self.workspace
            )
            if root_resource is None:
                continue
            deployment_prefix = resolve_jax_rs_resource_prefix(
                record.unit,
                root_resource["namespace"],
                record.type_info["display_name"],
                state=self.state,
            )
            if deployment_prefix is None:
                continue
            composed_base_path = join_endpoint_paths(
                deployment_prefix, root_resource["path"]
            )
            if len(composed_base_path) > MAX_COMPOSED_PATH:
                self._log_jax_rs_skip(record, "over-length resource root path")
                continue
            endpoints.extend(
                self._collect_subresource_endpoints(
                    record,
                    self._default_type_environment(record),
                    root_resource["namespace"],
                    composed_base_path,
                    False,
                    0,
                    frozenset(),
                    frozenset(),
                    {"states": 0},
                )
            )
        # The shared evidence merger remains authoritative; remove exact
        # internal duplicates here so standalone callers are deterministic.
        return _deduplicate(endpoints)


def analyze_jax_rs_hierarchy_and_subresources(
    workspace: JavaWorkspace,
    *,
    state: JaxRsState,
) -> tuple[EndpointFact, ...]:
    """Return only hierarchy/subresource endpoint additions for ``workspace``.

    Call this once after shared Java workspace construction and append its rows
    to the ordinary direct JAX-RS endpoint list before formatting/deduplication.

    Example call:
        ``analyze_jax_rs_hierarchy_and_subresources(workspace,
        state=jaxrs_state)`` returns only
        additive facts such as an inherited ``GET /api/items`` handler or a
        leaf reached through a subresource locator.
    """

    return JaxRsHierarchyAnalyzer(workspace, state=state).analyze_jax_rs_routes()
