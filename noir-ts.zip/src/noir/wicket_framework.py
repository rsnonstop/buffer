"""Minimal executable Apache Wicket framework-integration example.

Any explicit selection containing ``--framework wicket`` runs these hooks
through the same registry lifecycle as a real family.  They intentionally
provide no Wicket endpoint semantics yet: the stub creates no annotation
classifications, workspace state, diagnostics, or endpoint facts from the
existing raw-text marker.

Logic guides: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/16-adding-framework-support.md``.
"""

from __future__ import annotations

from .java_workspace import JavaWorkspace
from .model import AnalysisRequest, EndpointFact


def analyze_wicket_framework(
    _request: AnalysisRequest,
    _source_paths: tuple[str, ...],
    _workspace: JavaWorkspace,
    _state: None,
) -> tuple[EndpointFact, ...]:
    """Return no facts rather than treating marker text as endpoint proof.

    Any explicit set containing Wicket invokes this function, while the
    advisory Wicket marker does not auto-select it. The registry leaves state,
    preparation, and recognition hooks absent until Wicket needs them; there is
    no empty family state to attach to the Java workspace.  A future implementation
    may consume the shared source paths and workspace only after Wicket
    endpoint evidence and failure rules are specified.

    Example call:
        ``analyze_wicket_framework(request, source_paths, workspace, None)`` returns
        ``()`` without mutating input state or recording diagnostics.
    """

    return ()


__all__ = [
    "analyze_wicket_framework",
]
