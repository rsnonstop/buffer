"""Deterministic source discovery and framework-marker detection.

This module is deliberately parser-free.  It is the first application edge:
find candidate files, read the marker inputs supplied by the caller, and
return a stable detection value.  Choosing analyzers from that value belongs
to :mod:`noir.pipeline`.

Logic guide: ``p6.logic/02-cli-and-orchestration.md`` (source snapshot and
framework selection).
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from types import MappingProxyType
from typing import Mapping

from .contracts import IGNORED_SOURCE_DIRECTORIES


CODEGEN_REPORT_HINT = (
    "Необходимо запросить у команды папку generated-source, "
    "получаемую после сборки, и запустить для нее noir_sbt"
)


def detect_wicket_marker(_source_path: str, source_text: str) -> bool:
    """Recognize the raw-text Wicket marker for announcement only.

    Wicket has an explicitly selectable executable stub, but marker evidence
    remains advisory and never selects that adapter in ``auto`` mode.

    Example call:
        ``detect_wicket_marker("/workspace/app/Page.java",
        "import org.apache.wicket.Page;")`` returns ``True``; ordinary Java
        source without that package spelling returns ``False``.
    """

    return re.search(r"org\.apache\.wicket", source_text) is not None


def detect_jax_rs_marker(_source_path: str, source_text: str) -> bool:
    """Recognize either JAX-RS namespace for automatic analyzer selection.

    Example call:
        ``detect_jax_rs_marker("/workspace/app/Items.java",
        "import jakarta.ws.rs.GET;")`` returns ``True``; the legacy
        ``javax.ws.rs`` package also matches.
    """

    return bool(re.search(r"(?:jakarta|javax)\.ws\.rs", source_text))


def detect_spring_functional_route_marker(
    _source_path: str, source_text: str
) -> bool:
    """Recognize the raw Spring functional-router package marker.

    This supports marker detection only; semantic route proof still happens
    later against the parsed shared workspace.

    Example call:
        ``detect_spring_functional_route_marker("/workspace/app/Routes.java",
        "import org.springframework.web.reactive.function.server.RouterFunction;")``
        returns ``True`` and leaves actual route proof to the analyzer.
    """

    return (
        re.search(
            r"org\.springframework\.web\.reactive\.function\.server",
            source_text,
        )
        is not None
    )


def detect_spring_codegen_marker(_source_path: str, source_text: str) -> bool:
    """Recognize a Maven code-generator marker requiring manual follow-up.

    Example call:
        ``detect_spring_codegen_marker("/workspace/app/pom.xml",
        "<groupId>openapi.codegen</groupId>")`` returns
        ``True`` because the descriptor contains the configured codegen marker.
    """

    return bool(re.search(r"(?:openapi|io\.swagger)\.codegen", source_text))


def detect_spring_marker(_source_path: str, source_text: str) -> bool:
    """Recognize raw source evidence that selects Spring automatically.

    Example call:
        ``detect_spring_marker("/workspace/app/ItemsController.java",
        "import org.springframework.web.bind.annotation.GetMapping;")`` returns
        ``True``; unrelated uses of a class merely named ``GetMapping`` do not.
    """

    return (
        re.search(r"org\.springframework\.web\.bind\.annotation\.", source_text)
        is not None
        or detect_spring_functional_route_marker(_source_path, source_text)
    )


# Registry order controls deterministic findings and announcement order.  The
# detectors intentionally scan raw, case-sensitive text (including comments
# and literals); this is convenience selection evidence, not semantic proof.
FRAMEWORK_MARKER_RULES = (
    MappingProxyType(
        {
            "finding_name": "SpringBoot Annotation",
            "selection_mode": "auto",
            "input_kind": "java",
            "marker_detector": detect_spring_marker,
            "report_hint": "",
            "auto_selected_framework": "spring",
        }
    ),
    MappingProxyType(
        {
            "finding_name": "SpringBoot Route",
            "selection_mode": "manual",
            "input_kind": "java",
            "marker_detector": detect_spring_functional_route_marker,
            "report_hint": "",
            "auto_selected_framework": None,
        }
    ),
    MappingProxyType(
        {
            "finding_name": "SpringBoot Codegen",
            "selection_mode": "manual",
            "input_kind": "pom",
            "marker_detector": detect_spring_codegen_marker,
            "report_hint": CODEGEN_REPORT_HINT,
            "auto_selected_framework": None,
        }
    ),
    MappingProxyType(
        {
            "finding_name": "Apache Wicket",
            "selection_mode": "manual",
            "input_kind": "java",
            "marker_detector": detect_wicket_marker,
            "report_hint": "",
            "auto_selected_framework": None,
        }
    ),
    MappingProxyType(
        {
            "finding_name": "JaxRS",
            "selection_mode": "auto",
            "input_kind": "java",
            "marker_detector": detect_jax_rs_marker,
            "report_hint": "",
            "auto_selected_framework": "jaxrx",
        }
    ),
)


def _relative_name(path: str | os.PathLike[str], root: str | os.PathLike[str]) -> str:
    """Return a stable project-relative display key for discovery evidence.

    Example call:
        ``_relative_name("/workspace/shop/src/Items.java",
        "/workspace/shop")`` returns ``"src/Items.java"``.
    """

    return Path(os.path.relpath(path, start=root)).as_posix()


def is_ignored_source_file(
    file_path: str | os.PathLike[str],
    analysis_root: str | os.PathLike[str],
) -> bool:
    """Whether a file lies below a pruned directory component.

    The filename itself is not compared with the ignore registry; only parent
    directory components define exclusion.

    Example call:
        ``is_ignored_source_file("/workspace/shop/target/Generated.java",
        "/workspace/shop")`` returns ``True`` when ``target`` is a configured
        ignored directory; ``src/Target.java`` remains eligible.
    """

    relative = Path(os.path.relpath(file_path, start=analysis_root))
    return any(
        part in IGNORED_SOURCE_DIRECTORIES for part in relative.parts[:-1]
    )


def _discover_named_files(
    analysis_root: str | os.PathLike[str],
    predicate,
) -> list[str]:
    """Walk one tree with pruning and return paths in relative-name order.

    Both directory mutation and final sorting are deliberate: pruning avoids
    reading ignored trees, while relative sorting makes results independent of
    filesystem enumeration order. A directory read error aborts discovery just
    like an unreadable Java file aborts snapshotting; a partial tree must not
    look like a complete analysis with fewer endpoints.

    Example call:
        ``_discover_named_files("/workspace/shop",
        lambda name: name.lower().endswith(".java"))`` returns eligible Java
        file paths ordered by project-relative POSIX spelling.
    """

    def fail_on_unreadable_directory(error: OSError) -> None:
        """Abort instead of letting os.walk silently omit an unreadable tree.

        Example call:
            ``fail_on_unreadable_directory(PermissionError("app/private"))``
            propagates the directory error to the caller of discovery.
        """

        raise error

    discovered: list[str] = []
    for current_root, directory_names, file_names in os.walk(
        analysis_root, onerror=fail_on_unreadable_directory
    ):
        directory_names[:] = sorted(
            name
            for name in directory_names
            if name not in IGNORED_SOURCE_DIRECTORIES
        )
        discovered.extend(
            os.path.join(current_root, name)
            for name in sorted(file_names)
            if predicate(name)
        )
    return sorted(discovered, key=lambda path: _relative_name(path, analysis_root))


def discover_java_files(analysis_root: str | os.PathLike[str]) -> list[str]:
    """Return Java paths awaiting snapshotting in stable project-relative order.

    The suffix check is case-insensitive. Parsing and Java
    validity are intentionally deferred to the shared frontend.

    Example call:
        ``discover_java_files("/workspace/shop")`` may return
        ``["/workspace/shop/src/Items.java", "/workspace/shop/src/Routes.java"]``
        in project-relative order, excluding ignored build directories.
    """

    return _discover_named_files(
        analysis_root,
        lambda name: name.lower().endswith(".java"),
    )


def discover_pom_files(analysis_root: str | os.PathLike[str]) -> list[str]:
    """Return exact Maven descriptor paths used by marker scanning.

    Example call:
        ``discover_pom_files("/workspace/shop")`` returns paths such as
        ``["/workspace/shop/pom.xml"]`` and excludes ``pom.xml`` files below
        pruned build directories.
    """

    return _discover_named_files(analysis_root, lambda name: name == "pom.xml")


def scan_framework_markers(
    analysis_root: str | os.PathLike[str],
    source_bytes_by_path: Mapping[str, bytes | str],
) -> dict[str, object]:
    """Collect deterministic raw-text findings for pipeline ``auto`` mode.

    Java content comes from the immutable source snapshot, so it is not read a
    second time.  Maven descriptors are separate marker-only inputs.  The
    return value keeps three views distinct: every occurrence for diagnostics,
    registry-ordered distinct findings for announcements, and the set of
    analyzer families that auto-capable rules select.

    Example call:
        ``scan_framework_markers("/workspace/shop",
        {"/workspace/shop/src/Items.java":
        b"import jakarta.ws.rs.GET;"})`` returns a ``JaxRS`` occurrence/finding
        and ``frozenset({"jaxrx"})`` in ``selected_frameworks``.
    """

    # Relative path is the sort/display key; absolute name is retained only for
    # the detector signature.
    candidates = [
        (
            _relative_name(file_name, analysis_root),
            "java",
            str(file_name),
            source.decode("utf8") if isinstance(source, bytes) else str(source),
        )
        for file_name, source in source_bytes_by_path.items()
    ]
    for file_name in discover_pom_files(analysis_root):
        candidates.append(
            (
                _relative_name(file_name, analysis_root),
                "pom",
                file_name,
                Path(file_name).read_text(encoding="utf8"),
            )
        )

    occurrences: list[tuple[str, str]] = []
    found_names: set[str] = set()
    for relative_path, input_kind, file_name, content in sorted(candidates):
        for rule in FRAMEWORK_MARKER_RULES:
            if rule["input_kind"] != input_kind:
                continue
            if rule["marker_detector"](file_name, content):
                finding_name = str(rule["finding_name"])
                occurrences.append((finding_name, relative_path))
                found_names.add(finding_name)

    # Finding order follows the registry rather than discovery order so stdout
    # remains stable even when matching files move within the tree.
    findings = tuple(
        rule
        for rule in FRAMEWORK_MARKER_RULES
        if rule["finding_name"] in found_names
    )
    return {
        "occurrences": tuple(occurrences),
        "findings": findings,
        "selected_frameworks": frozenset(
            rule["auto_selected_framework"]
            for rule in findings
            if rule["selection_mode"] == "auto"
            and rule["auto_selected_framework"] is not None
        ),
    }


__all__ = [
    "CODEGEN_REPORT_HINT",
    "FRAMEWORK_MARKER_RULES",
    "detect_jax_rs_marker",
    "detect_spring_codegen_marker",
    "detect_spring_functional_route_marker",
    "detect_spring_marker",
    "detect_wicket_marker",
    "discover_java_files",
    "discover_pom_files",
    "is_ignored_source_file",
    "scan_framework_markers",
]
