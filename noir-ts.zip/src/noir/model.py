"""Immutable values passed between Noir's application pipeline stages.

This module contains vocabulary, not analysis behavior. It deliberately knows
nothing about Java, Spring, JAX-RS, CSV, logging, or file publication.

Logic guide: ``p6.logic/01-mental-model.md``,
``p6.logic/07-output-evidence-reports.md``, and
``p6.logic/11-naming-and-code-vocabulary.md``.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, TypeAlias

from .immutability import freeze_data


def _read_path(value: SourceFile | os.PathLike[str] | str) -> SourceFile:
    """Coerce a path-like value into the typed source-identity wrapper.

    Example call:
        ``_read_path("/workspace/app/ItemsController.java")`` returns the
        source identity ``SourceFile("/workspace/app/ItemsController.java")``.
    """

    return value if isinstance(value, SourceFile) else SourceFile(os.fspath(value))


class FrameworkSelection(str, Enum):
    """One normalized analyzer family selected by orchestration.

    ``JAX_RS`` is the internal concept; its value is the externally supported
    ``jaxrx`` CLI token.
    """

    SPRING = "spring"  # Run the Spring endpoint analyzer family.
    JAX_RS = "jaxrx"  # Run the JAX-RS and Java WebSocket analyzer family.
    WICKET = "wicket"  # Run the executable Wicket integration stub.

    # Example value: FrameworkSelection.SPRING selects the Spring passes.


# The enum is the runtime and CLI authority for explicit framework modes.
# ``auto`` is a selection policy rather than an analyzer family, so it follows
# the concrete identities without becoming a FrameworkSelection member.
FRAMEWORK_MODE_CHOICES = tuple(
    selection.value for selection in FrameworkSelection
) + ("auto",)

# ``None`` is the broad default (Spring and JAX-RS), ``auto`` is the marker
# policy, a scalar is one explicit family, and a tuple is an explicit set.
# Runtime validation against ``FrameworkSelection`` keeps that enum the only
# list of concrete framework tokens.
FrameworkMode: TypeAlias = str | tuple[str, ...] | None


def _normalize_framework_mode(mode: FrameworkMode) -> FrameworkMode:
    """Validate and canonicalize one framework-selection policy.

    A single explicit family remains a string for compatibility. Multiple
    explicit families become an immutable tuple in ``FrameworkSelection``
    order. ``auto`` is valid only as the scalar marker-selection policy.

    Example call:
        ``_normalize_framework_mode(("wicket", "spring"))`` returns
        ``("spring", "wicket")``; duplicates, an empty tuple, or a tuple
        containing ``"auto"`` raise ``ValueError``.
    """

    if mode is None or mode == "auto":
        return mode
    is_group = isinstance(mode, tuple)
    values = mode if is_group else (mode,)
    if not values:
        raise ValueError("explicit framework selection must not be empty")
    if "auto" in values:
        raise ValueError("auto must be requested once and alone")
    try:
        selections = tuple(FrameworkSelection(value) for value in values)
    except (TypeError, ValueError) as error:
        raise ValueError(f"unsupported framework mode: {mode!r}") from error
    if len(set(selections)) != len(selections):
        raise ValueError("a framework may be requested only once")
    ordered = tuple(
        selection.value
        for selection in FrameworkSelection
        if selection in selections
    )
    return ordered if len(ordered) > 1 else ordered[0]


@dataclass(frozen=True, slots=True)
class AnalysisRequest:
    """Resolved analysis intent, independent of CLI and output destinations.

    This value normalizes identity but does not require the root to exist; the
    CLI owns that user-input validation, while programmatic callers may define
    their own source edge.
    """

    # Root of the application source tree whose endpoints are being inventoried.
    analysis_root: Path
    # Analyzer policy: explicit family/families, marker ``auto``, or the default.
    framework_mode: FrameworkMode = None

    # Example value:
    # AnalysisRequest(Path("/workspace/shop"), ("spring", "wicket"))

    def __post_init__(self) -> None:
        """Freeze a canonical root and validate the requested framework mode.

        Example call:
            ``AnalysisRequest(Path("/workspace/shop"), "spring")`` invokes
            this hook and retains the absolute application root.
        """

        root = Path(self.analysis_root).expanduser().resolve()
        framework_mode = _normalize_framework_mode(self.framework_mode)
        object.__setattr__(self, "analysis_root", root)
        object.__setattr__(self, "framework_mode", framework_mode)


@dataclass(frozen=True, slots=True)
class FrameworkPlan:
    """Requested framework policy and its effective ordered analyzer set.

    Keeping both answers makes it possible to distinguish an explicit/default
    run from ``auto`` even when they happen to select the same families.
    """

    # Requested default, auto, or explicit single/multiple framework policy.
    requested_mode: FrameworkMode
    # Effective analyzer families in the order supplied by orchestration.
    selected: tuple[FrameworkSelection, ...] = ()

    # Example value:
    # FrameworkPlan(None, (FrameworkSelection.SPRING, FrameworkSelection.JAX_RS))

    def __post_init__(self) -> None:
        """Normalize selections and reject duplicate analyzer execution.

        Example call:
            ``FrameworkPlan("auto", (FrameworkSelection.SPRING,))`` invokes
            this hook for a marker-selected Spring-only run.
        """

        requested_mode = _normalize_framework_mode(self.requested_mode)
        selected = tuple(FrameworkSelection(item) for item in self.selected)
        if len(set(selected)) != len(selected):
            raise ValueError("a framework may be selected only once")
        if requested_mode not in (None, "auto"):
            requested_values = (
                requested_mode
                if isinstance(requested_mode, tuple)
                else (requested_mode,)
            )
            requested = {FrameworkSelection(item) for item in requested_values}
            if set(selected) != requested:
                raise ValueError(
                    "explicit framework plan must select exactly its requested families"
                )
        object.__setattr__(self, "requested_mode", requested_mode)
        object.__setattr__(self, "selected", selected)


@dataclass(frozen=True, slots=True, order=True)
class SourceFile:
    """An analysis-owned source name before presentation relativizes it.

    The wrapper prevents a source identity from being confused with arbitrary
    strings while remaining accepted by normal path APIs.
    """

    # Stable path spelling used to identify one application source file.
    path: str

    # Example value: SourceFile("/workspace/app/ItemsController.java")

    def __post_init__(self) -> None:
        """Normalize a path-like input to a non-empty string identity.

        Example call:
            ``SourceFile(Path("/workspace/app/ItemsController.java"))``
            invokes this hook and stores the path spelling as a string.
        """

        path = os.fspath(self.path)
        if not isinstance(path, str) or not path:
            raise ValueError("source file path must be a non-empty string")
        object.__setattr__(self, "path", path)

    def __fspath__(self) -> str:
        """Expose the source identity to standard filesystem APIs.

        Example call:
            ``os.fspath(SourceFile("/workspace/app/ItemsController.java"))``
            returns ``"/workspace/app/ItemsController.java"``.
        """

        return self.path

    def __str__(self) -> str:
        """Expose the source identity as its ordinary string spelling.

        Example call:
            ``str(SourceFile("/workspace/app/ItemsController.java"))`` returns
            the source path shown in diagnostics.
        """

        return self.path


@dataclass(frozen=True, slots=True, order=True)
class SourceSpan:
    """An exact half-open byte span in one snapshotted source file.

    Byte offsets, rather than rows or names, provide stable declaration
    identity compatible with Tree-sitter and represented-target reports.
    """

    # Source file containing the declaration or annotation being identified.
    source_file: SourceFile
    # Byte offset where the represented Java syntax begins, inclusive.
    start_byte: int
    # Byte offset immediately after that syntax, exclusive.
    end_byte: int

    # Example value:
    # SourceSpan(SourceFile("/workspace/app/ItemsController.java"), 800, 920)

    def __post_init__(self) -> None:
        """Coerce source identity and enforce a real non-empty byte interval.

        Example call:
            ``SourceSpan("/workspace/app/ItemsController.java", 800, 920)``
            invokes this hook for the bytes occupied by a handler method.
        """

        object.__setattr__(self, "source_file", _read_path(self.source_file))
        if (
            isinstance(self.start_byte, bool)
            or isinstance(self.end_byte, bool)
            or not isinstance(self.start_byte, int)
            or not isinstance(self.end_byte, int)
            or self.start_byte < 0
            or self.end_byte <= self.start_byte
        ):
            raise ValueError("source span must satisfy 0 <= start_byte < end_byte")


@dataclass(frozen=True, slots=True, order=True)
class SourceTarget:
    """A source declaration represented by an endpoint fact.

    Combining declaration kind with its exact span lets reports subtract a
    method, record component, or type without retaining parser objects or
    guessing from annotation/handler names.
    """

    # Application declaration category represented by an endpoint, such as ``method``.
    kind: str
    # Exact source identity and byte interval of that declaration.
    span: SourceSpan

    # Example value:
    # SourceTarget("method", SourceSpan(SourceFile("ItemsController.java"), 800, 920))

    def __post_init__(self) -> None:
        """Require an explicit declaration kind and already-validated span.

        Example call:
            ``SourceTarget("method", handler_span)`` invokes this hook to
            identify the Java declaration accounted for by an endpoint.
        """

        if not isinstance(self.kind, str) or not self.kind:
            raise ValueError("source target kind must be a non-empty string")
        if not isinstance(self.span, SourceSpan):
            raise TypeError("source target span must be a SourceSpan")


@dataclass(frozen=True, slots=True)
class AnnotationEvidence:
    """Scalar request-method provenance retained for CSV line selection.

    Validation of family, line, and same-file ownership occurs in
    :mod:`noir.evidence`; this value ensures parser nodes never cross the typed
    application boundary.
    """

    # One-based line of the route's scalar HTTP-method annotation.
    line: int
    # Proven fully qualified annotation identity, not merely its source spelling.
    identity: str
    # Supported evidence family used to validate and order the annotation line.
    family: str
    # File that owns the annotation; it must match the endpoint's public source.
    source_file: SourceFile

    # Example value:
    # AnnotationEvidence(42, "org.springframework.web.bind.annotation.GetMapping",
    #                    "spring-request-mapping", SourceFile("ItemsController.java"))

    def __post_init__(self) -> None:
        """Coerce the path-like source identity to :class:`SourceFile`.

        Example call:
            ``AnnotationEvidence(42, mapping_fqn, "spring-request-mapping",
            "/workspace/app/ItemsController.java")`` invokes this hook.
        """

        object.__setattr__(self, "source_file", _read_path(self.source_file))


@dataclass(frozen=True, slots=True)
class EndpointFact:
    """One rich analyzer fact before the intentionally lossy output boundary.

    Route declaration, concrete handler, and configuration owner are separate
    provenance identities because inherited/project routes can span files.
    ``source_line`` is analyzer diagnostic context, not the CSV annotation
    line. ``annotation_evidence`` and ``represented_targets`` carry the two
    private correctness channels used after public projection. Framework-local
    construction details stay with their analyzer until a fact is ready.
    """

    # Route path as proven by the analyzer, before final public normalization.
    path: str
    # Operation token such as ``GET``, ``POST``, ``SEND``, or ``SUBSCRIBE``.
    method: str
    # Java handler's source parameter spelling shown to the report reader.
    parameters: str
    # Source identity published in the endpoint row, normally the concrete handler.
    source_file: SourceFile
    # Reader-facing owning type and operation, for example ``ItemsController.list``.
    handler_name: str
    # Candidate-local diagnostic line; this is not automatically the CSV annotation line.
    source_line: int | None = None
    # Declaration that contributed route semantics such as the path and verb.
    route_source_file: SourceFile | None = None
    # One-based location of the route declaration when the analyzer can retain it.
    route_source_line: int | None = None
    # Concrete source declaration credited with implementing or serving the route.
    handler_source_file: SourceFile | None = None
    # One-based location of that concrete handler declaration.
    handler_source_line: int | None = None
    # Source/configuration owner used to select project-level base-path settings.
    project_source_file: SourceFile | None = None
    # Framework family that proved the fact, normally ``spring`` or ``jax-rs``.
    technology: str | None = None
    # Wire/application protocol, currently principally ``http`` or ``ws``.
    protocol: str = "http"
    # Analyzer-proven endpoint role; current producers use the documented surface set.
    surface: str = "server"
    # Traffic direction from the application's view, normally inbound or outbound.
    direction: str | None = None
    # Validated method-annotation provenance eligible for the CSV line column.
    annotation_evidence: tuple[AnnotationEvidence, ...] = ()
    # Exact source declarations accounted for by this endpoint in absence reports.
    represented_targets: tuple[SourceTarget, ...] = ()

    # Example value (an inherited route whose handler and configuration live elsewhere):
    # EndpointFact(
    #     path="/api/items", method="GET", parameters="String filter",
    #     source_file=SourceFile("/workspace/app/ItemsController.java"),
    #     handler_name="ItemsController.list", source_line=42,
    #     route_source_file=SourceFile("/workspace/contracts/ItemsApi.java"),
    #     route_source_line=12,
    #     handler_source_file=SourceFile("/workspace/app/ItemsController.java"),
    #     handler_source_line=42,
    #     project_source_file=SourceFile("/workspace/app/Routes.java"),
    #     technology="spring", protocol="http", surface="server",
    #     direction="inbound", annotation_evidence=(mapping_evidence,),
    #     represented_targets=(handler_target,),
    # )

    def __post_init__(self) -> None:
        """Normalize path-like identities and seal every nested collection.

        Example call:
            ``EndpointFact(path="/items", method="GET", parameters="",
            source_file="ItemsController.java",
            handler_name="ItemsController.list")`` invokes this hook.
        """

        object.__setattr__(self, "source_file", _read_path(self.source_file))
        for name in (
            "route_source_file",
            "handler_source_file",
            "project_source_file",
        ):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(self, name, _read_path(value))

        if isinstance(self.annotation_evidence, Mapping):
            raise TypeError("annotation evidence must contain AnnotationEvidence values")
        evidence = tuple(self.annotation_evidence)
        if not all(isinstance(item, AnnotationEvidence) for item in evidence):
            raise TypeError("annotation evidence must contain AnnotationEvidence values")

        if isinstance(self.represented_targets, Mapping):
            raise TypeError("represented targets must contain SourceTarget values")
        targets = tuple(self.represented_targets)
        if not all(isinstance(item, SourceTarget) for item in targets):
            raise TypeError("represented targets must contain SourceTarget values")

        object.__setattr__(self, "annotation_evidence", evidence)
        object.__setattr__(self, "represented_targets", targets)


@dataclass(frozen=True, slots=True)
class AnalysisDiagnostic:
    """One presentation-neutral event produced while proving source facts.

    Timestamping and line rendering belong to run-local diagnostic capture;
    optional span/category data can therefore remain deterministic domain data.
    """

    # Human-readable explanation of an analysis event or rejected candidate.
    message: str
    # Operational importance label used when the diagnostic is rendered.
    severity: str = "info"
    # Optional exact source interval that caused or contextualizes the event.
    source: SourceSpan | None = None
    # Optional stable grouping such as framework selection or endpoint decoding.
    category: str | None = None

    # Example value:
    # AnalysisDiagnostic("Skipped ambiguous mapping", "warning", mapping_span,
    #                    "spring-mvc")


@dataclass(frozen=True, slots=True)
class AnalysisResult:
    """Complete immutable handoff from analysis to presentation boundaries.

    Endpoint facts and structured diagnostics are accompanied by the selected
    framework plan, broad annotation inventory, final-trigger inventory, raw
    auto detections, and stdout announcements.  These parallel views cannot be
    reconstructed from the intentionally lossy endpoint CSV alone.
    """

    # All source-backed endpoint facts produced by the selected analyzers.
    endpoints: tuple[EndpointFact, ...] = ()
    # Run-scoped analysis events collected while proving or rejecting candidates.
    diagnostics: tuple[AnalysisDiagnostic, ...] = ()
    # Requested framework policy and the effective analyzer family order.
    framework_plan: FrameworkPlan | None = None
    # Broad view of recognized source annotation occurrences for audit output.
    annotation_audit_inventory: tuple[Any, ...] = ()
    # Narrow view of route-trigger declarations used by unmatched reporting.
    final_trigger_inventory: tuple[Any, ...] = ()
    # Raw marker findings that explain an automatic framework decision.
    detections: tuple[Any, ...] = ()
    # Stable user-facing framework-selection messages emitted by the CLI.
    announcements: tuple[Any, ...] = ()

    # Example value:
    # AnalysisResult(endpoints=(items_endpoint,), framework_plan=spring_plan,
    #                diagnostics=(ambiguity_notice,), announcements=(message,))

    def __post_init__(self) -> None:
        """Snapshot every collection so callers cannot mutate a completed run.

        Example call:
            ``AnalysisResult(endpoints=[items_endpoint], diagnostics=[])``
            invokes this hook and detaches both supplied collections.
        """

        endpoints = tuple(self.endpoints)
        if not all(isinstance(item, EndpointFact) for item in endpoints):
            raise TypeError("analysis endpoints must contain EndpointFact values")
        diagnostics = tuple(self.diagnostics)
        if not all(isinstance(item, AnalysisDiagnostic) for item in diagnostics):
            raise TypeError("analysis diagnostics must contain AnalysisDiagnostic values")
        object.__setattr__(self, "endpoints", endpoints)
        object.__setattr__(self, "diagnostics", diagnostics)
        for name in (
            "annotation_audit_inventory",
            "final_trigger_inventory",
            "detections",
            "announcements",
        ):
            object.__setattr__(
                self,
                name,
                tuple(freeze_data(item) for item in getattr(self, name)),
            )


__all__ = [
    "AnalysisDiagnostic",
    "AnalysisRequest",
    "AnalysisResult",
    "AnnotationEvidence",
    "EndpointFact",
    "FRAMEWORK_MODE_CHOICES",
    "FrameworkMode",
    "FrameworkPlan",
    "FrameworkSelection",
    "SourceFile",
    "SourceSpan",
    "SourceTarget",
]
