"""JAX-RS family setup, preparation, and ordered endpoint analysis.

The application pipeline calls these small facade functions through the
framework registry.  This module owns JAX-RS orchestration and imports no
Spring implementation, while the individual semantic analyzers retain their
existing responsibilities.

Logic guide: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/06-jax-rs.md``.
"""

from __future__ import annotations

from .diagnostics import record
from .java_workspace import JavaWorkspace
from .java_websocket import analyze_java_websocket_endpoints
from .jaxrs import (
    JaxRsState,
    analyze_direct_jax_rs_unit,
)
from .jaxrs_deployment import build_jax_rs_deployment_model
from .jaxrs_hierarchy import analyze_jax_rs_hierarchy_and_subresources
from .model import AnalysisRequest, EndpointFact


def prepare_jaxrs_analysis(
    request: AnalysisRequest, _workspace: JavaWorkspace, state: JaxRsState
) -> None:
    """Build deployment evidence before any selected family starts analysis.

    The pipeline invokes preparation only for selected adapters and completes
    that phase before any analysis starts.  This hook supplies JAX-RS with its
    ``web.xml`` and application prefix evidence; the neutral workspace stays
    unchanged, and other families do not consume JAX-RS state.

    Example call:
        ``prepare_jaxrs_analysis(request, workspace, jaxrs_state)`` prepares
        the state's deployment model scoped to ``request.analysis_root``.
    """

    state.deployment_model = build_jax_rs_deployment_model(
        state.applications, str(request.analysis_root)
    )


def analyze_jaxrs_framework(
    _request: AnalysisRequest,
    source_paths: tuple[str, ...],
    workspace: JavaWorkspace,
    state: JaxRsState,
) -> tuple[EndpointFact, ...]:
    """Run direct, hierarchy/subresource, then Java WebSocket recognizers.

    Direct analysis follows immutable snapshot order and records the same
    source heading as the former pipeline-owned loop.  Project-wide passes run
    once when the shared workspace contains compilation units.  ``_request``
    is intentionally unused today but keeps one common adapter signature for
    frameworks that need request-level configuration.

    Example call:
        ``analyze_jaxrs_framework(request, source_paths, workspace,
        jaxrs_state)`` returns
        all JAX-RS and Java WebSocket facts as one ordered immutable tuple.
    """

    endpoints: list[EndpointFact] = []
    units = workspace.get("compilation_units", {})
    for source_path in source_paths:
        unit = units.get(source_path)
        if unit is None:
            continue
        record(f"{source_path}:")
        endpoints.extend(analyze_direct_jax_rs_unit(unit, workspace, state=state))
    if units:
        endpoints.extend(
            analyze_jax_rs_hierarchy_and_subresources(workspace, state=state)
        )
        endpoints.extend(analyze_java_websocket_endpoints(workspace))
    return tuple(endpoints)


__all__ = [
    "analyze_jaxrs_framework",
    "prepare_jaxrs_analysis",
]
