"""Bounded source-only Spring HTTP client contract identification.

The analyzer receives an already-built Java workspace and identifies outbound
Spring HTTP Interface declarations and Feign interfaces without
reclassifying them as inbound server handlers. Only direct, genuinely
resolved framework annotations on unique source interfaces participate;
unresolved or ambiguous endpoint identity fails closed.

Logic guide: ``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Iterable

from .contracts import (
    HTTP_METHOD_TOKEN,
    METHOD_ANNOTATION_FAMILY_BY_IDENTITY,
    SPRING_HTTP_METHODS,
)
from .diagnostics import format_endpoint_diagnostic, record
from .evidence import (
    merge_endpoint_facts,
    method_annotation_evidence_from_mapping,
    represented_target_evidence,
)
from .java_frontend import (
    annotation_value_nodes,
    child_by_field,
    declaration_modifier_names,
    direct_annotation_records,
    get_annotation_arguments,
    lexical_type_chain,
    node_text,
    parameter_list_source_text,
    resolve_known_annotation,
    tree_node_key,
)
from .java_workspace import resolve_workspace_string_expression
from .model import EndpointFact
from .paths import ensure_path_leading_slash, join_endpoint_paths
from .spring_config import (
    SpringWorkspacePathConfiguration,
    apply_spring_path_configuration,
    resolve_spring_client_path_layers,
)
from .spring_mvc import (
    decode_builtin_spring_mapping,
    decode_spring_composed_mapping,
    union_request_method_conditions,
)


HTTP_EXCHANGE_PACKAGE = "org.springframework.web.service.annotation"
FEIGN_CLIENT_PACKAGE = "org.springframework.cloud.openfeign"

HTTP_EXCHANGE_METHODS = {
    "GetExchange": "GET",
    "PostExchange": "POST",
    "PutExchange": "PUT",
    "DeleteExchange": "DELETE",
    "PatchExchange": "PATCH",
    "HttpExchange": None,
}

HTTP_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "method", "contentType", "accept", "headers"}
)
FIXED_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "contentType", "accept", "headers"}
)


@dataclass(frozen=True, slots=True)
class _ClientCandidate:
    """Keep temporary client construction details inside the Spring family."""

    # Raw contract fact carrying exact method and mapping evidence.
    endpoint: EndpointFact
    # HTTP Interface lexical layers; Feign uses its already-composed fact path.
    path_layers: tuple[str, ...] | None

    # Example value: _ClientCandidate(items_fact, ("/api", "${remote.items}"))


def _log(unit: dict[str, Any], owner: str, message: str) -> None:
    """Record why an outbound contract candidate failed closed.

    Example call:
        ``_log(unit=items_unit, owner="ItemsController", message="unresolved route path")``
        records why an outbound contract candidate failed closed.
    """

    record(
        f"Skipped Spring client in {unit['source_path']} for {owner}: {message}"
    )


def _direct_methods(interface_node: Any) -> list[Any]:
    """Return source-ordered methods declared by one client interface.

    Example call:
        ``_direct_methods(interface_node=items_client_interface_node)``
        returns source-ordered methods declared by one client interface.
    """

    body = child_by_field(interface_node, "body")
    if body is None:
        return []
    return sorted(
        (
            child
            for child in body.named_children
            if child.type == "method_declaration"
        ),
        key=lambda node: node.start_byte,
    )


def _usable_contract_method(method_node: Any) -> bool:
    """Exclude private/static declarations that cannot be client operations.

    Example call:
        ``_usable_contract_method(method_node=list_method_node)``
        excludes private/static declarations that cannot be client operations.
    """

    modifiers = declaration_modifier_names(method_node)
    return "private" not in modifiers and "static" not in modifiers


def _resolved_exchange_annotations(
    unit: dict[str, Any], declaration_node: Any
) -> list[tuple[dict[str, Any], str]]:
    """Resolve genuine direct Spring HTTP Exchange annotations on a declaration.

    Example call:
        ``_resolved_exchange_annotations(
            unit=items_unit,
            declaration_node=items_declaration_node,
        )``
        resolves genuine direct Spring HTTP Exchange annotations on a declaration.
    """

    resolved: list[tuple[dict[str, Any], str]] = []
    for annotation_record in direct_annotation_records(declaration_node):
        identity = resolve_known_annotation(
            unit,
            annotation_record["name_node"],
            set(HTTP_EXCHANGE_METHODS),
            (HTTP_EXCHANGE_PACKAGE,),
        )
        if identity is not None:
            resolved.append((annotation_record, identity["name"]))
    return resolved


def _resolve_string_values(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    value_node: Any,
) -> tuple[str, ...] | None:
    """Resolve one annotation value/array into ordered static String alternatives.

    Example call:
        ``_resolve_string_values(
            unit=items_unit,
            workspace=java_workspace,
            owner="ItemsController",
            value_node=route_value_node,
        )``
        resolves one annotation value/array into ordered static String alternatives.
    """

    values: list[str] = []
    for current in annotation_value_nodes(value_node):
        value = resolve_workspace_string_expression(
            unit, current, workspace, owner
        )
        if value is None:
            return None
        values.append(value)
    # Noir's Java mapping decoder fans out array-shaped annotation input even
    # for annotations whose library declaration is scalar.  Retain that
    # source-recovery behavior, but only after genuine annotation provenance.
    return tuple(dict.fromkeys(values)) if values else ("",)


def _normalize_client_path(value: str) -> str:
    """Normalize a client path without corrupting absolute or configured bases.

    Example call:
        ``_normalize_client_path(value="https://api.example.com/items")``
        normalizes a client path without corrupting absolute or configured bases.
    """

    return (
        value
        if value.lower().startswith(("http://", "https://"))
        # Configuration is applied after extraction. Keep a root placeholder
        # unprefixed so a later absolute configured base remains a valid URL.
        or value.startswith("${")
        else ensure_path_leading_slash(value)
    )


def _combine_client_paths(type_path: str, method_path: str) -> str:
    """Compose lexical client paths with inner absolute-URL precedence.

    Example call:
        ``_combine_client_paths(type_path="/api", method_path="/items")``
        composes lexical client paths with inner absolute-URL precedence.
    """

    # A method-level absolute client URL is already complete and must not be
    # appended to a type-level contract prefix.
    if method_path.lower().startswith(("http://", "https://")):
        return method_path
    return join_endpoint_paths(type_path, method_path)


def _decode_exchange_paths(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_node: Any,
) -> list[str] | None:
    """Decode coherent value/url aliases into ordered client path fan-out.

    Example call:
        ``_decode_exchange_paths(
            unit=items_unit,
            workspace=java_workspace,
            owner="ItemsController",
            annotation_node=mapping_annotation_node,
        )``
        decodes coherent value/url aliases into ordered client path fan-out.
    """

    positional, named = get_annotation_arguments(annotation_node)
    if len(positional) > 1 or (positional and "value" in named):
        _log(unit, owner, "invalid positional/value URL aliases")
        return None

    explicit: list[tuple[str, Any]] = []
    if positional:
        explicit.append(("value", positional[0]))
    for attribute in ("value", "url"):
        if attribute in named:
            explicit.append((attribute, named[attribute]))
    if not explicit:
        return [""]

    aliases: list[tuple[str, tuple[str, ...]]] = []
    for attribute, node in explicit:
        values = _resolve_string_values(unit, workspace, owner, node)
        if values is None:
            _log(
                unit,
                owner,
                f"unresolved @{attribute} client path: "
                f"{node_text(unit['source'], node).strip()}",
            )
            return None
        aliases.append((attribute, values))
    if len({values for _attribute, values in aliases}) != 1:
        _log(unit, owner, "conflicting explicit value/url aliases")
        return None
    return list(
        dict.fromkeys(
            _normalize_client_path(value) for value in aliases[0][1]
        )
    )


def _decode_exchange_methods(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_name: str,
    annotation_node: Any,
) -> list[str] | None:
    """Decode fixed or custom HTTP Exchange method conditions.

    Example call:
        ``_decode_exchange_methods(
            unit=items_unit,
            workspace=java_workspace,
            owner="ItemsController",
            annotation_name="HttpExchange",
            annotation_node=mapping_annotation_node,
        )``
        decodes fixed or custom HTTP Exchange method conditions.
    """

    _positional, named = get_annotation_arguments(annotation_node)
    if annotation_name != "HttpExchange":
        if "method" in named:
            _log(unit, owner, f"invalid method on @{annotation_name}")
            return None
        return [HTTP_EXCHANGE_METHODS[annotation_name]]

    method_node = named.get("method")
    if method_node is None:
        return []
    resolved = _resolve_string_values(unit, workspace, owner, method_node)
    if resolved is None:
        _log(
            unit,
            owner,
            "unresolved @HttpExchange method: "
            f"{node_text(unit['source'], method_node).strip()}",
        )
        return None

    methods: list[str] = []
    for value in resolved:
        token = value.strip().upper()
        if not token:
            continue
        if len(token) > 128 or HTTP_METHOD_TOKEN.fullmatch(token) is None:
            _log(unit, owner, f"invalid @HttpExchange method token: {value}")
            return None
        methods.append(token)
    return list(dict.fromkeys(methods))


def _decode_exchange_mapping(
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    record: dict[str, Any],
    annotation_name: str,
) -> dict[str, Any] | None:
    """Turn one proven Exchange annotation into paths, verbs, and provenance.

    Example call:
        ``_decode_exchange_mapping(
            unit=items_unit,
            workspace=java_workspace,
            owner="ItemsController",
            record=path_annotation_record,
            annotation_name="HttpExchange",
        )``
        turns one proven Exchange annotation into paths, verbs, and provenance.
    """

    _positional, named = get_annotation_arguments(record["node"])
    allowed = (
        HTTP_EXCHANGE_ATTRIBUTES
        if annotation_name == "HttpExchange"
        else FIXED_EXCHANGE_ATTRIBUTES
    )
    unsupported = sorted(set(named) - allowed)
    if unsupported:
        _log(
            unit,
            owner,
            "unsupported @"
            f"{annotation_name} attributes: {', '.join(unsupported)}",
        )
        return None
    paths = _decode_exchange_paths(unit, workspace, owner, record["node"])
    methods = _decode_exchange_methods(
        unit,
        workspace,
        owner,
        annotation_name,
        record["node"],
    )
    if paths is None or methods is None:
        return None
    return {
        "paths": paths,
        "methods": methods,
        "annotation_node": record["node"],
        "annotation_identity": f"{HTTP_EXCHANGE_PACKAGE}.{annotation_name}",
        "annotation_family": METHOD_ANNOTATION_FAMILY_BY_IDENTITY[
            f"{HTTP_EXCHANGE_PACKAGE}.{annotation_name}"
        ],
    }


def _ordered_methods(methods: Iterable[str]) -> list[str]:
    """Deduplicate verbs using Spring's stable order before custom tokens.

    Example call:
        ``_ordered_methods(methods=("GET", "POST"))``
        deduplicates verbs using Spring's stable order before custom tokens.
    """

    unique = set(methods)
    known = [method for method in SPRING_HTTP_METHODS if method in unique]
    return known + sorted(unique - set(known))


def _union_exchange_methods(
    type_methods: Iterable[str],
    method_methods: Iterable[str],
) -> list[str]:
    """Combine type/method Exchange conditions using Noir's ordered-union rule.

    Example call:
        ``_union_exchange_methods(type_methods=("GET",), method_methods=("POST",))``
        combines type/method Exchange conditions using Noir's ordered-union rule.
    """

    type_methods = list(type_methods)
    method_methods = list(method_methods)
    if not type_methods:
        return _ordered_methods(method_methods)
    if not method_methods:
        return _ordered_methods(type_methods)
    return _ordered_methods([*type_methods, *method_methods])


def _endpoint(
    unit: dict[str, Any],
    owner: str,
    method_node: Any,
    parameters_node: Any,
    mapping: dict[str, Any],
    path: str,
    http_method: str,
    *,
    path_layers: tuple[str, ...] | None = None,
) -> _ClientCandidate:
    """Create one local client candidate with exact mapping and method evidence.

    Example call:
        ``_endpoint(
            unit=items_unit,
            owner="ItemsClient",
            method_node=list_method_node,
            parameters_node=list_parameters_node,
            mapping={"paths": ("/items",), "methods": ("GET",), "valid": True},
            path="/api/items",
            http_method="GET",
        )``
        creates one local client candidate with exact mapping and method evidence.
    """

    mapping_node = mapping["annotation_node"]
    endpoint = EndpointFact(
        path=path,
        method=http_method,
        parameters=parameter_list_source_text(unit["source"], parameters_node),
        source_file=unit["source_path"],
        source_line=mapping_node.start_point.row + 1,
        handler_name=owner,
        route_source_file=unit["source_path"],
        route_source_line=mapping_node.start_point.row + 1,
        handler_source_file=unit["source_path"],
        handler_source_line=method_node.start_point.row + 1,
        project_source_file=unit["source_path"],
        technology="spring",
        protocol="http",
        surface="client",
        direction="outbound",
        annotation_evidence=method_annotation_evidence_from_mapping(
            mapping,
            annotation_source_file=unit["source_path"],
            endpoint_source_file=unit["source_path"],
        ),
        represented_targets=represented_target_evidence(
            unit["source_path"], "method", method_node
        ),
    )
    record(format_endpoint_diagnostic(endpoint))
    return _ClientCandidate(endpoint, path_layers)


def _http_interface_endpoints(
    workspace: dict[str, Any],
    declaration: dict[str, Any],
) -> list[_ClientCandidate]:
    """Extract Spring HTTP Interface operations with lexical contract layers.

    Example call:
        ``_http_interface_endpoints(
            workspace=java_workspace,
            declaration=items_client_declaration,
        )``
        extracts Spring HTTP Interface operations with lexical contract layers.
    """

    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_owner = type_info["display_name"]
    type_node = type_info["node"]
    path_layers: list[tuple[str, ...]] = []
    type_methods: list[str] = []
    for layer in lexical_type_chain(
        tree_node_key(type_node), unit["type_infos"]
    ):
        type_annotations = [
            (record, name)
            for record, name in _resolved_exchange_annotations(
                unit, layer["node"]
            )
            if name == "HttpExchange"
        ]
        if len(type_annotations) > 1:
            _log(
                unit,
                type_owner,
                "multiple type-level @HttpExchange mappings",
            )
            return []
        if not type_annotations:
            continue
        mapping = _decode_exchange_mapping(
            unit,
            workspace,
            layer["display_name"],
            type_annotations[0][0],
            type_annotations[0][1],
        )
        if mapping is None:
            return []
        path_layers.append(tuple(mapping["paths"]))
        type_methods = _union_exchange_methods(type_methods, mapping["methods"])
    if not path_layers:
        path_layers = [("",)]

    endpoints: list[_ClientCandidate] = []
    for method_node in _direct_methods(type_node):
        if not _usable_contract_method(method_node):
            continue
        name_node = child_by_field(method_node, "name")
        parameters_node = child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        mappings = _resolved_exchange_annotations(
            unit, method_node
        )
        for record, annotation_name in mappings:
            mapping = _decode_exchange_mapping(
                unit,
                workspace,
                owner,
                record,
                annotation_name,
            )
            if mapping is None:
                continue
            methods = _union_exchange_methods(type_methods, mapping["methods"]) or [
                "ANY"
            ]
            combinations: list[tuple[str, ...]] = [()]
            for layer_paths in [*path_layers, tuple(mapping["paths"])]:
                combinations = [
                    (*prefix, current)
                    for prefix in combinations
                    for current in layer_paths
                ]
            for layers in combinations:
                path = ""
                for current in layers:
                    path = _combine_client_paths(path, current)
                for http_method in methods:
                    endpoints.append(
                        _endpoint(
                            unit,
                            owner,
                            method_node,
                            parameters_node,
                            mapping,
                            path,
                            http_method,
                            path_layers=layers,
                        )
                    )
    return endpoints


def _resolved_feign_client_markers(
    unit: dict[str, Any], type_node: Any
) -> list[dict[str, Any]]:
    """Resolve direct FeignClient markers used only to classify an interface.

    Example call:
        ``_resolved_feign_client_markers(
            unit=items_unit,
            type_node=items_controller_type_node,
        )``
        resolves direct FeignClient markers used only to classify an interface.
    """

    markers = []
    for annotation_record in direct_annotation_records(type_node):
        resolved = resolve_known_annotation(
            unit,
            annotation_record["name_node"],
            {"FeignClient"},
            (FEIGN_CLIENT_PACKAGE,),
        )
        if resolved is not None:
            markers.append(annotation_record)
    return markers


def _decode_mvc_mapping(
    workspace: dict[str, Any],
    unit: dict[str, Any],
    record: dict[str, Any],
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    """Decode a built-in or source-composed MVC mapping for a Feign contract.

    Example call:
        ``_decode_mvc_mapping(
            workspace=java_workspace,
            unit=items_unit,
            record=path_annotation_record,
            lexical_owner="ItemsController",
            diagnostic_owner="ItemsController.list",
        )``
        decodes a built-in or source-composed MVC mapping for a Feign contract.
    """

    mapping = decode_builtin_spring_mapping(
        unit,
        record["name_node"],
        record["node"],
        workspace,
        lexical_owner,
        diagnostic_owner,
    )
    if mapping is not None:
        return mapping
    return decode_spring_composed_mapping(
        unit["source_path"],
        unit,
        record["name_node"],
        record["node"],
        lexical_owner,
        diagnostic_owner,
        workspace,
    )


def _first_mvc_mapping(
    workspace: dict[str, Any],
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    """Select the first recognized MVC mapping on a Feign type layer.

    Example call:
        ``_first_mvc_mapping(
            workspace=java_workspace,
            unit=items_unit,
            declaration_node=items_declaration_node,
            lexical_owner="ItemsController",
            diagnostic_owner="ItemsController.list",
        )``
        selects the first recognized MVC mapping on a Feign type layer.
    """

    for annotation_record in direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            unit,
            annotation_record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            return mapping
    return None


def _all_mvc_mappings(
    workspace: dict[str, Any],
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> list[dict[str, Any]]:
    """Return every recognized method mapping that can fan out Feign routes.

    Example call:
        ``_all_mvc_mappings(
            workspace=java_workspace,
            unit=items_unit,
            declaration_node=items_declaration_node,
            lexical_owner="ItemsController",
            diagnostic_owner="ItemsController.list",
        )``
        returns every recognized method mapping that can fan out Feign routes.
    """

    mappings = []
    for annotation_record in direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            unit,
            annotation_record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            mappings.append(mapping)
    return mappings


def _feign_endpoints(
    workspace: dict[str, Any],
    declaration: dict[str, Any],
) -> list[_ClientCandidate]:
    """Extract outbound Feign operations from MVC mapping semantics.

    Example call:
        ``_feign_endpoints(workspace=java_workspace, declaration=items_client_declaration)``
        extracts outbound Feign operations from MVC mapping semantics.
    """

    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_node = type_info["node"]
    type_owner = type_info["display_name"]
    markers = _resolved_feign_client_markers(unit, type_node)
    if not markers:
        return []
    if len(markers) != 1:
        _log(unit, type_owner, "multiple @FeignClient annotations")
        return []

    # FeignClient.value/path are classification metadata in Noir's Spring
    # analyzer and deliberately do not contribute a container path.  Ordinary
    # MVC mappings on all lexical type layers do contribute.
    type_paths = [""]
    type_methods: list[str] = []
    for layer in lexical_type_chain(
        tree_node_key(type_node), unit["type_infos"]
    ):
        mapping = _first_mvc_mapping(
            workspace,
            unit,
            layer["node"],
            layer["display_name"],
            type_owner,
        )
        if mapping is None:
            continue
        if not mapping["valid"]:
            return []
        type_paths = [
            join_endpoint_paths(prefix, current)
            for prefix in type_paths
            for current in mapping["paths"]
        ]
        type_methods = union_request_method_conditions(
            type_methods, mapping["methods"]
        )

    endpoints: list[_ClientCandidate] = []
    for method_node in _direct_methods(type_node):
        if not _usable_contract_method(method_node):
            continue
        name_node = child_by_field(method_node, "name")
        parameters_node = child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        for mapping in _all_mvc_mappings(
            workspace, unit, method_node, type_owner, owner
        ):
            if not mapping["valid"]:
                continue
            methods = union_request_method_conditions(
                type_methods, mapping["methods"]
            ) or ["ANY"]
            for type_path in type_paths:
                for method_path in mapping["paths"]:
                    path = join_endpoint_paths(type_path, method_path)
                    for http_method in methods:
                        endpoints.append(
                            _endpoint(
                                unit,
                                owner,
                                method_node,
                                parameters_node,
                                mapping,
                                path,
                                http_method,
                            )
                        )
    return endpoints


def _deduplicate(
    candidates: Iterable[_ClientCandidate],
) -> tuple[_ClientCandidate, ...]:
    """Merge exact client facts without losing mapping/target evidence.

    Example call:
        ``_deduplicate(candidates=(items_candidate, duplicate_items_candidate))``
        merges exact client facts without losing mapping/target evidence.
    """

    unique: dict[tuple[Any, ...], _ClientCandidate] = {}
    for candidate in candidates:
        endpoint = candidate.endpoint
        key = (
            endpoint.path,
            endpoint.method,
            endpoint.parameters,
            endpoint.source_file,
            endpoint.source_line,
            endpoint.handler_name,
            endpoint.surface,
            endpoint.direction,
            candidate.path_layers is not None,
            candidate.path_layers or (),
        )
        # Lexical layers remain part of the local identity until configuration
        # resolves them; identical raw paths may have different absolute bases.
        unique[key] = (
            replace(
                candidate,
                endpoint=merge_endpoint_facts(unique[key].endpoint, endpoint),
            )
            if key in unique
            else candidate
        )
    return tuple(unique[key] for key in sorted(unique))


def analyze_spring_http_clients(
    workspace: dict[str, Any],
    configuration: SpringWorkspacePathConfiguration,
) -> tuple[EndpointFact, ...]:
    """Return configured outbound HTTP Interface and Feign endpoint facts.

    Lexical HTTP Interface layers survive only in local candidates. Resolve
    them before exporting ordinary facts, so shared model/output code never
    needs to understand Spring-specific construction state.

    Example call:
        ``analyze_spring_http_clients(workspace=java_workspace,
        configuration=spring_path_configuration)`` returns outbound Spring
        HTTP Interface and Feign facts with their project paths applied.
    """

    candidates: list[_ClientCandidate] = []
    for fqn in sorted(workspace.get("type_declarations", {})):
        declarations = workspace["type_declarations"][fqn]
        # Duplicate source identities are not safe client containers.
        if len(declarations) != 1:
            continue
        declaration = declarations[0]
        type_info = declaration["type_info"]
        if (
            type_info["node"].type != "interface_declaration"
            or not type_info["workspace_visible"]
        ):
            continue
        candidates.extend(_http_interface_endpoints(workspace, declaration))
        candidates.extend(_feign_endpoints(workspace, declaration))

    endpoints: list[EndpointFact] = []
    for candidate in _deduplicate(candidates):
        endpoint = candidate.endpoint
        if candidate.path_layers is None:
            endpoints.extend(apply_spring_path_configuration((endpoint,), configuration))
            continue
        path = resolve_spring_client_path_layers(
            candidate.path_layers,
            str(endpoint.project_source_file or endpoint.source_file),
            configuration,
        )
        if path is None:
            record(
                "Skipped Spring configuration/resource "
                "malformed or exhausted placeholder path in "
                f"{endpoint.source_file} for {endpoint.handler_name}"
            )
            continue
        endpoints.append(replace(endpoint, path=path))
    return tuple(endpoints)


__all__ = ["analyze_spring_http_clients"]
