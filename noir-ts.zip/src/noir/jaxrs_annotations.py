"""JAX-RS-owned annotation audit and final-trigger recognition.

The shared inventory owns source traversal and report assembly. These small
callbacks interpret built-ins, source-defined request designators, definition
metadata, and the Java WebSocket surface belonging to this analyzer family.

Logic guides: ``p6.logic/06-jax-rs.md`` and
``p6.logic/07-output-evidence-reports.md``.
"""

from __future__ import annotations

from types import MappingProxyType

from .contracts import (
    JAX_RS_CORE_PACKAGES,
    JAX_RS_HTTP_METHODS,
    JAX_RS_PACKAGES,
    METHOD_ANNOTATION_FAMILY_JAX_RS,
)
from .inventory import (
    annotation_owner_name,
    direct_final_trigger_classifications,
    final_trigger_placement_supported,
    registered_annotation_classifications,
    source_definition_for_annotation_metadata,
)
from .java_frontend import resolve_known_annotation, tree_node_key
from .java_workspace import JavaWorkspace, source_annotation_use_is_method_applicable
from .jaxrs import JaxRsState, resolve_custom_designator


# The broad audit includes route triggers plus activation and binding metadata,
# even when an endpoint is rejected or never considered by an analyzer.
SUPPORTED_ANNOTATIONS = (
    {
        "packages": JAX_RS_PACKAGES,
        "names": frozenset(
            {
                *JAX_RS_HTTP_METHODS,
                "ApplicationPath",
                "BeanParam",
                "Consumes",
                "CookieParam",
                "DefaultValue",
                "Encoded",
                "FormParam",
                "HeaderParam",
                "HttpMethod",
                "MatrixParam",
                "Path",
                "PathParam",
                "Produces",
                "QueryParam",
            }
        ),
        "role": "jax-rs-http-surface",
    },
    {
        "packages": JAX_RS_CORE_PACKAGES,
        "names": frozenset({"Context"}),
        "role": "jax-rs-binding-metadata",
    },
    {
        "packages": (
            "jakarta.ws.rs.container",
            "javax.ws.rs.container",
        ),
        "names": frozenset({"Suspended"}),
        "role": "jax-rs-binding-metadata",
    },
    {
        "packages": (
            "jakarta.websocket.server",
            "javax.websocket.server",
        ),
        "names": frozenset({"ServerEndpoint"}),
        "role": "websocket-handshake",
    },
)


# Final triggers include only annotations at supported endpoint declarations;
# exact represented-target evidence later subtracts them from absence reports.
FINAL_TRIGGER_ANNOTATIONS = (
    {
        "packages": JAX_RS_PACKAGES,
        "names": frozenset(JAX_RS_HTTP_METHODS),
        "placement": "method-or-component",
        "family_by_name": MappingProxyType(
            {
                name: METHOD_ANNOTATION_FAMILY_JAX_RS
                for name in JAX_RS_HTTP_METHODS
            }
        ),
    },
    {
        "packages": (
            "jakarta.websocket.server",
            "javax.websocket.server",
        ),
        "names": frozenset({"ServerEndpoint"}),
        "placement": "concrete-type",
        "family_by_name": MappingProxyType(
            {"ServerEndpoint": "jax-websocket-server-endpoint"}
        ),
    },
)


def classify_jaxrs_annotation(
    unit, record, workspace: JavaWorkspace, *, state: JaxRsState
) -> list[dict[str, str]]:
    """Classify built-in, custom-designator, and contextual JAX-RS annotations.

    ``Retention`` and ``Target`` enter the audit only when they are direct
    metadata of one valid source-defined request designator. Definition proof
    stays separate from whether an applied occurrence can emit an endpoint.

    Example call:
        ``classify_jaxrs_annotation(unit, occurrence, workspace, state=state)``
        returns ``[{"resolved": "app.PROBE"}]`` for a supported custom
        designator and an empty list when its identity is unresolved.
    """

    classifications = registered_annotation_classifications(
        unit, record, workspace, SUPPORTED_ANNOTATIONS
    )
    resolved = resolve_custom_designator(
        unit, record["name_node"], workspace,
        annotation_owner_name(unit, record["node"]), state=state,
    )
    if resolved["status"] == "resolved":
        classifications.append({"resolved": resolved["record"]["fqn"]})

    definition = source_definition_for_annotation_metadata(unit, record, workspace)
    if definition is None:
        return classifications
    occurrence_key = tree_node_key(record["node"])
    is_definition_meta_annotation = any(
        tree_node_key(meta_record["node"]) == occurrence_key
        for meta_record in definition["meta_annotations"]
    )
    java_metadata = (
        resolve_known_annotation(
            unit, record["name_node"], {"Retention", "Target"},
            ("java.lang.annotation",),
        )
        if is_definition_meta_annotation else None
    )
    if (
        java_metadata is not None
        and len(state.custom_designators.get(definition["fqn"], [])) == 1
    ):
        classifications.append({
            "resolved": f"{java_metadata['namespace']}.{java_metadata['name']}"
        })
    return classifications


def classify_jaxrs_trigger(
    unit, record, target, workspace: JavaWorkspace, *, state: JaxRsState
) -> list[dict[str, str]]:
    """Classify JAX-RS request and Java WebSocket endpoint triggers.

    Source-defined record-component designators must also apply to methods
    because the represented endpoint handler is the implicit accessor.

    Example call:
        ``classify_jaxrs_trigger(unit, occurrence, target, workspace,
        state=state)`` returns ``[{"resolved": "app.PROBE",
        "family": "jax-rs"}]`` for a supported source-defined designator.
    """

    classifications = direct_final_trigger_classifications(
        unit, record, target, workspace, FINAL_TRIGGER_ANNOTATIONS
    )
    if not final_trigger_placement_supported("method-or-component", target):
        return classifications
    owner_info = target.get("owner_info")
    owner_name = owner_info.get("display_name", "") if owner_info else ""
    resolved = resolve_custom_designator(
        unit, record["name_node"], workspace, owner_name, state=state
    )
    component_applicable = (
        target["kind"] != "record-component"
        or source_annotation_use_is_method_applicable(
            unit, record, workspace, owner_name
        )
    )
    if component_applicable and resolved["status"] == "resolved":
        classifications.append({
            "resolved": resolved["record"]["fqn"],
            "family": METHOD_ANNOTATION_FAMILY_JAX_RS,
        })
    return classifications


__all__ = [
    "FINAL_TRIGGER_ANNOTATIONS",
    "SUPPORTED_ANNOTATIONS",
    "classify_jaxrs_annotation",
    "classify_jaxrs_trigger",
]
