"""Bounded source-only Spring MVC controller hierarchy analysis.

This pass consumes an already-built Java workspace and deliberately emits
additions only: direct mappings remain owned by
``analyze_direct_spring_mvc_unit`` while this module binds
mappings declared on source interfaces or abstract bases to one concrete,
genuinely activated controller implementation.

Logic guide: ``p6.logic/04-spring-mvc.md``.
"""

from __future__ import annotations

from typing import Any

from .diagnostics import format_endpoint_diagnostic, record as record_diagnostic
from .evidence import (
    method_annotation_evidence_from_mapping,
    represented_target_evidence,
)
from .java_frontend import (
    child_by_field,
    direct_annotation_records,
    parameter_list_source_text,
    resolve_known_annotation,
)
from .java_hierarchy import (
    JavaSourceHierarchyGraph,
    MAX_HIERARCHY_DEPTH,
    JavaMethodRecord,
    JavaTypeRecord,
    JavaTypeReference,
)
from .java_workspace import workspace_type_fqn_accessible
from .model import EndpointFact
from .paths import join_endpoint_paths
from .spring_mvc import (
    decode_builtin_spring_mapping,
    decode_spring_composed_mapping,
    union_request_method_conditions,
)


SPRING_CONTROLLER_PACKAGES = (
    "org.springframework.stereotype",
    "org.springframework.web.bind.annotation",
)


class SpringMvcHierarchyAnalyzer:
    """Bind Spring mapping contracts by source identity and erased signature.

    Application state:
        ``workspace`` supplies shared declarations, ``hierarchy_graph`` binds
        contract types to concrete controllers, and the two caches retain
        already-decoded method/type mappings during this one pass.

    Example value:
        ``SpringMvcHierarchyAnalyzer(workspace)`` can bind
        ``ItemsApi.list()`` to ``ItemsController.list()`` without reparsing
        either source file.
    """

    def __init__(self, workspace: dict[str, Any]):
        """Build the neutral hierarchy once and initialize mapping caches.

        Example call:
            ``SpringMvcHierarchyAnalyzer(workspace=java_workspace)``
            builds the neutral hierarchy once and initializes mapping caches.
        """

        self.workspace = workspace
        # The shared Java type/signature hierarchy model already
        # supplies the exact workspace identity, generic adaptation, hierarchy
        # bounds, and maximally-specific-interface machinery needed here.
        self.hierarchy_graph = JavaSourceHierarchyGraph(workspace)
        self._method_mapping_cache: dict[tuple[Any, ...], dict[str, Any] | None] = {}
        self._type_mapping_cache: dict[str, dict[str, Any] | None] = {}

    def _log(self, record: JavaTypeRecord, message: str) -> None:
        """Record a controller-scoped reason for suppressing hierarchy additions.

        Example call:
            ``analyzer._log(
                record=items_controller_type_record,
                message="ambiguous mapping contract",
            )``
            records a controller-scoped reason for suppressing hierarchy additions.
        """

        record_diagnostic(
            "Skipped Spring hierarchy in "
            f"{record.unit['source_path']} for {record.type_info['display_name']}: "
            f"{message}"
        )

    def _is_direct_mvc_controller(self, record: JavaTypeRecord) -> bool:
        """Recognize a concrete source controller root with genuine activation.

        Example call:
            ``analyzer._is_direct_mvc_controller(record=items_controller_type_record)``
            recognizes a concrete source controller root with genuine activation.
        """

        if (
            record.kind != "class_declaration"
            or record.type_info["abstract"]
            or not record.type_info["workspace_visible"]
        ):
            return False
        for annotation in direct_annotation_records(record.type_info["node"]):
            resolved = resolve_known_annotation(
                record.unit,
                annotation["name_node"],
                {"Controller", "RestController"},
                SPRING_CONTROLLER_PACKAGES,
            )
            if resolved is not None and (
                (resolved["name"] == "Controller"
                 and resolved["namespace"] == "org.springframework.stereotype")
                or (
                    resolved["name"] == "RestController"
                    and resolved["namespace"]
                    == "org.springframework.web.bind.annotation"
                )
            ):
                return True
        return False

    @staticmethod
    def _is_mapping_contract_type(record: JavaTypeRecord) -> bool:
        """Identify interface or abstract-class owners allowed to supply mappings.

        Example call:
            ``analyzer._is_mapping_contract_type(record=items_api_type_record)``
            identifies interface or abstract-class owners allowed to supply mappings.
        """

        return record.kind == "interface_declaration" or (
            record.kind == "class_declaration" and record.type_info["abstract"]
        )

    def _type_accessible(self, declaration: JavaTypeRecord, consumer: JavaTypeRecord) -> bool:
        """Prove that a controller can name a prospective contract type.

        Example call:
            ``analyzer._type_accessible(
                declaration=items_api_type_record,
                consumer=items_controller_type_record,
            )``
            proves that a controller can name a prospective contract type.
        """

        return workspace_type_fqn_accessible(
            self.workspace,
            consumer.unit,
            consumer.type_info["display_name"],
            declaration.fqn,
        )

    def _method_accessible(
        self, method: JavaMethodRecord, consumer: JavaTypeRecord
    ) -> bool:
        """Apply Java visibility rules before inheriting a mapping method.

        Example call:
            ``analyzer._method_accessible(
                method=items_api_list_method_record,
                consumer=items_controller_type_record,
            )``
            applies Java visibility rules before inheriting a mapping method.
        """

        if "private" in method.modifiers or "static" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return True
        if "public" in method.modifiers or "protected" in method.modifiers:
            return True
        return method.owner.unit["package"] == consumer.unit["package"]

    def _implementation_usable(self, method: JavaMethodRecord) -> bool:
        """Require a concrete instance implementation for endpoint attribution.

        Example call:
            ``analyzer._implementation_usable(method=controller_list_method_record)``
            requires a concrete instance implementation for endpoint attribution.
        """

        if (
            "private" in method.modifiers
            or "static" in method.modifiers
            or "abstract" in method.modifiers
        ):
            return False
        body = child_by_field(method.node, "body")
        if method.owner.kind == "interface_declaration":
            return "default" in method.modifiers and body is not None
        return body is not None

    def _decode_annotations(
        self,
        unit: dict[str, Any],
        annotations: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        lexical_owner: str,
        diagnostic_owner: str,
    ) -> dict[str, Any] | None:
        """Select the first recognized built-in or composed Spring mapping.

        Example call:
            ``analyzer._decode_annotations(
                unit=items_unit,
                annotations=mapping_annotations,
                lexical_owner="ItemsController",
                diagnostic_owner="ItemsController.list",
            )``
            selects the first recognized built-in or composed Spring mapping.
        """

        for annotation in sorted(
            annotations, key=lambda record: record["node"].start_byte
        ):
            mapping = decode_builtin_spring_mapping(
                unit,
                annotation["name_node"],
                annotation["node"],
                self.workspace,
                lexical_owner,
                diagnostic_owner,
            )
            if mapping is not None:
                return mapping
            mapping = decode_spring_composed_mapping(
                unit["source_path"],
                unit,
                annotation["name_node"],
                annotation["node"],
                lexical_owner,
                diagnostic_owner,
                self.workspace,
            )
            if mapping is not None:
                return mapping
        return None

    def _method_mapping(self, method: JavaMethodRecord) -> dict[str, Any] | None:
        """Decode and cache the mapping owned by one exact method identity.

        Example call:
            ``analyzer._method_mapping(method=items_api_list_method_record)``
            decodes and caches the mapping owned by one exact method identity.
        """

        if method.id not in self._method_mapping_cache:
            owner = method.owner.type_info["display_name"]
            self._method_mapping_cache[method.id] = self._decode_annotations(
                method.owner.unit,
                method.annotations,
                owner,
                f"{owner}.{method.name}",
            )
        return self._method_mapping_cache[method.id]

    def _type_mapping(self, record: JavaTypeRecord) -> dict[str, Any] | None:
        """Decode and cache the optional mapping layer on one type.

        Example call:
            ``analyzer._type_mapping(record=items_api_type_record)``
            decodes and caches the optional mapping layer on one type.
        """

        if record.fqn not in self._type_mapping_cache:
            owner = record.type_info["display_name"]
            self._type_mapping_cache[record.fqn] = self._decode_annotations(
                record.unit,
                direct_annotation_records(record.type_info["node"]),
                owner,
                owner,
            )
        return self._type_mapping_cache[record.fqn]

    def _interface_mapping_branches(
        self,
        state: tuple[JavaTypeRecord, dict[str, JavaTypeReference]],
        signature: tuple[str, tuple[str, ...]],
        consumer: JavaTypeRecord,
        depth: int = 0,
        active: frozenset[str] = frozenset(),
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] | None = None,
    ) -> tuple[
        set[tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]], bool
    ]:
        """Collect accessible interface mapping origins through a bounded graph.

        Example call:
            ``analyzer._interface_mapping_branches(
                state=(items_api_type_record, {}),
                signature=("list", ("java.lang.String",)),
                consumer=items_controller_type_record,
            )``
            collects accessible interface mapping origins through a bounded graph.
        """

        if memo is None:
            memo = {}
        record, env = state
        memo_key = (record.fqn, self.hierarchy_graph._type_environment_key(env), signature)
        if memo_key in memo:
            cached, invalid = memo[memo_key]
            return set(cached), invalid
        if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
            return set(), True
        if not self._type_accessible(record, consumer):
            return set(), True

        matches = self.hierarchy_graph._methods_for_signature(record, env, signature)
        if len(matches) > 1:
            return set(), True
        if matches:
            method = matches[0]
            mapping = self._method_mapping(method)
            if mapping is not None:
                if not self._method_accessible(method, consumer):
                    return set(), True
                result = ({(method.id, self.hierarchy_graph._type_environment_key(env))}, False)
                memo[memo_key] = result
                return set(result[0]), result[1]

        if not record.interfaces_valid:
            return set(), True
        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]
        ] = set()
        blocked = False
        for edge in record.interfaces:
            following = self.hierarchy_graph._resolve_inheritance_edge(edge, env)
            if following is None or following[0].kind != "interface_declaration":
                blocked = True
                continue
            found, invalid = self._interface_mapping_branches(
                following,
                signature,
                consumer,
                depth + 1,
                active | {record.fqn},
                memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        memo[memo_key] = (set(candidates), blocked)
        return candidates, blocked

    def _resolve_mapping_source(
        self,
        implementation: JavaMethodRecord,
        signature: tuple[str, tuple[str, ...]],
        hierarchy: Any,
        implementation_index: int | None,
        root: JavaTypeRecord,
    ) -> tuple[JavaMethodRecord, dict[str, JavaTypeReference]] | None:
        """Select the one contract declaration supplying an implementation's route.

        Example call:
            ``analyzer._resolve_mapping_source(
                implementation=controller_list_method_record,
                signature=("list", ("java.lang.String",)),
                hierarchy=items_controller_hierarchy,
                implementation_index=0,
                root=items_controller_type_record,
            )``
            selects the one contract declaration supplying an implementation's route.
        """

        direct = self._method_mapping(implementation)
        if direct is not None:
            if (
                implementation.owner is not root
                and self._is_mapping_contract_type(implementation.owner)
                and self._method_accessible(implementation, root)
            ):
                implementation_env = (
                    hierarchy.class_states[implementation_index][1]
                    if implementation_index is not None
                    else self.hierarchy_graph._default_type_environment(implementation.owner)
                )
                return implementation, implementation_env
            # A direct mapping on the concrete root is emitted by the direct
            # analyzer and suppresses the inherited declaration. Mappings on
            # an unsupported owner also fail closed instead of being
            # reinterpreted.
            return None

        start = (
            implementation_index + 1
            if implementation_index is not None
            else 0
        )
        for record, env in hierarchy.class_states[start:]:
            matches = self.hierarchy_graph._methods_for_signature(record, env, signature)
            if len(matches) > 1:
                return None
            if not matches:
                continue
            method = matches[0]
            mapping = self._method_mapping(method)
            if mapping is None:
                continue
            if (
                not self._is_mapping_contract_type(record)
                or not self._type_accessible(record, root)
                or not self._method_accessible(method, root)
            ):
                return None
            return method, env

        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]
        ] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self._interface_mapping_branches(
                interface_root, signature, root, memo=memo
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self.hierarchy_graph._select_maximally_specific_candidates(
            candidates
        )
        blocked = blocked or specificity_invalid
        if blocked or len({candidate[0] for candidate in candidates}) != 1:
            return None
        return self.hierarchy_graph._resolve_method_candidate(next(iter(candidates)))

    def _all_signatures(
        self, hierarchy: Any
    ) -> tuple[set[tuple[str, tuple[str, ...]]], set[str]]:
        """Collect erased signatures and names whose identity could not be proven.

        Example call:
            ``analyzer._all_signatures(hierarchy=items_controller_hierarchy)``
            collects erased signatures and names whose identity could not be proven.
        """

        signatures: set[tuple[str, tuple[str, ...]]] = set()
        unresolved_names: set[str] = set()

        def add_methods(record: JavaTypeRecord, env: dict[str, JavaTypeReference]) -> None:
            """Add one adapted type's method signatures to the root work set.

            Example call:
                ``add_methods(record=items_api_type_record, env=type_environment)``
                adds one adapted type's method signatures to the root work set.
            """

            for method in record.methods:
                signature = self.hierarchy_graph._erased_method_signature(method, env)
                if signature is None:
                    unresolved_names.add(method.name)
                else:
                    signatures.add(signature)

        for record, env in hierarchy.class_states:
            add_methods(record, env)

        visited: set[tuple[str, tuple[tuple[str, JavaTypeReference], ...]]] = set()

        def visit(
            state: tuple[JavaTypeRecord, dict[str, JavaTypeReference]], depth: int = 0
        ) -> None:
            """Traverse bounded interface states while avoiding repeated environments.

            Example call:
                ``visit(state=(items_api_type_record, {}))``
                traverses bounded interface states while avoiding repeated environments.
            """

            record, env = state
            state_key = (record.fqn, self.hierarchy_graph._type_environment_key(env))
            if state_key in visited or depth > MAX_HIERARCHY_DEPTH:
                return
            visited.add(state_key)
            add_methods(record, env)
            for edge in record.interfaces:
                following = self.hierarchy_graph._resolve_inheritance_edge(edge, env)
                if following is not None:
                    visit(following, depth + 1)

        for interface_root in hierarchy.interface_roots:
            visit(interface_root)
        return signatures, unresolved_names

    def _implementation(
        self,
        signature: tuple[str, tuple[str, ...]],
        hierarchy: Any,
    ) -> tuple[JavaMethodRecord, dict[str, JavaTypeReference], int | None] | None:
        """Bind one erased signature to its concrete class/default implementation.

        Example call:
            ``analyzer._implementation(
                signature=("list", ("java.lang.String",)),
                hierarchy=items_controller_hierarchy,
            )``
            binds one erased signature to its concrete class/default implementation.
        """

        for index, (record, env) in enumerate(hierarchy.class_states):
            matches = self.hierarchy_graph._methods_for_signature(record, env, signature)
            if not matches:
                continue
            if len(matches) != 1 or not self._implementation_usable(matches[0]):
                return None
            return matches[0], env, index

        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, JavaTypeReference], ...]]
        ] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self.hierarchy_graph._interface_branches(
                interface_root, signature,
                accept_method=self.hierarchy_graph._is_public_implementation,
                stop_at_declaration=True,
                memo=memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self.hierarchy_graph._select_maximally_specific_candidates(
            candidates
        )
        if blocked or specificity_invalid or len(
            {candidate[0] for candidate in candidates}
        ) != 1:
            return None
        resolved = self.hierarchy_graph._resolve_method_candidate(next(iter(candidates)))
        if resolved is None or not self._implementation_usable(resolved[0]):
            return None
        return resolved[0], resolved[1], None

    def _mapping_conditions(
        self, mapping: dict[str, Any] | None
    ) -> tuple[list[str], list[str]] | None:
        """Translate absent/valid/invalid mapping states into composition layers.

        Example call:
            ``analyzer._mapping_conditions(
                mapping={"paths": ("/items",), "methods": ("GET",), "valid": True},
            )``
            translates absent/valid/invalid mapping states into composition layers.
        """

        if mapping is None:
            return [""], []
        if not mapping["valid"]:
            return None
        return list(mapping["paths"]), list(mapping["methods"])

    def _controller_hierarchy_endpoints(
        self, root: JavaTypeRecord
    ) -> list[EndpointFact]:
        """Emit only contract-derived additions for one concrete controller root.

        Example call:
            ``analyzer._controller_hierarchy_endpoints(
                root=items_controller_type_record,
            )``
            emits only contract-derived additions for one concrete controller root.
        """

        root_env = self.hierarchy_graph._default_type_environment(root)
        hierarchy = self.hierarchy_graph._build_hierarchy_context(root, root_env)
        if not hierarchy.complete:
            self._log(root, "incomplete or ambiguous type hierarchy")
            return []

        controller_conditions = self._mapping_conditions(self._type_mapping(root))
        if controller_conditions is None:
            return []
        controller_paths, controller_methods = controller_conditions
        signatures, unresolved_names = self._all_signatures(hierarchy)
        endpoints: list[EndpointFact] = []

        for signature in sorted(signatures):
            if signature[0] in unresolved_names:
                continue
            implementation_state = self._implementation(signature, hierarchy)
            if implementation_state is None:
                continue
            implementation, _implementation_env, implementation_index = (
                implementation_state
            )
            source_state = self._resolve_mapping_source(
                implementation,
                signature,
                hierarchy,
                implementation_index,
                root,
            )
            if source_state is None:
                continue
            source, _source_env = source_state
            mapping = self._method_mapping(source)
            if mapping is None or not mapping["valid"]:
                continue
            contract_conditions = self._mapping_conditions(
                self._type_mapping(source.owner)
            )
            if contract_conditions is None:
                continue
            contract_paths, contract_methods = contract_conditions
            effective_methods = union_request_method_conditions(
                controller_methods, contract_methods
            )
            effective_methods = union_request_method_conditions(
                effective_methods, mapping["methods"]
            ) or ["ANY"]
            owner_name = (
                f"{implementation.owner.type_info['display_name']}."
                f"{implementation.name}"
            )
            parameters = parameter_list_source_text(
                implementation.owner.unit["source"],
                implementation.parameters_node,
            )
            for controller_path in controller_paths:
                for contract_path in contract_paths:
                    base_path = join_endpoint_paths(
                        controller_path, contract_path
                    )
                    for method_path in mapping["paths"]:
                        endpoint_path = join_endpoint_paths(
                            base_path, method_path
                        )
                        for http_method in effective_methods:
                            endpoint = EndpointFact(
                                path=endpoint_path,
                                method=http_method,
                                parameters=parameters,
                                source_file=implementation.owner.unit["source_path"],
                                source_line=implementation.node.start_point.row + 1,
                                handler_name=owner_name,
                                route_source_file=source.owner.unit["source_path"],
                                route_source_line=mapping[
                                    "annotation_node"
                                ].start_point.row
                                + 1,
                                handler_source_file=implementation.owner.unit[
                                    "source_path"
                                ],
                                handler_source_line=implementation.node.start_point.row
                                + 1,
                                project_source_file=root.unit["source_path"],
                                technology="spring",
                                protocol="http",
                                surface="server",
                                direction="inbound",
                                # Annotation evidence belongs to the handler only
                                # when handler and contract declaration are identical.
                                annotation_evidence=(
                                    method_annotation_evidence_from_mapping(
                                        mapping,
                                        annotation_source_file=source.owner.unit[
                                            "source_path"
                                        ],
                                        endpoint_source_file=implementation.owner.unit[
                                            "source_path"
                                        ],
                                    )
                                    if source.id == implementation.id
                                    else ()
                                ),
                                represented_targets=represented_target_evidence(
                                    implementation.owner.unit["source_path"],
                                    "method",
                                    implementation.node,
                                ),
                            )
                            endpoints.append(endpoint)
                            record_diagnostic(format_endpoint_diagnostic(endpoint))
        return endpoints

    def analyze(self) -> tuple[EndpointFact, ...]:
        """Run the additive hierarchy pass over deterministic controller roots.

        Example call:
            ``analyzer.analyze()``
            runs the additive hierarchy pass over deterministic controller roots.
        """

        endpoints: list[EndpointFact] = []
        for fqn in sorted(self.hierarchy_graph.types):
            record = self.hierarchy_graph.types[fqn]
            if self._is_direct_mvc_controller(record):
                endpoints.extend(self._controller_hierarchy_endpoints(record))
        return tuple(endpoints)


def analyze_spring_mvc_hierarchy(
    workspace: dict[str, Any],
) -> tuple[EndpointFact, ...]:
    """Return signature-bound Spring controller hierarchy additions.

    Example call:
        ``analyze_spring_mvc_hierarchy(workspace=java_workspace)``
        returns signature-bound Spring controller hierarchy additions.
    """

    return SpringMvcHierarchyAnalyzer(workspace).analyze()


__all__ = ["SpringMvcHierarchyAnalyzer", "analyze_spring_mvc_hierarchy"]
