"""Spring-owned annotation audit and final-trigger recognition.

The shared inventory walks source occurrences and assembles reports. This
module decides Spring annotation meaning through the same semantic decoders
used by endpoint analysis, including supported source definitions whose uses
may later fail to produce endpoints.

Logic guides: ``p6.logic/04-spring-mvc.md`` and
``p6.logic/07-output-evidence-reports.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType

from .contracts import (
    METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
    METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE,
    METHOD_ANNOTATION_FAMILY_SPRING_VERB,
    SPRING_ALIAS_FOR_PACKAGE,
    SPRING_MAPPING_METHODS,
    SPRING_MAPPING_PACKAGE,
)
from .inventory import (
    annotation_owner_name,
    direct_final_trigger_classifications,
    final_trigger_placement_supported,
    registered_annotation_classifications,
    source_definition_for_annotation_metadata,
)
from .java_frontend import resolve_known_annotation, tree_node_key
from .java_workspace import JavaWorkspace
from .spring_mvc import (
    source_annotation_definition,
    source_annotation_is_method_applicable,
    spring_composed_definition_is_supported,
)


@dataclass(slots=True)
class SpringAnnotationState:
    """One run's cache of validated Spring source-annotation definitions.

    Example value:
        ``SpringAnnotationState({"app.Read": True})`` remembers that the
        definition of ``app.Read`` has supported Spring mapping semantics.
    """

    # Cache keyed by exact source annotation identity, shared by both inventories.
    definition_support: dict[str, bool] = field(default_factory=dict)


def build_spring_annotation_state(_workspace: JavaWorkspace) -> SpringAnnotationState:
    """Create the selected family's empty annotation-validation cache.

    Example call:
        ``build_spring_annotation_state(workspace)`` returns a fresh
        ``SpringAnnotationState`` without changing neutral Java indexes.
    """

    return SpringAnnotationState()


# The broad audit includes route triggers plus activation and binding metadata,
# even when an endpoint is rejected or never considered by an analyzer.
SUPPORTED_ANNOTATIONS = (
    {
        "packages": (SPRING_MAPPING_PACKAGE,),
        "names": frozenset(SPRING_MAPPING_METHODS),
        "role": "mvc-mapping",
    },
    {
        "packages": ("org.springframework.stereotype",),
        "names": frozenset({"Controller"}),
        "role": "controller-activation",
    },
    {
        "packages": (SPRING_MAPPING_PACKAGE,),
        "names": frozenset({"RestController"}),
        "role": "controller-activation",
    },
    {
        "packages": ("org.springframework.context.annotation",),
        "names": frozenset({"Bean", "Configuration"}),
        "role": "programmatic-route-activation",
    },
    {
        "packages": ("org.springframework.beans.factory.annotation",),
        "names": frozenset({"Autowired"}),
        "role": "programmatic-route-activation",
    },
    {
        "packages": ("org.springframework.web.service.annotation",),
        "names": frozenset(
            {
                "HttpExchange",
                "GetExchange",
                "PostExchange",
                "PutExchange",
                "DeleteExchange",
                "PatchExchange",
            }
        ),
        "role": "http-client-mapping",
    },
    {
        "packages": ("org.springframework.cloud.openfeign",),
        "names": frozenset({"FeignClient"}),
        "role": "feign-client-activation",
    },
    {
        "packages": ("org.springframework.messaging.handler.annotation",),
        "names": frozenset({"MessageMapping", "SubscribeMapping"}),
        "role": "message-mapping",
    },
)


# Final triggers include only annotations at supported endpoint declarations;
# exact represented-target evidence later subtracts them from absence reports.
FINAL_TRIGGER_ANNOTATIONS = (
    {
        "packages": (SPRING_MAPPING_PACKAGE,),
        "names": frozenset(SPRING_MAPPING_METHODS),
        "placement": "method-or-component",
        "family_by_name": MappingProxyType(
            {
                name: (
                    METHOD_ANNOTATION_FAMILY_SPRING_GENERIC
                    if name == "RequestMapping"
                    else METHOD_ANNOTATION_FAMILY_SPRING_VERB
                )
                for name in SPRING_MAPPING_METHODS
            }
        ),
    },
    {
        "packages": ("org.springframework.web.service.annotation",),
        "names": frozenset(
            {
                "HttpExchange",
                "GetExchange",
                "PostExchange",
                "PutExchange",
                "DeleteExchange",
                "PatchExchange",
            }
        ),
        "placement": "interface-method",
        "family_by_name": MappingProxyType(
            {
                name: (
                    METHOD_ANNOTATION_FAMILY_SPRING_GENERIC
                    if name == "HttpExchange"
                    else METHOD_ANNOTATION_FAMILY_SPRING_VERB
                )
                for name in (
                    "HttpExchange",
                    "GetExchange",
                    "PostExchange",
                    "PutExchange",
                    "DeleteExchange",
                    "PatchExchange",
                )
            }
        ),
    },
    {
        "packages": (
            "org.springframework.messaging.handler.annotation",
        ),
        "names": frozenset({"MessageMapping", "SubscribeMapping"}),
        "placement": "concrete-method",
        "family_by_name": MappingProxyType(
            {
                "MessageMapping": METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE,
                "SubscribeMapping": METHOD_ANNOTATION_FAMILY_SPRING_MESSAGE,
            }
        ),
    },
)


def classify_spring_annotation(
    unit, record, workspace: JavaWorkspace, *, state: SpringAnnotationState
) -> list[dict[str, str]]:
    """Classify built-in, composed, and contextual Spring audit annotations.

    ``Retention``/``Target`` and ``AliasFor`` are interesting only on a
    validated source-defined route annotation; identical metadata elsewhere
    stays outside the framework audit. A valid definition remains auditable
    even when a particular use's placement or argument values emit no endpoint.

    Example call:
        ``classify_spring_annotation(unit, occurrence, workspace, state=state)``
        returns ``[{"resolved": "app.Read"}]`` for a supported composed
        mapping, or an empty list when its meaning cannot be proven.
    """

    classifications = registered_annotation_classifications(
        unit, record, workspace, SUPPORTED_ANNOTATIONS
    )
    resolved = source_annotation_definition(
        unit, record["name_node"], workspace,
        annotation_owner_name(unit, record["node"]),
    )
    if (
        resolved["status"] == "resolved"
        and spring_composed_definition_is_supported(
            resolved["definition"], workspace, cache=state.definition_support
        )
    ):
        classifications.append({"resolved": resolved["definition"]["fqn"]})

    definition = source_definition_for_annotation_metadata(unit, record, workspace)
    if definition is None:
        return classifications
    occurrence_key = tree_node_key(record["node"])
    is_definition_meta_annotation = any(
        tree_node_key(meta_record["node"]) == occurrence_key
        for meta_record in definition["meta_annotations"]
    )
    is_definition_element_annotation = any(
        tree_node_key(annotation["node"]) == occurrence_key
        for elements in definition["elements"].values()
        for element in elements
        for annotation in element["annotations"]
    )
    java_metadata = (
        resolve_known_annotation(
            unit, record["name_node"], {"Retention", "Target"},
            ("java.lang.annotation",),
        )
        if is_definition_meta_annotation else None
    )
    spring_alias = (
        resolve_known_annotation(
            unit, record["name_node"], {"AliasFor"}, (SPRING_ALIAS_FOR_PACKAGE,),
        )
        if is_definition_element_annotation else None
    )
    if (
        (java_metadata is not None or spring_alias is not None)
        and spring_composed_definition_is_supported(
            definition, workspace, cache=state.definition_support
        )
    ):
        resolved = java_metadata or spring_alias
        classifications.append({"resolved": f"{resolved['namespace']}.{resolved['name']}"})
    return classifications


def classify_spring_trigger(
    unit, record, target, workspace: JavaWorkspace, *, state: SpringAnnotationState
) -> list[dict[str, str]]:
    """Classify Spring endpoint triggers at supported declaration placements.

    Source-defined component annotations additionally require method
    applicability, since their route evidence represents an implicit accessor.
    Unsupported or ambiguous identities produce no trigger candidate.

    Example call:
        ``classify_spring_trigger(unit, occurrence, target, workspace,
        state=state)`` returns ``[{"resolved": "app.Read",
        "family": "spring-composed-mvc"}]`` for a supported composed mapping.
    """

    classifications = direct_final_trigger_classifications(
        unit, record, target, workspace, FINAL_TRIGGER_ANNOTATIONS
    )
    if not final_trigger_placement_supported("method-or-component", target):
        return classifications
    owner_info = target.get("owner_info")
    owner_name = owner_info.get("display_name", "") if owner_info else ""
    resolved = source_annotation_definition(
        unit, record["name_node"], workspace, owner_name
    )
    component_applicable = (
        target["kind"] != "record-component"
        or source_annotation_is_method_applicable(unit, record, workspace, owner_name)
    )
    if (
        component_applicable
        and resolved["status"] == "resolved"
        and spring_composed_definition_is_supported(
            resolved["definition"], workspace, cache=state.definition_support
        )
    ):
        classifications.append({
            "resolved": resolved["definition"]["fqn"],
            "family": "spring-composed-mvc",
        })
    return classifications


__all__ = [
    "FINAL_TRIGGER_ANNOTATIONS",
    "SUPPORTED_ANNOTATIONS",
    "SpringAnnotationState",
    "build_spring_annotation_state",
    "classify_spring_annotation",
    "classify_spring_trigger",
]
