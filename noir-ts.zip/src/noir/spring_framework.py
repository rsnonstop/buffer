"""Spring-family setup and ordered endpoint orchestration.

This facade is the only framework-level owner of the complete Spring pass
sequence.  Individual Spring modules keep their focused semantic work, while
the application pipeline can treat the family as one configured analyzer.
The facade depends only on Spring modules and framework-neutral application
values; it has no JAX-RS knowledge.

Logic guides: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/05-spring-additional-surfaces.md``.
"""

from __future__ import annotations

from .java_workspace import JavaWorkspace
from .spring_annotations import SpringAnnotationState
from .model import AnalysisRequest, EndpointFact
from .spring_clients import analyze_spring_http_clients
from .spring_config import (
    analyze_spring_resource_handlers,
    apply_spring_path_configuration,
    build_spring_path_configuration,
)
from .spring_gateway import analyze_spring_gateway
from .spring_mvc import analyze_direct_spring_mvc_unit
from .spring_mvc_hierarchy import analyze_spring_mvc_hierarchy
from .spring_route_registrations import analyze_spring_route_registrations
from .spring_websocket_messaging import analyze_spring_websocket_and_messaging


def analyze_spring_framework(
    request: AnalysisRequest,
    source_paths: tuple[str, ...],
    workspace: JavaWorkspace,
    state: SpringAnnotationState,
) -> tuple[EndpointFact, ...]:
    """Run the complete Spring analyzer family in its established order.

    Annotation recognition owns the supplied Spring state; endpoint passes
    consume the neutral Java facts independently. Project configuration loads
    here before clients and messaging, so no separate preparation hook is needed.

    Direct MVC analysis visits the ordered source snapshot first.  When the
    workspace contains units, the project-wide route, hierarchy, Gateway,
    resource, client, and messaging passes follow exactly once. Clients resolve
    their lexical paths before returning ordinary facts; project paths apply
    once to the remaining server and messaging batches at the end.

    Example call:
        ``analyze_spring_framework(request, source_snapshot.paths,
        java_workspace, spring_state)`` returns Spring ``EndpointFact`` values after every
        selected Spring pass and project path layer has been applied.
    """

    endpoints: list[EndpointFact] = []
    units = workspace.get("compilation_units", {})
    for source_path in source_paths:
        unit = units.get(source_path)
        if unit is not None:
            endpoints.extend(analyze_direct_spring_mvc_unit(unit, workspace))
    if not units:
        return ()

    endpoints.extend(analyze_spring_route_registrations(workspace))
    endpoints.extend(analyze_spring_mvc_hierarchy(workspace))
    endpoints.extend(analyze_spring_gateway(workspace))
    endpoints.extend(analyze_spring_resource_handlers(workspace))
    configuration = build_spring_path_configuration(
        workspace,
        str(request.analysis_root),
    )
    clients = analyze_spring_http_clients(workspace, configuration)
    messaging = analyze_spring_websocket_and_messaging(workspace, configuration)
    # Keep the established server/client/messaging result order while leaving
    # already-configured clients out of the final project-path application.
    return (
        *apply_spring_path_configuration(endpoints, configuration),
        *clients,
        *apply_spring_path_configuration(messaging, configuration),
    )


__all__ = [
    "analyze_spring_framework",
]
