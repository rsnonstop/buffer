"""One-way orchestration from Java sources to typed endpoint facts.

Logic guide: ``p6.logic/02-cli-and-orchestration.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import partial
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from . import frameworks
from .diagnostics import record
from .discovery import discover_java_files, scan_framework_markers
from .inventory import (
    build_annotation_audit_inventory,
    build_final_trigger_inventory,
)
from .java_workspace import JavaWorkspace, build_java_workspace
from .model import (
    AnalysisRequest,
    AnalysisResult,
    EndpointFact,
    FrameworkPlan,
    FrameworkSelection,
)
from .tree_sitter_runtime import (
    build_workspace_runtime,
    require_tree_sitter,
    run_query_matches,
)


@dataclass(frozen=True, slots=True)
class SourceSnapshot:
    """The deterministic paths and exact bytes shared by every analysis pass."""

    # Deterministic source-file order used by every per-file analyzer pass.
    paths: tuple[str, ...]
    # Exact bytes read once for each path; later stages do not reread Java files.
    content: Mapping[str, bytes]

    # Example value:
    # SourceSnapshot(("/workspace/app/ItemsController.java",),
    #                {"/workspace/app/ItemsController.java": b"class ItemsController {}"})

    def __post_init__(self) -> None:
        """Detach the source snapshot and enforce exact path/content agreement.

        Example call:
            Constructing ``SourceSnapshot(("/workspace/app/Items.java",),
            {"/workspace/app/Items.java": b"class Items {}"})`` freezes the
            content mapping; a missing or extra content key raises ``ValueError``.
        """

        paths = tuple(self.paths)
        content = dict(self.content)
        if len(paths) != len(content) or set(paths) != set(content):
            raise ValueError("source paths and content must match exactly")
        object.__setattr__(self, "paths", paths)
        object.__setattr__(self, "content", MappingProxyType(content))


@dataclass(frozen=True, slots=True)
class FrameworkDecision:
    """The selected analyzers plus marker evidence and stdout announcements."""

    # Requested policy and effective ordered analyzer families for this run.
    plan: FrameworkPlan
    # Raw marker occurrences explaining an automatic framework selection.
    detections: tuple[Any, ...] = ()
    # Stable user-facing messages that the CLI prints after analysis.
    announcements: tuple[str, ...] = ()

    # Example value:
    # FrameworkDecision(spring_plan, (("SpringBoot", "pom.xml"),),
    #                   ("Found SpringBoot Annotation",))


def _snapshot_sources(root: Path) -> SourceSnapshot:
    """Discover application Java files and read one stable source snapshot.

    Example call:
        ``_snapshot_sources(Path("/workspace/shop"))`` returns ordered paths
        such as ``("/workspace/shop/src/ItemsController.java",)`` and the exact
        bytes read once for each path.
    """

    paths = tuple(discover_java_files(root))
    return SourceSnapshot(paths, {path: Path(path).read_bytes() for path in paths})


def _select_frameworks(
    request: AnalysisRequest,
    sources: SourceSnapshot,
) -> FrameworkDecision:
    """Choose the ordered framework analyzers for one application request.

    Example call:
        ``_select_frameworks(AnalysisRequest(Path("/workspace/shop"),
        framework_mode="auto"), sources)`` may return a decision selecting
        Spring when the snapshot/project files contain a Spring Boot marker,
        together with its user-facing announcement.
    """

    if request.framework_mode != "auto":
        if request.framework_mode is None:
            plan = FrameworkPlan(
                None,
                frameworks.default_framework_selections(),
            )
        else:
            requested = (
                request.framework_mode
                if isinstance(request.framework_mode, tuple)
                else (request.framework_mode,)
            )
            requested_plan = FrameworkPlan(
                request.framework_mode,
                tuple(FrameworkSelection(item) for item in requested),
            )
            selected_adapters = frameworks.adapters_for_plan(requested_plan)
            plan = FrameworkPlan(
                request.framework_mode,
                tuple(adapter.selection for adapter in selected_adapters),
            )
        return FrameworkDecision(
            plan,
            announcements=tuple(
                adapter.announcement
                for adapter in frameworks.adapters_for_plan(plan)
            ),
        )

    detection = scan_framework_markers(request.analysis_root, sources.content)
    occurrences = tuple(detection["occurrences"])
    for finding_name, relative_path in occurrences:
        record(f"Detected {finding_name} in {relative_path}")
    detected = {
        FrameworkSelection(item) for item in detection["selected_frameworks"]
    }
    registered = {
        adapter.selection for adapter in frameworks.FRAMEWORK_ADAPTERS
    }
    if unregistered := detected - registered:
        names = ", ".join(sorted(item.value for item in unregistered))
        raise ValueError(
            f"framework detection selected unregistered adapters: {names}"
        )
    selected = tuple(
        adapter.selection
        for adapter in frameworks.FRAMEWORK_ADAPTERS
        if adapter.selection in detected
    )
    announcements = tuple(
        f"Found {finding['finding_name']}"
        + (f" {finding['report_hint']}" if finding["report_hint"] else "")
        for finding in detection["findings"]
    )
    return FrameworkDecision(
        FrameworkPlan("auto", selected),
        detections=occurrences,
        announcements=announcements,
    )


def _build_workspace(sources: SourceSnapshot) -> JavaWorkspace:
    """Build the shared Java facts without adding framework-owned state.

    Example call:
        ``_build_workspace(sources)`` returns parsed units, source annotations,
        and Java identity/constant indexes reusable by every selected family.
    """

    runtime = build_workspace_runtime()
    return build_java_workspace(
        sources.content,
        runtime,
        match_query=run_query_matches,
    )


def run_analysis(request: AnalysisRequest) -> AnalysisResult:
    """Run the complete source-to-endpoint application analysis pipeline.

    Example call:
        ``run_analysis(AnalysisRequest(Path("/workspace/shop"),
        framework_mode="spring"))`` returns an ``AnalysisResult`` containing
        Spring endpoint facts, the effective framework plan, annotation and
        trigger inventories, detections, and CLI announcements.
    """

    require_tree_sitter()
    sources = _snapshot_sources(request.analysis_root)
    decision = _select_frameworks(request, sources)
    selected_adapters = frameworks.adapters_for_plan(decision.plan)
    workspace = _build_workspace(sources)
    # Each selected family owns its state for exactly this invocation. The
    # paired sequence preserves registry order without a shared state lookup.
    configured = tuple(
        (adapter, adapter.create_state(workspace) if adapter.create_state else None)
        for adapter in selected_adapters
    )
    root = str(request.analysis_root)
    annotation_inventory = build_annotation_audit_inventory(
        workspace,
        root,
        tuple(
            (adapter.name, partial(adapter.classify_annotation, state=state)
             if adapter.classify_annotation else None)
            for adapter, state in configured
        ),
    )
    trigger_inventory = (
        build_final_trigger_inventory(
            workspace,
            root,
            tuple(
                (adapter.name, partial(adapter.classify_trigger, state=state)
                 if adapter.classify_trigger else None)
                for adapter, state in configured
            ),
        ) if configured else ()
    )

    # Complete project preparation for every selected family before the first
    # analyzer runs; no analyzer can observe a selected family as unprepared.
    for adapter, state in configured:
        if adapter.prepare_analysis is not None:
            adapter.prepare_analysis(request, workspace, state)

    endpoints: list[EndpointFact] = []
    for adapter, state in configured:
        endpoints.extend(adapter.analyze(request, sources.paths, workspace, state))
    if not all(isinstance(endpoint, EndpointFact) for endpoint in endpoints):
        raise TypeError("analyzers must return EndpointFact values")

    return AnalysisResult(
        endpoints=tuple(endpoints),
        framework_plan=decision.plan,
        annotation_audit_inventory=tuple(annotation_inventory),
        final_trigger_inventory=tuple(trigger_inventory),
        detections=decision.detections,
        announcements=decision.announcements,
    )


__all__ = ["FrameworkDecision", "SourceSnapshot", "run_analysis"]
