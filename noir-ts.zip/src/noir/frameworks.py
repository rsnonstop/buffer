"""Static framework composition records used by the analysis pipeline.

The registry is deliberately explicit: adding a shipped framework means adding
one family facade and one visible entry here.  It provides deterministic order
without dynamic discovery, framework-to-framework imports, or a service
container.

Logic guides: ``p6.logic/02-cli-and-orchestration.md`` and
``p6.logic/16-adding-framework-support.md``.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, TypeAlias

from .java_workspace import JavaWorkspace
from .jaxrs import build_jaxrs_state
from .jaxrs_annotations import classify_jaxrs_annotation, classify_jaxrs_trigger
from .jaxrs_framework import analyze_jaxrs_framework, prepare_jaxrs_analysis
from .model import AnalysisRequest, EndpointFact, FrameworkPlan, FrameworkSelection
from .spring_annotations import (
    build_spring_annotation_state,
    classify_spring_annotation,
    classify_spring_trigger,
)
from .spring_framework import analyze_spring_framework
from .wicket_framework import analyze_wicket_framework


# The static registry combines different family state types. Concrete hooks
# name their own state record; only this heterogeneous composition edge uses
# Any. State is passed explicitly and never stored in the shared Java facts.
CreateState: TypeAlias = Callable[[JavaWorkspace], Any]
PrepareAnalysis: TypeAlias = Callable[[AnalysisRequest, JavaWorkspace, Any], None]
AnalyzeFramework: TypeAlias = Callable[
    [AnalysisRequest, tuple[str, ...], JavaWorkspace, Any],
    tuple[EndpointFact, ...],
]
# Classification hooks have a keyword-only state argument, visible in each
# family signature. The pipeline binds it before inventory receives the hook.
ClassifyAnnotation: TypeAlias = Callable[..., list[dict[str, str]]]


@dataclass(frozen=True, slots=True)
class FrameworkAdapter:
    """One framework family's complete composition-root contract.

    Every registered adapter has one public normalized selection identity.
    Only selected adapters create state, recognize annotations, prepare, and
    analyze. A family without state or annotation semantics leaves those hooks
    absent. Default and auto selection remain separate policy decisions.

    Example value:
        ``FrameworkAdapter("wicket", FrameworkSelection.WICKET,
        "Found Apache Wicket", False, analyze_wicket_framework)`` describes
        the selectable but non-default Wicket integration stub.
    """

    # Stable internal/report-section name, normally equal to the public token.
    name: str
    # Public normalized analyzer identity for this executable family.
    selection: FrameworkSelection
    # Announcement for a non-auto selection, including omitted/default mode.
    announcement: str
    # Whether omitted ``--framework`` includes this adapter.
    default_selected: bool
    # Family-owned endpoint orchestration; every registered adapter supplies it.
    analyze: AnalyzeFramework
    # Create this selected family's private indexes/cache from shared Java facts.
    create_state: CreateState | None = None
    # Optional project preparation after inventories, using this family's state.
    prepare_analysis: PrepareAnalysis | None = None
    # Recognize broad annotation meanings; inventory adds source/report identity.
    classify_annotation: ClassifyAnnotation | None = None
    # Recognize potential endpoint triggers even when analysis rejects a route.
    classify_trigger: ClassifyAnnotation | None = None

    def __post_init__(self) -> None:
        """Normalize the identity and reject an unusable adapter record.

        Example call:
            Constructing an adapter with ``selection=None`` raises
            ``ValueError`` instead of creating an unreachable registry row.
        """

        if (
            not isinstance(self.name, str)
            or not self.name
            or self.name.strip() != self.name
        ):
            raise ValueError("framework adapter name must be a non-empty stable token")
        try:
            selection = FrameworkSelection(self.selection)
        except (TypeError, ValueError) as error:
            raise ValueError(
                "framework adapter requires a valid selection identity"
            ) from error
        object.__setattr__(self, "selection", selection)
        if not isinstance(self.announcement, str) or not self.announcement:
            raise ValueError("framework adapter announcement must be non-empty")
        if not callable(self.analyze):
            raise TypeError("framework adapter analyze hook must be callable")
        for name in (
            "create_state", "prepare_analysis", "classify_annotation", "classify_trigger"
        ):
            hook = getattr(self, name)
            if hook is not None and not callable(hook):
                raise TypeError(f"framework adapter {name} hook must be callable")


def _validated_adapters(
    adapters: tuple[FrameworkAdapter, ...],
) -> tuple[FrameworkAdapter, ...]:
    """Reject duplicate registry identities while preserving tuple order.

    Example call:
        ``_validated_adapters((spring_adapter, jaxrs_adapter))`` returns that
        same ordered tuple when their names and selection identities are unique.
    """

    if not all(isinstance(adapter, FrameworkAdapter) for adapter in adapters):
        raise TypeError("framework registry must contain FrameworkAdapter values")
    names = tuple(adapter.name for adapter in adapters)
    if len(set(names)) != len(names):
        raise ValueError("framework adapter names must be unique")
    selections = tuple(adapter.selection for adapter in adapters)
    if len(set(selections)) != len(selections):
        raise ValueError("framework adapter selection identities must be unique")
    return adapters


# This tuple is the sole execution/default order.  The separate marker registry
# in ``noir.discovery`` continues to own raw detector and auto-announcement order.
FRAMEWORK_ADAPTERS = _validated_adapters(
    (
        FrameworkAdapter(
            name="spring",
            selection=FrameworkSelection.SPRING,
            announcement="Found SpringBoot Annotation",
            default_selected=True,
            create_state=build_spring_annotation_state,
            classify_annotation=classify_spring_annotation,
            classify_trigger=classify_spring_trigger,
            analyze=analyze_spring_framework,
        ),
        FrameworkAdapter(
            name="jaxrx",
            selection=FrameworkSelection.JAX_RS,
            announcement="Found JaxRS",
            default_selected=True,
            create_state=build_jaxrs_state,
            prepare_analysis=prepare_jaxrs_analysis,
            classify_annotation=classify_jaxrs_annotation,
            classify_trigger=classify_jaxrs_trigger,
            analyze=analyze_jaxrs_framework,
        ),
        FrameworkAdapter(
            name="wicket",
            selection=FrameworkSelection.WICKET,
            announcement="Found Apache Wicket",
            default_selected=False,
            analyze=analyze_wicket_framework,
        ),
    )
)


def default_framework_selections() -> tuple[FrameworkSelection, ...]:
    """Return default analyzer identities in execution-registry order.

    Example call:
        ``default_framework_selections()`` returns ``(SPRING, JAX_RS)`` and
        excludes the explicitly selectable, non-default Wicket stub.
    """

    return tuple(
        adapter.selection
        for adapter in FRAMEWORK_ADAPTERS
        if adapter.default_selected
    )


def adapters_for_plan(plan: FrameworkPlan) -> tuple[FrameworkAdapter, ...]:
    """Map a framework plan to adapters in authoritative registry order.

    A plan cannot silently select a family missing from the registry.  Its own
    tuple order is not execution order; this registry supplies that order.

    Example call:
        ``adapters_for_plan(FrameworkPlan("jaxrx", (JAX_RS,)))`` returns only
        the JAX-RS adapter, while an empty auto plan returns ``()``.
    """

    if not isinstance(plan, FrameworkPlan):
        raise TypeError("framework adapter lookup requires a FrameworkPlan")
    selected = set(plan.selected)
    adapters = tuple(
        adapter
        for adapter in FRAMEWORK_ADAPTERS
        if adapter.selection in selected
    )
    mapped = {adapter.selection for adapter in adapters}
    if mapped != selected:
        missing = ", ".join(sorted(item.value for item in selected - mapped))
        raise ValueError(f"framework plan contains unregistered selections: {missing}")
    return adapters


__all__ = [
    "FRAMEWORK_ADAPTERS",
    "FrameworkAdapter",
    "adapters_for_plan",
    "default_framework_selections",
]
