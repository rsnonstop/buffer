# 06 — JAX-RS and Java WebSocket logic

[← Additional Spring surfaces](05-spring-additional-surfaces.md) · [Index](README.md) · [Next: Output and evidence →](07-output-evidence-reports.md)

The CLI token for this branch is `jaxrx`. It produces two distinct inbound
families from one parse-once Java workspace:

1. JAX-RS HTTP resources, including hierarchy-derived methods and subresources.
2. Java WebSocket handshake routes declared by `@ServerEndpoint`.

All producers return immutable [`EndpointFact`](../src/noir/model.py) values.

Method-level companion:
[14 — JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) follows
direct resources, deployment selection, hierarchy binding, subresource
recursion, and WebSocket fact construction.

## 1. Ownership and execution order

| Owner | Entry point | Responsibility |
|---|---|---|
| [`noir.pipeline`](../src/noir/pipeline.py) | `run_analysis()` | Creates selected family state, builds inventories, prepares, and runs selected adapters. |
| [`noir.frameworks`](../src/noir/frameworks.py) | `FRAMEWORK_ADAPTERS` | Binds the `jaxrx` selection to its independent facade in deterministic order. |
| [`noir.jaxrs_framework`](../src/noir/jaxrs_framework.py) | `prepare_jaxrs_analysis()` / `analyze_jaxrs_framework()` | Prepares private JAX-RS state and owns direct/hierarchy/WebSocket order. |
| [`noir.java_frontend`](../src/noir/java_frontend.py) | `build_java_compilation_unit()` | Parses one source snapshot and records syntax/query facts. |
| [`noir.java_workspace`](../src/noir/java_workspace.py) | `build_java_workspace()` | Builds neutral type, member, annotation, and constant indexes. |
| [`noir.jaxrs`](../src/noir/jaxrs.py) | `JaxRsState` / `build_jaxrs_state()` / `analyze_direct_jax_rs_unit()` | Keeps designator/application meanings outside Java facts; analyzes direct resources. |
| [`noir.jaxrs_annotations`](../src/noir/jaxrs_annotations.py) | `classify_jaxrs_annotation()` / `classify_jaxrs_trigger()` | Owns broad and trigger annotation meanings using explicit JAX-RS state; shared inventory owns source traversal and reporting. |
| [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) | `build_jax_rs_deployment_model()` / `select_jax_rs_deployment_prefix()` | Combines source applications with bounded `web.xml` evidence. |
| [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) | `JavaSourceHierarchyGraph` | Owns neutral hierarchy, generic adaptation, and erased signatures. |
| [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) | `analyze_jax_rs_hierarchy_and_subresources()` | Resolves annotation bundles, implementations, and locator traversal. |
| [`noir.java_websocket`](../src/noir/java_websocket.py) | `analyze_java_websocket_endpoints()` | Extracts Javax/Jakarta WebSocket handshakes. |

```mermaid
sequenceDiagram
    participant P as run_analysis
    participant F as jaxrs_framework facade
    participant W as shared Java workspace
    participant X as JaxRsState
    participant I as inventories
    participant D as deployment model
    participant J as direct JAX-RS
    participant H as hierarchy/subresources
    participant S as Java WebSocket

    P->>W: parse every source once
    P->>X: build_jaxrs_state(workspace) for selected JAX-RS
    P->>I: classify using selected callbacks bound to state
    P->>F: prepare_jaxrs_analysis(request, workspace, state)
    F->>D: combine state.applications and web.xml evidence
    F->>X: set state.deployment_model
    loop each compilation unit
        F->>J: analyze_direct_jax_rs_unit(unit, workspace, state=state)
    end
    F->>H: add inherited and locator-reached facts using state
    F->>S: add ServerEndpoint facts
    F-->>P: ordered EndpointFact tuple
    P-->>P: return typed AnalysisResult
```

When both framework branches run, they share the neutral Java workspace;
JAX-RS alone consumes its deployment state. The pipeline completes every
selected family's preparation before analysis, then Spring endpoint passes
precede JAX endpoint passes. Neither family imports the other or reparses source.

`build_jaxrs_state(workspace)` returns a fresh `JaxRsState`. Its indexes are
family interpretation, so the neutral `JavaWorkspace` gains no JAX-RS keys.
Only selected JAX-RS analysis creates this state; no disabled-family cleanup
is required. The state fields are:

| State field | Value shape | Meaning |
|---|---|---|
| `state.custom_designator_candidates` | set of annotation FQNs, for example `{"app.Fast"}` | relevant source annotation identities, including invalid candidates |
| `state.custom_designators` | annotation FQN → list of `{namespace, method, source_path, ...}` records | proven custom request-method designators |
| `state.applications` | list of `{namespace, package, path, fqn, ...}` records | source `@ApplicationPath` evidence, including `path=None` uncertainty |
| `state.deployment_model` | application key `(project root, package, family-or-None)` → prefix, plus source-class and explicit-descriptor lookup views | project/application deployment keys after source and descriptor evidence merge |

Remembering invalid designator candidates is intentional: using a relevant but
invalid annotation must poison method selection rather than look unrelated.
Concrete dictionary values for every neutral and JAX-specific index are in
[Workspace and index vocabulary](11-naming-and-code-vocabulary.md#workspace-and-index-vocabulary).

## 2. Route equations

For a direct root method:

```text
deployment prefix + root @Path + method @Path = endpoint path
```

For an inherited method or subresource leaf:

```text
deployment prefix
+ root @Path
+ selected interface contract @Path layers
+ locator @Path segments
+ leaf @Path
= endpoint path
```

Every included segment must resolve statically. A request method comes from
exactly one valid standard or custom designator. Partial paths are never
emitted.

## 3. Javax/Jakarta family proof

JAX-RS support is symmetric for `jakarta.ws.rs` and `javax.ws.rs`, with core
types in the matching `.core` package.

| Evidence | Family rule |
|---|---|
| root `@Path` | establishes the resource family |
| standard designator | must match the root |
| custom designator | its genuine `@HttpMethod` establishes a matching family |
| method `@Path` | must match the root |
| `@ApplicationPath` | must match the directly extended core `Application` |
| hierarchy annotation bundle | every recognized supported JAX annotation must share one family |
| `@ServerEndpoint` | independent `jakarta.websocket` or `javax.websocket` family |

Resolution is import- and source-aware. Local types, exact/wildcard collisions,
inaccessible declarations, mixed families, and duplicate fully qualified
source identities fail closed.

## 4. Custom request-method designators

[`index_jax_rs_custom_designators`](../src/noir/jaxrs.py) validates source
annotation declarations before any use is resolved. A valid declaration has:

1. exactly one genuine Javax/Jakarta `@HttpMethod`;
2. exactly one genuine `java.lang.annotation.Retention`;
3. `RetentionPolicy.RUNTIME` resolved through Java name/static-member rules;
4. a statically resolved String token;
5. a token no longer than 128 characters; and
6. a token satisfying HTTP token grammar.

The shared constant resolver supports bounded source constants,
concatenations, parentheses, exact static imports, and unambiguous static
wildcards. It rejects cycles, mutable/inaccessible fields, wrong types,
ambiguous owners, and over-limit expressions.

[`resolve_custom_designator`](../src/noir/jaxrs.py) then resolves an applied
annotation to exactly one accessible source declaration and one valid record
from its required `state=` argument. Neutral Java definitions still provide
declaration identity and accessibility. Its result is `none`, `resolved`, `invalid`, or `ambiguous`. A relevant
invalid or ambiguous result invalidates request-method selection.

Dependency-only custom annotations cannot be proven because their declarations
and retention evidence are absent from the workspace.

## 5. Standard designators and method paths

Modeled standard annotations are `GET`, `POST`, `PUT`, `DELETE`, `PATCH`,
`HEAD`, and `OPTIONS`. A standard designator must be marker-shaped; arguments,
multiple designators, mixed families, or a relevant invalid custom designator
reject the method.

A method-level `@Path` is optional. If present, exactly one genuine annotation
in the root family must resolve one value. Accepted syntax is one positional
value or one named `value`; mixing them, extra attributes, missing/multiple
values, or unresolved expressions fails closed. The empty segment is used when
the annotation is absent.

## 6. `@ApplicationPath` source index

[`index_jax_rs_application_paths`](../src/noir/jaxrs.py) accepts a concrete
source class with exactly one genuine `@ApplicationPath` and a direct
superclass of the matching core `Application` type. Indirect inheritance does
not establish an application record; public visibility is not required.

Failure shapes intentionally differ:

| Condition | Result |
|---|---|
| abstract application | diagnosed and omitted |
| family mismatch or unresolved/indirect superclass | diagnosed and omitted |
| multiple genuine annotations | invalid null-path records retained |
| one annotation with unresolved value | one null-path record retained |
| one resolved annotation | valid application record |

An omitted application can leave an empty prefix. A retained null path
participates in ambiguity and can suppress affected endpoints.

## 7. Direct resource analysis

[`analyze_direct_jax_rs_unit`](../src/noir/jaxrs.py) receives a compilation unit
from the shared workspace and requires the selected `JaxRsState` explicitly
through `state=`. It reuses these source indexes for every unit.

### 7.1 Root gate

A direct root is a workspace-visible, non-local, concrete class or record with
exactly one genuine, resolvable direct `@Path`. A nested type with its own
direct path is an independent root; lexical outer paths are not inherited.

The direct pass does not require a public root, unique fully qualified
addressability, or proven runtime construction.

### 7.2 Method gate

For each direct method under an eligible root:

1. resolve exactly one request-method designator;
2. require an explicit `public` modifier;
3. resolve zero or one same-family method `@Path`;
4. select one deployment prefix;
5. compose and emit an `EndpointFact`.

A method with `@Path` but no designator is not a direct endpoint; hierarchy
analysis may use it as a locator.

### 7.3 Record component accessors

A component's annotations can describe its implicit zero-argument accessor.
Only standard designators, `@Path`, and source annotations proven applicable to
methods participate. The component is ignored when the record declares an
explicit zero-parameter accessor of the same name.

A synthesized fact uses the component name, empty parameters, and the record
component as `represented_targets`. Its `annotation_evidence` is empty because
the request annotation is not on a method declaration; the CSV line is
therefore blank.

## 8. Deployment model and `web.xml`

[`build_jax_rs_deployment_model`](../src/noir/jaxrs_deployment.py) combines
the supplied application records with bounded servlet-descriptor evidence.
It returns a model; `prepare_jaxrs_analysis(request, workspace, state)` stores
that result in `state.deployment_model`. The builder neither receives nor
mutates the Java workspace.

### 8.1 Project ownership and source keys

The nearest layout containing `src/main/java`, `src/main/resources`, or
`src/main/webapp` defines project ownership. Without a marker, the analysis
root is the project. A source application key is:

```text
(project root, application package, Javax/Jakarta family)
```

Records sharing a key coalesce only when every path resolves and all paths
agree; otherwise the key's prefix is unknown.

### 8.2 Descriptor bounds

Only regular files named exactly `web.xml` are considered. Discovery applies
the configured directory-pruning rules, excludes symlinks and files over 10
MiB, and diagnoses unreadable or malformed XML.

The parser reads direct servlet declarations, init parameters, mappings, and
URL patterns. A mapping is relevant when its servlet class matches bounded
Jersey/RESTEasy/CXF names or its servlet/init parameters name a supported
application class. Supported init parameter names are
`javax.ws.rs.Application` and `jakarta.ws.rs.Application`.

URL-pattern normalization is:

| Pattern | Prefix |
|---|---|
| `/api/*`, `/api/`, `api/*` | `/api` |
| `/` | empty |
| `/*` | `/` |

An explicit mapping associated with an application key overrides Java
`@ApplicationPath`; conflicting explicit values make the key unknown. One
unassociated recognizable servlet prefix can apply to known source applications
only when all such mappings agree and the project has no explicit application
key. A descriptor alone does not create endpoints.

### 8.3 Prefix selection

[`select_jax_rs_deployment_prefix`](../src/noir/jaxrs_deployment.py) filters by
resource project, compatible family, and application packages that are
ancestors of the resource package. It keeps the most specific package,
prefers explicit descriptor evidence, then exact family evidence, and requires
all survivors to agree on one valid path.

No candidates means an empty prefix, except for the narrow single-project
nonstandard-layout fallback: the resource must belong to that sole project and
all compatible entries must agree. Ambiguity is diagnosed and suppresses the
endpoint.

If `state.deployment_model` is `None`,
`resolve_jax_rs_resource_prefix(unit, namespace, owner_name, state=state)` uses
`state.applications` with the same most-specific-package/agreement principles.
The normal pipeline prepares the full model before endpoint analysis.

## 9. Hierarchy binding

[`noir.java_hierarchy`](../src/noir/java_hierarchy.py) owns unique visible
source types, class/interface edges, generic substitutions, source methods,
erased signatures, and maximally specific/default-interface selection.
Duplicate fully qualified identities are omitted from the graph.

[`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) adds JAX annotation
classification, atomic bundle inheritance, implementation binding, interface
path layers, and locator traversal. `JaxRsHierarchyAnalyzer(workspace,
state=jaxrs_state)` retains the explicit family state alongside the neutral
Java graph; hierarchy and direct passes consult the same family view.

### 9.1 Bounds and implementations

| Bound | Value |
|---|---:|
| hierarchy depth | 12 |
| expanded hierarchy states | 256 |
| generic environment for one interface | one consistent environment |

Override identity is method name plus erased parameter types; return type is
not part of the signature. Generic environments are substituted before
erasure.

A usable implementation is non-static, non-private, non-abstract, and either
an explicitly public class/record method or a body-bearing default interface
method. Duplicate erased signatures, unresolved signature types, ambiguous
classes/defaults, and incomparable annotation origins fail closed.

### 9.2 Atomic annotation bundles

A selected method's annotation bundle is indivisible:

- any direct annotation other than genuine `java.lang.Override`, or any direct
  parameter annotation, makes the implementation the bundle source;
- otherwise the nearest eligible superclass bundle wins;
- otherwise one maximally specific interface bundle may win;
- multiple or invalid origins reject that signature.

The whole supported bundle is checked for one Javax/Jakarta family. Route
behavior comes from `@Path` and the request designator. Supporting annotations
such as consumes/produces, context, suspended, and parameter bindings are
classified but their runtime behavior is not modeled.

If an interface method supplies the selected bundle, one genuine same-family
type-level `@Path` on that interface contributes a path layer. Superclass
type-level paths are not added by this rule.

### 9.3 Worked value: interface contract bound to a class

Assume these declarations are in the shared workspace and no deployment
prefix applies:

~~~java
// app/ItemsApi.java
package app;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;

@Path("/contract")
public interface ItemsApi {
    @GET
    @Path("/items/{id}")
    Item find(@PathParam("id") String id);
}
~~~

~~~java
// app/ItemsResource.java
package app;

import jakarta.ws.rs.Path;

@Path("/api")
public class ItemsResource implements ItemsApi {
    @Override
    public Item find(String id) { return null; }
}

record Item(String id) {}
~~~

The neutral graph contains FQN-keyed records and an adapted traversal context:

~~~python
graph.types == {
    "app.ItemsApi": api_type_record,
    "app.ItemsResource": resource_type_record,
    "app.Item": item_type_record,
}

context = JavaHierarchyContext(
    class_states=[(resource_type_record, {})],
    interface_roots=[(api_type_record, {})],
    complete=True,
)
~~~

For erased signature `("find", ("java.lang.String",))`, the class method is
the implementation but the interface method supplies the indivisible
annotation bundle:

~~~python
effective = JaxRsEffectiveMethod(
    implementation=resource_find_method,
    implementation_env={},
    annotation_source=api_find_method,
    binding={
        "kind": "leaf",
        "path": "/items/{id}",
        "method": "GET",
        "evidence_node": get_annotation_node,
        "annotation_identity": "jakarta.ws.rs.GET",
        "annotation_family": "jax-rs-designator",
    },
    hierarchy_added=True,
    signature=("find", ("java.lang.String",)),
)
~~~

The path layers are therefore:

~~~text
empty deployment prefix
+ concrete root /api
+ selected interface contract /contract
+ leaf /items/{id}
= /api/contract/items/{id}
~~~

The resulting fact is an inbound JAX-RS `GET` attributed to concrete handler
`ItemsResource.find`, with parameter spelling `String id`. Because `@GET` is
on a different source method from the concrete implementation, it does not
claim same-method annotation-line evidence. The full meanings and constructor
shapes of `JavaTypeRecord`, `JavaHierarchyContext`, and
`JaxRsEffectiveMethod` are in
[Java data structures by module](11-naming-and-code-vocabulary.md#java-data-structures-by-module).

## 10. Subresource locators

An effective method is a leaf when it has a request designator, or a locator
when it has a nonempty `@Path` and no designator.

A locator target must resolve uniquely to a concrete source class or record.
Supported shapes include a direct declared type, `Class<T>`, an exact
parameterized source type, and a raw generic source type with its bounded
default environment. Interfaces, abstract/external/duplicate/inaccessible
types, primitives, arrays, wildcards, unresolved variables, malformed arity,
and non-resource shapes are rejected.

The locator method path defines the transition; the target type's own
type-level `@Path` is not appended.

Traversal is branch-local and bounded by depth 16, 4096 states per root, and
8192 composed path characters. Active type/edge cycles stop that branch. A
hierarchy/subresource leaf is emitted only when reached through a locator or
added through hierarchy binding, avoiding duplication of ordinary direct
leaves.

[`deduplicate_endpoint_facts`](../src/noir/evidence.py) removes analyzer-local
duplicates with a typed identity and unions their annotation/target evidence.
Public six-field consolidation remains a later boundary.

## 11. Java WebSocket handshakes

[`analyze_java_websocket_endpoints`](../src/noir/java_websocket.py) recognizes
`jakarta.websocket.server.ServerEndpoint` and
`javax.websocket.server.ServerEndpoint` on one unique workspace type.

The type and every enclosing type must be public and visible. A class is
concrete; a nested class is static; and it has an implicit or explicit public
zero-argument constructor. A record must have zero components. Other type
kinds are rejected.

The annotation accepts one positional value or named `value`. Mixing forms,
missing/multiple values, unresolved constants, empty paths, queries, or
fragments fail closed. A leading slash is added when absent. Encoder, decoder,
subprotocol, and configurator attributes do not affect route identity.

No JAX deployment prefix is applied. The emitted fact uses:

| Field | Value |
|---|---|
| method | `GET` |
| protocol / surface / direction | `ws` / `websocket` / inbound |
| technology | `jax-websocket` |
| handler | endpoint type |
| annotation evidence | empty |
| represented target | annotated type |

`@ServerEndpoint` is not request-method evidence, so the public annotation-line
cell is blank.

## 12. Typed provenance and diagnostics

Direct JAX methods record the handler method as their represented target and
the applied standard/custom designator as annotation evidence. Synthesized
record accessors represent the component and carry no method evidence.

Hierarchy and subresource facts always attribute the public handler and target
to the selected implementation. A superclass/interface annotation can prove
the route, but supplies CSV method-line evidence only when its source method is
the implementation method. Cross-declaration evidence therefore leaves the
public line blank.

Diagnostics go through [`noir.diagnostics.record`](../src/noir/diagnostics.py).
A bound application/CLI collector captures them; an unbound direct analyzer
call remains file-free and simply does not capture the message. Diagnostics are
not reconstructed from endpoint facts.

## 13. Bounds and proof limits

| Bound or uncertainty | Limit / survival scope |
|---|---|
| Java constant depth / resolved string | 12 / 8192 characters |
| custom HTTP token | 128 characters |
| descriptor size | 10 MiB |
| hierarchy | depth 12, 256 states |
| locator traversal | depth 16, 4096 states per root |
| composed locator path | 8192 characters |
| bad root `@Path` | root's direct methods |
| invalid/multiple/mixed designator | method or binding |
| non-public direct method | method |
| ambiguous deployment prefix | associated endpoints |
| incomplete hierarchy | uncertain inherited additions, not direct facts |
| invalid locator return/cycle/limit | locator branch or root budget |
| invalid `@ServerEndpoint` type/path | WebSocket type |
| malformed descriptor | descriptor; other evidence survives |

This model does not prove runtime scanning/registration, dependency-bytecode
designators or hierarchies, dynamic locator polymorphism, constructor/injection
viability for direct roots, filters, proxies, hosts, authentication,
authorization, full parameter/media semantics, WebSocket callbacks, or runtime
deployment reachability beyond the bounded source and descriptor evidence
above.

Next: [07 — Output, evidence, and reports](07-output-evidence-reports.md).
