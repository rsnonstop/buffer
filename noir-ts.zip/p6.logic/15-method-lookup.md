# 15 — Method lookup and reading strategy

[← JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) ·
[Index](README.md) · [Adding framework support →](16-adding-framework-support.md)

This chapter is the bridge between a symbol selected in `src/` and the larger
application story. It does not repeat every algorithm. It tells the reader
which deep chapter owns the symbol, which runtime route contains it, and which
other views answer the next likely question.

## 1. The method-documentation contract

The method-level chapters use exact Python symbol names. An editor-wide search
for a selected function, class, or non-trivial class method should therefore
find either:

- a method card explaining its caller, input, decisions, output, effects, and
  failure behavior; or
- a compact helper-table entry explaining the smaller operation and naming the
  method family or call chain that gives it context.

“Important method” means any definition that owns at least one of these:

- an application or analyzer entry point;
- orchestration or pass ordering;
- a domain-value transition;
- Java identity, visibility, constant, hierarchy, or ambiguity proof;
- framework-semantic decoding;
- endpoint/evidence construction, merging, or suppression;
- validation, diagnostics, filesystem publication, or another observable
  effect; or
- substantial branching whose fail-closed outcome affects coverage.

Tiny accessors and syntax conveniences are not given full method cards. Their
exact names still appear in grouped tables beside the decision method that
uses them. Dunder methods are described with their owning value type when they
enforce a domain invariant.

## 2. Choose the owning method guide

| Selected source file | Method-level guide | Main data leaving the module |
|---|---|---|
| `noir_sbt.py`, `application.py`, `cli.py` | [Core runtime methods](12-core-runtime-methods.md) | arguments, `AnalysisRequest`, artifacts, exit status |
| `noir/__init__.py` | [Core runtime methods](12-core-runtime-methods.md) for lazy application/output aliases and domain re-exports | package API aliases; `__getattr__` loads non-model exports on first access and `__dir__` advertises them without loading |
| `pipeline.py`, `frameworks.py`, `discovery.py`, `tree_sitter_runtime.py`, `diagnostics.py` | [Core runtime methods](12-core-runtime-methods.md) | `SourceSnapshot`, `FrameworkPlan`, adapter lifecycle, diagnostics, `AnalysisResult` |
| `spring_framework.py`, `jaxrs_framework.py`, `wicket_framework.py` | [Core runtime methods](12-core-runtime-methods.md) and [adding framework support](16-adding-framework-support.md) | family-owned configure/prepare/analyze hooks; Wicket currently returns an empty tuple |
| `java_ast.py`, `java_frontend.py`, `java_queries.py`, `java_methods.py` | [Core runtime methods](12-core-runtime-methods.md) | compilation-unit facts, query captures, `MethodFact` indexes |
| `java_workspace.py`, `java_hierarchy.py`, `model.py`, `immutability.py`, `paths.py` | [Core runtime methods](12-core-runtime-methods.md) | shared workspace indexes and immutable domain values |
| `spring_mvc.py`, `spring_mvc_hierarchy.py` | [Spring methods](13-spring-methods.md) | direct, composed, record-accessor, and inherited MVC facts |
| `spring_route_registrations.py`, `spring_gateway.py` | [Spring methods](13-spring-methods.md) | functional, programmatic, and Gateway facts |
| `spring_clients.py`, `spring_config.py`, `spring_websocket_messaging.py` | [Spring methods](13-spring-methods.md) | client, resource, handshake, messaging, and configured Spring facts |
| `jaxrs.py`, `jaxrs_deployment.py`, `jaxrs_hierarchy.py`, `java_websocket.py` | [JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) | direct, inherited, subresource, deployment-aware, and WebSocket facts |
| `inventory.py`, `evidence.py`, `output.py`, `reports.py` | [JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) | audit inventories, owned evidence, consolidated rows, report bytes |
| `comparison.py`, `contracts.py` | [JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md) | validated Noir locations, comparison items, stable contract values |

The older chapters remain the behavior-oriented view. The method guides are
the implementation-oriented view. For example, use [Spring MVC](04-spring-mvc.md)
to understand composed-mapping policy and the Spring method guide to follow
`decode_spring_composed_mapping()` through its helper calls.

## 3. Start from one of four runtime trunks

Most method searches become easier once the selected symbol is placed on one
of four trunks.

The guide deliberately uses several bounded call graphs instead of one graph
of the whole package. A whole-package graph would mix orchestration, syntax
utilities, framework decisions, and rendering into an unreadable network.
Each trunk shows stable stage boundaries; the deep chapter then expands only
the relevant branch down to decision methods and data transformations.

### 3.1 Invocation and orchestration

~~~mermaid
flowchart LR
    CLI["run_cli()"] --> APP["analyze()"]
    APP --> PIPE["run_analysis()"]
    PIPE --> SNAP["_snapshot_sources()"]
    PIPE --> SELECT["_select_frameworks()"]
    PIPE --> WORK["_build_workspace()"]
    PIPE --> LOOKUP["frameworks.adapters_for_plan()"]
    WORK --> CFG["create selected family state and bind recognizers"]
    CFG --> INV["build inventories"]
    INV --> PREP["prepare all selected adapters"]
    LOOKUP --> PREP
    PREP --> RUN["analyze selected adapters in registry order"]
    RUN --> SP["spring_framework.analyze_spring_framework()"]
    RUN --> JP["jaxrs_framework.analyze_jaxrs_framework()"]
    RUN --> WP["wicket_framework.analyze_wicket_framework()"]
    SP --> RESULT["AnalysisResult"]
    JP --> RESULT
    WP -. empty tuple .-> RESULT
~~~

Use this trunk for questions about timing, selected frameworks, analyzer order,
diagnostic scope, or why a failure did or did not mutate an artifact.

### 3.2 Java evidence and semantic proof

~~~mermaid
flowchart LR
    BYTES["snapshotted bytes"] --> UNIT["build_java_compilation_unit()"]
    UNIT --> WORK["build_java_workspace()"]
    WORK --> IDX["type / constant / annotation / method indexes"]
    IDX --> RESOLVE["name, value, visibility, and hierarchy resolvers"]
    RESOLVE --> DECODER["framework decoder"]
    DECODER --> FACT["EndpointFact or fail-closed skip"]
~~~

Use this trunk when a method deals with Tree-sitter nodes, imports, constants,
type identity, hierarchy, source-defined annotations, or ambiguity.

### 3.3 Framework extraction

~~~mermaid
flowchart TD
    UNIT["shared compilation units"] --> DIRECT["direct per-unit pass"]
    WORK["shared workspace indexes"] --> PROJECT["project-wide supplemental pass"]
    DIRECT --> FACTS["candidate EndpointFact values"]
    PROJECT --> FACTS
    FACTS --> CHOICE{"this producer defines<br/>local deduplication?"}
    CHOICE -->|"yes"| LOCAL["typed evidence-preserving local deduplication"]
    CHOICE -->|"no"| PIPE["pipeline result"]
    LOCAL --> PIPE
~~~

Use this trunk to understand how a framework-specific candidate is gated,
decoded, attributed, and turned into typed evidence. The Spring and JAX-RS
guides show separate call graphs for each supported surface; the Wicket facade
shows a selected lifecycle with no semantic producer yet.

### 3.4 Presentation and publication

~~~mermaid
flowchart LR
    FACT["EndpointFact"] --> CAND["EndpointRowCandidate"]
    CAND --> GROUP["ConsolidatedEndpoints"]
    GROUP --> CSV["seven-column CSV"]
    GROUP -->|"represented targets"| ABSENT["annotations-without-endpoints report"]
    TRIGGER["final-trigger inventory"] --> ABSENT
    TRIGGER --> PROJ["trigger_annotation_log_inventory"]
    PROJ --> LOG["annotation and diagnostics log"]
    DIAG["run-local diagnostics"] --> LOG
    TRIGGER --> COMP["optional Noir comparison"]
    NOIR["loaded Noir locations"] --> COMP
    COMP --> REPORT["comparison report"]
~~~

Use this trunk when a selected method normalizes paths, merges identities,
chooses `method_annotation_line`, renders text, compares Noir locations, or
publishes bytes.

## 4. Read a method card in this order

Each full method card answers the same questions:

1. **Why is it called?** The incoming edge and owning runtime stage.
2. **What does it receive?** The important types and whether values are raw,
   parsed, resolved, normalized, or already consolidated.
3. **What proof does it require?** Identity, placement, visibility, uniqueness,
   bounds, or framework activation gates.
4. **What can it return?** A domain value, zero or more facts, a skip sentinel,
   rendered bytes, or an exception.
5. **What can it change?** Workspace indexes, run-local diagnostics, stdout, or
   an output artifact. Most semantic helpers have no external side effect.
6. **How does uncertainty behave?** Fail-closed skip, diagnostic, bounded
   fallback, or fatal error.
7. **Where does the result go next?** The outgoing edge and next representation.

This order prevents a common reading error: understanding a local expression
without knowing whether the method is gathering evidence, proving an endpoint,
or projecting an already-proven fact.

## 5. Data-state labels used in call graphs

| Label | Meaning | Mutation/effect rule |
|---|---|---|
| raw source | exact snapshotted Java bytes and paths | each Java file is read once by the pipeline; marker-only POM input is separate |
| syntax node | Tree-sitter node tied to one retained tree | never valid outside its workspace lifetime |
| unit fact | dictionary record for one compilation unit | built once, then enriched during workspace/framework indexing and reused by analyzers |
| workspace index | cross-file identity/value/hierarchy map | run-local mutation is owned by builders, framework attachers, and explicit support caches |
| decoded candidate | bounded framework semantics, not yet necessarily an endpoint | may be dropped on ambiguity or a later gate |
| `EndpointFact` | typed, source-backed endpoint assertion | analyzers emit; output cannot invent one |
| owned evidence | validated `AnnotationEvidence` / `SourceTarget` | merged without changing public identity |
| row candidate | six public fields plus private evidence | created only at the presentation boundary |
| consolidated result | sorted rows plus represented-target union | immutable input to artifact rendering |
| prepared payload | complete byte reports and completion text prepared in memory | byte-report rendering has no filesystem effect; the CSV and the `Annotation and diagnostics log` each render during their direct writes |

Arrows in the deep guides mean either a direct call or a data hand-off. A
diamond is a decision that can suppress a candidate. A box ending in “record
diagnostic” is still a successful local return unless the graph explicitly
shows an exception edge.

## 6. Cross-check the method against other views

| Question after reading a method | Best companion chapter |
|---|---|
| Why does this layer own the method? | [Mental model](01-mental-model.md) |
| Where is it in whole-run order? | [CLI and orchestration](02-cli-and-orchestration.md) |
| How are Java names and constants proven? | [Shared Java engine](03-shared-java-engine.md) |
| What is the Spring behavior contract? | [Spring MVC](04-spring-mvc.md) or [additional Spring surfaces](05-spring-additional-surfaces.md) |
| What is the JAX-RS/WebSocket behavior contract? | [JAX-RS and Java WebSocket](06-jax-rs.md) |
| Why does evidence disappear or survive output? | [Output, evidence, and reports](07-output-evidence-reports.md) |
| Can I see a concrete source example travel through it? | [Worked traces](08-worked-traces.md) |
| What production risk does its limit create? | [Production use](09-production-use.md) |
| Which production definitions depend on it? | [Code map](10-code-map.md) |
| What does a term or type name mean? | [Application logic vocabulary](11-naming-and-code-vocabulary.md) |

## 7. Practical lookup recipe

If the selected symbol is `resolve_spring_alias_terminal()`:

1. its module, `spring_mvc.py`, routes to the Spring method guide in the table
   above;
2. exact-name search lands on its method card and composed-annotation call
   graph;
3. the incoming calls show how `AliasFor` edges reach it;
4. its outputs lead forward to `decode_spring_composed_mapping()` and then to
   `EndpointFact` construction; and
5. the behavior chapter explains the policy while the code map identifies its
   production owner and downstream consumers.

Apply the same recipe to private methods such as
`JaxRsHierarchyAnalyzer._resolve_effective_jax_rs_methods()`: search the exact
qualified name, read its class-level call graph, then follow the returned value
to the next method card. The leading underscore means module-private, not
unimportant.

## 8. Keeping this view coherent

When an important method is added, renamed, or changes its input/output role:

1. update the owning method guide using the method-card fields above;
2. update a call graph if the incoming or outgoing runtime edge changed;
3. update the behavior chapter only when the application rule changed;
4. update the code map when production ownership or dependencies changed; and
5. search `p6.logic` for the old exact symbol name.

This keeps the top-down application story stable while allowing the
method-level layer to evolve with implementation details.

Continue with [16 — Adding framework support](16-adding-framework-support.md),
or return to the [logic guide index](README.md).
