# 08 — Worked end-to-end traces

[← Output and evidence](07-output-evidence-reports.md) · [Index](README.md) · [Next: Production use →](09-production-use.md)

These traces follow source evidence through the current native package flow:
one shared Java workspace, typed `EndpointFact` values, Spring configuration,
public projection, evidence merging, and reports. Filenames and line numbers
are illustrative; the decisions match the implementation.

## Code coordinates

| Trace | Start here | Important downstream owners |
|---|---|---|
| A — direct Spring | [`noir.spring_mvc`](../src/noir/spring_mvc.py) :: `analyze_direct_spring_mvc_unit()` | [`noir.spring_config`](../src/noir/spring_config.py) :: `apply_spring_path_configuration()`; [`noir.output`](../src/noir/output.py) :: `normalize_endpoint_path()` |
| B — inherited Spring | [`noir.spring_mvc_hierarchy`](../src/noir/spring_mvc_hierarchy.py) :: `analyze_spring_mvc_hierarchy()` | [`noir.java_hierarchy`](../src/noir/java_hierarchy.py) :: `JavaSourceHierarchyGraph`; typed evidence in [`noir.evidence`](../src/noir/evidence.py) |
| C — method conditions | [`noir.spring_mvc`](../src/noir/spring_mvc.py) :: `union_request_method_conditions()` | `ordered_http_methods()` and direct fact fan-out |
| D — JAX-RS deployment and locator | [`noir.jaxrs_deployment`](../src/noir/jaxrs_deployment.py) :: `build_jax_rs_deployment_model()` | `select_jax_rs_deployment_prefix()`; [`noir.jaxrs_hierarchy`](../src/noir/jaxrs_hierarchy.py) :: `analyze_jax_rs_hierarchy_and_subresources()` |
| E — Spring surfaces | [`noir.spring_framework`](../src/noir/spring_framework.py) :: `analyze_spring_framework()` | client, configuration, WebSocket, and messaging analyzers |
| F — invalid first mapping | [`noir.spring_mvc`](../src/noir/spring_mvc.py) :: `first_spring_mapping()` | built-in/composed decoding and run-scoped diagnostics |
| G — converging producers | [`noir.output`](../src/noir/output.py) :: `consolidate_endpoint_rows()` | annotation-evidence and represented-target union |
| H — incomplete coverage | [`noir.inventory`](../src/noir/inventory.py) :: `build_final_trigger_inventory()` | [`noir.reports`](../src/noir/reports.py) :: `render_annotations_without_endpoints_report_bytes()` |

## 1. Direct Spring MVC: configuration and public normalization

Assume the analysis root is named `shop`:

~~~properties
# src/main/resources/application.properties
server.servlet.context-path=/edge
routes.api=/v1
~~~

~~~java
package demo;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("${routes.api}/orders")
class OrderController {
    @GetMapping({"/{id:[0-9]{1,3}}", "/latest"})
    Object get(String id) { return null; }
}
~~~

`run_analysis()` builds one compilation unit for this file. The selected
`spring_framework` facade calls
`analyze_direct_spring_mvc_unit(unit, workspace)`, which proves the mapping
identities and emits two typed facts:

~~~text
GET /${routes.api}/orders/{id:[0-9]{1,3}}
GET /${routes.api}/orders/latest
~~~

Each fact attributes the handler to `OrderController.get`, retains the source
parameter spelling `String id`, and carries typed annotation and represented
target evidence. The direct pass does not require `@RestController` for route
eligibility.

`build_spring_path_configuration()` reads the owning project's supported
properties, and `apply_spring_path_configuration()` resolves the placeholder
and prepends the inbound server base:

~~~text
/edge/v1/orders/{id:[0-9]{1,3}}
/edge/v1/orders/latest
~~~

At the public boundary, `consolidate_endpoint_rows()` calls
`normalize_endpoint_path()`. The balanced Spring regex constraint is removed,
but the variable name remains:

~~~text
/edge/v1/orders/{id}
/edge/v1/orders/latest
~~~

Conceptually, the result is:

~~~csv
module_name;interface_type;endpoint;source_file_name;method_name;parameters;method_annotation_line
shop;http GET;/edge/v1/orders/latest;src/main/java/demo/OrderController.java;OrderController.get;String id;<GetMapping line>
shop;http GET;/edge/v1/orders/{id};src/main/java/demo/OrderController.java;OrderController.get;String id;<GetMapping line>
~~~

The diagnostic log includes the recognized endpoint-trigger annotations. The
final-trigger report does not list this method's mapping trigger because the
surviving row represents that exact method target.

## 2. Spring mapping inherited from an interface

~~~java
// ApiContract.java
package demo;

import org.springframework.web.bind.annotation.*;

@RequestMapping("/contract")
public interface ApiContract {
    @GetMapping("/ping")
    String ping();
}
~~~

~~~java
// ApiController.java
package demo;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ApiController implements ApiContract {
    @Override
    public String ping() { return "ok"; }
}
~~~

The direct pass emits neither declaration: the concrete method has no direct
mapping, while the interface method is not a concrete handler. The hierarchy
pass then:

1. proves one concrete controller and a complete source hierarchy;
2. matches `ping()` by erased signature;
3. selects the interface contract because no nearer method mapping wins;
4. composes `/api`, `/contract`, and `/ping`.

The resulting path is `/api/contract/ping`.

Route and handler ownership differ:

~~~mermaid
flowchart LR
    CONTRACT["ApiContract.java<br/>route declaration"] --> FACT["EndpointFact"]
    HANDLER["ApiController.java<br/>handler declaration"] --> FACT
    FACT --> CSV["CSV source: ApiController.java"]
    FACT --> LINE["method_annotation_line: blank"]
~~~

The public annotation line is blank because the route annotation and handler
are in different files. The represented target is the concrete implementation
method, so the interface trigger may still appear in the final-trigger report.
That is deliberate source attribution, not proof that the route lacks an
annotation.

## 3. Spring request-method condition union

~~~java
@RequestMapping(path = "/reports", method = RequestMethod.GET)
class ReportController {
    @RequestMapping(path = "/daily", method = RequestMethod.POST)
    Object daily() { return null; }
}
~~~

`union_request_method_conditions()` models type and method request conditions
as an ordered union, not a runtime intersection. It therefore emits:

~~~text
GET  /reports/daily
POST /reports/daily
~~~

This is an intentional static approximation and an important source of
possible static-only rows during production reconciliation.

## 4. JAX-RS `web.xml` override and subresource traversal

Source declares `/from-java`:

~~~java
@ApplicationPath("/from-java")
public class ApiApplication extends jakarta.ws.rs.core.Application {}
~~~

The owning descriptor explicitly associates that application with `/rest/*`:

~~~xml
<web-app>
  <servlet>
    <servlet-name>jax</servlet-name>
    <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
    <init-param>
      <param-name>jakarta.ws.rs.Application</param-name>
      <param-value>demo.api.ApiApplication</param-value>
    </init-param>
  </servlet>
  <servlet-mapping>
    <servlet-name>jax</servlet-name>
    <url-pattern>/rest/*</url-pattern>
  </servlet-mapping>
</web-app>
~~~

Resources use a locator:

~~~java
@Path("/root")
public class Root {
    @Path("/accounts")
    public AccountResource accounts() { return new AccountResource(); }
}
~~~

~~~java
@Path("/standalone")
public class AccountResource {
    @GET
    @Path("/{id}")
    public Object get(String id) { return null; }
}
~~~

The explicit XML association makes `/rest` the deployment prefix for this
application. `Root.accounts` has a path but no request designator, so it is a
locator. Traversal proves its exact concrete source return type and composes:

~~~text
/rest + /root + /accounts + /{id}
= /rest/root/accounts/{id}
~~~

The target type path `/standalone` is intentionally not inserted into the
locator chain. Its own direct root remains independent, so the direct pass can
also produce `/rest/standalone/{id}`. The locator row is attributed to
`AccountResource.get`, and its same-file `@GET` line is eligible for the CSV.

## 5. Spring path domains do not share one rewrite rule

With:

~~~properties
server.servlet.context-path=/edge
inventory.base=https://inventory.example
~~~

and a broker application prefix `/app`, four raw facts resolve differently:

| Fact | Final path | Rule |
|---|---|---|
| inbound MVC `/orders` | `/edge/orders` | inbound HTTP receives the server base |
| outbound client `${inventory.base}/items` | `https://inventory.example/items` | the absolute resolved URL wins; no server base |
| WebSocket handshake `/socket` | `/edge/socket` | the HTTP upgrade path receives the server base |
| message destination `/refresh` | `/app/refresh` | broker application prefix; no servlet base |

Their public interface types remain distinct: `http ...`, `http-client ...`,
`ws GET`, and `ws SEND`.

## 6. The first recognized Spring mapping is invalid

~~~java
class ProblemController {
    @GetMapping(dynamicPath())
    @PostMapping("/apparently-safe")
    Object run() { return null; }
}
~~~

`first_spring_mapping()` selects the first recognized mapping in source order.
The static string evaluator cannot resolve `dynamicPath()`, so the recognized
result is invalid. The later `@PostMapping` is not a fallback.

~~~mermaid
flowchart TD
    START["annotations in source order"] --> FIRST["first recognized: GetMapping"]
    FIRST --> RESOLVE{"path fully resolved?"}
    RESOLVE -- no --> STOP["reject this method candidate"]
    STOP --> DIAG["record diagnostic"]
    STOP --> ABSENT["trigger target remains unrepresented"]
~~~

Because no surviving fact represents the method, both trigger occurrences may
appear in the final-trigger report. Subtraction is by exact source target, not
by path spelling or annotation name.

## 7. Two producer paths converge

~~~java
@Path("")
class Root {
    @Path("")
    public Leaf leaf() { return new Leaf(); }
}

@Path("")
class Leaf {
    @GET @Path("/same")
    public Object same() { return null; }
}
~~~

The direct JAX-RS pass and locator traversal can both produce the same public
identity for `Leaf.same`. Each analyzer emits an `EndpointFact`; projection
creates two `EndpointRowCandidate` values. `consolidate_endpoint_rows()` groups
on the normalized first six CSV fields, then unions typed annotation evidence
and represented targets before choosing the seventh field.

The outcome is one row, the `@GET` line is retained, and every valid represented
target from both candidates participates in final-trigger subtraction.

## 8. Successful completion does not mean complete runtime coverage

Suppose a source tree contains ten accepted routes plus:

- a functional route behind unsupported control flow;
- a mapping whose constant cannot be resolved;
- a custom annotation defined only in a dependency;
- a locator whose runtime target type is dynamic.

The run can still publish ten rows and return status 0. Candidate-local
ambiguity or unsupported syntax normally rejects only that branch.

~~~text
exit 0 = analysis completed and requested artifacts were published
exit 0 ≠ every runtime endpoint was understood
~~~

Production review therefore considers the CSV, diagnostics, final-trigger
report, source-root assumptions, and an independent build or runtime view.

Next: [09 — Production use and risk controls](09-production-use.md).
