# 01 — Mental model

## 1. What the program is—and is not

`noir_sbt` is a static source recognizer. It uses Java syntax plus a deliberately bounded semantic model to prove endpoint facts. It does not use Maven or Gradle to compile the code, load a classpath, construct a Spring application context, start a JAX-RS container, execute configuration methods, or evaluate arbitrary Java.

That choice explains the central rule used throughout the implementation:

> Emit an endpoint when the framework identity, route data, source binding, and the current branch's explicit eligibility checks are statically unambiguous; otherwise log the reason and skip it.

This is “fail closed” at the candidate level. A bad candidate normally does not abort the scan and does not erase valid sibling candidates.

## 2. System boundary

```mermaid
flowchart TB
    subgraph Inputs
        J["Java source files"]
        SP["Spring application.properties / yml / yaml"]
        WX["JAX-RS web.xml"]
        CLI["CLI options"]
    end

    subgraph StaticAnalyzer["noir_sbt static analyzer"]
        D["Discovery"]
        TS["Tree-sitter parse and queries"]
        W["Whole-workspace semantic indexes"]
        SA["Spring analyzer family"]
        JA["JAX-RS analyzer family"]
        WA["Wicket selectable empty stub"]
        FN["Formatting, normalization, evidence merge"]
    end

    subgraph Outputs
        CSV["Endpoint CSV"]
        LOG["Annotation + diagnostic log"]
        ABS["Annotations-without-endpoints log"]
        STD["stdout / stderr / exit status"]
    end

    CLI --> D
    J --> D
    D --> TS --> W
    SP --> SA
    WX --> JA
    W --> SA
    W --> JA
    W --> WA
    SA --> FN
    JA --> FN
    WA -. no facts yet .-> FN
    FN --> CSV
    W --> LOG
    SA --> LOG
    JA --> LOG
    W --> ABS
    FN --> ABS
    D --> STD
```

Anything requiring information outside those source/configuration inputs is outside the proof model. Examples include runtime bean conditions, active profiles, dependency bytecode, programmatically generated strings, reflection beyond the one supported registration shape, servlet-container defaults not encoded in the supported source/XML model, and routes introduced by libraries at runtime.

## 3. Layers and dependency direction

[`src/noir_sbt.py`](../src/noir_sbt.py) is only the executable launcher. Read
the application from the command boundary inward:

```mermaid
flowchart TD
    F["noir_sbt.py\nlauncher"] --> C["noir.cli\ncommand effects"]
    C --> A["noir.application\ntyped diagnostic scope"]
    A --> P["noir.pipeline\none-way stage order"]
    P --> M["noir.model\nimmutable request/result/facts"]
    P --> R["noir.frameworks\nstatic execution table"]

    P --> J["java_frontend + java_workspace"]
    J --> N["java_ast + java_methods + java_hierarchy"]
    R --> S["spring_framework facade"]
    R --> X["jaxrs_framework facade"]
    R --> K["wicket_framework selectable empty stub"]
    J --> S
    J --> X
    J --> K

    S --> O["noir.output + noir.reports"]
    X --> O
    C --> O
```

The pipeline imports the static execution table rather than concrete family
passes. That table binds each adapter name to a family-owned facade. The
Spring and JAX-RS facades accept the shared workspace and request context,
call only their own specialized modules, and return `EndpointFact` values.
There is no service locator, dynamic discovery, or framework-to-framework
dependency.

The execution table is separate from `discovery.FRAMEWORK_MARKER_RULES`.
Detector rules own raw findings and `auto` announcements; execution adapters
own selected-family order. One or more explicit families can be requested by
repeating `--framework`; the request tuple is canonicalized in enum order and
the effective lifecycle is independently restored to execution-table order.
Wicket has a selection identity, so `--framework wicket` runs its empty
lifecycle and `--framework spring --framework wicket` composes it with Spring
without coupling their facades. Its adapter is not a default and its marker
remains advisory, so omitted and auto modes do not run it.

The package root eagerly exposes only the stable model vocabulary. Its
`analyze` and `EndpointRowCandidate` convenience exports are loaded on first
access, so importing a neutral submodule does not initialize the parser and
every framework analyzer. `__dir__` still advertises all names in `__all__`
before either lazy export is resolved.

The diagram's boxes correspond to these concrete definitions:

| Diagram concept | Code coordinate | What to inspect there |
|---|---|---|
| request and result boundary | [`src/noir/model.py`](../src/noir/model.py) :: `AnalysisRequest`, `AnalysisResult` | Validation, immutability, and the data allowed across the application boundary |
| complete stage flow | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `run_analysis()` | The only top-level ordering of discovery, workspace construction, and framework passes |
| execution composition | [`src/noir/frameworks.py`](../src/noir/frameworks.py) :: `FRAMEWORK_ADAPTERS` | Static family hooks, explicit/default selection, and Spring–JAX-RS–Wicket execution order |
| family orchestration | [`src/noir/spring_framework.py`](../src/noir/spring_framework.py), [`src/noir/jaxrs_framework.py`](../src/noir/jaxrs_framework.py), [`src/noir/wicket_framework.py`](../src/noir/wicket_framework.py) | Exact pass order or deliberate empty behavior inside each independent family |
| source view | [`src/noir/pipeline.py`](../src/noir/pipeline.py) :: `SourceSnapshot` and `_snapshot_sources()` | The exact path/byte invariant that makes a run internally consistent |
| parser runtime | [`src/noir/tree_sitter_runtime.py`](../src/noir/tree_sitter_runtime.py) :: `build_workspace_runtime()` | The pinned dependency gate and query/runtime construction |
| rich endpoint identity | [`src/noir/model.py`](../src/noir/model.py) :: `EndpointFact` | Route, handler, project, protocol/surface, and private evidence before CSV loss |
| public row boundary | [`src/noir/output.py`](../src/noir/output.py) :: `endpoint_fact_to_row_candidate()` | Which rich fields survive projection and which are intentionally discarded |

## 4. One shared workspace, many endpoint families

`run_analysis()` first creates an immutable `SourceSnapshot`. The neutral
`java_workspace.build_java_workspace()` then creates every compilation unit
and shared index, including neutral source-annotation definitions.
`build_workspace_runtime()` compiles the complete shared query set once.

The pipeline creates separate state only for selected families: `JaxRsState`
owns JAX-RS meanings and deployment data; `SpringAnnotationState` owns its
definition-validation cache. The shared `JavaWorkspace` remains Java-only.
Family recognition callbacks receive their own state and supply annotation
meanings to the neutral inventory builder. After both inventories exist, every
selected adapter with a preparation hook completes project
preparation before any analyzer begins. This is where JAX-RS deployment
evidence is built. Selected facades then analyze in registry order: Spring,
JAX-RS, then Wicket when selected. CLI option order and a programmatic tuple's
input order do not alter that sequence. A scalar explicit Wicket mode selects
only Wicket. No framework pass reparses a source already present in the
workspace.

Temporary Spring client path layers stay inside the Spring client pass. Its
exported `EndpointFact` values contain resolved client paths and common evidence;
the common model carries no unfinished Spring configuration fields.

```mermaid
flowchart LR
    F["Every discovered Java file"] --> U["Compilation unit"]
    U --> T["Types and lexical nesting"]
    U --> I["Imports and package"]
    U --> C["String constants"]
    U --> A["Annotation occurrences and definitions"]
    T --> W["Workspace indexes"]
    I --> W
    C --> W
    A --> W
    W --> X1["Direct decoders"]
    W --> X2["Hierarchy graphs"]
    W --> X3["Functional/DSL recognizers"]
    W --> X4["Audit inventories"]
```

The workspace is whole-tree rather than file-local because paths and route annotations can depend on:

- constants declared in other files;
- exact and wildcard imports;
- nested or same-package types;
- source-defined composed annotations;
- custom JAX-RS HTTP method annotations;
- generic interfaces and abstract base classes;
- subresource return types;
- project ownership.

The four labels on the right of the diagram describe different kinds of
application-logic view over the same parsed source:

- A **workspace index** is a run-local lookup table derived from all parsed
  files. For example, the key `"demo.Paths"` can lead to the unique source
  type declaration, while the key `("demo.Paths", "ROOT")` can lead to the
  declaration whose initializer is `"/api"`. An index does not invent Java
  meaning; it makes already-observed declarations searchable across files.
- A **direct decoder** reads route evidence attached to the declaration being
  reported. For example, the Spring decoder can turn
  `@GetMapping("/items") void list()` directly into `GET /items` without
  following an inheritance or registration edge.
- A **hierarchy graph** connects source-visible types to their source-visible
  parents and methods. For example, it can bind an interface method
  `ItemsApi.list()` carrying `@GetMapping("/items")` to the concrete
  `ItemsController.list()` implementation before an endpoint is emitted.
- A **functional/DSL recognizer** interprets one deliberately supported chain
  of Java calls as declarative route data. For example,
  `RouterFunctions.route(GET("/items"), handler::list)` expresses a route even
  though there is no route annotation on `list()`.

The index stores searchable evidence; a decoder or recognizer gives that
evidence framework meaning; a hierarchy graph supplies source-level binding
between declarations. Concrete index shapes and worked values are collected
in [the vocabulary chapter](11-naming-and-code-vocabulary.md#workspace-and-index-vocabulary).

## 5. Endpoint-family catalogue

The following table is the high-level dispatch map. Detailed proof conditions are in the framework chapters.

| Family | Recognized source shape | Internal surface | Public `interface_type` shape |
|---|---|---|---|
| Spring MVC direct | `@GetMapping`, other shortcuts, `@RequestMapping`, supported composed mappings | server | `http <verb>` |
| Spring MVC hierarchy | Mapping on interface/abstract contract bound to a concrete controller method | server | `http <verb>` |
| Spring functional | Servlet/WebFlux `RouterFunction` in a genuine `@Bean` publisher | server | `http <verb>` |
| Spring programmatic MVC | Bounded `RequestMappingHandlerMapping.registerMapping` graph | server | `http <verb>` |
| Spring Cloud Gateway | Bounded `@Bean RouteLocator` Java DSL | gateway | `http-gateway <verb>` |
| Spring static resources | `WebMvcConfigurer.addResourceHandlers` | static-handler | `http-static-handler GET` |
| Spring HTTP Interface | `@HttpExchange` / fixed exchange annotations on interfaces | client | `http-client <verb>` |
| Spring OpenFeign | `@FeignClient` interface plus MVC mappings | client | `http-client <verb>` |
| Spring raw/STOMP handshake | `WebSocketConfigurer` or `WebSocketMessageBrokerConfigurer` registrations | websocket-handshake | `ws GET` |
| Spring messaging | Controller `@MessageMapping` / `@SubscribeMapping` | message | `ws SEND` / `ws SUBSCRIBE` |
| JAX-RS direct | Concrete `@Path` class/record with public designator method | default server | `http <verb>` |
| JAX-RS hierarchy | Interface/abstract annotation bundle bound by erased signature | default server | `http <verb>` |
| JAX-RS subresource | One or more typed `@Path` locator edges leading to a leaf | default server | `http <verb>` |
| Java WebSocket | Javax/Jakarta `@ServerEndpoint` class/record | websocket | `ws GET` |

For non-HTTP protocols, the formatter discards the surface subtype. A Spring handshake and a JAX WebSocket handshake therefore both become `ws GET` in the CSV.

### Why the HTTP interface types differ

All four `http...` forms use the HTTP protocol. The suffix does not describe a
different wire protocol; it preserves the endpoint's application role in the
seven-column public report:

| `interface_type` | Who initiates/serves the traffic | Example |
|---|---|---|
| `http GET` | the analyzed application serves an ordinary inbound HTTP route | `@GetMapping("/items")` |
| `http-gateway GET` | the application is a gateway that matches and forwards an inbound HTTP request | `route().GET("/items", ...).uri("lb://inventory")` |
| `http-static-handler GET` | Spring serves a configured static-resource path instead of invoking a normal controller endpoint | `addResourceHandler("/assets/**")` |
| `http-client GET` | application code declares an outbound HTTP operation against another service | `@GetExchange("/items")` on a client interface |

Thus, `http` is the protocol prefix and the optional suffix is a surface
classification. It lets a reader avoid treating an outbound client contract,
a forwarding rule, or a static resource mapping as an inbound business
handler.

## 6. Three identities inside one endpoint fact

Several analyzers distinguish:

1. **route declaration** — where the path/verb was declared;
2. **concrete handler** — the method/type reported as implementing the endpoint;
3. **project owner** — whose Spring/JAX configuration supplies a base path.

Those identities map to the similarly named `EndpointFact` fields as follows:

| Field | Application-logic meaning | Worked value below |
|---|---|---|
| `source_file` | the source identity published in the endpoint row; normally the concrete declaration a reader should open | `ItemsController.java` |
| `route_source_file` | the declaration that supplied route semantics such as path and verb | `ItemsApi.java`, because its interface method owns `@GetMapping` |
| `handler_source_file` | the concrete code declaration credited with handling the operation | `ItemsController.java` |
| `project_source_file` | the source/configuration owner used to select project-level path configuration; it need not contain the route or handler | `Routes.java` |

For a direct controller method, all four can name the same file. They separate
only when a contract, concrete implementation, and project configuration
participate in one fact. `source_line` is local diagnostic context;
`route_source_line` and `handler_source_line` identify their corresponding
provenance declarations.

For a direct method all three are usually the same file. They can diverge:

```mermaid
flowchart LR
    C["Interface contract\n@GetMapping('/items')"] -->|"route source"| E["Internal endpoint fact"]
    H["Concrete controller\nItemsController.list()"] -->|"handler + CSV source"| E
    P["Publisher/configuration module"] -->|"base path owner"| E
    E --> R["CSV row"]
    R --> O["Only concrete source/method remains"]
```

The typed value can carry all three identities without exposing a mutable row
shape:

```python
EndpointFact(
    path="/api/items",
    method="GET",
    parameters="String filter",
    source_file=SourceFile("/workspace/app/ItemsController.java"),
    source_line=42,
    handler_name="ItemsController.list",
    route_source_file=SourceFile("/workspace/contracts/ItemsApi.java"),
    route_source_line=12,
    handler_source_file=SourceFile("/workspace/app/ItemsController.java"),
    handler_source_line=42,
    project_source_file=SourceFile("/workspace/app/Routes.java"),
    technology="spring",
    protocol="http",
    surface="server",
    direction="inbound",
    annotation_evidence=(...),
    represented_targets=(...),
)
```

Not every analyzer populates every optional provenance or classification field.
Projection accepts only `EndpointFact`, preserves typed evidence until
consolidation, and does not copy `source_line` directly to the CSV.

### `surface` values

`surface` answers “what application role does this endpoint fact represent?”
It is independent of `protocol` and is used with `direction` when deriving the
public `interface_type`.

| Value | Meaning | Typical protocol/direction |
|---|---|---|
| `server` | ordinary route served by the analyzed application | `http` / `inbound` |
| `gateway` | Spring Cloud Gateway match-and-forward route | `http` / `inbound` |
| `static-handler` | Spring static-resource handler mapping | `http` / `inbound` |
| `client` | outbound Spring HTTP Interface or OpenFeign contract | `http` / `outbound` |
| `websocket-handshake` | Spring HTTP upgrade/handshake registration | `ws` / `inbound` |
| `message` | STOMP-style message destination rather than an HTTP request | `ws` / `inbound` |
| `websocket` | Javax/Jakarta annotated WebSocket server endpoint | `ws` / `inbound` |

The default is `server` because ordinary Spring MVC and JAX-RS facts are the
most common. Producers set a more specific value only after proving the
corresponding framework surface.

`surface` is currently a string rather than a closed enum. The table lists all
values emitted by the production analyzers; programmatic construction can pass
another string, which would be projected as another `http-<surface>` label.
The Spring path resolver also recognizes the compatibility labels `proxy` and
`resource`, although no current endpoint producer emits them.

## 7. Additions-only passes

The direct Spring and JAX-RS passes cover simple concrete annotations. Hierarchy, route-registration, and other specialized extraction passes append facts they can prove beyond that baseline; a candidate-local rejection in one of those passes does not delete an unrelated direct fact. This additions-only description ends at extraction: the later Spring configuration pass rewrites every Spring path and can drop any fact whose configured path cannot be resolved. An unexpected exception in any pass aborts the whole run.

```mermaid
flowchart TD
    SD["Direct Spring facts"] --> SA["Append Spring route registrations, hierarchy, and other surfaces"]
    SA --> C["Apply Spring configuration; facts may be rewritten or dropped"]
    JD["Direct JAX-RS facts"] --> JA["Append JAX-RS hierarchy, locator, and WebSocket facts"]
    C --> M["Combine selected framework facts"]
    JA --> M
    M --> N["Normalize"]
    N --> G["Group on public six-field identity"]
    G --> R["One final row per identity"]
```

The final identity includes concrete source, method name, and raw parameter text. Two handlers with the same method/path remain two rows when those fields differ.

## 8. The two meanings of “line”

There are two unrelated line concepts:

- `source_line` is the analyzer’s internal diagnostic line, which may be a route call, handler method, annotation, or type depending on the branch.
- `method_annotation_line` is selected later from validated same-source method-annotation evidence.

They are not interchangeable. Non-annotation routes and cross-file inherited mappings can have a meaningful internal `source_line` while the CSV column is blank.

## 9. Determinism versus completeness

The implementation invests heavily in deterministic ordering and ambiguity rejection:

- sorted discovery;
- exact source identities;
- fixed framework and HTTP-method order;
- source-byte ordering;
- deterministic local and final deduplication;
- bounded graph traversal;
- rejection of multiple equally valid bindings.

Those properties make repeated results auditable, but they do not prove completeness. Unsupported or ambiguous valid Java can be skipped. The diagnostics and annotations-without-endpoints report are therefore part of the result, not optional noise.

Next: [02 — CLI and orchestration](02-cli-and-orchestration.md).
