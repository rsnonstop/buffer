# 13 — Spring method-level execution and data flow

[← Core runtime methods](12-core-runtime-methods.md) · [Index](README.md) ·
[JAX-RS, evidence, and output methods →](14-jaxrs-output-methods.md)

This chapter supplements the module-level [Spring MVC](04-spring-mvc.md) and
[additional Spring surfaces](05-spring-additional-surfaces.md) chapters with a
source-level map of the important functions and methods. It answers four
questions for each branch:

1. who calls it;
2. what data enters and leaves;
3. which decisions make it emit or fail closed; and
4. where endpoint facts, diagnostics, and typed evidence are created or merged.

The source is authoritative. Coordinates use `module.symbol`, so searching for
an exact Python symbol in this file leads to its contract even when multiple
modules use helper names such as `_resolve_path()` or `_deduplicate()`.

## 1. Reading conventions

### 1.1 Common data shapes

| Shape | Meaning while reading the call graphs |
|---|---|
| `unit` | One already-parsed Java compilation unit: exact source bytes, Tree-sitter nodes, imports, lexical type records, and query captures. |
| `workspace` | The shared parse-once workspace and its cross-file indexes. Spring passes consume the same node identities. |
| `MethodFact` / `MethodIndex` | Normalized source method identity and lookup tables produced by `java_methods`; used by DSL and reflection analyzers. |
| decoded MVC `mapping` | A dictionary containing `paths`, `methods`, `valid`, `annotation_node`, and, for evidence-producing mappings, `annotation_identity` and `annotation_family`. |
| `EndpointFact` | An immutable rich endpoint before configured-path rewriting and the lossy CSV boundary. Route, handler, project, annotation, and represented-target provenance remain distinct. |
| `spring_clients._ClientCandidate` | A client-local pair of raw `EndpointFact` and optional HTTP Interface lexical path layers; configured ordinary facts leave the client pass. |
| `SpringAnnotationState` | Spring-owned composed-definition support cache shared by broad and final annotation recognition. |
| `None` | Usually “not proved” or “not recognized.” At first-mapping boundaries, a recognized-invalid mapping is instead returned with `valid=False` so a later annotation cannot replace it. |
| empty tuple/list | A successful pass or branch that emitted no additions. It does not remove facts emitted by another analyzer. |

### 1.2 Invariants shared by these modules

- Parsing is outside every Spring analyzer. The analyzers receive the shared
  workspace and never construct another parser.
- Name resolution proves genuine framework identity through imports, source
  declarations, accessibility, and shadowing rules. A matching simple name is
  insufficient.
- Static strings are resolved by the shared bounded workspace resolver. These
  modules do not execute Java.
- Candidate uncertainty normally fails closed at the smallest safe boundary.
  An unexpected Python exception is different: it escapes and aborts the run.
- Each created `EndpointFact` is immutable. Configuration uses
  `dataclasses.replace()` rather than mutating it.
- `source_line` is diagnostic context. The CSV annotation-line value comes
  only from validated `annotation_evidence` at the later output boundary.
- Diagnostic recording is the usual side effect. Neutral annotation
  definitions are already present when Spring starts; the composed-definition
  support cache belongs to `SpringAnnotationState`, and configuration loading
  is the family's deliberate filesystem read. The Java workspace stays neutral.

## 2. End-to-end Spring call graph

`spring_framework.analyze_spring_framework()` is the production facade for the
focused Spring modules and fixes their ordering:

```mermaid
flowchart TD
    P["spring_framework.analyze_spring_framework<br/>(request, source paths, workspace, state)"] --> D["for each unit:<br/>spring_mvc.analyze_direct_spring_mvc_unit"]
    D --> R["spring_route_registrations.<br/>analyze_spring_route_registrations"]
    R --> H["spring_mvc_hierarchy.<br/>analyze_spring_mvc_hierarchy"]
    H --> G["spring_gateway.<br/>analyze_spring_gateway"]
    G --> S["spring_config.<br/>analyze_spring_resource_handlers"]
    S --> B["spring_config.<br/>build_spring_path_configuration"]
    B --> C["spring_clients.<br/>analyze_spring_http_clients(workspace, configuration)"]
    C --> W["spring_websocket_messaging.<br/>analyze_spring_websocket_and_messaging"]
    W --> A["spring_config.<br/>apply_spring_path_configuration<br/>to server and messaging batches"]
    A --> O["configured tuple[EndpointFact, ...]"]
```

The server stages first collect raw facts. Clients need project configuration
to resolve each lexical path before returning ordinary facts; messaging needs
it to group STOMP prefixes by project. The final configuration calls rewrite
only the raw server and messaging batches. The result retains the established
server/client/messaging order, with configuration applied once per fact.
Configuration-load diagnostics appear before client extraction; client builders
still record their raw candidate paths before local resolution or rejection.

The optional `GatewayPathResolver` callback is useful to standalone callers of
`analyze_spring_gateway()`. The production facade does not pass it; Gateway
facts join the common one-time configuration stage instead.

## 3. `spring_mvc.py`: direct mappings and composed annotations

### 3.1 Direct-MVC call graph

```mermaid
flowchart TD
    A["analyze_direct_spring_mvc_unit(unit, workspace)"] --> T["first_spring_mapping(type annotations)"]
    A --> M["first_spring_mapping(method/component annotations)"]
    T --> F["compose_lexical_type_mapping"]
    M --> B["decode_builtin_spring_mapping"]
    M --> C["decode_spring_composed_mapping"]
    B --> P["get_spring_annotation_paths"]
    B --> V["get_spring_request_methods"]
    P --> SR["resolve_workspace_string_expression"]
    V --> MR["resolve_spring_request_method_expression"]
    F --> X["path Cartesian product + ordered method union"]
    X --> E["EndpointFact per path/method"]
    E --> AE["method_annotation_evidence_from_mapping<br/>(ordinary methods only)"]
    E --> RT["represented_target_evidence<br/>(method or record-component)"]
```

### 3.2 Direct mapping contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_mvc.resolve_spring_mapping_name()` | Built-in decoders and component filtering; annotation name node → built-in simple name or `None`. | Accepts only an exact FQN, exact import, or unambiguous genuine Spring wildcard import. Visible lexical types, package types, and wildcard collisions shadow the library name. No side effects. |
| `spring_mvc.get_spring_annotation_paths()` | Built-in and inventory-support decoders; annotation occurrence → `{values, unresolved, present}`. | Reconciles positional/`value`/`path`; aliases must resolve to the same ordered tuple. Any unresolved selected value removes the entire path fan-out. Values gain a leading slash and retain first-seen order. |
| `spring_mvc.resolve_spring_request_method_expression()` | Request-method and alias-value decoders; enum expression → canonical verb or `None`. | Accepts only genuine `RequestMethod` members through qualified identity or unambiguous static import. It does not infer from the token alone. |
| `spring_mvc.get_spring_request_methods()` | Built-in and inventory-support decoders; `RequestMapping` occurrence → `{values, unresolved, present}`. | Absent/empty `method` is unconstrained. It preserves valid members while reporting invalid spellings to its caller; all-invalid explicit values can invalidate the mapping. |
| `spring_mvc.ordered_http_methods()` | Method decoders and composers; iterable → unique verbs in `SPRING_HTTP_METHODS` order. | Deterministic pure helper; unsupported tokens are omitted because callers prove them first. |
| `spring_mvc.union_request_method_conditions()` | Direct, hierarchy, and Feign composition; type and method lists → stable ordered union. | Empty side is neutral. This is Noir's deliberate union model, not Spring runtime intersection. |
| `spring_mvc.log_unresolved_mapping()` | `decode_builtin_spring_mapping()`; source/owner/kind/expressions → no return value. | Adds one run diagnostic per unresolved expression; does not raise or edit mappings. |
| `spring_mvc.decode_builtin_spring_mapping()` | `first_spring_mapping()`, hierarchy, and Feign; one annotation → mapping dictionary or `None`. | `None` means not a genuine built-in. A recognized annotation returns a mapping even when invalid. Fixed verbs come from shortcut identity; `RequestMapping` verbs are decoded. It attaches canonical identity/family for later evidence. |
| `spring_mvc.first_spring_mapping()` | Direct type/method/component analysis; captured annotations → first mapping or `None`. | Sorts by annotation source position, tries built-in then composed decoding, and stops on the first recognized result. Recognized-invalid therefore suppresses later valid annotations on the declaration. |
| `spring_mvc.compose_lexical_type_mapping()` | Direct method/component analysis; owner key plus local type-info copy → composed type paths/methods or `None`. | Walks outer-to-inner lexical types. Missing mapping is neutral; one recognized-invalid layer suppresses every descendant target. Paths form a Cartesian product and methods use ordered union. |
| `spring_mvc.spring_method_applicable_component_candidates()` | Record-component branch; captured component annotations → filtered captures. | Built-ins are accepted; source annotations must resolve and be applicable to `METHOD`. It prevents an annotation that can only target a component/field from being reinterpreted as the implicit accessor's method annotation. |
| `spring_mvc.analyze_direct_spring_mvc_unit()` | Production Spring loop; one unit plus shared workspace → tuple of direct facts. | Copies `type_infos` before attaching analysis-local mappings. Concrete workspace-visible ordinary methods and eligible implicit record accessors fan out over lexical/type/method paths and verbs. Abstract/invisible owners, explicit accessors, absent/invalid mappings, or invalid lexical layers skip only the target. Every fact is diagnosed. It performs no local deduplication. |

For an ordinary method, `analyze_direct_spring_mvc_unit()` fills request
parameters from raw parameter-list source text, creates annotation evidence
from the selected mapping, and represents the exact method span. For an
implicit record accessor it emits empty parameters, deliberately no method
annotation evidence, and represents the record-component span.

### 3.3 Composed-annotation and `AliasFor` call graph

```mermaid
flowchart TD
    I["workspace annotation_definitions"] --> SD["source_annotation_definition"]
    U["decode_spring_composed_mapping(applied annotation)"] --> SD["source_annotation_definition"]
    SD --> BR["collect_spring_mapping_branches"]
    BR -->|recursive meta-annotations| BR
    BR --> RR["spring_definition_runtime_retained"]
    RR --> LF["decode_builtin_spring_mapping(RequestMapping leaf)"]
    LF --> PE["parse_spring_alias_edge(each element)"]
    PE --> AT["resolve_spring_alias_terminal"]
    AT -->|custom branch edge| AT
    AT --> TV["type/cardinality/ignored-target validators"]
    TV --> IV["annotation_instance_values(each layer)"]
    IV --> DV["decode path/method explicit values or defaults"]
    DV --> OV["inner-to-outer override fold"]
    OV --> CM["canonical mapping using outer applied node + FQN"]

    INV["annotation inventory"] --> SUP["spring_composed_definition_is_supported"]
    SUP --> BR
    SUP --> PE
    SUP --> AT
```

### 3.4 Composed mapping contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_mvc.spring_definition_runtime_retained()` | Composed use/support validation; definition → boolean. | Requires exactly one genuine `java.lang.annotation.Retention` and a provable `RUNTIME` value. |
| `spring_mvc.resolve_spring_mapping_spelling()` | Meta-annotation traversal and class-literal resolution; spelling → built-in name or `None`. | Same collision-safe identity policy as direct annotation resolution, but operates on stored spelling/context. |
| `spring_mvc.source_annotation_definition()` | Composed decoder, traversal, and component applicability; applied name → status plus definition. | Distinguishes `none`, `missing`, `ambiguous`, `inaccessible`, and `resolved`. Only one source identity, one declaration, and accessible ownership produce `resolved`. |
| `spring_mvc.source_annotation_is_method_applicable()` | Component filtering; annotation occurrence → boolean. | Resolves one source definition and delegates genuine `@Target` semantics to the workspace helper. |
| `spring_mvc.collect_spring_mapping_branches()` | Composed decoder and inventory validator; definition → branches plus errors. | Recurses through source meta-annotations to a `RequestMapping` leaf, rejects cycles and depth beyond `SPRING_MAX_COMPOSED_ANNOTATION_DEPTH`, and rejects verb shortcuts used as annotation-declaration leaves. Unrelated meta-annotations are ignored. |
| `spring_mvc.resolve_alias_annotation_target()` | Alias edge parser; `AliasFor.annotation` value → target FQN or `None`. | Requires a class literal naming one genuine built-in or one accessible, unique source annotation. |
| `spring_mvc.parse_spring_alias_edge()` | Terminal resolution and definition validation; one annotation element → typed edge status. | Requires exactly one genuine `AliasFor`; validates positional/named argument grammar, reciprocal names, static String resolution, and annotation target. It returns `none`, `resolved`, or `invalid` with a reason. |
| `spring_mvc.resolve_ignored_sibling_alias_target()` | Terminal resolver; off-branch custom target → ignored-custom terminal or invalid. | Allows only one accessible runtime-retained direct sibling meta-annotation with one non-recursive target element and a valid fixed occurrence. The value is validated but excluded from route identity. |
| `spring_mvc.resolve_spring_alias_terminal()` | Composed decoder/support validator; definition element plus branch maps → terminal status. | Recursively follows alias edges; rejects element cycles, outer-directed edges, missing/ambiguous elements, incompatible shapes, and non-reciprocal local pairs. Canonical route terminals are `path` or `method`; known non-route RequestMapping and bounded custom terminals are validated then marked ignored. |
| `spring_mvc.annotation_instance_values()` | Composed use and sibling validation; definition plus occurrence → explicit element map or error. | Binds positional input to `value`, rejects unknown/duplicate forms, and requires a value/default for every required element. It does not decode the values. |
| `spring_mvc.decode_spring_alias_path_value()` | Composed value fold; value expression → ordered tuple or `None`. | Every array member must statically resolve as a String; one unresolved member rejects the selected value. |
| `spring_mvc.decode_spring_alias_method_value()` | Composed value fold; value expression → method tuple or `None`. | Every member must be a genuine Spring `RequestMethod` expression. |
| `spring_mvc.invalid_spring_composed_mapping()` | Composed decoder error branches; applied node → `valid=False` mapping. | Encodes “recognized but invalid,” preserving first-recognized suppression without fabricating identity/evidence. |
| `spring_mvc.log_spring_composed_issue()` | Composed decoder; context plus reason → no return value. | Records a candidate-scoped diagnostic only. |
| `spring_mvc.decode_spring_composed_mapping()` | `first_spring_mapping()`, hierarchy, and Feign; applied source annotation → mapping, invalid mapping, or `None`. | Requires one accessible definition, exactly one bounded branch, runtime retention on every custom layer, a valid leaf, coherent alias terminals/types/defaults, and coherent instance values. It folds fixed leaf then inner-to-outer custom layers, with explicit values before defaults. On success, path/method overrides replace the leaf and evidence identity/node become the outer applied annotation. |
| `spring_mvc.spring_composed_definition_is_supported()` | Spring annotation callbacks; source definition and optional cache → boolean. | Repeats definition-level graph, leaf, edge, type/default, and fixed intermediate-instance validation but intentionally does not validate an outer consumer occurrence. Seeds `False` before recursion and caches a final `True` in the caller's `SpringAnnotationState.definition_support`; standalone calls use a fresh local cache. |

### 3.5 Alias validation helpers

These helpers are small, but they are important when diagnosing why an
otherwise plausible composed mapping failed:

| Coordinate | Exact responsibility |
|---|---|
| `spring_mvc.decode_alias_string()` | Resolve an alias attribute name with shared String semantics. |
| `spring_mvc.spring_alias_element_type_valid()` | Require `String`/`String[]` for a path terminal or `RequestMethod`/array for a method terminal. |
| `spring_mvc.spring_alias_non_output_type_valid()` | Validate String shape for route-neutral RequestMapping attributes. |
| `spring_mvc.spring_alias_value_cardinality_valid()` | Reject an array initializer flowing into a scalar element; arrays accept scalar or array input. |
| `spring_mvc.spring_alias_known_type_shape()` | Canonicalize supported primitive, String, and RequestMethod scalar/array shapes. |
| `spring_mvc.spring_alias_custom_types_compatible()` | Permit equal shapes and scalar-to-array flow, but not array-to-scalar flow. |

## 4. `spring_mvc_hierarchy.py`: binding contracts to implementations

### 4.1 Call and data graph

```mermaid
flowchart TD
    E["analyze_spring_mvc_hierarchy(workspace)"] --> C["SpringMvcHierarchyAnalyzer(workspace)"]
    C --> A["analyze"]
    A --> R["_is_direct_mvc_controller(root)"]
    R --> CE["_controller_hierarchy_endpoints(root)"]
    CE --> HC["JavaSourceHierarchyGraph._build_hierarchy_context"]
    HC --> SG["_all_signatures"]
    SG --> IM["_implementation(signature)"]
    IM --> MS["_resolve_mapping_source"]
    MS --> IB["_interface_mapping_branches"]
    MS --> MM["_method_mapping / _type_mapping caches"]
    MM --> DA["_decode_annotations"]
    DA --> MVC["built-in or composed MVC decoder"]
    MVC --> PC["controller type + contract type + method conditions"]
    PC --> F["EndpointFact attributed to concrete implementation"]
```

### 4.2 Method contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer.__init__()` | Public wrapper; workspace → analyzer instance. | Builds one neutral `JavaSourceHierarchyGraph` and per-instance type/method mapping caches. It does not emit facts. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._is_direct_mvc_controller()` | `analyze()`; type record → boolean. | Requires a concrete, workspace-visible class and a genuine direct `Controller` or `RestController`. Records, composed stereotypes, and inherited stereotypes do not activate this pass. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._decode_annotations()` | Mapping caches; declaration annotations → first mapping or `None`. | Source-orders direct annotations and applies the same built-in-then-composed, recognized-invalid-first behavior as direct MVC. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._method_mapping()` | Source/implementation selection; exact method → cached mapping. | Cache key is the exact method identity, not its name. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._type_mapping()` | Controller/contract composition; type → cached mapping. | Cache key is the source FQN and only direct type annotations participate. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._interface_mapping_branches()` | `_resolve_mapping_source()`; adapted interface state and erased signature → candidate origins plus blocked flag. | Bounded recursive traversal rejects cycles/depth overflow, inaccessible types/methods, duplicate matching declarations, invalid interface edges, and ambiguous paths. Memoization is local to one resolution. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._resolve_mapping_source()` | Controller endpoint loop; implementation/signature/hierarchy → one mapped declaration/environment or `None`. | A direct mapping on the concrete root is left to direct MVC. Otherwise it prefers an eligible mapped implementation, then the nearest accessible abstract-class contract, then one maximally specific interface origin. Blocked or competing origins skip the signature. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._all_signatures()` | Controller endpoint loop; hierarchy context → erased signatures plus unresolved names. | Walks class states and bounded interface states with generic environments. If any declaration of a method name cannot produce an erased signature, every same-name signature is conservatively skipped. Nested `add_methods()` and `visit()` own collection and cycle avoidance. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._implementation()` | Controller endpoint loop; signature/hierarchy → one concrete/default implementation state or `None`. | Chooses the first usable class implementation, otherwise one maximally specific default interface method. Private/static/abstract/bodyless or ambiguous candidates fail that signature. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._mapping_conditions()` | Controller endpoint loop; optional mapping → path/method layer or `None`. | Absence is neutral `([""], [])`; recognized-invalid suppresses; valid values are copied. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer._controller_hierarchy_endpoints()` | `analyze()`; activated controller root → additions. | Requires a complete hierarchy. For each sound signature it binds implementation and mapping source, composes controller type, contract-owner type, and method layers, then creates facts. Handler/source/parameters/target come from the implementation; route provenance comes from the contract; project provenance comes from the root. Cross-method mapping evidence is deliberately empty. |
| `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer.analyze()` | Public wrapper; analyzer state → tuple of facts. | Iterates source FQNs deterministically and analyzes only activated roots. Diagnostics and instance caches are the only effects. |
| `spring_mvc_hierarchy.analyze_spring_mvc_hierarchy()` | Pipeline; workspace → tuple of hierarchy additions. | Constructs one analyzer and returns `analyze()`. It never suppresses direct facts already collected. |

The smaller hierarchy guards are still searchable here:
`SpringMvcHierarchyAnalyzer._log()` records root-scoped rejection;
`SpringMvcHierarchyAnalyzer._is_mapping_contract_type()` admits interfaces and
abstract classes; `SpringMvcHierarchyAnalyzer._type_accessible()` and
`SpringMvcHierarchyAnalyzer._method_accessible()` enforce source accessibility;
and `SpringMvcHierarchyAnalyzer._implementation_usable()` requires a concrete
instance body (or an interface default body).

## 5. `spring_route_registrations.py`: functional and imperative MVC DSLs

This module builds one `MethodIndex`, runs two independent analyzers, appends
their facts, and performs analyzer-local evidence-preserving deduplication.

### 5.1 Functional route call graph

```mermaid
flowchart TD
    E["analyze_spring_route_registrations"] --> IX["_build_method_index(workspace)"]
    IX --> AF["_analyze_functional_routes"]
    AF --> AG["owner + unique source + @Bean + RouterFunction family"]
    AG --> RET["_single_direct_return"]
    RET --> EX["_decode_functional_expression"]
    EX --> DR["route(predicate, handler)"]
    EX --> AR["andRoute(...)"]
    EX --> NE["nest(...)"]
    EX --> BU["_decode_builder -> _decode_builder_chain"]
    DR --> PR["_decode_predicate"]
    AR --> PR
    NE --> SP["_decode_selecting_predicate(path)"]
    BU --> BA["_decode_builder_route_arguments"]
    PR --> SP
    SP --> NP["_is_route_identity_neutral_predicate"]
    DR --> HD["_decode_handler"]
    AR --> HD
    BA --> HD
    HD --> HB["_bind_this_handler when exact"]
    EX --> EP["_handler_endpoint"]
    EP --> F["EndpointFact + represented method target"]
```

### 5.2 Functional route contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_route_registrations._known_direct_annotation()` | Both analyzer families; declaration plus expected identity → the unique annotation or `None`. | Requires exactly one genuine direct annotation. Optional `marker_only` also rejects annotation arguments. |
| `spring_route_registrations._owner_is_concrete_class()` / `spring_route_registrations._owner_is_unique()` | Publisher/configuration gates; `MethodFact` → boolean. | Separate concrete visibility from exact one-declaration attribution. Failure skips that owner method before DSL decoding. |
| `spring_route_registrations._call_has_owner()` | Functional and mapping-info decoders; invocation/member/expected FQN → boolean. | Proves a qualified type receiver or exact/unambiguous static import. `_unqualified_static_member_resolves()` rejects lexical source methods and ambiguous wildcard owners; `_method_variable_names()` prevents receiver/type shadowing. |
| `spring_route_registrations._router_function_family()` | Functional publisher gate; return type → `servlet`, `webflux`, or `None`. | Resolves the raw generic return type to exactly one supported Spring package. |
| `spring_route_registrations._single_direct_return()` | Functional publisher gate; `MethodFact` → returned expression or `None`. | Requires exactly one return in the entire body and requires it to be a direct top-level statement. Failure rejects the publisher. |
| `spring_route_registrations._direct_variable_initializer()` | Neutral predicate validation; field name/type → one initializer or `None`. | Deliberately recognizes only a uniquely declared typed `final` owner field; this is not general Java data flow. |
| `spring_route_registrations._is_route_identity_neutral_predicate()` | Selecting/builders; predicate node → boolean. | Allows proven non-path/non-method `RequestPredicates` calls, bounded `and`/`or`/`negate`, and one safe final-field indirection. Any extra path/method selector, shadowing, cycle, or depth over 16 fails the route expression. |
| `spring_route_registrations._bind_this_handler()` | Handler decoder; method reference → exact `MethodFact` or `None`. | Requires `this::name`, exactly one same-owner source method, one formal parameter, and non-static identity. Overload ambiguity declines attribution. |
| `spring_route_registrations._decode_handler()` | Route/builder decoders; handler expression → `(valid_shape, exact_handler_or_None)`. | Lambdas and method references through a local receiver prove publication but fall back to publisher attribution. A missing same-owner `this::name` is invalid; an existing but ambiguous overload is valid without exact attribution. |
| `spring_route_registrations._decode_selecting_predicate()` | Predicate/nest decoders; selector expression → static path or `None`. | Peels bounded `.and(neutral)` suffixes, proves the fixed selector's Spring owner, requires one argument, then resolves the path. |
| `spring_route_registrations._decode_predicate()` | Direct `route`/`andRoute`; node → `(fixed_verb, path)` or `None`. | The root selector must be one of the seven supported functional verbs; all identity-neutral suffixes are validated by the selecting decoder. |
| `spring_route_registrations._decode_builder_route_arguments()` | Builder walker; fixed-verb call → `(path, handler)` or `None`. | Accepts `(path, handler)` or `(path, neutral_predicate, handler)` only. Path and handler must both be sound. |
| `spring_route_registrations._decode_builder_chain()` | `_decode_builder()` and recursive nested blocks; fluent node → `(valid, routes)`. | Validates `RouterFunctions.route()` root, fixed-verb stages, and `nest(path(...), alias -> block)` statements. Shared budget rejects over 256 visited steps, nesting beyond 16, or over 4096 emitted builder routes. Any unsupported builder statement rejects that builder expression. |
| `spring_route_registrations._decode_builder()` | Functional expression decoder; terminal `build()` → decoded routes. | Requires zero arguments and delegates the receiver chain to the bounded builder walker. |
| `spring_route_registrations._decode_functional_expression()` | Functional publisher; return expression → `(valid, routes)`. | Recursively handles direct `route`, `andRoute`, direct `nest`, and builder `build`. Direct nest depth is bounded at 16. Unsupported grammar rejects the publisher expression; it does not guess partial identity. |
| `spring_route_registrations._handler_endpoint()` | Functional and programmatic branches; verb/path/handler/publisher/route node → fact. | Attributes the public row and represented target to an exact handler when available, otherwise the publisher. Route/project provenance stays on the publisher. Registration calls have empty annotation evidence. It records the emitted fact. |
| `spring_route_registrations._analyze_functional_routes()` | Public entry; workspace/index → facts. | Applies unique concrete owner, exact `@Bean`, `RouterFunction` family, direct-return, and expression gates. A rejected expression drops that publisher; each decoded route becomes a fact. |

The remaining functional helpers are deliberately narrow:
`spring_route_registrations._log()` records a scoped diagnostic;
`spring_route_registrations._resolve_path()` delegates String resolution then
normalizes; and `spring_route_registrations._lambda_parameter_and_body()`
accepts the one inferred alias/body form used by nested builders.

### 5.3 Programmatic registration call graph

```mermaid
flowchart TD
    E["analyze_spring_route_registrations"] --> AP["_analyze_programmatic_mvc_registrations"]
    AP --> OG["unique concrete @Configuration owner"]
    OG --> AM["_analyze_programmatic_registration_method"]
    AM --> MG["non-static void + marker @Autowired + one mapping parameter"]
    MG --> CF["no unregister, nested call, control flow, or tracked mutation"]
    CF --> LC["collect direct typed locals and direct registerMapping calls"]
    LC --> RA["_resolve_local_argument"]
    RA --> MI["_decode_request_mapping_info"]
    RA --> RM["_decode_reflected_method"]
    RM --> CT["canonical source/reflection parameter types"]
    MI --> X["paths × methods"]
    CT --> X
    X --> HE["_handler_endpoint(exact reflected handler, registration publisher)"]
```

### 5.4 Programmatic registration contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_route_registrations._resolve_source_type()` | Reflection and handler checks; type node → one accessible source FQN or `None`. | Duplicate, external-only, unresolved, or inaccessible owners are not reflected handlers. |
| `spring_route_registrations._canonical_named_type()` | Canonical parameter decoder; named type → comparable FQN or `None`. | Prefers one source identity, then exact imports, explicit lower-case-qualified external names, or a bounded `java.lang` set. Ambiguous relative nested names fail closed. |
| `spring_route_registrations._canonical_type()` | Reflection decoder; Java type plus varargs flag → canonical scalar/array spelling or `None`. | Recurses through arrays and handles primitive, named, and varargs shapes without class loading. |
| `spring_route_registrations._class_literal_type()` | Reflection decoder; `T.class` → canonical parameter type or `None`. | Requires a class literal with exactly one type child. |
| `spring_route_registrations._decode_reflected_method()` | Registration-call decoder; `Class.getMethod(...)` → `(exact MethodFact, target FQN)` or `None`. | Resolves one concrete source class, nonempty static method-name String, canonical class-literal parameters, and exactly one public non-static matching overload. |
| `spring_route_registrations._decode_request_mapping_info()` | Registration-call decoder; builder expression → `(paths, methods)` or `None`. | Accepts only `RequestMappingInfo.paths(...)[.methods(...)].build()`. Every path and genuine request method must resolve; no paths rejects; absent methods becomes `ANY`. |
| `spring_route_registrations._mapping_invocations()` | Registration method gate; mapping parameter/name → matching receiver calls. | Finds calls anywhere first, allowing the caller to distinguish absence from nested/control-flow use. |
| `spring_route_registrations._has_tracked_mutation()` | Registration method gate; tracked names and accepted locals → boolean. | Rejects reassignment/update and ambiguous nested redeclaration of every relevant local or formal parameter. |
| `spring_route_registrations._resolve_local_argument()` | Per-call decoder; argument, expected kind, local table, call position → inline expression or `None`. | A non-identifier passes through. An identifier must name one earlier direct local of the exact tracked kind. |
| `spring_route_registrations._is_programmatic_registration_owner()` | Owner cache; `MethodFact` → boolean. | Requires a concrete owner and exactly one genuine direct `Configuration`. |
| `spring_route_registrations._analyze_programmatic_registration_method()` | Programmatic owner loop; workspace/index/method → facts. | Method-level gates require non-static textual `void`, marker-only `Autowired`, exactly one genuine mapping parameter, no unregister, no modeled control flow, only direct calls, and stable locals/parameters. Once those pass, malformed sibling calls are diagnosed and skipped independently. A valid call must reconcile mapping info, reflected method, and a handler formal of the same source type. |
| `spring_route_registrations._analyze_programmatic_mvc_registrations()` | Public entry; workspace/index → facts. | Caches owner eligibility by FQN and analyzes every method of an eligible unique configuration owner. |
| `spring_route_registrations._deduplicate()` | Public entry; registration facts → tuple. | Groups on route, verb, parameters, public source/line, and handler; delegates to `deduplicate_endpoint_facts()` so represented targets are unioned. |
| `spring_route_registrations.analyze_spring_route_registrations()` | Pipeline; workspace → tuple of functional plus programmatic facts. | Builds one varargs-aware method index, executes the two branches in order, and locally deduplicates. Only diagnostics are externally visible side effects. |

Small data-flow helpers are `spring_route_registrations._local_declarators()`
(declarators in one local statement),
`spring_route_registrations._tracked_local_kind()` (mapping-info versus reflected
method), and `spring_route_registrations._direct_expression()` (one direct
expression statement).

## 6. `spring_clients.py`: outbound HTTP Interface and Feign contracts

### 6.1 Branch graph

```mermaid
flowchart TD
    E["analyze_spring_http_clients"] --> U["unique visible source interfaces"]
    U --> HI["_http_interface_endpoints"]
    U --> FE["_feign_endpoints"]
    HI --> TE["lexical type-level HttpExchange layers"]
    TE --> ME["direct method Exchange annotations"]
    ME --> DE["_decode_exchange_mapping"]
    DE --> DP["_decode_exchange_paths"]
    DE --> DM["_decode_exchange_methods"]
    DP --> PL["local _ClientCandidate.path_layers"]
    DM --> UF["_union_exchange_methods"]
    FE --> FM["one direct FeignClient marker"]
    FM --> TM["first MVC mapping per lexical type"]
    TM --> MM["all MVC mappings per direct method"]
    MM --> MVC["built-in/composed MVC decoders"]
    PL --> EP["_endpoint"]
    UF --> EP
    MVC --> EP
    EP --> DD["_deduplicate local candidates"]
    DD --> CFG["resolve HTTP Interface layers or Feign path"]
    CFG --> OUT["configured tuple[EndpointFact, ...]"]
```

### 6.2 Method contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_clients._resolved_exchange_annotations()` | HTTP Interface type/method loops; declaration → genuine direct Exchange records and names. | Lookalikes are ignored; only the exact `org.springframework.web.service.annotation` family participates. |
| `spring_clients._resolve_string_values()` | Exchange path/method decoding; annotation value → ordered tuple or `None`. | Resolves every recovered array member. One unresolved value rejects that attribute; an empty recovered value becomes one empty string. |
| `spring_clients._decode_exchange_paths()` | Exchange mapping decoder; annotation → paths or `None`. | Positional/`value`/`url` aliases must be syntactically valid and equal after resolution. Absolute URLs and leading placeholders remain unprefixed; ordinary paths gain `/`. |
| `spring_clients._decode_exchange_methods()` | Exchange mapping decoder; annotation identity/occurrence → methods or `None`. | Fixed `*Exchange` annotations reject an explicit `method`. Generic `HttpExchange` accepts bounded uppercase HTTP tokens; absent/empty means unconstrained. |
| `spring_clients._decode_exchange_mapping()` | HTTP Interface extraction; proven annotation → mapping or `None`. | Rejects unknown named attributes, then combines path and method decoders and attaches canonical annotation identity/family. Route-neutral headers/media attributes are accepted but omitted from endpoint identity. |
| `spring_clients._union_exchange_methods()` | HTTP Interface composition; type/method verbs → ordered union. | Known Spring verbs use framework order; custom generic tokens follow lexically via `_ordered_methods()`. Empty side is neutral. |
| `spring_clients._http_interface_endpoints()` | Public client loop; one unique interface declaration → local candidates. | Walks lexical types; each layer may have at most one generic type-level `HttpExchange`. An invalid type layer rejects the interface branch. It visits direct usable methods only and decodes every genuine method mapping independently. Lexical and method path alternatives remain explicit candidate layer tuples until configuration resolves them; verbs default to `ANY`. |
| `spring_clients._resolved_feign_client_markers()` | Feign branch; interface type → genuine direct markers. | Marker attributes classify the contract but do not contribute paths. Exactly one marker is required by the caller. |
| `spring_clients._decode_mvc_mapping()` | Feign mapping selectors; one annotation record → MVC mapping or `None`. | Reuses the authoritative built-in/composed Spring mapping semantics. |
| `spring_clients._first_mvc_mapping()` | Feign lexical type loop; declaration → first recognized mapping or `None`. | Type layers use first-recognized semantics; a recognized-invalid type mapping rejects the Feign branch. |
| `spring_clients._all_mvc_mappings()` | Feign method loop; declaration → every recognized mapping. | Method annotations may fan out as separate endpoint mappings; invalid mappings are skipped independently by the caller. |
| `spring_clients._feign_endpoints()` | Public client loop; one interface declaration → local candidates. | Requires exactly one direct Feign marker, composes the first mapping on every lexical type layer, and applies every mapping on each direct usable method. It does not traverse interface inheritance or use Feign marker URL/path values. |
| `spring_clients._ClientCandidate` | Client builders → temporary Spring value. | Holds the raw fact and optional HTTP Interface path layers. Feign uses the composed fact path. It never leaves `analyze_spring_http_clients()`. |
| `spring_clients._endpoint()` | Both client branches; unit/method/mapping/path/verb/layers → local candidate. | Creates an outbound HTTP/client fact, exact mapping annotation evidence, exact represented method target, and raw-path diagnostic. It pairs the fact with HTTP Interface layers in `_ClientCandidate`; the common fact has no temporary client field. |
| `spring_clients._deduplicate()` | Public entry; client candidates → tuple. | Local identity includes route fields, client surface/direction, and lexical layers. Candidate collisions union fact evidence through `merge_endpoint_facts()` before path resolution. |
| `spring_clients.analyze_spring_http_clients()` | Spring facade; workspace/configuration → configured outbound facts. | Iterates FQNs deterministically, rejects duplicate declarations, and runs both branches for workspace-visible interfaces. After local deduplication it resolves HTTP Interface layers or the Feign path, diagnoses/drops invalid paths, and exports ordinary `EndpointFact` values with evidence intact. |

Supporting client symbols are `spring_clients._log()` (diagnostic),
`spring_clients._direct_methods()` (source-ordered direct declarations),
`spring_clients._usable_contract_method()` (exclude private/static),
`spring_clients._normalize_client_path()` (URL/placeholder-aware normalization),
`spring_clients._combine_client_paths()` (inner absolute URL wins), and
`spring_clients._ordered_methods()` (stable known-then-custom verb order).

## 7. `spring_config.py`: project paths and static resources

This module has two separate responsibilities: construct/apply immutable path
configuration, and extract `WebMvcConfigurer` static-handler routes.

### 7.1 Configuration data flow

```mermaid
flowchart TD
    B["build_spring_path_configuration(workspace, analysis_root)"] --> IR["_infer_project_root(each Java source)"]
    IR --> RC["_read_project_path_configuration(each root)"]
    RC --> PP["_parse_properties"]
    RC --> PY["_parse_mapping_yaml"]
    PP --> PC["SpringProjectPathConfiguration"]
    PY --> PC
    PC --> WC["SpringWorkspacePathConfiguration"]

    WC --> AP["apply_spring_path_configuration(raw facts, configuration)"]
    AP --> RP["resolve_spring_endpoint_path"]
    WC --> CP["resolve_spring_client_path_layers<br/>called inside client extraction"]
    CP --> PH["_resolve_placeholders per layer"]
    RP --> PH
    PH -->|resolved| RE["replace(fact, path=...) with evidence intact"]
    PH -->|invalid/exhausted| DR["diagnose and drop this fact"]
```

### 7.2 Configuration contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_config.SpringProjectPathConfiguration` | Project loader → immutable project record. | Holds canonical project root, all parsed placeholder values, the chosen server base, and loaded file names. |
| `spring_config.SpringWorkspacePathConfiguration` | Configuration builder → immutable run record. | Maps canonical source files to optional project roots and roots to project records. |
| `spring_config._infer_project_root()` | Configuration builder; source and analysis root → project `Path` or `None`. | Requires the source under the analysis root; prefers exactly one `src/main/java`, otherwise at most one `src`, otherwise the analysis root. Repeated markers are ambiguous. |
| `spring_config._parse_properties()` | Project loader; text → flat key/value dictionary. | Implements only non-comment lines with the first `=` or `:` separator. It deliberately does not emulate the full Java properties grammar. |
| `spring_config._strip_yaml_comment()` | YAML subset parser; line → uncommented line or `None`. | Tracks simple single/double quotes and rejects unterminated quotes. |
| `spring_config._split_yaml_mapping()` | YAML subset parser; stripped line → key/value tokens or `None`. | Splits at the first unquoted colon. |
| `spring_config._yaml_string()` | YAML subset parser; token → supported string or `None`. | Decodes JSON-style double quotes and YAML single-quote escaping; plain keys are bounded; null/boolean/float/collection/anchor/block forms are not path strings. |
| `spring_config._parse_mapping_yaml()` | Project loader; YAML text → flat dotted mapping or `None`. | Accepts mapping-only indentation with String/integer leaves. Tabs, sequences/doc markers, malformed nesting, anchors, and parsed profile-activation keys reject the whole file; unsupported scalar leaves are ignored. |
| `spring_config._read_project_path_configuration()` | Configuration builder; project root → project record. | Reads resource directories in documented precedence and each properties/YML/YAML file in order; unreadable or rejected files are diagnosed and skipped. Later parsed keys overwrite earlier values. WebFlux base path wins over servlet context path. This is filesystem I/O. |
| `spring_config.build_spring_path_configuration()` | Pipeline; workspace/root → workspace configuration. | Infers ownership for every compilation unit, logs ambiguous sources, loads each distinct root once in sorted order, and returns immutable records. It does not mutate the workspace. |
| `spring_config._resolve_placeholders()` | All path resolvers; path and values → substituted string or `None`. | Supports nested `${key}` and `${key:default}` with at most 100 substitutions and 8192 output characters. Missing keys without defaults become empty. Residual/malformed placeholders fail closed. |
| `spring_config.resolve_spring_endpoint_path()` | Common application and optional callbacks; path/source/configuration plus endpoint classification → path, unchanged path, or `None`. | Non-Spring/ineligible facts pass through. Eligible inbound HTTP and handshake paths receive the owning project's server base; message destinations and outbound clients do not. All eligible paths consume placeholders, then normalize and collapse slashes without damaging URL authorities. |
| `spring_config.resolve_spring_client_path_layers()` | Client analyzer; lexical layers/source/configuration → final path or `None`. | Resolves placeholders before composing each layer. Any inner absolute HTTP(S) URL resets all earlier lexical prefixes. Clients never receive the server base. |
| `spring_config.make_spring_path_resolver()` | Optional sibling integration; configuration → callback. | Nested `apply()` accepts a direct `source_file` or `unit`, removes diagnostic-only `owner_name`, forwards endpoint classification, and returns `None` when source ownership input is unusable. It captures but does not modify configuration. |
| `spring_config.apply_spring_path_configuration()` | Spring facade for raw server/messaging batches, and client analyzer for Feign paths; endpoint iterable/configuration → tuple. | Non-Spring facts pass unchanged. Spring facts use the common resolver with `project_source_file` before public source, diagnose/drop only unresolved facts, and `replace()` successful paths. Input facts remain unchanged; no client construction metadata is read. |

Pure normalization seams `spring_config._canonical_path()`,
`spring_config._normalize_optional_path()`, and
`spring_config._collapse_path_slashes()` respectively canonicalize filesystem
identity, preserve absolute URLs while normalizing optional prefixes, and
collapse repeated separators. `spring_config._log()` records configuration or
resource rejections.

### 7.3 Static-resource call graph and contracts

```mermaid
flowchart TD
    E["analyze_spring_resource_handlers"] --> IT["_iter_resource_handler_configurer_methods"]
    IT --> CG["unique concrete direct WebMvcConfigurer"]
    CG --> MG["canonical public instance void addResourceHandlers(registry)"]
    MG --> MU["_registry_is_mutated"]
    MU -->|stable| FI["find registry.addResourceHandler calls"]
    FI --> DC["direct top-level registration-chain gate"]
    DC --> AR["resolve every path argument independently"]
    AR --> F["EndpointFact: GET/static-handler/inbound"]
```

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_config._known_type()` | Resource configurer recognition; node/simple name → boolean. | Proves an exact type in Spring's MVC configuration package. |
| `spring_config._iter_resource_handler_configurer_methods()` | Resource analyzer; workspace → canonical configurer method tuples. | Requires one source declaration, concrete visible class, exactly one genuine direct `WebMvcConfigurer` interface, and a public non-static textual-`void` method with exactly one genuine `ResourceHandlerRegistry` formal. |
| `spring_config._invocation_name()` | Resource analyzer; invocation → method spelling. | Source-text helper only; it does not prove owner identity. |
| `spring_config._registry_is_mutated()` | Resource method gate; unit/body/parameter name → boolean. | Assignment or update of the exact registry parameter rejects that configurer method. |
| `spring_config.analyze_spring_resource_handlers()` | Pipeline; workspace → static-handler facts. | Finds exact-parameter `addResourceHandler` calls, requires each to belong to a direct top-level fluent registration statement, and resolves each argument independently. A bad argument is diagnosed without discarding good siblings. Each good path creates a `GET`/HTTP/static-handler/inbound fact with empty annotation evidence and the configurer method as represented target. |
| `spring_config._deduplicate()` | Resource analyzer; facts → tuple. | Groups route, method, parameters, source/line, and handler while unioning represented targets. |

## 8. `spring_gateway.py`: bounded Spring Cloud Gateway DSL

### 8.1 Call graph

```mermaid
flowchart TD
    E["analyze_spring_gateway"] --> IX["strict MethodIndex"]
    IX --> OG["_owner_is_unique_concrete_class"]
    OG --> VG["_validated_route_locator_builder_name"]
    VG --> PUB["_decode_route_locator_publisher"]
    PUB --> RL["one _decode_route_lambda per route call"]
    RL --> DP["_decode_predicate_chain"]
    RL --> HP["_decode_predicate_helper when direct chain fails"]
    HP --> DP
    DP --> IC["_invocation_chain"]
    DP --> PA["_resolve_path × _resolve_http_method"]
    PA --> GC["GatewayRouteConditions(paths, methods)"]
    GC --> EP["_endpoint per path/method"]
    EP --> DD["_deduplicate"]
```

### 8.2 Method contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_gateway.GatewayPathResolver` | Public type alias for optional integration callback. | Receives a path plus source/surface metadata and returns a resolved path or `None`. |
| `spring_gateway.GatewayRouteConditions` | Predicate decoder → immutable paths/methods tuple. | Represents only inbound identity; route ID, destination, and filters are excluded. |
| `spring_gateway._known_direct_annotation()` | Publisher gate; method and expected annotation → unique record or `None`. | Requires exactly one genuine direct annotation. |
| `spring_gateway._owner_is_unique_concrete_class()` | Public loop; workspace/publisher → boolean. | Requires one visible, non-abstract source class declaration matching the `MethodFact`. |
| `spring_gateway._single_direct_return()` | Publisher/helper decoders; method → expression or `None`. | Requires one direct top-level return. By default any nested return rejects; the outer publisher disables only the nested-return rejection so a rejected route lambda cannot erase valid siblings. |
| `spring_gateway._validated_route_locator_builder_name()` | Public loop; publisher → exact builder formal name or `None`. | Requires one direct genuine `Bean`, genuine `RouteLocator` return, and exactly one genuine `RouteLocatorBuilder` parameter. Other formals are tolerated. |
| `spring_gateway._decode_predicate_lambda_parameter()` | Route lambda decoder; lambda → one alias or `None`. | Accepts one inferred identifier or one explicitly typed genuine `PredicateSpec` formal. |
| `spring_gateway._resolve_path()` | Predicate chain; path expression → configured normalized path or `None`. | Resolves one static String, normalizes it, and optionally invokes `GatewayPathResolver`. Callback `None`, empty, or non-string results fail that route. |
| `spring_gateway._resolve_http_method()` | Predicate chain; enum expression → verb or `None`. | Proves one genuine `HttpMethod` or `RequestMethod`; `CONNECT` is valid only for `HttpMethod`. Ambiguous unqualified owners fail closed. |
| `spring_gateway._invocation_chain()` | Predicate decoder; fluent expression → root plus source-ordered calls or `None`. | Uses a 16-iteration receiver-chain bound and rejects malformed argument nodes or a chain that does not reach its root within that bound. |
| `spring_gateway._decode_predicate_chain()` | Direct/helper route decoder; expression/root alias → `GatewayRouteConditions` or `None`. | Accepts exactly `path`, `path.and.method`, or `method.and.path`. All trailing `filter`/`filters` calls must be consecutive and unary. Every path/method argument resolves; absent method becomes `ANY`. |
| `spring_gateway._decode_predicate_helper()` | Route lambda fallback; helper invocation → conditions or `None`. | Requires an unqualified/`this` same-owner call passing the exact lambda alias and exactly one uniquely indexed helper with genuine `PredicateSpec` input, genuine `BooleanSpec` output, and one direct return. |
| `spring_gateway._decode_route_lambda()` | Publisher decoder; route lambda → conditions or `None`. | Requires a supported single parameter and body ending in unary `uri(...)`. Destination expression is deliberately ignored. It tries a direct predicate chain, then the bounded helper branch. |
| `spring_gateway._route_lambda_argument()` | Publisher decoder; `route(...)` call → lambda or `None`. | Accepts one lambda or `(ignored route-id, lambda)`; dynamic route IDs are route-neutral. |
| `spring_gateway._decode_route_locator_publisher()` | Public loop; publisher/index/builder/callback → decoded route list or `None`. | Requires a direct `builder.routes().route(...).build()` chain with zero-argument terminals and a 256-iteration reverse-walk bound. Malformed outer publication rejects the publisher. An unsupported route lambda is diagnosed and skipped while valid siblings survive. |
| `spring_gateway._endpoint()` | Public loop; publisher/call/verb/path → fact. | Creates an inbound HTTP/gateway fact attributed to the `Bean` publisher, with empty parameters/annotation evidence and the publisher method as represented target; records a diagnostic. |
| `spring_gateway._deduplicate()` | Public entry; Gateway facts → tuple. | Groups route, method, parameters, source/line, and handler; unions typed targets. |
| `spring_gateway.analyze_spring_gateway()` | Pipeline or standalone caller; workspace plus optional resolver → tuple. | Builds a strict method index, applies publisher gates, fans out decoded conditions, creates facts, and locally deduplicates. |

`spring_gateway._log()` is the candidate-scoped diagnostic helper.

## 9. `spring_websocket_messaging.py`: handshakes, prefixes, and destinations

### 9.1 Branch graph

```mermaid
flowchart TD
    E["analyze_spring_websocket_and_messaging"] --> WH["_websocket_handler_handshake_endpoints"]
    E --> SH["_stomp_handshake_endpoints"]
    E --> MM["_message_mapping_endpoints"]
    WH --> WC["_websocket_handler_configurer_methods"]
    SH --> SC["_stomp_configurer_methods"]
    WC --> UC["_unique_concrete_configurers"]
    SC --> UC
    WH --> HF["_has_typed_websocket_handler_field"]
    WH --> RP["_resolved_paths"]
    SH --> RP
    MM --> PF["_stomp_application_prefixes"]
    PF --> SC
    MM --> CT["lexical controller marker + type MessageMapping paths"]
    CT --> MA["method MessageMapping / SubscribeMapping"]
    MA --> F["EndpointFact + annotation evidence + method target"]
    WH --> H["EndpointFact + empty annotation evidence + configurer target"]
    SH --> H
    F --> DD["_deduplicate"]
    H --> DD
```

### 9.2 Shared configurer and handshake contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_websocket_messaging._unique_concrete_configurers()` | STOMP/raw configurer iterators; workspace/interface → owner tuples. | Requires a unique, concrete, visible source class with exactly one genuine direct implementation of the requested configurer interface. |
| `spring_websocket_messaging._formal_parameter()` | Canonical method gate; method/type/package → `(name, parameters_node)` or `None`. | Requires exactly one uncommented formal of the genuine framework type. |
| `spring_websocket_messaging._canonical_method()` | Configurer iterators; method and expected signature → receiver/parameters/body or `None`. | Requires public, non-static, textual `void`, exact name, body, and exact one framework parameter. |
| `spring_websocket_messaging._receiver_mutated()` | Configurer iterators; method body and receiver name → boolean. | Assignment/update of the registry parameter invalidates that canonical hook. |
| `spring_websocket_messaging._receiver_calls()` | Handshake/prefix branches; exact receiver and call name → all matching invocations. | Finds calls irrespective of nesting so callers can explicitly reject hidden control flow. `_direct_receiver_calls()` filters that set through the common direct-statement gate. |
| `spring_websocket_messaging._stomp_configurer_methods()` | STOMP handshake/prefix branches; workspace → canonical hook tuples. | Yields both `registerStompEndpoints`/`addEndpoint` and `configureMessageBroker`/`setApplicationDestinationPrefixes`, including receiver mutation state. |
| `spring_websocket_messaging._websocket_handler_configurer_methods()` | Raw handshake branch; workspace → canonical hook tuples. | Yields canonical `registerWebSocketHandlers(WebSocketHandlerRegistry)` methods and mutation state. |
| `spring_websocket_messaging._direct_call_with_allowed_chain()` | Handshake/prefix gates; invocation/body/allowed suffixes → boolean. | Walks outward from a registry call, accepts only listed route-neutral fluent suffixes, and requires the final chain to be a direct body statement. `withSockJS` is not neutral and therefore fails. |
| `spring_websocket_messaging._handler_field_name()` | Raw handler validator; expression → `(field_name, explicit_this)` or `None`. | Accepts only an identifier or `this.field`. |
| `spring_websocket_messaging._has_typed_websocket_handler_field()` | Raw handshake branch; handler expression → boolean. | Requires exactly one owner field of genuine `WebSocketHandler` type. An unqualified reference fails if a local/formal/catch name shadows it; `this.field` remains explicit. |
| `spring_websocket_messaging._websocket_handler_handshake_endpoints()` | Public entry; workspace → raw handshake facts. | Requires a stable configurer, direct allowed `addHandler(handler, paths...)` chain, exact typed handler field, and all static paths. Each path creates `ws GET`/websocket-handshake/inbound fact with empty annotation evidence and the configurer method target. |
| `spring_websocket_messaging._stomp_handshake_endpoints()` | Public entry; workspace → STOMP handshake facts. | Applies the same stable/direct/allowed-chain/static-path gates to `addEndpoint`. Each path creates the same handshake classification and configurer target. |

Small shared helpers are
`spring_websocket_messaging._invocation_name()` (call spelling),
`spring_websocket_messaging._arguments()` (semantic arguments without
comments), and `spring_websocket_messaging._resolved_paths()` (all-or-nothing
static String resolution plus normalization).

### 9.3 Prefix and message contracts

| Coordinate | Caller; input → output | Decisions, effects, and failure boundary |
|---|---|---|
| `spring_websocket_messaging._project_key()` | Prefix/message branches; configuration and source → project key or `None`. | Uses configured canonical ownership; without configuration it falls back to the canonical source path. |
| `spring_websocket_messaging._stomp_application_prefixes()` | Message branch; workspace/configuration → valid prefix map plus invalid-project set. | Across each project, registry mutation, nested calls, more than one direct setter, or an unresolved/no-argument setter invalidate message prefix identity for that project. A canonical hook with no setter leaves the default empty prefix. |
| `spring_websocket_messaging._annotation_paths()` | Type/method message decoders; annotation → paths or `None`. | Accepts only positional/`value`/`path`, requires coherent aliases, and resolves every value. `empty_default=True` makes an argument-less type mapping neutral; a method mapping needs an explicit value group (an explicit empty String normalizes to the root, while an empty array emits no destination). |
| `spring_websocket_messaging._known_annotations()` | Controller/type/method decoders; query captures/names/package → resolved records. | Filters captures by genuine package identity while preserving source order. |
| `spring_websocket_messaging._lexical_controller_type_chain()` | Message branch; method owner key → outer-to-inner type records. | Thin named seam over shared lexical type traversal. |
| `spring_websocket_messaging._has_controller_marker_in_lexical_chain()` | Message branch; lexical chain → boolean. | Requires a genuine `Controller` or `RestController` on at least one lexical owner layer; no bean graph or inherited stereotype is inferred. |
| `spring_websocket_messaging._lexical_message_mapping_paths()` | Message branch; lexical chain → type-path fan-out or `None`. | Composes every genuine type-level `MessageMapping` in source order. One invalid annotation suppresses message facts below that chain. |
| `spring_websocket_messaging._message_mapping_endpoints()` | Public entry; workspace/configuration → message facts. | First builds project prefix state. It then visits concrete visible captured method owners in valid projects, requires lexical controller activation, composes project/type/method destinations, and emits `SEND` for `MessageMapping` or `SUBSCRIBE` for `SubscribeMapping`. Each fact has exact method annotation evidence and represented method target. |
| `spring_websocket_messaging._deduplicate()` | Public entry; all WebSocket/message facts → tuple. | Local identity includes protocol, surface, verb, path, source, handler, and parameters; the shared merge unions annotation/target evidence. |
| `spring_websocket_messaging.analyze_spring_websocket_and_messaging()` | Pipeline; workspace/configuration → tuple. | Runs raw handshakes, STOMP handshakes, then message destinations, and deduplicates their combined facts. |

## 10. Where facts and evidence are created and merged

### 10.1 Fact construction sites

There is no generic Spring endpoint builder because each source mechanism has
different attribution. These are all Spring construction sites in the seven
modules:

| Construction site | Public/route/handler/project attribution | Annotation evidence | Represented target |
|---|---|---|---|
| `spring_mvc.analyze_direct_spring_mvc_unit()` ordinary-method branch | All identities use the mapped method source; diagnostic line is the mapping annotation. | `method_annotation_evidence_from_mapping()` for the selected built-in or outer composed annotation. | Exact method span. |
| `spring_mvc.analyze_direct_spring_mvc_unit()` record-component branch | Public source is the record source; handler name is the implicit accessor. | Empty: a component annotation is not method-annotation evidence. | Exact record-component span. |
| `SpringMvcHierarchyAnalyzer._controller_hierarchy_endpoints()` | Public/handler identity is the concrete implementation; route identity is the mapped contract; project identity is the activated concrete controller root. | Mapping evidence only when mapping source and implementation are the exact same method. | Exact implementation method. |
| `spring_route_registrations._handler_endpoint()` | Public/handler is an exactly bound handler or the publisher fallback; route/project are the `Bean` or registration method. | Empty: path and verb came from calls, not a method annotation. | Effective handler method, including publisher fallback. |
| `spring_clients._endpoint()` | Public, route, handler, and project remain on the interface contract method. | Exact Exchange or MVC method mapping. | Exact interface method. |
| `spring_config.analyze_spring_resource_handlers()` | Public/route/handler use the configurer method/source. | Empty: registration invocation supplies route identity. | Exact `addResourceHandlers` method. |
| `spring_gateway._endpoint()` | All identities use the `RouteLocator` publisher; diagnostic route line uses the `route` call. | Empty: predicate calls supply route identity. | Exact publisher method. |
| `spring_websocket_messaging._websocket_handler_handshake_endpoints()` | Configurer method owns public, route, handler, and project identity. | Empty. | Exact raw WebSocket configurer method. |
| `spring_websocket_messaging._stomp_handshake_endpoints()` | Configurer method owns public, route, handler, and project identity. | Empty. | Exact STOMP configurer method. |
| `spring_websocket_messaging._message_mapping_endpoints()` | Annotated controller method owns public, route, handler, and project identity. | `method_annotation_evidence_from_node()` with the exact Message/Subscribe annotation identity and family. | Exact controller method. |

### 10.2 Evidence-preserving flow

```mermaid
flowchart LR
    S["Tree-sitter annotation/declaration node"] --> AE["AnnotationEvidence?<br/>same-file method annotations only"]
    S --> RT["SourceTarget?<br/>canonical file + kind + byte span"]
    AE --> F["immutable EndpointFact"]
    RT --> F
    F --> LD["analyzer-local _deduplicate"]
    LD --> ME["evidence.merge_endpoint_facts"]
    ME --> U["union annotation_evidence + represented_targets;<br/>retain newer non-evidence fields"]
    U --> CFG["apply_spring_path_configuration:<br/>replace path, preserve evidence"]
    CFG --> OUT["later output consolidation on public six-field identity"]
    OUT --> LINE["select annotation line from merged owned evidence"]
    OUT --> AUDIT["union represented targets for unmatched-annotation subtraction"]
```

The local deduplication functions in registrations, resources,
Gateway, and WebSocket/messaging pass analyzer-specific identity tuples to
`evidence.deduplicate_endpoint_facts()`. That helper delegates collisions to
`evidence.merge_endpoint_facts()`, which keeps the later fact's ordinary
fields but deterministically unions and revalidates both evidence collections.
Clients group their local candidates with lexical path layers included in the
identity and use the same `merge_endpoint_facts()` operation on collisions.
Direct MVC and MVC hierarchy return their facts without local deduplication;
cross-analyzer/public duplicates are handled later by output consolidation.

Configuration does not merge facts. It either preserves a non-Spring fact,
creates a Spring copy with a resolved path, or diagnoses and omits one
unresolved fact. Client-local path layers are consumed before ordinary client
facts leave their analyzer. Therefore a dropped fact's
represented target cannot make a failed endpoint appear represented in the
final annotations-without-endpoints report.

### 10.3 Why route, handler, and project sources travel separately

```mermaid
flowchart TD
    RD["route declaration"] --> RS["route_source_file / route_source_line"]
    HD["concrete or fallback handler"] --> PS["source_file + handler_name + parameters"]
    HD --> HS["handler_source_file / handler_source_line"]
    PJ["configuration owner"] --> PR["project_source_file"]
    RS --> F["EndpointFact"]
    PS --> F
    HS --> F
    PR --> F
    F --> C["configuration chooses project_source_file,<br/>else public source_file"]
    F --> O["output projects public source/method/parameters"]
```

This separation matters most for functional handlers and hierarchy contracts:
the file reported to the user may be the concrete handler, while the route
publisher selects Spring configuration ownership and the mapping declaration
supplies route provenance.

## 11. Worked method-to-output traces

### 11.1 Direct composed MVC method

1. `analyze_direct_spring_mvc_unit()` takes one captured method and calls
   `first_spring_mapping()`.
2. The built-in decoder returns `None`; `decode_spring_composed_mapping()`
   resolves the source definition, branch, alias terminals, and occurrence
   values.
3. The returned mapping retains final paths/methods but changes
   `annotation_node` and `annotation_identity` to the outer applied annotation.
4. `compose_lexical_type_mapping()` supplies outer-to-inner type layers.
5. The direct analyzer forms every path/method combination and creates a fact.
6. `method_annotation_evidence_from_mapping()` records the outer annotation's
   line and canonical identity; `represented_target_evidence()` records the
   method byte span.
7. `apply_spring_path_configuration()` resolves placeholders and prepends the
   owning server base without changing either evidence tuple.
8. Output consolidation may merge the row with another equal public identity;
   the annotation line is selected only after that merge.

### 11.2 Functional route with an exact `this::handler`

1. `analyze_spring_route_registrations()` builds one `MethodIndex`.
2. `_analyze_functional_routes()` proves the unique concrete `Bean`
   `RouterFunction` publisher and selects its one direct return.
3. `_decode_functional_expression()` proves the predicate path/verb and asks
   `_decode_handler()` to interpret the method reference.
4. `_bind_this_handler()` finds one non-static, one-parameter same-owner
   method, so `_handler_endpoint()` reports that handler's source, name, and
   parameters.
5. Route and project provenance still point to the `Bean` publisher. This
   ensures its project configuration is used even if the handler identity
   later differs.
6. The fact has no annotation evidence, but its represented target is the
   exact handler declaration.

If the reference is a valid lambda or local-receiver method reference, step 4
falls back to publisher attribution. If `this::name` names no source method,
the route expression is invalid; if overloads make exact binding ambiguous,
the route remains valid with publisher attribution.

### 11.3 Inherited MVC contract

1. `SpringMvcHierarchyAnalyzer.analyze()` selects a genuinely activated
   concrete controller root.
2. `_controller_hierarchy_endpoints()` builds a complete adapted hierarchy and
   obtains erased signatures from `_all_signatures()`.
3. `_implementation()` selects the concrete/default handler; then
   `_resolve_mapping_source()` selects the accessible abstract/interface
   declaration that owns the mapping.
4. Controller-type, contract-type, and method conditions compose into the
   public route.
5. The fact reports implementation source/name/parameters and represents the
   implementation span, while route provenance points to the contract.
6. A different contract method cannot populate the implementation row's CSV
   annotation line, so annotation evidence is empty unless the two exact
   method identities coincide.

### 11.4 HTTP Interface client with a configured absolute base

1. `_http_interface_endpoints()` decodes lexical type and direct method
   Exchange annotations.
2. `_endpoint()` pairs the raw outbound fact and its lexical choices in a
   Spring-local `_ClientCandidate`, retaining mapping evidence and the exact
   interface method target.
3. `_deduplicate()` includes those layers in candidate identity so distinct
   lexical choices cannot lose evidence before configuration is resolved.
4. `resolve_spring_client_path_layers()` resolves placeholders one layer at a time.
   If an inner resolved layer is an absolute URL, it resets outer prefixes.
5. `analyze_spring_http_clients()` replaces the raw fact's path and exports an
   ordinary `EndpointFact`; it never applies the inbound server base. The
   facade keeps these configured clients out of its later server/message path
   application.

## 12. Fail-closed scope and side-effect map

| Uncertainty or invalid state | Scope of suppression |
|---|---|
| Unresolved/invalid first direct MVC mapping or lexical type layer | One method/component target, or descendants below that invalid lexical layer. |
| Invalid composed use-site graph/value | That applied mapping target; the inventory can still recognize a valid definition independently. |
| Incomplete MVC type hierarchy | All hierarchy additions for that activated controller root; direct MVC facts remain. |
| Ambiguous hierarchy implementation or mapping origin | One erased signature. |
| Unsupported functional return expression or builder budget exhaustion | One `Bean` publisher. |
| Programmatic registration control flow, mutation, nested call, or bad activation | One registration method. |
| Malformed `registerMapping` arguments after method gates pass | One call; valid sibling calls survive. |
| Malformed Gateway outer publication chain | One `RouteLocator` publisher. |
| Unsupported Gateway route lambda | One route call; valid sibling route calls survive. |
| Mutated static-resource registry | One configurer method. |
| Unresolved static-resource path argument | One argument; other arguments survive. |
| Invalid HTTP Interface type layer | That interface's HTTP Interface branch. |
| Invalid HTTP Interface method annotation | That annotation mapping. |
| Invalid Feign lexical type mapping | That interface's Feign branch. |
| Invalid Feign method mapping | That mapping; valid method mappings survive. |
| Mutated WebSocket/STOMP registry or unsupported registration chain | Affected configurer method/call; no inferred alias flow. |
| Ambiguous/nested/multiple STOMP application-prefix setters | Message endpoints for that project; handshake facts remain independent. |
| Invalid lexical type message mapping | Message facts under that lexical chain. |
| Invalid/unresolved method destination | That annotation occurrence. |
| Unresolved configured placeholder/base | One final `EndpointFact`. |

| Operation | Observable effect |
|---|---|
| `spring_mvc.spring_composed_definition_is_supported()` | Reads/writes the supplied Spring annotation-state cache; standalone calls use local state. The neutral workspace is unchanged. |
| `SpringMvcHierarchyAnalyzer` mapping helpers | Fill only instance-local caches. |
| Every `_log()`/`log_*()` and successful fact builder | Appends text to the currently bound diagnostic collector. |
| `spring_config.build_spring_path_configuration()` | Reads supported configuration files; returns immutable data. |
| Extraction, deduplication, and configuration application | Return new tuples/facts; they do not write output artifacts. |

## 13. Complete symbol coverage index

The detailed tables above cover orchestration, emission, ambiguity gates, and
substantial decoders. This compact index includes every top-level function and
every class method in the seven semantic modules, plus their family facade, so
an exact symbol search never ends at module-level prose only.

| Module | Symbols present in this chapter |
|---|---|
| `spring_framework.py` | `spring_framework.analyze_spring_framework()`. |
| `spring_mvc.py` | `spring_mvc.resolve_spring_mapping_name()`, `spring_mvc.get_spring_annotation_paths()`, `spring_mvc.resolve_spring_request_method_expression()`, `spring_mvc.get_spring_request_methods()`, `spring_mvc.ordered_http_methods()`, `spring_mvc.union_request_method_conditions()`, `spring_mvc.log_unresolved_mapping()`, `spring_mvc.decode_builtin_spring_mapping()`, `spring_mvc.first_spring_mapping()`, `spring_mvc.compose_lexical_type_mapping()`, `spring_mvc.analyze_direct_spring_mvc_unit()`, `spring_mvc.spring_definition_runtime_retained()`, `spring_mvc.resolve_spring_mapping_spelling()`, `spring_mvc.source_annotation_definition()`, `spring_mvc.source_annotation_is_method_applicable()`, `spring_mvc.spring_method_applicable_component_candidates()`, `spring_mvc.collect_spring_mapping_branches()`, `spring_mvc.decode_alias_string()`, `spring_mvc.resolve_alias_annotation_target()`, `spring_mvc.parse_spring_alias_edge()`, `spring_mvc.spring_alias_element_type_valid()`, `spring_mvc.spring_alias_non_output_type_valid()`, `spring_mvc.spring_alias_value_cardinality_valid()`, `spring_mvc.spring_alias_known_type_shape()`, `spring_mvc.spring_alias_custom_types_compatible()`, `spring_mvc.resolve_ignored_sibling_alias_target()`, `spring_mvc.resolve_spring_alias_terminal()`, `spring_mvc.annotation_instance_values()`, `spring_mvc.decode_spring_alias_path_value()`, `spring_mvc.decode_spring_alias_method_value()`, `spring_mvc.invalid_spring_composed_mapping()`, `spring_mvc.log_spring_composed_issue()`, `spring_mvc.decode_spring_composed_mapping()`, `spring_mvc.spring_composed_definition_is_supported()`. |
| `spring_mvc_hierarchy.py` | `spring_mvc_hierarchy.SpringMvcHierarchyAnalyzer`, `SpringMvcHierarchyAnalyzer.__init__()`, `SpringMvcHierarchyAnalyzer._log()`, `SpringMvcHierarchyAnalyzer._is_direct_mvc_controller()`, `SpringMvcHierarchyAnalyzer._is_mapping_contract_type()`, `SpringMvcHierarchyAnalyzer._type_accessible()`, `SpringMvcHierarchyAnalyzer._method_accessible()`, `SpringMvcHierarchyAnalyzer._implementation_usable()`, `SpringMvcHierarchyAnalyzer._decode_annotations()`, `SpringMvcHierarchyAnalyzer._method_mapping()`, `SpringMvcHierarchyAnalyzer._type_mapping()`, `SpringMvcHierarchyAnalyzer._interface_mapping_branches()`, `SpringMvcHierarchyAnalyzer._resolve_mapping_source()`, `SpringMvcHierarchyAnalyzer._all_signatures()`, `SpringMvcHierarchyAnalyzer._implementation()`, `SpringMvcHierarchyAnalyzer._mapping_conditions()`, `SpringMvcHierarchyAnalyzer._controller_hierarchy_endpoints()`, `SpringMvcHierarchyAnalyzer.analyze()`, `spring_mvc_hierarchy.analyze_spring_mvc_hierarchy()`. |
| `spring_route_registrations.py` | `spring_route_registrations._log()`, `spring_route_registrations._known_direct_annotation()`, `spring_route_registrations._owner_is_concrete_class()`, `spring_route_registrations._owner_is_unique()`, `spring_route_registrations._method_variable_names()`, `spring_route_registrations._unqualified_static_member_resolves()`, `spring_route_registrations._call_has_owner()`, `spring_route_registrations._router_function_family()`, `spring_route_registrations._single_direct_return()`, `spring_route_registrations._resolve_path()`, `spring_route_registrations._direct_variable_initializer()`, `spring_route_registrations._is_route_identity_neutral_predicate()`, `spring_route_registrations._bind_this_handler()`, `spring_route_registrations._decode_handler()`, `spring_route_registrations._decode_selecting_predicate()`, `spring_route_registrations._decode_predicate()`, `spring_route_registrations._lambda_parameter_and_body()`, `spring_route_registrations._decode_builder_route_arguments()`, `spring_route_registrations._decode_builder_chain()`, `spring_route_registrations._decode_builder()`, `spring_route_registrations._decode_functional_expression()`, `spring_route_registrations._handler_endpoint()`, `spring_route_registrations._analyze_functional_routes()`, `spring_route_registrations._resolve_source_type()`, `spring_route_registrations._canonical_named_type()`, `spring_route_registrations._canonical_type()`, `spring_route_registrations._class_literal_type()`, `spring_route_registrations._decode_reflected_method()`, `spring_route_registrations._decode_request_mapping_info()`, `spring_route_registrations._local_declarators()`, `spring_route_registrations._tracked_local_kind()`, `spring_route_registrations._direct_expression()`, `spring_route_registrations._mapping_invocations()`, `spring_route_registrations._has_tracked_mutation()`, `spring_route_registrations._resolve_local_argument()`, `spring_route_registrations._is_programmatic_registration_owner()`, `spring_route_registrations._analyze_programmatic_registration_method()`, `spring_route_registrations._analyze_programmatic_mvc_registrations()`, `spring_route_registrations._deduplicate()`, `spring_route_registrations.analyze_spring_route_registrations()`. |
| `spring_clients.py` | `spring_clients._ClientCandidate`, `spring_clients._log()`, `spring_clients._direct_methods()`, `spring_clients._usable_contract_method()`, `spring_clients._resolved_exchange_annotations()`, `spring_clients._resolve_string_values()`, `spring_clients._normalize_client_path()`, `spring_clients._combine_client_paths()`, `spring_clients._decode_exchange_paths()`, `spring_clients._decode_exchange_methods()`, `spring_clients._decode_exchange_mapping()`, `spring_clients._ordered_methods()`, `spring_clients._union_exchange_methods()`, `spring_clients._endpoint()`, `spring_clients._http_interface_endpoints()`, `spring_clients._resolved_feign_client_markers()`, `spring_clients._decode_mvc_mapping()`, `spring_clients._first_mvc_mapping()`, `spring_clients._all_mvc_mappings()`, `spring_clients._feign_endpoints()`, `spring_clients._deduplicate()`, `spring_clients.analyze_spring_http_clients()`. |
| `spring_config.py` | `spring_config.SpringProjectPathConfiguration`, `spring_config.SpringWorkspacePathConfiguration`, `spring_config._canonical_path()`, `spring_config._log()`, `spring_config._known_type()`, `spring_config._infer_project_root()`, `spring_config._parse_properties()`, `spring_config._strip_yaml_comment()`, `spring_config._split_yaml_mapping()`, `spring_config._yaml_string()`, `spring_config._parse_mapping_yaml()`, `spring_config._normalize_optional_path()`, `spring_config._read_project_path_configuration()`, `spring_config.build_spring_path_configuration()`, `spring_config._resolve_placeholders()`, `spring_config._collapse_path_slashes()`, `spring_config.resolve_spring_endpoint_path()`, `spring_config.resolve_spring_client_path_layers()`, `spring_config.make_spring_path_resolver()`, nested `apply()`, `spring_config.apply_spring_path_configuration()`, `spring_config._iter_resource_handler_configurer_methods()`, `spring_config._invocation_name()`, `spring_config._registry_is_mutated()`, `spring_config._deduplicate()`, `spring_config.analyze_spring_resource_handlers()`. |
| `spring_gateway.py` | `spring_gateway.GatewayPathResolver`, `spring_gateway.GatewayRouteConditions`, `spring_gateway._log()`, `spring_gateway._known_direct_annotation()`, `spring_gateway._owner_is_unique_concrete_class()`, `spring_gateway._single_direct_return()`, `spring_gateway._validated_route_locator_builder_name()`, `spring_gateway._decode_predicate_lambda_parameter()`, `spring_gateway._resolve_path()`, `spring_gateway._resolve_http_method()`, `spring_gateway._invocation_chain()`, `spring_gateway._decode_predicate_chain()`, `spring_gateway._decode_predicate_helper()`, `spring_gateway._decode_route_lambda()`, `spring_gateway._route_lambda_argument()`, `spring_gateway._decode_route_locator_publisher()`, `spring_gateway._endpoint()`, `spring_gateway._deduplicate()`, `spring_gateway.analyze_spring_gateway()`. |
| `spring_websocket_messaging.py` | `spring_websocket_messaging._unique_concrete_configurers()`, `spring_websocket_messaging._formal_parameter()`, `spring_websocket_messaging._canonical_method()`, `spring_websocket_messaging._receiver_mutated()`, `spring_websocket_messaging._invocation_name()`, `spring_websocket_messaging._direct_receiver_calls()`, `spring_websocket_messaging._receiver_calls()`, `spring_websocket_messaging._arguments()`, `spring_websocket_messaging._resolved_paths()`, `spring_websocket_messaging._project_key()`, `spring_websocket_messaging._stomp_configurer_methods()`, `spring_websocket_messaging._websocket_handler_configurer_methods()`, `spring_websocket_messaging._direct_call_with_allowed_chain()`, `spring_websocket_messaging._handler_field_name()`, `spring_websocket_messaging._has_typed_websocket_handler_field()`, `spring_websocket_messaging._websocket_handler_handshake_endpoints()`, `spring_websocket_messaging._stomp_handshake_endpoints()`, `spring_websocket_messaging._stomp_application_prefixes()`, `spring_websocket_messaging._annotation_paths()`, `spring_websocket_messaging._known_annotations()`, `spring_websocket_messaging._lexical_controller_type_chain()`, `spring_websocket_messaging._has_controller_marker_in_lexical_chain()`, `spring_websocket_messaging._lexical_message_mapping_paths()`, `spring_websocket_messaging._message_mapping_endpoints()`, `spring_websocket_messaging._deduplicate()`, `spring_websocket_messaging.analyze_spring_websocket_and_messaging()`. |

## 14. Practical reading recipe

When investigating a randomly selected Spring method:

1. search its exact coordinate in section 13;
2. read its module contract table to learn caller, input/output, and rejection
   scope;
3. walk upward in that module's call graph to find the production entry point;
4. if it creates a fact, use section 10.1 to verify attribution and evidence;
5. follow section 10.2 through local deduplication and path configuration; and
6. use section 12 to distinguish a deliberately skipped candidate from a
   whole-run exception.

This gives both views needed for maintenance: the existing module-level map
explains ownership, while this chapter makes individual methods and the data
that crosses them directly discoverable.

Continue with
[14 — JAX-RS, evidence, and output methods](14-jaxrs-output-methods.md), or use
the [method lookup](15-method-lookup.md) for an exact source symbol.
