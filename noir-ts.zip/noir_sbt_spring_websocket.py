"""Bounded Spring WebSocket handshake and message-destination identification.

The host module is passed in explicitly so this pass can reuse the shared Java
identity, annotation-provenance, and workspace String-resolution machinery
without importing :mod:`noir_sbt` and creating an import cycle.

Supported forms are intentionally source-backed:

* direct ``WebSocketMessageBrokerConfigurer`` implementations with canonical
  ``registerStompEndpoints(StompEndpointRegistry)`` registrations;
* direct ``WebSocketConfigurer`` implementations with canonical
  ``registerWebSocketHandlers(WebSocketHandlerRegistry)`` registrations;
* canonical ``setApplicationDestinationPrefixes`` calls on the same genuine
  STOMP configurer family; and
* genuine ``@Controller`` message handlers using ``@MessageMapping`` or
  ``@SubscribeMapping`` on concrete workspace classes/records.

Receiver aliases, mutation, nested registration flow, dynamic paths, fake
framework identities, and ambiguous project ownership fail closed.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping


WEBSOCKET_CONFIG_PACKAGE = "org.springframework.web.socket.config.annotation"
WEBSOCKET_PACKAGE = "org.springframework.web.socket"
MESSAGE_CONFIG_PACKAGE = "org.springframework.messaging.simp.config"
MESSAGE_ANNOTATION_PACKAGE = "org.springframework.messaging.handler.annotation"
STEREOTYPE_PACKAGE = "org.springframework.stereotype"

PATH_NEUTRAL_REGISTRATION_CALLS = frozenset(
    {
        "addInterceptors",
        "setAllowedOrigins",
        "setAllowedOriginPatterns",
        "setHandshakeHandler",
    }
)
WEB_BIND_ANNOTATION_PACKAGE = "org.springframework.web.bind.annotation"


def _text(unit: Mapping[str, Any], node: Any) -> str:
    return unit["source"][node.start_byte : node.end_byte].decode("utf8")


def _field(host: Any, node: Any, name: str) -> Any:
    return host.child_by_field(node, name)


def _walk(node: Any) -> Iterable[Any]:
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


def _raw_type_node(node: Any) -> Any:
    current = node
    for _depth in range(16):
        if current is None:
            return None
        if current.type == "generic_type":
            children = list(current.named_children)
            current = children[0] if children else None
            continue
        if current.type == "annotated_type":
            candidates = [
                child for child in current.named_children if child.type != "annotation"
            ]
            current = candidates[-1] if len(candidates) == 1 else None
            continue
        return current
    return None


def _known_type(
    host: Any,
    unit: Mapping[str, Any],
    node: Any,
    simple_name: str,
    package: str,
) -> bool:
    raw = _raw_type_node(node)
    return bool(
        raw is not None
        and host.resolve_known_type(
            unit, _text(unit, raw), simple_name, (package,), raw
        )
        == package
    )


def _direct_interface_types(host: Any, type_node: Any) -> list[Any]:
    interfaces = _field(host, type_node, "interfaces")
    if interfaces is None:
        return []
    children = list(interfaces.named_children)
    if len(children) == 1 and children[0].type == "type_list":
        return list(children[0].named_children)
    return children


def _unique_concrete_configurers(
    workspace: Mapping[str, Any], host: Any, interface_name: str
) -> Iterable[tuple[Mapping[str, Any], Mapping[str, Any], Any]]:
    for fname in sorted(workspace.get("units", {})):
        unit = workspace["units"][fname]
        for type_info in sorted(
            unit["type_infos"].values(), key=lambda info: info["node"].start_byte
        ):
            node = type_info["node"]
            if (
                node.type != "class_declaration"
                or type_info["abstract"]
                or not type_info["workspace_visible"]
            ):
                continue
            owner_fqn = host.qualified_type_name(unit, type_info)
            declarations = workspace["type_declarations"].get(owner_fqn, [])
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                continue
            interfaces = [
                edge
                for edge in _direct_interface_types(host, node)
                if _known_type(
                    host,
                    unit,
                    edge,
                    interface_name,
                    WEBSOCKET_CONFIG_PACKAGE,
                )
            ]
            if len(interfaces) == 1:
                yield unit, type_info, node


def _formal_parameter(
    host: Any,
    unit: Mapping[str, Any],
    method: Any,
    expected_type: str,
    package: str,
) -> tuple[str, Any] | None:
    parameters = _field(host, method, "parameters")
    if parameters is None:
        return None
    formals = [
        child
        for child in parameters.named_children
        if child.type not in {"line_comment", "block_comment"}
    ]
    if len(formals) != 1:
        return None
    parameter = formals[0]
    if parameter.type != "formal_parameter":
        return None
    type_node = _field(host, parameter, "type")
    name_node = _field(host, parameter, "name")
    if (
        type_node is None
        or name_node is None
        or not _known_type(host, unit, type_node, expected_type, package)
    ):
        return None
    return _text(unit, name_node), parameters


def _canonical_method(
    host: Any,
    unit: Mapping[str, Any],
    method: Any,
    method_name: str,
    parameter_type: str,
    parameter_package: str,
) -> tuple[str, Any, Any] | None:
    name = _field(host, method, "name")
    return_type = _field(host, method, "type")
    body = _field(host, method, "body")
    modifiers = host.declaration_modifier_names(method)
    if (
        name is None
        or return_type is None
        or body is None
        or _text(unit, name) != method_name
        or _text(unit, return_type).strip() != "void"
        or "public" not in modifiers
        or "static" in modifiers
    ):
        return None
    formal = _formal_parameter(
        host, unit, method, parameter_type, parameter_package
    )
    if formal is None:
        return None
    return formal[0], formal[1], body


def _receiver_mutated(
    host: Any, unit: Mapping[str, Any], body: Any, receiver_name: str
) -> bool:
    for node in _walk(body):
        if node.type == "assignment_expression":
            left = _field(host, node, "left")
            if (
                left is not None
                and left.type == "identifier"
                and _text(unit, left) == receiver_name
            ):
                return True
        if node.type == "update_expression" and any(
            child.type == "identifier" and _text(unit, child) == receiver_name
            for child in node.named_children
        ):
            return True
    return False


def _invocation_name(host: Any, unit: Mapping[str, Any], node: Any) -> str:
    name = _field(host, node, "name")
    return _text(unit, name) if name is not None else ""


def _direct_call_chain(host: Any, invocation: Any, body: Any) -> bool:
    current = invocation
    while getattr(current, "parent", None) is not None:
        parent = current.parent
        if parent.type != "method_invocation":
            break
        object_node = _field(host, parent, "object")
        if object_node is None or (
            object_node.start_byte,
            object_node.end_byte,
        ) != (current.start_byte, current.end_byte):
            break
        current = parent
    statement = getattr(current, "parent", None)
    return bool(
        statement is not None
        and statement.type == "expression_statement"
        and getattr(statement, "parent", None) is not None
        and host.tree_node_key(statement.parent) == host.tree_node_key(body)
    )


def _direct_receiver_calls(
    host: Any,
    unit: Mapping[str, Any],
    body: Any,
    receiver_name: str,
    invocation_name: str,
) -> Iterable[Any]:
    for invocation in _receiver_calls(
        host, unit, body, receiver_name, invocation_name
    ):
        if _direct_call_chain(host, invocation, body):
            yield invocation


def _receiver_calls(
    host: Any,
    unit: Mapping[str, Any],
    body: Any,
    receiver_name: str,
    invocation_name: str,
) -> Iterable[Any]:
    for invocation in _walk(body):
        if (
            invocation.type != "method_invocation"
            or _invocation_name(host, unit, invocation) != invocation_name
        ):
            continue
        receiver = _field(host, invocation, "object")
        if (
            receiver is None
            or receiver.type != "identifier"
            or _text(unit, receiver) != receiver_name
        ):
            continue
        yield invocation


def _arguments(host: Any, invocation: Any) -> list[Any]:
    arguments = _field(host, invocation, "arguments")
    return (
        [
            child
            for child in arguments.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
        if arguments is not None
        else []
    )


def _resolved_paths(
    host: Any,
    unit: Mapping[str, Any],
    workspace: Mapping[str, Any],
    owner_name: str,
    nodes: Iterable[Any],
) -> list[str] | None:
    paths = []
    for node in nodes:
        value = host.resolve_workspace_string_expression(
            unit, node, workspace, owner_name
        )
        if value is None:
            return None
        paths.append(host.combine_paths("", host.normalize_spring_path(value)))
    return list(dict.fromkeys(paths))


def _project_key(configuration: Any, fname: str) -> str | None:
    if configuration is None:
        return str(Path(fname).resolve(strict=False))
    return configuration.source_projects.get(str(Path(fname).resolve(strict=False)))


def _configuration_methods(
    workspace: Mapping[str, Any], host: Any
) -> Iterable[
    tuple[Mapping[str, Any], Mapping[str, Any], Any, str, Any, Any, str, bool]
]:
    for unit, type_info, type_node in _unique_concrete_configurers(
        workspace, host, "WebSocketMessageBrokerConfigurer"
    ):
        body = _field(host, type_node, "body")
        if body is None:
            continue
        for method in body.named_children:
            if method.type != "method_declaration":
                continue
            for method_name, parameter_type, parameter_package, call_name in (
                (
                    "registerStompEndpoints",
                    "StompEndpointRegistry",
                    WEBSOCKET_CONFIG_PACKAGE,
                    "addEndpoint",
                ),
                (
                    "configureMessageBroker",
                    "MessageBrokerRegistry",
                    MESSAGE_CONFIG_PACKAGE,
                    "setApplicationDestinationPrefixes",
                ),
            ):
                canonical = _canonical_method(
                    host,
                    unit,
                    method,
                    method_name,
                    parameter_type,
                    parameter_package,
                )
                if canonical is None:
                    continue
                receiver, parameters, method_body = canonical
                yield (
                    unit,
                    type_info,
                    method,
                    receiver,
                    parameters,
                    method_body,
                    call_name,
                    _receiver_mutated(host, unit, method_body, receiver),
                )


def _raw_configuration_methods(
    workspace: Mapping[str, Any], host: Any
) -> Iterable[
    tuple[Mapping[str, Any], Mapping[str, Any], Any, str, Any, bool]
]:
    for unit, type_info, type_node in _unique_concrete_configurers(
        workspace, host, "WebSocketConfigurer"
    ):
        body = _field(host, type_node, "body")
        if body is None:
            continue
        for method in body.named_children:
            if method.type != "method_declaration":
                continue
            canonical = _canonical_method(
                host,
                unit,
                method,
                "registerWebSocketHandlers",
                "WebSocketHandlerRegistry",
                WEBSOCKET_CONFIG_PACKAGE,
            )
            if canonical is None:
                continue
            receiver, _parameters, method_body = canonical
            yield (
                unit,
                type_info,
                method,
                receiver,
                method_body,
                _receiver_mutated(host, unit, method_body, receiver),
            )


def _direct_call_with_allowed_chain(
    host: Any,
    unit: Mapping[str, Any],
    invocation: Any,
    body: Any,
    allowed_chain_names: frozenset[str],
) -> bool:
    current = invocation
    while getattr(current, "parent", None) is not None:
        parent = current.parent
        if parent.type != "method_invocation":
            break
        object_node = _field(host, parent, "object")
        if object_node is None or (
            object_node.start_byte,
            object_node.end_byte,
        ) != (current.start_byte, current.end_byte):
            break
        if _invocation_name(host, unit, parent) not in allowed_chain_names:
            return False
        current = parent
    statement = getattr(current, "parent", None)
    return bool(
        statement is not None
        and statement.type == "expression_statement"
        and getattr(statement, "parent", None) is not None
        and host.tree_node_key(statement.parent) == host.tree_node_key(body)
    )


def _handler_field_name(
    host: Any, unit: Mapping[str, Any], node: Any
) -> tuple[str, bool] | None:
    if node.type == "identifier":
        return _text(unit, node), False
    if node.type != "field_access":
        return None
    object_node = _field(host, node, "object")
    field_node = _field(host, node, "field")
    if (
        object_node is None
        or object_node.type != "this"
        or field_node is None
        or field_node.type != "identifier"
    ):
        return None
    return _text(unit, field_node), True


def _has_typed_websocket_handler_field(
    host: Any,
    unit: Mapping[str, Any],
    type_info: Mapping[str, Any],
    method_body: Any,
    handler_node: Any,
) -> bool:
    reference = _handler_field_name(host, unit, handler_node)
    if reference is None:
        return False
    name, explicit_this = reference

    # An unqualified name shadowed anywhere in the method is not exact enough
    # for this deliberately bounded symbol model.  ``this.field`` is explicit.
    if not explicit_this:
        for node in _walk(method_body):
            if node.type not in {
                "variable_declarator",
                "formal_parameter",
                "catch_formal_parameter",
            }:
                continue
            name_node = _field(host, node, "name")
            if name_node is not None and _text(unit, name_node) == name:
                return False

    owner_body = _field(host, type_info["node"], "body")
    if owner_body is None:
        return False
    candidates = []
    for declaration in owner_body.named_children:
        if declaration.type != "field_declaration":
            continue
        type_node = _field(host, declaration, "type")
        if type_node is None or not _known_type(
            host,
            unit,
            type_node,
            "WebSocketHandler",
            WEBSOCKET_PACKAGE,
        ):
            continue
        for declarator in declaration.named_children:
            if declarator.type != "variable_declarator":
                continue
            name_node = _field(host, declarator, "name")
            if name_node is not None and _text(unit, name_node) == name:
                candidates.append(declarator)
    return len(candidates) == 1


def _raw_handshake_endpoints(
    workspace: Mapping[str, Any], host: Any
) -> list[dict[str, Any]]:
    endpoints = []
    # These WebSocketHandlerRegistration operations configure the already
    # selected handler/path set; they do not replace or add endpoint paths.
    for unit, type_info, method, receiver, body, mutated in _raw_configuration_methods(
        workspace, host
    ):
        if mutated:
            continue
        owner = type_info["display_name"]
        function = f"{owner}.registerWebSocketHandlers"
        for invocation in _receiver_calls(host, unit, body, receiver, "addHandler"):
            if not _direct_call_with_allowed_chain(
                host,
                unit,
                invocation,
                body,
                PATH_NEUTRAL_REGISTRATION_CALLS,
            ):
                continue
            arguments = _arguments(host, invocation)
            if len(arguments) < 2 or not _has_typed_websocket_handler_field(
                host, unit, type_info, body, arguments[0]
            ):
                continue
            paths = _resolved_paths(
                host,
                unit,
                workspace,
                owner,
                arguments[1:],
            )
            if not paths:
                continue
            for path in paths:
                endpoint = {
                    "uri": path,
                    "method": "GET",
                    "uri_params": "",
                    "SrcFile": unit["fname"],
                    "SrcLine": invocation.start_point.row + 1,
                    "SFunction": function,
                    "RouteSrcFile": unit["fname"],
                    "RouteSrcLine": invocation.start_point.row + 1,
                    "HandlerSrcFile": unit["fname"],
                    "HandlerSrcLine": method.start_point.row + 1,
                    "ProjectSrcFile": unit["fname"],
                    "technology": "spring",
                    "protocol": "ws",
                    "surface": "websocket-handshake",
                    "direction": "inbound",
                }
                endpoints.append(endpoint)
                host.debug_log(endpoint)
    return endpoints


def _handshake_endpoints(
    workspace: Mapping[str, Any], host: Any
) -> list[dict[str, Any]]:
    endpoints = []
    for unit, type_info, method, receiver, _parameters, body, call_name, mutated in _configuration_methods(
        workspace, host
    ):
        if call_name != "addEndpoint" or mutated:
            continue
        owner = type_info["display_name"]
        function = f"{owner}.registerStompEndpoints"
        for invocation in _receiver_calls(host, unit, body, receiver, call_name):
            if not _direct_call_with_allowed_chain(
                host,
                unit,
                invocation,
                body,
                PATH_NEUTRAL_REGISTRATION_CALLS,
            ):
                continue
            paths = _resolved_paths(
                host,
                unit,
                workspace,
                owner,
                _arguments(host, invocation),
            )
            if not paths:
                continue
            for path in paths:
                endpoint = {
                    "uri": path,
                    "method": "GET",
                    "uri_params": "",
                    "SrcFile": unit["fname"],
                    "SrcLine": invocation.start_point.row + 1,
                    "SFunction": function,
                    "RouteSrcFile": unit["fname"],
                    "RouteSrcLine": invocation.start_point.row + 1,
                    "HandlerSrcFile": unit["fname"],
                    "HandlerSrcLine": method.start_point.row + 1,
                    "ProjectSrcFile": unit["fname"],
                    "technology": "spring",
                    "protocol": "ws",
                    "surface": "websocket-handshake",
                    "direction": "inbound",
                }
                endpoints.append(endpoint)
                host.debug_log(endpoint)
    return endpoints


def _application_prefixes(
    workspace: Mapping[str, Any], host: Any, configuration: Any
) -> tuple[dict[str, tuple[str, ...]], frozenset[str]]:
    prefixes: dict[str, list[str]] = {}
    direct_call_counts: dict[str, int] = {}
    invalid_projects: set[str] = set()
    for unit, type_info, _method, receiver, _parameters, body, call_name, mutated in _configuration_methods(
        workspace, host
    ):
        if call_name != "setApplicationDestinationPrefixes":
            continue
        project = _project_key(configuration, unit["fname"])
        if project is None:
            continue
        if mutated:
            invalid_projects.add(project)
            continue
        receiver_calls = list(
            _receiver_calls(host, unit, body, receiver, call_name)
        )
        calls = [
            invocation
            for invocation in receiver_calls
            if _direct_call_with_allowed_chain(
                host, unit, invocation, body, frozenset()
            )
        ]
        # An application prefix hidden in control flow is still a real
        # registration, but its runtime identity is not statically known.
        # Distinguish that from a canonical method with no registration.
        if len(calls) != len(receiver_calls):
            invalid_projects.add(project)
        direct_call_counts[project] = direct_call_counts.get(project, 0) + len(calls)
        if direct_call_counts[project] > 1:
            # This API replaces, rather than accumulates, the configured
            # prefixes. Source ordering across repeated calls/configurers is
            # not a sound endpoint-identity proof, so reject the project.
            invalid_projects.add(project)
        for invocation in calls:
            values = _resolved_paths(
                host,
                unit,
                workspace,
                type_info["display_name"],
                _arguments(host, invocation),
            )
            if not values:
                invalid_projects.add(project)
                continue
            prefixes.setdefault(project, []).extend(values)
    return (
        {
            project: tuple(dict.fromkeys(values))
            for project, values in prefixes.items()
            if project not in invalid_projects
        },
        frozenset(invalid_projects),
    )


def _annotation_paths(
    host: Any,
    unit: Mapping[str, Any],
    workspace: Mapping[str, Any],
    annotation: Mapping[str, Any],
    owner_name: str,
    *,
    empty_default: bool = False,
) -> list[str] | None:
    positional, named = host.get_annotation_arguments(annotation["node"])
    if set(named) - {"value", "path"} or len(positional) > 1:
        return None
    groups = []
    if positional:
        groups.append(positional[0])
    for attribute in ("value", "path"):
        if attribute in named:
            groups.append(named[attribute])
    if not groups:
        return [""] if empty_default else None
    decoded = []
    for group in groups:
        values = _resolved_paths(
            host,
            unit,
            workspace,
            owner_name,
            host.annotation_value_nodes(group),
        )
        if values is None:
            return None
        decoded.append(tuple(values))
    if len(set(decoded)) != 1:
        return None
    return list(decoded[0])


def _known_annotations(
    host: Any,
    unit: Mapping[str, Any],
    candidates: Iterable[Mapping[str, list[Any]]],
    names: set[str],
    package: str,
) -> list[tuple[dict[str, Any], str]]:
    matches = []
    for record in host.annotation_records(candidates):
        resolved = host.resolve_known_annotation(
            unit, record["name_node"], names, (package,)
        )
        if resolved is not None:
            matches.append((record, resolved["name"]))
    return matches


def _controller_chain(
    host: Any, unit: Mapping[str, Any], type_key: tuple[int, int]
) -> list[Mapping[str, Any]]:
    return host.type_chain(type_key, unit["type_infos"])


def _controller_active(
    host: Any,
    unit: Mapping[str, Any],
    chain: Iterable[Mapping[str, Any]],
) -> bool:
    for info in chain:
        key = host.tree_node_key(info["node"])
        annotations = _known_annotations(
            host,
            unit,
            unit["type_candidates"].get(key, []),
            {"Controller"},
            STEREOTYPE_PACKAGE,
        )
        rest_annotations = _known_annotations(
            host,
            unit,
            unit["type_candidates"].get(key, []),
            {"RestController"},
            WEB_BIND_ANNOTATION_PACKAGE,
        )
        if annotations or rest_annotations:
            return True
    return False


def _class_message_paths(
    host: Any,
    unit: Mapping[str, Any],
    workspace: Mapping[str, Any],
    chain: Iterable[Mapping[str, Any]],
) -> list[str] | None:
    paths = [""]
    for info in chain:
        key = host.tree_node_key(info["node"])
        records = _known_annotations(
            host,
            unit,
            unit["type_candidates"].get(key, []),
            {"MessageMapping"},
            MESSAGE_ANNOTATION_PACKAGE,
        )
        if not records:
            continue
        current_paths = []
        for record, _name in records:
            decoded = _annotation_paths(
                host,
                unit,
                workspace,
                record,
                info["display_name"],
                empty_default=True,
            )
            if decoded is None:
                return None
            current_paths.extend(decoded)
        paths = [
            host.combine_paths(base, current)
            for base in paths
            for current in dict.fromkeys(current_paths)
        ]
    return list(dict.fromkeys(paths))


def _message_endpoints(
    workspace: Mapping[str, Any], host: Any, configuration: Any
) -> list[dict[str, Any]]:
    project_prefixes, invalid_prefix_projects = _application_prefixes(
        workspace, host, configuration
    )
    endpoints = []
    for fname in sorted(workspace.get("units", {})):
        unit = workspace["units"][fname]
        project = _project_key(configuration, fname)
        if project is None or project in invalid_prefix_projects:
            continue
        app_prefixes = project_prefixes.get(project, ("",))
        for method_key in sorted(unit["method_candidates"]):
            candidates = unit["method_candidates"][method_key]
            representative = candidates[0]
            type_node = host.first_capture(representative, "type.node")
            method_node = host.first_capture(representative, "method.node")
            method_name_node = host.first_capture(representative, "method.name")
            parameters_node = host.first_capture(representative, "method.parameters")
            if None in (type_node, method_node, method_name_node, parameters_node):
                continue
            type_key = host.tree_node_key(type_node)
            info = unit["type_infos"].get(type_key)
            if (
                info is None
                or info["abstract"]
                or not info["workspace_visible"]
            ):
                continue
            chain = _controller_chain(host, unit, type_key)
            if not _controller_active(host, unit, chain):
                continue
            class_paths = _class_message_paths(
                host, unit, workspace, chain
            )
            if class_paths is None:
                continue
            owner = info["display_name"]
            function = f"{owner}.{_text(unit, method_name_node)}"
            annotations = _known_annotations(
                host,
                unit,
                candidates,
                {"MessageMapping", "SubscribeMapping"},
                MESSAGE_ANNOTATION_PACKAGE,
            )
            for record, name in annotations:
                method_paths = _annotation_paths(
                    host, unit, workspace, record, function
                )
                if not method_paths:
                    continue
                verb = "SEND" if name == "MessageMapping" else "SUBSCRIBE"
                for app_prefix in app_prefixes:
                    for class_path in class_paths:
                        for method_path in method_paths:
                            uri = host.combine_paths(
                                host.combine_paths(app_prefix, class_path),
                                method_path,
                            )
                            endpoint = {
                                "uri": uri,
                                "method": verb,
                                "uri_params": host.get_callable_parameters_as_is(
                                    unit["source"], parameters_node
                                ),
                                "SrcFile": fname,
                                "SrcLine": record["node"].start_point.row + 1,
                                "SFunction": function,
                                "RouteSrcFile": fname,
                                "RouteSrcLine": record["node"].start_point.row + 1,
                                "HandlerSrcFile": fname,
                                "HandlerSrcLine": method_node.start_point.row + 1,
                                "ProjectSrcFile": fname,
                                "technology": "spring",
                                "protocol": "ws",
                                "surface": "message",
                                "direction": "inbound",
                            }
                            endpoints.append(endpoint)
                            host.debug_log(endpoint)
    return endpoints


def _deduplicate(endpoints: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    unique = {}
    for endpoint in endpoints:
        key = tuple(
            endpoint.get(field)
            for field in (
                "protocol",
                "surface",
                "method",
                "uri",
                "SrcFile",
                "SFunction",
                "uri_params",
            )
        )
        unique[key] = endpoint
    return [unique[key] for key in sorted(unique)]


def analyze_spring_websocket(
    workspace: Mapping[str, Any], host: Any, configuration: Any = None
) -> list[dict[str, Any]]:
    """Return Spring WebSocket handshake and message-destination facts."""

    return _deduplicate(
        [
            *_raw_handshake_endpoints(workspace, host),
            *_handshake_endpoints(workspace, host),
            *_message_endpoints(workspace, host, configuration),
        ]
    )


__all__ = ["analyze_spring_websocket"]
