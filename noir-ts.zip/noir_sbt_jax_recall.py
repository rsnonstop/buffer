"""Bounded source-only JAX-RS hierarchy and subresource recall.

This module deliberately does not import :mod:`noir_sbt`.  The integrating
analyzer passes that module as ``host`` together with an already-built JAX
workspace.  Keeping the dependency one-way lets the host opt into this recall
pass without an import-time cycle.

``analyze_jax_recall`` is a workspace-level operation.  Its result contains
only rows which the host's direct JAX pass cannot produce: hierarchy-bound
root methods and leaves reached through at least one subresource locator.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


MAX_HIERARCHY_DEPTH = 12
MAX_HIERARCHY_STATES = 256
MAX_SUBRESOURCE_DEPTH = 16
MAX_SUBRESOURCE_STATES = 4096
MAX_COMPOSED_PATH = 8192

JAVA_LANG_TYPES = {
    "Boolean",
    "Byte",
    "Character",
    "CharSequence",
    "Class",
    "Comparable",
    "Double",
    "Enum",
    "Float",
    "Integer",
    "Iterable",
    "Long",
    "Number",
    "Object",
    "Short",
    "String",
    "Throwable",
    "Void",
}

JAX_METHOD_ANNOTATIONS = {
    "BeanParam",
    "Consumes",
    "CookieParam",
    "DefaultValue",
    "Encoded",
    "FormParam",
    "HeaderParam",
    "MatrixParam",
    "Path",
    "PathParam",
    "Produces",
    "QueryParam",
    "Context",
    "Suspended",
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
}

PRIMITIVE_NODE_TYPES = {
    "boolean_type",
    "floating_point_type",
    "integral_type",
    "void_type",
}


@dataclass(frozen=True)
class TypeRef:
    kind: str
    name: str
    args: tuple["TypeRef", ...] = ()
    dimensions: int = 0


@dataclass
class MethodRecord:
    id: tuple[Any, ...]
    owner: "TypeRecord"
    node: Any
    name: str
    parameters_node: Any
    return_node: Any
    parameter_nodes: tuple[Any, ...]
    annotations: tuple[dict[str, Any], ...]
    parameter_annotations: tuple[dict[str, Any], ...]
    modifiers: frozenset[str]
    method_type_parameters: tuple[str, ...]
    method_type_bounds: dict[str, TypeRef]
    parameter_refs: tuple[TypeRef, ...] | None
    return_ref: TypeRef | None


@dataclass
class TypeRecord:
    fqn: str
    unit: dict[str, Any]
    type_info: dict[str, Any]
    kind: str
    type_parameters: tuple[str, ...]
    type_bounds: dict[str, TypeRef] = field(default_factory=dict)
    methods: list[MethodRecord] = field(default_factory=list)
    superclass: TypeRef | None = None
    superclass_declared: bool = False
    interfaces: tuple[TypeRef, ...] = ()
    interfaces_valid: bool = True


@dataclass(frozen=True)
class TypeState:
    record_fqn: str
    env_key: tuple[tuple[str, TypeRef], ...]


@dataclass
class HierarchyContext:
    class_states: list[tuple[TypeRecord, dict[str, TypeRef]]]
    interface_roots: list[tuple[TypeRecord, dict[str, TypeRef]]]
    complete: bool


@dataclass
class EffectiveMethod:
    implementation: MethodRecord
    implementation_env: dict[str, TypeRef]
    annotation_source: MethodRecord
    binding: dict[str, Any]
    hierarchy_added: bool
    signature: tuple[str, tuple[str, ...]] | None


class JaxRecallAnalyzer:
    def __init__(self, workspace: dict[str, Any], host: Any):
        self.workspace = workspace
        self.host = host
        self.types: dict[str, TypeRecord] = {}
        self._signature_cache: dict[tuple[Any, ...], tuple[str, tuple[str, ...]] | None] = {}
        self._effective_cache: dict[tuple[Any, ...], list[EffectiveMethod]] = {}
        self._build_index()

    def log(self, method_or_type: Any, message: str, expression: str | None = None) -> None:
        if isinstance(method_or_type, MethodRecord):
            unit = method_or_type.owner.unit
            owner = f"{method_or_type.owner.type_info['display_name']}.{method_or_type.name}"
        else:
            unit = method_or_type.unit
            owner = method_or_type.type_info["display_name"]
        self.host.log_jax_issue(unit["fname"], owner, message, expression)

    # ------------------------------------------------------------------
    # Workspace source/type model

    def _build_index(self) -> None:
        # Only unique workspace-visible identities can take part.  Duplicate
        # declarations stay absent, so every edge to one fails closed.
        for fqn, declarations in self.workspace.get("type_declarations", {}).items():
            if len(declarations) != 1:
                continue
            declaration = declarations[0]
            info = declaration["type_info"]
            if info["node"].type not in {
                "class_declaration",
                "interface_declaration",
                "record_declaration",
            }:
                continue
            parameters, _bound_nodes = self._type_parameter_nodes(info["node"])
            self.types[fqn] = TypeRecord(
                fqn=fqn,
                unit=declaration["unit"],
                type_info=info,
                kind=info["node"].type,
                type_parameters=tuple(parameters),
            )

        # Parse after every identity exists, so cross-file edges and method
        # types use one consistent resolver.
        for record in self.types.values():
            parameters, bound_nodes = self._type_parameter_nodes(record.type_info["node"])
            type_vars = set(parameters)
            record.type_bounds = {
                name: (
                    self._parse_type_ref(record, bound_nodes.get(name), type_vars)
                    or TypeRef("decl", "java.lang.Object")
                )
                for name in parameters
            }
            self._parse_edges(record, type_vars)
            self._parse_methods(record, type_vars)

    def _type_parameter_nodes(self, declaration_node: Any) -> tuple[list[str], dict[str, Any]]:
        parameters_node = next(
            (child for child in declaration_node.named_children if child.type == "type_parameters"),
            None,
        )
        names: list[str] = []
        bounds: dict[str, Any] = {}
        if parameters_node is None:
            return names, bounds
        for parameter in parameters_node.named_children:
            if parameter.type != "type_parameter" or not parameter.named_children:
                continue
            name_node = parameter.named_children[0]
            name = self.host.node_text(self._unit_source_for_node(declaration_node), name_node)
            names.append(name)
            bound = next(
                (child for child in parameter.named_children if child.type == "type_bound"),
                None,
            )
            if bound is not None and bound.named_children:
                bounds[name] = bound.named_children[0]
        return names, bounds

    def _unit_source_for_node(self, node: Any) -> bytes:
        # Nodes are kept alive by their workspace unit.  Byte ranges alone are
        # not globally unique, so locate the containing tree by ancestry.
        current = node
        while getattr(current, "parent", None) is not None:
            current = current.parent
        for unit in self.workspace["units"].values():
            if unit["tree"].root_node == current:
                return unit["source"]
        raise KeyError("Tree-sitter node is not owned by the supplied workspace")

    @staticmethod
    def _modifier_names(node: Any) -> frozenset[str]:
        modifiers = next((child for child in node.children if child.type == "modifiers"), None)
        if modifiers is None:
            return frozenset()
        return frozenset(child.type for child in modifiers.children)

    def _parse_methods(self, record: TypeRecord, owner_type_vars: set[str]) -> None:
        body = self.host.child_by_field(record.type_info["node"], "body")
        if body is None:
            return
        for method_node in body.named_children:
            if method_node.type != "method_declaration":
                continue
            name_node = self.host.child_by_field(method_node, "name")
            parameters_node = self.host.child_by_field(method_node, "parameters")
            return_node = self.host.child_by_field(method_node, "type")
            if name_node is None or parameters_node is None or return_node is None:
                continue
            method_params, method_bound_nodes = self._type_parameter_nodes(method_node)
            all_type_vars = owner_type_vars | set(method_params)
            method_bounds = {
                name: (
                    self._parse_type_ref(record, method_bound_nodes.get(name), all_type_vars)
                    or TypeRef("decl", "java.lang.Object")
                )
                for name in method_params
            }
            parameter_nodes = tuple(
                child
                for child in parameters_node.named_children
                if child.type in {"formal_parameter", "spread_parameter"}
            )
            parameter_refs: list[TypeRef] = []
            parameters_valid = True
            for parameter in parameter_nodes:
                ref = self._parse_parameter_ref(record, parameter, all_type_vars)
                if ref is None:
                    parameters_valid = False
                    break
                parameter_refs.append(ref)
            annotations = tuple(self.host.direct_annotation_records(method_node))
            parameter_annotations = tuple(
                annotation
                for parameter in parameter_nodes
                for annotation in self.host.direct_annotation_records(parameter)
            )
            record.methods.append(
                MethodRecord(
                    id=(record.unit["fname"], method_node.start_byte, method_node.end_byte),
                    owner=record,
                    node=method_node,
                    name=self.host.node_text(record.unit["source"], name_node),
                    parameters_node=parameters_node,
                    return_node=return_node,
                    parameter_nodes=parameter_nodes,
                    annotations=annotations,
                    parameter_annotations=parameter_annotations,
                    modifiers=self._modifier_names(method_node),
                    method_type_parameters=tuple(method_params),
                    method_type_bounds=method_bounds,
                    parameter_refs=tuple(parameter_refs) if parameters_valid else None,
                    return_ref=self._parse_type_ref(record, return_node, all_type_vars),
                )
            )

    def _parse_edges(self, record: TypeRecord, type_vars: set[str]) -> None:
        node = record.type_info["node"]
        superclass_node = self.host.child_by_field(node, "superclass")
        record.superclass_declared = superclass_node is not None
        if superclass_node is not None and len(superclass_node.named_children) == 1:
            record.superclass = self._parse_type_ref(
                record, superclass_node.named_children[0], type_vars
            )

        interfaces_node = self.host.child_by_field(node, "interfaces")
        if interfaces_node is None and record.kind == "interface_declaration":
            interfaces_node = next(
                (child for child in node.named_children if child.type == "extends_interfaces"),
                None,
            )
        if interfaces_node is None:
            return
        type_list = next(
            (child for child in interfaces_node.named_children if child.type == "type_list"),
            None,
        )
        edge_nodes = type_list.named_children if type_list is not None else interfaces_node.named_children
        edges: list[TypeRef] = []
        for edge_node in edge_nodes:
            ref = self._parse_type_ref(record, edge_node, type_vars)
            if ref is None:
                record.interfaces_valid = False
            else:
                edges.append(ref)
        record.interfaces = tuple(edges)

    def _parse_parameter_ref(
        self, record: TypeRecord, parameter: Any, type_vars: set[str]
    ) -> TypeRef | None:
        type_node = self.host.child_by_field(parameter, "type")
        extra_dimensions = 0
        if parameter.type == "spread_parameter":
            extra_dimensions = 1
            type_node = next(
                (
                    child
                    for child in parameter.named_children
                    if child.type not in {"modifiers", "identifier", "dimensions"}
                ),
                None,
            )
        dimensions = self.host.child_by_field(parameter, "dimensions")
        if dimensions is not None:
            extra_dimensions += self.host.node_text(record.unit["source"], dimensions).count("[")
        ref = self._parse_type_ref(record, type_node, type_vars)
        return self._with_dimensions(ref, extra_dimensions)

    @staticmethod
    def _with_dimensions(ref: TypeRef | None, extra: int) -> TypeRef | None:
        if ref is None:
            return None
        return TypeRef(ref.kind, ref.name, ref.args, ref.dimensions + extra)

    def _parse_type_ref(
        self, owner: TypeRecord, node: Any | None, type_vars: set[str]
    ) -> TypeRef | None:
        if node is None:
            return None
        if node.type in PRIMITIVE_NODE_TYPES:
            return TypeRef("primitive", self.host.node_text(owner.unit["source"], node).strip())
        if node.type == "array_type":
            base = next((child for child in node.named_children if child.type != "dimensions"), None)
            dimensions = sum(
                self.host.node_text(owner.unit["source"], child).count("[")
                for child in node.named_children
                if child.type == "dimensions"
            )
            return self._with_dimensions(self._parse_type_ref(owner, base, type_vars), dimensions)
        if node.type == "annotated_type":
            children = [
                child
                for child in node.named_children
                if child.type not in {"annotation", "marker_annotation"}
            ]
            return self._parse_type_ref(owner, children[-1] if len(children) == 1 else None, type_vars)
        if node.type == "generic_type":
            base = next((child for child in node.named_children if child.type != "type_arguments"), None)
            arguments_node = next(
                (child for child in node.named_children if child.type == "type_arguments"),
                None,
            )
            if base is None or arguments_node is None:
                return None
            base_ref = self._parse_type_ref(owner, base, type_vars)
            if base_ref is None or base_ref.kind != "decl" or base_ref.dimensions:
                return None
            arguments: list[TypeRef] = []
            for argument in arguments_node.named_children:
                if argument.type in {"wildcard", "type_bound"}:
                    return None
                parsed = self._parse_type_ref(owner, argument, type_vars)
                if parsed is None:
                    return None
                arguments.append(parsed)
            return TypeRef("decl", base_ref.name, tuple(arguments))
        if node.type not in {"type_identifier", "scoped_type_identifier", "identifier"}:
            return None
        spelling = self.host.node_text(owner.unit["source"], node).strip()
        if node.type in {"type_identifier", "identifier"} and spelling in type_vars:
            return TypeRef("variable", spelling)
        identity = self._resolve_type_identity(owner, spelling)
        return TypeRef("decl", identity) if identity is not None else None

    def _resolve_type_identity(self, owner: TypeRecord, spelling: str) -> str | None:
        unit = owner.unit
        owner_name = owner.type_info["display_name"]
        # Qualified source or explicit external spelling.
        if "." in spelling:
            candidates = self.host.resolve_workspace_owner_fqns(
                unit, spelling, owner_name, self.workspace
            )
            if len(candidates) == 1:
                return candidates[0]
            # A fully qualified external type has usable identity for method
            # signatures, but never becomes a traversal target.
            if spelling[0].islower() and not candidates:
                return spelling
            return None

        # Lexical member types have the highest source tier.
        for lexical_owner in self.host.lexical_owner_fqns(unit, owner_name):
            candidate = f"{lexical_owner}.{spelling}"
            if self.host.workspace_type_fqn_accessible(
                self.workspace, unit, owner_name, candidate
            ):
                return candidate

        exact = unit["imports"]["exact"].get(spelling)
        if exact is not None:
            if not exact:
                return None
            declarations = self.workspace["type_declarations"].get(exact, [])
            if declarations:
                return exact if self.host.workspace_type_fqn_accessible(
                    self.workspace, unit, owner_name, exact
                ) else None
            return exact

        same_package = f"{unit['package']}.{spelling}" if unit["package"] else spelling
        if self.host.workspace_type_fqn_accessible(
            self.workspace, unit, owner_name, same_package
        ):
            return same_package

        candidates = {
            f"{package}.{spelling}"
            for package in unit["imports"]["wildcards"]
            if self.host.workspace_type_fqn_accessible(
                self.workspace, unit, owner_name, f"{package}.{spelling}"
            )
        }
        if spelling in JAVA_LANG_TYPES:
            candidates.add(f"java.lang.{spelling}")
        return next(iter(candidates)) if len(candidates) == 1 else None

    # ------------------------------------------------------------------
    # Generic adaptation and signatures

    def _default_env(self, record: TypeRecord) -> dict[str, TypeRef]:
        return {
            parameter: self._nonexact_ref(
                self._adapt_ref(
                    record.type_bounds.get(
                        parameter, TypeRef("decl", "java.lang.Object")
                    ),
                    {},
                )
                or TypeRef("decl", "java.lang.Object")
            )
            for parameter in record.type_parameters
        }

    @staticmethod
    def _nonexact_ref(ref: TypeRef) -> TypeRef:
        """Mark a raw/bound substitution as erasure-only, not a runtime target."""

        return TypeRef("erasure", ref.name, ref.args, ref.dimensions)

    def _adapt_ref(
        self, ref: TypeRef | None, env: dict[str, TypeRef], stack: tuple[str, ...] = ()
    ) -> TypeRef | None:
        if ref is None:
            return None
        if ref.kind == "variable":
            if ref.name in stack:
                return None
            replacement = env.get(ref.name)
            if replacement is None:
                return None
            adapted = self._adapt_ref(replacement, env, stack + (ref.name,))
            return self._with_dimensions(adapted, ref.dimensions)
        args: list[TypeRef] = []
        for argument in ref.args:
            adapted = self._adapt_ref(argument, env, stack)
            if adapted is None:
                return None
            args.append(adapted)
        return TypeRef(ref.kind, ref.name, tuple(args), ref.dimensions)

    @staticmethod
    def _erased_type(ref: TypeRef | None) -> str | None:
        if ref is None or ref.kind == "variable":
            return None
        suffix = "[]" * ref.dimensions
        return f"{ref.name}{suffix}"

    @staticmethod
    def _env_key(env: dict[str, TypeRef]) -> tuple[tuple[str, TypeRef], ...]:
        return tuple(sorted(env.items()))

    def _method_env(self, method: MethodRecord, owner_env: dict[str, TypeRef]) -> dict[str, TypeRef]:
        env = dict(owner_env)
        for parameter in method.method_type_parameters:
            bound = method.method_type_bounds.get(
                parameter, TypeRef("decl", "java.lang.Object")
            )
            env[parameter] = self._adapt_ref(bound, env) or TypeRef(
                "decl", "java.lang.Object"
            )
        return env

    def _signature(
        self, method: MethodRecord, owner_env: dict[str, TypeRef]
    ) -> tuple[str, tuple[str, ...]] | None:
        key = (method.id, self._env_key(owner_env))
        if key in self._signature_cache:
            return self._signature_cache[key]
        if method.parameter_refs is None:
            self._signature_cache[key] = None
            return None
        env = self._method_env(method, owner_env)
        parameters: list[str] = []
        for ref in method.parameter_refs:
            erased = self._erased_type(self._adapt_ref(ref, env))
            if erased is None:
                self._signature_cache[key] = None
                return None
            parameters.append(erased)
        result = (method.name, tuple(parameters))
        self._signature_cache[key] = result
        return result

    def _edge_state(
        self, edge: TypeRef, env: dict[str, TypeRef]
    ) -> tuple[TypeRecord, dict[str, TypeRef]] | None:
        adapted = self._adapt_ref(edge, env)
        if adapted is None or adapted.kind != "decl" or adapted.dimensions:
            return None
        target = self.types.get(adapted.name)
        if target is None:
            return None
        if adapted.args:
            if len(adapted.args) != len(target.type_parameters):
                return None
            target_env = dict(zip(target.type_parameters, adapted.args))
        else:
            target_env = self._default_env(target)
        return target, target_env

    # ------------------------------------------------------------------
    # Hierarchy graph and effective method binding

    def _hierarchy(self, root: TypeRecord, root_env: dict[str, TypeRef]) -> HierarchyContext:
        complete = True
        class_states: list[tuple[TypeRecord, dict[str, TypeRef]]] = []
        seen_classes: set[str] = set()
        current = (root, root_env)
        while current is not None:
            record, env = current
            if record.fqn in seen_classes or len(class_states) >= MAX_HIERARCHY_DEPTH:
                complete = False
                break
            seen_classes.add(record.fqn)
            class_states.append(current)
            if not record.superclass_declared:
                break
            if record.superclass is None:
                complete = False
                break
            following = self._edge_state(record.superclass, env)
            if following is None or following[0].kind != "class_declaration":
                complete = False
                break
            current = following

        interface_roots: list[tuple[TypeRecord, dict[str, TypeRef]]] = []
        state_envs: dict[str, tuple[tuple[str, TypeRef], ...]] = {}
        expanded = 0

        def visit(record: TypeRecord, env: dict[str, TypeRef], depth: int, active: frozenset[str]) -> None:
            nonlocal complete, expanded
            if depth > MAX_HIERARCHY_DEPTH or expanded >= MAX_HIERARCHY_STATES:
                complete = False
                return
            if record.fqn in active:
                complete = False
                return
            env_key = self._env_key(env)
            previous = state_envs.get(record.fqn)
            if previous is not None:
                if previous != env_key:
                    complete = False
                return
            state_envs[record.fqn] = env_key
            expanded += 1
            if not record.interfaces_valid:
                complete = False
                return
            for edge in record.interfaces:
                following = self._edge_state(edge, env)
                if following is None or following[0].kind != "interface_declaration":
                    complete = False
                    continue
                visit(following[0], following[1], depth + 1, active | {record.fqn})

        for class_record, class_env in class_states:
            if not class_record.interfaces_valid:
                complete = False
                continue
            for edge in class_record.interfaces:
                following = self._edge_state(edge, class_env)
                if following is None or following[0].kind != "interface_declaration":
                    complete = False
                    continue
                interface_roots.append(following)
                visit(following[0], following[1], 1, frozenset())
        return HierarchyContext(class_states, interface_roots, complete)

    @staticmethod
    def _is_public_implementation(method: MethodRecord) -> bool:
        if "static" in method.modifiers or "private" in method.modifiers or "abstract" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return "default" in method.modifiers and method.node.child_by_field_name("body") is not None
        return "public" in method.modifiers

    @staticmethod
    def _is_ancestor_annotation_method(method: MethodRecord) -> bool:
        if "static" in method.modifiers or "private" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return True
        return "public" in method.modifiers or "protected" in method.modifiers

    def _methods_for_signature(
        self,
        record: TypeRecord,
        env: dict[str, TypeRef],
        signature: tuple[str, tuple[str, ...]],
    ) -> list[MethodRecord]:
        return [method for method in record.methods if self._signature(method, env) == signature]

    def _is_genuine_override(self, method: MethodRecord, annotation: dict[str, Any]) -> bool:
        return self.host.resolve_known_annotation(
            method.owner.unit,
            annotation["name_node"],
            {"Override"},
            ("java.lang",),
        ) is not None

    def _has_atomic_annotation_bundle(self, method: MethodRecord) -> bool:
        # Unknown direct annotations conservatively block inheritance.  This
        # covers source NameBinding annotations without guessing their meta
        # provenance.  Genuine @Override is the sole ignored marker.
        if any(not self._is_genuine_override(method, annotation) for annotation in method.annotations):
            return True
        return bool(method.parameter_annotations)

    def _interface_branches(
        self,
        state: tuple[TypeRecord, dict[str, TypeRef]],
        signature: tuple[str, tuple[str, ...]],
        mode: str,
        depth: int = 0,
        active: frozenset[str] = frozenset(),
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] | None = None,
    ) -> tuple[set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]], bool]:
        if memo is None:
            memo = {}
        record, env = state
        memo_key = (record.fqn, self._env_key(env), signature, mode)
        if memo_key in memo:
            cached_candidates, cached_invalid = memo[memo_key]
            return set(cached_candidates), cached_invalid
        if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
            return set(), True
        matches = self._methods_for_signature(record, env, signature)
        if len(matches) > 1:
            return set(), True
        if matches:
            method = matches[0]
            if mode == "default":
                if self._is_public_implementation(method):
                    result = ({(method.id, self._env_key(env))}, False)
                    memo[memo_key] = result
                    return set(result[0]), result[1]
                return set(), True
            if self._has_atomic_annotation_bundle(method):
                result = ({(method.id, self._env_key(env))}, False)
                memo[memo_key] = result
                return set(result[0]), result[1]
            # An unannotated interface redeclaration does not suppress an
            # annotation bundle on its parent declaration.
        if not record.interfaces_valid:
            return set(), True
        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
        blocked = False
        for edge in record.interfaces:
            following = self._edge_state(edge, env)
            if following is None or following[0].kind != "interface_declaration":
                blocked = True
                continue
            found, invalid = self._interface_branches(
                following,
                signature,
                mode,
                depth + 1,
                active | {record.fqn},
                memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        memo[memo_key] = (set(candidates), blocked)
        return candidates, blocked

    def _method_from_candidate(
        self,
        candidate: tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]],
    ) -> tuple[MethodRecord, dict[str, TypeRef]] | None:
        method_id, env_key = candidate
        for record in self.types.values():
            for method in record.methods:
                if method.id == method_id:
                    return method, dict(env_key)
        return None

    def _interface_subtype(
        self,
        child: tuple[MethodRecord, dict[str, TypeRef]],
        ancestor_fqn: str,
    ) -> tuple[bool, bool]:
        record = child[0].owner
        env = child[1]
        pending = [(record, env, 0)]
        visited: set[tuple[str, tuple[tuple[str, TypeRef], ...]]] = set()
        while pending:
            current, current_env, depth = pending.pop()
            state_key = (current.fqn, self._env_key(current_env))
            if state_key in visited:
                continue
            visited.add(state_key)
            if depth > MAX_HIERARCHY_DEPTH or len(visited) > MAX_HIERARCHY_STATES:
                return False, True
            if current.fqn == ancestor_fqn and current.fqn != record.fqn:
                return True, False
            if not current.interfaces_valid:
                return False, True
            for edge in current.interfaces:
                following = self._edge_state(edge, current_env)
                if following is None or following[0].kind != "interface_declaration":
                    return False, True
                pending.append((following[0], following[1], depth + 1))
        return False, False

    def _maximally_specific_candidates(
        self,
        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]],
    ) -> tuple[set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]], bool]:
        resolved = {
            candidate: self._method_from_candidate(candidate)
            for candidate in candidates
        }
        if any(value is None for value in resolved.values()):
            return set(), True
        dominated: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
        for candidate, value in resolved.items():
            for other, other_value in resolved.items():
                if candidate == other:
                    continue
                is_subtype, invalid = self._interface_subtype(
                    other_value, value[0].owner.fqn
                )
                if invalid:
                    return set(), True
                if is_subtype:
                    dominated.add(candidate)
                    break
        return candidates - dominated, False

    def _annotation_source(
        self,
        implementation: MethodRecord,
        implementation_env: dict[str, TypeRef],
        signature: tuple[str, tuple[str, ...]],
        hierarchy: HierarchyContext,
        implementation_class_index: int | None,
    ) -> MethodRecord | None:
        if self._has_atomic_annotation_bundle(implementation):
            return implementation

        start = (implementation_class_index + 1) if implementation_class_index is not None else 0
        for record, env in hierarchy.class_states[start:]:
            matches = [
                method
                for method in self._methods_for_signature(record, env, signature)
                if self._is_ancestor_annotation_method(method)
            ]
            if len(matches) > 1:
                return None
            if matches and self._has_atomic_annotation_bundle(matches[0]):
                return matches[0]

        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self._interface_branches(
                interface_root, signature, "annotation", memo=memo
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self._maximally_specific_candidates(candidates)
        blocked = blocked or specificity_invalid
        # A single source declaration reached through a diamond is one origin.
        source_ids = {candidate[0] for candidate in candidates}
        if blocked or len(source_ids) != 1:
            return None
        return self._method_from_candidate(next(iter(candidates)))[0]

    def _annotation_kind(self, method: MethodRecord, annotation: dict[str, Any]) -> str:
        unit = method.owner.unit
        for package_group in (
            self.host.JAX_RS_PACKAGES,
            self.host.JAX_RS_CORE_PACKAGES,
            ("jakarta.ws.rs.container", "javax.ws.rs.container"),
        ):
            resolved = self.host.resolve_known_annotation(
                unit,
                annotation["name_node"],
                JAX_METHOD_ANNOTATIONS,
                package_group,
            )
            if resolved is not None:
                return resolved["name"]
        custom = self.host.resolve_custom_designator(
            unit,
            annotation["name_node"],
            self.workspace,
            f"{method.owner.type_info['display_name']}.{method.name}",
        )
        return "custom" if custom["status"] != "none" else "other"

    def _standard_jax_annotation_family(
        self, method: MethodRecord, annotation: dict[str, Any]
    ) -> str | None:
        unit = method.owner.unit
        package_groups = (
            self.host.JAX_RS_PACKAGES,
            self.host.JAX_RS_CORE_PACKAGES,
            ("jakarta.ws.rs.container", "javax.ws.rs.container"),
        )
        for packages in package_groups:
            resolved = self.host.resolve_known_annotation(
                unit,
                annotation["name_node"],
                JAX_METHOD_ANNOTATIONS,
                packages,
            )
            if resolved is not None:
                return (
                    "jakarta.ws.rs"
                    if resolved["namespace"].startswith("jakarta.ws.rs")
                    else "javax.ws.rs"
                )
        return None

    def _decode_binding(
        self, method: MethodRecord, namespace: str
    ) -> dict[str, Any] | None:
        owner_name = f"{method.owner.type_info['display_name']}.{method.name}"
        for annotation in method.annotations + method.parameter_annotations:
            family = self._standard_jax_annotation_family(method, annotation)
            if family is not None and family != namespace:
                self.log(method, "mixed Javax/Jakarta effective annotation bundle")
                return None
        annotation_kinds = [self._annotation_kind(method, annotation) for annotation in method.annotations]
        designator_evidence = any(
            kind in set(self.host.JAX_RS_HTTP_METHODS) | {"custom"}
            for kind in annotation_kinds
        )
        path_evidence = "Path" in annotation_kinds
        designator = self.host.resolve_jax_method_designator(
            method.owner.unit,
            list(method.annotations),
            self.workspace,
            namespace,
            owner_name,
        )
        if designator_evidence and designator is None:
            return None
        method_path = self.host.resolve_jax_method_path(
            method.owner.unit,
            list(method.annotations),
            namespace,
            method.owner.type_info["display_name"],
            owner_name,
            self.workspace,
        )
        if method_path is None:
            return None
        if designator is not None:
            return {
                "kind": "leaf",
                "path": method_path,
                "method": designator["method"],
                "evidence_node": designator["node"],
            }
        if path_evidence and method_path:
            path_node = next(
                (
                    annotation["node"]
                    for annotation, kind in zip(method.annotations, annotation_kinds)
                    if kind == "Path"
                ),
                method.node,
            )
            return {"kind": "locator", "path": method_path, "evidence_node": path_node}
        return None

    def _interface_type_path(
        self, effective: EffectiveMethod, namespace: str
    ) -> str | None:
        """Return the selected interface contract's direct ``@Path`` layer.

        Noir composes an implemented interface's type path with the concrete
        root and method path.  Superclass type paths remain intentionally
        excluded.  Keep the stronger source identity and namespace checks of
        this analyzer while preserving that valid interface route layer.
        """

        source_owner = effective.annotation_source.owner
        if (
            not effective.hierarchy_added
            or source_owner.kind != "interface_declaration"
        ):
            return ""
        unit = source_owner.unit
        modifiers = next(
            (
                child
                for child in source_owner.type_info["node"].named_children
                if child.type == "modifiers"
            ),
            None,
        )
        records = []
        if modifiers is not None:
            for annotation in modifiers.named_children:
                if annotation.type not in {"annotation", "marker_annotation"}:
                    continue
                name_node = self.host.child_by_field(annotation, "name")
                if name_node is not None:
                    records.append({"node": annotation, "name_node": name_node})
        candidates = []
        for record in records:
            resolved = self.host.resolve_known_annotation(
                unit,
                record["name_node"],
                {"Path"},
                self.host.JAX_RS_PACKAGES,
            )
            if resolved is not None:
                candidates.append((record, resolved))
        if not candidates:
            return ""
        if len(candidates) != 1 or candidates[0][1]["namespace"] != namespace:
            self.log(
                effective.annotation_source,
                "ambiguous or mixed interface type @Path",
            )
            return None
        owner_name = source_owner.type_info["display_name"]
        return self.host.decode_jax_path_annotation(
            unit,
            candidates[0][0],
            owner_name,
            owner_name,
            "interface type @Path value",
            self.workspace,
        )

    def _effective_methods(
        self, resource: TypeRecord, env: dict[str, TypeRef], namespace: str
    ) -> list[EffectiveMethod]:
        cache_key = (resource.fqn, self._env_key(env), namespace)
        if cache_key in self._effective_cache:
            return self._effective_cache[cache_key]

        hierarchy = self._hierarchy(resource, env)
        effective: list[EffectiveMethod] = []
        handled_direct_ids: set[tuple[Any, ...]] = set()
        direct_signature_counts: dict[tuple[str, tuple[str, ...]], int] = {}
        for method in resource.methods:
            signature = self._signature(method, env)
            if signature is not None:
                direct_signature_counts[signature] = direct_signature_counts.get(signature, 0) + 1

        # Direct methods remain usable even when an unrelated hierarchy edge
        # cannot be resolved.  Only inherited binding requires a complete graph.
        for method in resource.methods:
            if not self._is_public_implementation(method):
                continue
            signature = self._signature(method, env)
            if signature is not None and direct_signature_counts[signature] != 1:
                self.log(method, "duplicate erased method signature")
                continue
            source = method
            if not self._has_atomic_annotation_bundle(method):
                if not hierarchy.complete or signature is None:
                    continue
                source = self._annotation_source(method, env, signature, hierarchy, 0)
                if source is None:
                    continue
            binding = self._decode_binding(source, namespace)
            if binding is None:
                continue
            effective.append(
                EffectiveMethod(
                    implementation=method,
                    implementation_env=env,
                    annotation_source=source,
                    binding=binding,
                    hierarchy_added=source.id != method.id,
                    signature=signature,
                )
            )
            handled_direct_ids.add(method.id)

        if not hierarchy.complete:
            self._effective_cache[cache_key] = effective
            return effective

        signatures: set[tuple[str, tuple[str, ...]]] = set()
        unresolved_names = {method.name for method in resource.methods if self._signature(method, env) is None}
        for record, state_env in hierarchy.class_states:
            signatures.update(
                signature
                for method in record.methods
                if (signature := self._signature(method, state_env)) is not None
            )

        def collect_interface_signatures(
            state: tuple[TypeRecord, dict[str, TypeRef]],
            depth: int = 0,
            active: frozenset[str] = frozenset(),
        ) -> None:
            record, state_env = state
            if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
                return
            signatures.update(
                signature
                for method in record.methods
                if (signature := self._signature(method, state_env)) is not None
            )
            for edge in record.interfaces:
                following = self._edge_state(edge, state_env)
                if following is not None:
                    collect_interface_signatures(
                        following, depth + 1, active | {record.fqn}
                    )

        for interface_root in hierarchy.interface_roots:
            collect_interface_signatures(interface_root)

        for signature in sorted(signatures):
            if signature[0] in unresolved_names:
                continue
            implementation: MethodRecord | None = None
            implementation_env: dict[str, TypeRef] | None = None
            implementation_index: int | None = None
            malformed = False
            for index, (record, state_env) in enumerate(hierarchy.class_states):
                matches = self._methods_for_signature(record, state_env, signature)
                if not matches:
                    continue
                if len(matches) != 1 or not self._is_public_implementation(matches[0]):
                    malformed = True
                    break
                implementation = matches[0]
                implementation_env = state_env
                implementation_index = index
                break
            if malformed:
                continue
            if implementation is None:
                candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
                blocked = False
                memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
                for interface_root in hierarchy.interface_roots:
                    found, invalid = self._interface_branches(
                        interface_root, signature, "default", memo=memo
                    )
                    candidates.update(found)
                    blocked = blocked or invalid
                candidates, specificity_invalid = self._maximally_specific_candidates(
                    candidates
                )
                blocked = blocked or specificity_invalid
                if blocked or len({candidate[0] for candidate in candidates}) != 1:
                    continue
                resolved = self._method_from_candidate(next(iter(candidates)))
                if resolved is None:
                    continue
                implementation, implementation_env = resolved
            if implementation.id in handled_direct_ids:
                continue
            source = self._annotation_source(
                implementation,
                implementation_env,
                signature,
                hierarchy,
                implementation_index,
            )
            if source is None:
                continue
            binding = self._decode_binding(source, namespace)
            if binding is None:
                continue
            effective.append(
                EffectiveMethod(
                    implementation=implementation,
                    implementation_env=implementation_env,
                    annotation_source=source,
                    binding=binding,
                    hierarchy_added=True,
                    signature=signature,
                )
            )

        effective.sort(
            key=lambda item: (
                item.implementation.owner.fqn,
                item.implementation.name,
                item.signature or (item.implementation.name, ()),
                item.implementation.node.start_byte,
            )
        )
        self._effective_cache[cache_key] = effective
        return effective

    # ------------------------------------------------------------------
    # Recursive subresource collection

    def _target_from_return(
        self, effective: EffectiveMethod
    ) -> tuple[TypeRecord, dict[str, TypeRef]] | None:
        method = effective.implementation
        env = self._method_env(method, effective.implementation_env)
        returned = self._adapt_ref(method.return_ref, env)
        if returned is None or returned.kind != "decl" or returned.dimensions:
            return None
        if returned.name == "java.lang.Class":
            if len(returned.args) != 1:
                return None
            returned = returned.args[0]
            if returned.kind != "decl" or returned.dimensions:
                return None
        target = self.types.get(returned.name)
        if (
            target is None
            or target.kind not in {"class_declaration", "record_declaration"}
            or target.type_info["abstract"]
        ):
            return None
        if returned.args:
            if len(returned.args) != len(target.type_parameters):
                return None
            target_env = dict(zip(target.type_parameters, returned.args))
        else:
            target_env = self._default_env(target)
        return target, target_env

    def _endpoint(
        self, effective: EffectiveMethod, uri: str
    ) -> dict[str, Any]:
        method = effective.implementation
        owner_name = f"{method.owner.type_info['display_name']}.{method.name}"
        return {
            "uri": uri,
            "method": effective.binding["method"],
            "uri_params": self.host.get_callable_parameters_as_is(
                method.owner.unit["source"], method.parameters_node
            ),
            "SrcFile": method.owner.unit["fname"],
            "SrcLine": method.node.start_point.row + 1,
            "SFunction": owner_name,
        }

    def _collect(
        self,
        resource: TypeRecord,
        env: dict[str, TypeRef],
        namespace: str,
        base_uri: str,
        via_locator: bool,
        depth: int,
        active_types: frozenset[TypeState],
        active_edges: frozenset[tuple[Any, ...]],
        budget: dict[str, int],
    ) -> list[dict[str, Any]]:
        state = TypeState(resource.fqn, self._env_key(env))
        if state in active_types or depth > MAX_SUBRESOURCE_DEPTH:
            self.log(resource, "cyclic or over-depth subresource traversal")
            return []
        if budget["states"] >= MAX_SUBRESOURCE_STATES:
            self.log(resource, "over-state-limit subresource traversal")
            return []
        budget["states"] += 1
        branch_types = active_types | {state}
        endpoints: list[dict[str, Any]] = []
        for effective in self._effective_methods(resource, env, namespace):
            interface_path = self._interface_type_path(effective, namespace)
            if interface_path is None:
                continue
            composed = self.host.combine_paths(
                self.host.combine_paths(base_uri, interface_path),
                effective.binding["path"],
            )
            if len(composed) > MAX_COMPOSED_PATH:
                self.log(effective.implementation, "over-length subresource path")
                continue
            if effective.binding["kind"] == "leaf":
                if via_locator or effective.hierarchy_added:
                    endpoint = self._endpoint(effective, composed)
                    endpoints.append(endpoint)
                    self.host.debug_log(endpoint)
                continue

            target_state = self._target_from_return(effective)
            if target_state is None:
                self.log(effective.implementation, "unresolved subresource locator return type")
                continue
            target, target_env = target_state
            edge_key = (
                effective.implementation.id,
                effective.signature,
                target.fqn,
                self._env_key(target_env),
            )
            if edge_key in active_edges:
                self.log(effective.implementation, "cyclic subresource locator edge")
                continue
            endpoints.extend(
                self._collect(
                    target,
                    target_env,
                    namespace,
                    composed,
                    True,
                    depth + 1,
                    branch_types,
                    active_edges | {edge_key},
                    budget,
                )
            )
        return endpoints

    def analyze(self) -> list[dict[str, Any]]:
        endpoints: list[dict[str, Any]] = []
        for fqn in sorted(self.types):
            record = self.types[fqn]
            if (
                record.kind not in {"class_declaration", "record_declaration"}
                or record.type_info["abstract"]
                or not record.type_info["workspace_visible"]
            ):
                continue
            root = self.host.resolve_jax_root(record.unit, record.type_info, self.workspace)
            if root is None:
                continue
            application_path = self.host.select_jax_application_path(
                self.workspace,
                record.unit,
                root["namespace"],
                record.type_info["display_name"],
            )
            if application_path is None:
                continue
            base_uri = self.host.combine_paths(application_path, root["path"])
            if len(base_uri) > MAX_COMPOSED_PATH:
                self.log(record, "over-length resource root path")
                continue
            endpoints.extend(
                self._collect(
                    record,
                    self._default_env(record),
                    root["namespace"],
                    base_uri,
                    False,
                    0,
                    frozenset(),
                    frozenset(),
                    {"states": 0},
                )
            )
        # The host's final six-column formatter/deduper remains authoritative;
        # remove exact internal duplicates here so standalone callers are also
        # deterministic.
        unique = {
            (
                endpoint["method"],
                endpoint["uri"],
                endpoint["SrcFile"],
                endpoint["SFunction"],
                endpoint["uri_params"],
            ): endpoint
            for endpoint in endpoints
        }
        return [unique[key] for key in sorted(unique)]


def analyze_jax_recall(workspace: dict[str, Any], host: Any) -> list[dict[str, Any]]:
    """Return only hierarchy/subresource endpoint additions for ``workspace``.

    Call this once after ``host.build_jax_workspace`` and append its rows to
    the ordinary direct-JAX endpoint list before the host formatter/deduper.
    """

    return JaxRecallAnalyzer(workspace, host).analyze()
