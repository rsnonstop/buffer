## Context

The scanner already has the two broad phases needed by this change. It first
loads every discovered Java source into one workspace and builds the existing
annotation inventory, then runs all enabled direct, recall, hierarchy,
configuration, client, and WebSocket analyzers before formatting and
deduplicating endpoint rows. The final six-field grouping in
`deduplicate_and_sort_rows` is the first point at which the logical rows that
will survive into the CSV are known.

Neither current output model can answer the new membership question. The
annotation inventory deliberately includes supporting and definition metadata
and retains no exact applied target. Endpoint rows expose display names,
parameters, and source lines, which are lossy for overloaded methods, record
components, inherited declarations, and type-level WebSocket endpoints. The
private `method_annotation_line` evidence describes causal annotation
provenance, not the source target represented by a row. It is deliberately
empty or points elsewhere for several cases that still establish target
membership.

The implementation is procedural and endpoint analyzers exchange small
dictionaries. Direct Spring analysis parses the same immutable source bytes in
a separate Tree-sitter tree, while the remaining analyzers primarily use nodes
from the shared workspace. The design must therefore add exact internal
identity without changing public endpoint dictionaries, the CSV schema, the
existing annotation-inventory shape, or analyzer success rules.

## Goals / Non-Goals

**Goals:**

- Discover only genuine final-trigger-capable occurrences in a placement where
  their supported semantic family can be a final trigger, independently of
  later endpoint rejection.
- Give candidates and endpoint candidates a common exact source-target
  identity that works across the two Java parses.
- Preserve all represented target identities through analyzer-local and final
  endpoint deduplication without affecting public identity, ordering, or
  annotation provenance.
- Decide absence globally after all enabled analyzers, Spring configuration,
  normalization, and final deduplication.
- Render the specified deterministic per-file/per-framework report and publish
  it without replacing a prior completed report on a failed run.
- Preserve existing `analyze_module`, deduplication, CSV, companion-log, and
  framework-filter behavior for current callers.

**Non-Goals:**

- Discover new endpoints, annotation identities, semantic families, or source
  placements.
- Treat supporting annotations such as `Path`, `Controller`, `FeignClient`, or
  `Bean` as final triggers.
- Decide whether an annotation caused a row or compare candidates with
  `method_annotation_line`.
- Add target or candidate information to the public CSV or existing companion
  log.
- Replace all endpoint dictionaries with a new object hierarchy.
- Add transactional rollback for the existing CSV or companion log, or delete
  previously generated absent-trigger reports during rollback.

## Decisions

### 1. Join candidates and endpoints with an exact source-target identity

Introduce one immutable private target value with this logical shape:

```text
SourceTargetId = (
    canonical source file,
    target kind,
    declaration start byte,
    declaration end byte,
)
```

The target kind is one of `method`, `record-component`, or `type`. Canonical
file identity prevents path aliases from matching, and the kind prevents an
accidental cross-form collision. Declaration byte spans, rather than names,
lines, or signatures, identify the exact parsed source element. They also let
the direct Spring tree and workspace tree produce the same identity because
both parse the source bytes captured at the beginning of the run.

Each finalized trigger candidate will contain only scalar report state:

- framework and semantic family;
- canonical occurrence identity consisting of file and annotation byte span;
- terminal source name and resolved fully qualified identity;
- exact `SourceTargetId` and precomputed `Applied to` label;
- one-based starting line and bounded source extract.

Candidate discovery will not retain Tree-sitter nodes beyond workspace
analysis. Relative POSIX paths remain presentation data and do not participate
in membership.

For display, existing lexical type `display_name` values supply nested owner
names. A separate parameter-label helper will take the complete source between
the parser-identified method-parameter parentheses, replace every run of
`space`, `tab`, `form feed`, `carriage return`, or `line feed` with one ASCII
space, and trim ASCII spaces. The existing `get_callable_parameters_as_is`
helper will remain unchanged because its output is part of the CSV contract.

Alternative considered: use `(source_file_name, method_name, parameters)` or a
source line as the join key. This was rejected because those fields cannot
identify record components or types and can collide or diverge for overloads,
inheritance, synthetic accessors, and normalized display text.

### 2. Build a dedicated closed trigger-candidate catalog

Add a candidate collector over `unit["annotation_occurrences"]` after the
shared workspace has built its source-definition indexes. This generic
occurrence list is required because the current owner-specific method query
does not include every interface contract position. The collector first finds
the declaration whose `modifiers` directly contain the annotation, then
applies a closed identity-and-placement policy:

| Semantic family | Trigger-capable applied target |
| --- | --- |
| Direct or composed Spring MVC mapping | method in a class, record, or interface; supported potential implicit-accessor record component |
| Spring HTTP Exchange mapping | method declared by an interface |
| Spring message mapping | method in a class or record |
| Standard or custom JAX-RS request-method designator | method in a class, record, or interface; supported potential implicit-accessor record component |
| Jakarta/Javax `ServerEndpoint` | class or record type |

The direct registry will enumerate the exact supported fully qualified
identities, framework, semantic family, and allowed placement policy. It will
reuse `resolve_known_annotation` and the existing workspace source-ownership
checks, so import ambiguity, local shadows, wildcard conflicts, and analyzed
same-FQN declarations continue to fail closed. This registry is intentionally
separate from the broader annotation-inventory registry and will have a
coverage test against every supported final-trigger family.

Source-defined Spring and JAX classifications will invoke the existing bounded
definition resolvers independently. Spring composition must pass
`spring_composed_definition_is_supported`; JAX custom designators must resolve
uniquely through the current custom-designator index. A record-component use
will also reuse the existing method-applicability rule that models propagation
to a potential implicit accessor. The retained identity, name, line, target,
and extract always belong to the outer use-site occurrence. An occurrence can
qualify independently for both enabled frameworks.

Placement is the only use-site gate in this collector. Abstractness,
visibility, activation, owner uniqueness, explicit accessor presence,
constructor shape, path/value decoding, deployment configuration, and other
endpoint conditions remain later analyzer decisions. Type-level mapping
modifiers, annotation-definition metadata, enum or annotation declarations,
fields, ordinary parameters, locals, packages, and type uses fail the
placement policy.

Within a file and framework, the occurrence byte span is the deduplication
identity. Repeated discovery must agree on the same resolved classification;
an ambiguous conflict fails closed instead of rendering competing items. Two
distinct annotations on one target remain two candidates, and one dual-family
outer occurrence remains one item in each applicable framework section.

Alternative considered: filter the rendered broad annotation inventory. This
was rejected because that projection has already discarded target structure
and deliberately contains supporting annotations and definition metadata.
Instrumenting successful endpoint emission was also rejected because it would
miss precisely the later-rejected occurrences this report is intended to show.

### 3. Attribute exactly one represented target to every raw endpoint candidate

Every built-in endpoint producer will attach a singleton private represented
target collection when it creates a raw endpoint dictionary. Attribution
follows the source element represented by the endpoint, never every element
that contributed route or annotation evidence:

| Endpoint producer | Represented target |
| --- | --- |
| Direct Spring or JAX method analysis | exact method declaration |
| Direct Spring or JAX implicit record accessor | exact record component |
| Spring HTTP Interface, Feign, or message analysis | exact contract/handler method |
| Spring hierarchy | concrete implementation method, not inherited mapping source |
| JAX hierarchy or subresource recall | effective implementation method, not annotation source |
| Spring functional/programmatic recall | effective handler method, or publisher method when it is the represented handler |
| Spring Gateway, resource handler, or WebSocket registration | exact publisher/configuration method already attributed to the row |
| JAX `ServerEndpoint` | exact annotated class or record |

An explicit record accessor is a distinct method target and never inherits the
record component's target identity. Conversely, an endpoint synthesized from
the component retains the component target even though its public function
looks like an accessor. Configuration application already copies endpoint
dictionaries; therefore it preserves target evidence for retained endpoints
and naturally removes the evidence of endpoints it rejects.

Use a shared constructor for target identities and a shared endpoint-evidence
merge helper. A raw producer must contribute exactly one valid target. A
post-dedup endpoint dictionary may contain more than one because several raw
candidates can collapse. Focused coverage will enforce the singleton producer
invariant for every analyzer family instead of permitting a fallback inferred
from `SFunction`, parameters, or source lines.

Alternative considered: mark both an inherited contract and its concrete
implementation as represented. This was rejected because the route source is
supporting evidence; the row is attributed to the distinct concrete method.

### 4. Union private target evidence through every deduplication layer

Generalize the existing private-evidence merge behavior so it preserves the
same last-candidate survivor for ordinary fields while unioning both
method-annotation evidence and represented target identities. Keep the current
method-evidence helper as a compatibility wrapper if callers use it directly.
Every analyzer-local deduplicator, including the currently last-wins-only
Spring recall, Gateway, resource-handler, client, WebSocket, and JAX recall
paths, will route collisions through the shared merge behavior. Private target
sets never participate in a local or public endpoint key.

A merged internal endpoint may therefore retain multiple private
method-annotation evidence records and multiple represented targets. This is
intentional: finalization continues to select exactly one public
`method_annotation_line` using the existing provenance priority, while absent
membership uses the complete private represented-target union and never the
selected public annotation line.

Refactor final grouping into an internal finalizer that performs the existing
normalization and grouping by the original six public identity fields and
returns:

- the same ordered public row dictionaries, including unchanged
  `method_annotation_line` selection; and
- the represented-target union retained by each surviving logical group, from
  which a global union is obtained.

`format_endpoint` will carry the small private target values alongside current
private annotation evidence. `write_csv` will still receive only declared
public fields. The existing `deduplicate_and_sort_rows` function will remain a
wrapper returning its current list of public rows, while the CLI uses the
richer finalizer. `analyze_module` will likewise keep returning the current
endpoint list and accept an optional candidate-catalog output parameter
parallel to `annotation_inventory`.

```text
workspace trigger candidates
                 │
all enabled raw endpoint candidates
                 │ attach one exact represented target each
                 ▼
analyzer-local merges union private targets
                 ▼
Spring configuration and shared formatting
                 ▼
legacy six-field final grouping unions private targets
                 ├──────────► unchanged public CSV rows
                 ▼
global represented-target set
                 │
candidate target membership filter
                 ▼
absent-trigger report items
```

The membership test is simply whether a candidate's target is absent from the
global represented-target union. It is not evaluated per framework section.
Framework selection already limits both the collected candidate
classifications and endpoint analyzers included in that union. Fan-out adds no
special case, and two different targets collapsed into one logical row both
remain represented.

Alternative considered: collect targets before final grouping or retain only
the dedup survivor's target. Although a pre-group global set can appear
equivalent today, retaining the union on each logical group makes the required
survivor semantics explicit and prevents future filters from silently losing
target evidence.

### 5. Render a pure report projection without changing the companion log

After finalization, filter each candidate catalog by the global represented
target set and render every discovered file with the enabled framework
sections. Reuse one shared bounded row-extraction core for complete annotation
lines plus the next 10 non-empty lines. Keep the existing
`annotation_source_extract` point-row adapter for the compatibility-sensitive
broad inventory, and use a byte-aligned Java physical-line adapter for the new
absent report so LF, CRLF, and CR terminators remain aligned with annotation
byte spans while form feed remains source content. Keep
`build_annotation_inventory`, `annotation_inventory_lines`, and
`render_annotation_log` unchanged.

The absent-report renderer will operate only on scalar catalog records and
return bytes rather than opening its destination. It will build and join items,
framework sections, and file blocks with explicit single blank lines. Sorting
is by relative POSIX file path, fixed framework order (`spring`, then `jaxrx`),
and annotation `(start_byte, end_byte)`. A non-empty rendering is encoded once
as UTF-8 without a BOM and receives exactly one final LF; a successful run with
no Java files renders `b""`. No diagnostics or timestamps enter this
projection.

Keeping rendering pure separates membership and layout tests from filesystem
failure tests and ensures a rendering error cannot partially modify an older
report.

### 6. Publish the new report atomically as the last fallible success step

Derive the path with `Path` operations: remove `output_path.suffix` once when
present, then append `-anno-without-endpoints.log` to the remaining filename.
Do not create, truncate, or otherwise touch this destination at CLI startup or
on any error path.

The successful CLI lifecycle will be:

1. collect candidates and all enabled endpoint candidates;
2. finalize endpoints and render the absent-report bytes in memory;
3. write the CSV using its existing behavior;
4. render the existing `<output>.log` using its existing behavior; and
5. atomically publish the absent-report bytes, then return success.

Publication will create a unique temporary file in the destination directory,
write the bytes in binary mode, flush and sync it, close it, and call
`os.replace` for the destination. The replace is the last fallible external
operation on the success path. Any write, sync, close, or replace error causes
best-effort removal of the exact temporary file and is re-raised; the
destination is never opened in place. Thus a prior completed report remains
unchanged, and a first failed run leaves the derived path absent. The same
mechanism publishes a zero-byte successful report.

Publishing last deliberately permits a newly written CSV or companion log to
coexist with an old or absent new report when report publication fails. This is
the existing per-file behavior explicitly retained by the specification; a
multi-file generation transaction would require a separate output protocol.

Alternative considered: open the report early and fill it incrementally. This
was rejected because analyzer, CSV, companion-log, and renderer failures would
destroy the previous completed result or expose partial membership decisions.

### 7. Verify classification, attribution, merging, layout, and compatibility separately

Add a focused absent-trigger report test module with these layers:

- pure path and atomic-publication tests for extensionless and multi-suffix
  outputs, replacement, first-run failure, prior-content preservation,
  temporary cleanup, empty bytes, UTF-8, and LF behavior;
- pure renderer tests for exact field/indentation order, blank-line rules,
  empty sections, fixed framework and file order, same-line byte ordering,
  exactly 10 following non-empty lines, Unicode, and exclusion of
  diagnostics/timestamps;
- candidate-collector tests for direct, source-defined, interface, abstract,
  record-component, nested/overloaded method, and `ServerEndpoint` placements,
  plus every excluded supporting identity and unsupported source form;
- target-attribution tests for every endpoint producer, including concrete
  hierarchy implementations, explicit versus implicit record accessors,
  functional handlers, registration methods, and type-level WebSockets;
- parameterized collision tests for every analyzer-local deduplicator, Spring
  configuration retention/rejection tests, and final dedup tests proving that
  multiple private annotation records and represented targets survive where
  appropriate while one legacy row, public fields, row order, and the selected
  annotation provenance do not change; and
- CLI lifecycle and cross-framework integration tests for late/cross-file
  membership, framework filtering, deterministic reruns, no-Java success, and
  all controlled failure boundaries.

The existing annotation-log suite remains the compatibility gate for the broad
inventory and diagnostics. Existing endpoint and method-annotation-line suites
remain the gates for byte-compatible CSV behavior and provenance selection,
and the full test suite is required before completion.

## Risks / Trade-offs

- **[A producer omits or misattributes a target]** -> Centralize target
  construction, maintain the explicit producer matrix, and assert singleton
  target evidence for every raw built-in endpoint family.
- **[A local deduplicator drops a represented target]** -> Route every
  collision through the shared private-evidence merge and test local as well
  as final fan-in.
- **[Candidate support drifts from endpoint support]** -> Keep a closed
  final-trigger registry with a complete family coverage matrix and reuse the
  existing identity and source-definition resolvers rather than package
  inference.
- **[Separate parser trees produce different identities]** -> Build identities
  from canonical file plus kind and byte span, require both trees to consume
  the immutable captured bytes, and test direct Spring/workspace equivalence.
- **[The new finalizer changes existing public behavior]** -> Preserve the
  old wrapper APIs and six-field key, keep private evidence outside sorting and
  normalization, and compare projected/public outputs byte-for-byte.
- **[Candidate collection changes the broad inventory]** -> Keep a separate
  scalar catalog and leave all current inventory collection and rendering
  functions untouched.
- **[Evidence increases memory on large fan-out]** -> Store small immutable
  target tuples, union them during existing dedup passes, and avoid retaining
  AST nodes or duplicating extracts per endpoint row.
- **[Report publication fails after the CSV changes]** -> Publish the report
  individually and last, fail the run, preserve the previous report, and keep
  CSV rollback outside this change as specified.
- **[Rollback leaves a stale derived report]** -> Do not delete user output
  automatically; document that consumers should ignore or explicitly remove
  the exact derived artifact after rollback.

## Migration Plan

1. Add private target/candidate helpers and the closed candidate classifier,
   retaining existing public projections.
2. Attach singleton represented targets at every endpoint producer and update
   all analyzer-local merge paths.
3. Introduce the richer finalizer while preserving the existing dedup wrapper
   and prove public row/provenance invariance.
4. Add pure rendering, path derivation, and atomic publication helpers, then
   connect publication as the CLI's final success step.
5. Run focused candidate, target, merge, renderer, and lifecycle tests followed
   by the complete endpoint, inventory, diagnostic, and CSV regression suite.

No stored-data migration is required. Rollback reverts the optional catalog,
private target evidence, richer finalizer, and final publication step. Existing
CSV and companion-log behavior then continues unchanged; already generated
absent-trigger report files are left untouched rather than deleted.
