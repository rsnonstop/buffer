## 1. Exact Target and Private Evidence Foundation

- [x] 1.1 Add the private `SourceTargetId` representation using canonical source file, target kind, and declaration byte span, with constructors for method, record-component, and class/record type nodes.
- [x] 1.2 Add validation and deterministic union helpers that require one represented target on each raw built-in endpoint candidate while permitting a merged endpoint to retain multiple targets, without exposing targets as public fields.
- [x] 1.3 Generalize endpoint private-evidence merging to preserve the existing last-candidate survivor while unioning both method-annotation evidence and represented targets, and retain the current method-evidence merge API as a compatibility wrapper.
- [x] 1.4 Add focused unit tests for exact span identity, target-kind separation, canonical-file matching, direct-Spring/workspace cross-tree equivalence, deterministic target union, and unchanged last-candidate behavior.

## 2. Final-Trigger Candidate Catalog

- [x] 2.1 Implement direct applied-target discovery from generic annotation occurrences by requiring a declaration-modifier relationship and recognizing eligible class/interface/record methods, potential implicit-accessor record components, and class/record types while rejecting unsupported source forms.
- [x] 2.2 Add report-only target-label builders for methods, record components, and types, including nested lexical owner names and the specified ASCII-whitespace normalization of complete method parameter source without changing `get_callable_parameters_as_is()`.
- [x] 2.3 Add a closed direct final-trigger registry covering the supported Spring MVC, HTTP Exchange, message, Javax/Jakarta JAX-RS request-method, and Javax/Jakarta `ServerEndpoint` identities with their framework, semantic family, and placement policy.
- [x] 2.4 Implement direct candidate classification with the existing exact-identity, import ambiguity, local/source shadowing, same-FQN ownership, and framework-selection rules, without applying endpoint activation, visibility, value-decoding, or other later gates.
- [x] 2.5 Implement source-defined candidate classification through the existing bounded Spring composition and JAX custom-designator resolvers, retaining the outer use-site occurrence, supporting independent dual-framework classification, and applying the existing record-component method-applicability rule.
- [x] 2.6 Build a scalar candidate catalog for every discovered Java file, reusing bounded annotation extracts, retaining enabled-framework sections, sorting by relative POSIX path and exact occurrence span, and deduplicating only repeated same-framework discovery of one occurrence.
- [x] 2.7 Extend `analyze_module()` with an optional candidate-catalog output parameter parallel to `annotation_inventory` while preserving its endpoint-list return value and all existing callers.
- [x] 2.8 Add collector tests for every included identity and placement, abstract/invisible/unbound owners, invalid outer values, cyclic/ambiguous definitions, interface contracts, nested and overloaded methods, record components with explicit accessors, `ServerEndpoint` later failures, dual-framework outer uses, shadows, framework filtering, and exclusions for type modifiers, supporting/activation/definition annotations, fields, locals, constructors, ordinary parameters, annotation elements, packages, type uses, and unsupported type forms.

## 3. Endpoint Represented-Target Attribution

- [x] 3.1 Attach exactly one represented method or record-component target to every direct Spring MVC and direct JAX-RS endpoint candidate, including separate-parser span equivalence and implicit accessor fan-out.
- [x] 3.2 Attach the exact contract or handler method target to Spring HTTP Interface, Feign, `MessageMapping`, and `SubscribeMapping` endpoint candidates.
- [x] 3.3 Attach only the concrete or effective implementation method target to Spring hierarchy and JAX hierarchy/subresource candidates, never an inherited annotation, contract, path, or route source.
- [x] 3.4 Attach the resolved handler target to Spring functional/programmatic recall candidates, using the publisher only when it is the represented fallback and never substituting an activation or route-contributor method.
- [x] 3.5 Attach the exact attributed publisher/configuration method target to Spring Gateway, resource-handler, raw WebSocket, and STOMP registration candidates.
- [x] 3.6 Attach the exact annotated class or record target to every JAX `ServerEndpoint` handshake candidate, without treating enclosing or member declarations as represented.
- [x] 3.7 Route collisions in the Spring recall, Gateway, resource-handler, client, WebSocket/message, and JAX recall local deduplicators through the shared private-evidence merge, and verify Spring configuration copying preserves retained target evidence while rejected endpoints cease to represent a target.
- [x] 3.8 Add an attribution-matrix test proving every built-in raw endpoint producer carries exactly one valid target and covering strict inheritance, publisher-versus-handler selection, implicit versus explicit record accessors, non-annotation routes, registration methods, and type-level WebSockets.

## 4. Final Endpoint Grouping and Global Membership

- [x] 4.1 Preserve validated represented-target evidence through `format_endpoint()` alongside existing private annotation evidence without changing any public formatted field.
- [x] 4.2 Introduce an internal endpoint finalizer that performs the existing normalization, original six-field grouping, sorting, and `method_annotation_line` selection while unioning represented targets within each surviving logical row.
- [x] 4.3 Keep `deduplicate_and_sort_rows()` as a compatibility wrapper returning only the unchanged ordered public row list, and expose richer finalized groups and their represented-target union only to the new CLI workflow.
- [x] 4.4 Implement global absence projection by filtering candidates whose exact target occurs in any finalized row, independently of candidate framework, annotation causality, fan-out, and selected public provenance.
- [x] 4.5 Add finalizer and membership tests for same-target competing annotations, sibling targets, fan-out, normalization-induced merging, two distinct targets collapsing into one row, cross-framework merging, empty or alternate annotation provenance, deterministic ordering, and unchanged public rows.

## 5. Deterministic Rendering and Atomic Publication

- [x] 5.1 Implement a pure absent-trigger renderer that emits every discovered file and enabled framework section, exact item field order and indentation, explicit `none` sections, and fixed file/framework/occurrence ordering with the specified blank-line rules.
- [x] 5.2 Reuse a shared bounded complete-annotation extraction core through compatibility-preserving point-row and byte-aligned physical-line adapters, and make the renderer return UTF-8 bytes without BOM or timestamps/diagnostics, with LF-only separators, exactly one terminal LF for non-empty output, and zero bytes when no Java files are discovered.
- [x] 5.3 Add a pure path helper that removes only the final output suffix when present and appends `-anno-without-endpoints.log`, covering simple, multi-suffix, and extensionless output names without changing `<output>.log` derivation.
- [x] 5.4 Add same-directory atomic byte publication using one unique temporary file, binary write, flush/sync/close, and `os.replace`, with best-effort cleanup and re-raising on every pre-publication or replace failure without opening the destination in place.
- [x] 5.5 Add pure renderer, path, and publisher tests for exact multiline extracts, blank-line handling, ten following non-empty lines, EOF and overlapping extracts, all `Applied to` forms, Unicode, byte layout, first creation, stale-content and zero-byte replacement, injected write/sync/close/replace failures, prior-content preservation, and temporary cleanup.

## 6. CLI Lifecycle and End-to-End Behavior

- [x] 6.1 Update `main()` to collect the candidate catalog, use the richer final endpoint result, render absence from the global represented-target union, write the existing CSV and companion log, and atomically publish the new report as the final fallible success step.
- [x] 6.2 Keep the derived report untouched at startup and in every existing error handler, propagate publication failure as run failure, and preserve the existing CSV rollback, argument-validation, diagnostic-buffer, and companion-log behavior.
- [x] 6.3 Add end-to-end fixtures for later-rejected direct and source-defined Spring/JAX triggers, missing activation, unresolved values, strict inherited-contract absence, record components and explicit accessors, failed and successful `ServerEndpoint` types, and non-annotation routes representing annotated methods.
- [x] 6.4 Add dual-framework and filtered-mode fixtures proving membership is global across enabled analyzers, disabled analyzers cannot establish membership, merged-row provenance does not narrow represented targets, and every file still receives only its enabled framework sections.
- [x] 6.5 Add CLI lifecycle tests for all derived filename forms, successful zero-Java-file output, deterministic repeated runs, replacement with only current content, failures during analysis/finalization/CSV/companion-log stages, and atomic-publication failure with and without a prior completed report.

## 7. Compatibility and Validation

- [x] 7.1 Extend regression assertions to prove candidate collection and target evidence do not change endpoint discovery, normalization, six-field identity, row count/order, CSV encoding/delimiter/columns/values, or `method_annotation_line` selection.
- [x] 7.2 Verify the existing broad annotation inventory and `Diagnostics:` companion-log bytes and framework filtering remain unchanged, while the new report contains neither timestamps nor diagnostics.
- [x] 7.3 Run `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_noir_sbt_absent_annotation_log.py'` and the complete `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests` suite, fixing regressions without broadening endpoint or annotation support.
- [x] 7.4 Run `openspec validate log-trigger-annotations-without-endpoints --strict`, `git diff --check`, and repeated end-to-end analyses, confirming byte-identical absent-trigger reports and unchanged existing outputs for default, Spring-only, and JAX-only modes.

## 8. Verification Remediation

- [x] 8.1 Refactor the legacy and absent-report extract adapters through one shared bounded row-extraction core without changing broad-inventory bytes, and add absent-renderer coverage for exactly 10 following non-empty lines, Unicode UTF-8 output without BOM, and physical-line terminators.
- [x] 8.2 Add direct regression assertions for same-target direct/source-defined ordering, dual-framework target equality, represented competing annotations, sibling isolation, fan-out membership, nested non-propagation, and repeated discovery deduplication.
- [x] 8.3 Add parameterized collision tests for all six analyzer-local deduplicators plus Spring configuration copy/rejection tests, proving multiple private annotation and represented-target records survive where appropriate while final CSV output retains one row and one selected `method_annotation_line`.
- [x] 8.4 Strengthen candidate and target-identity coverage for type-level `HttpExchange`/`MessageMapping` exclusions, identical-span target-kind separation, and canonical path aliases.
- [x] 8.5 Rerun focused and full regression suites, strict OpenSpec validation, whitespace checks, and a warning-focused verification pass.
