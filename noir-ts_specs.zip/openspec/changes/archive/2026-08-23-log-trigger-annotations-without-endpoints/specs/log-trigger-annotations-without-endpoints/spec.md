## Purpose

Produce a separate deterministic report of recognized final-trigger-capable
annotation occurrences whose directly annotated Java targets are represented
by no surviving endpoint CSV row, without changing existing scanner outputs.

## ADDED Requirements

### Requirement: Completed analysis writes a separate absent-trigger report
After normal analysis completes, the system SHALL write a separate report whose
path is derived from `--output` by removing its final filename extension, when
present, and appending `-anno-without-endpoints.log`. The system SHALL finalize
the report only after every discovered Java file, every enabled analyzer,
cross-file and hierarchy processing, endpoint normalization, and final endpoint
deduplication have completed. Report membership SHALL use the logical endpoint
rows that survive into the CSV.

#### Scenario: CSV output path derives the report path
- **WHEN** analysis completes with `--output /workspace/build/endpoints.csv`
- **THEN** the endpoint CSV is written to `/workspace/build/endpoints.csv`
- **AND** the absent-trigger report is written to `/workspace/build/endpoints-anno-without-endpoints.log`
- **AND** the existing companion inventory and diagnostic log remains `/workspace/build/endpoints.csv.log`

#### Scenario: Extensionless output path derives the report path
- **WHEN** analysis completes with `--output /workspace/build/endpoints`
- **THEN** the absent-trigger report is written to `/workspace/build/endpoints-anno-without-endpoints.log`

#### Scenario: Only the final extension is removed
- **WHEN** analysis completes with `--output /workspace/build/endpoints.audit.csv`
- **THEN** the absent-trigger report is written to `/workspace/build/endpoints.audit-anno-without-endpoints.log`

#### Scenario: Multi-phase results are evaluated only after completion
- **WHEN** endpoint evidence for a candidate target is discovered by a later file, hierarchy pass, or enabled analyzer
- **THEN** the system waits for all processing and final deduplication before deciding whether that target is absent

#### Scenario: Failed run does not publish partial absence results
- **GIVEN** a completed absent-trigger report already exists for an output path
- **WHEN** a later analysis using that output path terminates before normal completion
- **THEN** the previous completed report remains byte-identical
- **AND** no partial or temporary current-run report remains at the derived path

#### Scenario: First run fails before report publication
- **GIVEN** no absent-trigger report exists for an output path
- **WHEN** analysis using that output path terminates before normal completion
- **THEN** no absent-trigger report or temporary report exists at the derived path

#### Scenario: Report publication fails
- **WHEN** all analysis phases complete but the absent-trigger report cannot be published
- **THEN** the run does not complete successfully
- **AND** any previous completed report remains byte-identical
- **AND** the derived report path remains absent when no previous completed report existed

#### Scenario: Failed run does not add CSV rollback semantics
- **WHEN** a run fails before absent-trigger report publication after exercising existing CSV output behavior
- **THEN** CSV preservation, replacement, or failure behavior remains governed by the existing scanner contract
- **AND** report-to-CSV consistency is guaranteed only for runs that complete successfully

#### Scenario: Successful analysis discovers no Java files
- **WHEN** analysis completes successfully without discovering any Java files
- **THEN** the system creates an empty absent-trigger report

### Requirement: Candidate eligibility requires final-trigger semantics and placement
For each enabled framework, the system SHALL consider an annotation occurrence
a final-trigger candidate only when its genuine resolved identity belongs to an
already supported final endpoint-trigger family and its exact source placement
is one in which that family can serve as the final trigger. Candidate
eligibility SHALL NOT require the occurrence to emit an endpoint or its
use-site values to decode successfully. Candidate discovery SHALL preserve the
existing exact-identity, source-shadowing, ambiguity, and framework-selection
rules and SHALL NOT enable a new annotation, framework, or endpoint shape.

#### Scenario: Later endpoint rejection remains a candidate
- **WHEN** a genuine final-trigger mapping is directly applied to an endpoint-capable method position
- **AND** an abstract or unbound owner, unresolved value, missing activation context, or another later condition prevents a final row
- **THEN** the mapping occurrence remains a candidate

#### Scenario: Later-rejected candidate is rendered
- **WHEN** a genuine final-trigger mapping is directly applied to a method declaration with unresolved use-site values
- **AND** no final row represents that exact method
- **THEN** the occurrence is rendered in the enabled framework's absent-trigger section

#### Scenario: Trigger identity is used only as a type-level modifier
- **WHEN** Spring `RequestMapping`, `HttpExchange`, or `MessageMapping` is directly applied to a type where it can only supply a shared prefix or condition
- **THEN** that occurrence is not a final-trigger candidate

#### Scenario: Trigger identity is used in an unsupported source position
- **WHEN** a mapping or request-method designator is applied to a field, local variable, ordinary parameter, package, annotation element, or another position unsupported as a final trigger
- **THEN** that occurrence is not a final-trigger candidate

An ordinary parameter in this requirement means a method, constructor, or
spread parameter and does not include a record component that the supported
Java analysis models as a potential implicit accessor.

#### Scenario: Trigger-capable placement fails a later condition
- **WHEN** a final-trigger identity occurs in a method, record-component, class, or record placement supported for that identity's semantic family
- **AND** visibility, abstractness, activation, value resolution, or another later endpoint condition prevents a row
- **THEN** the occurrence remains a candidate rather than being treated as an unsupported placement

#### Scenario: Identity is unsupported or unresolved
- **WHEN** an annotation is unsupported, ambiguous, shadowed without supported source-defined semantics, or otherwise unresolved for the enabled framework
- **THEN** that occurrence is not a final-trigger candidate

#### Scenario: Framework selection limits candidate classifications
- **WHEN** analysis runs with `--framework spring` or `--framework jaxrx`
- **THEN** only candidate classifications belonging to that enabled framework are considered

### Requirement: Spring candidate families are explicit and closed
For `spring`, the system SHALL recognize as candidates only the following
currently supported final-trigger families in their trigger-capable
placements:

- method uses, including Feign contract methods, and supported potential
  implicit-accessor record-component uses of genuine Spring MVC
  `RequestMapping`, `GetMapping`, `PostMapping`, `PutMapping`,
  `DeleteMapping`, and `PatchMapping`;
- outer method or supported record-component uses of a source-defined composed
  Spring annotation whose definition resolves unambiguously through the
  supported MVC composition model;
- HTTP-interface method uses of genuine `HttpExchange`, `GetExchange`,
  `PostExchange`, `PutExchange`, `DeleteExchange`, and `PatchExchange`; and
- handler-method uses of genuine `MessageMapping` and `SubscribeMapping`.

Spring activation, configuration, registration, path-modifier, binding, and
programmatic-route annotations SHALL remain outside this candidate set.

#### Scenario: Spring MVC method mapping is a candidate
- **WHEN** a genuine Spring MVC mapping is directly applied to a method position supported as a final trigger
- **THEN** the occurrence is a `spring` candidate even if no endpoint is ultimately emitted

#### Scenario: Feign activation is missing
- **WHEN** a genuine Spring MVC mapping is applied to a Feign-capable contract method but no valid `FeignClient` context produces a row
- **THEN** the method mapping remains a candidate
- **AND** `FeignClient` is not itself a candidate

#### Scenario: HTTP-interface type mapping is only a modifier
- **WHEN** `HttpExchange` is applied to an HTTP-interface type and `GetExchange` is applied to one of its methods
- **THEN** only the method `GetExchange` occurrence is a candidate

#### Scenario: Message activation annotation is excluded
- **WHEN** `MessageMapping` is applied to a handler-capable method and `Controller` is applied to its owner
- **THEN** the method `MessageMapping` occurrence is a candidate
- **AND** `Controller` is not a candidate

#### Scenario: Spring non-annotation route source has no candidate
- **WHEN** an endpoint can be produced from functional routing, Gateway DSL, raw WebSocket registration, configuration resources, or programmatic registration
- **THEN** `Bean`, `Configuration`, `Autowired`, `Controller`, and other supporting occurrences do not become final-trigger candidates merely because they assist that endpoint source

### Requirement: JAX-mode candidate families are explicit and closed
For `jaxrx`, the system SHALL recognize as candidates genuine Jakarta and
Javax occurrences of the seven standard JAX-RS request-method designators
`GET`, `POST`, `PUT`, `DELETE`, `PATCH`, `HEAD`, and `OPTIONS` on supported
method or potential implicit-accessor record-component placements; supported
outer uses of source-defined custom request-method designators; and genuine
`jakarta.websocket.server.ServerEndpoint` or
`javax.websocket.server.ServerEndpoint` occurrences on class or record
declarations. Interface, enum, and annotation declarations SHALL NOT be
trigger-capable `ServerEndpoint` placements. Visibility, abstractness,
constructor availability, nested-static status, record component count, and
path decoding SHALL be later endpoint conditions rather than placement gates.
JAX-RS path, deployment, representation, binding, context, and definition
metadata SHALL remain outside the candidate set.

#### Scenario: Standard JAX-RS designator is a candidate
- **WHEN** one of the seven genuine standard request-method designators occurs on a supported method position
- **THEN** it is a `jaxrx` candidate even when path, visibility, deployment, or another later condition prevents endpoint emission

#### Scenario: JAX-RS Path is not a final trigger
- **WHEN** `Path` is applied to a type or method without a candidate request-method designator
- **THEN** `Path` is not a candidate and is not written to the absent-trigger report

#### Scenario: Nonstandard method uses a custom designator
- **WHEN** a supported source-defined request-method designator resolves to `TRACE` or another valid HTTP token
- **THEN** its outer use can be a candidate
- **AND** no built-in `TRACE` annotation identity is inferred

#### Scenario: WebSocket endpoint type is a candidate
- **WHEN** genuine `ServerEndpoint` is directly applied to a class or record declaration
- **THEN** the occurrence is a `jaxrx` candidate
- **AND** a surviving WebSocket handshake row attributed to that type represents its target

#### Scenario: WebSocket candidate fails a later condition
- **WHEN** genuine `ServerEndpoint` is directly applied to a class or record declaration
- **AND** path decoding, abstractness, nesting, constructor shape, record components, or another later endpoint condition prevents a handshake row
- **THEN** the type occurrence is rendered when no final row represents that exact type

#### Scenario: WebSocket annotation is on an unsupported type form
- **WHEN** genuine `ServerEndpoint` is directly applied to an interface, enum, or annotation declaration
- **THEN** the occurrence is not a final-trigger candidate

#### Scenario: JAX supporting metadata is excluded
- **WHEN** `ApplicationPath`, `Consumes`, `Produces`, a parameter-binding annotation, a context annotation, or `HttpMethod` definition metadata is recognized
- **THEN** that occurrence is not a final-trigger candidate

### Requirement: Source-defined candidates use the outer occurrence
A source-defined composed Spring mapping or custom JAX-RS request-method
annotation SHALL be a candidate only when its definition resolves
unambiguously through the existing bounded supported-definition semantics and
its outer occurrence is in a trigger-capable placement. The candidate's name,
resolved identity, target, line, and extract SHALL come from that outer
use-site occurrence. Meta-annotation and Java declaration-metadata occurrences
inside the annotation definition SHALL NOT be candidates. Once definition
semantics and placement qualify, invalid or unresolved values at the outer use
site SHALL NOT remove candidate eligibility.

#### Scenario: Valid source-defined use has no endpoint row
- **WHEN** a supported composed Spring mapping or custom JAX-RS designator is used on a trigger-capable method
- **AND** that exact method is represented by no final endpoint row
- **THEN** the report item identifies the outer source-defined occurrence and its source-defined fully qualified identity

#### Scenario: Definition metadata is not a use-site candidate
- **WHEN** `RequestMapping`, `HttpMethod`, `Target`, `Retention`, or `AliasFor` occurs inside a supported source-defined annotation declaration
- **THEN** the definition occurrence is not a candidate merely because an outer use can trigger endpoints

#### Scenario: Invalid source-defined definition is excluded
- **WHEN** a source-defined annotation definition is cyclic, ambiguous, inaccessible, lacks required supported semantics, or otherwise fails supported definition resolution
- **THEN** its outer occurrences are not classified as final-trigger candidates

#### Scenario: Outer values fail after definition resolution
- **WHEN** a source-defined definition resolves to a supported final-trigger family and its outer occurrence has invalid or unresolved use-site values
- **THEN** the outer occurrence remains a candidate

#### Scenario: One outer occurrence qualifies for both frameworks
- **WHEN** one source-defined outer occurrence independently resolves to supported Spring and JAX final-trigger semantics
- **AND** both frameworks are enabled
- **THEN** the occurrence receives one candidate classification in each framework section
- **AND** both classifications use the same exact applied target for global membership

#### Scenario: Direct and source-defined candidates share an absent target
- **WHEN** a direct trigger and a supported source-defined outer trigger occur on the same method
- **AND** no final row represents that exact method
- **THEN** both occurrences are rendered in exact source order in each applicable framework section

### Requirement: Absence uses exact applied-target membership rather than causality
The system SHALL associate every candidate with the exact Java source element
directly annotated by the occurrence and SHALL report the candidate only when
no surviving final endpoint row represents that target. Every candidate on the
same exact target SHALL receive the same membership result, regardless of
which annotation caused, contributed to, was ignored for, or was selected as
public provenance for an endpoint row. A single surviving row SHALL establish
membership regardless of path or method fan-out.

#### Scenario: Competing mappings share an endpoint-bearing method
- **WHEN** `GetMapping` and `PostMapping` are both applied to one method
- **AND** a final endpoint row represents that method using only `GetMapping`
- **THEN** neither candidate is reported

#### Scenario: Candidate target has no endpoint
- **WHEN** a genuine candidate mapping is applied to an abstract method and no final endpoint row represents that exact method
- **THEN** the candidate is reported

#### Scenario: Sibling endpoint does not establish membership
- **WHEN** one method has a surviving endpoint row and a different method in the same type has a candidate annotation but no row
- **THEN** the candidate on the different method is reported

#### Scenario: Fan-out does not change membership
- **WHEN** one annotated method produces multiple final path or HTTP-method rows
- **THEN** every candidate directly applied to that method is omitted after the first surviving row establishes target membership

#### Scenario: Public annotation provenance is not membership
- **WHEN** a candidate shares a represented method with a row whose `method_annotation_line` is empty or points to another annotation
- **THEN** membership is determined from the represented target rather than by comparing annotation line values

### Requirement: Target representation is exact and survives deduplication
A method candidate SHALL match only a row representing that exact source method
declaration. A supported record-component candidate SHALL be represented by a
final row for the implicit accessor attributed to that exact component. A
`ServerEndpoint` type candidate SHALL be represented only by a final handshake
row attributed to that exact type. Each endpoint candidate SHALL have exactly
one represented source target attributed to it. Annotation sources, inherited
contracts, route publishers, configuration elements, path contributors, and
other supporting evidence SHALL NOT become represented targets unless an
endpoint candidate is itself attributed to that source element. A row
attributed to a different declaration SHALL NOT establish membership through
matching owner, name, signature, inheritance, route contribution, or lexical
containment alone.

When endpoint candidates attributed to different represented targets merge
under the existing logical endpoint identity, the surviving row SHALL
represent the union of those endpoint candidates' represented-target
identities for absent-trigger membership, without changing the public CSV row
or its selected provenance.

#### Scenario: Inherited contract annotation belongs to another declaration
- **WHEN** an annotation occurs on an interface or superclass method but the surviving endpoint row is attributed to a distinct concrete implementation method
- **THEN** the row does not represent the annotated contract declaration
- **AND** the contract occurrence is reported when no other row represents that exact declaration

#### Scenario: Record component produces an implicit accessor endpoint
- **WHEN** a supported candidate occurs on a record component and a final row is attributed to the implicit accessor synthesized from that exact component
- **THEN** the component candidate is omitted even though public `method_annotation_line` is empty

#### Scenario: Record component has no implicit accessor endpoint
- **WHEN** a supported candidate occurs on a record component and no final row is attributed to the implicit accessor synthesized from that component
- **THEN** the component candidate is reported

#### Scenario: Explicit accessor does not automatically represent a component
- **WHEN** an explicit accessor prevents endpoint synthesis from an annotated record component
- **AND** a final row represents only that distinct explicit method declaration
- **THEN** the method row does not by itself represent the component target
- **AND** the component candidate is reported when no other final row represents that exact component

#### Scenario: Nested target membership does not propagate outward
- **WHEN** a final endpoint row represents a member of a nested type
- **THEN** that row does not represent the nested type's lexical outer type or an unrelated sibling target

#### Scenario: Deduplicated row preserves all attributed represented targets
- **WHEN** endpoint candidates attributed to two exact represented source targets normalize to the same final logical endpoint row
- **THEN** that row establishes membership for both represented targets
- **AND** the endpoint remains one public CSV row

#### Scenario: Inherited route evidence is not a represented target
- **WHEN** an endpoint candidate attributed to a concrete method uses annotation or path evidence from a contract declaration
- **THEN** final deduplication retains the concrete method as the represented target
- **AND** it does not promote the supporting contract declaration into the represented-target union

### Requirement: Membership is global across enabled analyzers
The system SHALL test target membership against final rows produced by every
framework analyzer enabled for the run, while presenting each candidate only
under its own enabled framework classification. Framework filtering SHALL
naturally restrict both the candidate classifications and endpoint rows
available to membership evaluation.

#### Scenario: Another enabled framework represents the target
- **WHEN** a Spring candidate's exact target is represented only by a final JAX row while both analyzers are enabled
- **THEN** the Spring section omits that candidate even when no JAX candidate occurrence is attached to the target

#### Scenario: Non-annotation route represents the target
- **WHEN** a final row from a functional or programmatic route is attributed to the exact method carrying a candidate annotation
- **THEN** the candidate is omitted even though no annotation caused that final row

#### Scenario: Framework filter removes the only representing row
- **WHEN** a candidate for the selected framework has no selected-framework row but would share a target with a row from a disabled analyzer
- **THEN** the disabled analyzer's row does not establish membership for that run

#### Scenario: Deduplication provenance priority does not narrow membership
- **WHEN** Spring and JAX endpoint candidates merge and public provenance selects only one annotation
- **THEN** every represented target attributed to a merged endpoint candidate remains represented for membership

### Requirement: Every discovered file and enabled framework has a section
The report SHALL contain exactly one `File: <path>` block for every Java file
discovered under `--path`. The path SHALL be relative to `--path` and use POSIX
separators. Each file block SHALL contain exactly one `Framework: spring`
section when Spring is enabled and exactly one `Framework: jaxrx` section when
JAX mode is enabled. When both are enabled, the Spring section SHALL precede
the JAX section. A section with no reportable candidate SHALL render
`Annotations without endpoints: none` whether it had no candidates or every
candidate target was represented. Exactly one blank line SHALL separate
adjacent framework sections, file blocks, and annotation items; no blank line
SHALL occur between `Annotations without endpoints:` and its first item.

#### Scenario: Default analysis renders both framework sections
- **WHEN** `--framework` is omitted and both analyzers are enabled
- **THEN** every file block contains `Framework: spring` followed by `Framework: jaxrx`

#### Scenario: Filtered analysis renders only the selected framework
- **WHEN** analysis runs with `--framework spring`
- **THEN** every file block contains one Spring section and no JAX section

#### Scenario: JAX-filtered analysis renders only JAX mode
- **WHEN** analysis runs with `--framework jaxrx`
- **THEN** every file block contains one JAX section and no Spring section

#### Scenario: Framework section has no absent candidates
- **WHEN** a file has no candidates for an enabled framework or every candidate target has a final row
- **THEN** that framework section contains `Annotations without endpoints: none`

#### Scenario: File and section spacing is stable
- **WHEN** the report contains multiple framework sections or file blocks
- **THEN** one blank line separates adjacent framework sections and one blank line separates adjacent file blocks
- **AND** the report has no leading blank line

#### Scenario: File blocks use lexical path order
- **WHEN** discovered relative paths are `z/Api.java`, `a/Z.java`, and `a/A.java`
- **THEN** their file blocks appear as `a/A.java`, `a/Z.java`, and `z/Api.java`

### Requirement: Report items expose resolved annotation and target evidence
Each reported candidate SHALL use the following fields in order:
`Annotation`, `Resolved`, `Applied to`, `Line`, and `Extract`. `Annotation`
SHALL contain the terminal source annotation name, `Resolved` SHALL contain its
resolved fully qualified identity, and `Line` SHALL contain the one-based
physical line on which the annotation begins.

`Applied to` SHALL contain a stable target kind and lexically qualified source
label using these forms:

- `method <declaring-type>.<method-name>(<parameters>)` for a method;
- `record component <declaring-record>.<component-name>` for a record
  component; and
- `type <type-name>` for a type.

Lexically qualified type names SHALL include enclosing types, separated by
`.`. Together with the file block and annotation line, the rendered target
evidence SHALL distinguish overloaded and nested declarations. For a method,
`<parameters>` SHALL be derived from the complete source text between its
parameter-list parentheses: remove the parentheses, replace every maximal run
of spaces, tabs, form feeds, carriage returns, or line feeds with one ASCII
space, trim leading and trailing spaces, and preserve all remaining source
text—including annotations, comments, receiver syntax, varargs, names,
generic-type punctuation, and comma punctuation—unchanged. A zero-parameter
method SHALL render empty parentheses.

Each item SHALL start with two spaces, a hyphen, and `Annotation:`. Its other
field labels SHALL start with four spaces. Every extract source line SHALL
start with six spaces followed by `<one-based-line>: ` and the original source
text. The following example fixes the field order and indentation:

```text
  - Annotation: GetMapping
    Resolved: org.springframework.web.bind.annotation.GetMapping
    Applied to: method DraftController.draft()
    Line: 34
    Extract:
      34:     @GetMapping("/draft")
      35:     public abstract String draft();
```

#### Scenario: Direct annotation item uses the required field order
- **WHEN** a direct `GetMapping` on `DraftController.draft()` beginning on line 34 is reported
- **THEN** its item contains `Annotation: GetMapping`, `Resolved: org.springframework.web.bind.annotation.GetMapping`, `Applied to: method DraftController.draft()`, and `Line: 34` in that order before `Extract:`

#### Scenario: Source-defined annotation reports its outer identity
- **WHEN** an outer source-defined annotation occurrence is reported
- **THEN** `Annotation` contains its outer use-site name
- **AND** `Resolved` contains its source-defined fully qualified identity rather than an underlying meta-annotation identity

#### Scenario: Overloaded method target is distinguishable
- **WHEN** candidates on two overloaded methods are reported
- **THEN** each `Applied to` value includes that method's normalized source parameter declarations

#### Scenario: Multiline annotated parameters are normalized
- **WHEN** a reported candidate targets `read(@Valid` on one physical line followed by `String id, int... counts)` on later lines
- **THEN** `Applied to` renders `method <declaring-type>.read(@Valid String id, int... counts)`

#### Scenario: Type-level WebSocket target uses the type form
- **WHEN** a `ServerEndpoint` type candidate is reported
- **THEN** `Applied to` uses the `type <type-name>` form

### Requirement: Extract includes the complete annotation and ten following non-empty lines
For every reported item, `Extract` SHALL contain every physical source line
occupied by the complete annotation followed by exactly the next 10 non-empty
physical source lines, or every remaining non-empty line when fewer than 10
remain before end-of-file. Extracted lines SHALL retain their one-based source
line numbers, source order, original text, and indentation. Blank lines after
the annotation SHALL not be emitted and SHALL not consume the 10-line limit.

#### Scenario: Multiline annotation has a full extract
- **WHEN** a reported annotation occupies multiple physical lines
- **THEN** every annotation line is emitted
- **AND** the 10-line context count begins after its final physical line

#### Scenario: Blank context lines do not consume the limit
- **WHEN** blank or whitespace-only lines occur among the physical lines following an annotation
- **THEN** those lines are omitted without consuming the 10 following non-empty lines
- **AND** retained line numbers show the resulting source gaps

#### Scenario: Blank physical line is inside the annotation span
- **WHEN** a blank or whitespace-only physical line lies inside a multiline annotation's parsed span
- **THEN** that line is emitted as part of the complete annotation
- **AND** the report still emits up to 10 following non-empty context lines after the annotation ends

#### Scenario: Annotation is near end-of-file
- **WHEN** fewer than 10 non-empty lines remain after a complete reported annotation
- **THEN** every remaining non-empty line is emitted without padding or duplication

#### Scenario: Two extracts overlap
- **WHEN** two reported candidates occur fewer than 10 non-empty lines apart
- **THEN** each candidate receives an independent complete extract
- **AND** shared source lines can appear in both extracts

### Requirement: Report rendering is deterministic
The system SHALL sort file blocks by relative POSIX path, framework sections
in `spring` then `jaxrx` order when both are enabled, and items by exact source
position. Repeated discovery of the same framework classification at the same
annotation span SHALL produce one item, while distinct source occurrences
SHALL remain distinct. Structured report lines SHALL have no timestamp prefix
and the report SHALL contain no `Diagnostics:` section. The report SHALL use
UTF-8 without a byte-order mark and LF line endings. Every non-empty report
SHALL end in exactly one LF; the successful zero-Java-file report SHALL contain
zero bytes.

#### Scenario: Candidates begin on the same line
- **WHEN** multiple reportable candidates begin on one physical line
- **THEN** they are ordered by their exact source column or byte position

#### Scenario: One occurrence is discovered by multiple passes
- **WHEN** the same source occurrence and framework classification is discovered by multiple analysis passes
- **THEN** that framework section contains one item for the occurrence

#### Scenario: Multiple items use stable spacing
- **WHEN** one framework section contains two or more reportable occurrences
- **THEN** exactly one blank line separates adjacent annotation items

#### Scenario: Repeated identical analysis
- **WHEN** the same source tree and arguments are analyzed successfully twice
- **THEN** the two absent-trigger reports are byte-identical

#### Scenario: Successful rerun replaces prior content
- **GIVEN** the report contains a previous completed run
- **WHEN** another analysis completes successfully using the same output path
- **THEN** the report contains only the newly completed run's deterministic content

### Requirement: Existing scanner behavior remains compatible
Candidate collection, target membership, and report rendering SHALL NOT add,
remove, select, or distinguish endpoint rows; change endpoint normalization,
six-field identity, deduplication, ordering, CSV encoding, delimiter, columns,
values, or `method_annotation_line`; change CLI argument validation or
framework selection; or change the existing `<output>.log` annotation
inventory and `Diagnostics:` behavior. An absent-trigger candidate SHALL NOT
by itself authorize endpoint emission.

#### Scenario: New report does not alter endpoint CSV
- **WHEN** an occurrence is added to or removed from the absent-trigger report
- **THEN** endpoint rows and every CSV field remain governed by the existing endpoint capabilities

#### Scenario: Broad annotation inventory remains broader
- **WHEN** a recognized supporting annotation is excluded from the final-trigger candidate set
- **THEN** its existing `<output>.log` inventory behavior remains unchanged

#### Scenario: Diagnostics remain in the existing companion log
- **WHEN** analysis records skipped, ambiguous, unresolved, or other diagnostic evidence
- **THEN** that evidence remains governed by the existing companion log
- **AND** it is not copied into the absent-trigger report as a diagnostic section

#### Scenario: Candidate does not create an endpoint
- **WHEN** a valid candidate target has no final endpoint row
- **THEN** writing the candidate to the report does not create an endpoint row
