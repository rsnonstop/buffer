## Why

The existing annotation inventory shows what noir-sbt recognizes, but it does
not isolate potential final endpoint triggers whose annotated source targets
produce no endpoint row. Reviewers need a focused report of these gaps without
manually correlating the broad inventory with the final endpoint CSV.

## What Changes

- Add a separate, deterministic output-derived
  `...-anno-without-endpoints.log` report after complete analysis.
- Consider only recognized annotation occurrences that can be final endpoint
  triggers for an enabled framework in their applied source position; exclude
  supporting annotations such as JAX-RS `@Path`.
- Determine absence from the exact Java element to which the candidate
  annotation is applied: report the occurrence only when that target is
  represented by no surviving final endpoint CSV row.
- Render every discovered Java file with a section for each enabled framework,
  including an explicit `Annotations without endpoints: none` result where
  applicable.
- For each reported occurrence, include its annotation name, resolved identity,
  applied-to target, one-based starting line, complete annotation source, and
  the next 10 non-empty source lines or the available remainder at EOF.
- Preserve deterministic path, framework, and source ordering while leaving
  the existing endpoint CSV, annotation inventory, diagnostics, and
  `method_annotation_line` behavior unchanged.

## Capabilities

### New Capabilities

- `log-trigger-annotations-without-endpoints`: Produce a separate per-file and
  per-enabled-framework report of recognized final-trigger-capable annotation
  occurrences whose exact annotated source targets are represented by no
  surviving final endpoint CSV row.

### Modified Capabilities

- None.

## Impact

- Adds one observable report file to successful analyses without changing CLI
  arguments or existing output schemas.
- Affects annotation/target evidence retained across enabled analyzers, final
  endpoint correlation, report rendering, and focused regression coverage.
- Reuses the established resolved-identity and bounded source-extract behavior
  without broadening supported annotations, frameworks, or endpoint shapes.
- Requires compatibility tests proving endpoint identification, CSV
  normalization/deduplication, the existing annotation inventory, and
  diagnostics remain unchanged.

## Initial Intent (As-Is)

````text
# TO-BE:
Extend script-logging to a separate log file "...-anno-without-endpoints.log":
After analyzys of a source file is fully finished (or after all analyzis of all files is finished, if multi-file/multi-phase analyzys is used):
Log pathname to the file (similar to what is currently implemented in "existent log-file")
After the path to file is logged:
- for each "script enabled framework": log framework identity. Then:
  - Log: info about all this framework's annotatoins in the source file, that are "not in any Endpoint".
    Clarification: "Annotation is not in any Endpoint" means: a method or "something", this annotation is applied to, - is not in any API Endpoint (and as consequense - no such endpoints are resulted CSV).
    Clarification: we consider and log only "potentially endpoint triggering annotaions", that can be "potential final endpoint trigger" for a framework. Example: for jax-rs: we consider annotations like GET/POST/PUT/DELETE/OPTIONS/PATCH/HEAD, but not "@Path".
    - Log annotation and it's "starting line" in the file with "number of the line".
    - After each framewok'a annotation - include next 10 non-empty lines of the source code of the file.



## Examples of log:
```
File: src/main/java/example/AnnotationAuditController.java
Framework: spring
Annotations without endpoints:
  - Annotation: GetMapping
    Resolved: org.springframework.web.bind.annotation.GetMapping
    Applied to: method DraftController.draft()
    Line: 34
    Extract:
      34:     @GetMapping(
      35:         path = "/draft"
      36:     )
      37:     public abstract String draft();
      38: }
  ...
```

```
File: src/main/java/example/HybridController.java
Framework: spring
Annotations without endpoints: none

Framework: jaxrx
Annotations without endpoints: none
``


````
