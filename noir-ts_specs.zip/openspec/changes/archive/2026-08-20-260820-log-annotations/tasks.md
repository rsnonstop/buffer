## 1. Annotation Discovery and Recognition

- [x] 1.1 Add one context-independent Tree-sitter query for `annotation` and `marker_annotation` usages, retain occurrence records per workspace file without changing `declared_annotation_names()`, and verify focused tests capture declaration, method, parameter, type-use, record, package, nested, and meta-annotation positions while excluding comment/string lookalikes and using `QueryCursor.matches()`.
- [x] 1.2 Add the bounded Spring/JAX-RS recognition registry and endpoint-neutral classifier using existing provenance rules, and verify a coverage-matrix test exercises every registered annotation role plus exact imports, wildcard imports, fully qualified spellings, local/same-package shadows, ambiguity, unsupported annotations, and `--framework spring|jaxrx` filtering.
- [x] 1.3 Reuse the existing source-definition graphs for recognized Spring composed mappings and JAX-RS custom request-method annotations, merge repeated discovery by file/byte span, and verify focused tests retain genuine source-defined occurrences once while omitting invalid, cyclic, ambiguous, or unsupported definitions.
- [x] 1.4 Reject direct framework classification when the analyzed workspace declares the resolved supported FQN, preserve independent Spring/JAX-RS source-defined recognition, and verify imported and fully qualified Spring/JAX-RS shadows are omitted while valid same-FQN composed/custom definitions remain eligible.

## 2. Source Evidence and Log Rendering

- [x] 2.1 Implement physical-line extraction for the complete annotation plus exactly 10 following non-empty lines, and verify focused tests cover multiline annotations, skipped blank lines with real line-number gaps, original indentation, annotations sharing a line, overlapping extracts, and fewer-than-10-line EOF truncation.
- [x] 2.2 Implement deterministic per-file inventory rendering with relative `File:` paths, source-ordered annotation items, supported `Framework:`/`Resolved:` entries, and `Annotations: none`, and verify the rendered structure matches the example in the spec for multiple annotations while listing every discovered Java file exactly once.
- [x] 2.3 Route existing `write_log()` events through a resettable per-run diagnostic buffer and render one distinct `Diagnostics:` section after the timestamp-free inventory, and verify focused tests preserve diagnostic order/timestamps, prevent diagnostics from becoming annotation items, and retain controlled-error diagnostics.
- [x] 2.4 Integrate inventory collection and final log rendering into normal module analysis without feeding annotation records into endpoint emission or CSV formatting, and verify CLI-level tests for default, Spring-only, and JAX-RS-only modes produce the expected log while preserving identical endpoint rows and the existing six-column UTF-8-BOM semicolon CSV contract.

## 3. Validation and Workspace Reconciliation

- [x] 3.1 Add `tests/test_noir_sbt_annotation_log.py` with the focused behavioral and layout cases from the capability spec, and verify `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_noir_sbt_annotation_log.py'` passes.
- [x] 3.2 Run the complete solution regression suite with `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests`, fix any logging-state leakage or endpoint/CSV regression, and record a passing command result.
- [x] 3.3 Reconcile the applicable `is/` implementation, QA-implementation, findings, and current-state notes required by `ig/AGENTS.md` with the delivered behavior, and verify they agree with this OpenSpec change, preserve `openspec-goal.md`, leave `in/` and archived/`zzpin` content untouched, and document the focused and full-regression results.
