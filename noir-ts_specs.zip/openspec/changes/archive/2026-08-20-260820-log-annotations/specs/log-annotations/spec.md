## Purpose

Log only annotations that noir-sbt recognizes as supported by its Spring or JAX-RS analysis, together with resolved framework identity and nearby source evidence.

## ADDED Requirements

### Requirement: Every discovered Java file has one inventory block
The system SHALL write exactly one annotation-inventory block to `<output>.log` for every Java file discovered under `--path`. Each block SHALL start with one `File: <path>` line whose path is relative to `--path`, followed by annotation information for that file.

#### Scenario: Files with and without recognized annotations
- **WHEN** an analysis discovers one Java file containing recognized annotations and another Java file containing none
- **THEN** the log contains exactly one `File:` block for each file
- **AND** the file without recognized annotations contains `Annotations: none`

#### Scenario: Framework filtering leaves a file without matches
- **WHEN** a Java file contains only JAX-RS-recognized and unsupported annotations and the analysis runs with `--framework spring`
- **THEN** that file still appears once and contains `Annotations: none`

### Requirement: Inventory includes only recognized annotations
The system SHALL inventory an annotation occurrence only when noir-sbt resolves it as supported by a selected Spring or JAX-RS analyzer. Annotations belonging to other or unsupported frameworks, annotations unrelated to supported analysis, unresolved identities, and familiar-name shadows without valid provenance SHALL be omitted. Recognition SHALL NOT require the occurrence to produce an endpoint, and inventory inclusion SHALL NOT authorize or imply support for a new endpoint shape.

#### Scenario: Supported annotation does not emit an endpoint
- **WHEN** noir-sbt resolves a supported annotation but the enclosing source construct fails another endpoint-emission condition
- **THEN** the annotation occurrence is included in the inventory
- **AND** no endpoint is added solely because the annotation was logged

#### Scenario: Unsupported or unrelated annotation
- **WHEN** a source annotation belongs to another framework, is application-defined without supported semantics, or is unrelated to noir-sbt's supported analysis
- **THEN** the annotation occurrence is omitted from the inventory

#### Scenario: Familiar name without valid provenance
- **WHEN** a source annotation shares a familiar Spring or JAX-RS simple name without valid supported-framework provenance
- **THEN** the annotation occurrence is omitted from the inventory

#### Scenario: Framework selection
- **WHEN** `--framework spring` or `--framework jaxrx` is supplied
- **THEN** only annotations recognized for that selected framework are inventoried

#### Scenario: Both supported frameworks are selected by default
- **WHEN** `--framework` is omitted
- **THEN** annotations recognized for either Spring or JAX-RS are inventoried

#### Scenario: Source-defined supported annotation
- **WHEN** a source-defined annotation is recognized through supported Spring composition or JAX-RS request-method semantics
- **THEN** its source occurrence is eligible for the same inventory as a directly declared framework annotation

### Requirement: Workspace source declarations shadow direct framework identity
When the analyzed workspace declares any source type at an otherwise supported framework FQN, the system SHALL treat that declaration as owning the identity and SHALL NOT recognize occurrences directly from that FQN or its import, regardless of imported or fully qualified spelling. Such an occurrence SHALL remain eligible only when its source declaration independently satisfies supported Spring composition or JAX-RS request-method semantics.

The following non-normative example illustrates a shadow annotation. The analyzed source tree declares its own `GetMapping` at the exact FQN normally associated with Spring:

```java
// src/main/java/org/springframework/web/bind/annotation/GetMapping.java
package org.springframework.web.bind.annotation;

public @interface GetMapping {}
```

Application source then refers to that workspace-owned declaration using both an import and a fully qualified spelling:

```java
// src/main/java/example/UserController.java
package example;

import org.springframework.web.bind.annotation.GetMapping;

class UserController {
    @GetMapping
    void importedShadow() {}

    @org.springframework.web.bind.annotation.GetMapping
    void fullyQualifiedShadow() {}
}
```

Because the workspace declaration has no supported Spring composition, neither occurrence is recognized directly as Spring. If the two files contain no other recognized annotations, their inventory blocks are:

```text
File: src/main/java/example/UserController.java
Annotations: none

File: src/main/java/org/springframework/web/bind/annotation/GetMapping.java
Annotations: none
```

#### Scenario: Workspace declaration shadows an exact supported framework FQN
- **WHEN** the analyzed workspace declares a source type at an otherwise supported Spring or JAX-RS framework FQN
- **AND** an occurrence refers to that identity through an import or fully qualified spelling
- **AND** the source declaration does not satisfy supported source-defined semantics
- **THEN** the occurrence is omitted from the inventory

#### Scenario: Exact-FQN source declaration has supported semantics
- **WHEN** the analyzed workspace declares an annotation at an otherwise supported framework FQN
- **AND** that declaration independently satisfies supported Spring composition or JAX-RS request-method semantics
- **THEN** its occurrence remains eligible through source-defined recognition
- **AND** its framework entry reports the supported framework and that exact FQN

### Requirement: Each recognized annotation occurrence has framework-resolved evidence
For each inventoried occurrence, the system SHALL write an `Annotation:` item containing its annotation name, a one-based `Line:` value for its starting source line, a `Frameworks:` list, and an `Extract:` block. Every framework entry SHALL contain a supported `Framework: spring` or `Framework: jaxrx` label and the annotation's fully resolved identity in `Resolved:`.

The following non-normative example illustrates the required nesting and field names. Its `Extract:` sections are abbreviated for readability; actual extracts SHALL follow the 10-non-empty-line requirement below.

```text
File: src/main/java/example/UserController.java
Annotations:
  - Annotation: GetMapping
    Line: 14
    Frameworks:
      - Framework: spring
        Resolved: org.springframework.web.bind.annotation.GetMapping
    Extract:
      14: @GetMapping("/users/{id}")
      15: public User find(
      16:     @PathVariable String id
      17: ) {
      18:     return service.find(id);
      19: }

  - Annotation: Read
    Line: 46
    Frameworks:
      - Framework: spring
        Resolved: annotations.Read
    Extract:
      46: @Read("/orders")
      47: public Order readOrder(String id) {
      48:     return service.read(id);
      49: }
```

#### Scenario: Direct Spring mapping annotation
- **WHEN** a genuine `GetMapping` occurrence starts on source line 14
- **THEN** its item reports `Annotation: GetMapping` and `Line: 14`
- **AND** its framework entry reports `Framework: spring` and `Resolved: org.springframework.web.bind.annotation.GetMapping`

#### Scenario: One occurrence is found by multiple analysis passes
- **WHEN** the same source occurrence is encountered more than once or is relevant to more than one supported framework classification
- **THEN** the log contains one annotation item for that source occurrence
- **AND** its distinct framework resolutions are merged under `Frameworks:`

#### Scenario: Repeated annotation name at different locations
- **WHEN** the same recognized annotation name occurs at two different source positions
- **THEN** each source occurrence has its own annotation item

### Requirement: Extract contains the complete annotation and ten following non-empty lines
The `Extract:` block SHALL include every physical source line occupied by the complete annotation, followed by exactly 10 non-empty physical source lines after the annotation, or all remaining non-empty lines when fewer than 10 exist before end-of-file. Extracted lines SHALL retain their one-based source line numbers, source order, and original indentation; blank lines after the annotation SHALL neither be emitted nor count toward the limit.

#### Scenario: Blank lines occur after an annotation
- **WHEN** blank lines are interspersed among more than 10 non-empty lines following a recognized annotation
- **THEN** the extract contains the complete annotation and the first 10 following non-empty lines
- **AND** displayed source line numbers may skip the omitted blank lines

#### Scenario: Multiline annotation
- **WHEN** a recognized annotation occupies multiple physical source lines
- **THEN** every line occupied by the annotation is present in the extract
- **AND** the 10-line context count begins after the annotation's final physical line

#### Scenario: Annotation near end-of-file
- **WHEN** fewer than 10 non-empty lines remain after the complete annotation
- **THEN** the extract contains every remaining non-empty line without padding or failure

### Requirement: Inventory ordering and rendering are deterministic
The system SHALL order file blocks by relative source path and annotation items within each file by source position. The structured inventory lines SHALL not receive per-line event timestamp prefixes.

#### Scenario: Repeated identical analysis
- **WHEN** the same source tree and arguments are analyzed twice
- **THEN** the annotation inventory has identical file ordering, annotation ordering, field structure, and extract contents in both logs

### Requirement: Existing scanner outputs remain compatible
The annotation inventory SHALL NOT change endpoint identification, CLI argument behavior, or the six-column endpoint CSV. Existing analysis diagnostics SHALL remain available in a section distinct from the per-file annotation inventory.

#### Scenario: Annotation logging is enabled by normal analysis
- **WHEN** noir-sbt analyzes a source tree and writes the structured annotation inventory
- **THEN** it still creates the endpoint CSV using the existing encoding, delimiter, columns, normalization, deduplication, and ordering rules
- **AND** endpoint rows are unaffected by whether a recognized annotation ultimately appears in the inventory

#### Scenario: Analysis produces diagnostics
- **WHEN** the analyzer records skipped, ambiguous, or unresolved source evidence
- **THEN** those diagnostics remain in the companion log without being rendered as annotation items
