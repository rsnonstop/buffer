## Context

See [proposal.md](proposal.md) for motivation and [specs/log-annotations/spec.md](specs/log-annotations/spec.md) for observable behavior.

The host already discovers and reads every Java file deterministically, parses those sources into a shared Tree-sitter workspace, and resolves supported Spring and JAX-RS annotation identities with import, source-shadow, and composition checks. Its current annotation queries are owner-specific, while `declared_annotation_names()` indexes Java `@interface` declarations rather than annotation usages. Logging is currently event-oriented: `write_log()` immediately appends a timestamped line, and endpoint analyzers and recall modules call it directly.

The implementation must remain procedural, use Tree-sitter queries with `QueryCursor.matches()`, preserve current provenance rules, and leave CLI and endpoint CSV behavior unchanged.

## Goals / Non-Goals

**Goals:**

- Collect syntactic Java annotation candidates once regardless of declaration context, then retain only occurrences recognized by the selected supported analyzer(s).
- Reuse current source/provenance knowledge to classify genuine noir-sbt-supported Spring/JAX-RS annotations without familiar-name false positives.
- Produce the stable per-file layout and bounded source extracts defined by the spec while retaining existing diagnostics separately.
- Keep endpoint analyzers isolated from inventory collection so logging cannot create or suppress endpoint rows.

**Non-Goals:**

- Log or determine the actual external framework, library, or fully qualified identity of an unsupported annotation.
- Treat every annotation from a Spring or JAX-RS package as supported; support means that noir-sbt currently consumes that annotation as potential attack-surface evidence or source-definition control metadata. Neutral Java annotations that a graph merely ignores, such as `java.lang.Override`, are not framework semantics and are excluded.
- Add endpoint support for annotations that are merely inventoried.
- Perform classpath or bytecode resolution, infer runtime registration, change ignored-directory discovery, or change CLI/CSV contracts.
- Repurpose `declared_annotation_names()`; its declaration-shadowing role remains unchanged.

## Decisions

### 1. Add one context-independent Tree-sitter annotation query

Add a shared query that matches both Java `annotation` and `marker_annotation` nodes anywhere in a compilation unit and captures the full node plus its name node. Compile it with the existing Java query runtime and execute it through `QueryCursor.matches()` for every workspace unit.

Normalize matches into small procedural records keyed by file and the annotation node's byte span. This captures declaration, method, parameter, type-use, record-component, package, and meta-annotation occurrences without enumerating every possible owner. Comments and string literals cannot match because they are not annotation syntax.

This is preferred over extending every owner-specific query because the latter would be incomplete and would rediscover the same occurrence through several analyzers. Regex scanning is rejected because it would regress the project's Tree-sitter and syntax-accuracy constraints.

### 2. Recognize supported candidates in a separate, endpoint-neutral pass

After the shared workspace and its source annotation indexes are built, classify collected candidates for the framework mode selected by the CLI. The recognizer will use a bounded registry of annotation identities and roles already consumed by the supported Spring and JAX-RS analyzers, together with the existing provenance helpers.

The registry maps supported annotation semantics to the log labels `spring` and `jaxrx`. Recognition reflects analyzer support rather than merely the annotation's declaring package; a Spring/JAX-RS annotation that noir-sbt does not consume is not recognized and is omitted.

Direct supported annotations are resolved with the existing import, fully qualified spelling, wildcard, local-shadow, same-package, and ambiguity rules. Source-defined Spring composed mappings and JAX-RS custom request-method annotations use the existing bounded annotation-definition graphs. Only the selected framework recognizer runs when `--framework` is supplied; both run when it is omitted.

After a direct candidate resolves to a supported framework FQN, consult the shared workspace type index. Any analyzed source type declaration owning that exact FQN suppresses direct framework classification for imported and fully qualified uses alike. This check suppresses only the direct registry path: the independent Spring-composition and JAX-RS custom request-method classifiers still run, so a same-FQN source annotation can be retained when its declaration independently satisfies supported source-defined semantics.

Contextual Java metadata is bounded to the positions actually consumed by those definition graphs: genuine `Retention` and `Target` meta-annotations on a participating source annotation declaration, and genuine `AliasFor` annotations on its elements. A Java `Override` occurrence is deliberately omitted because the hierarchy walker treats it only as a neutral exception while deciding whether some other JAX-RS annotation bundle may be inherited; it does not itself express supported Spring/JAX-RS attack-surface semantics.

For each candidate:

- one or more successful classifications retain the occurrence and produce sorted `Framework: spring` and/or `Framework: jaxrx` entries, each with its genuine `Resolved:` identity;
- no successful selected-framework classification omits the occurrence entirely;
- ambiguity, invalid provenance, an unrelated framework, or an unsupported annotation never produces an inventory item;
- repeated discovery of the same retained byte-span occurrence merges classifications rather than adding another item.

A centralized recognition table plus a coverage matrix is preferred over package-name prefixes. Prefix inference would incorrectly retain unsupported Spring/JAX-RS annotations and familiar-name shadows. Instrumenting endpoint emission is rejected because it would omit recognized annotations that fail a later endpoint-emission condition.

### 3. Keep a simple per-run inventory data shape

Store the inventory as file records containing only recognized annotation records; do not introduce a new object model. Workspace candidates retain their source node/name spelling and byte span while classification and extraction run. The finalized report record contains the displayed name, starting line, sorted framework entries, and bounded extract, without retaining Tree-sitter nodes beyond the analysis lifecycle.

Use the terminal identifier for the displayed `Annotation:` value; the complete original spelling remains visible in `Extract:` and a supported fully qualified identity appears in `Resolved:`. Sort files by the existing relative-path ordering and annotations by `(start_byte, end_byte)`.

This keeps the feature consistent with the current procedural host and provides an unambiguous occurrence identity even when several annotations share a line or name.

### 4. Build extracts from physical source lines

Create a line index for each source once. For an occurrence, emit every physical line intersected by the complete annotation node, then scan forward from its final physical line until 10 non-empty lines have been emitted or EOF is reached. Test emptiness after trimming, but render each retained line with its original indentation and one-based physical line number.

Extracts intentionally overlap when annotations are close together because each annotation must carry self-contained evidence. The fixed 10-line bound prevents unbounded context per occurrence.

### 5. Render inventory and diagnostics in two phases

Keep the public `write_log(message)` entry point used by the host and recall modules, but route its timestamped event text to a per-run diagnostic buffer instead of immediately interleaving it with report structure. Reset that buffer at CLI startup.

At the end of analysis, one renderer overwrites `<output>.log` in UTF-8 with:

1. file blocks and annotation items in deterministic order, without timestamps;
2. one `Diagnostics:` section containing buffered events in their original order and timestamped form.

The renderer emits `Annotations: none` for a file with no recognized occurrences; every rendered framework entry includes `Resolved:`. Keeping the existing logging function signature avoids changes throughout the recall modules. Buffering is preferred over prepending inventory to an already-written log because it guarantees one coherent layout and prevents partially interleaved file blocks.

The renderer follows this layout. Extracts are abbreviated here only to keep the example compact; the renderer still emits the complete annotation plus 10 following non-empty lines as specified.

```text
File: src/main/java/example/UserController.java
Annotations:
  - Annotation: GetMapping
    Line: 14
    Frameworks:
      - Framework: spring
        Resolved: org.springframework.web.bind.annotation.GetMapping
    Extract:
      14: @GetMapping("/users/{id}")
      15: public User find(
      16:     @PathVariable String id
      17: ) {
      18:     return service.find(id);
      19: }

  - Annotation: Read
    Line: 46
    Frameworks:
      - Framework: spring
        Resolved: annotations.Read
    Extract:
      46: @Read("/orders")
      47: public Order readOrder(String id) {
      48:     return service.read(id);
      49: }
```

Endpoint collection continues to return and format the same endpoint records. Annotation collection, classification, and log rendering do not participate in endpoint deduplication or CSV writing.

### 6. Lock the support boundary and output layout with tests

Add focused tests for annotation syntax in varied Java locations, supported direct and source-defined identities, omission of fake/ambiguous/unsupported identities, imported and fully qualified exact-FQN workspace shadows, same-FQN source declarations with supported composition/custom-method semantics, framework-mode filtering, occurrence deduplication, multiline annotations, blank-line skipping, EOF truncation, file ordering, files without recognized annotations, and diagnostic separation.

Keep full endpoint regressions as the compatibility gate. A maintained test matrix must cover every annotation role in the recognition registry so future endpoint features deliberately update logging recognition rather than drifting silently.

## Risks / Trade-offs

- **[Recognition registry drifts from endpoint analyzers]** → Keep one explicit registry organized by existing analyzer feature and enforce a coverage matrix plus source-defined annotation tests whenever supported semantics change.
- **[Ambiguous source identity is mislabeled as supported]** → Reuse fail-closed provenance resolution; ambiguous and invalid identities are omitted.
- **[Workspace source claims an exact supported framework FQN]** → Treat the workspace declaration as the identity owner and reject direct classification; keep only independently validated source-defined semantics eligible.
- **[Logs grow substantially in annotation-heavy supported projects]** → Retain the fixed 10-non-empty-line bound, reference already-loaded sources during collection, and render file blocks sequentially.
- **[Buffered diagnostics are lost on an unexpected fatal failure]** → Render buffered diagnostics on the controlled CLI error path; abrupt process termination retains the same best-effort limitation as the current logger.
- **[Existing log parsers break]** → Treat the layout as the proposal's declared log-only breaking change and cover exact structural markers with regression tests; CSV consumers remain unaffected.
- **[Generic query misses an unusual Java annotation position]** → Match annotation node kinds without constraining their parent and test declaration, parameter, type-use, package, record, nested, and meta-annotation placements.

## Migration Plan

1. Add generic candidate collection and selected-framework recognition without connecting them to endpoint emission.
2. Add extract/render helpers and focused tests for the new log contract.
3. Route existing diagnostic calls through the per-run buffer and render the two log sections.
4. Run the focused change tests and the complete endpoint regression suite.

No stored data migration is required. Rollback consists of restoring the former immediate log writer and removing the inventory rendering path; endpoint and CSV logic remain independently reversible.
