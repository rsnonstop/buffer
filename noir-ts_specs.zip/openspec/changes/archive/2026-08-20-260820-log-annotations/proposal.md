## Why

The companion log does not currently provide a complete, structured inventory of annotations that noir-sbt recognizes as supported by its Spring and JAX-RS analysis. Analysts need per-file annotation evidence, resolved framework identity, and nearby source context to understand and review what the scanner considered.

## What Changes

- Add a deterministic recognized-annotation inventory to the companion log, with one block for every discovered Java file, including files with no recognized annotations.
- Include only annotation occurrences that noir-sbt recognizes as supported by the selected Spring and/or JAX-RS analyzer; omit annotations from other or unsupported frameworks.
- Treat a source type declared in the analyzed workspace at an otherwise supported framework FQN as a shadow for direct recognition, while still allowing that annotation to qualify through supported source-defined Spring composition or JAX-RS request-method semantics.
- Report each recognized occurrence once with its annotation name, one-based starting line, applicable framework and resolved annotation identity, complete annotation source, and the next 10 non-empty source lines or the available remainder at end-of-file.
- Represent files without recognized annotations as `Annotations: none` and keep file and annotation ordering deterministic.
- Preserve existing analysis diagnostics in a distinct part of the log while leaving endpoint identification and the six-column CSV contract unchanged.
- **BREAKING (log consumers only)**: replace the current event-style companion log layout with the structured per-file annotation inventory layout; the CSV and CLI contracts do not change.

## Capabilities

### New Capabilities

- `log-annotations`: Produce structured, framework-resolved source evidence only for annotations that noir-sbt recognizes as supported by its Spring or JAX-RS analysis.

### Modified Capabilities

- None.

## Impact

- Affects annotation collection and companion-log rendering in the Python scanner, plus focused and regression test coverage.
- Changes the human- and machine-observable layout of `<output>.log`; consumers that parse its current timestamped event lines may require adjustment.
- Does not add dependencies, change CLI arguments, broaden endpoint support, or alter endpoint CSV contents.
