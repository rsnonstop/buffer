## MODIFIED Requirements

### Requirement: Existing scanner outputs remain compatible
The annotation inventory SHALL NOT change endpoint identification, CLI argument behavior, or endpoint CSV behavior except for the `method_annotation_line` extension defined by the endpoint-annotation-provenance capability. The CSV SHALL retain its original six columns in their existing order and append `method_annotation_line` as the seventh column. Existing analysis diagnostics SHALL remain available in a section distinct from the per-file annotation inventory.

#### Scenario: Annotation logging is enabled by normal analysis
- **WHEN** noir-sbt analyzes a source tree and writes the structured annotation inventory
- **THEN** it creates the endpoint CSV using the existing encoding, delimiter, normalization, six-field endpoint identity, deduplication, and ordering rules
- **AND** the CSV contains the existing six columns followed by `method_annotation_line`
- **AND** inventory inclusion does not create, remove, or select endpoint rows or their method-annotation provenance

#### Scenario: Analysis produces diagnostics
- **WHEN** the analyzer records skipped, ambiguous, or unresolved source evidence
- **THEN** those diagnostics remain in the companion log without being rendered as annotation items
