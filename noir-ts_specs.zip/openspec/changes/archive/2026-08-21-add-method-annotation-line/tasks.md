## 1. Shared Annotation Provenance Model

- [x] 1.1 Split the original six CSV identity fields from the seven-field presentation schema, appending `method_annotation_line` after `parameters` without reordering existing columns.
- [x] 1.2 Add a shared private method-annotation evidence record and constructor that validates a positive one-based line, canonical identity, configured semantic family, and source-file ownership without retaining AST nodes.
- [x] 1.3 Add immutable canonical annotation-type and family-priority configuration covering supported Spring MVC, HTTP-client, message, and Javax/Jakarta JAX-RS method triggers, including source-defined family fallback.
- [x] 1.4 Implement deterministic evidence selection by family priority, starting line, and resolved identity, with unit tests for `GetMapping` over `GET`, equal-priority ties, custom-family fallback, and familiar-name shadows.

## 2. Eligible Analyzer Evidence

- [x] 2.1 Extend direct and composed Spring mapping decoding to return canonical occurrence identity and priority family while preserving the outer method annotation node and existing route semantics.
- [x] 2.2 Attach evidence to direct Spring MVC and Feign endpoint candidates from the accepted method mapping, including pathless `RequestMapping`, multiline annotations, and path/method fan-out.
- [x] 2.3 Attach evidence to Spring HTTP Interface client candidates from accepted method-level `GetExchange`/`PostExchange`/`PutExchange`/`DeleteExchange`/`PatchExchange`/`HttpExchange` annotations.
- [x] 2.4 Attach evidence to Spring message endpoint candidates from accepted method-level `MessageMapping` and `SubscribeMapping` annotations while leaving handshake and registration routes empty.
- [x] 2.5 Extend standard and custom JAX-RS designator decoding with canonical identity and family metadata, and attach evidence to direct resource-method candidates from the designator occurrence rather than `Path`.
- [x] 2.6 Propagate Spring hierarchy and JAX-RS hierarchy/subresource evidence only when the annotation-owning declaration is the same source method represented by the endpoint row.
- [x] 2.7 Audit remaining endpoint producers and add explicit no-evidence handling for inherited-only mappings, record-component accessors, type-level WebSockets, activation annotations, functional/programmatic registrations, gateway DSL routes, and configuration-generated routes without repurposing `SrcLine`.

## 3. Legacy-Identity Merge and CSV Output

- [x] 3.1 Preserve private evidence through endpoint formatting while keeping it outside the declared public CSV fields and annotation-inventory data.
- [x] 3.2 Rework normalization and deduplication to group by the normalized original six-field tuple, merge candidate evidence, and emit exactly one selected line or an empty value per logical endpoint.
- [x] 3.3 Keep row sorting based on the legacy six-field tuple and verify that the seventh value cannot split, remove, or reorder legacy endpoints.
- [x] 3.4 Update CSV serialization and header tests for UTF-8 BOM, semicolon delimiter, the exact seven-column order, scalar line values, and empty ineligible fields.

## 4. Provenance Behavior Coverage

- [x] 4.1 Add end-to-end fixtures for both supplied Spring examples and assert the method-level `RequestMapping`/`GetMapping` line instead of the class annotation or method declaration line.
- [x] 4.2 Add direct Spring and JAX-RS coverage for multiline occurrences, path/method fan-out, fully qualified annotations, composed Spring mappings, and custom JAX-RS designators reporting their usage lines.
- [x] 4.3 Add Spring HTTP-client and message-mapping integration coverage showing eligible method annotations populate the new column.
- [x] 4.4 Add competing `GET`/`GetMapping`, equal-priority, annotated-plus-unannotated, and distinct-legacy-key fixtures to verify row-specific priority and six-field candidate merging.
- [x] 4.5 Add negative integration coverage proving inherited annotations from other declarations, record-component annotations, type-level annotations, unrelated method annotations, and non-annotation routes serialize an empty value.
- [x] 4.6 Update annotation-inventory CLI coverage for the seven-column contract and verify inventory inclusion and framework filtering neither create nor select endpoint provenance.

## 5. Compatibility and Validation

- [x] 5.1 Update existing row/header assertions and test helpers for the seventh field while retaining explicit comparisons of legacy six-field values, endpoint counts, normalization, deduplication, and order.
- [x] 5.2 Run the complete test suite and fix regressions without broadening endpoint recognition or changing existing fail-closed behavior for invalid or multiple mappings.
- [x] 5.3 Run strict OpenSpec validation and repeated end-to-end analyses, confirming byte-identical seven-column CSV output and unchanged six-field projections.
- [x] 5.4 Preserve pre-change last-candidate-wins behavior for analyzer-local duplicate metadata while merging private provenance, and add regression coverage for both the survivor fields and evidence union.
