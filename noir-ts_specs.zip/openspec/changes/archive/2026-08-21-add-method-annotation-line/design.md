## Context

See `proposal.md` for motivation and the delta specs for required behavior. Endpoint analyzers currently return small dictionaries with shared output facts and several branch-specific evidence fields. `SrcLine` is overloaded: direct Spring MVC and JAX-RS use an annotation line, while hierarchy, functional, configuration, gateway, and WebSocket branches may use a method, invocation, or type line. The shared formatter discards all line evidence, and deduplication currently keys on every declared CSV field.

The new value must therefore retain causal method-annotation evidence without changing endpoint discovery or allowing the seventh column to split rows that were identical under the existing six-column contract.

## Goals / Non-Goals

**Goals:**

- Carry resolved, causal method-annotation evidence from each eligible analyzer to the shared output boundary.
- Select one deterministic line when duplicate endpoint candidates provide competing evidence.
- Preserve the original six normalized fields as endpoint identity and ordering.
- Make ineligible branches explicit so an unrelated `SrcLine` can never leak into the new column.
- Keep annotation-inventory logging independent from endpoint provenance.

**Non-Goals:**

- Reinterpret or replace existing diagnostic, route, handler, or project source-line fields.
- Discover new endpoint annotations, frameworks, routes, or inheritance relationships.
- Add an annotation name or annotation source-file column to the public CSV.
- Change analyzer fail-closed behavior for multiple mappings or invalid annotations.

## Decisions

### 1. Represent provenance as explicit internal evidence

Eligible endpoint candidates will carry a private list of method-annotation evidence records. Each record contains:

- the annotation occurrence's one-based starting `line`;
- its canonical resolved `identity`;
- its static priority `family`; and
- its source file, used to guard the same-source-method invariant.

The evidence stays separate from `SrcLine`, `RouteSrcLine`, and `HandlerSrcLine`. A shared constructor/validator will reject missing, non-positive, or source-mismatched evidence rather than coercing existing line fields.

An evidence list is preferable to one scalar because duplicate analyzers and future fan-in can contribute more than one valid trigger before priority selection. Storing only a line would lose the resolved type needed for priority; storing a preselected line in each analyzer would make cross-analyzer selection inconsistent.

Alternative considered: derive the line from the annotation inventory after endpoint analysis. This was rejected because the inventory includes recognized annotations that do not emit endpoints and intentionally has no causal association with a particular row.

### 2. Attach evidence at the point where an analyzer accepts a trigger

Resolution code will return annotation metadata alongside its existing decoded mapping or designator:

- Direct Spring MVC and Feign mappings use the accepted method mapping occurrence.
- Spring HTTP Interface mappings use the accepted method-level `*Exchange` occurrence.
- Spring message endpoints use the accepted `MessageMapping` or `SubscribeMapping` occurrence.
- Direct JAX-RS resources use the accepted standard or custom request-method designator, not `Path`.
- Supported composed Spring and custom JAX-RS annotations use the outer occurrence on the represented method while retaining the resolved terminal family for priority.
- Hierarchy and JAX subresource passes attach evidence only when the annotation-owning method is the same source method represented by the CSV row.

Record-component accessors, inherited annotations owned by another declaration, class/type annotations, WebSocket handshake annotations, activation annotations, and functional or programmatic route evidence will carry no method-annotation evidence. An analyzer must never infer eligibility by scanning all annotations on a handler after the route has already been identified; it may attach only the occurrence that participated in its successful endpoint decision.

Alternative considered: copy `SrcLine` for direct analyzers and clear it in known exceptions. This was rejected because the meaning of `SrcLine` is branch-dependent and new analyzers could silently produce plausible but incorrect values.

### 3. Centralize canonical type resolution and static priority

Priority will be represented by immutable module-level configuration. Direct framework annotations will be keyed by canonical fully qualified identity, with semantic-family fallback for supported source-defined annotations. The configured family order is:

1. Spring verb-specific MVC and HTTP-client mappings;
2. Spring generic MVC and HTTP-client mappings;
3. Spring message mappings; and
4. standard or custom JAX-RS request-method designators.

This makes Spring `GetMapping` outrank JAX-RS `GET` when both contribute to the same legacy row. A composed/custom occurrence keeps its own resolved identity for deterministic comparison but inherits the family of its supported terminal mapping or designator. Candidate ordering is `(family priority, starting line, resolved identity)`.

Using canonical identities prevents a local shadow named `GetMapping` or `GET` from acquiring framework priority. Keeping the table centralized makes adding a newly supported annotation an explicit review point.

Alternative considered: use source order alone. This was rejected because output would depend on annotation layout and would not satisfy the configured type-priority requirement.

### 4. Merge provenance using the legacy endpoint key

The output pipeline will separate public schema from endpoint identity:

```text
analyzer endpoint facts
        │
        ▼
format and normalize original six fields
        │
        ▼
group by normalized six-field tuple
        │
        ├── merge private annotation evidence
        ▼
select highest-priority eligible evidence
        │
        ▼
append method_annotation_line and serialize seven fields
```

The implementation will keep an explicit constant for the original six identity fields and derive the seven-field presentation schema by appending `method_annotation_line`. Deduplication accumulates evidence under the six-field key, chooses one record centrally, and emits an empty value when the merged set contains none. Rows remain ordered by the same six-field tuple, so line-number text cannot perturb legacy ordering.

Analyzer-local deduplication will retain its pre-change survivor semantics for every non-provenance field. Where duplicate candidates historically used last-candidate-wins behavior, provenance merging will keep that last candidate as the base record and union only the private evidence collections.

Alternative considered: append the column and continue deduplicating on all declared fields. This was rejected because identical legacy rows carrying different annotation lines would become multiple endpoints instead of selecting one line.

### 5. Preserve procedural analyzer boundaries

The evidence record and selection helpers will remain small dictionaries/functions in the existing procedural architecture. Analyzer modules that already receive the host module will call shared evidence helpers rather than introducing a new object hierarchy or importing one analyzer from another.

Mapping/designator decoders will expose the minimum additional metadata needed by their callers. Public CSV formatting remains centralized, and `write_csv` continues to receive only declared public fields.

Alternative considered: introduce endpoint and annotation dataclasses across all analyzers. This would provide stronger typing but would create a broad migration unrelated to the requested output field.

### 6. Verify both branch coverage and output invariance

Tests will cover evidence creation and priority selection independently from end-to-end CSV behavior. Integration fixtures will cover the two supplied Spring examples, JAX-RS, composed/custom annotations, Spring clients, message mappings, competing `GET`/`GetMapping`, fan-out, and duplicate candidates. Negative fixtures will cover inherited mappings, record components, type-level WebSockets, functional/programmatic routes, and unrelated method annotations.

Compatibility assertions will compare the original six projected fields and endpoint count before and after the change, verify the exact seven-column header, and retain byte-identical repeated-run coverage. Annotation-inventory tests will verify that logging neither creates nor selects endpoint provenance.

## Risks / Trade-offs

- [Missed analyzer branch yields an unexpected blank] → Audit every endpoint producer reached by module analysis and add positive or explicit-empty coverage for each branch family.
- [An inherited annotation line points into a different file than `source_file_name`] → Require evidence ownership to match the represented source method and source file before attaching it.
- [The new field changes deduplication or ordering] → Maintain a named six-field identity tuple and test legacy projection and row count independently of the seven-field presentation.
- [Provenance merging changes non-public duplicate metadata] → Preserve each analyzer's existing candidate-survivor behavior while unioning only private annotation evidence.
- [Simple-name shadows receive incorrect priority] → Construct evidence only after existing framework/source-defined resolution succeeds and store canonical identities.
- [A custom annotation has no literal entry in the static table] → Carry its resolved semantic family and use the configured family priority, then deterministic line/identity tie-breakers.
- [Schema consumers reject the additional column] → Treat the header change as breaking, append rather than reorder existing fields, and document rollback.
- [Extra evidence increases memory on large repositories] → Keep evidence records scalar and merge them during the existing deduplication pass; do not retain AST nodes in formatted rows.

## Migration Plan

1. Add the internal evidence schema, canonical priority configuration, and selection helpers without changing CSV output.
2. Propagate evidence through eligible direct and extended analyzers; leave ineligible branches empty and retain existing diagnostic line fields.
3. Split the legacy identity-field constant from the seven-field presentation schema and merge/select provenance during deduplication.
4. Append the column in CSV formatting and update unit, integration, annotation-log, and deterministic-output tests.
5. Validate that projecting generated rows onto the original six columns preserves endpoint values, count, normalization, deduplication, and ordering.

Rollback consists of restoring the six-field presentation constant and bypassing provenance selection. Because the original endpoint fields and identity key remain unchanged, no stored-data migration is required.
