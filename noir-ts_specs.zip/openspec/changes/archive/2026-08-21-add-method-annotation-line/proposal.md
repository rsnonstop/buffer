## Why

Endpoint CSV rows identify their source method but do not expose which method-level annotation caused the endpoint to be emitted. Reporting that annotation's source line gives reviewers and downstream tooling direct, auditable provenance instead of a potentially unrelated method or route-evidence line.

## What Changes

- **BREAKING** Append `method_annotation_line` as the seventh endpoint CSV column, after the existing six columns.
- Populate the column with the one-based starting line of a supported triggering annotation syntactically attached to the source method represented by the row; leave it empty when no such annotation exists.
- When several eligible annotations contribute to the same logical endpoint row, select one by a statically configured priority of resolved annotation types. Prefer Spring `@GetMapping` over JAX-RS `@GET` in the stated competing-annotation case, with deterministic handling for supported source-defined annotations and equal-priority candidates.
- Treat the new value as provenance metadata: retain the existing six fields as endpoint identity, select provenance while merging duplicate candidates, and do not change endpoint identification or endpoint count.
- Preserve the existing CSV encoding, delimiter, normalization, deterministic ordering, and values of the original fields.
- Do not introduce support for new endpoint annotations, frameworks, or endpoint shapes.

## Capabilities

### New Capabilities

- `endpoint-annotation-provenance`: Defines CSV reporting of the triggering method annotation's source line, including eligibility, priority selection, duplicate-candidate merging, and empty-value behavior across all CSV-producing analyzers.

### Modified Capabilities

- `log-annotations`: Replaces the existing six-column CSV compatibility statement with the seven-column contract while preserving independence between annotation inventory logging and endpoint emission.

## Impact

- Affects endpoint provenance carried by direct and extended Spring and JAX-RS analyzers, including server, client, and messaging surfaces, plus shared CSV formatting and deduplication.
- Requires explicit empty provenance for class/type annotations, inherited annotations from a different represented method, record-component annotations, and functional or programmatic endpoint sources.
- Requires tests for direct, composed/custom, competing, fan-out, duplicate, and non-method-annotation endpoint evidence.
- Changes the public CSV header, so downstream consumers that assume exactly six columns may require updates.

## Original Request (As-Is)

````text
# TO-BE:
Extend CSV output:
- add column "method_annotation_line".

For each endpoint in CSV:
- if particular method came to "the CSV row" for the endpoint: as result of an Annotation defined on this method in source code: 
  then: 
  - fill column "method_annotation_line" with "line number" of where this "method Annotation, trigerring endpoint" is defined in the source code file.
  If there are several "such annotations" defined on the "endpoint method" - choose most appropriate annotation.
  Staticly configure priority of Annotation types, that can be defined on method as "multiple annotations. Example: "@GET" and "@GetMapping".

## Example 1
```
@RestController
@RequestMapping("/api")
public class MyController {

    @RequestMapping
    public String index() {
        return "index";
    }
}
```
For endpoint "/api" - use "@RequestMapping" annotation on method "index()"

## Example 2
```
@RestController
@RequestMapping("/api")
public class MyController {

    @GetMapping("/hello")
    public String hello() {
        return "hello";
    }
}
```
For Endpoint "GET /api/hello" - for method "hello()" - use annotation '@GetMapping("/hello")' on method "hello()"

````
