# endpoint-annotation-provenance Specification

## Purpose

Expose auditable source provenance for annotation-driven endpoint rows by reporting the line of the method annotation that caused each row to be emitted.

## Requirements

### Requirement: Endpoint CSV includes method annotation line
The system SHALL append `method_annotation_line` after `parameters` as the seventh endpoint CSV column. Every row SHALL contain either the one-based starting source line of its selected triggering method annotation or an empty value when no eligible annotation exists.

#### Scenario: Direct Spring method mapping
- **WHEN** `@GetMapping("/hello")` attached to an endpoint method starts on line 14 and produces `GET /api/hello`
- **THEN** the row's `method_annotation_line` value is `14`

#### Scenario: Pathless method mapping combined with a class path
- **WHEN** a method-level `@RequestMapping` produces an endpoint whose `/api` path is contributed by a class-level `@RequestMapping("/api")`
- **THEN** the row reports the starting line of the method-level `@RequestMapping`
- **AND** it does not report the line of the class-level annotation

#### Scenario: Multiline method annotation
- **WHEN** the selected triggering method annotation occupies multiple physical source lines
- **THEN** the row reports the line on which the annotation begins

#### Scenario: One annotation fans out into multiple rows
- **WHEN** one triggering method annotation produces multiple endpoint rows through path or HTTP-method fan-out
- **THEN** every resulting row reports that annotation's same starting line

### Requirement: Eligibility is tied to the represented source method and row
An annotation SHALL be eligible only when it is a supported endpoint trigger syntactically attached to the source method represented by the row and contributed to producing that particular row. Eligibility SHALL apply across every CSV-producing analyzer without enabling any new annotation, framework, or endpoint shape.

#### Scenario: JAX-RS request-method designator
- **WHEN** a supported JAX-RS request-method designator attached to the represented source method produces an endpoint row
- **THEN** the row reports the designator occurrence's starting line
- **AND** a `@Path` annotation is not selected merely because it contributes a path

#### Scenario: Supported Spring client method mapping
- **WHEN** a supported Spring HTTP-client mapping attached to the represented source method produces an outbound endpoint row
- **THEN** the row reports that method mapping's starting line

#### Scenario: Supported Spring message mapping
- **WHEN** `@MessageMapping` or `@SubscribeMapping` attached to the represented source method produces a message endpoint row
- **THEN** the row reports that method annotation's starting line

#### Scenario: Unrelated annotation on the same method
- **WHEN** an annotation is attached to the represented source method but did not contribute to producing the particular endpoint row
- **THEN** that annotation is not eligible to supply `method_annotation_line`

### Requirement: Source-defined triggering annotations report their usage line
When a supported source-defined or composed annotation attached to the represented source method triggers a row, the system SHALL report the line of that method-level occurrence rather than a line in the annotation type declaration or meta-annotation chain.

#### Scenario: Composed Spring mapping
- **WHEN** a supported composed Spring mapping attached to the represented source method triggers a row
- **THEN** `method_annotation_line` reports the composed annotation's occurrence on that method
- **AND** it does not report the line of an underlying mapping meta-annotation

#### Scenario: Custom JAX-RS request-method designator
- **WHEN** a supported source-defined JAX-RS request-method annotation attached to the represented source method triggers a row
- **THEN** `method_annotation_line` reports the custom annotation's occurrence on that method
- **AND** it does not report the line of its `@HttpMethod` declaration annotation

### Requirement: Non-method and indirect evidence produces an empty value
The system SHALL emit an empty `method_annotation_line` when an endpoint row has no supported triggering annotation syntactically attached to the source method represented by that row. Existing route, handler, activation, or diagnostic line evidence SHALL NOT be substituted.

#### Scenario: Endpoint produced without a method annotation
- **WHEN** an endpoint row is produced by functional routing, programmatic registration, configuration, a gateway DSL, or another non-annotation route mechanism
- **THEN** `method_annotation_line` is empty

#### Scenario: Type-level annotation
- **WHEN** a class, interface, record, or other type-level annotation contributes to an endpoint but no eligible annotation is attached to the represented source method
- **THEN** `method_annotation_line` is empty

#### Scenario: Inherited annotation belongs to another method declaration
- **WHEN** a concrete implementation method is represented by the row but its endpoint annotation occurs only on an interface or superclass method
- **THEN** `method_annotation_line` is empty

#### Scenario: Record-component annotation
- **WHEN** an endpoint is attributed to an implicit record accessor whose triggering annotation is syntactically attached to the record component rather than a source method
- **THEN** `method_annotation_line` is empty

#### Scenario: Type-level WebSocket endpoint
- **WHEN** a WebSocket handshake row is produced by a type-level endpoint annotation
- **THEN** `method_annotation_line` is empty

#### Scenario: Activation annotation does not define the route
- **WHEN** a method annotation activates analysis but does not define the particular endpoint route
- **THEN** that annotation does not supply `method_annotation_line`

### Requirement: Multiple eligible annotations use static resolved-type priority
When several eligible annotations contribute to the same logical endpoint row, the system SHALL select exactly one using a static priority defined against resolved annotation identities and semantic families, not simple-name spelling. The static order, from highest to lowest priority, SHALL be: recognized Spring verb-specific MVC and HTTP-client mappings; recognized Spring generic MVC and HTTP-client mappings; recognized Spring message mappings; and recognized standard or custom JAX-RS request-method designators. A supported source-defined annotation SHALL inherit the priority of its resolved Spring mapping or JAX-RS designator family. Equal-priority candidates SHALL be ordered by earliest starting source line and then by resolved identity.

#### Scenario: GET and GetMapping both trigger the same row
- **WHEN** genuine JAX-RS `@GET` and Spring `@GetMapping` annotations on the same represented method both contribute to the same logical endpoint row
- **THEN** `@GetMapping` is selected by the static priority
- **AND** `method_annotation_line` reports the starting line of `@GetMapping`

#### Scenario: Priority is specific to the row
- **WHEN** a method carries a higher-priority annotation that does not contribute to a particular row and a lower-priority annotation that does
- **THEN** the contributing annotation supplies `method_annotation_line`

#### Scenario: Source-defined annotation uses family priority
- **WHEN** a supported source-defined annotation and another eligible annotation contribute to the same logical endpoint row
- **THEN** the source-defined annotation is ranked using its resolved endpoint family

#### Scenario: Familiar simple name is shadowed
- **WHEN** a method annotation has the same simple name as a prioritized framework annotation but does not resolve to a supported endpoint trigger
- **THEN** it receives no framework priority and does not supply `method_annotation_line`

#### Scenario: Equal-priority candidates
- **WHEN** multiple eligible annotations have equal configured priority for the same logical endpoint row
- **THEN** the annotation with the earliest starting source line is selected

### Requirement: Annotation provenance does not change endpoint identity
The system SHALL continue to normalize, identify, deduplicate, and order logical endpoint rows using the original six CSV fields. It SHALL merge annotation provenance for candidates with the same normalized six-field identity, select one eligible annotation by the configured priority, and only then append `method_annotation_line`. The new column SHALL NOT create, remove, or distinguish endpoints.

#### Scenario: Duplicate candidates carry different annotation lines
- **WHEN** two endpoint candidates have the same normalized values for all original six fields but carry different eligible triggering annotations
- **THEN** the CSV contains one logical endpoint row
- **AND** its `method_annotation_line` is selected from the merged candidates by static priority

#### Scenario: Annotated and unannotated candidates merge
- **WHEN** annotated and unannotated endpoint candidates have the same normalized original six-field identity
- **THEN** the CSV contains one logical endpoint row
- **AND** the eligible annotation supplies its `method_annotation_line`

#### Scenario: Distinct legacy endpoint identities remain distinct
- **WHEN** two candidates differ in at least one normalized original CSV field
- **THEN** they remain distinct rows regardless of their `method_annotation_line` values

### Requirement: CSV presentation remains deterministic
The system SHALL retain the existing UTF-8 BOM encoding, semicolon delimiter, endpoint normalization, and deterministic ordering while emitting the seventh column. The values of the original six fields SHALL remain unchanged by annotation-provenance selection.

#### Scenario: Repeated identical analysis
- **WHEN** the same source tree and arguments are analyzed twice
- **THEN** both seven-column CSV outputs are byte-identical
