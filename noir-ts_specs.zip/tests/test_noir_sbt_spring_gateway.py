from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_spring_gateway  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class SpringGatewayTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze(self, directory_name, files, *, apply_path=None):
        module_root = self.root / directory_name
        source_by_file = {}
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
            source_by_file[str(source_file)] = source.encode("utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        workspace = noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=noir_sbt.build_jax_runtime(),
            include_jax=False,
        )
        return noir_sbt_spring_gateway.analyze_spring_gateway(
            workspace,
            noir_sbt,
            apply_path=apply_path,
        )

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
            for endpoint in endpoints
        }

    def test_03_spr_gw_001_genuine_publisher_fans_out_paths_and_methods(self):
        transformed = []

        def apply_path(path, **context):
            transformed.append(
                (path, context["owner_name"], context["surface"])
            )
            return f"/gateway{path}"

        endpoints = self.analyze(
            "gateway-direct",
            {
                "shared/Paths.java": """
                    package shared;
                    public final class Paths {
                        public static final String BASE = "/reports";
                        public static final String ALT = BASE + "/archive/**";
                        public static final String TARGET = "no://op";
                    }
                """,
                "api/GatewayRoutes.java": """
                    package api;
                    import org.springframework.cloud.gateway.route.RouteLocator;
                    import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
                    import org.springframework.cloud.gateway.filter.GatewayFilter;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.http.HttpMethod;
                    import shared.Paths;
                    public class GatewayRoutes {
                        @Bean
                        public RouteLocator routes(RouteLocatorBuilder builder) {
                            return /* docs */ builder.routes()
                                .route("reports", route -> route
                                    .path(Paths.BASE + "/**" /* docs */, Paths.ALT)
                                    .and()
                                    .method(
                                        HttpMethod.GET,
                                        HttpMethod.DELETE,
                                        HttpMethod.CONNECT
                                    )
                                    .uri(Paths.TARGET))
                                .route("public", route -> route
                                    .path("/public/**")
                                    .uri("no://op"))
                                .build();
                        }
                    }
                """,
            },
            apply_path=apply_path,
        )

        self.assertEqual(len(endpoints), 7)
        self.assertTrue(
            all(
                endpoint["protocol"] == "http"
                and endpoint["surface"] == "gateway"
                and endpoint["direction"] == "inbound"
                and endpoint["technology"] == "spring"
                for endpoint in endpoints
            )
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/gateway/reports/**", "GatewayRoutes.routes"),
                ("DELETE", "/gateway/reports/**", "GatewayRoutes.routes"),
                ("CONNECT", "/gateway/reports/**", "GatewayRoutes.routes"),
                (
                    "GET",
                    "/gateway/reports/archive/**",
                    "GatewayRoutes.routes",
                ),
                (
                    "DELETE",
                    "/gateway/reports/archive/**",
                    "GatewayRoutes.routes",
                ),
                (
                    "CONNECT",
                    "/gateway/reports/archive/**",
                    "GatewayRoutes.routes",
                ),
                ("ANY", "/gateway/public/**", "GatewayRoutes.routes"),
            },
        )
        self.assertEqual(
            transformed,
            [
                ("/reports/**", "GatewayRoutes", "gateway"),
                ("/reports/archive/**", "GatewayRoutes", "gateway"),
                ("/public/**", "GatewayRoutes", "gateway"),
            ],
        )

    def test_03_spr_gw_002_exact_predicate_spec_helper_binds_once(self):
        endpoints = self.analyze(
            "gateway-helper",
            {
                "shared/Paths.java": """
                    package shared;
                    public final class Paths {
                        public static final String COMMAND = "/commands/**";
                    }
                """,
                "api/HelperRoutes.java": """
                    package api;
                    import org.springframework.cloud.gateway.route.RouteLocator;
                    import org.springframework.cloud.gateway.route.builder.BooleanSpec;
                    import org.springframework.cloud.gateway.route.builder.PredicateSpec;
                    import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.http.HttpMethod;
                    import shared.Paths;
                    public class HelperRoutes {
                        @Bean
                        RouteLocator routes(/* docs */ RouteLocatorBuilder builder) {
                            return builder.routes()
                                .route("command", (PredicateSpec route) ->
                                    this.command(route).uri("no://op"))
                                .build();
                        }

                        private BooleanSpec command(PredicateSpec predicate) {
                            return predicate.method(HttpMethod.POST)
                                .and().path(Paths.COMMAND);
                        }

                    }
                """,
            },
        )

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("POST", "/commands/**", "HelperRoutes.routes")},
        )

    def test_03_spr_gw_003_dynamic_fake_and_ambiguous_shapes_fail_closed(self):
        endpoints = self.analyze(
            "gateway-negative",
            {
                "api/MixedRoutes.java": """
                    package api;
                    import org.springframework.cloud.gateway.route.RouteLocator;
                    import org.springframework.cloud.gateway.route.builder.BooleanSpec;
                    import org.springframework.cloud.gateway.route.builder.PredicateSpec;
                    import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.http.HttpMethod;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    public class MixedRoutes {
                        @Bean
                        RouteLocator routes(RouteLocatorBuilder builder) {
                            return builder.routes()
                                .route("valid", r -> r.path("/valid").uri("no://op"))
                                .route("host", r -> r.host("example.org").and()
                                    .path("/host").uri("no://op"))
                                .route("path", r -> r.path(dynamicPath()).uri("no://op"))
                                .route("body", r -> {
                                    return r.path("/block").uri("no://op");
                                })
                                .route("target", r -> r.path("/target").uri(target()))
                                .route("filter", r -> r.path("/filter")
                                    .filters(filters -> filters).uri("no://op"))
                                .route(routeId(), r -> r.path("/single-filter")
                                    .filter(gatewayFilter()).uri(target()))
                                .route("bad-connect", r -> r
                                    .path("/request-method-connect")
                                    .and().method(RequestMethod.CONNECT)
                                    .uri("no://op"))
                                .route("helper", r -> helper(r).uri("no://op"))
                                .build();
                        }

                        String dynamicPath() { return "/dynamic"; }
                        String routeId() { return "dynamic-id"; }
                        String target() { return "no://dynamic"; }
                        GatewayFilter gatewayFilter() { return null; }
                        BooleanSpec helper(PredicateSpec predicate) {
                            return predicate.method(RequestMethod.PUT)
                                .and().path("/ambiguous");
                        }
                        BooleanSpec helper(PredicateSpec predicate, String ignored) {
                            return predicate.path("/other");
                        }
                    }
                """,
                "api/NotPublished.java": """
                    package api;
                    import org.springframework.cloud.gateway.route.RouteLocator;
                    import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
                    public class NotPublished {
                        RouteLocator routes(RouteLocatorBuilder builder) {
                            return builder.routes()
                                .route("hidden", r -> r.path("/hidden").uri("no://op"))
                                .build();
                        }
                    }
                """,
                "fake/FakeGateway.java": """
                    package fake;
                    @interface Bean {}
                    class RouteLocator {}
                    class RouteLocatorBuilder {}
                    public class FakeGateway {
                        @Bean RouteLocator routes(RouteLocatorBuilder builder) {
                            return null;
                        }
                    }
                """,
            },
        )

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("ANY", "/valid", "MixedRoutes.routes"),
                ("ANY", "/target", "MixedRoutes.routes"),
                ("ANY", "/filter", "MixedRoutes.routes"),
                ("ANY", "/single-filter", "MixedRoutes.routes"),
                ("PUT", "/ambiguous", "MixedRoutes.routes"),
            },
        )
        diagnostics = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertGreaterEqual(
            diagnostics.count("Skipped Spring Gateway unsupported route lambda"),
            3,
        )


if __name__ == "__main__":
    unittest.main()
