from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_jax_recall  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class JaxHierarchyAndSubresourceRecallTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runtime = noir_sbt.build_jax_runtime()

    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def workspace(self, files):
        source_by_file = {
            str(self.root / relative_name): source.encode("utf8")
            for relative_name, source in files.items()
        }
        return noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=self.runtime,
        )

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
            for endpoint in endpoints
        }

    def recall(self, files):
        workspace = self.workspace(files)
        return workspace, noir_sbt_jax_recall.analyze_jax_recall(
            workspace, noir_sbt
        )

    def baseline(self, workspace):
        endpoints = []
        for file_name in sorted(workspace["units"]):
            endpoints.extend(
                noir_sbt.JaxRS_Analyzer(file_name, workspace=workspace)
            )
        return endpoints

    def test_host_analyze_module_runs_jax_recall_once(self):
        files = {
            "api/Contract.java": """
                package api;
                public interface Contract {
                    @jakarta.ws.rs.GET @jakarta.ws.rs.Path("/inherited")
                    void inherited();
                }
            """,
            "api/Root.java": """
                package api;
                @jakarta.ws.rs.Path("/root")
                public class Root implements Contract {
                    public void inherited() {}
                    @jakarta.ws.rs.Path("/sub")
                    public Leaf sub() { return null; }
                }
            """,
            "api/Leaf.java": """
                package api;
                public class Leaf {
                    @jakarta.ws.rs.POST @jakarta.ws.rs.Path("/leaf")
                    public void leaf() {}
                }
            """,
        }
        for relative_name, source in files.items():
            source_file = self.root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
        endpoints = noir_sbt.analyze_module(self.root, "jaxrx")
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/root/inherited", "Root.inherited"),
                ("POST", "/root/sub/leaf", "Leaf.leaf"),
            },
        )
        self.assertEqual(len(endpoints), 2)

    def test_transitive_generic_hierarchy_is_signature_aware_and_additions_only(self):
        files = {
            "contract/Base.java": """
                package contract;
                import jakarta.ws.rs.*;
                public interface Base<T> {
                    @GET @Path("/by-id") void fetch(T value);
                    @DELETE @Path("/number") void change(long value);
                    @POST @Path("/text") void change(String value);
                }
            """,
            "contract/Mid.java": """
                package contract;
                public interface Mid<U> extends Base<U> {}
            """,
            "api/Resource.java": """
                package api;
                import contract.Mid;
                import jakarta.ws.rs.*;
                @Path("/api")
                public class Resource implements Mid<String> {
                    @Override public void fetch(String value) {}
                    @Override public void change(long value) {}
                    @Override @PUT @Path("/override")
                    public void change(String value) {}
                }
            """,
        }
        workspace, additions = self.recall(files)

        self.assertEqual(
            self.endpoint_keys(additions),
            {
                ("GET", "/api/by-id", "Resource.fetch"),
                ("DELETE", "/api/number", "Resource.change"),
            },
        )
        self.assertEqual(
            self.endpoint_keys(self.baseline(workspace)),
            {("PUT", "/api/override", "Resource.change")},
        )
        self.assertNotIn(
            ("POST", "/api/text", "Resource.change"),
            self.endpoint_keys(additions),
        )

    def test_superclass_precedes_interface_and_direct_jax_annotations_block_inheritance(self):
        _workspace, additions = self.recall(
            {
                "sample/SuperResource.java": """
                    package sample;
                    import jakarta.ws.rs.*;
                    public abstract class SuperResource {
                        @GET @Path("/super") public abstract void chosen();
                    }
                """,
                "sample/Conflicting.java": """
                    package sample;
                    import jakarta.ws.rs.*;
                    public interface Conflicting {
                        @POST @Path("/interface") void chosen();
                    }
                """,
                "sample/Blocked.java": """
                    package sample;
                    import jakarta.ws.rs.*;
                    public interface Blocked {
                        @GET @Path("/inherited") void metadata(String value);
                        @GET @Path("/param") void parameter(String value);
                    }
                """,
                "sample/Root.java": """
                    package sample;
                    import jakarta.ws.rs.*;
                    @Path("/root")
                    public class Root extends SuperResource
                            implements Conflicting, Blocked {
                        @Override public void chosen() {}
                        @Override @Produces("text/plain")
                        public void metadata(String value) {}
                        @Override public void parameter(
                            @QueryParam("value") String value) {}
                    }
                """,
            }
        )

        self.assertEqual(
            self.endpoint_keys(additions),
            {("GET", "/root/super", "Root.chosen")},
        )

    def test_competing_interface_origins_and_mixed_families_fail_closed(self):
        _workspace, additions = self.recall(
            {
                "amb/A.java": """
                    package amb;
                    import jakarta.ws.rs.*;
                    public interface A { @GET @Path("/a") void clash(); }
                """,
                "amb/B.java": """
                    package amb;
                    import jakarta.ws.rs.*;
                    public interface B { @POST @Path("/b") void clash(); }
                """,
                "amb/Mixed.java": """
                    package amb;
                    public interface Mixed {
                        @jakarta.ws.rs.GET @javax.ws.rs.Produces("text/plain")
                        @jakarta.ws.rs.Path("/mixed") void mixed();
                    }
                """,
                "amb/Root.java": """
                    package amb;
                    @jakarta.ws.rs.Path("/root")
                    public class Root implements A, B, Mixed {
                        public void clash() {}
                        public void mixed() {}
                        @jakarta.ws.rs.GET @jakarta.ws.rs.Path("/direct")
                        public void direct() {}
                    }
                """,
            }
        )

        self.assertEqual(additions, [])
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("mixed Javax/Jakarta effective annotation bundle", diagnostic)

    def test_most_specific_interface_and_inherited_generic_locator_leaf_bind(self):
        _workspace, additions = self.recall(
            {
                "contract/Parent.java": """
                    package contract;
                    import jakarta.ws.rs.*;
                    public interface Parent {
                        @GET @Path("/parent") void selected();
                    }
                """,
                "contract/Child.java": """
                    package contract;
                    import jakarta.ws.rs.*;
                    public interface Child extends Parent {
                        @POST @Path("/child") void selected();
                    }
                """,
                "contract/Locator.java": """
                    package contract;
                    import jakarta.ws.rs.Path;
                    public interface Locator<T> {
                        @Path("/located") T locate();
                    }
                """,
                "contract/LeafContract.java": """
                    package contract;
                    import jakarta.ws.rs.*;
                    public interface LeafContract {
                        @GET @Path("/leaf") void leaf();
                    }
                """,
                "api/Leaf.java": """
                    package api;
                    import contract.LeafContract;
                    public class Leaf implements LeafContract {
                        @Override public void leaf() {}
                    }
                """,
                "api/Root.java": """
                    package api;
                    import contract.*;
                    import jakarta.ws.rs.Path;
                    @Path("/root")
                    public class Root implements Child, Parent, Locator<Leaf> {
                        @Override public void selected() {}
                        @Override public Leaf locate() { return null; }
                    }
                """,
            }
        )

        self.assertEqual(
            self.endpoint_keys(additions),
            {
                ("POST", "/root/child", "Root.selected"),
                ("GET", "/root/located/leaf", "Leaf.leaf"),
            },
        )

    def test_deep_locator_chain_exceeds_noir_one_hop_and_ignores_target_type_path(self):
        workspace, additions = self.recall(
            {
                "application/RestApplication.java": """
                    package application;
                    import jakarta.ws.rs.ApplicationPath;
                    import jakarta.ws.rs.core.Application;
                    @ApplicationPath("/app")
                    public class RestApplication extends Application {}
                """,
                "root/Root.java": """
                    package root;
                    import level.one.LevelOne;
                    import jakarta.ws.rs.Path;
                    @Path("/root") public class Root {
                        @Path("/one") public LevelOne one() { return null; }
                    }
                """,
                "level/one/LevelOne.java": """
                    package level.one;
                    import level.two.LevelTwo;
                    import jakarta.ws.rs.Path;
                    public class LevelOne {
                        @Path("/two") public LevelTwo two() { return null; }
                    }
                """,
                "level/two/LevelTwo.java": """
                    package level.two;
                    import jakarta.ws.rs.*;
                    @Path("/ignored") public class LevelTwo {
                        @GET @Path("/leaf") public String leaf(int id) { return ""; }
                    }
                """,
            }
        )

        self.assertEqual(
            self.endpoint_keys(additions),
            {("GET", "/app/root/one/two/leaf", "LevelTwo.leaf")},
        )
        # The old pass sees the independently rooted LevelTwo row, but cannot
        # compose the deep locator URI.
        self.assertEqual(
            self.endpoint_keys(self.baseline(workspace)),
            {("GET", "/app/ignored/leaf", "LevelTwo.leaf")},
        )

    def test_branch_local_guards_keep_sibling_paths_and_class_return_locators(self):
        _workspace, additions = self.recall(
            {
                "sample/Root.java": """
                    package sample;
                    import jakarta.ws.rs.Path;
                    @Path("/root") public class Root {
                        @Path("/a") public Leaf a() { return null; }
                        @Path("/b") public Class<Leaf> b() { return Leaf.class; }
                    }
                """,
                "sample/Leaf.java": """
                    package sample;
                    import jakarta.ws.rs.*;
                    public class Leaf {
                        @GET @Path("/leaf") public void leaf() {}
                    }
                """,
            }
        )

        self.assertEqual(
            self.endpoint_keys(additions),
            {
                ("GET", "/root/a/leaf", "Leaf.leaf"),
                ("GET", "/root/b/leaf", "Leaf.leaf"),
            },
        )

    def test_interface_type_path_composes_with_concrete_root(self):
        _workspace, additions = self.recall(
            {
                "catalog/CatalogApi.java": """
                    package catalog;
                    import jakarta.ws.rs.*;
                    @Path("/catalog")
                    public interface CatalogApi {
                        @GET @Path("/{id}") String find(String id);
                        @POST String create(String body);
                    }
                """,
                "catalog/CatalogResource.java": """
                    package catalog;
                    @jakarta.ws.rs.Path("/api")
                    public class CatalogResource implements CatalogApi {
                        public String find(String id) { return id; }
                        public String create(String body) { return body; }
                    }
                """,
            }
        )

        self.assertEqual(
            self.endpoint_keys(additions),
            {
                ("GET", "/api/catalog/{id}", "CatalogResource.find"),
                ("POST", "/api/catalog", "CatalogResource.create"),
            },
        )

    def test_locator_cycles_and_invalid_targets_skip_without_losing_valid_leaves(self):
        _workspace, additions = self.recall(
            {
                "cycle/Root.java": """
                    package cycle;
                    import jakarta.ws.rs.Path;
                    @Path("/root") public class Root<T extends Branch> {
                        @Path("/branch") public Branch branch() { return null; }
                        @Path("/object") public Object dynamic() { return null; }
                        @Path("/generic") public T generic() { return null; }
                    }
                """,
                "cycle/Branch.java": """
                    package cycle;
                    import jakarta.ws.rs.*;
                    public class Branch {
                        @GET @Path("/leaf") public void leaf() {}
                        @Path("/back") public Root back() { return null; }
                    }
                """,
            }
        )

        self.assertEqual(
            self.endpoint_keys(additions),
            {("GET", "/root/branch/leaf", "Branch.leaf")},
        )
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("cyclic or over-depth subresource traversal", diagnostic)
        self.assertIn("unresolved subresource locator return type", diagnostic)


if __name__ == "__main__":
    unittest.main()
