from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_spring_config  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class SpringConfigurationAndResourceTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def workspace(self, files):
        source_by_file = {}
        for relative_name, source in files.items():
            source_file = self.root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
            if source_file.suffix == ".java":
                source_by_file[str(source_file)] = source.encode("utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        return noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=noir_sbt.build_jax_runtime(),
            include_jax=False,
        )

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (
                endpoint["method"],
                endpoint["uri"],
                endpoint["SFunction"],
                endpoint["surface"],
            )
            for endpoint in endpoints
        }

    def test_03_spr_cfg_001_003_precedence_placeholders_and_project_isolation(self):
        workspace = self.workspace(
            {
                "module-a/src/main/java/api/Api.java": """
                    package api;
                    public class Api {}
                """,
                "module-a/src/main/resources/application.properties": """
                    server.servlet.context-path=/servlet
                    route.leaf=properties
                """,
                "module-a/src/main/resources/application.yml": """
                    spring:
                      webflux:
                        base-path: /webflux
                    route:
                      leaf: yml
                """,
                "module-a/src/main/resources/application.yaml": """
                    route:
                      leaf: yaml
                """,
                "module-a/resources/application.properties": """
                    route.leaf=resources
                """,
                "module-a/application.yaml": """
                    spring:
                      webflux:
                        base-path: latest
                    route:
                      leaf: root-yaml
                    number: 41
                """,
                "module-b/src/main/java/api/Other.java": """
                    package api;
                    public class Other {}
                """,
                "module-b/src/main/resources/application.properties": """
                    server.servlet.context-path=/other
                    route.leaf=module-b
                """,
            }
        )
        configuration = noir_sbt_spring_config.build_spring_configuration(
            workspace, self.root, noir_sbt
        )
        file_a = str(self.root / "module-a/src/main/java/api/Api.java")
        file_b = str(self.root / "module-b/src/main/java/api/Other.java")
        raw = [
            {
                "uri": "/items/${outer:${missing:${route.leaf}}}/${number:0}",
                "method": "GET",
                "uri_params": "",
                "SrcFile": file_a,
                "SrcLine": 1,
                "SFunction": "Api.items",
            },
            {
                "uri": "/${route.leaf}",
                "method": "POST",
                "uri_params": "",
                "SrcFile": file_b,
                "SrcLine": 1,
                "SFunction": "Other.create",
                "technology": "spring",
                "protocol": "http",
                "surface": "proxy",
                "direction": "inbound",
            },
            {
                "uri": "/registered",
                "method": "PUT",
                "uri_params": "",
                "SrcFile": file_b,
                "ProjectSrcFile": file_a,
                "SrcLine": 1,
                "SFunction": "Other.registeredElsewhere",
                "technology": "spring",
                "protocol": "http",
                "surface": "server",
                "direction": "inbound",
            },
            {
                "uri": "/socket/${route.leaf}",
                "method": "GET",
                "uri_params": "",
                "SrcFile": file_a,
                "SrcLine": 1,
                "SFunction": "Api.socket",
                "technology": "spring",
                "protocol": "ws",
                "surface": "server",
                "direction": "inbound",
            },
            {
                "uri": "/jax",
                "method": "GET",
                "uri_params": "",
                "SrcFile": file_a,
                "SrcLine": 1,
                "SFunction": "Jax.items",
                "technology": "jaxrs",
                "protocol": "http",
                "surface": "server",
                "direction": "inbound",
            },
        ]

        configured = noir_sbt_spring_config.apply_spring_configuration(
            raw, configuration, noir_sbt
        )
        self.assertEqual(
            [endpoint["uri"] for endpoint in configured],
            [
                "/latest/items/root-yaml/41",
                "/other/module-b",
                "/latest/registered",
                "/socket/${route.leaf}",
                "/jax",
            ],
        )
        self.assertEqual(
            noir_sbt_spring_config.apply_spring_configuration(
                configured, configuration, noir_sbt
            ),
            configured,
        )
        callback = noir_sbt_spring_config.spring_path_applicator(
            configuration, noir_sbt
        )
        self.assertEqual(
            callback(
                "/gateway/${route.leaf}", file_a, surface="gateway"
            ),
            "/latest/gateway/root-yaml",
        )
        self.assertEqual(
            callback(
                "/gateway/${route.leaf}",
                unit={"fname": file_a},
                owner_name="Routes.routes",
                surface="gateway",
            ),
            "/latest/gateway/root-yaml",
        )

    def test_03_spr_cfg_002_unsupported_yaml_and_bad_placeholders_fail_closed(self):
        workspace = self.workspace(
            {
                "module/src/main/java/api/Api.java": "package api; class Api {}",
                "ambiguous/src/generated/src/api/Ambiguous.java": (
                    "package api; class Ambiguous {}"
                ),
                "module/src/main/resources/application.yml": """
                    server:
                      servlet:
                        context-path: /must-not-leak
                    spring:
                      config:
                        activate:
                          on-profile: prod
                """,
                "module/resources/application.yaml": """
                    routes:
                      - /one
                      - /two
                """,
            }
        )
        configuration = noir_sbt_spring_config.build_spring_configuration(
            workspace, self.root, noir_sbt
        )
        source_file = str(self.root / "module/src/main/java/api/Api.java")
        ambiguous_file = str(
            self.root / "ambiguous/src/generated/src/api/Ambiguous.java"
        )
        exact_bound = "/" + "".join("${x:a}" for _ in range(100))
        repeated = "/" + "".join("${x:a}" for _ in range(101))
        raw = [
            {
                "uri": "/ok/${missing:default}",
                "method": "GET",
                "uri_params": "",
                "SrcFile": source_file,
                "SrcLine": 1,
                "SFunction": "Api.ok",
            },
            {
                "uri": exact_bound,
                "method": "GET",
                "uri_params": "",
                "SrcFile": source_file,
                "SrcLine": 2,
                "SFunction": "Api.exactBound",
            },
            {
                "uri": "/ambiguous",
                "method": "GET",
                "uri_params": "",
                "SrcFile": ambiguous_file,
                "SrcLine": 2,
                "SFunction": "Ambiguous.route",
            },
            {
                "uri": "/bad/${missing",
                "method": "GET",
                "uri_params": "",
                "SrcFile": source_file,
                "SrcLine": 2,
                "SFunction": "Api.bad",
            },
            {
                "uri": repeated,
                "method": "GET",
                "uri_params": "",
                "SrcFile": source_file,
                "SrcLine": 3,
                "SFunction": "Api.exhausted",
            },
        ]
        configured = noir_sbt_spring_config.apply_spring_configuration(
            raw, configuration, noir_sbt
        )
        self.assertEqual(
            [(endpoint["uri"], endpoint["SFunction"]) for endpoint in configured],
            [
                ("/ok/default", "Api.ok"),
                ("/" + "a" * 100, "Api.exactBound"),
                ("/ambiguous", "Ambiguous.route"),
            ],
        )
        diagnostics = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("unsupported or malformed YAML", diagnostics)
        self.assertIn("ambiguous project ownership", diagnostics)
        self.assertIn("malformed or exhausted placeholder", diagnostics)

    def test_03_spr_res_001_workspace_constants_fan_out_and_configuration(self):
        workspace = self.workspace(
            {
                "app/src/main/java/paths/Patterns.java": """
                    package paths;
                    public final class Patterns {
                        public static final String ASSETS = "/assets";
                        public static final String CONFIGURED = "/${asset.root:default}/**";
                    }
                """,
                "app/src/main/java/config/StaticResources.java": """
                    package config;
                    import paths.Patterns;
                    import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
                    import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
                    public final class StaticResources implements WebMvcConfigurer {
                        public void addResourceHandlers(ResourceHandlerRegistry registry) {
                            registry.addResourceHandler(
                                Patterns.ASSETS + "/**", Patterns.CONFIGURED
                            ).addResourceLocations("classpath:/static/");
                        }
                    }
                """,
                "app/src/main/resources/application.properties": """
                    server.servlet.context-path=/portal
                    asset.root=cdn
                """,
            }
        )
        raw = noir_sbt_spring_config.analyze_spring_resource_handlers(
            workspace, noir_sbt
        )
        configuration = noir_sbt_spring_config.build_spring_configuration(
            workspace, self.root, noir_sbt
        )
        endpoints = noir_sbt_spring_config.apply_spring_configuration(
            raw, configuration, noir_sbt
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (
                    "GET",
                    "/portal/assets/**",
                    "StaticResources.addResourceHandlers",
                    "static-handler",
                ),
                (
                    "GET",
                    "/portal/cdn/**",
                    "StaticResources.addResourceHandlers",
                    "static-handler",
                ),
            },
        )
        self.assertEqual({endpoint["protocol"] for endpoint in endpoints}, {"http"})
        self.assertEqual({endpoint["direction"] for endpoint in endpoints}, {"inbound"})
        self.assertEqual({endpoint["technology"] for endpoint in endpoints}, {"spring"})

    def test_03_spr_res_002_fake_alias_nested_mutated_and_unresolved_shapes(self):
        workspace = self.workspace(
            {
                "app/src/main/java/config/Good.java": """
                    package config;
                    import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
                    import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
                    public class Good implements WebMvcConfigurer {
                        @Override public void addResourceHandlers(ResourceHandlerRegistry registry) {
                            registry.addResourceHandler("/valid", UNKNOWN, "/also-valid");
                            if (enabled()) registry.addResourceHandler("/nested");
                        }
                        boolean enabled() { return true; }
                    }
                """,
                "app/src/main/java/config/AliasOnly.java": """
                    package config;
                    import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
                    import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
                    public class AliasOnly implements WebMvcConfigurer {
                        @Override public void addResourceHandlers(ResourceHandlerRegistry registry) {
                            ResourceHandlerRegistry alias = registry;
                            alias.addResourceHandler("/alias");
                        }
                    }
                """,
                "app/src/main/java/config/Mutated.java": """
                    package config;
                    import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
                    import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
                    public class Mutated implements WebMvcConfigurer {
                        @Override public void addResourceHandlers(ResourceHandlerRegistry registry) {
                            registry = replacement();
                            registry.addResourceHandler("/mutated");
                        }
                        ResourceHandlerRegistry replacement() { return null; }
                    }
                """,
                "app/src/main/java/fake/WebMvcConfigurer.java": """
                    package fake;
                    public interface WebMvcConfigurer {}
                """,
                "app/src/main/java/fake/ResourceHandlerRegistry.java": """
                    package fake;
                    public class ResourceHandlerRegistry {}
                """,
                "app/src/main/java/fake/FakeConfig.java": """
                    package fake;
                    public class FakeConfig implements WebMvcConfigurer {
                        @java.lang.Override
                        public void addResourceHandlers(ResourceHandlerRegistry registry) {}
                    }
                """,
            }
        )
        endpoints = noir_sbt_spring_config.analyze_spring_resource_handlers(
            workspace, noir_sbt
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (
                    "GET",
                    "/valid",
                    "Good.addResourceHandlers",
                    "static-handler",
                ),
                (
                    "GET",
                    "/also-valid",
                    "Good.addResourceHandlers",
                    "static-handler",
                ),
            },
        )
        diagnostics = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("nested resource registration", diagnostics)
        self.assertIn("unresolved resource-handler path", diagnostics)
        self.assertIn("mutated ResourceHandlerRegistry", diagnostics)


if __name__ == "__main__":
    unittest.main()
