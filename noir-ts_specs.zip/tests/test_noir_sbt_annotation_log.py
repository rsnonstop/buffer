from __future__ import annotations

import csv
import io
import sys
import tempfile
import unittest
from contextlib import redirect_stderr
from pathlib import Path
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


class AnnotationWorkspaceTestCase(unittest.TestCase):
    def setUp(self):
        self._old_globals = (
            noir_sbt.log_file,
            noir_sbt.input_srcdir,
            noir_sbt.module_name,
            noir_sbt.diagnostic_log_buffer,
        )
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")
        noir_sbt.diagnostic_log_buffer = None

    def tearDown(self):
        (
            noir_sbt.log_file,
            noir_sbt.input_srcdir,
            noir_sbt.module_name,
            noir_sbt.diagnostic_log_buffer,
        ) = self._old_globals
        self._temporary_directory.cleanup()

    def write_module(self, name, files):
        module_root = self.root / name
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
        return module_root

    def collect(self, name, files, framework=None):
        module_root = self.write_module(name, files)
        inventory = []
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        with mock.patch("builtins.print"):
            endpoints = noir_sbt.analyze_module(
                module_root,
                framework,
                annotation_inventory=inventory,
            )
        return module_root, inventory, endpoints

    @staticmethod
    def annotation_items(inventory):
        return [
            (file_record["file"], annotation)
            for file_record in inventory
            for annotation in file_record["annotations"]
        ]


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class AnnotationCandidateQueryTests(AnnotationWorkspaceTestCase):
    def test_generic_query_covers_java_positions_and_excludes_text_lookalikes(self):
        source = b'''@PackageAnn
package demo;

@Meta
public @interface Decl {}

@TypeAnn
class Outer {
    @FieldAnn String value;

    @MethodAnn(value = "@StringLookalike")
    void run(@ParamAnn String input, java.util.List<@UseAnn String> values) {
        // @CommentLookalike
        @LocalAnn String local = input;
    }

    @NestedAnn class Inner {}
}

record Data(@ComponentAnn String value) {}
'''
        runtime = noir_sbt.build_jax_runtime()
        workspace = noir_sbt.build_jax_workspace(
            {str(self.root / "package-info.java"): source}, runtime=runtime
        )
        unit = next(iter(workspace["units"].values()))
        names = [
            noir_sbt.node_text(unit["source"], record["name_node"])
            for record in unit["annotation_occurrences"]
        ]
        self.assertEqual(
            names,
            [
                "PackageAnn",
                "Meta",
                "TypeAnn",
                "FieldAnn",
                "MethodAnn",
                "ParamAnn",
                "UseAnn",
                "LocalAnn",
                "NestedAnn",
                "ComponentAnn",
            ],
        )
        self.assertNotIn("StringLookalike", names)
        self.assertNotIn("CommentLookalike", names)
        self.assertEqual(
            noir_sbt.declared_annotation_names(
                unit["source"], unit["matches"]["annotation_declaration"]
            ),
            {"Decl"},
        )

    def test_query_runner_uses_matches_as_the_association_unit(self):
        calls = []

        class Cursor:
            def __init__(self, query):
                calls.append(("init", query))

            def matches(self, root):
                calls.append(("matches", root))
                return [(0, {"annotation.node": []})]

        lifetime = []
        with mock.patch.object(noir_sbt, "QueryCursor", Cursor):
            matches = noir_sbt.run_query_matches("query", "root", lifetime)
        self.assertEqual(matches, [(0, {"annotation.node": []})])
        self.assertEqual(calls, [("init", "query"), ("matches", "root")])
        self.assertEqual(len(lifetime), 1)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class AnnotationRecognitionTests(AnnotationWorkspaceTestCase):
    SPRING_IDENTITIES = {
        "org.springframework.web.bind.annotation.RequestMapping",
        "org.springframework.web.bind.annotation.GetMapping",
        "org.springframework.web.bind.annotation.PostMapping",
        "org.springframework.web.bind.annotation.PutMapping",
        "org.springframework.web.bind.annotation.DeleteMapping",
        "org.springframework.web.bind.annotation.PatchMapping",
        "org.springframework.stereotype.Controller",
        "org.springframework.web.bind.annotation.RestController",
        "org.springframework.context.annotation.Bean",
        "org.springframework.context.annotation.Configuration",
        "org.springframework.beans.factory.annotation.Autowired",
        "org.springframework.web.service.annotation.HttpExchange",
        "org.springframework.web.service.annotation.GetExchange",
        "org.springframework.web.service.annotation.PostExchange",
        "org.springframework.web.service.annotation.PutExchange",
        "org.springframework.web.service.annotation.DeleteExchange",
        "org.springframework.web.service.annotation.PatchExchange",
        "org.springframework.cloud.openfeign.FeignClient",
        "org.springframework.messaging.handler.annotation.MessageMapping",
        "org.springframework.messaging.handler.annotation.SubscribeMapping",
    }
    JAX_IDENTITIES = {
        *(f"jakarta.ws.rs.{name}" for name in (
            "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS",
            "ApplicationPath", "BeanParam", "Consumes", "CookieParam",
            "DefaultValue", "Encoded", "FormParam", "HeaderParam",
            "HttpMethod", "MatrixParam", "Path", "PathParam", "Produces",
            "QueryParam",
        )),
        *(f"javax.ws.rs.{name}" for name in (
            "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS",
            "ApplicationPath", "BeanParam", "Consumes", "CookieParam",
            "DefaultValue", "Encoded", "FormParam", "HeaderParam",
            "HttpMethod", "MatrixParam", "Path", "PathParam", "Produces",
            "QueryParam",
        )),
        "jakarta.ws.rs.core.Context",
        "javax.ws.rs.core.Context",
        "jakarta.ws.rs.container.Suspended",
        "javax.ws.rs.container.Suspended",
        "jakarta.websocket.server.ServerEndpoint",
        "javax.websocket.server.ServerEndpoint",
    }

    def test_registry_matrix_is_complete_and_uses_exact_supported_identities(self):
        registry_identities = {"spring": set(), "jaxrx": set()}
        for framework, groups in noir_sbt.SUPPORTED_ANNOTATION_REGISTRY.items():
            for group in groups:
                registry_identities[framework].update(
                    f"{package}.{name}"
                    for package in group["packages"]
                    for name in group["names"]
                )
        self.assertEqual(registry_identities["spring"], self.SPRING_IDENTITIES)
        self.assertEqual(registry_identities["jaxrx"], self.JAX_IDENTITIES)

        expected = {
            *(('spring', identity) for identity in self.SPRING_IDENTITIES),
            *(('jaxrx', identity) for identity in self.JAX_IDENTITIES),
        }
        annotations = [
            f"    @{identity} void method{index}() {{}}"
            for index, (_framework, identity) in enumerate(sorted(expected))
        ]
        annotations.extend(
            [
                "    @org.springframework.web.bind.annotation.PathVariable String path;",
                "    @org.springframework.stereotype.Component String component;",
                "    @jakarta.ws.rs.NameBinding String binding;",
                "    @java.lang.Override void neutral() {}",
            ]
        )
        _root, inventory, _endpoints = self.collect(
            "registry",
            {"All.java": "class All {\n" + "\n".join(annotations) + "\n}\n"},
        )
        actual = {
            (classification["framework"], classification["resolved"])
            for _file, annotation in self.annotation_items(inventory)
            for classification in annotation["frameworks"]
        }
        self.assertEqual(actual, expected)
        inventoried_names = {
            annotation["name"] for _file, annotation in self.annotation_items(inventory)
        }
        self.assertTrue(
            {"PathVariable", "Component", "NameBinding", "Override"}.isdisjoint(
                inventoried_names
            )
        )

    def test_provenance_framework_filtering_and_empty_files_fail_closed(self):
        files = {
            "app/Valid.java": '''package app;
import org.springframework.web.bind.annotation.GetMapping;
import jakarta.ws.rs.*;
class Valid {
    @GetMapping void exact() {}
    @org.springframework.web.bind.annotation.PostMapping void qualified() {}
    @GetMapping String endpointInvalidPlacement;
    @Path("/jax") @GET void wildcard() {}
    @org.springframework.stereotype.Component String unsupported;
    @java.lang.Override void neutral() {}
}
''',
            "local/Local.java": '''package local;
import org.springframework.web.bind.annotation.*;
@interface GetMapping {}
class Local { @GetMapping void fake() {} }
''',
            "same/GetMapping.java": "package same; class GetMapping {}\n",
            "same/Api.java": '''package same;
import org.springframework.web.bind.annotation.*;
class Api { @GetMapping void fake() {} }
''',
            "fake/GetMapping.java": "package fake; public @interface GetMapping {}\n",
            "ambiguous/Api.java": '''package ambiguous;
import fake.*;
import org.springframework.web.bind.annotation.*;
class Api { @GetMapping void fake() {} }
''',
            "dual/Api.java": '''package dual;
import jakarta.ws.rs.*;
import javax.ws.rs.*;
class Api { @Path("/ambiguous") void fake() {} }
''',
            "plain/Plain.java": "package plain; class Plain {}\n",
        }
        _root, default_inventory, _endpoints = self.collect(
            "provenance-default", files
        )
        _root, spring_inventory, _endpoints = self.collect(
            "provenance-spring", files, "spring"
        )
        _root, jax_inventory, _endpoints = self.collect(
            "provenance-jax", files, "jaxrx"
        )

        self.assertEqual(
            [record["file"] for record in default_inventory], sorted(files)
        )
        self.assertTrue(
            all(len([record for record in default_inventory if record["file"] == name]) == 1
                for name in files)
        )
        default_items = self.annotation_items(default_inventory)
        self.assertEqual(
            [annotation["name"] for file_name, annotation in default_items
             if file_name == "app/Valid.java"],
            ["GetMapping", "PostMapping", "GetMapping", "Path", "GET"],
        )
        self.assertTrue(
            all(
                not record["annotations"]
                for record in default_inventory
                if record["file"] != "app/Valid.java"
            )
        )
        self.assertEqual(
            {
                classification["framework"]
                for _file, annotation in self.annotation_items(spring_inventory)
                for classification in annotation["frameworks"]
            },
            {"spring"},
        )
        self.assertEqual(
            [annotation["name"] for _file, annotation in self.annotation_items(jax_inventory)],
            ["Path", "GET"],
        )

    def test_workspace_declarations_shadow_exact_supported_framework_fqns(self):
        files = {
            "org/springframework/web/bind/annotation/GetMapping.java": '''package org.springframework.web.bind.annotation;
public @interface GetMapping {}
''',
            "jakarta/ws/rs/Path.java": '''package jakarta.ws.rs;
public @interface Path { String value(); }
''',
            "app/Api.java": '''package app;
import jakarta.ws.rs.Path;
import org.springframework.web.bind.annotation.GetMapping;
class Api {
    @GetMapping void importedSpringShadow() {}
    @org.springframework.web.bind.annotation.GetMapping void qualifiedSpringShadow() {}
    @Path("/imported") void importedJaxShadow() {}
    @jakarta.ws.rs.Path("/qualified") void qualifiedJaxShadow() {}
}
''',
        }
        _root, inventory, _endpoints = self.collect("exact-fqn-shadows", files)

        self.assertEqual(
            [record["file"] for record in inventory],
            sorted(files),
        )
        self.assertEqual(self.annotation_items(inventory), [])

    def test_exact_fqn_source_declarations_can_use_supported_semantics(self):
        files = {
            "org/springframework/web/bind/annotation/GetMapping.java": '''package org.springframework.web.bind.annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping("/source-defined")
public @interface GetMapping {}
''',
            "jakarta/ws/rs/GET.java": '''package jakarta.ws.rs;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.RUNTIME)
@HttpMethod("FETCH")
public @interface GET {}
''',
            "app/Api.java": '''package app;
import jakarta.ws.rs.GET;
import org.springframework.web.bind.annotation.GetMapping;
class Api {
    @GetMapping void spring() {}
    @GET void jax() {}
}
''',
        }
        _root, inventory, _endpoints = self.collect(
            "exact-fqn-supported-semantics", files
        )

        app_annotations = [
            annotation
            for file_name, annotation in self.annotation_items(inventory)
            if file_name == "app/Api.java"
        ]
        self.assertEqual(
            [annotation["name"] for annotation in app_annotations],
            ["GetMapping", "GET"],
        )
        self.assertEqual(
            app_annotations[0]["frameworks"],
            [
                {
                    "framework": "spring",
                    "resolved": "org.springframework.web.bind.annotation.GetMapping",
                }
            ],
        )
        self.assertEqual(
            app_annotations[1]["frameworks"],
            [{"framework": "jaxrx", "resolved": "jakarta.ws.rs.GET"}],
        )

    def test_source_defined_semantics_merge_and_invalid_graphs_are_omitted(self):
        files = {
            "annotations/Read.java": '''package annotations;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import jakarta.ws.rs.HttpMethod;
import org.springframework.core.annotation.AliasFor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@RequestMapping(method = RequestMethod.GET)
@HttpMethod("READ")
public @interface Read {
    @AliasFor(annotation = RequestMapping.class, attribute = "path")
    String[] value() default {};
    @Retention(RetentionPolicy.RUNTIME)
    String unrelatedMetadata() default "";
}
''',
            "annotations/Bad.java": '''package annotations;
@jakarta.ws.rs.HttpMethod("BAD")
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
public @interface Bad {}
''',
            "annotations/InvalidSpring.java": '''package annotations;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.GetMapping
public @interface InvalidSpring {}
''',
            "annotations/InvalidAlias.java": '''package annotations;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping
public @interface InvalidAlias {
    @org.springframework.core.annotation.AliasFor(
        annotation = org.springframework.web.bind.annotation.RequestMapping.class,
        attribute = "path"
    )
    int value() default 0;
}
''',
            "annotations/CycleA.java": '''package annotations;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@CycleB public @interface CycleA {}
''',
            "annotations/CycleB.java": '''package annotations;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@CycleA public @interface CycleB {}
''',
            "duplicate/One.java": '''package duplicate;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping
public @interface Duplicate {}
''',
            "duplicate/Two.java": '''package duplicate;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping
public @interface Duplicate {}
''',
            "api/Api.java": '''package api;
import annotations.Bad;
import annotations.CycleA;
import annotations.InvalidAlias;
import annotations.InvalidSpring;
import annotations.Read;
import duplicate.Duplicate;
class Api {
    @Read("/hybrid") void read() {}
    @Bad void bad() {}
    @InvalidAlias void invalidAlias() {}
    @InvalidSpring void invalid() {}
    @CycleA void cycle() {}
    @Duplicate void duplicate() {}
}
''',
        }
        _root, inventory, _endpoints = self.collect("source-defined", files)
        items = self.annotation_items(inventory)
        api_items = [
            annotation for file_name, annotation in items if file_name == "api/Api.java"
        ]
        self.assertEqual([annotation["name"] for annotation in api_items], ["Read"])
        self.assertEqual(
            api_items[0]["frameworks"],
            [
                {"framework": "jaxrx", "resolved": "annotations.Read"},
                {"framework": "spring", "resolved": "annotations.Read"},
            ],
        )

        read_metadata = {
            annotation["name"]: annotation["frameworks"]
            for file_name, annotation in items
            if file_name == "annotations/Read.java"
        }
        self.assertEqual(
            sum(
                annotation["name"] == "Retention"
                for file_name, annotation in items
                if file_name == "annotations/Read.java"
            ),
            1,
        )
        self.assertEqual(
            read_metadata["Target"],
            [
                {"framework": "jaxrx", "resolved": "java.lang.annotation.Target"},
                {"framework": "spring", "resolved": "java.lang.annotation.Target"},
            ],
        )
        self.assertEqual(
            read_metadata["Retention"],
            [
                {"framework": "jaxrx", "resolved": "java.lang.annotation.Retention"},
                {"framework": "spring", "resolved": "java.lang.annotation.Retention"},
            ],
        )
        self.assertEqual(
            read_metadata["AliasFor"],
            [{"framework": "spring", "resolved": "org.springframework.core.annotation.AliasFor"}],
        )


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class AnnotationExtractTests(AnnotationWorkspaceTestCase):
    def test_extracts_preserve_complete_annotation_and_bounded_physical_context(self):
        source_lines = [
            "class Api {",
            "    @org.springframework.web.bind.annotation.GetMapping(",
            "        ",
            "        path = \"/one\"",
            "    )",
            "",
            "      ",
            "    void one() {",
            "        int a = 1;",
            "        int b = 2;",
            "        int c = 3;",
            "        int d = 4;",
            "        int e = 5;",
            "        int f = 6;",
            "        int g = 7;",
            "        int h = 8;",
            "        int i = 9;",
            "        int j = 10;",
            "    }",
            "    @org.springframework.web.bind.annotation.PostMapping @org.springframework.web.bind.annotation.GetMapping void both() {}",
            "    int tail = 1;",
            "}",
        ]
        _root, inventory, _endpoints = self.collect(
            "extract", {"Api.java": "\n".join(source_lines) + "\n"}, "spring"
        )
        annotations = inventory[0]["annotations"]
        self.assertEqual(
            [annotation["name"] for annotation in annotations],
            ["GetMapping", "PostMapping", "GetMapping"],
        )
        first_extract = annotations[0]["extract"]
        self.assertEqual(
            [source_line["line"] for source_line in first_extract],
            [2, 3, 4, 5, *range(8, 18)],
        )
        self.assertEqual(first_extract[1]["source"], "        ")
        self.assertEqual(first_extract[2]["source"], '        path = "/one"')
        self.assertNotIn(18, [line["line"] for line in first_extract])

        for annotation in annotations[1:]:
            self.assertEqual(
                [source_line["line"] for source_line in annotation["extract"]],
                [20, 21, 22],
            )
            self.assertEqual(annotation["extract"][0]["source"], source_lines[19])


class AnnotationRendererAndDiagnosticsTests(AnnotationWorkspaceTestCase):
    def test_renderer_matches_structured_layout_and_separates_diagnostics(self):
        inventory = [
            {
                "file": "src/main/java/example/UserController.java",
                "annotations": [
                    {
                        "name": "GetMapping",
                        "line": 14,
                        "frameworks": [
                            {
                                "framework": "spring",
                                "resolved": "org.springframework.web.bind.annotation.GetMapping",
                            }
                        ],
                        "extract": [
                            {"line": 14, "source": '    @GetMapping("/users/{id}")'},
                            {"line": 15, "source": "    public User find() {"},
                        ],
                    },
                    {
                        "name": "Read",
                        "line": 46,
                        "frameworks": [
                            {"framework": "spring", "resolved": "annotations.Read"}
                        ],
                        "extract": [
                            {"line": 46, "source": '    @Read("/orders")'},
                            {"line": 47, "source": "    public Order read() {"},
                        ],
                    },
                ],
            },
            {"file": "src/main/java/example/Plain.java", "annotations": []},
        ]
        report = self.root / "rendered.log"
        diagnostics = [
            "2026-08-20 10:00:00 first",
            "2026-08-20 10:00:01 second",
        ]
        noir_sbt.render_annotation_log(report, inventory, diagnostics)
        self.assertEqual(
            report.read_text(encoding="utf8"),
            '''File: src/main/java/example/UserController.java
Annotations:
  - Annotation: GetMapping
    Line: 14
    Frameworks:
      - Framework: spring
        Resolved: org.springframework.web.bind.annotation.GetMapping
    Extract:
      14:     @GetMapping("/users/{id}")
      15:     public User find() {

  - Annotation: Read
    Line: 46
    Frameworks:
      - Framework: spring
        Resolved: annotations.Read
    Extract:
      46:     @Read("/orders")
      47:     public Order read() {

File: src/main/java/example/Plain.java
Annotations: none

Diagnostics:
2026-08-20 10:00:00 first
2026-08-20 10:00:01 second
''',
        )

    def test_write_log_buffers_timestamped_events_in_order_and_direct_calls_still_write(self):
        with mock.patch.object(noir_sbt, "datetime") as clock:
            clock.now.return_value.strftime.side_effect = [
                "2026-08-20 10:00:00",
                "2026-08-20 10:00:01",
                "2026-08-20 10:00:02",
            ]
            noir_sbt.diagnostic_log_buffer = []
            noir_sbt.write_log("first")
            noir_sbt.write_log("second")
            self.assertEqual(
                noir_sbt.diagnostic_log_buffer,
                [
                    "2026-08-20 10:00:00 first",
                    "2026-08-20 10:00:01 second",
                ],
            )
            noir_sbt.diagnostic_log_buffer = None
            noir_sbt.write_log("direct")
        self.assertEqual(
            Path(noir_sbt.log_file).read_text(encoding="utf8"),
            "2026-08-20 10:00:02 direct\n",
        )

    def test_controlled_cli_error_renders_diagnostics_and_restores_buffer(self):
        module_root = self.write_module("controlled-error", {"Plain.java": "class Plain {}\n"})
        output = self.root / "error.csv"
        previous_buffer = ["outer"]
        noir_sbt.diagnostic_log_buffer = previous_buffer
        with (
            mock.patch.object(
                noir_sbt, "analyze_module", side_effect=RuntimeError("controlled failure")
            ),
            redirect_stderr(io.StringIO()),
            self.assertRaises(SystemExit),
        ):
            noir_sbt.main(["--path", str(module_root), "--output", str(output)])
        report = Path(f"{output}.log").read_text(encoding="utf8")
        self.assertIn("Diagnostics:\n", report)
        self.assertIn("Framework mode: spring and jaxrx", report)
        self.assertIn("ERROR: controlled failure", report)
        self.assertNotIn("Annotation:", report)
        self.assertIs(noir_sbt.diagnostic_log_buffer, previous_buffer)

    def test_unexpected_cli_error_best_effort_renders_before_reraising(self):
        module_root = self.write_module("unexpected-error", {"Plain.java": "class Plain {}\n"})
        output = self.root / "unexpected.csv"

        def fail_after_diagnostic(*_args, **_kwargs):
            noir_sbt.write_log("diagnostic before unexpected failure")
            raise ValueError("unexpected failure")

        with (
            mock.patch.object(noir_sbt, "analyze_module", side_effect=fail_after_diagnostic),
            self.assertRaisesRegex(ValueError, "unexpected failure"),
        ):
            noir_sbt.main(["--path", str(module_root), "--output", str(output)])
        report = Path(f"{output}.log").read_text(encoding="utf8")
        self.assertIn("Framework mode: spring and jaxrx", report)
        self.assertIn("diagnostic before unexpected failure", report)
        self.assertIsNone(noir_sbt.diagnostic_log_buffer)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class AnnotationCliIntegrationTests(AnnotationWorkspaceTestCase):
    def test_cli_default_and_filtered_modes_preserve_csv_and_inventory_contracts(self):
        files = {
            "a/SpringApi.java": '''package a;
import org.springframework.web.bind.annotation.GetMapping;
class SpringApi { @GetMapping("/spring") void spring() {} }
''',
            "b/JaxApi.java": '''package b;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
@Path("/jax") class JaxApi { @GET public void get() {} }
''',
            "c/Plain.java": '''package c;
@org.springframework.stereotype.Component class Plain {}
''',
        }
        module_root = self.write_module("cli", files)

        results = {}
        for label, framework in (("default", None), ("spring", "spring"), ("jax", "jaxrx")):
            output = self.root / f"{label}.csv"
            arguments = ["--path", str(module_root), "--output", str(output)]
            if framework is not None:
                arguments.extend(["--framework", framework])
            with mock.patch("builtins.print"):
                self.assertEqual(noir_sbt.main(arguments), 0)
            raw_csv = output.read_bytes()
            with output.open("r", encoding="utf-8-sig", newline="") as stream:
                reader = csv.DictReader(stream, delimiter=";")
                rows = list(reader)
                headers = reader.fieldnames
            report = Path(f"{output}.log").read_text(encoding="utf8")
            inventory_text, diagnostics = report.split("Diagnostics:\n", 1)
            results[label] = (rows, inventory_text, diagnostics)
            self.assertTrue(raw_csv.startswith(b"\xef\xbb\xbf"))
            self.assertEqual(
                headers,
                [
                    "module_name",
                    "interface_type",
                    "endpoint",
                    "source_file_name",
                    "method_name",
                    "parameters",
                    "method_annotation_line",
                ],
            )
            self.assertEqual(inventory_text.count("File: "), len(files))
            self.assertEqual(
                [
                    line.removeprefix("File: ")
                    for line in inventory_text.splitlines()
                    if line.startswith("File: ")
                ],
                sorted(files),
            )
            self.assertNotIn("2026-", inventory_text)
            self.assertIn("Framework mode:", diagnostics)
            self.assertIsNone(noir_sbt.diagnostic_log_buffer)

        self.assertIn("Annotation: GetMapping", results["default"][1])
        self.assertIn("Annotation: Path", results["default"][1])
        self.assertIn("Annotation: GET", results["default"][1])
        self.assertIn("Annotation: GetMapping", results["spring"][1])
        self.assertNotIn("Annotation: Path", results["spring"][1])
        self.assertNotIn("Annotation: GET", results["spring"][1])
        self.assertNotIn("Annotation: GetMapping", results["jax"][1])
        self.assertIn("Annotation: Path", results["jax"][1])
        self.assertIn("Annotation: GET", results["jax"][1])
        self.assertNotIn("Annotation: Component", results["default"][1])

        self.assertEqual(
            {(row["interface_type"], row["endpoint"]) for row in results["default"][0]},
            {("http GET", "/spring"), ("http GET", "/jax")},
        )
        self.assertEqual(
            {(row["interface_type"], row["endpoint"]) for row in results["spring"][0]},
            {("http GET", "/spring")},
        )
        self.assertEqual(
            {(row["interface_type"], row["endpoint"]) for row in results["jax"][0]},
            {("http GET", "/jax")},
        )
        self.assertEqual(
            {
                (row["interface_type"], row["endpoint"]): row[
                    "method_annotation_line"
                ]
                for row in results["default"][0]
            },
            {("http GET", "/spring"): "3", ("http GET", "/jax"): "4"},
        )
        self.assertEqual(
            [row["method_annotation_line"] for row in results["spring"][0]],
            ["3"],
        )
        self.assertEqual(
            [row["method_annotation_line"] for row in results["jax"][0]],
            ["4"],
        )
        for rows, _inventory, _diagnostics in results.values():
            self.assertTrue(all(set(row) == set(noir_sbt.CSV_FIELDNAMES) for row in rows))
            self.assertTrue(all("Annotation" not in value for row in rows for value in row.values()))


if __name__ == "__main__":
    unittest.main()
