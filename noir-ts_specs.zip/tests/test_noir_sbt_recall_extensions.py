from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class JavaRecallExtensionIntegrationTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze_module(self, directory_name, files, framework=None):
        module_root = self.root / directory_name
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        with mock.patch("builtins.print"):
            return noir_sbt.analyze_module(module_root, framework)

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
            for endpoint in endpoints
        }

    def assert_jax_diagnostic_was_written(self):
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("Skipped JAX-RS", diagnostic)

    def test_03_spr_rec_001_top_level_and_nested_record_routes(self):
        endpoints = self.analyze_module(
            "spring-records",
            {
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String route();
                    }
                """,
                "api/TopRecord.java": """
                    package api;
                    import annotations.Read;
                    import org.springframework.web.bind.annotation.RestController;
                    import org.springframework.web.bind.annotation.GetMapping;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    @RestController
                    @RequestMapping("/top")
                    public record TopRecord() {
                        @GetMapping("/direct") public String direct() { return ""; }
                        @Read(route = "/composed") public String composed() { return ""; }
                    }
                """,
                "api/Outer.java": """
                    package api;
                    import org.springframework.web.bind.annotation.PostMapping;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RestController;
                    public final class Outer {
                        @RestController
                        @RequestMapping("/nested")
                        public record Nested() {
                            @PostMapping("/save")
                            public String save() { return ""; }
                        }
                    }
                """,
                "api/RootRecord.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    import org.springframework.web.bind.annotation.RestController;
                    @RestController
                    public record RootRecord() {
                        @GetMapping("/root") public String root() { return ""; }
                    }
                """,
                "api/AccessorRecord.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    import org.springframework.web.bind.annotation.RestController;
                    @RestController
                    public record AccessorRecord(String value) {
                        @Override
                        @GetMapping("/accessor")
                        public String value() { return value; }
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(len(endpoints), 5)
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/top/direct", "TopRecord.direct"),
                ("GET", "/top/composed", "TopRecord.composed"),
                ("POST", "/nested/save", "Outer.Nested.save"),
                ("GET", "/root", "RootRecord.root"),
                ("GET", "/accessor", "AccessorRecord.value"),
            },
        )

    def test_03_jax_rec_001_javax_jakarta_and_nested_record_roots(self):
        endpoints = self.analyze_module(
            "jax-records",
            {
                "designators/PROBE.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod("PROBE")
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    public @interface PROBE {}
                """,
                "api/Modern.java": """
                    package api;
                    import designators.PROBE;
                    @jakarta.ws.rs.Path("/modern")
                    public record Modern() {
                        @jakarta.ws.rs.GET @jakarta.ws.rs.Path("/items")
                        public String items() { return ""; }
                        @PROBE public String probe() { return ""; }
                    }
                """,
                "api/Legacy.java": """
                    package api;
                    @javax.ws.rs.Path("/legacy")
                    public record Legacy() {
                        @javax.ws.rs.POST public String create() { return ""; }
                    }
                """,
                "api/Holder.java": """
                    package api;
                    public final class Holder {
                        @jakarta.ws.rs.Path("/nested")
                        public record Nested() {
                            @jakarta.ws.rs.DELETE
                            public String delete() { return ""; }
                        }
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(len(endpoints), 4)
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/modern/items", "Modern.items"),
                ("PROBE", "/modern", "Modern.probe"),
                ("POST", "/legacy", "Legacy.create"),
                ("DELETE", "/nested", "Holder.Nested.delete"),
            },
        )

    def test_03_rec_002_nonroute_components_accessors_and_local_records(self):
        endpoints = self.analyze_module(
            "record-nonroutes",
            {
                "api/PlainRecord.java": """
                    package api;
                    public record PlainRecord(@Deprecated String value) {
                        @Deprecated
                        public String value() { return this.value; }
                    }
                """,
                "api/OrdinaryApi.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class OrdinaryApi {
                        @GetMapping("/ordinary") void ordinary() {}
                        void enclosing() {
                            @org.springframework.web.bind.annotation.RestController
                            record LocalRecord() {
                                @GetMapping("/local") void local() {}
                            }
                        }
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(len(endpoints), 1)
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/ordinary", "OrdinaryApi.ordinary")},
        )

    def test_03_rec_acc_001_method_applicable_components_emit_implicit_accessors(self):
        spring_endpoints = self.analyze_module(
            "record-component-spring",
            {
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.ElementType;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import java.lang.annotation.Target;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Target(ElementType.METHOD)
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String route();
                    }
                """,
                "annotations/Create.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/created", method = RequestMethod.POST)
                    public @interface Create {}
                """,
                "api/ComponentController.java": """
                    package api;
                    import annotations.Create;
                    import annotations.Read;
                    import org.springframework.web.bind.annotation.GetMapping;
                    import org.springframework.web.bind.annotation.PostMapping;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RestController;
                    @RestController
                    @RequestMapping("/records")
                    public record ComponentController(
                        @GetMapping("/direct") String direct,
                        @Read(route = "/composed") String composed,
                        @Create String created,
                        @PostMapping("/tail") String... tail
                    ) {}
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(spring_endpoints),
            {
                ("GET", "/records/direct", "ComponentController.direct"),
                ("GET", "/records/composed", "ComponentController.composed"),
                ("POST", "/records/created", "ComponentController.created"),
                ("POST", "/records/tail", "ComponentController.tail"),
            },
        )
        self.assertEqual(len(spring_endpoints), 4)
        self.assertTrue(
            all(endpoint["uri_params"] == "" for endpoint in spring_endpoints)
        )

        jax_endpoints = self.analyze_module(
            "record-component-jax",
            {
                "designators/PROBE.java": """
                    package designators;
                    @java.lang.annotation.Target({
                        java.lang.annotation.ElementType.METHOD,
                        java.lang.annotation.ElementType.RECORD_COMPONENT
                    })
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @jakarta.ws.rs.HttpMethod("PROBE")
                    public @interface PROBE {}
                """,
                "api/Modern.java": """
                    package api;
                    import designators.PROBE;
                    @jakarta.ws.rs.Path("/modern")
                    public record Modern(
                        @jakarta.ws.rs.GET @jakarta.ws.rs.Path("/item") String item,
                        @PROBE @jakarta.ws.rs.Path("/probe") String probe
                    ) {
                        public Modern(
                            @jakarta.ws.rs.HeaderParam("Item") String item,
                            @jakarta.ws.rs.HeaderParam("Probe") String probe
                        ) {
                            this.item = item;
                            this.probe = probe;
                        }
                    }
                """,
                "api/Legacy.java": """
                    package api;
                    @javax.ws.rs.Path("/legacy")
                    public record Legacy(
                        @javax.ws.rs.POST @javax.ws.rs.Path("/item") String item
                    ) {
                        public Legacy(@javax.ws.rs.HeaderParam("Item") String item) {
                            this.item = item;
                        }
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(
            self.endpoint_keys(jax_endpoints),
            {
                ("GET", "/modern/item", "Modern.item"),
                ("PROBE", "/modern/probe", "Modern.probe"),
                ("POST", "/legacy/item", "Legacy.item"),
            },
        )
        self.assertEqual(len(jax_endpoints), 3)
        self.assertTrue(
            all(endpoint["uri_params"] == "" for endpoint in jax_endpoints)
        )

    def test_03_rec_acc_002_targets_and_explicit_accessors_fail_closed(self):
        spring_endpoints = self.analyze_module(
            "record-component-spring-negative",
            {
                "annotations/ComponentRead.java": """
                    package annotations;
                    @java.lang.annotation.Target(
                        java.lang.annotation.ElementType.RECORD_COMPONENT
                    )
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @org.springframework.web.bind.annotation.RequestMapping(
                        path = "/component", method =
                        org.springframework.web.bind.annotation.RequestMethod.GET
                    )
                    public @interface ComponentRead {}
                """,
                "annotations/TypeUseRead.java": """
                    package annotations;
                    @java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE_USE)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @org.springframework.web.bind.annotation.RequestMapping(
                        path = "/type-use", method =
                        org.springframework.web.bind.annotation.RequestMethod.GET
                    )
                    public @interface TypeUseRead {}
                """,
                "annotations/MethodRead.java": """
                    package annotations;
                    import static java.lang.annotation.ElementType.METHOD;
                    @java.lang.annotation.Target(METHOD)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @org.springframework.web.bind.annotation.RequestMapping(
                        path = "/method", method =
                        org.springframework.web.bind.annotation.RequestMethod.GET
                    )
                    public @interface MethodRead {}
                """,
                "one/Read.java": """
                    package one;
                    @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @org.springframework.web.bind.annotation.RequestMapping("/one")
                    public @interface Read {}
                """,
                "two/Read.java": """
                    package two;
                    @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @org.springframework.web.bind.annotation.RequestMapping("/two")
                    public @interface Read {}
                """,
                "shadow/GetMapping.java": """
                    package shadow;
                    @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
                    public @interface GetMapping {}
                """,
                "api/NegativeController.java": """
                    package api;
                    import annotations.*;
                    import one.*;
                    import two.*;
                    @org.springframework.web.bind.annotation.RestController
                    @org.springframework.web.bind.annotation.RequestMapping("/negative")
                    public record NegativeController(
                        @ComponentRead String componentOnly,
                        @TypeUseRead String typeUse,
                        @shadow.GetMapping String fake,
                        @Read String ambiguous,
                        @MethodRead String explicit,
                        @MethodRead String routed,
                        @MethodRead String receiver,
                        @MethodRead String overload
                    ) {
                        public String explicit() { return explicit; }

                        @org.springframework.web.bind.annotation.PostMapping("/explicit-route")
                        public String routed() { return routed; }

                        public String receiver(NegativeController this) {
                            return receiver;
                        }

                        public String overload(int ignored) { return overload; }
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(spring_endpoints),
            {
                (
                    "POST",
                    "/negative/explicit-route",
                    "NegativeController.routed",
                ),
                ("GET", "/negative/method", "NegativeController.overload"),
            },
        )
        self.assertEqual(len(spring_endpoints), 2)

        jax_endpoints = self.analyze_module(
            "record-component-jax-negative",
            {
                "designators/ComponentProbe.java": """
                    package designators;
                    @java.lang.annotation.Target(
                        java.lang.annotation.ElementType.RECORD_COMPONENT
                    )
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @jakarta.ws.rs.HttpMethod("COMPONENT")
                    public @interface ComponentProbe {}
                """,
                "designators/TypeUseProbe.java": """
                    package designators;
                    @java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE_USE)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @jakarta.ws.rs.HttpMethod("TYPEUSE")
                    public @interface TypeUseProbe {}
                """,
                "designators/MethodProbe.java": """
                    package designators;
                    @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @jakarta.ws.rs.HttpMethod("PROBE")
                    public @interface MethodProbe {}
                """,
                "shadow/GET.java": """
                    package shadow;
                    @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
                    public @interface GET {}
                """,
                "api/NegativeResource.java": """
                    package api;
                    import designators.*;
                    @jakarta.ws.rs.Path("/negative")
                    public record NegativeResource(
                        @ComponentProbe String componentOnly,
                        @TypeUseProbe String typeUse,
                        @shadow.GET String fake,
                        @MethodProbe String explicit,
                        @jakarta.ws.rs.GET String routed,
                        @MethodProbe String receiver,
                        @MethodProbe String overload
                    ) {
                        public NegativeResource(
                            @jakarta.ws.rs.HeaderParam("A") String componentOnly,
                            @jakarta.ws.rs.HeaderParam("B") String typeUse,
                            @jakarta.ws.rs.HeaderParam("C") String fake,
                            @jakarta.ws.rs.HeaderParam("D") String explicit,
                            @jakarta.ws.rs.HeaderParam("E") String routed,
                            @jakarta.ws.rs.HeaderParam("F") String receiver,
                            @jakarta.ws.rs.HeaderParam("G") String overload
                        ) {
                            this.componentOnly = componentOnly;
                            this.typeUse = typeUse;
                            this.fake = fake;
                            this.explicit = explicit;
                            this.routed = routed;
                            this.receiver = receiver;
                            this.overload = overload;
                        }

                        public String explicit() { return explicit; }

                        @jakarta.ws.rs.POST @jakarta.ws.rs.Path("/explicit-route")
                        public String routed() { return routed; }

                        public String receiver(NegativeResource this) {
                            return receiver;
                        }

                        public String overload(int ignored) { return overload; }
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(
            self.endpoint_keys(jax_endpoints),
            {
                ("POST", "/negative/explicit-route", "NegativeResource.routed"),
                ("PROBE", "/negative", "NegativeResource.overload"),
            },
        )
        self.assertEqual(len(jax_endpoints), 2)

    def test_03_jax_http_001_workspace_constant_forms_emit_custom_methods(self):
        endpoints = self.analyze_module(
            "workspace-http-methods",
            {
                "tokens/Verbs.java": """
                    package tokens;
                    public final class Verbs {
                        public static final String TYPE = "REPORT";
                        public static final String QUALIFIED = "COPY";
                        public static final String EXACT = "PURGE";
                        public static final String WILD = "LINK";
                        public static final String PREFIX = "MER";
                        public static final String SUFFIX = "GE";
                        public static final String CORE_CHAIN =
                            jakarta.ws.rs.HttpMethod.PATCH + "X";
                    }
                """,
                "designators/LocalVerbs.java": """
                    package designators;
                    public final class LocalVerbs {
                        public static final String SAME = "SEARCH";
                    }
                """,
                "designators/REPORT.java": """
                    package designators;
                    import tokens.Verbs;
                    @jakarta.ws.rs.HttpMethod(Verbs.TYPE)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface REPORT {}
                """,
                "designators/COPY.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(tokens.Verbs.QUALIFIED)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface COPY {}
                """,
                "designators/PURGE.java": """
                    package designators;
                    import static tokens.Verbs.EXACT;
                    @jakarta.ws.rs.HttpMethod(EXACT)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface PURGE {}
                """,
                "designators/LINK.java": """
                    package designators;
                    import static tokens.Verbs.*;
                    @jakarta.ws.rs.HttpMethod(WILD)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface LINK {}
                """,
                "designators/MERGE.java": """
                    package designators;
                    import tokens.Verbs;
                    @jakarta.ws.rs.HttpMethod(Verbs.PREFIX + Verbs.SUFFIX)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface MERGE {}
                """,
                "designators/SEARCH.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(LocalVerbs.SAME)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface SEARCH {}
                """,
                "designators/CORE_FQ.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(javax.ws.rs.HttpMethod.GET)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface CORE_FQ {}
                """,
                "designators/CORE_TYPE.java": """
                    package designators;
                    import javax.ws.rs.HttpMethod;
                    @jakarta.ws.rs.HttpMethod(HttpMethod.POST)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface CORE_TYPE {}
                """,
                "designators/CORE_CONCAT.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(
                        jakarta.ws.rs.HttpMethod.GET + "X"
                    )
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface CORE_CONCAT {}
                """,
                "designators/CORE_PAREN.java": """
                    package designators;
                    import javax.ws.rs.HttpMethod;
                    @jakarta.ws.rs.HttpMethod((HttpMethod.HEAD))
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface CORE_PAREN {}
                """,
                "designators/CORE_CHAIN.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(tokens.Verbs.CORE_CHAIN)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface CORE_CHAIN {}
                """,
                "api/Resource.java": """
                    package api;
                    import designators.*;
                    @jakarta.ws.rs.Path("/custom")
                    public class Resource {
                        @REPORT public void report() {}
                        @COPY public void copy() {}
                        @PURGE public void purge() {}
                        @LINK public void link() {}
                        @MERGE public void merge() {}
                        @SEARCH public void search() {}
                        @CORE_FQ public void coreFq() {}
                        @CORE_TYPE public void coreType() {}
                        @CORE_CONCAT public void coreConcat() {}
                        @CORE_PAREN public void coreParen() {}
                        @CORE_CHAIN public void coreChain() {}
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(len(endpoints), 11)
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("REPORT", "/custom", "Resource.report"),
                ("COPY", "/custom", "Resource.copy"),
                ("PURGE", "/custom", "Resource.purge"),
                ("LINK", "/custom", "Resource.link"),
                ("MERGE", "/custom", "Resource.merge"),
                ("SEARCH", "/custom", "Resource.search"),
                ("GET", "/custom", "Resource.coreFq"),
                ("POST", "/custom", "Resource.coreType"),
                ("GETX", "/custom", "Resource.coreConcat"),
                ("HEAD", "/custom", "Resource.coreParen"),
                ("PATCHX", "/custom", "Resource.coreChain"),
            },
        )

    def test_03_jax_http_002_invalid_workspace_tokens_fail_closed(self):
        endpoints = self.analyze_module(
            "invalid-workspace-http-methods",
            {
                "tokens/BadVerbs.java": """
                    package tokens;
                    public final class BadVerbs {
                        public static String MUTABLE = "MUTATE";
                        private static final String PRIVATE = "PRIVATE";
                        public static final String A = B;
                        public static final String B = A;
                    }
                """,
                "one/Verbs.java": """
                    package one;
                    public final class Verbs {
                        public static final String CLASH = "ONE";
                    }
                """,
                "two/Verbs.java": """
                    package two;
                    public final class Verbs {
                        public static final String CLASH = "TWO";
                    }
                """,
                "designators/MUTABLE.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(tokens.BadVerbs.MUTABLE)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface MUTABLE {}
                """,
                "designators/PRIVATE.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(tokens.BadVerbs.PRIVATE)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface PRIVATE {}
                """,
                "designators/CYCLE.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(tokens.BadVerbs.A)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface CYCLE {}
                """,
                "designators/AMBIGUOUS.java": """
                    package designators;
                    import static one.Verbs.*;
                    import static two.Verbs.*;
                    @jakarta.ws.rs.HttpMethod(CLASH)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface AMBIGUOUS {}
                """,
                "designators/INVALID.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod("BAD METHOD")
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface INVALID {}
                """,
                "designators/OVERSIZED.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(
                        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
                        "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"
                    )
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface OVERSIZED {}
                """,
                "designators/UNRESOLVED.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(MISSING)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface UNRESOLVED {}
                """,
                "api/Resource.java": """
                    package api;
                    import designators.*;
                    @jakarta.ws.rs.Path("/invalid")
                    public class Resource {
                        @MUTABLE public void mutable() {}
                        @PRIVATE public void hidden() {}
                        @CYCLE public void cycle() {}
                        @AMBIGUOUS public void ambiguous() {}
                        @INVALID public void invalid() {}
                        @OVERSIZED public void oversized() {}
                        @UNRESOLVED public void unresolved() {}
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(endpoints, [])
        self.assert_jax_diagnostic_was_written()
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        for owner in (
            "MUTABLE",
            "PRIVATE",
            "CYCLE",
            "AMBIGUOUS",
            "INVALID",
            "OVERSIZED",
            "UNRESOLVED",
        ):
            self.assertIn(owner, diagnostic)

    def test_03_jax_http_002_static_import_precedence_and_ambiguity(self):
        endpoints = self.analyze_module(
            "http-method-precedence",
            {
                "valid/Verbs.java": """
                    package valid;
                    public final class Verbs {
                        public static final String GET = "GET";
                        public static final String POST = "FAKE-POST";
                    }
                """,
                "invalid/Verbs.java": """
                    package invalid;
                    public final class Verbs {
                        public static String GET = "GET";
                    }
                """,
                "designators/EXACT_SOURCE.java": """
                    package designators;
                    import static valid.Verbs.GET;
                    import static jakarta.ws.rs.HttpMethod.*;
                    @jakarta.ws.rs.HttpMethod(GET)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface EXACT_SOURCE {}
                """,
                "designators/EXACT_CORE.java": """
                    package designators;
                    import static valid.Verbs.*;
                    import static jakarta.ws.rs.HttpMethod.POST;
                    @jakarta.ws.rs.HttpMethod(POST)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface EXACT_CORE {}
                """,
                "designators/INVALID_EXACT.java": """
                    package designators;
                    import static invalid.Verbs.GET;
                    import static jakarta.ws.rs.HttpMethod.*;
                    @jakarta.ws.rs.HttpMethod(GET)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface INVALID_EXACT {}
                """,
                "designators/AMBIGUOUS_SOURCE.java": """
                    package designators;
                    import static invalid.Verbs.*;
                    import static jakarta.ws.rs.HttpMethod.*;
                    @jakarta.ws.rs.HttpMethod(GET)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface AMBIGUOUS_SOURCE {}
                """,
                "designators/AMBIGUOUS_CORE.java": """
                    package designators;
                    import static jakarta.ws.rs.HttpMethod.*;
                    import static javax.ws.rs.HttpMethod.*;
                    @jakarta.ws.rs.HttpMethod(GET)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface AMBIGUOUS_CORE {}
                """,
                "designators/LOCAL_MUTABLE.java": """
                    package designators;
                    class LocalTokens {
                        static String METHOD = "LOCAL";
                    }
                    @jakarta.ws.rs.HttpMethod(LocalTokens.METHOD)
                    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
                    public @interface LOCAL_MUTABLE {}
                """,
                "api/Resource.java": """
                    package api;
                    import designators.*;
                    @jakarta.ws.rs.Path("/precedence")
                    public class Resource {
                        @EXACT_SOURCE public void exactSource() {}
                        @EXACT_CORE public void exactCore() {}
                        @INVALID_EXACT public void invalidExact() {}
                        @AMBIGUOUS_SOURCE public void ambiguousSource() {}
                        @AMBIGUOUS_CORE public void ambiguousCore() {}
                        @LOCAL_MUTABLE public void localMutable() {}
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/precedence", "Resource.exactSource"),
                ("POST", "/precedence", "Resource.exactCore"),
            },
        )
        self.assertEqual(len(endpoints), 2)
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        for owner in (
            "INVALID_EXACT",
            "AMBIGUOUS_SOURCE",
            "AMBIGUOUS_CORE",
            "LOCAL_MUTABLE",
        ):
            self.assertIn(owner, diagnostic)
