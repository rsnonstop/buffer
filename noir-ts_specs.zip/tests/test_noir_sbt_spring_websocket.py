from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_spring_config  # noqa: E402
import noir_sbt_spring_websocket  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class SpringWebSocketTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runtime = noir_sbt.build_jax_runtime()

    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze(self, files):
        source_by_file = {}
        for relative_name, source in files.items():
            target = self.root / relative_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(source, encoding="utf8")
            if target.suffix == ".java":
                source_by_file[str(target)] = source.encode("utf8")
        workspace = noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=self.runtime,
            include_jax=False,
        )
        configuration = noir_sbt_spring_config.build_spring_configuration(
            workspace, self.root, noir_sbt
        )
        raw = noir_sbt_spring_websocket.analyze_spring_websocket(
            workspace, noir_sbt, configuration
        )
        return noir_sbt_spring_config.apply_spring_configuration(
            raw, configuration, noir_sbt
        )

    @staticmethod
    def keys(endpoints):
        return {
            (
                endpoint["protocol"],
                endpoint["surface"],
                endpoint["method"],
                endpoint["uri"],
                endpoint["SFunction"],
            )
            for endpoint in endpoints
        }

    def test_03_spr_ws_001_handshakes_and_message_destinations(self):
        endpoints = self.analyze(
            {
                "app/src/main/resources/application.properties": (
                    "server.servlet.context-path=/portal\n"
                    "socket.root=/socket\n"
                ),
                "app/src/main/java/api/WebSocketConfig.java": """
                    package api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.*;
                    public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
                        static final String CHAT = "${socket.root}/chat/{roomId}";
                        public void registerStompEndpoints(
                            /* docs */ StompEndpointRegistry registry
                        ) {
                            registry.addEndpoint(CHAT /* docs */).setAllowedOriginPatterns("*");
                            registry.addEndpoint("/portfolio").withSockJS();
                        }
                        public void configureMessageBroker(MessageBrokerRegistry registry) {
                            registry.setApplicationDestinationPrefixes("/app", "/commands");
                        }
                    }
                """,
                "app/src/main/java/api/ChatController.java": """
                    package api;
                    import org.springframework.messaging.handler.annotation.*;
                    import org.springframework.stereotype.Controller;
                    @Controller
                    @MessageMapping("/chat")
                    public class ChatController {
                        static final String SEND = "/send";
                        @MessageMapping({SEND + "/{roomId}", "/broadcast"})
                        public void send(String payload) {}
                        @SubscribeMapping(path = "/presence/{roomId}")
                        public String presence() { return ""; }

                        @MessageMapping
                        public static class MarkerLayer {
                            @MessageMapping("/marker")
                            public void marker() {}
                        }
                    }
                """,
            }
        )

        self.assertEqual(
            self.keys(endpoints),
            {
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/portal/socket/chat/{roomId}",
                    "WebSocketConfig.registerStompEndpoints",
                ),
                (
                    "ws",
                    "message",
                    "SEND",
                    "/app/chat/send/{roomId}",
                    "ChatController.send",
                ),
                (
                    "ws",
                    "message",
                    "SEND",
                    "/app/chat/broadcast",
                    "ChatController.send",
                ),
                (
                    "ws",
                    "message",
                    "SUBSCRIBE",
                    "/app/chat/presence/{roomId}",
                    "ChatController.presence",
                ),
                (
                    "ws",
                    "message",
                    "SEND",
                    "/app/chat/marker",
                    "ChatController.MarkerLayer.marker",
                ),
                (
                    "ws",
                    "message",
                    "SEND",
                    "/commands/chat/send/{roomId}",
                    "ChatController.send",
                ),
                (
                    "ws",
                    "message",
                    "SEND",
                    "/commands/chat/broadcast",
                    "ChatController.send",
                ),
                (
                    "ws",
                    "message",
                    "SUBSCRIBE",
                    "/commands/chat/presence/{roomId}",
                    "ChatController.presence",
                ),
                (
                    "ws",
                    "message",
                    "SEND",
                    "/commands/chat/marker",
                    "ChatController.MarkerLayer.marker",
                ),
            },
        )
        rows = [
            noir_sbt.format_endpoint(endpoint, "app", self.root)
            for endpoint in endpoints
        ]
        self.assertEqual(
            {row["interface_type"] for row in rows},
            {"ws GET", "ws SEND", "ws SUBSCRIBE"},
        )

    def test_03_spr_ws_002_project_prefixes_are_isolated(self):
        endpoints = self.analyze(
            {
                "one/src/main/resources/application.properties": (
                    "server.servlet.context-path=/one\nleaf=one\n"
                ),
                "one/src/main/java/api/Config.java": """
                    package api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.*;
                    public class Config implements WebSocketMessageBrokerConfigurer {
                        public void registerStompEndpoints(StompEndpointRegistry r) {
                            r.addEndpoint("/socket/${leaf}");
                        }
                        public void configureMessageBroker(MessageBrokerRegistry r) {
                            r.setApplicationDestinationPrefixes("/one-app");
                        }
                    }
                """,
                "one/src/main/java/api/ControllerOne.java": """
                    package api;
                    @org.springframework.stereotype.Controller
                    public class ControllerOne {
                        @org.springframework.messaging.handler.annotation.MessageMapping("/go/${leaf}")
                        public void go() {}
                    }
                """,
                "two/src/main/resources/application.properties": (
                    "server.servlet.context-path=/two\nleaf=two\n"
                ),
                "two/src/main/java/api/ControllerTwo.java": """
                    package api;
                    @org.springframework.web.bind.annotation.RestController
                    public class ControllerTwo {
                        @org.springframework.messaging.handler.annotation.SubscribeMapping("/watch/${leaf}")
                        public void watch() {}
                    }
                """,
            }
        )
        self.assertEqual(
            self.keys(endpoints),
            {
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/one/socket/one",
                    "Config.registerStompEndpoints",
                ),
                (
                    "ws",
                    "message",
                    "SEND",
                    "/one-app/go/one",
                    "ControllerOne.go",
                ),
                (
                    "ws",
                    "message",
                    "SUBSCRIBE",
                    "/watch/two",
                    "ControllerTwo.watch",
                ),
            },
        )

    def test_03_spr_ws_003_fake_dynamic_and_nested_forms_fail_closed(self):
        endpoints = self.analyze(
            {
                "app/src/main/java/fake/WebSocketMessageBrokerConfigurer.java": """
                    package fake;
                    public interface WebSocketMessageBrokerConfigurer {}
                """,
                "app/src/main/java/fake/MessageMapping.java": """
                    package fake;
                    public @interface MessageMapping { String value(); }
                """,
                "app/src/main/java/api/Bad.java": """
                    package api;
                    import fake.WebSocketMessageBrokerConfigurer;
                    public class Bad implements WebSocketMessageBrokerConfigurer {
                        @fake.MessageMapping("/fake") public void fake() {}
                    }
                """,
                "app/src/main/java/api/Config.java": """
                    package api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.*;
                    public class Config implements WebSocketMessageBrokerConfigurer {
                        public void registerStompEndpoints(StompEndpointRegistry registry) {
                            if (enabled()) registry.addEndpoint("/nested");
                            registry.addEndpoint(dynamic());
                            registry.addEndpoint("/valid");
                        }
                        public void configureMessageBroker(MessageBrokerRegistry registry) {
                            registry.setApplicationDestinationPrefixes(dynamic());
                        }
                        boolean enabled() { return true; }
                        String dynamic() { return "/dynamic"; }
                    }
                """,
                "app/src/main/java/api/NotAController.java": """
                    package api;
                    public class NotAController {
                        @org.springframework.messaging.handler.annotation.MessageMapping("/hidden")
                        public void hidden() {}
                    }
                """,
                "app/src/main/java/api/Good.java": """
                    package api;
                    @org.springframework.stereotype.Controller
                    public class Good {
                        @org.springframework.messaging.handler.annotation.SubscribeMapping("/visible")
                        public void visible() {}
                    }
                """,
            }
        )
        self.assertEqual(
            self.keys(endpoints),
            {
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/valid",
                    "Config.registerStompEndpoints",
                ),
            },
        )

    def test_raw_websocket_configurer_fanout_and_allowed_origin_chain(self):
        endpoints = self.analyze(
            {
                "app/src/main/resources/application.properties": (
                    "server.servlet.context-path=/portal\n"
                ),
                "app/src/main/java/api/WebSocketConfiguration.java": """
                    package api;
                    import org.springframework.web.socket.WebSocketHandler;
                    import org.springframework.web.socket.config.annotation.*;
                    public class WebSocketConfiguration implements WebSocketConfigurer {
                        private static final String WS_API_MAPPING = "/api/ws/**";
                        private final WebSocketHandler wsHandler;
                        WebSocketConfiguration(WebSocketHandler wsHandler) {
                            this.wsHandler = wsHandler;
                        }
                        @Override
                        public void registerWebSocketHandlers(
                            WebSocketHandlerRegistry registry
                        ) {
                            if (!(wsHandler instanceof WebSocketHandler)) {
                                throw new IllegalStateException();
                            }
                            registry.addHandler(
                                wsHandler, WS_API_MAPPING, "/api/socket"
                            ).setAllowedOriginPatterns("*").setAllowedOrigins("https://example.com");
                        }
                    }
                """,
            }
        )

        self.assertEqual(
            self.keys(endpoints),
            {
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/portal/api/ws/**",
                    "WebSocketConfiguration.registerWebSocketHandlers",
                ),
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/portal/api/socket",
                    "WebSocketConfiguration.registerWebSocketHandlers",
                ),
            },
        )

    def test_raw_websocket_invalid_registrations_preserve_valid_siblings(self):
        endpoints = self.analyze(
            {
                "app/src/main/java/api/Config.java": """
                    package api;
                    import org.springframework.web.socket.WebSocketHandler;
                    import org.springframework.web.socket.config.annotation.*;
                    public class Config implements WebSocketConfigurer {
                        private final WebSocketHandler handler = null;
                        private final Object unknownHandler = null;
                        public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
                            registry.addHandler(handler, "/valid");
                            registry.addHandler(this.handler, "/explicit");

                            WebSocketHandlerRegistry alias = registry;
                            alias.addHandler(handler, "/alias");
                            if (true) registry.addHandler(handler, "/nested");
                            registry.addHandler(handler, dynamic());
                            registry.addHandler(handler, "/all-or", dynamic());
                            registry.addHandler(unknownHandler, "/unknown-handler");
                            registry.addHandler(factory(), "/factory-handler");
                            registry.addHandler(handler, "/interceptors").addInterceptors();
                            registry.addHandler(handler, "/handshake").setHandshakeHandler(null);
                            registry.addHandler(handler, "/sockjs").withSockJS();
                            registry.addHandler(handler, "/chained-handler")
                                    .addHandler(handler, "/second-handler");
                        }
                        String dynamic() { return "/dynamic"; }
                        WebSocketHandler factory() { return handler; }
                    }
                """,
            }
        )

        self.assertEqual(
            self.keys(endpoints),
            {
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/valid",
                    "Config.registerWebSocketHandlers",
                ),
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/explicit",
                    "Config.registerWebSocketHandlers",
                ),
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/handshake",
                    "Config.registerWebSocketHandlers",
                ),
                (
                    "ws",
                    "websocket-handshake",
                    "GET",
                    "/interceptors",
                    "Config.registerWebSocketHandlers",
                ),
            },
        )

    def test_raw_websocket_provenance_signature_and_mutation_fail_closed(self):
        endpoints = self.analyze(
            {
                "app/src/main/java/fake/WebSocketConfigurer.java": """
                    package fake;
                    public interface WebSocketConfigurer {}
                """,
                "app/src/main/java/fake/WebSocketHandlerRegistry.java": """
                    package fake;
                    public class WebSocketHandlerRegistry {
                        public void addHandler(WebSocketHandler handler, String... paths) {}
                    }
                """,
                "app/src/main/java/fake/WebSocketHandler.java": """
                    package fake;
                    public interface WebSocketHandler
                        extends org.springframework.web.socket.WebSocketHandler {}
                """,
                "app/src/main/java/api/FakeConfigurer.java": """
                    package api;
                    import fake.*;
                    public class FakeConfigurer implements WebSocketConfigurer {
                        private final WebSocketHandler handler = null;
                        public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
                            registry.addHandler(handler, "/fake-configurer");
                        }
                    }
                """,
                "app/src/main/java/api/FakeHandler.java": """
                    package api;
                    import fake.WebSocketHandler;
                    import org.springframework.web.socket.config.annotation.*;
                    public class FakeHandler implements WebSocketConfigurer {
                        private final WebSocketHandler handler = null;
                        public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
                            registry.addHandler(handler, "/fake-handler");
                        }
                    }
                """,
                "app/src/main/java/api/NotConfigurer.java": """
                    package api;
                    import org.springframework.web.socket.WebSocketHandler;
                    import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
                    public class NotConfigurer {
                        private final WebSocketHandler handler = null;
                        public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
                            registry.addHandler(handler, "/not-configurer");
                        }
                    }
                """,
                "app/src/main/java/api/Mutated.java": """
                    package api;
                    import org.springframework.web.socket.WebSocketHandler;
                    import org.springframework.web.socket.config.annotation.*;
                    public class Mutated implements WebSocketConfigurer {
                        private final WebSocketHandler handler = null;
                        public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
                            registry = registry;
                            registry.addHandler(handler, "/mutated");
                        }
                    }
                """,
                "app/src/main/java/api/WrongSignature.java": """
                    package api;
                    import org.springframework.web.socket.WebSocketHandler;
                    import org.springframework.web.socket.config.annotation.*;
                    abstract class ValidBase implements WebSocketConfigurer {
                        public void registerWebSocketHandlers(
                            WebSocketHandlerRegistry registry
                        ) {}
                    }
                    public class WrongSignature extends ValidBase
                            implements WebSocketConfigurer {
                        private static final WebSocketHandler handler = null;
                        public static void registerWebSocketHandlers(
                            WebSocketHandlerRegistry registry, boolean ignored
                        ) {
                            registry.addHandler(handler, "/wrong-signature");
                        }
                    }
                """,
            }
        )

        self.assertEqual(endpoints, [])

    def test_invalid_application_prefix_suppresses_project_message_identity(self):
        endpoints = self.analyze(
            {
                "multiple/src/main/java/api/Config.java": """
                    package api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
                    public class Config implements WebSocketMessageBrokerConfigurer {
                        public void configureMessageBroker(MessageBrokerRegistry registry) {
                            registry.setApplicationDestinationPrefixes("/first");
                            registry.setApplicationDestinationPrefixes("/last");
                        }
                    }
                """,
                "multiple/src/main/java/api/Good.java": """
                    package api;
                    @org.springframework.stereotype.Controller
                    public class Good {
                        @org.springframework.messaging.handler.annotation.SubscribeMapping("/visible")
                        public void visible() {}
                    }
                """,
                "chained/src/main/java/api/ChainedConfig.java": """
                    package api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
                    public class ChainedConfig implements WebSocketMessageBrokerConfigurer {
                        public void configureMessageBroker(MessageBrokerRegistry registry) {
                            registry.setApplicationDestinationPrefixes("/first")
                                    .setApplicationDestinationPrefixes("/last");
                        }
                    }
                """,
                "chained/src/main/java/api/ChainedController.java": """
                    package api;
                    @org.springframework.stereotype.Controller
                    public class ChainedController {
                        @org.springframework.messaging.handler.annotation.MessageMapping("/hidden")
                        public void hidden() {}
                    }
                """,
            }
        )
        self.assertEqual(endpoints, [])

    def test_nested_application_prefix_suppresses_only_its_project_messages(self):
        endpoints = self.analyze(
            {
                "blocked/src/main/java/blocked/api/BlockedConfig.java": """
                    package blocked.api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
                    public class BlockedConfig implements WebSocketMessageBrokerConfigurer {
                        public void configureMessageBroker(MessageBrokerRegistry registry) {
                            if (true) {
                                registry.setApplicationDestinationPrefixes("/blocked");
                            }
                        }
                    }
                """,
                "blocked/src/main/java/blocked/api/BlockedController.java": """
                    package blocked.api;
                    @org.springframework.stereotype.Controller
                    public class BlockedController {
                        @org.springframework.messaging.handler.annotation.MessageMapping("/hidden")
                        public void hidden() {}
                    }
                """,
                "valid/src/main/java/valid/api/ValidConfig.java": """
                    package valid.api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
                    public class ValidConfig implements WebSocketMessageBrokerConfigurer {
                        public void configureMessageBroker(MessageBrokerRegistry registry) {
                            registry.setApplicationDestinationPrefixes("/good");
                        }
                    }
                """,
                "valid/src/main/java/valid/api/GoodController.java": """
                    package valid.api;
                    @org.springframework.stereotype.Controller
                    public class GoodController {
                        @org.springframework.messaging.handler.annotation.MessageMapping("/visible")
                        public void visible() {}
                    }
                """,
            }
        )

        self.assertEqual(
            self.keys(endpoints),
            {
                (
                    "ws",
                    "message",
                    "SEND",
                    "/good/visible",
                    "GoodController.visible",
                )
            },
        )

    def test_mutated_application_registry_suppresses_project_messages(self):
        endpoints = self.analyze(
            {
                "app/src/main/java/api/Config.java": """
                    package api;
                    import org.springframework.messaging.simp.config.MessageBrokerRegistry;
                    import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
                    public class Config implements WebSocketMessageBrokerConfigurer {
                        public void configureMessageBroker(MessageBrokerRegistry registry) {
                            registry = registry;
                            registry.setApplicationDestinationPrefixes("/app");
                        }
                    }
                """,
                "app/src/main/java/api/Controller.java": """
                    package api;
                    @org.springframework.stereotype.Controller
                    public class Controller {
                        @org.springframework.messaging.handler.annotation.MessageMapping("/hidden")
                        public void hidden() {}
                    }
                """,
            }
        )

        self.assertEqual(endpoints, [])


if __name__ == "__main__":
    unittest.main()
