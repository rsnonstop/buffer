from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_spring_clients  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class SpringClientTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def workspace(self, directory_name, files):
        module_root = self.root / directory_name
        source_by_file = {}
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
            if source_file.suffix == ".java":
                source_by_file[str(source_file)] = source.encode("utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        workspace = noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=noir_sbt.build_jax_runtime(),
            include_jax=False,
        )
        return module_root, workspace

    def analyze(self, directory_name, files):
        _module_root, workspace = self.workspace(directory_name, files)
        return noir_sbt_spring_clients.analyze_spring_clients(
            workspace, noir_sbt
        )

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (
                endpoint["method"],
                endpoint["uri"],
                endpoint["SFunction"],
                endpoint["uri_params"],
            )
            for endpoint in endpoints
        }

    def test_http_interface_type_method_paths_and_string_methods_fan_out(self):
        endpoints = self.analyze(
            "http-interface",
            {
                "shared/ClientPaths.java": """
                    package shared;
                    public final class ClientPaths {
                        public static final String API = "/api";
                        public static final String ITEMS = "/items";
                        public static final String ARCHIVE = "/archive";
                        public static final String CUSTOM = "PROPFIND";
                    }
                """,
                "api/CatalogClient.java": """
                    package api;
                    import org.springframework.web.service.annotation.*;
                    import shared.ClientPaths;
                    @HttpExchange(url = ClientPaths.API, method = "HEAD")
                    public interface CatalogClient {
                        @GetExchange(url = {ClientPaths.ITEMS, ClientPaths.ARCHIVE})
                        String find(String id);

                        @HttpExchange(
                            url = "/search",
                            method = {ClientPaths.CUSTOM, "DELETE"}
                        )
                        String search(
                            java.util.Map<String, java.util.List<Integer>> query
                        );

                        @PostExchange(value = "/create", url = "/create")
                        void create(String body);

                        @GetExchange("/private")
                        private String hidden() { return ""; }
                    }
                """,
            },
        )

        self.assertEqual(len(endpoints), 9)
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (method, f"/api{path}", "CatalogClient.find", "String id")
                for method in {"GET", "HEAD"}
                for path in {"/items", "/archive"}
            }
            | {
                (
                    method,
                    "/api/search",
                    "CatalogClient.search",
                    "java.util.Map<String, java.util.List<Integer>> query",
                )
                for method in {"HEAD", "DELETE", "PROPFIND"}
            }
            | {
                (
                    method,
                    "/api/create",
                    "CatalogClient.create",
                    "String body",
                )
                for method in {"HEAD", "POST"}
            },
        )
        self.assertTrue(
            all(
                endpoint["technology"] == "spring"
                and endpoint["protocol"] == "http"
                and endpoint["surface"] == "client"
                and endpoint["direction"] == "outbound"
                and endpoint["RouteSrcFile"] == endpoint["SrcFile"]
                and endpoint["HandlerSrcFile"] == endpoint["SrcFile"]
                for endpoint in endpoints
            )
        )
        formatted = noir_sbt.format_endpoint(
            endpoints[0], "module", self.root
        )
        self.assertTrue(formatted["interface_type"].startswith("http-client "))

    def test_all_fixed_http_exchange_annotations_are_genuine_client_routes(self):
        endpoints = self.analyze(
            "fixed-http-exchanges",
            {
                "api/FixedClient.java": """
                    package api;
                    import org.springframework.web.service.annotation.*;
                    @HttpExchange("/fixed")
                    public interface FixedClient {
                        @GetExchange(url = "/get") void get();
                        @PostExchange(url = "/post") void post();
                        @PutExchange(url = "/put") void put();
                        @DeleteExchange(url = "/delete") void delete();
                        @PatchExchange(url = "/patch") void patch();
                    }
                """,
            },
        )

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/fixed/get", "FixedClient.get", ""),
                ("POST", "/fixed/post", "FixedClient.post", ""),
                ("PUT", "/fixed/put", "FixedClient.put", ""),
                ("DELETE", "/fixed/delete", "FixedClient.delete", ""),
                ("PATCH", "/fixed/patch", "FixedClient.patch", ""),
            },
        )

    def test_nested_client_interfaces_compose_enclosing_type_mappings(self):
        endpoints = self.analyze(
            "nested-client-interfaces",
            {
                "api/HttpContracts.java": """
                    package api;
                    import org.springframework.web.service.annotation.HttpExchange;
                    import org.springframework.web.service.annotation.PostExchange;
                    @HttpExchange(url = "/http-root", method = "HEAD")
                    public interface HttpContracts {
                        @HttpExchange(url = "/inventory", method = "OPTIONS")
                        interface InventoryClient {
                            @PostExchange("/items")
                            void create(String body);
                        }
                    }
                """,
                "api/FeignContracts.java": """
                    package api;
                    import org.springframework.cloud.openfeign.FeignClient;
                    import org.springframework.web.bind.annotation.PostMapping;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @RequestMapping(
                        path = "/feign-root",
                        method = RequestMethod.HEAD
                    )
                    public interface FeignContracts {
                        @FeignClient(name = "orders")
                        @RequestMapping(
                            path = "/orders",
                            method = RequestMethod.PUT
                        )
                        interface OrdersClient {
                            @PostMapping("/items")
                            void create(String body);
                        }
                    }
                """,
            },
        )

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (
                    method,
                    "/http-root/inventory/items",
                    "HttpContracts.InventoryClient.create",
                    "String body",
                )
                for method in {"HEAD", "OPTIONS", "POST"}
            }
            | {
                (
                    method,
                    "/feign-root/orders/items",
                    "FeignContracts.OrdersClient.create",
                    "String body",
                )
                for method in {"HEAD", "PUT", "POST"}
            },
        )
        self.assertEqual(len(endpoints), 6)
        self.assertEqual({endpoint["surface"] for endpoint in endpoints}, {"client"})
        self.assertEqual(
            {endpoint["direction"] for endpoint in endpoints}, {"outbound"}
        )

    def test_feign_mvc_fanout_ignores_feign_container_path(self):
        endpoints = self.analyze(
            "feign",
            {
                "api/InventoryClient.java": """
                    package api;
                    import org.springframework.cloud.openfeign.FeignClient;
                    import org.springframework.web.bind.annotation.*;
                    @FeignClient(name = "inventory", path = "/ignored-feign")
                    @RequestMapping(
                        path = {"/api", "/v2"},
                        method = RequestMethod.HEAD
                    )
                    public interface InventoryClient {
                        @GetMapping(path = {"/items", "/archive"})
                        String find(long id);

                        @RequestMapping(
                            path = "/commands",
                            method = {RequestMethod.POST, RequestMethod.TRACE}
                        )
                        void command(String body);

                        String localHelper();
                    }
                """,
            },
        )

        self.assertEqual(len(endpoints), 14)
        self.assertFalse(any("ignored-feign" in endpoint["uri"] for endpoint in endpoints))
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (
                    method,
                    f"{base}{path}",
                    "InventoryClient.find",
                    "long id",
                )
                for method in {"GET", "HEAD"}
                for base in {"/api", "/v2"}
                for path in {"/items", "/archive"}
            }
            | {
                (
                    method,
                    f"{base}/commands",
                    "InventoryClient.command",
                    "String body",
                )
                for method in {"HEAD", "POST", "TRACE"}
                for base in {"/api", "/v2"}
            },
        )
        self.assertEqual({endpoint["surface"] for endpoint in endpoints}, {"client"})
        self.assertEqual({endpoint["direction"] for endpoint in endpoints}, {"outbound"})

    def test_fake_ambiguous_and_unresolved_client_mappings_fail_closed(self):
        endpoints = self.analyze(
            "client-negative",
            {
                "fake/GetExchange.java": """
                    package fake;
                    public @interface GetExchange { String url() default ""; }
                """,
                "fake/FeignClient.java": """
                    package fake;
                    public @interface FeignClient { String name() default ""; }
                """,
                "fake/GetMapping.java": """
                    package fake;
                    public @interface GetMapping { String value() default ""; }
                """,
                "api/AmbiguousHttp.java": """
                    package api;
                    import fake.*;
                    import org.springframework.web.service.annotation.*;
                    public interface AmbiguousHttp {
                        @GetExchange(url = "/ambiguous") String get();
                    }
                """,
                "api/BrokenHttp.java": """
                    package api;
                    import org.springframework.web.service.annotation.*;
                    public interface BrokenHttp {
                        @GetExchange(url = Missing.PATH) String path();
                        @HttpExchange(url = "/bad", method = Missing.METHOD)
                        String method();
                        @GetExchange(url = "/good-http") String good();
                    }
                """,
                "api/AmbiguousFeign.java": """
                    package api;
                    import fake.*;
                    import org.springframework.cloud.openfeign.*;
                    import org.springframework.web.bind.annotation.*;
                    @FeignClient(name = "ambiguous")
                    public interface AmbiguousFeign {
                        @GetMapping("/ambiguous") String get();
                    }
                """,
                "api/BrokenFeign.java": """
                    package api;
                    import org.springframework.cloud.openfeign.FeignClient;
                    import org.springframework.web.bind.annotation.*;
                    @FeignClient(name = "broken")
                    public interface BrokenFeign {
                        @GetMapping(Missing.PATH) String path();
                        @RequestMapping(path = "/bad", method = Missing.METHOD)
                        String method();
                        @PostMapping("/good-feign") String good();
                    }
                """,
            },
        )

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/good-http", "BrokenHttp.good", ""),
                ("POST", "/good-feign", "BrokenFeign.good", ""),
            },
        )
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("unresolved @url client path", diagnostic)
        self.assertIn("unresolved @HttpExchange method", diagnostic)
        self.assertIn("unresolved Spring path", diagnostic)
        self.assertIn("unresolved Spring method", diagnostic)

    def test_http_exchange_placeholder_expands_to_absolute_url(self):
        module_root = self.root / "configured-absolute-client"
        files = {
            "src/main/resources/application.properties": (
                "remote.base=https://remote.example\n"
            ),
            "src/main/java/api/RemoteClient.java": """
                package api;
                import org.springframework.web.service.annotation.HttpExchange;
                @HttpExchange("/api")
                public interface RemoteClient {
                    @HttpExchange(
                        url = "${remote.base}/items",
                        method = "GET"
                    )
                    void items();
                }
            """,
        }
        for relative_name, source in files.items():
            target = module_root / relative_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(source, encoding="utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")

        endpoints = noir_sbt.analyze_module(module_root, "spring")

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (
                    "GET",
                    "https://remote.example/items",
                    "RemoteClient.items",
                    "",
                )
            },
        )
        self.assertEqual(len(endpoints), 1)
        self.assertEqual(endpoints[0]["surface"], "client")
        self.assertEqual(endpoints[0]["direction"], "outbound")

    def test_host_integration_keeps_clients_unprefixed_and_runs_once(self):
        module_root = self.root / "host-integration"
        files = {
            "src/main/resources/application.properties": """
                server.servlet.context-path=/server-prefix
                remote.path=resolved-client
            """,
            "src/main/java/api/ServerController.java": """
                package api;
                import org.springframework.web.bind.annotation.GetMapping;
                public class ServerController {
                    @GetMapping("/server") public void server() {}
                }
            """,
            "src/main/java/api/HttpClient.java": """
                package api;
                import org.springframework.web.service.annotation.GetExchange;
                public interface HttpClient {
                    @GetExchange(url = "/${remote.path}") String remote();
                    @GetExchange(url = "https://remote.example//absolute")
                    String absolute();
                }
            """,
            "src/main/java/api/FeignApi.java": """
                package api;
                import org.springframework.cloud.openfeign.FeignClient;
                import org.springframework.web.bind.annotation.GetMapping;
                @FeignClient(name = "remote", path = "/ignored")
                public interface FeignApi {
                    @GetMapping("/feign") String remote();
                }
            """,
        }
        for relative_name, source in files.items():
            target = module_root / relative_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(source, encoding="utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")

        endpoints = noir_sbt.analyze_module(module_root, "spring")
        self.assertEqual(
            {
                (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
                for endpoint in endpoints
            },
            {
                ("GET", "/server-prefix/server", "ServerController.server"),
                ("GET", "/resolved-client", "HttpClient.remote"),
                (
                    "GET",
                    "https://remote.example/absolute",
                    "HttpClient.absolute",
                ),
                ("GET", "/feign", "FeignApi.remote"),
            },
        )
        self.assertEqual(len(endpoints), 4)
        clients = [
            endpoint for endpoint in endpoints if endpoint.get("surface") == "client"
        ]
        self.assertEqual(len(clients), 3)
        self.assertEqual({endpoint["direction"] for endpoint in clients}, {"outbound"})
        self.assertEqual(
            {
                noir_sbt.format_endpoint(endpoint, "module", module_root)[
                    "interface_type"
                ]
                for endpoint in clients
            },
            {"http-client GET"},
        )


if __name__ == "__main__":
    unittest.main()
