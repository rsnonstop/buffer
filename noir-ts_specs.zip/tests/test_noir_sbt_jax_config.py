from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_jax_config  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


class JaxDeploymentConfigurationUnitTests(unittest.TestCase):
    def test_project_roots_patterns_and_namespaced_xml_match_bounded_semantics(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertEqual(
                noir_sbt_jax_config.infer_jax_project_root(
                    root / "module/src/main/java/api/Api.java", root
                ),
                str(root / "module"),
            )
            self.assertEqual(
                noir_sbt_jax_config.infer_jax_project_root(
                    root / "module/src/main/resources/META-INF/web.xml", root
                ),
                str(root / "module"),
            )
            self.assertEqual(
                noir_sbt_jax_config.infer_jax_project_root(
                    root / "nonstandard/api/Api.java", root
                ),
                str(root),
            )

        self.assertEqual(
            {
                pattern: noir_sbt_jax_config.normalize_servlet_pattern(pattern)
                for pattern in ("/", "/*", "/api/*", "/api/", "api/*", "*.do")
            },
            {
                "/": "",
                "/*": "/",
                "/api/*": "/api",
                "/api/": "/api",
                "api/*": "/api",
                "*.do": "/*.do",
            },
        )

        mappings = noir_sbt_jax_config.parse_web_xml_jaxrs_mappings(
            """
            <web-app xmlns="https://jakarta.ee/xml/ns/jakartaee">
              <servlet>
                <servlet-name>rest</servlet-name>
                <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
                <init-param>
                  <param-name>jakarta.ws.rs.Application</param-name>
                  <param-value>sample.ApiApplication</param-value>
                </init-param>
                <init-param>
                  <param-name>ignored</param-name>
                  <param-value>other.IgnoredApplication</param-value>
                </init-param>
              </servlet>
              <servlet-mapping>
                <servlet-name>rest</servlet-name>
                <url-pattern>/one/*</url-pattern>
                <url-pattern>/two/</url-pattern>
              </servlet-mapping>
              <servlet-mapping>
                <servlet-name>missing</servlet-name>
                <url-pattern>/ignored/*</url-pattern>
              </servlet-mapping>
            </web-app>
            """
        )
        self.assertEqual(
            mappings,
            [
                {
                    "pattern": "/one/*",
                    "application_classes": [
                        "org.glassfish.jersey.servlet.ServletContainer",
                        "sample.ApiApplication",
                    ],
                    "jaxrs_servlet": True,
                },
                {
                    "pattern": "/two/",
                    "application_classes": [
                        "org.glassfish.jersey.servlet.ServletContainer",
                        "sample.ApiApplication",
                    ],
                    "jaxrs_servlet": True,
                },
            ],
        )


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class JaxDeploymentConfigurationIntegrationTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze(self, files):
        for relative_name, source in files.items():
            source_file = self.root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        with mock.patch("builtins.print"):
            return noir_sbt.analyze_module(self.root, "jaxrx")

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
            for endpoint in endpoints
        }

    def test_explicit_xml_overrides_java_for_direct_hierarchy_and_subresources(self):
        endpoints = self.analyze(
            {
                "module-a/src/main/java/app/RootApplication.java": """
                    package app;
                    import jakarta.ws.rs.ApplicationPath;
                    import jakarta.ws.rs.core.Application;
                    @ApplicationPath("/java-root")
                    public class RootApplication extends Application {}
                """,
                "module-a/src/main/java/app/admin/AdminApplication.java": """
                    package app.admin;
                    @jakarta.ws.rs.ApplicationPath("/java-admin")
                    public class AdminApplication
                        extends jakarta.ws.rs.core.Application {}
                """,
                "module-a/src/main/java/app/api/RootContract.java": """
                    package app.api;
                    import jakarta.ws.rs.GET;
                    import jakarta.ws.rs.Path;
                    public interface RootContract {
                        @GET @Path("/inherited") String inherited();
                    }
                """,
                "module-a/src/main/java/app/api/RootResource.java": """
                    package app.api;
                    import jakarta.ws.rs.GET;
                    import jakarta.ws.rs.Path;
                    @Path("/root")
                    public class RootResource implements RootContract {
                        @GET @Path("/direct") public String direct() { return ""; }
                        @Override public String inherited() { return ""; }
                        @Path("/child") public Leaf child() { return new Leaf(); }
                    }
                """,
                "module-a/src/main/java/app/api/Leaf.java": """
                    package app.api;
                    import jakarta.ws.rs.GET;
                    import jakarta.ws.rs.Path;
                    public class Leaf {
                        @GET @Path("/leaf") public String leaf() { return ""; }
                    }
                """,
                "module-a/src/main/java/app/admin/api/AdminResource.java": """
                    package app.admin.api;
                    @jakarta.ws.rs.Path("/admin")
                    public class AdminResource {
                        @jakarta.ws.rs.GET public String get() { return ""; }
                    }
                """,
                "module-a/src/main/webapp/WEB-INF/web.xml": """
                    <web-app xmlns="https://jakarta.ee/xml/ns/jakartaee">
                      <servlet>
                        <servlet-name>root</servlet-name>
                        <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
                        <init-param>
                          <param-name>jakarta.ws.rs.Application</param-name>
                          <param-value>app.RootApplication</param-value>
                        </init-param>
                      </servlet>
                      <servlet-mapping>
                        <servlet-name>root</servlet-name>
                        <url-pattern>/xml-root/*</url-pattern>
                      </servlet-mapping>
                    </web-app>
                """,
                "module-b/src/main/java/app/OtherApplication.java": """
                    package app;
                    @jakarta.ws.rs.ApplicationPath("/java-other")
                    public class OtherApplication
                        extends jakarta.ws.rs.core.Application {}
                """,
                "module-b/src/main/java/app/api/OtherResource.java": """
                    package app.api;
                    @jakarta.ws.rs.Path("/other")
                    public class OtherResource {
                        @jakarta.ws.rs.GET public String get() { return ""; }
                    }
                """,
                "module-b/src/main/webapp/WEB-INF/web.xml": """
                    <web-app>
                      <servlet>
                        <servlet-name>other</servlet-name>
                        <servlet-class>OtherApplication</servlet-class>
                      </servlet>
                      <servlet-mapping>
                        <servlet-name>other</servlet-name>
                        <url-pattern>/xml-other/</url-pattern>
                      </servlet-mapping>
                    </web-app>
                """,
            }
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/xml-root/root/direct", "RootResource.direct"),
                ("GET", "/xml-root/root/inherited", "RootResource.inherited"),
                ("GET", "/xml-root/root/child/leaf", "Leaf.leaf"),
                ("GET", "/java-admin/admin", "AdminResource.get"),
                ("GET", "/xml-other/other", "OtherResource.get"),
            },
        )

    def test_heuristic_application_and_unique_global_servlet_mappings(self):
        endpoints = self.analyze(
            {
                "heuristic/src/main/java/external/api/ExternalResource.java": """
                    package external.api;
                    @jakarta.ws.rs.Path("/items")
                    public class ExternalResource {
                        @jakarta.ws.rs.GET public void list() {}
                    }
                """,
                "heuristic/src/main/webapp/WEB-INF/web.xml": """
                    <web-app>
                      <servlet>
                        <servlet-name>external</servlet-name>
                        <servlet-class>external.RemoteApplication</servlet-class>
                      </servlet>
                      <servlet-mapping>
                        <servlet-name>external</servlet-name>
                        <url-pattern>external/*</url-pattern>
                      </servlet-mapping>
                    </web-app>
                """,
                "fallback/src/main/java/known/KnownApplication.java": """
                    package known;
                    @jakarta.ws.rs.ApplicationPath("/java")
                    public class KnownApplication
                        extends jakarta.ws.rs.core.Application {}
                """,
                "fallback/src/main/java/known/api/KnownResource.java": """
                    package known.api;
                    @jakarta.ws.rs.Path("/known")
                    public class KnownResource {
                        @jakarta.ws.rs.GET public void get() {}
                    }
                """,
                "fallback/src/main/java/outside/OutsideResource.java": """
                    package outside;
                    @jakarta.ws.rs.Path("/outside")
                    public class OutsideResource {
                        @jakarta.ws.rs.GET public void get() {}
                    }
                """,
                "fallback/src/main/webapp/WEB-INF/web.xml": """
                    <web-app>
                      <servlet>
                        <servlet-name>jersey</servlet-name>
                        <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
                      </servlet>
                      <servlet-mapping>
                        <servlet-name>jersey</servlet-name>
                        <url-pattern>/fallback/*</url-pattern>
                      </servlet-mapping>
                    </web-app>
                """,
            }
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/external/items", "ExternalResource.list"),
                ("GET", "/fallback/known", "KnownResource.get"),
                ("GET", "/outside", "OutsideResource.get"),
            },
        )

    def test_remote_application_fqn_does_not_steal_local_xml_package_heuristic(self):
        endpoints = self.analyze(
            {
                "module-a/src/main/java/shared/alpha/AlphaResource.java": """
                    package shared.alpha;
                    @jakarta.ws.rs.Path("/items")
                    public class AlphaResource {
                        @jakarta.ws.rs.GET public void list() {}
                    }
                """,
                "module-a/src/main/webapp/WEB-INF/web.xml": """
                    <web-app>
                      <servlet>
                        <servlet-name>remote</servlet-name>
                        <servlet-class>shared.RemoteApplication</servlet-class>
                      </servlet>
                      <servlet-mapping>
                        <servlet-name>remote</servlet-name>
                        <url-pattern>/xml-a/*</url-pattern>
                      </servlet-mapping>
                    </web-app>
                """,
                "module-b/src/main/java/shared/RemoteApplication.java": """
                    package shared;
                    @jakarta.ws.rs.ApplicationPath("/java-b")
                    public class RemoteApplication
                        extends jakarta.ws.rs.core.Application {}
                """,
                "module-b/src/main/java/shared/beta/BetaResource.java": """
                    package shared.beta;
                    @jakarta.ws.rs.Path("/orders")
                    public class BetaResource {
                        @jakarta.ws.rs.GET public void list() {}
                    }
                """,
            }
        )

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/xml-a/items", "AlphaResource.list"),
                ("GET", "/java-b/orders", "BetaResource.list"),
            },
        )

    def test_malformed_test_and_ambiguous_global_xml_fail_closed(self):
        endpoints = self.analyze(
            {
                "malformed/src/main/java/a/AApplication.java": """
                    package a;
                    @jakarta.ws.rs.ApplicationPath("/java-a")
                    public class AApplication extends jakarta.ws.rs.core.Application {}
                """,
                "malformed/src/main/java/a/Resource.java": """
                    package a;
                    @jakarta.ws.rs.Path("/resource")
                    public class Resource {
                        @jakarta.ws.rs.GET public void get() {}
                    }
                """,
                "malformed/src/main/webapp/WEB-INF/web.xml": "<web-app><broken>",
                "malformed/src/test/resources/web.xml": """
                    <web-app><servlet><servlet-name>ignored</servlet-name>
                    <servlet-class>a.AApplication</servlet-class></servlet>
                    <servlet-mapping><servlet-name>ignored</servlet-name>
                    <url-pattern>/ignored/*</url-pattern></servlet-mapping></web-app>
                """,
                "ambiguous/src/main/java/b/BApplication.java": """
                    package b;
                    @jakarta.ws.rs.ApplicationPath("/java-b")
                    public class BApplication extends jakarta.ws.rs.core.Application {}
                """,
                "ambiguous/src/main/java/b/Resource.java": """
                    package b;
                    @jakarta.ws.rs.Path("/resource")
                    public class Resource {
                        @jakarta.ws.rs.GET public void get() {}
                    }
                """,
                "ambiguous/src/main/webapp/WEB-INF/web.xml": """
                    <web-app>
                      <servlet><servlet-name>one</servlet-name>
                        <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
                      </servlet>
                      <servlet><servlet-name>two</servlet-name>
                        <servlet-class>org.jboss.resteasy.plugins.server.servlet.HttpServletDispatcher</servlet-class>
                      </servlet>
                      <servlet-mapping><servlet-name>one</servlet-name>
                        <url-pattern>/one/*</url-pattern></servlet-mapping>
                      <servlet-mapping><servlet-name>two</servlet-name>
                        <url-pattern>/two/*</url-pattern></servlet-mapping>
                    </web-app>
                """,
                "explicit-ambiguous/src/main/java/c/CApplication.java": """
                    package c;
                    @jakarta.ws.rs.ApplicationPath("/java-c")
                    public class CApplication extends jakarta.ws.rs.core.Application {}
                """,
                "explicit-ambiguous/src/main/java/c/Resource.java": """
                    package c;
                    @jakarta.ws.rs.Path("/resource")
                    public class Resource {
                        @jakarta.ws.rs.GET public void get() {}
                    }
                """,
                "explicit-ambiguous/src/main/webapp/WEB-INF/web.xml": """
                    <web-app>
                      <servlet><servlet-name>app</servlet-name>
                        <servlet-class>c.CApplication</servlet-class>
                      </servlet>
                      <servlet-mapping><servlet-name>app</servlet-name>
                        <url-pattern>/one/*</url-pattern>
                        <url-pattern>/two/*</url-pattern>
                      </servlet-mapping>
                    </web-app>
                """,
            }
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/java-a/resource", "Resource.get"),
                ("GET", "/java-b/resource", "Resource.get"),
            },
        )
        self.assertIn(
            "malformed web.xml",
            Path(noir_sbt.log_file).read_text(encoding="utf8"),
        )


if __name__ == "__main__":
    unittest.main()
