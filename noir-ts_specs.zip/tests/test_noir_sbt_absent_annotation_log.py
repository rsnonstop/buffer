from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_jax_recall  # noqa: E402
import noir_sbt_spring_clients  # noqa: E402
import noir_sbt_spring_config  # noqa: E402
import noir_sbt_spring_gateway  # noqa: E402
import noir_sbt_spring_recall  # noqa: E402
import noir_sbt_spring_websocket  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)

SPRING_MVC_TRIGGER_NAMES = (
    "RequestMapping",
    "GetMapping",
    "PostMapping",
    "PutMapping",
    "DeleteMapping",
    "PatchMapping",
)
SPRING_EXCHANGE_TRIGGER_NAMES = (
    "HttpExchange",
    "GetExchange",
    "PostExchange",
    "PutExchange",
    "DeleteExchange",
    "PatchExchange",
)
SPRING_MESSAGE_TRIGGER_NAMES = ("MessageMapping", "SubscribeMapping")
JAX_TRIGGER_NAMES = ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS")
EXPECTED_FINAL_TRIGGER_IDENTITIES = {
    "spring": {
        *(
            f"org.springframework.web.bind.annotation.{name}"
            for name in SPRING_MVC_TRIGGER_NAMES
        ),
        *(
            f"org.springframework.web.service.annotation.{name}"
            for name in SPRING_EXCHANGE_TRIGGER_NAMES
        ),
        *(
            f"org.springframework.messaging.handler.annotation.{name}"
            for name in SPRING_MESSAGE_TRIGGER_NAMES
        ),
    },
    "jaxrx": {
        *(
            f"{package}.{name}"
            for package in ("jakarta.ws.rs", "javax.ws.rs")
            for name in JAX_TRIGGER_NAMES
        ),
        "jakarta.websocket.server.ServerEndpoint",
        "javax.websocket.server.ServerEndpoint",
    },
}


class AbsentAnnotationTestCase(unittest.TestCase):
    def setUp(self):
        self._old_globals = (
            noir_sbt.log_file,
            noir_sbt.input_srcdir,
            noir_sbt.module_name,
            noir_sbt.diagnostic_log_buffer,
        )
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")
        noir_sbt.diagnostic_log_buffer = None

    def tearDown(self):
        (
            noir_sbt.log_file,
            noir_sbt.input_srcdir,
            noir_sbt.module_name,
            noir_sbt.diagnostic_log_buffer,
        ) = self._old_globals
        self._temporary_directory.cleanup()

    def workspace(self, name, files, *, include_jax=True):
        module_root = self.root / name
        sources = {}
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
            if source_file.suffix.lower() == ".java":
                sources[str(source_file)] = source.encode("utf8")
        workspace = noir_sbt.build_jax_workspace(
            sources,
            runtime=noir_sbt.build_jax_runtime(),
            include_jax=include_jax,
        )
        return module_root, workspace

    def inventory(self, name, files, selected=("spring", "jaxrx")):
        selected = set(selected)
        module_root, workspace = self.workspace(
            name, files, include_jax="jaxrx" in selected
        )
        inventory = noir_sbt.build_absent_trigger_inventory(
            workspace, module_root, selected
        )
        return module_root, workspace, inventory

    def analyzed(self, name, files, framework=None):
        module_root = self.root / name
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
        inventory = []
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        with mock.patch("builtins.print"):
            endpoints = noir_sbt.analyze_module(
                module_root,
                framework,
                absent_trigger_inventory=inventory,
            )
        formatted = [
            noir_sbt.format_endpoint(endpoint, module_root.name, module_root)
            for endpoint in endpoints
        ]
        return module_root, inventory, endpoints, noir_sbt.finalize_endpoint_rows(
            formatted
        )

    @staticmethod
    def framework_annotations(inventory, file_name, framework):
        file_record = next(
            record for record in inventory if record["file"] == file_name
        )
        framework_record = next(
            record
            for record in file_record["frameworks"]
            if record["framework"] == framework
        )
        return framework_record["annotations"]

    def method_target(self, module_root, relative_name, method_name):
        source_file = module_root / relative_name
        source = source_file.read_bytes()
        tree = noir_sbt.build_jax_runtime()["parser"].parse(source)
        matches = []

        def visit(node):
            if node.type == "method_declaration":
                name_node = noir_sbt.child_by_field(node, "name")
                if (
                    name_node is not None
                    and noir_sbt.node_text(source, name_node) == method_name
                ):
                    matches.append(node)
            for child in node.named_children:
                visit(child)

        visit(tree.root_node)
        self.assertEqual(
            len(matches),
            1,
            f"expected exactly one {relative_name}:{method_name} declaration",
        )
        target = noir_sbt.source_target_id(source_file, "method", matches[0])
        self.assertIsNotNone(target)
        return target

    def assert_exact_attribution(self, endpoint, expected_target):
        targets = endpoint.get(noir_sbt.REPRESENTED_TARGETS_KEY)
        self.assertIsInstance(targets, tuple, endpoint)
        self.assertEqual(len(targets), 1, endpoint)
        self.assertEqual(
            noir_sbt.validated_source_target_id(targets[0]), targets[0]
        )
        self.assertEqual(targets, (expected_target,), endpoint)
        self.assertEqual(
            targets[0][0],
            os.path.realpath(endpoint["SrcFile"]),
            endpoint,
        )


class SourceTargetEvidenceTests(AbsentAnnotationTestCase):
    def test_final_trigger_registry_has_exact_closed_identity_coverage(self):
        actual = {"spring": set(), "jaxrx": set()}
        for framework, groups in noir_sbt.FINAL_TRIGGER_ANNOTATION_REGISTRY.items():
            for group in groups:
                self.assertEqual(set(group["family_by_name"]), set(group["names"]))
                actual[framework].update(
                    f"{package}.{name}"
                    for package in group["packages"]
                    for name in group["names"]
                )

        self.assertEqual(actual, EXPECTED_FINAL_TRIGGER_IDENTITIES)
        self.assertFalse(
            {
                "jakarta.ws.rs.Path",
                "javax.ws.rs.Path",
                "org.springframework.context.annotation.Bean",
                "org.springframework.stereotype.Controller",
            }
            & (actual["spring"] | actual["jaxrx"])
        )

    def test_source_target_identity_validation_and_deterministic_merge(self):
        source_file = self.root / "Api.java"
        first_node = SimpleNamespace(start_byte=12, end_byte=40)
        second_node = SimpleNamespace(start_byte=55, end_byte=81)

        first = noir_sbt.source_target_id(source_file, "method", first_node)
        second = noir_sbt.source_target_id(
            source_file, "record-component", second_node
        )
        same_span_component = noir_sbt.source_target_id(
            source_file, "record-component", first_node
        )
        path_alias = source_file.parent / "nested" / ".." / source_file.name

        self.assertEqual(
            first,
            (os.path.realpath(source_file), "method", 12, 40),
        )
        self.assertEqual(
            noir_sbt.represented_target_evidence(
                source_file, "method", first_node
            ),
            (first,),
        )
        self.assertNotEqual(first, same_span_component)
        self.assertEqual(
            noir_sbt.source_target_id(path_alias, "method", first_node),
            first,
        )
        self.assertIsNone(
            noir_sbt.source_target_id(source_file, "field", first_node)
        )
        self.assertEqual(
            noir_sbt.represented_target_evidence(
                source_file, "method", SimpleNamespace(start_byte=8, end_byte=8)
            ),
            (),
        )
        self.assertEqual(
            noir_sbt.merge_represented_targets(
                (second, first), first, ("invalid",), None
            ),
            (first, second),
        )

    def test_private_merge_keeps_candidate_fields_and_unions_both_evidence_kinds(self):
        source_file = self.root / "Api.java"
        first_target = noir_sbt.represented_target_evidence(
            source_file,
            "method",
            SimpleNamespace(start_byte=1, end_byte=20),
        )
        second_target = noir_sbt.represented_target_evidence(
            source_file,
            "method",
            SimpleNamespace(start_byte=30, end_byte=50),
        )
        first_annotation = noir_sbt.make_method_annotation_evidence(
            3,
            "jakarta.ws.rs.GET",
            annotation_source_file=source_file,
            endpoint_source_file=source_file,
        )
        second_annotation = noir_sbt.make_method_annotation_evidence(
            9,
            "org.springframework.web.bind.annotation.GetMapping",
            annotation_source_file=source_file,
            endpoint_source_file=source_file,
        )
        current = {
            "survivor": "old",
            "old_only": True,
            noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (first_annotation,),
            noir_sbt.REPRESENTED_TARGETS_KEY: first_target,
        }
        candidate = {
            "survivor": "new",
            "new_only": True,
            noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (second_annotation,),
            noir_sbt.REPRESENTED_TARGETS_KEY: second_target,
        }

        merged = noir_sbt.merge_endpoint_private_evidence(current, candidate)

        self.assertEqual(merged["survivor"], "new")
        self.assertNotIn("old_only", merged)
        self.assertTrue(merged["new_only"])
        self.assertEqual(
            set(merged[noir_sbt.REPRESENTED_TARGETS_KEY]),
            {first_target[0], second_target[0]},
        )
        self.assertEqual(
            {record["line"] for record in merged[noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY]},
            {3, 9},
        )
        self.assertEqual(
            noir_sbt.merge_endpoint_method_annotation_evidence(current, candidate),
            merged,
        )
        self.assertEqual(current["survivor"], "old")
        self.assertEqual(candidate["survivor"], "new")

    def test_all_analyzer_local_deduplicators_union_private_evidence(self):
        source_file = self.root / "Api.java"
        source_file.write_text("class Api {}\n", encoding="utf8")
        first_target = noir_sbt.source_target_id(
            source_file,
            "method",
            SimpleNamespace(start_byte=10, end_byte=30),
        )
        second_target = noir_sbt.source_target_id(
            source_file,
            "method",
            SimpleNamespace(start_byte=40, end_byte=60),
        )
        first_annotation = noir_sbt.make_method_annotation_evidence(
            3,
            "org.springframework.web.bind.annotation.GetMapping",
            annotation_source_file=source_file,
            endpoint_source_file=source_file,
        )
        second_annotation = noir_sbt.make_method_annotation_evidence(
            9,
            "org.springframework.web.bind.annotation.PostMapping",
            annotation_source_file=source_file,
            endpoint_source_file=source_file,
        )
        base = {
            "uri": "/same",
            "method": "GET",
            "uri_params": "",
            "SrcFile": str(source_file),
            "SrcLine": 20,
            "SFunction": "Api.same",
            "technology": "spring",
            "protocol": "http",
            "surface": "server",
            "direction": "inbound",
        }
        cases = (
            ("resource", noir_sbt_spring_config._deduplicate, {}),
            (
                "client",
                noir_sbt_spring_clients._deduplicate,
                {
                    "surface": "client",
                    "direction": "outbound",
                    "_spring_client_path_layers": ("/same",),
                },
            ),
            (
                "websocket",
                noir_sbt_spring_websocket._deduplicate,
                {"protocol": "ws", "surface": "message"},
            ),
            ("recall", noir_sbt_spring_recall._deduplicate, {}),
            ("gateway", noir_sbt_spring_gateway._deduplicate, {}),
            ("jax-recall", noir_sbt_jax_recall._deduplicate, {}),
        )
        merged_by_name = {}

        for name, deduplicate, extras in cases:
            with self.subTest(deduplicator=name):
                first = {
                    **base,
                    **extras,
                    "survivor": "first",
                    "first_only": True,
                    noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (
                        first_annotation,
                    ),
                    noir_sbt.REPRESENTED_TARGETS_KEY: (first_target,),
                }
                last = {
                    **base,
                    **extras,
                    "survivor": "last",
                    "last_only": True,
                    noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (
                        second_annotation,
                    ),
                    noir_sbt.REPRESENTED_TARGETS_KEY: (second_target,),
                }
                first_before = dict(first)
                last_before = dict(last)

                rows = deduplicate((first, last), noir_sbt)

                self.assertEqual(len(rows), 1)
                merged = rows[0]
                merged_by_name[name] = merged
                self.assertEqual(merged["survivor"], "last")
                self.assertNotIn("first_only", merged)
                self.assertTrue(merged["last_only"])
                self.assertEqual(
                    merged[noir_sbt.REPRESENTED_TARGETS_KEY],
                    (first_target, second_target),
                )
                self.assertEqual(
                    [
                        evidence["line"]
                        for evidence in merged[
                            noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY
                        ]
                    ],
                    [3, 9],
                )
                self.assertEqual(first, first_before)
                self.assertEqual(last, last_before)

        formatted = noir_sbt.format_endpoint(
            merged_by_name["jax-recall"], "app", self.root
        )
        finalized = noir_sbt.finalize_endpoint_rows((formatted,))
        self.assertEqual(len(finalized["rows"]), 1)
        self.assertEqual(
            list(finalized["rows"][0]), noir_sbt.CSV_FIELDNAMES
        )
        self.assertEqual(finalized["rows"][0]["method_annotation_line"], "3")
        self.assertEqual(
            finalized["represented_targets"],
            (first_target, second_target),
        )

    def test_spring_configuration_copies_retained_targets_and_prunes_rejected_targets(self):
        source_file = self.root / "Configured.java"
        source_file.write_text("class Configured {}\n", encoding="utf8")
        retained_target = noir_sbt.source_target_id(
            source_file,
            "method",
            SimpleNamespace(start_byte=1, end_byte=10),
        )
        rejected_target = noir_sbt.source_target_id(
            source_file,
            "method",
            SimpleNamespace(start_byte=11, end_byte=20),
        )
        common = {
            "method": "GET",
            "uri_params": "",
            "SrcFile": str(source_file),
            "SrcLine": 1,
            "technology": "spring",
            "protocol": "http",
            "surface": "server",
            "direction": "inbound",
        }
        retained = {
            **common,
            "uri": "/ok",
            "SFunction": "Configured.ok",
            noir_sbt.REPRESENTED_TARGETS_KEY: (retained_target,),
        }
        rejected = {
            **common,
            "uri": "/${missing",
            "SFunction": "Configured.rejected",
            noir_sbt.REPRESENTED_TARGETS_KEY: (rejected_target,),
        }
        raw = [retained, rejected]
        raw_before = [dict(endpoint) for endpoint in raw]
        configuration = noir_sbt_spring_config.SpringConfiguration(
            analysis_root=str(self.root),
            projects={},
            source_projects={},
        )

        configured = noir_sbt_spring_config.apply_spring_configuration(
            raw, configuration, noir_sbt
        )

        self.assertEqual(raw, raw_before)
        self.assertEqual(len(configured), 1)
        self.assertIsNot(configured[0], retained)
        self.assertTrue(configured[0]["_spring_configuration_applied"])
        self.assertEqual(
            configured[0][noir_sbt.REPRESENTED_TARGETS_KEY],
            (retained_target,),
        )
        finalized = noir_sbt.finalize_endpoint_rows(
            (
                noir_sbt.format_endpoint(
                    configured[0], "app", self.root
                ),
            )
        )
        self.assertEqual(finalized["represented_targets"], (retained_target,))
        self.assertNotIn(rejected_target, finalized["represented_targets"])

    def test_finalizer_unions_exact_targets_without_changing_public_rows(self):
        first_file = self.root / "First.java"
        second_file = self.root / "Second.java"
        first = noir_sbt.source_target_id(
            first_file, "method", SimpleNamespace(start_byte=10, end_byte=30)
        )
        second = noir_sbt.source_target_id(
            second_file, "method", SimpleNamespace(start_byte=40, end_byte=60)
        )
        base = {
            "module_name": "app",
            "interface_type": "http GET",
            "endpoint": "/same",
            "source_file_name": "Api.java",
            "method_name": "Api.same",
            "parameters": "",
        }
        candidates = [
            {**base, noir_sbt.REPRESENTED_TARGETS_KEY: (second,)},
            {**base, noir_sbt.REPRESENTED_TARGETS_KEY: (first,)},
        ]

        finalized = noir_sbt.finalize_endpoint_rows(candidates)

        self.assertEqual(set(finalized), {"rows", "groups", "represented_targets"})
        self.assertEqual(len(finalized["rows"]), 1)
        self.assertEqual(len(finalized["groups"]), 1)
        self.assertEqual(finalized["represented_targets"], (first, second))
        self.assertEqual(
            list(finalized["rows"][0]), noir_sbt.CSV_FIELDNAMES
        )
        self.assertNotIn(
            noir_sbt.REPRESENTED_TARGETS_KEY, finalized["rows"][0]
        )
        self.assertEqual(
            finalized["rows"], noir_sbt.deduplicate_and_sort_rows(candidates)
        )
        self.assertEqual(
            noir_sbt.finalize_endpoint_rows(reversed(candidates))["rows"],
            finalized["rows"],
        )

    def test_finalizer_normalizes_before_union_and_selects_alternate_provenance(self):
        first_file = self.root / "First.java"
        second_file = self.root / "Second.java"
        first = noir_sbt.source_target_id(
            first_file, "method", SimpleNamespace(start_byte=10, end_byte=30)
        )
        second = noir_sbt.source_target_id(
            second_file, "method", SimpleNamespace(start_byte=40, end_byte=60)
        )
        jax = noir_sbt.make_method_annotation_evidence(
            2,
            "jakarta.ws.rs.GET",
            annotation_source_file=first_file,
            endpoint_source_file=first_file,
        )
        spring = noir_sbt.make_method_annotation_evidence(
            20,
            "org.springframework.web.bind.annotation.GetMapping",
            annotation_source_file=second_file,
            endpoint_source_file=second_file,
        )
        base = {
            "module_name": "app",
            "interface_type": "http GET",
            "source_file_name": "Api.java",
            "method_name": "Api.same",
            "parameters": "",
        }
        candidates = [
            {
                **base,
                "endpoint": "/api//items/{id:[0-9]{2}}",
                noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (jax,),
                noir_sbt.REPRESENTED_TARGETS_KEY: (first,),
            },
            {
                **base,
                "endpoint": "api/items/{id}",
                noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (spring,),
                noir_sbt.REPRESENTED_TARGETS_KEY: (second,),
            },
            {**base, "endpoint": "/api/items/{id}"},
        ]

        finalized = noir_sbt.finalize_endpoint_rows(candidates)

        self.assertEqual(len(finalized["rows"]), 1)
        self.assertEqual(finalized["rows"][0]["endpoint"], "/api/items/{id}")
        self.assertEqual(finalized["rows"][0]["method_annotation_line"], "20")
        self.assertEqual(finalized["represented_targets"], (first, second))
        self.assertEqual(
            noir_sbt.finalize_endpoint_rows(reversed(candidates)), finalized
        )


class ReportPathAndPublicationTests(AbsentAnnotationTestCase):
    def test_report_path_removes_only_the_final_suffix(self):
        cases = {
            self.root / "endpoints.csv": self.root
            / "endpoints-anno-without-endpoints.log",
            self.root / "endpoints": self.root
            / "endpoints-anno-without-endpoints.log",
            self.root / "endpoints.audit.csv": self.root
            / "endpoints.audit-anno-without-endpoints.log",
        }
        for output, expected in cases.items():
            with self.subTest(output=output):
                self.assertEqual(
                    Path(noir_sbt.derive_absent_trigger_report_path(output)),
                    expected,
                )

    def test_atomic_publication_replaces_complete_bytes_and_supports_empty_report(self):
        destination = self.root / "report.log"
        destination.write_bytes(b"old report\n")

        noir_sbt.publish_bytes_atomically(destination, "caf\u00e9\n".encode())
        self.assertEqual(destination.read_bytes(), "caf\u00e9\n".encode())
        self.assertEqual(list(self.root.iterdir()), [destination])

        noir_sbt.publish_bytes_atomically(destination, b"")
        self.assertEqual(destination.read_bytes(), b"")
        self.assertEqual(list(self.root.iterdir()), [destination])

    def test_atomic_publication_failure_preserves_prior_or_absent_destination(self):
        for existing in (False, True):
            with self.subTest(existing=existing):
                directory = self.root / str(existing)
                directory.mkdir()
                destination = directory / "report.log"
                if existing:
                    destination.write_bytes(b"completed\n")
                with mock.patch.object(
                    noir_sbt.os,
                    "replace",
                    side_effect=OSError("replace failed"),
                ):
                    with self.assertRaisesRegex(OSError, "replace failed"):
                        noir_sbt.publish_bytes_atomically(destination, b"partial")
                if existing:
                    self.assertEqual(destination.read_bytes(), b"completed\n")
                    self.assertEqual(list(directory.iterdir()), [destination])
                else:
                    self.assertFalse(destination.exists())
                    self.assertEqual(list(directory.iterdir()), [])

    def test_atomic_write_flush_fsync_and_close_failures_clean_temporary_files(self):
        real_fdopen = os.fdopen

        class FailingStage:
            def __init__(self, descriptor, stage):
                self.raw = real_fdopen(descriptor, "wb")
                self.stage = stage

            def __enter__(self):
                return self

            def __exit__(self, exc_type, _exc, _traceback):
                self.raw.close()
                if self.stage == "close" and exc_type is None:
                    raise OSError("close failed")

            def write(self, payload):
                if self.stage == "write":
                    raise OSError("write failed")
                return self.raw.write(payload)

            def flush(self):
                if self.stage == "flush":
                    raise OSError("flush failed")
                return self.raw.flush()

            def fileno(self):
                return self.raw.fileno()

        for stage in ("write", "flush", "fsync", "close"):
            with self.subTest(stage=stage):
                directory = self.root / stage
                directory.mkdir()
                destination = directory / "report.log"
                destination.write_bytes(b"completed\n")
                patcher = (
                    mock.patch.object(
                        noir_sbt.os,
                        "fdopen",
                        side_effect=lambda descriptor, _mode, stage=stage: FailingStage(
                            descriptor, stage
                        ),
                    )
                    if stage != "fsync"
                    else mock.patch.object(
                        noir_sbt.os,
                        "fsync",
                        side_effect=OSError("fsync failed"),
                    )
                )
                with patcher:
                    with self.assertRaisesRegex(OSError, f"{stage} failed"):
                        noir_sbt.publish_bytes_atomically(
                            destination, b"current run\n"
                        )
                self.assertEqual(destination.read_bytes(), b"completed\n")
                self.assertEqual(list(directory.iterdir()), [destination])

    def test_atomic_publication_cleans_staging_file_on_interrupt(self):
        destination = self.root / "report.log"
        destination.write_bytes(b"completed\n")

        with mock.patch.object(
            noir_sbt.os,
            "fsync",
            side_effect=KeyboardInterrupt("interrupted"),
        ):
            with self.assertRaisesRegex(KeyboardInterrupt, "interrupted"):
                noir_sbt.publish_bytes_atomically(destination, b"current\n")

        self.assertEqual(destination.read_bytes(), b"completed\n")
        self.assertEqual(list(self.root.iterdir()), [destination])


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class CandidateInventoryTests(AbsentAnnotationTestCase):
    def test_collector_parses_every_direct_closed_registry_identity(self):
        spring_mvc = "\n".join(
            f"    @org.springframework.web.bind.annotation.{name} abstract void mvc{index}();"
            for index, name in enumerate(SPRING_MVC_TRIGGER_NAMES)
        )
        spring_exchange = "\n".join(
            f"    @org.springframework.web.service.annotation.{name} void exchange{index}();"
            for index, name in enumerate(SPRING_EXCHANGE_TRIGGER_NAMES)
        )
        spring_message = "\n".join(
            f"    @org.springframework.messaging.handler.annotation.{name} void message{index}() {{}}"
            for index, name in enumerate(SPRING_MESSAGE_TRIGGER_NAMES)
        )
        jax_methods = "\n".join(
            f"    @{package}.{name} abstract void jax{package_index}_{name.lower()}();"
            for package_index, package in enumerate(("jakarta.ws.rs", "javax.ws.rs"))
            for name in JAX_TRIGGER_NAMES
        )
        source = f"""package all;
abstract class SpringMvc {{
{spring_mvc}
}}
interface SpringExchange {{
{spring_exchange}
}}
class SpringMessage {{
{spring_message}
}}
abstract class JaxMethods {{
{jax_methods}
}}
@jakarta.websocket.server.ServerEndpoint("/jakarta") class JakartaSocket {{}}
@javax.websocket.server.ServerEndpoint("/javax") record JavaxSocket() {{}}
"""
        _root, _workspace, inventory = self.inventory(
            "all-direct-identities", {"all/All.java": source}
        )

        actual = {
            framework: {
                item["resolved"]
                for item in self.framework_annotations(
                    inventory, "all/All.java", framework
                )
            }
            for framework in ("spring", "jaxrx")
        }
        self.assertEqual(actual, EXPECTED_FINAL_TRIGGER_IDENTITIES)
        self.assertEqual(len(actual["spring"]), 14)
        self.assertEqual(len(actual["jaxrx"]), 16)

    def test_direct_spring_endpoint_and_workspace_candidate_share_target_id(self):
        _root, inventory, endpoints, finalized = self.analyzed(
            "cross-parser",
            {
                "api/Api.java": """package api;
import org.springframework.web.bind.annotation.GetMapping;
class Api {
    @GetMapping("/live") void live() {}
}
"""
            },
            "spring",
        )

        candidate = self.framework_annotations(
            inventory, "api/Api.java", "spring"
        )[0]
        self.assertEqual(len(endpoints), 1)
        self.assertEqual(
            endpoints[0][noir_sbt.REPRESENTED_TARGETS_KEY],
            (candidate["target"],),
        )
        self.assertEqual(finalized["represented_targets"], (candidate["target"],))
        self.assertNotIn(
            b"Annotation: GetMapping",
            noir_sbt.absent_trigger_report_bytes(
                inventory, finalized["represented_targets"]
            ),
        )

    def test_applied_to_normalizes_complex_parameters_and_nested_overloads(self):
        source = """package api;
abstract class Outer {
    abstract class Inner {
        @org.springframework.web.bind.annotation.GetMapping
        abstract <T> void read(
            @Valid(
                groups = {
                    One.class,
                    Two.class
                }
            )
            java.util.Map<String,
                java.util.List<? extends Number>> values,
            /* keep
               details */ String... names
        );

        @org.springframework.web.bind.annotation.PostMapping
        abstract void read(int id);
    }
}
"""
        _root, _workspace, inventory = self.inventory(
            "complex-parameters", {"api/Outer.java": source}, ("spring",)
        )
        annotations = self.framework_annotations(
            inventory, "api/Outer.java", "spring"
        )

        self.assertEqual(
            [item["applied_to"] for item in annotations],
            [
                "method Outer.Inner.read(@Valid( groups = { One.class, Two.class } ) "
                "java.util.Map<String, java.util.List<? extends Number>> values, "
                "/* keep details */ String... names)",
                "method Outer.Inner.read(int id)",
            ],
        )
        self.assertNotEqual(annotations[0]["target"], annotations[1]["target"])

    def test_candidate_placements_and_exclusions_are_closed(self):
        source = """package api;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.messaging.handler.annotation.MessageMapping;
import jakarta.websocket.server.ServerEndpoint;

@RequestMapping("/prefix")
@MessageMapping("/message-prefix")
abstract class Api {
    @GetMapping(path = Missing.PATH) abstract void spring();
    @MessageMapping("/message") void message() {}
    @GetMapping Api() {}
    @PostMapping String field;
    void wrong(@jakarta.ws.rs.GET String value) {
        @jakarta.ws.rs.POST String local = "";
    }
    void spread(@jakarta.ws.rs.PUT String... values) {}
    java.util.@GetMapping List<String> typeUse;
    @org.springframework.context.annotation.Bean Object support() { return null; }
    @jakarta.ws.rs.Path("/support") void pathOnly() {}
}

@org.springframework.web.service.annotation.HttpExchange("/exchange-prefix")
interface Contracts {
    @GetMapping("/contract") void mvc();
    @GetExchange("/exchange") void exchange();
    @jakarta.ws.rs.HEAD void jax();
}

class WrongExchange {
    @GetExchange("/bad") void exchange() {}
}

record Routes(@GetMapping("/component") String item) {}

@ServerEndpoint("#fragment") abstract class Socket {}
@ServerEndpoint("/ignored") interface BadSocket {}
@ServerEndpoint("/ignored") enum BadSocketEnum { VALUE }
@ServerEndpoint("/ignored") @interface BadSocketAnnotation {}

@interface Elements {
    @GetMapping String value();
}
"""
        _root, _workspace, inventory = self.inventory(
            "placements",
            {
                "api/Api.java": source,
                "pkg/package-info.java": """@org.springframework.web.bind.annotation.GetMapping
package pkg;
""",
            },
        )

        spring = self.framework_annotations(inventory, "api/Api.java", "spring")
        jax = self.framework_annotations(inventory, "api/Api.java", "jaxrx")
        self.assertEqual(
            {(item["name"], item["applied_to"]) for item in spring},
            {
                ("GetMapping", "method Api.spring()"),
                ("MessageMapping", "method Api.message()"),
                ("GetMapping", "method Contracts.mvc()"),
                ("GetExchange", "method Contracts.exchange()"),
                ("GetMapping", "record component Routes.item"),
            },
        )
        self.assertEqual(
            {(item["name"], item["applied_to"]) for item in jax},
            {
                ("HEAD", "method Contracts.jax()"),
                ("ServerEndpoint", "type Socket"),
            },
        )
        self.assertTrue(
            all(
                set(item)
                == {
                    "name",
                    "resolved",
                    "family",
                    "target",
                    "applied_to",
                    "line",
                    "start_byte",
                    "end_byte",
                    "extract",
                }
                for item in [*spring, *jax]
            )
        )
        self.assertEqual(
            self.framework_annotations(
                inventory, "pkg/package-info.java", "spring"
            ),
            [],
        )
        self.assertEqual(
            self.framework_annotations(
                inventory, "pkg/package-info.java", "jaxrx"
            ),
            [],
        )

    def test_anonymous_methods_are_excluded_and_physical_lines_are_byte_aligned(self):
        files = {
            "api/Anonymous.java": """package api;
abstract class Anonymous {
    Object value = new Object() {
        @org.springframework.web.bind.annotation.GetMapping("/ghost")
        void ghost() {}
    };
    @org.springframework.web.bind.annotation.PostMapping("/real")
    abstract void real();
}
""",
            "api/FormFeed.java": (
                "package api;\n"
                "abstract class FormFeed {\f    "
                "@org.springframework.web.bind.annotation.GetMapping "
                "abstract void formFeed();\n}\n"
            ),
            "api/CarriageReturn.java": (
                "package api;\r"
                "abstract class CarriageReturn {\r"
                "    @org.springframework.web.bind.annotation.GetMapping "
                "abstract void carriageReturn();\r}\r"
            ),
            "api/CrLf.java": (
                "package api;\r\n"
                "abstract class CrLf {\r\n"
                "    @org.springframework.web.bind.annotation.GetMapping "
                "abstract void crlf();\r\n}\r\n"
            ),
        }
        _root, _workspace, inventory = self.inventory(
            "physical-lines", files, ("spring",)
        )

        anonymous = self.framework_annotations(
            inventory, "api/Anonymous.java", "spring"
        )
        self.assertEqual(
            [(item["name"], item["applied_to"]) for item in anonymous],
            [("PostMapping", "method Anonymous.real()")],
        )

        form_feed = self.framework_annotations(
            inventory, "api/FormFeed.java", "spring"
        )[0]
        self.assertEqual(form_feed["line"], 2)
        self.assertEqual(form_feed["extract"][0]["line"], 2)
        self.assertIn("\f", form_feed["extract"][0]["source"])
        self.assertIn("@org.springframework", form_feed["extract"][0]["source"])

        carriage_return = self.framework_annotations(
            inventory, "api/CarriageReturn.java", "spring"
        )[0]
        self.assertEqual(carriage_return["line"], 3)
        self.assertEqual(carriage_return["extract"][0]["line"], 3)
        self.assertTrue(
            carriage_return["extract"][0]["source"].lstrip().startswith(
                "@org.springframework"
            )
        )
        crlf = self.framework_annotations(
            inventory, "api/CrLf.java", "spring"
        )[0]
        self.assertEqual(crlf["line"], 3)
        self.assertEqual(crlf["extract"][0]["line"], 3)
        self.assertNotIn(
            b"\r", noir_sbt.absent_trigger_report_bytes(inventory, ())
        )

    def test_source_defined_outer_use_is_independent_per_framework(self):
        files = {
            "annotations/Read.java": """package annotations;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import jakarta.ws.rs.HttpMethod;
import org.springframework.core.annotation.AliasFor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@RequestMapping(method = RequestMethod.GET)
@HttpMethod("READ")
public @interface Read {
    @AliasFor(annotation = RequestMapping.class, attribute = "path")
    String[] value() default {};
}
""",
            "api/Api.java": """package api;
import annotations.Read;
import org.springframework.web.bind.annotation.PostMapping;
abstract class Api {
    @Read(Missing.PATH) abstract void dual();
    @PostMapping("/direct") abstract void spring();
    @javax.ws.rs.OPTIONS abstract void jax();
}
""",
        }
        _root, _workspace, inventory = self.inventory("source-defined", files)

        spring = self.framework_annotations(inventory, "api/Api.java", "spring")
        jax = self.framework_annotations(inventory, "api/Api.java", "jaxrx")
        self.assertEqual(
            [(item["name"], item["resolved"]) for item in spring],
            [
                ("Read", "annotations.Read"),
                (
                    "PostMapping",
                    "org.springframework.web.bind.annotation.PostMapping",
                ),
            ],
        )
        self.assertEqual(
            [(item["name"], item["resolved"]) for item in jax],
            [
                ("Read", "annotations.Read"),
                ("OPTIONS", "javax.ws.rs.OPTIONS"),
            ],
        )
        self.assertEqual(spring[0]["target"], jax[0]["target"])
        self.assertEqual(
            (spring[0]["start_byte"], spring[0]["end_byte"]),
            (jax[0]["start_byte"], jax[0]["end_byte"]),
        )
        self.assertEqual(
            self.framework_annotations(
                inventory, "annotations/Read.java", "spring"
            ),
            [],
        )
        self.assertEqual(
            self.framework_annotations(
                inventory, "annotations/Read.java", "jaxrx"
            ),
            [],
        )

        for selected, expected_framework in (
            (("spring",), "spring"),
            (("jaxrx",), "jaxrx"),
        ):
            with self.subTest(selected=selected):
                _root, _workspace, filtered = self.inventory(
                    f"filtered-{expected_framework}", files, selected
                )
                self.assertTrue(
                    all(
                        [record["framework"] for record in file_record["frameworks"]]
                        == [expected_framework]
                        for file_record in filtered
                    )
                )

    def test_direct_and_source_defined_candidates_share_absent_target_in_source_order(self):
        files = {
            "annotations/Read.java": """package annotations;
@java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping(
    method = org.springframework.web.bind.annotation.RequestMethod.GET
)
public @interface Read {
    @org.springframework.core.annotation.AliasFor(
        annotation = org.springframework.web.bind.annotation.RequestMapping.class,
        attribute = "path"
    )
    String[] value() default {};
}
""",
            "api/Api.java": """package api;
import annotations.Read;
import org.springframework.web.bind.annotation.PostMapping;
abstract class Api {
    @Read(Missing.READ)
    @PostMapping(path = Missing.POST)
    abstract void both();
}
""",
        }
        _root, inventory, endpoints, finalized = self.analyzed(
            "direct-source-same-target", files, "spring"
        )
        candidates = self.framework_annotations(
            inventory, "api/Api.java", "spring"
        )

        self.assertEqual(endpoints, [])
        self.assertEqual(finalized["rows"], [])
        self.assertEqual(
            [candidate["name"] for candidate in candidates],
            ["Read", "PostMapping"],
        )
        self.assertEqual(candidates[0]["target"], candidates[1]["target"])

        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        ).decode("utf8")
        labels = [
            line.split(": ", 1)[1]
            for line in report.splitlines()
            if line.startswith("  - Annotation: ")
        ]
        self.assertEqual(labels, ["Read", "PostMapping"])
        self.assertEqual(report.count("Applied to: method Api.both()"), 2)

    def test_same_fqn_supported_definitions_survive_shadowing_while_invalid_graphs_fail_closed(self):
        files = {
            "org/springframework/web/bind/annotation/GetMapping.java": """package org.springframework.web.bind.annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping("/source-defined")
public @interface GetMapping {}
""",
            "jakarta/ws/rs/GET.java": """package jakarta.ws.rs;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.RUNTIME)
@HttpMethod("FETCH")
public @interface GET {}
""",
            "annotations/Bad.java": """package annotations;
@jakarta.ws.rs.HttpMethod("BAD")
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
public @interface Bad {}
""",
            "annotations/InvalidSpring.java": """package annotations;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping
@org.springframework.web.bind.annotation.PostMapping
public @interface InvalidSpring {}
""",
            "annotations/CycleA.java": """package annotations;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@CycleB public @interface CycleA {}
""",
            "annotations/CycleB.java": """package annotations;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@CycleA
@org.springframework.web.bind.annotation.RequestMapping
public @interface CycleB {}
""",
            "api/Api.java": """package api;
import annotations.Bad;
import annotations.CycleA;
import annotations.InvalidSpring;
import jakarta.ws.rs.GET;
import org.springframework.web.bind.annotation.GetMapping;
abstract class Api {
    @GetMapping(Missing.SPRING) abstract void spring();
    @GET(value = Missing.JAX) abstract void jax();
    @Bad abstract void bad();
    @InvalidSpring abstract void invalidSpring();
    @CycleA abstract void cyclic();
}
""",
        }
        _root, _workspace, inventory = self.inventory("same-fqn", files)

        spring = self.framework_annotations(inventory, "api/Api.java", "spring")
        jax = self.framework_annotations(inventory, "api/Api.java", "jaxrx")
        self.assertEqual(
            [(item["name"], item["resolved"], item["family"]) for item in spring],
            [
                (
                    "GetMapping",
                    "org.springframework.web.bind.annotation.GetMapping",
                    "spring-composed-mvc",
                )
            ],
        )
        self.assertEqual(
            [(item["name"], item["resolved"], item["family"]) for item in jax],
            [
                (
                    "GET",
                    "jakarta.ws.rs.GET",
                    noir_sbt.METHOD_ANNOTATION_FAMILY_JAX_RS,
                )
            ],
        )
        for file_record in inventory:
            if file_record["file"] == "api/Api.java":
                continue
            self.assertTrue(
                all(
                    not section["annotations"]
                    for section in file_record["frameworks"]
                ),
                file_record["file"],
            )

    def test_exact_membership_and_report_layout_use_candidate_target(self):
        source = """package demo;
import org.springframework.web.bind.annotation.PostMapping;
abstract class Draft {
    @PostMapping(
        path = "/two"
    )
    abstract void two();
}
"""
        _root, _workspace, inventory = self.inventory(
            "render", {"Draft.java": source}, ("spring",)
        )
        candidate = self.framework_annotations(
            inventory, "Draft.java", "spring"
        )[0]

        payload = noir_sbt.absent_trigger_report_bytes(inventory, ())

        self.assertEqual(
            payload,
            b"File: Draft.java\n"
            b"Framework: spring\n"
            b"Annotations without endpoints:\n"
            b"  - Annotation: PostMapping\n"
            b"    Resolved: org.springframework.web.bind.annotation.PostMapping\n"
            b"    Applied to: method Draft.two()\n"
            b"    Line: 4\n"
            b"    Extract:\n"
            b"      4:     @PostMapping(\n"
            b"      5:         path = \"/two\"\n"
            b"      6:     )\n"
            b"      7:     abstract void two();\n"
            b"      8: }\n",
        )
        self.assertFalse(payload.startswith(b"\xef\xbb\xbf"))
        self.assertEqual(
            noir_sbt.absent_trigger_report_bytes(
                inventory, (candidate["target"],)
            ),
            b"File: Draft.java\n"
            b"Framework: spring\n"
            b"Annotations without endpoints: none\n",
        )

    def test_renderer_orders_files_frameworks_and_same_line_occurrences(self):
        files = {
            "z/Z.java": """package z;
abstract class Z { @jakarta.ws.rs.HEAD @jakarta.ws.rs.GET abstract void z(); }
""",
            "a/A.java": """package a;
abstract class A { @org.springframework.web.bind.annotation.PostMapping @org.springframework.web.bind.annotation.GetMapping abstract void a(); }
""",
        }
        _root, _workspace, inventory = self.inventory("ordering", files)

        text = noir_sbt.absent_trigger_report_bytes(inventory, ()).decode("utf8")

        self.assertLess(text.index("File: a/A.java"), text.index("File: z/Z.java"))
        for file_block in text.split("\n\nFile: "):
            self.assertLess(
                file_block.index("Framework: spring"),
                file_block.index("Framework: jaxrx"),
            )
        self.assertLess(text.index("Annotation: PostMapping"), text.index("Annotation: GetMapping"))
        self.assertLess(text.index("Annotation: HEAD"), text.index("Annotation: GET"))
        self.assertNotIn("Diagnostics:", text)
        self.assertNotRegex(text, r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}")
        self.assertTrue(text.endswith("\n"))

    def test_duplicate_discovery_passes_render_one_framework_item(self):
        module_root, workspace = self.workspace(
            "duplicate-discovery",
            {
                "api/Api.java": """package api;
abstract class Api {
    @org.springframework.web.bind.annotation.GetMapping(path = Missing.PATH)
    abstract void draft();
}
"""
            },
            include_jax=False,
        )
        unit = workspace["units"][str(module_root / "api/Api.java")]
        self.assertEqual(len(unit["annotation_occurrences"]), 1)

        occurrence = unit["annotation_occurrences"][0]
        unit["annotation_occurrences"] = [
            occurrence,
            dict(occurrence),
            dict(occurrence),
        ]
        inventory = noir_sbt.build_absent_trigger_inventory(
            workspace, module_root, {"spring"}
        )
        candidates = self.framework_annotations(
            inventory, "api/Api.java", "spring"
        )

        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0]["name"], "GetMapping")
        report = noir_sbt.absent_trigger_report_bytes(inventory, ()).decode("utf8")
        self.assertEqual(report.count("  - Annotation: GetMapping\n"), 1)

    def test_extracts_preserve_blank_annotation_lines_overlap_eof_and_spacing(self):
        files = {
            "a/Extracts.java": """package a;
abstract class Extracts {
    @org.springframework.web.bind.annotation.GetMapping(
        
        path = "/one"
    )

    @org.springframework.web.bind.annotation.PostMapping("/two")
      
    abstract void both();
}
""",
            "z/Tail.java": """package z;
abstract class Tail {
    @jakarta.ws.rs.GET abstract void tail();
}
""",
        }
        _root, _workspace, inventory = self.inventory("extract-spacing", files)
        spring = self.framework_annotations(
            inventory, "a/Extracts.java", "spring"
        )

        self.assertEqual(
            [line["line"] for line in spring[0]["extract"]],
            [3, 4, 5, 6, 8, 10, 11],
        )
        self.assertEqual(spring[0]["extract"][1]["source"], "        ")
        self.assertEqual(
            [line["line"] for line in spring[1]["extract"]],
            [8, 10, 11],
        )
        self.assertEqual(
            {
                line["line"]
                for line in spring[0]["extract"]
                if line["line"] in {8, 10, 11}
            },
            {line["line"] for line in spring[1]["extract"]},
        )

        text = noir_sbt.absent_trigger_report_bytes(inventory, ()).decode("utf8")
        self.assertEqual(text.count("\n\n  - Annotation: PostMapping"), 1)
        self.assertEqual(text.count("\n\nFramework: jaxrx"), 2)
        self.assertEqual(text.count("\n\nFile: z/Tail.java"), 1)
        self.assertNotIn("\n\n\n", text)
        self.assertFalse(text.startswith("\n"))
        self.assertTrue(text.endswith("\n"))
        self.assertFalse(text.endswith("\n\n"))
        self.assertIn("      4:         \n", text)
        self.assertEqual(text.count("      10:     abstract void both();"), 2)

    def test_extract_caps_context_at_ten_nonempty_lines_and_renders_unicode_without_bom(self):
        source = """package café;
abstract class Café {
    @org.springframework.web.bind.annotation.GetMapping("/café")

    abstract void café();
    String context01 = "un";

    String context02 = "deux";
    String context03 = "trois";
    String context04 = "quatre";
    String context05 = "cinq";
    String context06 = "six";
    String context07 = "sept";
    String context08 = "huit";
    String context09 = "neuf";
    String excluded10 = "dix";
    String excluded11 = "onze";
}
"""
        _root, _workspace, inventory = self.inventory(
            "unicode-context", {"api/Café.java": source}, ("spring",)
        )
        candidate = self.framework_annotations(
            inventory, "api/Café.java", "spring"
        )[0]

        self.assertEqual(
            [line["line"] for line in candidate["extract"]],
            [3, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15],
        )
        self.assertNotIn(
            "excluded10",
            "\n".join(line["source"] for line in candidate["extract"]),
        )

        payload = noir_sbt.absent_trigger_report_bytes(inventory, ())
        self.assertFalse(payload.startswith(b"\xef\xbb\xbf"))
        self.assertIn("File: api/Café.java".encode("utf8"), payload)
        self.assertIn("/café".encode("utf8"), payload)
        self.assertIn("abstract void café();".encode("utf8"), payload)
        self.assertNotIn(b"excluded10", payload)
        self.assertEqual(payload.decode("utf8").encode("utf8"), payload)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class TargetMembershipEdgeTests(AbsentAnnotationTestCase):
    def test_competing_sibling_and_fanout_candidates_use_exact_target_membership(self):
        _root, inventory, endpoints, finalized = self.analyzed(
            "exact-membership",
            {
                "api/Api.java": """package api;
import org.springframework.web.bind.annotation.*;
@RestController class Api {
    @GetMapping("/chosen")
    @PostMapping(path = Missing.PATH)
    void competing() {}

    @DeleteMapping(path = Missing.PATH)
    void sibling() {}

    @RequestMapping(
        path = {"/a", "/b"},
        method = {RequestMethod.GET, RequestMethod.POST}
    )
    @PatchMapping(path = Missing.PATCH)
    void fanOut() {}
}
"""
            },
            "spring",
        )
        candidates = self.framework_annotations(
            inventory, "api/Api.java", "spring"
        )
        by_name = {candidate["name"]: candidate for candidate in candidates}

        self.assertEqual(
            by_name["GetMapping"]["target"],
            by_name["PostMapping"]["target"],
        )
        self.assertEqual(
            by_name["RequestMapping"]["target"],
            by_name["PatchMapping"]["target"],
        )
        self.assertNotIn(
            by_name["DeleteMapping"]["target"],
            finalized["represented_targets"],
        )
        self.assertEqual(
            set(finalized["represented_targets"]),
            {
                by_name["GetMapping"]["target"],
                by_name["RequestMapping"]["target"],
            },
        )
        self.assertEqual(
            {
                (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
                for endpoint in endpoints
            },
            {
                ("GET", "/chosen", "Api.competing"),
                ("GET", "/a", "Api.fanOut"),
                ("POST", "/a", "Api.fanOut"),
                ("GET", "/b", "Api.fanOut"),
                ("POST", "/b", "Api.fanOut"),
            },
        )

        competing_row = next(
            row
            for row in finalized["rows"]
            if row["method_name"] == "Api.competing"
        )
        self.assertEqual(
            competing_row["method_annotation_line"],
            str(by_name["GetMapping"]["line"]),
        )

        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        ).decode("utf8")
        labels = [
            line.split(": ", 1)[1]
            for line in report.splitlines()
            if line.startswith("  - Annotation: ")
        ]
        self.assertEqual(labels, ["DeleteMapping"])
        self.assertIn("Applied to: method Api.sibling()", report)

    def test_nested_member_endpoint_does_not_represent_outer_or_sibling_target(self):
        _root, inventory, endpoints, finalized = self.analyzed(
            "nested-membership",
            {
                "api/Outer.java": """package api;
@jakarta.websocket.server.ServerEndpoint("/outer")
public abstract class Outer {
    @org.springframework.web.bind.annotation.PostMapping(path = Missing.PATH)
    abstract void sibling();

    @org.springframework.web.bind.annotation.RestController
    static class Nested {
        @org.springframework.web.bind.annotation.GetMapping("/live")
        void live() {}
    }
}
"""
            },
        )
        spring = self.framework_annotations(
            inventory, "api/Outer.java", "spring"
        )
        jax = self.framework_annotations(
            inventory, "api/Outer.java", "jaxrx"
        )
        by_name = {candidate["name"]: candidate for candidate in spring}

        self.assertEqual(
            [
                (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
                for endpoint in endpoints
            ],
            [("GET", "/live", "Outer.Nested.live")],
        )
        self.assertEqual(
            finalized["represented_targets"],
            (by_name["GetMapping"]["target"],),
        )
        self.assertNotIn(
            by_name["PostMapping"]["target"],
            finalized["represented_targets"],
        )
        self.assertNotIn(jax[0]["target"], finalized["represented_targets"])

        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        ).decode("utf8")
        labels = [
            line.split(": ", 1)[1]
            for line in report.splitlines()
            if line.startswith("  - Annotation: ")
        ]
        self.assertEqual(labels, ["PostMapping", "ServerEndpoint"])
        self.assertIn("Applied to: method Outer.sibling()", report)
        self.assertIn("Applied to: type Outer", report)
        self.assertNotIn("  - Annotation: GetMapping\n", report)

    def test_implicit_record_component_is_represented_but_explicit_accessor_is_distinct(self):
        _root, inventory, endpoints, finalized = self.analyzed(
            "record-components",
            {
                "api/Routes.java": """package api;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
record Implicit(@GetMapping("/implicit") String value) {}
record Explicit(@PostMapping("/component") String value) {
    @GetMapping("/method") public String value() { return value; }
}
"""
            },
            "spring",
        )
        candidates = self.framework_annotations(
            inventory, "api/Routes.java", "spring"
        )
        by_applied_to = {item["applied_to"]: item for item in candidates}
        endpoint_targets = {
            target
            for endpoint in endpoints
            for target in endpoint[noir_sbt.REPRESENTED_TARGETS_KEY]
        }

        self.assertEqual(
            set(by_applied_to),
            {
                "record component Implicit.value",
                "record component Explicit.value",
                "method Explicit.value()",
            },
        )
        self.assertIn(
            by_applied_to["record component Implicit.value"]["target"],
            endpoint_targets,
        )
        self.assertIn(
            by_applied_to["method Explicit.value()"]["target"],
            endpoint_targets,
        )
        self.assertNotIn(
            by_applied_to["record component Explicit.value"]["target"],
            endpoint_targets,
        )
        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        )
        self.assertIn(b"Annotation: PostMapping", report)
        self.assertIn(b"Applied to: record component Explicit.value", report)
        self.assertNotIn(b"Applied to: record component Implicit.value", report)
        self.assertNotIn(b"Applied to: method Explicit.value()", report)

    def test_server_endpoint_success_represents_type_while_later_failures_report(self):
        files = {
            "live/Live.java": """package live;
@jakarta.websocket.server.ServerEndpoint("/live")
public class Live {}
""",
            "bad/BadPath.java": """package bad;
@jakarta.websocket.server.ServerEndpoint("#fragment")
public class BadPath {}
""",
            "bad/AbstractSocket.java": """package bad;
@javax.websocket.server.ServerEndpoint("/abstract")
public abstract class AbstractSocket {}
""",
            "bad/Stateful.java": """package bad;
@javax.websocket.server.ServerEndpoint("/stateful")
public record Stateful(String value) {}
""",
        }
        _root, inventory, endpoints, finalized = self.analyzed(
            "server-endpoints", files, "jaxrx"
        )
        candidates = {
            item["applied_to"]: item
            for file_record in inventory
            for section in file_record["frameworks"]
            for item in section["annotations"]
        }

        self.assertEqual(
            set(candidates),
            {"type Live", "type BadPath", "type AbstractSocket", "type Stateful"},
        )
        self.assertEqual(len(endpoints), 1)
        self.assertEqual(endpoints[0]["SFunction"], "Live")
        self.assertEqual(
            endpoints[0][noir_sbt.REPRESENTED_TARGETS_KEY],
            (candidates["type Live"]["target"],),
        )
        self.assertEqual(finalized["rows"][0]["method_annotation_line"], "")
        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        ).decode("utf8")
        self.assertNotIn("Applied to: type Live\n", report)
        for failed in ("BadPath", "AbstractSocket", "Stateful"):
            self.assertIn(f"Applied to: type {failed}\n", report)
        self.assertEqual(report.count("Annotation: ServerEndpoint"), 3)

    def test_inherited_contract_candidate_is_not_represented_by_concrete_handler(self):
        files = {
            "contract/Contract.java": """package contract;
import org.springframework.web.bind.annotation.GetMapping;
public interface Contract {
    @GetMapping("/inherited") void inherited();
}
""",
            "api/Controller.java": """package api;
import contract.Contract;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController @RequestMapping("/api")
public class Controller implements Contract {
    public void inherited() {}
}
""",
        }
        _root, inventory, endpoints, finalized = self.analyzed(
            "inherited-contract", files, "spring"
        )
        contract_candidate = self.framework_annotations(
            inventory, "contract/Contract.java", "spring"
        )[0]

        self.assertEqual(len(endpoints), 1)
        self.assertEqual(endpoints[0]["SFunction"], "Controller.inherited")
        concrete_target = endpoints[0][noir_sbt.REPRESENTED_TARGETS_KEY][0]
        self.assertNotEqual(contract_candidate["target"], concrete_target)
        self.assertTrue(concrete_target[0].endswith("api/Controller.java"))
        self.assertTrue(
            contract_candidate["target"][0].endswith("contract/Contract.java")
        )
        self.assertEqual(finalized["rows"][0]["method_annotation_line"], "")
        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        )
        self.assertIn(b"Annotation: GetMapping", report)
        self.assertIn(b"Applied to: method Contract.inherited()", report)

    def test_late_rejected_direct_and_source_defined_triggers_reach_report(self):
        files = {
            "annotations/Read.java": """package annotations;
@java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@org.springframework.web.bind.annotation.RequestMapping(
    method = org.springframework.web.bind.annotation.RequestMethod.GET
)
public @interface Read {
    @org.springframework.core.annotation.AliasFor(
        annotation = org.springframework.web.bind.annotation.RequestMapping.class,
        attribute = "path"
    )
    String[] value() default {};
}
""",
            "designators/PROPFIND.java": """package designators;
@java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@jakarta.ws.rs.HttpMethod("PROPFIND")
public @interface PROPFIND {}
""",
            "api/SpringApi.java": """package api;
import annotations.Read;
@org.springframework.web.bind.annotation.RestController
public class SpringApi {
    @Read(Missing.PATH) public void composed() {}
}
""",
            "api/Dormant.java": """package api;
public interface Dormant {
    @org.springframework.web.bind.annotation.GetMapping("/inactive")
    void inactive();
}
""",
            "api/JaxApi.java": """package api;
import designators.PROPFIND;
@jakarta.ws.rs.Path("/jax")
public class JaxApi {
    @PROPFIND void custom() {}
    @jakarta.ws.rs.GET void standard() {}
}
""",
        }
        _root, inventory, endpoints, finalized = self.analyzed(
            "late-rejections", files
        )

        self.assertEqual(endpoints, [])
        self.assertEqual(finalized["rows"], [])
        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        ).decode("utf8")
        for annotation, applied_to in (
            ("Read", "method SpringApi.composed()"),
            ("GetMapping", "method Dormant.inactive()"),
            ("PROPFIND", "method JaxApi.custom()"),
            ("GET", "method JaxApi.standard()"),
        ):
            with self.subTest(annotation=annotation):
                self.assertIn(f"Annotation: {annotation}\n", report)
                self.assertIn(f"Applied to: {applied_to}\n", report)

    def test_non_annotation_route_represents_annotated_handler_target(self):
        module_root, inventory, endpoints, finalized = self.analyzed(
            "route-represents-annotation",
            {
                "api/Routes.java": """package api;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.RouterFunctions;
import org.springframework.web.servlet.function.ServerRequest;
import org.springframework.web.servlet.function.ServerResponse;
public class Routes {
    @Bean RouterFunction<ServerResponse> routes() {
        return RouterFunctions.route()
            .POST("/actual", this::handler)
            .build();
    }
    @GetMapping(path = Missing.PATH)
    ServerResponse handler(ServerRequest request) { return null; }
}
"""
            },
            "spring",
        )
        candidate = self.framework_annotations(
            inventory, "api/Routes.java", "spring"
        )[0]

        self.assertEqual(
            [(endpoint["method"], endpoint["uri"], endpoint["SFunction"])
             for endpoint in endpoints],
            [("POST", "/actual", "Routes.handler")],
        )
        self.assert_exact_attribution(
            endpoints[0],
            self.method_target(module_root, "api/Routes.java", "handler"),
        )
        self.assertEqual(
            endpoints[0][noir_sbt.REPRESENTED_TARGETS_KEY],
            (candidate["target"],),
        )
        report = noir_sbt.absent_trigger_report_bytes(
            inventory, finalized["represented_targets"]
        )
        self.assertEqual(
            report,
            b"File: api/Routes.java\n"
            b"Framework: spring\n"
            b"Annotations without endpoints: none\n",
        )


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class ProducerAttributionMatrixTests(AbsentAnnotationTestCase):
    def test_http_interface_feign_and_message_rows_use_contract_or_handler_method(self):
        module_root, _inventory, endpoints, _finalized = self.analyzed(
            "declarative-producers",
            {
                "api/RemoteClient.java": """package api;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;
@HttpExchange("/remote")
public interface RemoteClient {
    @GetExchange("/items") String load();
}
""",
                "api/FeignApi.java": """package api;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
@FeignClient(name = "remote")
public interface FeignApi {
    @PostMapping("/commands") void create(String body);
}
""",
                "api/SocketConfig.java": """package api;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
public class SocketConfig implements WebSocketMessageBrokerConfigurer {
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/socket");
    }
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.setApplicationDestinationPrefixes("/app");
    }
}
""",
                "api/ChatController.java": """package api;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SubscribeMapping;
import org.springframework.stereotype.Controller;
@Controller
public class ChatController {
    @MessageMapping("/send") public void send(String body) {}
    @SubscribeMapping("/watch") public void watch() {}
}
""",
            },
            "spring",
        )

        expected = {
            "RemoteClient.load": self.method_target(
                module_root, "api/RemoteClient.java", "load"
            ),
            "FeignApi.create": self.method_target(
                module_root, "api/FeignApi.java", "create"
            ),
            "SocketConfig.registerStompEndpoints": self.method_target(
                module_root, "api/SocketConfig.java", "registerStompEndpoints"
            ),
            "ChatController.send": self.method_target(
                module_root, "api/ChatController.java", "send"
            ),
            "ChatController.watch": self.method_target(
                module_root, "api/ChatController.java", "watch"
            ),
        }
        self.assertEqual(
            {(endpoint["SFunction"], endpoint["uri"]) for endpoint in endpoints},
            {
                ("RemoteClient.load", "/remote/items"),
                ("FeignApi.create", "/commands"),
                ("SocketConfig.registerStompEndpoints", "/socket"),
                ("ChatController.send", "/app/send"),
                ("ChatController.watch", "/app/watch"),
            },
        )
        for endpoint in endpoints:
            self.assert_exact_attribution(
                endpoint, expected[endpoint["SFunction"]]
            )

    def test_functional_routes_select_handler_and_publisher_fallback(self):
        module_root, _inventory, endpoints, _finalized = self.analyzed(
            "functional-attribution",
            {
                "api/Routes.java": """package api;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.RouterFunctions;
import org.springframework.web.servlet.function.ServerRequest;
import org.springframework.web.servlet.function.ServerResponse;
public class Routes {
    @Bean RouterFunction<ServerResponse> routes() {
        return RouterFunctions.route()
            .GET("/handled", this::handle)
            .POST("/fallback", request -> null)
            .build();
    }
    ServerResponse handle(ServerRequest request) { return null; }
}
"""
            },
            "spring",
        )

        by_uri = {endpoint["uri"]: endpoint for endpoint in endpoints}
        self.assertEqual(set(by_uri), {"/handled", "/fallback"})
        self.assertEqual(by_uri["/handled"]["SFunction"], "Routes.handle")
        self.assertEqual(by_uri["/fallback"]["SFunction"], "Routes.routes")
        self.assert_exact_attribution(
            by_uri["/handled"],
            self.method_target(module_root, "api/Routes.java", "handle"),
        )
        self.assert_exact_attribution(
            by_uri["/fallback"],
            self.method_target(module_root, "api/Routes.java", "routes"),
        )

    def test_gateway_resource_raw_websocket_and_stomp_use_registration_method(self):
        module_root, _inventory, endpoints, _finalized = self.analyzed(
            "programmatic-producers",
            {
                "api/GatewayRoutes.java": """package api;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
public class GatewayRoutes {
    @Bean RouteLocator routes(RouteLocatorBuilder builder) {
        return builder.routes()
            .route("one", route -> route.path("/gateway").uri("no://op"))
            .build();
    }
}
""",
                "api/StaticResources.java": """package api;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
public class StaticResources implements WebMvcConfigurer {
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/assets/**");
    }
}
""",
                "api/RawSocketConfig.java": """package api;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
public class RawSocketConfig implements WebSocketConfigurer {
    private final WebSocketHandler handler = null;
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(handler, "/raw");
    }
}
""",
                "api/StompConfig.java": """package api;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
public class StompConfig implements WebSocketMessageBrokerConfigurer {
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/stomp");
    }
}
""",
            },
            "spring",
        )

        expected = {
            "GatewayRoutes.routes": self.method_target(
                module_root, "api/GatewayRoutes.java", "routes"
            ),
            "StaticResources.addResourceHandlers": self.method_target(
                module_root, "api/StaticResources.java", "addResourceHandlers"
            ),
            "RawSocketConfig.registerWebSocketHandlers": self.method_target(
                module_root,
                "api/RawSocketConfig.java",
                "registerWebSocketHandlers",
            ),
            "StompConfig.registerStompEndpoints": self.method_target(
                module_root, "api/StompConfig.java", "registerStompEndpoints"
            ),
        }
        self.assertEqual(
            {(endpoint["SFunction"], endpoint["uri"]) for endpoint in endpoints},
            {
                ("GatewayRoutes.routes", "/gateway"),
                ("StaticResources.addResourceHandlers", "/assets/**"),
                ("RawSocketConfig.registerWebSocketHandlers", "/raw"),
                ("StompConfig.registerStompEndpoints", "/stomp"),
            },
        )
        for endpoint in endpoints:
            self.assert_exact_attribution(
                endpoint, expected[endpoint["SFunction"]]
            )

    def test_jax_hierarchy_and_subresource_use_effective_implementation_method(self):
        module_root, _inventory, endpoints, _finalized = self.analyzed(
            "jax-effective-implementation",
            {
                "contract/RootContract.java": """package contract;
public interface RootContract {
    @jakarta.ws.rs.GET @jakarta.ws.rs.Path("/inherited")
    void inherited();
}
""",
                "contract/LeafContract.java": """package contract;
public interface LeafContract {
    @jakarta.ws.rs.POST @jakarta.ws.rs.Path("/leaf")
    void leaf();
}
""",
                "api/Root.java": """package api;
import contract.RootContract;
@jakarta.ws.rs.Path("/root")
public class Root implements RootContract {
    public void inherited() {}
    @jakarta.ws.rs.Path("/sub") public Leaf sub() { return null; }
}
""",
                "api/Leaf.java": """package api;
import contract.LeafContract;
public class Leaf implements LeafContract {
    public void leaf() {}
}
""",
            },
            "jaxrx",
        )

        by_function = {endpoint["SFunction"]: endpoint for endpoint in endpoints}
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"], endpoint["SFunction"])
             for endpoint in endpoints},
            {
                ("GET", "/root/inherited", "Root.inherited"),
                ("POST", "/root/sub/leaf", "Leaf.leaf"),
            },
        )
        implementation_targets = {
            "Root.inherited": self.method_target(
                module_root, "api/Root.java", "inherited"
            ),
            "Leaf.leaf": self.method_target(
                module_root, "api/Leaf.java", "leaf"
            ),
        }
        contract_targets = {
            "Root.inherited": self.method_target(
                module_root, "contract/RootContract.java", "inherited"
            ),
            "Leaf.leaf": self.method_target(
                module_root, "contract/LeafContract.java", "leaf"
            ),
        }
        for function, endpoint in by_function.items():
            self.assert_exact_attribution(
                endpoint, implementation_targets[function]
            )
            self.assertNotEqual(
                endpoint[noir_sbt.REPRESENTED_TARGETS_KEY],
                (contract_targets[function],),
            )


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class CompatibilityRegressionTests(AbsentAnnotationTestCase):
    def test_candidate_catalog_is_inert_for_public_csv_inventory_and_diagnostics(self):
        module_root = self.root / "compatibility"
        source_file = module_root / "api" / "Mixed.java"
        source_file.parent.mkdir(parents=True)
        source_file.write_text(
            """package api;
@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/spring")
@jakarta.ws.rs.Path("/jax")
public class Mixed {
    @org.springframework.web.bind.annotation.GetMapping("/ok")
    public void spring() {}

    @jakarta.ws.rs.GET @jakarta.ws.rs.Path("/ok")
    public void jax() {}

    @org.springframework.web.bind.annotation.GetMapping(path = Missing.PATH)
    public void invalidSpring() {}

    @jakarta.ws.rs.POST void hiddenJax() {}
}
""",
            encoding="utf8",
        )

        class FixedNow:
            def strftime(self, _format):
                return "2000-01-01 00:00:00"

        class FixedDateTime:
            @classmethod
            def now(cls):
                return FixedNow()

        def run(*, collect_candidates):
            inventory = []
            candidates = []
            diagnostics = []
            noir_sbt.diagnostic_log_buffer = diagnostics
            with (
                mock.patch.object(noir_sbt, "datetime", FixedDateTime),
                mock.patch("builtins.print"),
            ):
                endpoints = noir_sbt.analyze_module(
                    module_root,
                    annotation_inventory=inventory,
                    absent_trigger_inventory=(
                        candidates if collect_candidates else None
                    ),
                )
            public_endpoints = [
                {
                    key: value
                    for key, value in endpoint.items()
                    if key != noir_sbt.REPRESENTED_TARGETS_KEY
                }
                for endpoint in endpoints
            ]
            formatted = [
                noir_sbt.format_endpoint(endpoint, module_root.name, module_root)
                for endpoint in endpoints
            ]
            rows = noir_sbt.finalize_endpoint_rows(formatted)["rows"]
            return public_endpoints, rows, inventory, diagnostics, candidates

        without_catalog = run(collect_candidates=False)
        with_catalog = run(collect_candidates=True)

        self.assertEqual(without_catalog[:4], with_catalog[:4])
        self.assertTrue(with_catalog[4])
        self.assertTrue(with_catalog[3])
        self.assertTrue(
            all(
                noir_sbt.REPRESENTED_TARGETS_KEY not in row
                for row in with_catalog[1]
            )
        )

        csv_paths = (self.root / "without.csv", self.root / "with.csv")
        log_paths = (self.root / "without.log", self.root / "with.log")
        for index, result in enumerate((without_catalog, with_catalog)):
            noir_sbt.write_csv(csv_paths[index], noir_sbt.CSV_FIELDNAMES, result[1])
            noir_sbt.render_annotation_log(
                log_paths[index], result[2], result[3]
            )

        self.assertEqual(csv_paths[0].read_bytes(), csv_paths[1].read_bytes())
        self.assertEqual(log_paths[0].read_bytes(), log_paths[1].read_bytes())
        self.assertTrue(csv_paths[0].read_bytes().startswith(b"\xef\xbb\xbf"))
        self.assertIn(b"module_name;interface_type;endpoint;", csv_paths[0].read_bytes())
        self.assertIn(b"Annotation: Path", log_paths[0].read_bytes())
        self.assertIn(b"Diagnostics:\n2000-01-01 00:00:00", log_paths[0].read_bytes())


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class AbsentAnnotationCliTests(AbsentAnnotationTestCase):
    def test_cli_uses_global_membership_and_selected_framework_rows(self):
        module_root = self.root / "hybrid"
        source_file = module_root / "api" / "Hybrid.java"
        source_file.parent.mkdir(parents=True)
        source_file.write_text(
            """package api;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import org.springframework.web.bind.annotation.GetMapping;
@Path("/api")
class Hybrid {
    @GetMapping(path = Missing.PATH)
    @GET
    public void same() {}
}
""",
            encoding="utf8",
        )

        both_output = self.root / "both.csv"
        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(
                    ["--path", str(module_root), "--output", str(both_output)]
                ),
                0,
            )
        both_report = Path(
            noir_sbt.derive_absent_trigger_report_path(both_output)
        )
        first_bytes = both_report.read_bytes()
        self.assertIn(b"Framework: spring", first_bytes)
        self.assertIn(b"Framework: jaxrx", first_bytes)
        self.assertEqual(first_bytes.count(b"Annotations without endpoints: none"), 2)
        self.assertNotIn(b"Annotation: GetMapping", first_bytes)

        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(
                    ["--path", str(module_root), "--output", str(both_output)]
                ),
                0,
            )
        self.assertEqual(both_report.read_bytes(), first_bytes)

        spring_output = self.root / "spring.csv"
        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(
                    [
                        "--path",
                        str(module_root),
                        "--output",
                        str(spring_output),
                        "--framework",
                        "spring",
                    ]
                ),
                0,
            )
        spring_report = Path(
            noir_sbt.derive_absent_trigger_report_path(spring_output)
        ).read_bytes()
        self.assertIn(b"Annotation: GetMapping", spring_report)
        self.assertNotIn(b"Framework: jaxrx", spring_report)
        self.assertTrue((Path(f"{spring_output}.log")).exists())

        jax_output = self.root / "jax.csv"
        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(
                    [
                        "--path",
                        str(module_root),
                        "--output",
                        str(jax_output),
                        "--framework",
                        "jaxrx",
                    ]
                ),
                0,
            )
        jax_report = Path(
            noir_sbt.derive_absent_trigger_report_path(jax_output)
        ).read_bytes()
        self.assertIn(b"Framework: jaxrx", jax_report)
        self.assertNotIn(b"Framework: spring", jax_report)
        self.assertNotIn(b"Annotation: GetMapping", jax_report)
        self.assertIn(b"Annotations without endpoints: none", jax_report)

    def test_cli_derives_every_output_filename_form(self):
        empty_root = self.root / "filename-forms"
        empty_root.mkdir()
        outputs = (
            self.root / "endpoints.csv",
            self.root / "endpoints",
            self.root / "endpoints.audit.csv",
        )

        for output in outputs:
            with self.subTest(output=output), mock.patch("builtins.print"):
                self.assertEqual(
                    noir_sbt.main(
                        [
                            "--path",
                            str(empty_root),
                            "--output",
                            str(output),
                            "--framework",
                            "spring",
                        ]
                    ),
                    0,
                )
                self.assertTrue(output.exists())
                self.assertTrue(Path(f"{output}.log").exists())
                self.assertEqual(
                    Path(
                        noir_sbt.derive_absent_trigger_report_path(output)
                    ).read_bytes(),
                    b"",
                )

    def test_cli_successful_rerun_replaces_report_with_only_current_source(self):
        module_root = self.root / "replacement"
        source_file = module_root / "Draft.java"
        source_file.parent.mkdir()
        output = self.root / "replacement.csv"

        source_file.write_text(
            """import org.springframework.web.bind.annotation.GetMapping;
public class Draft {
    @GetMapping(path = Missing.OLD) public void oldRoute() {}
}
""",
            encoding="utf8",
        )
        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(
                    [
                        "--path",
                        str(module_root),
                        "--output",
                        str(output),
                        "--framework",
                        "spring",
                    ]
                ),
                0,
            )
        report = Path(noir_sbt.derive_absent_trigger_report_path(output))
        first = report.read_bytes()
        self.assertIn(b"Annotation: GetMapping", first)
        self.assertIn(b"@GetMapping(path = Missing.OLD)", first)

        source_file.write_text(
            """import org.springframework.web.bind.annotation.PostMapping;
public class Draft {
    @PostMapping(path = Missing.CURRENT) public void currentRoute() {}
}
""",
            encoding="utf8",
        )
        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(
                    [
                        "--path",
                        str(module_root),
                        "--output",
                        str(output),
                        "--framework",
                        "spring",
                    ]
                ),
                0,
            )
        current = report.read_bytes()
        self.assertNotEqual(current, first)
        self.assertIn(b"Annotation: PostMapping", current)
        self.assertIn(b"@PostMapping(path = Missing.CURRENT)", current)
        self.assertNotIn(b"Annotation: GetMapping", current)
        self.assertNotIn(b"@GetMapping(path = Missing.OLD)", current)

    def test_cli_first_publication_failure_leaves_report_absent(self):
        empty_root = self.root / "first-publication-failure"
        empty_root.mkdir()
        output = self.root / "first-publication-failure.csv"
        report = Path(noir_sbt.derive_absent_trigger_report_path(output))

        with (
            mock.patch("builtins.print"),
            mock.patch.object(
                noir_sbt.os,
                "replace",
                side_effect=OSError("replace failed"),
            ),
            self.assertRaisesRegex(OSError, "replace failed"),
        ):
            noir_sbt.main(
                [
                    "--path",
                    str(empty_root),
                    "--output",
                    str(output),
                    "--framework",
                    "spring",
                ]
            )

        self.assertFalse(report.exists())
        self.assertTrue(output.exists())
        self.assertTrue(Path(f"{output}.log").exists())
        self.assertEqual(
            list(report.parent.glob(f".{report.name}.*.tmp")), []
        )

    def test_cli_empty_run_and_publication_failure_boundaries(self):
        empty_root = self.root / "empty"
        empty_root.mkdir()
        output = self.root / "empty.csv"
        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(
                    [
                        "--path",
                        str(empty_root),
                        "--output",
                        str(output),
                        "--framework",
                        "spring",
                    ]
                ),
                0,
            )
        report = Path(noir_sbt.derive_absent_trigger_report_path(output))
        self.assertEqual(report.read_bytes(), b"")

        report.write_bytes(b"previous completed report\n")
        with (
            mock.patch("builtins.print"),
            mock.patch.object(
                noir_sbt,
                "publish_bytes_atomically",
                side_effect=OSError("publication failed"),
            ),
        ):
            with self.assertRaisesRegex(OSError, "publication failed"):
                noir_sbt.main(
                    [
                        "--path",
                        str(empty_root),
                        "--output",
                        str(output),
                        "--framework",
                        "spring",
                    ]
                )
        self.assertEqual(report.read_bytes(), b"previous completed report\n")

    def test_cli_preserves_prior_report_across_prepublication_failure_stages(self):
        module_root = self.root / "failure-module"
        module_root.mkdir()
        stages = (
            ("analysis", "analyze_module"),
            ("finalization", "finalize_endpoint_rows"),
            ("csv", "write_csv"),
            ("companion-log", "render_annotation_log"),
        )
        for stage, function_name in stages:
            with self.subTest(stage=stage):
                output = self.root / f"{stage}.csv"
                report = Path(
                    noir_sbt.derive_absent_trigger_report_path(output)
                )
                previous = f"previous {stage}\n".encode()
                report.write_bytes(previous)
                failure = OSError(f"{stage} failed")
                with (
                    mock.patch("builtins.print"),
                    mock.patch.object(
                        noir_sbt, function_name, side_effect=failure
                    ),
                    mock.patch.object(
                        noir_sbt,
                        "publish_bytes_atomically",
                        wraps=noir_sbt.publish_bytes_atomically,
                    ) as publisher,
                ):
                    with self.assertRaisesRegex(OSError, f"{stage} failed"):
                        noir_sbt.main(
                            [
                                "--path",
                                str(module_root),
                                "--output",
                                str(output),
                                "--framework",
                                "spring",
                            ]
                        )
                publisher.assert_not_called()
                self.assertEqual(report.read_bytes(), previous)
                self.assertEqual(
                    list(report.parent.glob(f".{report.name}.*.tmp")), []
                )


if __name__ == "__main__":
    unittest.main()
