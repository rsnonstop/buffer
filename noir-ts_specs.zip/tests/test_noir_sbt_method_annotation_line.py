from __future__ import annotations

import csv
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_spring_websocket  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)

EXPECTED_CSV_FIELDNAMES = [
    "module_name",
    "interface_type",
    "endpoint",
    "source_file_name",
    "method_name",
    "parameters",
    "method_annotation_line",
]


def source_line(source, token, occurrence=1):
    position = -1
    for _ in range(occurrence):
        position = source.find(token, position + 1)
        if position < 0:
            raise AssertionError(f"source token not found: {token!r}")
    return source.count("\n", 0, position) + 1


class MethodAnnotationEvidenceUnitTests(unittest.TestCase):
    def evidence(self, source_file, line, identity, family=None):
        return noir_sbt.make_method_annotation_evidence(
            line,
            identity,
            family,
            annotation_source_file=source_file,
            endpoint_source_file=source_file,
        )

    def test_schema_configuration_and_evidence_validation(self):
        self.assertEqual(
            noir_sbt.CSV_IDENTITY_FIELDNAMES,
            (
                "module_name",
                "interface_type",
                "endpoint",
                "source_file_name",
                "method_name",
                "parameters",
            ),
        )
        self.assertEqual(noir_sbt.CSV_FIELDNAMES, EXPECTED_CSV_FIELDNAMES)
        with self.assertRaises(TypeError):
            noir_sbt.METHOD_ANNOTATION_FAMILY_PRIORITY[
                noir_sbt.METHOD_ANNOTATION_FAMILY_JAX_RS
            ] = 0
        with self.assertRaises(TypeError):
            noir_sbt.METHOD_ANNOTATION_FAMILY_BY_IDENTITY[
                "example.Mapping"
            ] = noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC

        with tempfile.TemporaryDirectory() as directory:
            source_file = Path(directory) / "Api.java"
            other_file = Path(directory) / "Other.java"
            identity = "org.springframework.web.bind.annotation.GetMapping"
            evidence = self.evidence(source_file, 7, identity)
            self.assertEqual(
                evidence,
                {
                    "line": 7,
                    "identity": identity,
                    "family": noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_VERB,
                    "source_file": os.path.realpath(source_file),
                },
            )
            self.assertTrue(
                all(isinstance(value, (int, str)) for value in evidence.values())
            )

            for invalid_line in (None, True, 0, -1, "7"):
                with self.subTest(invalid_line=invalid_line):
                    self.assertIsNone(
                        noir_sbt.make_method_annotation_evidence(
                            invalid_line,
                            identity,
                            annotation_source_file=source_file,
                            endpoint_source_file=source_file,
                        )
                    )
            self.assertIsNone(
                noir_sbt.make_method_annotation_evidence(
                    7,
                    "not a canonical identity",
                    noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
                    annotation_source_file=source_file,
                    endpoint_source_file=source_file,
                )
            )
            self.assertIsNone(
                noir_sbt.make_method_annotation_evidence(
                    7,
                    identity,
                    noir_sbt.METHOD_ANNOTATION_FAMILY_JAX_RS,
                    annotation_source_file=source_file,
                    endpoint_source_file=source_file,
                )
            )
            self.assertIsNone(
                noir_sbt.make_method_annotation_evidence(
                    7,
                    identity,
                    annotation_source_file=source_file,
                    endpoint_source_file=other_file,
                )
            )

            self.assertIsNone(noir_sbt.method_annotation_family("example.GetMapping"))
            self.assertIsNone(self.evidence(source_file, 8, "example.GetMapping"))
            custom = self.evidence(
                source_file,
                8,
                "example.Read",
                noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
            )
            self.assertEqual(
                custom["family"], noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC
            )

            node = SimpleNamespace(start_point=SimpleNamespace(row=10))
            from_node = noir_sbt.method_annotation_evidence_from_node(
                node,
                identity,
                noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_VERB,
                annotation_source_file=source_file,
                endpoint_source_file=source_file,
            )
            self.assertEqual(from_node[0]["line"], 11)
            self.assertNotIn("node", from_node[0])
            self.assertEqual(
                noir_sbt.method_annotation_evidence_from_mapping(
                    {
                        "annotation_node": node,
                        "annotation_identity": identity,
                        "annotation_family": (
                            noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_VERB
                        ),
                    },
                    annotation_source_file=source_file,
                    endpoint_source_file=source_file,
                ),
                from_node,
            )

    def test_selector_uses_family_line_identity_and_custom_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            source_file = Path(directory) / "Api.java"
            spring = self.evidence(
                source_file,
                20,
                "org.springframework.web.bind.annotation.GetMapping",
            )
            jax = self.evidence(source_file, 2, "jakarta.ws.rs.GET")
            self.assertEqual(
                noir_sbt.select_method_annotation_evidence((jax, spring)), spring
            )

            earlier = self.evidence(
                source_file,
                4,
                "example.ZRoute",
                noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
            )
            later = self.evidence(
                source_file,
                5,
                "example.ARoute",
                noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
            )
            self.assertEqual(
                noir_sbt.select_method_annotation_evidence((later, earlier)), earlier
            )

            same_line_z = self.evidence(
                source_file,
                9,
                "example.ZRoute",
                noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
            )
            same_line_a = self.evidence(
                source_file,
                9,
                "example.ARoute",
                noir_sbt.METHOD_ANNOTATION_FAMILY_SPRING_GENERIC,
            )
            self.assertEqual(
                noir_sbt.select_method_annotation_evidence(
                    (same_line_z, same_line_a)
                ),
                same_line_a,
            )
            self.assertEqual(
                noir_sbt.select_method_annotation_evidence((jax, later)), later
            )
            self.assertIsNone(
                noir_sbt.select_method_annotation_evidence(
                    ({"line": 1, "identity": "example.GetMapping"},)
                )
            )

    def test_deduplication_merges_evidence_on_the_legacy_six_field_key(self):
        with tempfile.TemporaryDirectory() as directory:
            source_file = Path(directory) / "Api.java"
            base = {
                "module_name": "app",
                "interface_type": "http GET",
                "source_file_name": "Api.java",
                "method_name": "Api.same",
                "parameters": "",
            }
            jax = self.evidence(source_file, 2, "jakarta.ws.rs.GET")
            spring = self.evidence(
                source_file,
                20,
                "org.springframework.web.bind.annotation.GetMapping",
            )
            other = self.evidence(
                source_file,
                1,
                "org.springframework.web.bind.annotation.RequestMapping",
            )
            candidates = [
                {
                    **base,
                    "endpoint": "/a",
                    noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (jax,),
                },
                {**base, "endpoint": "/a"},
                {
                    **base,
                    "endpoint": "/a",
                    noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (spring,),
                },
                {
                    **base,
                    "endpoint": "/b",
                    noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (other,),
                },
            ]
            rows = noir_sbt.deduplicate_and_sort_rows(candidates)
            self.assertEqual([row["endpoint"] for row in rows], ["/a", "/b"])
            self.assertEqual(
                [row["method_annotation_line"] for row in rows], ["20", "1"]
            )
            self.assertEqual(
                [tuple(row[field] for field in noir_sbt.CSV_IDENTITY_FIELDNAMES)
                 for row in rows],
                [
                    ("app", "http GET", "/a", "Api.java", "Api.same", ""),
                    ("app", "http GET", "/b", "Api.java", "Api.same", ""),
                ],
            )
            self.assertTrue(all(list(row) == EXPECTED_CSV_FIELDNAMES for row in rows))
            self.assertEqual(
                noir_sbt.deduplicate_and_sort_rows(reversed(candidates)), rows
            )

    def test_internal_deduplication_preserves_last_candidate_metadata(self):
        with tempfile.TemporaryDirectory() as directory:
            source_file = Path(directory) / "Api.java"
            first_evidence = self.evidence(
                source_file,
                10,
                "org.springframework.messaging.handler.annotation.MessageMapping",
            )
            last_evidence = self.evidence(
                source_file,
                20,
                "org.springframework.messaging.handler.annotation.SubscribeMapping",
            )
            base = {
                "protocol": "ws",
                "surface": "message",
                "method": "SEND",
                "uri": "/same",
                "SrcFile": str(source_file),
                "SFunction": "Api.handle",
                "uri_params": "",
            }
            first = {
                **base,
                "SrcLine": 10,
                "RouteSrcLine": 10,
                "first_only": "discarded",
                noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (first_evidence,),
            }
            last = {
                **base,
                "SrcLine": 20,
                "RouteSrcLine": 20,
                "last_only": "retained",
                noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (last_evidence,),
            }
            first_before = dict(first)
            last_before = dict(last)

            rows = noir_sbt_spring_websocket._deduplicate(
                [first, last], noir_sbt
            )

            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["SrcLine"], 20)
            self.assertEqual(rows[0]["RouteSrcLine"], 20)
            self.assertNotIn("first_only", rows[0])
            self.assertEqual(rows[0]["last_only"], "retained")
            self.assertEqual(
                [
                    evidence["line"]
                    for evidence in rows[0][
                        noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY
                    ]
                ],
                [10, 20],
            )
            self.assertEqual(
                noir_sbt.select_method_annotation_evidence(
                    rows[0][noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY]
                )["line"],
                10,
            )
            self.assertEqual(first, first_before)
            self.assertEqual(last, last_before)

            unannotated_last = {
                **base,
                "SrcLine": 30,
                "RouteSrcLine": 30,
                noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY: (),
            }
            merged = noir_sbt.merge_endpoint_method_annotation_evidence(
                rows[0], unannotated_last
            )
            self.assertEqual(merged["SrcLine"], 30)
            self.assertNotIn("last_only", merged)
            self.assertEqual(
                [
                    evidence["line"]
                    for evidence in merged[
                        noir_sbt.METHOD_ANNOTATION_EVIDENCE_KEY
                    ]
                ],
                [10, 20],
            )


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class MethodAnnotationLineIntegrationTests(unittest.TestCase):
    def setUp(self):
        self._old_globals = (
            noir_sbt.log_file,
            noir_sbt.input_srcdir,
            noir_sbt.module_name,
            noir_sbt.diagnostic_log_buffer,
        )
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")
        noir_sbt.diagnostic_log_buffer = None

    def tearDown(self):
        (
            noir_sbt.log_file,
            noir_sbt.input_srcdir,
            noir_sbt.module_name,
            noir_sbt.diagnostic_log_buffer,
        ) = self._old_globals
        self._temporary_directory.cleanup()

    def write_module(self, name, files):
        module_root = self.root / name
        for relative_name, source in files.items():
            target = module_root / relative_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(source, encoding="utf8")
        return module_root

    def analyze_rows(self, module_root, framework=None):
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        with mock.patch("builtins.print"):
            endpoints = noir_sbt.analyze_module(module_root, framework)
        return noir_sbt.deduplicate_and_sort_rows(
            [
                noir_sbt.format_endpoint(endpoint, module_root.name, module_root)
                for endpoint in endpoints
            ]
        )

    def cli_rows(self, module_root, label):
        output = self.root / f"{label}.csv"
        with mock.patch("builtins.print"):
            self.assertEqual(
                noir_sbt.main(["--path", str(module_root), "--output", str(output)]),
                0,
            )
        raw = output.read_bytes()
        with output.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream, delimiter=";")
            rows = list(reader)
            self.assertEqual(reader.fieldnames, EXPECTED_CSV_FIELDNAMES)
        return raw, rows

    def test_direct_composed_custom_fanout_and_priority_reach_csv(self):
        read_source = """
            package annotations;
            import java.lang.annotation.ElementType;
            import java.lang.annotation.Retention;
            import java.lang.annotation.RetentionPolicy;
            import java.lang.annotation.Target;
            import org.springframework.core.annotation.AliasFor;
            import org.springframework.web.bind.annotation.RequestMapping;
            import org.springframework.web.bind.annotation.RequestMethod;
            @Target(ElementType.METHOD)
            @Retention(RetentionPolicy.RUNTIME)
            @RequestMapping(method = RequestMethod.GET)
            public @interface Read {
                @AliasFor(annotation = RequestMapping.class, attribute = "path")
                String[] path() default {};
            }
        """
        propfind_source = """
            package designators;
            @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
            @java.lang.annotation.Retention(
                java.lang.annotation.RetentionPolicy.RUNTIME
            )
            @jakarta.ws.rs.HttpMethod("PROPFIND")
            public @interface PROPFIND {}
        """
        api_source = """
            package api;
            import annotations.Read;
            import designators.PROPFIND;

            @org.springframework.web.bind.annotation.RequestMapping("/api")
            @jakarta.ws.rs.Path("/api")
            public class Api {
                @org.springframework.web.bind.annotation.RequestMapping
                public void index() {}

                @org.springframework.web.bind.annotation.GetMapping(
                    path = {"/hello", "/hi"}
                )
                public void hello() {}

                @Read(path = "/composed")
                public void composed() {}

                @jakarta.ws.rs.GET
                @jakarta.ws.rs.Path("/jax")
                public void jax() {}

                @PROPFIND
                @jakarta.ws.rs.Path("/dav")
                public void dav() {}

                @jakarta.ws.rs.GET
                @org.springframework.web.bind.annotation.GetMapping("/both")
                @jakarta.ws.rs.Path("/both")
                public void both() {}
            }
        """
        module_root = self.write_module(
            "direct-provenance",
            {
                "annotations/Read.java": read_source,
                "designators/PROPFIND.java": propfind_source,
                "api/Api.java": api_source,
            },
        )

        first_bytes, rows = self.cli_rows(module_root, "direct-first")
        second_bytes, repeated_rows = self.cli_rows(module_root, "direct-second")
        self.assertEqual(first_bytes, second_bytes)
        self.assertEqual(rows, repeated_rows)
        self.assertTrue(first_bytes.startswith(b"\xef\xbb\xbf"))
        self.assertEqual(len(rows), 7)

        by_endpoint = {row["endpoint"]: row for row in rows}
        index_line = str(
            source_line(
                api_source,
                "@org.springframework.web.bind.annotation.RequestMapping\n",
            )
        )
        get_line = str(
            source_line(
                api_source,
                "@org.springframework.web.bind.annotation.GetMapping(\n",
            )
        )
        self.assertEqual(by_endpoint["/api"]["method_annotation_line"], index_line)
        self.assertNotEqual(
            index_line,
            str(
                source_line(
                    api_source,
                    '@org.springframework.web.bind.annotation.RequestMapping("/api")',
                )
            ),
        )
        self.assertNotEqual(index_line, str(source_line(api_source, "void index")))
        self.assertEqual(
            {
                by_endpoint["/api/hello"]["method_annotation_line"],
                by_endpoint["/api/hi"]["method_annotation_line"],
            },
            {get_line},
        )
        self.assertEqual(
            by_endpoint["/api/composed"]["method_annotation_line"],
            str(source_line(api_source, '@Read(path = "/composed")')),
        )
        self.assertEqual(
            by_endpoint["/api/jax"]["method_annotation_line"],
            str(source_line(api_source, "@jakarta.ws.rs.GET", occurrence=1)),
        )
        self.assertEqual(
            by_endpoint["/api/dav"]["method_annotation_line"],
            str(source_line(api_source, "@PROPFIND")),
        )
        self.assertEqual(
            by_endpoint["/api/both"]["method_annotation_line"],
            str(
                source_line(
                    api_source,
                    '@org.springframework.web.bind.annotation.GetMapping("/both")',
                )
            ),
        )
        self.assertNotEqual(
            by_endpoint["/api/both"]["method_annotation_line"],
            str(source_line(api_source, "@jakarta.ws.rs.GET", occurrence=2)),
        )

    def test_http_clients_and_message_mappings_use_method_occurrences(self):
        client_source = """
            package api;
            import org.springframework.web.service.annotation.GetExchange;
            import org.springframework.web.service.annotation.HttpExchange;
            @HttpExchange("/remote")
            public interface RemoteClient {
                @GetExchange(
                    url = {"/items", "/archive"}
                )
                String load();
            }
        """
        message_source = """
            package api;
            import org.springframework.messaging.handler.annotation.MessageMapping;
            import org.springframework.messaging.handler.annotation.SubscribeMapping;
            import org.springframework.stereotype.Controller;
            @Controller
            @MessageMapping("/chat")
            public class ChatController {
                @Deprecated
                @MessageMapping({"/send", "/broadcast"})
                public void send(String payload) {}

                @SubscribeMapping("/presence")
                public void presence() {}
            }
        """
        config_source = """
            package api;
            import org.springframework.messaging.simp.config.MessageBrokerRegistry;
            import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
            import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
            public class SocketConfig implements WebSocketMessageBrokerConfigurer {
                public void registerStompEndpoints(StompEndpointRegistry registry) {
                    registry.addEndpoint("/socket");
                }
                public void configureMessageBroker(MessageBrokerRegistry registry) {
                    registry.setApplicationDestinationPrefixes("/app");
                }
            }
        """
        module_root = self.write_module(
            "client-message-provenance",
            {
                "api/RemoteClient.java": client_source,
                "api/ChatController.java": message_source,
                "api/SocketConfig.java": config_source,
            },
        )
        rows = self.analyze_rows(module_root, "spring")

        client_rows = [row for row in rows if row["method_name"] == "RemoteClient.load"]
        self.assertEqual(
            {(row["interface_type"], row["endpoint"]) for row in client_rows},
            {
                ("http-client GET", "/remote/items"),
                ("http-client GET", "/remote/archive"),
            },
        )
        self.assertEqual(
            {row["method_annotation_line"] for row in client_rows},
            {str(source_line(client_source, "@GetExchange(\n"))},
        )
        self.assertNotIn(
            str(source_line(client_source, '@HttpExchange("/remote")')),
            {row["method_annotation_line"] for row in client_rows},
        )

        message_rows = [
            row for row in rows if row["method_name"] == "ChatController.send"
        ]
        self.assertEqual(
            {row["endpoint"] for row in message_rows},
            {"/app/chat/send", "/app/chat/broadcast"},
        )
        self.assertEqual(
            {row["method_annotation_line"] for row in message_rows},
            {str(source_line(message_source, '@MessageMapping({"/send", "/broadcast"})'))},
        )
        presence = next(
            row for row in rows if row["method_name"] == "ChatController.presence"
        )
        self.assertEqual(
            presence["method_annotation_line"],
            str(source_line(message_source, '@SubscribeMapping("/presence")')),
        )
        handshake = next(
            row
            for row in rows
            if row["method_name"] == "SocketConfig.registerStompEndpoints"
        )
        self.assertEqual(handshake["method_annotation_line"], "")

    def test_inherited_record_type_and_non_annotation_routes_are_empty(self):
        contract_source = """
            package contract;
            public interface Contract {
                @org.springframework.web.bind.annotation.GetMapping("/inherited")
                void inherited();
            }
        """
        controller_source = """
            package api;
            import contract.Contract;
            @org.springframework.web.bind.annotation.RestController
            public class Controller implements Contract {
                public void inherited() {}

                @Deprecated
                @org.springframework.web.bind.annotation.GetMapping("/direct")
                public void direct() {}
            }
        """
        record_source = """
            package api;
            @org.springframework.web.bind.annotation.RestController
            @org.springframework.web.bind.annotation.RequestMapping("/records")
            public record ComponentController(
                @org.springframework.web.bind.annotation.GetMapping("/component")
                String component
            ) {}
        """
        functional_source = """
            package api;
            import org.springframework.context.annotation.Bean;
            import org.springframework.web.servlet.function.RouterFunction;
            import org.springframework.web.servlet.function.RouterFunctions;
            import org.springframework.web.servlet.function.ServerRequest;
            import org.springframework.web.servlet.function.ServerResponse;
            public class FunctionalRoutes {
                @Bean
                RouterFunction<ServerResponse> routes() {
                    return RouterFunctions.route()
                        .GET("/functional", this::handle)
                        .build();
                }
                ServerResponse handle(ServerRequest request) { return null; }
            }
        """
        gateway_source = """
            package api;
            import org.springframework.cloud.gateway.route.RouteLocator;
            import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
            import org.springframework.context.annotation.Bean;
            public class GatewayRoutes {
                @Bean
                RouteLocator routes(RouteLocatorBuilder builder) {
                    return builder.routes().route("one", route ->
                        route.path("/gateway").uri("no://op")).build();
                }
            }
        """
        websocket_source = """
            package api;
            @jakarta.websocket.server.ServerEndpoint("/socket")
            public class Socket {}
        """
        module_root = self.write_module(
            "negative-provenance",
            {
                "contract/Contract.java": contract_source,
                "api/Controller.java": controller_source,
                "api/ComponentController.java": record_source,
                "api/FunctionalRoutes.java": functional_source,
                "api/GatewayRoutes.java": gateway_source,
                "api/Socket.java": websocket_source,
            },
        )
        rows = self.analyze_rows(module_root)
        by_method = {row["method_name"]: row for row in rows}
        self.assertEqual(
            set(by_method),
            {
                "Controller.inherited",
                "Controller.direct",
                "ComponentController.component",
                "FunctionalRoutes.handle",
                "GatewayRoutes.routes",
                "Socket",
            },
        )
        self.assertEqual(
            by_method["Controller.direct"]["method_annotation_line"],
            str(
                source_line(
                    controller_source,
                    '@org.springframework.web.bind.annotation.GetMapping("/direct")',
                )
            ),
        )
        for method_name in set(by_method) - {"Controller.direct"}:
            with self.subTest(method_name=method_name):
                self.assertEqual(by_method[method_name]["method_annotation_line"], "")


if __name__ == "__main__":
    unittest.main()
