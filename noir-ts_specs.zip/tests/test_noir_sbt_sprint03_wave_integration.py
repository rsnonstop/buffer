from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class Sprint03SelectedWaveIntegrationTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name) / "app"
        noir_sbt.log_file = str(self.root.parent / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def write(self, relative_name, source):
        target = self.root / relative_name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(source, encoding="utf8")

    @staticmethod
    def keys(endpoints):
        return {
            (
                endpoint.get("protocol", "http"),
                endpoint["method"],
                endpoint["uri"],
                endpoint["SFunction"],
            )
            for endpoint in endpoints
        }

    def test_03_gen_003_selected_wave_composes_once_and_is_deterministic(self):
        self.write(
            "src/main/resources/application.properties",
            "server.servlet.context-path=/svc\nleaf=items\n",
        )
        self.write(
            "contracts/src/main/java/contract/Contract.java",
            """
                package contract;
                import org.springframework.web.bind.annotation.GetMapping;
                public interface Contract {
                    @GetMapping("/inherited/${leaf}") void inherited();
                }
            """,
        )
        self.write(
            "contracts/src/main/resources/application.properties",
            "server.servlet.context-path=/contract\nleaf=wrong-contract\n",
        )
        self.write(
            "src/main/java/api/Controller.java",
            """
                package api;
                import contract.Contract;
                import org.springframework.web.bind.annotation.*;
                @RestController @RequestMapping("/api")
                public class Controller implements Contract {
                    public void inherited() {}
                    @GetMapping("/direct/${leaf}") public void direct() {}
                    @WaveRead(path = "/alias/${leaf}") public void alias() {}
                }
            """,
        )
        self.write(
            "src/main/java/api/WaveRead.java",
            """
                package api;
                import java.lang.annotation.*;
                import org.springframework.core.annotation.AliasFor;
                import org.springframework.web.bind.annotation.*;
                @Retention(RetentionPolicy.RUNTIME)
                @RequestMapping(method = RequestMethod.GET)
                public @interface WaveRead {
                    @AliasFor("path") String[] value() default {};
                    @AliasFor("value") String[] path() default {};
                }
            """,
        )
        self.write(
            "src/main/java/api/GatewayRoutes.java",
            """
                package api;
                import org.springframework.cloud.gateway.route.RouteLocator;
                import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
                import org.springframework.context.annotation.Bean;
                public class GatewayRoutes {
                    @Bean RouteLocator routes(RouteLocatorBuilder builder) {
                        return builder.routes().route("one", r ->
                            r.path("/proxy/${leaf}").uri("no://op")).build();
                    }
                }
            """,
        )
        self.write(
            "src/main/java/api/FunctionalRoutes.java",
            """
                package api;
                import org.springframework.context.annotation.Bean;
                import org.springframework.web.servlet.function.*;
                public class FunctionalRoutes {
                    @Bean RouterFunction<ServerResponse> routes() {
                        return RouterFunctions.route()
                            .GET("/functional/${leaf}", this::handle)
                            .build();
                    }
                    ServerResponse handle(ServerRequest request) { return null; }
                }
            """,
        )
        self.write(
            "library/src/main/java/handlers/RegisteredHandler.java",
            """
                package handlers;
                public class RegisteredHandler {
                    public void save(String body) {}
                }
            """,
        )
        self.write(
            "library/src/main/resources/application.properties",
            "server.servlet.context-path=/handler\nleaf=wrong-handler\n",
        )
        self.write(
            "src/main/java/api/Registration.java",
            """
                package api;
                import handlers.RegisteredHandler;
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.context.annotation.Configuration;
                import org.springframework.web.bind.annotation.RequestMethod;
                import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
                import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
                @Configuration
                public class Registration {
                    @Autowired void register(
                        RequestMappingHandlerMapping mapping,
                        RegisteredHandler handler
                    ) throws NoSuchMethodException {
                        mapping.registerMapping(
                            RequestMappingInfo.paths("/registered/${leaf}")
                                .methods(RequestMethod.POST).build(),
                            handler,
                            RegisteredHandler.class.getMethod("save", String.class)
                        );
                    }
                }
            """,
        )
        self.write(
            "src/main/java/api/Resources.java",
            """
                package api;
                import org.springframework.web.servlet.config.annotation.*;
                public class Resources implements WebMvcConfigurer {
                    @Override public void addResourceHandlers(ResourceHandlerRegistry registry) {
                        registry.addResourceHandler("/assets/${leaf}/**");
                    }
                }
            """,
        )
        self.write(
            "src/main/java/api/Socket.java",
            """
                package api;
                @jakarta.websocket.server.ServerEndpoint("/socket")
                public class Socket {}
            """,
        )

        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        with mock.patch("builtins.print"):
            first = noir_sbt.analyze_module(self.root)
            second = noir_sbt.analyze_module(self.root)
            spring_only = noir_sbt.analyze_module(self.root, "spring")
            jax_only = noir_sbt.analyze_module(self.root, "jaxrx")

        expected = {
            ("http", "GET", "/svc/api/direct/items", "Controller.direct"),
            ("http", "GET", "/svc/api/alias/items", "Controller.alias"),
            ("http", "GET", "/svc/api/inherited/items", "Controller.inherited"),
            ("http", "ANY", "/svc/proxy/items", "GatewayRoutes.routes"),
            ("http", "GET", "/svc/functional/items", "FunctionalRoutes.handle"),
            ("http", "POST", "/svc/registered/items", "RegisteredHandler.save"),
            (
                "http",
                "GET",
                "/svc/assets/items/**",
                "Resources.addResourceHandlers",
            ),
            ("ws", "GET", "/socket", "Socket"),
        }
        self.assertEqual(self.keys(first), expected)
        self.assertEqual(len(first), len(expected))
        self.assertEqual(first, second)
        self.assertEqual(
            self.keys(spring_only),
            {endpoint for endpoint in expected if endpoint[0] == "http"},
        )
        self.assertEqual(
            self.keys(jax_only),
            {endpoint for endpoint in expected if endpoint[0] == "ws"},
        )
        rows = noir_sbt.deduplicate_and_sort_rows(
            [
                noir_sbt.format_endpoint(endpoint, "app", self.root)
                for endpoint in first
            ]
        )
        self.assertEqual(len(rows), len(expected))
        self.assertEqual(
            {row["interface_type"] for row in rows},
            {
                "http GET",
                "http POST",
                "http-gateway ANY",
                "http-static-handler GET",
                "ws GET",
            },
        )


if __name__ == "__main__":
    unittest.main()
