from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_spring_hierarchy  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class SpringHierarchyAndAliasTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runtime = noir_sbt.build_jax_runtime()
        cls.spring_runtime = noir_sbt.build_spring_runtime()

    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def workspace(self, files):
        source_by_file = {
            str(self.root / relative_name): source.encode("utf8")
            for relative_name, source in files.items()
        }
        return noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=self.runtime,
            include_jax=False,
        )

    def hierarchy(self, files):
        workspace = self.workspace(files)
        return workspace, noir_sbt_spring_hierarchy.analyze_spring_hierarchy(
            workspace, noir_sbt
        )

    def direct(self, workspace):
        endpoints = []
        for file_name, unit in sorted(workspace["units"].items()):
            endpoints.extend(
                noir_sbt.SpringBoot_Analyzer(
                    file_name,
                    unit["source"],
                    runtime=self.spring_runtime,
                    workspace=workspace,
                )
            )
        return endpoints

    @staticmethod
    def keys(endpoints):
        return {
            (
                endpoint["method"],
                endpoint["uri"],
                endpoint["SFunction"],
                endpoint["uri_params"],
            )
            for endpoint in endpoints
        }

    def test_03_spr_inh_001_transitive_generic_interface_and_abstract_base(self):
        files = {
            "contract/Base.java": """
                package contract;
                import org.springframework.web.bind.annotation.*;
                @RequestMapping("/contract")
                public interface Base<T> {
                    @GetMapping("/item") T item(T value);
                    @DeleteMapping("/number") void change(long value);
                    @PostMapping("/text") void change(String value);
                }
            """,
            "contract/Mid.java": """
                package contract;
                public interface Mid<U> extends Base<U> {}
            """,
            "api/AbstractApi.java": """
                package api;
                import org.springframework.web.bind.annotation.*;
                public abstract class AbstractApi {
                    @PutMapping("/base") public abstract void base();
                }
            """,
            "api/Controller.java": """
                package api;
                import contract.Mid;
                import org.springframework.web.bind.annotation.*;
                @RestController @RequestMapping("/api")
                public class Controller extends AbstractApi implements Mid<String> {
                    @Override public String item(String value) { return value; }
                    @Override public void change(long value) {}
                    @Override public void change(String value) {}
                    @Override public void base() {}
                }
            """,
        }
        workspace, additions = self.hierarchy(files)

        self.assertEqual(
            self.keys(additions),
            {
                ("GET", "/api/contract/item", "Controller.item", "String value"),
                ("DELETE", "/api/contract/number", "Controller.change", "long value"),
                ("POST", "/api/contract/text", "Controller.change", "String value"),
                ("PUT", "/api/base", "Controller.base", ""),
            },
        )
        self.assertEqual(self.direct(workspace), [])
        self.assertEqual({item["technology"] for item in additions}, {"spring"})
        self.assertEqual({item["protocol"] for item in additions}, {"http"})
        self.assertEqual({item["surface"] for item in additions}, {"server"})
        self.assertEqual({item["direction"] for item in additions}, {"inbound"})
        self.assertTrue(
            all(item["SrcFile"].endswith("api/Controller.java") for item in additions)
        )

    def test_host_runs_spring_hierarchy_additions_once(self):
        files = {
            "contract/Contract.java": """
                package contract;
                import org.springframework.web.bind.annotation.GetMapping;
                public interface Contract {
                    @GetMapping("/inherited") void inherited();
                }
            """,
            "api/Controller.java": """
                package api;
                import contract.Contract;
                import org.springframework.web.bind.annotation.*;
                @RestController @RequestMapping("/api")
                public class Controller implements Contract {
                    public void inherited() {}
                    @PostMapping("/direct") public void direct() {}
                }
            """,
        }
        for relative_name, source in files.items():
            target = self.root / relative_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(source, encoding="utf8")

        endpoints = noir_sbt.analyze_module(self.root, "spring")

        self.assertEqual(
            self.keys(endpoints),
            {
                ("GET", "/api/inherited", "Controller.inherited", ""),
                ("POST", "/api/direct", "Controller.direct", ""),
            },
        )
        self.assertEqual(len(endpoints), 2)

    def test_03_spr_inh_002_signature_precedence_suppression_and_diamond(self):
        _workspace, additions = self.hierarchy(
            {
                "contract/Parent.java": """
                    package contract;
                    import org.springframework.web.bind.annotation.*;
                    public interface Parent {
                        @GetMapping("/parent") void selected();
                        @GetMapping("/diamond") void diamond();
                    }
                """,
                "contract/Child.java": """
                    package contract;
                    import org.springframework.web.bind.annotation.*;
                    public interface Child extends Parent {
                        @PostMapping("/child") void selected();
                    }
                """,
                "contract/Other.java": """
                    package contract;
                    public interface Other extends Parent {}
                """,
                "contract/Numbers.java": """
                    package contract;
                    import org.springframework.web.bind.annotation.*;
                    public interface Numbers {
                        @DeleteMapping("/long") void update(long value);
                        @PostMapping("/text") void update(String value);
                        @GetMapping("/shadowed") void shadowed();
                    }
                """,
                "api/AbstractApi.java": """
                    package api;
                    import org.springframework.web.bind.annotation.*;
                    public abstract class AbstractApi {
                        @PatchMapping("/super") public abstract void chosen();
                    }
                """,
                "contract/Conflicting.java": """
                    package contract;
                    import org.springframework.web.bind.annotation.*;
                    public interface Conflicting {
                        @PutMapping("/interface") void chosen();
                    }
                """,
                "api/Controller.java": """
                    package api;
                    import contract.*;
                    import org.springframework.web.bind.annotation.*;
                    @RestController @RequestMapping("/api")
                    public class Controller extends AbstractApi
                            implements Child, Other, Numbers, Conflicting {
                        public void selected() {}
                        public void diamond() {}
                        public void update(long value) {}
                        public void update(String value) {}
                        @GetMapping("/direct") public void shadowed() {}
                        public void chosen() {}
                    }
                """,
            }
        )

        self.assertEqual(
            self.keys(additions),
            {
                ("POST", "/api/child", "Controller.selected", ""),
                ("GET", "/api/diamond", "Controller.diamond", ""),
                ("DELETE", "/api/long", "Controller.update", "long value"),
                ("POST", "/api/text", "Controller.update", "String value"),
                ("PATCH", "/api/super", "Controller.chosen", ""),
            },
        )
        self.assertNotIn(
            ("GET", "/api/shadowed", "Controller.shadowed", ""),
            self.keys(additions),
        )

    def test_03_spr_inh_003_invalid_graphs_fail_closed_but_direct_survives(self):
        files = {
            "fake/RestController.java": """
                package fake;
                public @interface RestController {}
            """,
            "contract/A.java": """
                package contract;
                import org.springframework.web.bind.annotation.*;
                public interface A { @GetMapping("/a") void clash(); }
            """,
            "contract/B.java": """
                package contract;
                import org.springframework.web.bind.annotation.*;
                public interface B { @PostMapping("/b") void clash(); }
            """,
            "api/Ambiguous.java": """
                package api;
                import contract.*;
                import org.springframework.web.bind.annotation.*;
                @RestController
                public class Ambiguous implements A, B {
                    public void clash() {}
                    @GetMapping("/direct") public void direct() {}
                }
            """,
            "api/Missing.java": """
                package api;
                import missing.Contract;
                @org.springframework.web.bind.annotation.RestController
                public class Missing implements Contract {
                    public void absent() {}
                }
            """,
            "api/Fake.java": """
                package api;
                import fake.RestController;
                import contract.A;
                @RestController public class Fake implements A {
                    public void clash() {}
                }
            """,
        }
        workspace, additions = self.hierarchy(files)

        self.assertEqual(additions, [])
        self.assertEqual(
            self.keys(self.direct(workspace)),
            {("GET", "/direct", "Ambiguous.direct", "")},
        )
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("Skipped Spring hierarchy", diagnostic)

    def test_03_spr_inh_004_lexical_outer_is_not_a_contract_prefix(self):
        _workspace, additions = self.hierarchy(
            {
                "contract/Contract.java": """
                    package contract;
                    import org.springframework.web.bind.annotation.*;
                    @RequestMapping("/contract")
                    public interface Contract {
                        @GetMapping("/item") void item();
                    }
                """,
                "api/Outer.java": """
                    package api;
                    import contract.Contract;
                    import org.springframework.web.bind.annotation.*;
                    @RequestMapping("/lexical-only")
                    public class Outer {
                        @RestController @RequestMapping("/actual")
                        public static class Nested implements Contract {
                            public void item() {}
                        }
                    }
                """,
            }
        )

        self.assertEqual(
            self.keys(additions),
            {("GET", "/actual/contract/item", "Outer.Nested.item", "")},
        )

    def test_03_spr_alias_001_direct_and_local_alias_agreement(self):
        workspace = self.workspace(
            {
                "annotations/LocalRead.java": """
                    package annotations;
                    import java.lang.annotation.*;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.*;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface LocalRead {
                        @AliasFor("path") String[] value() default {};
                        @AliasFor("value") String[] path() default {};
                    }
                """,
                "annotations/ImplicitRead.java": """
                    package annotations;
                    import java.lang.annotation.*;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.*;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface ImplicitRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {"/default"};
                        @AliasFor(annotation = RequestMapping.class, attribute = "value")
                        String[] value() default {"/default"};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.*;
                    import org.springframework.web.bind.annotation.*;
                    class Api {
                        @GetMapping(path = "/direct", value = "/direct")
                        void direct() {}
                        @LocalRead(path = "/local") void local() {}
                        @ImplicitRead(route = "/explicit") void explicit() {}
                    }
                """,
            }
        )

        self.assertEqual(
            self.keys(self.direct(workspace)),
            {
                ("GET", "/direct", "Api.direct", ""),
                ("GET", "/local", "Api.local", ""),
                ("GET", "/explicit", "Api.explicit", ""),
            },
        )

    def test_03_spr_alias_002_conflicts_and_invalid_local_graphs_skip(self):
        workspace = self.workspace(
            {
                "annotations/BadDefaults.java": """
                    package annotations;
                    import java.lang.annotation.*;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.*;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface BadDefaults {
                        @AliasFor("path") String[] value() default {"/a"};
                        @AliasFor("value") String[] path() default {"/b"};
                    }
                """,
                "annotations/OneWay.java": """
                    package annotations;
                    import java.lang.annotation.*;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.*;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface OneWay {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                        @AliasFor("route") String[] alternate() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.*;
                    import org.springframework.web.bind.annotation.*;
                    class Api {
                        @GetMapping(path = "/left", value = "/right")
                        void directConflict() {}
                        @BadDefaults void badDefaults() {}
                        @OneWay(alternate = "/one-way") void oneWay() {}
                    }
                """,
            }
        )

        self.assertEqual(self.direct(workspace), [])
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("Skipped unresolved Spring path", diagnostic)
        self.assertIn("Skipped invalid Spring composed mapping", diagnostic)


if __name__ == "__main__":
    unittest.main()
