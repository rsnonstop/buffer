from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


class GeneralBehaviorTests(unittest.TestCase):
    def test_import_is_side_effect_free_and_main_is_exposed(self):
        self.assertTrue(callable(noir_sbt.main))

    def test_unsupported_tree_sitter_pair_is_rejected_before_analysis(self):
        unsupported_pairs = (
            {"tree-sitter": "0.26.0", "tree-sitter-java": "0.23.5"},
            {"tree-sitter": "0.25.2", "tree-sitter-java": "0.24.0"},
        )
        for versions in unsupported_pairs:
            with (
                self.subTest(versions=versions),
                mock.patch.multiple(
                    noir_sbt,
                    tsjava=object(),
                    Language=object(),
                    Parser=object(),
                    Query=object(),
                    QueryCursor=object(),
                ),
                mock.patch.object(
                    noir_sbt.metadata,
                    "version",
                    side_effect=lambda name: versions[name],
                ),
            ):
                with self.assertRaisesRegex(RuntimeError, "unsupported.*0.25.2"):
                    noir_sbt.require_tree_sitter()

    def test_supported_tree_sitter_version_passes_dependency_gate(self):
        versions = {
            "tree-sitter": "0.25.2",
            "tree-sitter-java": "0.23.5",
        }
        with (
            mock.patch.multiple(
                noir_sbt,
                tsjava=object(),
                Language=object(),
                Parser=object(),
                Query=object(),
                QueryCursor=object(),
            ),
            mock.patch.object(
                noir_sbt.metadata, "version", side_effect=lambda name: versions[name]
            ),
        ):
            self.assertIsNone(noir_sbt.require_tree_sitter())

    def test_unverifiable_tree_sitter_pair_is_rejected(self):
        for versions in ({}, {"tree-sitter": "0.25.2"}):

            def installed_version(name):
                if name not in versions:
                    raise noir_sbt.metadata.PackageNotFoundError
                return versions[name]

            with (
                self.subTest(versions=versions),
                mock.patch.multiple(
                    noir_sbt,
                    tsjava=object(),
                    Language=object(),
                    Parser=object(),
                    Query=object(),
                    QueryCursor=object(),
                ),
                mock.patch.object(
                    noir_sbt.metadata,
                    "version",
                    side_effect=installed_version,
                ),
            ):
                with self.assertRaisesRegex(RuntimeError, "unknown.*0.25.2"):
                    noir_sbt.require_tree_sitter()

    def test_java_string_literal_decoding_is_bounded_and_exact(self):
        self.assertEqual(noir_sbt.decode_java_string_literal('"/a\\t\\u002fb"'), "/a\t/b")
        self.assertEqual(noir_sbt.decode_java_string_literal('"\\141"'), "a")
        self.assertEqual(noir_sbt.decode_java_string_literal(r'"/\uD83D\uDE00"'), "/😀")
        self.assertEqual(noir_sbt.decode_java_string_literal(r'"\s"'), " ")
        self.assertIsNone(noir_sbt.decode_java_string_literal(r'"\uD83D"'))
        self.assertIsNone(noir_sbt.decode_java_string_literal('"bad\\x"'))
        self.assertIsNone(noir_sbt.decode_java_string_literal("not-a-literal"))

    def test_path_and_method_condition_composition(self):
        self.assertEqual(noir_sbt.combine_paths("", ""), "/")
        self.assertEqual(noir_sbt.combine_paths("/api/", "/users"), "/api/users")
        self.assertEqual(
            noir_sbt.combine_request_method_conditions(["POST", "GET"], ["TRACE", "POST"]),
            ["GET", "POST", "TRACE"],
        )
        self.assertEqual(noir_sbt.combine_request_method_conditions([], []), [])

    def test_rows_are_deduplicated_and_sorted_by_csv_field_order(self):
        row_a = {
            "module_name": "app",
            "interface_type": "http POST",
            "endpoint": "/b",
            "source_file_name": "B.java",
            "method_name": "B.b",
            "parameters": "",
        }
        row_b = {
            "module_name": "app",
            "interface_type": "http GET",
            "endpoint": "/a",
            "source_file_name": "A.java",
            "method_name": "A.a",
            "parameters": "String value",
        }
        self.assertEqual(
            noir_sbt.deduplicate_and_sort_rows([row_a, row_b, dict(row_a)]),
            [
                {**row_b, "method_annotation_line": ""},
                {**row_a, "method_annotation_line": ""},
            ],
        )

    def test_endpoint_path_identity_normalizes_templates_and_slashes(self):
        base = {
            "module_name": "app",
            "interface_type": "http GET",
            "source_file_name": "Api.java",
            "method_name": "Api.get",
            "parameters": "",
        }
        rows = noir_sbt.deduplicate_and_sort_rows(
            [
                {**base, "endpoint": "//api//items/{id:[0-9]+}"},
                {
                    **base,
                    "method_name": "Api.placeholder",
                    "endpoint": "configured/${route.leaf}",
                },
            ]
        )
        self.assertEqual(
            [(row["endpoint"], row["method_name"]) for row in rows],
            [
                ("/api/items/{id}", "Api.get"),
                ("/configured/{leaf}", "Api.placeholder"),
            ],
        )
        self.assertEqual(
            noir_sbt.normalize_endpoint_path(
                "/x/{id:[0-9]{1,3}}/{slug:(?:a|b){2}}"
            ),
            "/x/{id}/{slug}",
        )
        self.assertEqual(
            noir_sbt.normalize_endpoint_path("HTTP://example.test//v1"),
            "HTTP://example.test/v1",
        )

    def test_csv_has_bom_semicolon_and_exact_headers(self):
        row = {
            "module_name": "app",
            "interface_type": "http GET",
            "endpoint": "/items",
            "source_file_name": "Api.java",
            "method_name": "Api.items",
            "parameters": "String value, int count",
        }
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "endpoints.csv"
            noir_sbt.write_csv(output, noir_sbt.CSV_FIELDNAMES, [row])
            raw = output.read_bytes()
            self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
            with output.open("r", encoding="utf-8-sig", newline="") as csv_file:
                reader = csv.DictReader(csv_file, delimiter=";")
                self.assertEqual(
                    reader.fieldnames,
                    [
                        "module_name",
                        "interface_type",
                        "endpoint",
                        "source_file_name",
                        "method_name",
                        "parameters",
                        "method_annotation_line",
                    ],
                )
                self.assertEqual(
                    list(reader), [{**row, "method_annotation_line": ""}]
                )

    def test_java_discovery_is_sorted_and_prunes_ignored_directories(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "z").mkdir()
            (root / "a").mkdir()
            (root / "target").mkdir()
            (root / "z" / "Z.java").write_text("class Z {}", encoding="utf8")
            (root / "a" / "A.java").write_text("class A {}", encoding="utf8")
            (root / "target" / "Ignored.java").write_text("class Ignored {}", encoding="utf8")
            (root / "a" / "notes.txt").write_text("not Java", encoding="utf8")
            self.assertEqual(
                [Path(path).relative_to(root).as_posix() for path in noir_sbt.discover_java_files(root)],
                ["a/A.java", "z/Z.java"],
            )

    def test_argument_parser_keeps_named_framework_contract(self):
        parser = noir_sbt.build_argument_parser()
        args = parser.parse_args(
            ["--path", "/tmp/app", "--output", "out.csv", "--framework", "spring"]
        )
        self.assertEqual((args.path, args.output, args.framework), ("/tmp/app", "out.csv", "spring"))

    def test_module_name_and_relative_source_path_are_formatted(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "sample-app"
            source = root / "src" / "Api.java"
            source.parent.mkdir(parents=True)
            source.write_text("class Api {}", encoding="utf8")
            row = noir_sbt.format_endpoint(
                {
                    "method": "GET",
                    "uri": "/items",
                    "SrcFile": str(source),
                    "SFunction": "Api.items",
                    "uri_params": "",
                },
                root.name,
                str(root),
            )
            self.assertEqual(row["module_name"], "sample-app")
            self.assertEqual(row["source_file_name"], "src/Api.java")

    def test_framework_selection_dispatches_only_requested_analyzers(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "Api.java"
            source.write_text("class Api {}", encoding="utf8")
            with (
                mock.patch.object(noir_sbt, "require_tree_sitter"),
                mock.patch.object(noir_sbt, "build_spring_runtime", return_value={}),
                mock.patch.object(noir_sbt, "build_jax_runtime", return_value={}),
                mock.patch.object(noir_sbt, "build_jax_workspace", return_value={}),
                mock.patch.object(noir_sbt, "SpringBoot_Analyzer", return_value=[]) as spring,
                mock.patch.object(noir_sbt, "JaxRS_Analyzer", return_value=[]) as jaxrs,
                mock.patch("builtins.print"),
            ):
                noir_sbt.analyze_module(directory, "spring")
                self.assertEqual(spring.call_count, 1)
                jaxrs.assert_not_called()

                spring.reset_mock()
                noir_sbt.analyze_module(directory, "jaxrx")
                spring.assert_not_called()
                self.assertEqual(jaxrs.call_count, 1)

                spring.reset_mock()
                jaxrs.reset_mock()
                noir_sbt.analyze_module(directory)
                self.assertEqual(spring.call_count, 1)
                self.assertEqual(jaxrs.call_count, 1)

    @unittest.skipIf(TREE_SITTER_AVAILABLE, "dependency-missing behavior applies only here")
    def test_missing_tree_sitter_is_reported_at_analysis_time(self):
        with self.assertRaisesRegex(RuntimeError, "tree_sitter"):
            noir_sbt.require_tree_sitter()


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class SpringTreeSitterIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runtime = noir_sbt.build_spring_runtime()

    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        noir_sbt.log_file = str(Path(self._temporary_directory.name) / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze(self, source):
        return noir_sbt.SpringBoot_Analyzer(
            "Api.java", source.encode("utf8"), runtime=self.runtime
        )

    def test_unconstrained_request_mapping_is_any(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.RequestMapping;
            class Api {
                @RequestMapping("/items")
                void items() {}
            }
            """
        )
        self.assertEqual(
            [(endpoint["method"], endpoint["uri"]) for endpoint in endpoints],
            [("ANY", "/items")],
        )

    def test_shortcuts_and_all_explicit_request_methods(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.*;
            class Api {
                @GetMapping("/get") void get() {}
                @PostMapping("/post") void post() {}
                @PutMapping("/put") void put() {}
                @DeleteMapping("/delete") void delete() {}
                @PatchMapping("/patch") void patch() {}
                @RequestMapping(
                    path = {"/all-a", "/all-b"},
                    method = {
                        RequestMethod.GET, RequestMethod.POST,
                        RequestMethod.PUT, RequestMethod.DELETE,
                        RequestMethod.PATCH, RequestMethod.HEAD,
                        RequestMethod.OPTIONS, RequestMethod.TRACE
                    }
                )
                void all() {}
            }
            """
        )
        fixed = {
            (endpoint["method"], endpoint["uri"])
            for endpoint in endpoints
            if not endpoint["uri"].startswith("/all-")
        }
        self.assertEqual(
            fixed,
            {
                ("GET", "/get"),
                ("POST", "/post"),
                ("PUT", "/put"),
                ("DELETE", "/delete"),
                ("PATCH", "/patch"),
            },
        )
        all_rows = [
            endpoint for endpoint in endpoints if endpoint["uri"].startswith("/all-")
        ]
        self.assertEqual(len(all_rows), 16)
        self.assertEqual(
            {endpoint["method"] for endpoint in all_rows},
            set(noir_sbt.SPRING_HTTP_METHODS),
        )

    def test_value_positional_arrays_and_explicit_empty_arrays(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.*;
            class Api {
                @GetMapping({"/a", /* docs */ "/b"}) void positional() {}
                @PostMapping(value = {"/c", "/d"}) void value() {}
                @RequestMapping(path = {}, method = {}) void empty() {}
            }
            """
        )
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"]) for endpoint in endpoints},
            {
                ("GET", "/a"),
                ("GET", "/b"),
                ("POST", "/c"),
                ("POST", "/d"),
                ("ANY", "/"),
            },
        )

    def test_comments_inside_annotation_arguments_are_trivia(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.*;
            @RequestMapping("/items")
            class Api {
                @PostMapping(
                    "/create" /* route documentation */
                )
                void create() {}
            }
            """
        )
        self.assertEqual(
            [(endpoint["method"], endpoint["uri"]) for endpoint in endpoints],
            [("POST", "/items/create")],
        )

    def test_path_method_fanout_constants_and_raw_parameters(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.*;
            @RequestMapping(path = {"/api", "/v2"}, method = RequestMethod.GET)
            class Api {
                static final String ROOT = "/items";
                static final String DETAIL = ROOT + "/{id}";

                @RequestMapping(
                    path = {DETAIL, ("/other")},
                    method = {RequestMethod.POST, RequestMethod.TRACE}
                )
                void update(
                    @Deprecated java.util.Map<String, java.util.List<Integer>> value,
                    String... names
                ) {}
            }
            """
        )
        self.assertEqual(len(endpoints), 12)
        self.assertEqual({endpoint["method"] for endpoint in endpoints}, {"GET", "POST", "TRACE"})
        self.assertEqual(
            {endpoint["uri"] for endpoint in endpoints},
            {"/api/items/{id}", "/api/other", "/v2/items/{id}", "/v2/other"},
        )
        expected_parameters = (
            "@Deprecated java.util.Map<String, java.util.List<Integer>> value,\n"
            "                    String... names"
        )
        self.assertEqual({endpoint["uri_params"] for endpoint in endpoints}, {expected_parameters})

    def test_interface_constants_abstract_text_and_method_scope(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.*;
            @interface Note { String value(); }
            interface Paths { String ROOT = "/interface"; }

            @Note("abstract")
            class Api {
                static final String ROOT = "/class";
                static class run { static final String ROOT = "/wrong"; }

                @GetMapping(Paths.ROOT) void fromInterface() {}
                @GetMapping(ROOT) void run() {}
            }
            """
        )
        self.assertEqual(
            {(endpoint["uri"], endpoint["SFunction"]) for endpoint in endpoints},
            {
                ("/interface", "Api.fromInterface"),
                ("/class", "Api.run"),
            },
        )

    def test_external_constants_are_not_guessed_from_same_file_names(self):
        endpoints = self.analyze(
            """
            import static external.Paths.ROOT;
            import org.springframework.web.bind.annotation.GetMapping;

            class Other { static final String ROOT = "/wrong-static"; }
            class Paths { static final String ROOT = "/wrong-qualified"; }
            class Api {
                @GetMapping(ROOT) void staticImport() {}
                @GetMapping(external.Paths.ROOT) void qualifiedExternal() {}
            }
            """
        )
        self.assertEqual(endpoints, [])

    def test_unresolved_path_and_method_do_not_fall_back(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.*;
            class Api {
                @GetMapping(pathFactory()) void badPath() {}
                @RequestMapping(path = "/x", method = unknown()) void badMethod() {}
            }
            """
        )
        self.assertEqual(endpoints, [])
        log = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("unresolved Spring path", log)
        self.assertIn("unresolved Spring method", log)

    def test_annotation_provenance_first_mapping_and_nested_owner(self):
        endpoints = self.analyze(
            """
            import org.springframework.web.bind.annotation.*;
            @RequestMapping("/outer")
            class Outer {
                @RequestMapping("/inner")
                class Inner {
                    @GetMapping("/first")
                    @PostMapping("/ignored")
                    void run() {}
                }
            }
            """
        )
        self.assertEqual(
            [(endpoint["method"], endpoint["uri"], endpoint["SFunction"]) for endpoint in endpoints],
            [("GET", "/outer/inner/first", "Outer.Inner.run")],
        )

        local_annotation_endpoints = self.analyze(
            """
            @interface GetMapping { String value(); }
            class NotSpring {
                @GetMapping("/false-positive") void nope() {}
            }
            """
        )
        self.assertEqual(local_annotation_endpoints, [])

        wrong_import_endpoints = self.analyze(
            """
            import com.example.GetMapping;
            class NotSpring {
                @GetMapping("/false-positive") void nope() {}
            }
            """
        )
        self.assertEqual(wrong_import_endpoints, [])

    def test_fully_qualified_mapping_is_accepted(self):
        endpoints = self.analyze(
            """
            class Api {
                @org.springframework.web.bind.annotation.DeleteMapping("/items/{id}")
                void remove(long id) {}
            }
            """
        )
        self.assertEqual(
            [(endpoint["method"], endpoint["uri"]) for endpoint in endpoints],
            [("DELETE", "/items/{id}")],
        )

    def test_jaxrs_analyzer_keeps_basic_smoke_behavior(self):
        source = Path(self._temporary_directory.name) / "Resource.java"
        source.write_text(
            """
            import javax.ws.rs.*;
            @Path("/api")
            class Resource {
                @GET
                @Path("/items")
                public void items(String value) {}
            }
            """,
            encoding="utf8",
        )
        endpoints = noir_sbt.JaxRS_Analyzer(str(source), None)
        self.assertEqual(
            [
                (
                    endpoint["method"],
                    endpoint["uri"],
                    endpoint["SFunction"],
                    endpoint["uri_params"],
                )
                for endpoint in endpoints
            ],
            [("GET", "/api/items", "Resource.items", "String value")],
        )


if __name__ == "__main__":
    unittest.main()
