from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class JavaDifferentiatorIntegrationTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def write_module(self, directory_name, files):
        module_root = self.root / directory_name
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
        return module_root

    def analyze_module(self, directory_name, files, framework=None):
        module_root = self.write_module(directory_name, files)
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        with mock.patch("builtins.print"):
            return noir_sbt.analyze_module(module_root, framework)

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
            for endpoint in endpoints
        }

    def assert_diagnostic_was_written(self):
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertTrue(diagnostic.strip())
        self.assertIn("Spring", diagnostic)

    def test_02_con_001_exact_imported_type_constant_for_spring_and_jaxrs(self):
        endpoints = self.analyze_module(
            "exact-type-import",
            {
                "paths/ApiPaths.java": """
                    package paths;
                    public final class ApiPaths {
                        public static final String ROOT = "/shared";
                    }
                """,
                "springapi/SpringApi.java": """
                    package springapi;
                    import paths.ApiPaths;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class SpringApi {
                        @GetMapping(ApiPaths.ROOT + "/spring")
                        void list() {}
                    }
                """,
                "jaxapi/JaxResource.java": """
                    package jaxapi;
                    import paths.ApiPaths;
                    import jakarta.ws.rs.GET;
                    import jakarta.ws.rs.Path;
                    @Path(ApiPaths.ROOT)
                    class JaxResource {
                        @GET @Path("/jax") public void list() {}
                    }
                """,
            },
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/shared/spring", "SpringApi.list"),
                ("GET", "/shared/jax", "JaxResource.list"),
            },
        )

    def test_02_con_002_same_package_and_fully_qualified_type_constants(self):
        endpoints = self.analyze_module(
            "qualified-types",
            {
                "paths/Paths.java": """
                    package paths;
                    public final class Paths {
                        public static final String SAME = "/same";
                        public static final String FQN = "/qualified";
                    }
                """,
                "paths/SamePackageApi.java": """
                    package paths;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class SamePackageApi {
                        @GetMapping(Paths.SAME) void list() {}
                    }
                """,
                "jaxapi/QualifiedResource.java": """
                    package jaxapi;
                    @jakarta.ws.rs.Path(paths.Paths.FQN)
                    class QualifiedResource {
                        @jakarta.ws.rs.GET public void list() {}
                    }
                """,
            },
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/same", "SamePackageApi.list"),
                ("GET", "/qualified", "QualifiedResource.list"),
            },
        )

    def test_02_con_002_exact_import_beats_default_package_holder(self):
        endpoints = self.analyze_module(
            "exact-import-precedence",
            {
                "Paths.java": """
                    public final class Paths {
                        public static final String ROOT = "/wrong-default";
                    }
                """,
                "paths/Paths.java": """
                    package paths;
                    public final class Paths {
                        public static final String ROOT = "/imported";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import paths.Paths;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(Paths.ROOT) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/imported", "Api.list")},
        )

    def test_02_con_003_exact_and_unique_wildcard_static_imports(self):
        endpoints = self.analyze_module(
            "static-imports",
            {
                "paths/StaticPaths.java": """
                    package paths;
                    public final class StaticPaths {
                        public static final String EXACT = "/exact";
                        public static final String WILDCARD = "/wildcard";
                    }
                """,
                "springapi/SpringApi.java": """
                    package springapi;
                    import static paths.StaticPaths.EXACT;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class SpringApi {
                        @GetMapping(EXACT + "/spring") void list() {}
                    }
                """,
                "jaxapi/JaxResource.java": """
                    package jaxapi;
                    import static paths.StaticPaths.*;
                    import jakarta.ws.rs.GET;
                    import jakarta.ws.rs.Path;
                    @Path(WILDCARD + "/jax")
                    class JaxResource {
                        @GET public void list() {}
                    }
                """,
            },
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/exact/spring", "SpringApi.list"),
                ("GET", "/wildcard/jax", "JaxResource.list"),
            },
        )

    def test_02_con_004_cross_file_parentheses_aliases_and_concat_chains(self):
        endpoints = self.analyze_module(
            "constant-chain",
            {
                "paths/ChainPaths.java": """
                    package paths;
                    public interface ChainPaths {
                        String ROOT = ("/api");
                        String VERSION = (ROOT + "/v2");
                        String ITEMS = VERSION + ("/items");
                    }
                """,
                "springapi/SpringApi.java": """
                    package springapi;
                    import paths.ChainPaths;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class SpringApi {
                        @GetMapping(ChainPaths.ITEMS + "/spring") void list() {}
                    }
                """,
                "jaxapi/JaxResource.java": """
                    package jaxapi;
                    import paths.ChainPaths;
                    import jakarta.ws.rs.GET;
                    import jakarta.ws.rs.Path;
                    @Path(ChainPaths.ITEMS)
                    class JaxResource {
                        @GET @Path(("/jax")) public void list() {}
                    }
                """,
            },
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/api/v2/items/spring", "SpringApi.list"),
                ("GET", "/api/v2/items/jax", "JaxResource.list"),
            },
        )

    def test_02_con_005_application_path_uses_imported_constant(self):
        endpoints = self.analyze_module(
            "application-path-constant",
            {
                "paths/DeploymentPaths.java": """
                    package paths;
                    public final class DeploymentPaths {
                        public static final String ROOT = "/service";
                    }
                """,
                "deployment/ApiApplication.java": """
                    package deployment;
                    import paths.DeploymentPaths;
                    import jakarta.ws.rs.ApplicationPath;
                    import jakarta.ws.rs.core.Application;
                    @ApplicationPath(DeploymentPaths.ROOT + "/v1")
                    public class ApiApplication extends Application {}
                """,
                "api/ItemsResource.java": """
                    package api;
                    import jakarta.ws.rs.GET;
                    import jakarta.ws.rs.Path;
                    @Path("/items") class ItemsResource {
                        @GET @Path("/list") public void list() {}
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/service/v1/items/list", "ItemsResource.list")},
        )

    def test_02_con_006_ambiguous_cycle_wrong_owner_and_unresolved_are_skipped(self):
        endpoints = self.analyze_module(
            "unresolved-constants",
            {
                "a/Paths.java": """
                    package a;
                    public final class Paths {
                        public static final String ROOT = "/a";
                    }
                """,
                "b/Paths.java": """
                    package b;
                    public final class Paths {
                        public static final String ROOT = "/b";
                    }
                """,
                "cycles/CycleA.java": """
                    package cycles;
                    public final class CycleA {
                        public static final String ROOT = CycleB.ROOT;
                    }
                """,
                "cycles/CycleB.java": """
                    package cycles;
                    public final class CycleB {
                        public static final String ROOT = CycleA.ROOT;
                    }
                """,
                "api/Api.java": """
                    package api;
                    import a.*;
                    import b.*;
                    import cycles.CycleA;
                    import static a.Paths.ROOT;
                    import static b.Paths.ROOT;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(Paths.ROOT) void ambiguousType() {}
                        @GetMapping(ROOT) void ambiguousStatic() {}
                        @GetMapping(CycleA.ROOT) void cycle() {}
                        @GetMapping(missing.Paths.ROOT) void wrongOwner() {}
                        @GetMapping("/prefix" + Missing.SUFFIX) void unresolved() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_006_duplicate_holder_fqn_is_unresolved(self):
        endpoints = self.analyze_module(
            "duplicate-holder-fqn",
            {
                "first/Paths.java": """
                    package duplicate;
                    public final class Paths {
                        public static final String ROOT = "/first";
                    }
                """,
                "second/Paths.java": """
                    package duplicate;
                    public final class Paths {
                        public static final String ROOT = "/second";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import duplicate.Paths;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(Paths.ROOT) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_006_local_class_holder_is_not_workspace_addressable(self):
        endpoints = self.analyze_module(
            "local-class-holder",
            {
                "factory/Factory.java": """
                    package factory;
                    public class Factory {
                        void definePaths() {
                            class Paths {
                                static final String ROOT = "/local";
                            }
                        }
                    }
                """,
                "api/Api.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(factory.Factory.Paths.ROOT) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_006_named_package_cannot_use_unnamed_nested_holder(self):
        endpoints = self.analyze_module(
            "unnamed-package-holder",
            {
                "Outer.java": """
                    class Outer {
                        static class Paths {
                            static final String ROOT = "/unnamed";
                        }
                    }
                """,
                "api/Api.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(Outer.Paths.ROOT) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_006_static_wildcard_member_ambiguity_precedes_eligibility(self):
        endpoints = self.analyze_module(
            "static-wildcard-member-ambiguity",
            {
                "good/Paths.java": """
                    package good;
                    public final class Paths {
                        public static final String WRONG = "/good-wrong";
                        public static final String MUTABLE = "/good-mutable";
                    }
                """,
                "bad/Paths.java": """
                    package bad;
                    public class Paths {
                        public static final int WRONG = 7;
                        public static String MUTABLE = "/bad-mutable";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import static bad.Paths.*;
                    import static good.Paths.*;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(WRONG) void wrongTypeCompetitor() {}
                        @GetMapping(MUTABLE) void mutableCompetitor() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_006_type_wildcard_ambiguity_precedes_member_eligibility(self):
        endpoints = self.analyze_module(
            "type-wildcard-member-ambiguity",
            {
                "good/Paths.java": """
                    package good;
                    public final class Paths {
                        public static final String ROOT = "/eligible";
                    }
                """,
                "bad/Paths.java": """
                    package bad;
                    public final class Paths {
                        public static final String OTHER = "/other";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import bad.*;
                    import good.*;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(Paths.ROOT) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_007_invalid_cross_file_class_fields_are_not_constants(self):
        endpoints = self.analyze_module(
            "invalid-fields",
            {
                "paths/InvalidPaths.java": """
                    package paths;
                    public class InvalidPaths {
                        public static final int NUMBER = 7;
                        public final String NON_STATIC = "/non-static";
                        public static String NON_FINAL = "/non-final";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import paths.InvalidPaths;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(InvalidPaths.NUMBER) void number() {}
                        @GetMapping(InvalidPaths.NON_STATIC) void nonStatic() {}
                        @GetMapping(InvalidPaths.NON_FINAL) void nonFinal() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_007_lexical_invalid_fields_shadow_static_imports(self):
        endpoints = self.analyze_module(
            "lexical-field-shadowing",
            {
                "paths/ImportedPaths.java": """
                    package paths;
                    public final class ImportedPaths {
                        public static final String ROOT = "/imported-root";
                        public static final String WRONG = "/imported-wrong";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import static paths.ImportedPaths.ROOT;
                    import static paths.ImportedPaths.WRONG;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        static String ROOT = "/mutable";
                        static final int WRONG = 7;
                        @GetMapping(ROOT) void mutable() {}
                        @GetMapping(WRONG) void wrongType() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_007_transitive_mutable_dependency_is_unresolved(self):
        endpoints = self.analyze_module(
            "transitive-mutable-field",
            {
                "paths/MutablePaths.java": """
                    package paths;
                    public class MutablePaths {
                        public static String ROOT = "/mutable";
                    }
                """,
                "paths/FinalPaths.java": """
                    package paths;
                    public final class FinalPaths {
                        public static final String ITEMS =
                            MutablePaths.ROOT + "/items";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import paths.FinalPaths;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping(FinalPaths.ITEMS) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_007_same_file_private_constant_respects_lexical_owner(self):
        endpoints = self.analyze_module(
            "same-file-private-owner",
            {
                "Api.java": """
                    import org.springframework.web.bind.annotation.GetMapping;

                    class Unrelated {
                        private static final String ROOT = "/unrelated";
                    }

                    class Api {
                        @GetMapping(Unrelated.ROOT) void illegalAccess() {}
                    }

                    class Outer {
                        private static final String ROOT = "/outer";

                        static class Nested {
                            @GetMapping(ROOT + "/nested") void legalAccess() {}
                        }
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/outer/nested", "Outer.Nested.legalAccess")},
        )
        self.assert_diagnostic_was_written()

    def test_02_con_007_instance_final_string_resolves_for_instance_method(self):
        endpoints = self.analyze_module(
            "instance-final-constant",
            {
                "Api.java": """
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        final String P = "/instance-final";
                        @GetMapping(P) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/instance-final", "Api.list")},
        )

    def test_02_con_007_mutable_and_static_instance_constant_uses_are_rejected(self):
        endpoints = self.analyze_module(
            "invalid-same-file-instance-fields",
            {
                "Api.java": """
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        final String P = "/instance-final";
                        String MUTABLE = "/mutable";
                        @GetMapping(MUTABLE) void mutable() {}
                        @GetMapping(P) static void staticUse() {}
                        @GetMapping(this.P) void explicitThis() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_con_006_jax_ineligible_exact_import_does_not_fall_through(self):
        endpoints = self.analyze_module(
            "jax-http-method-constant-provenance",
            {
                "fake/Verbs.java": """
                    package fake;
                    public final class Verbs {
                        public static String GET = "GET";
                    }
                """,
                "designators/EXACT_BAD.java": """
                    package designators;
                    import static fake.Verbs.GET;
                    import static jakarta.ws.rs.HttpMethod.*;
                    @jakarta.ws.rs.HttpMethod(GET)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    public @interface EXACT_BAD {}
                """,
                "designators/WILDCARD_BAD.java": """
                    package designators;
                    import static fake.Verbs.*;
                    import static javax.ws.rs.HttpMethod.*;
                    @javax.ws.rs.HttpMethod(GET)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    public @interface WILDCARD_BAD {}
                """,
                "api/ModernResource.java": """
                    package api;
                    import designators.EXACT_BAD;
                    @jakarta.ws.rs.Path("/modern")
                    class ModernResource {
                        @EXACT_BAD public void get() {}
                    }
                """,
                "api/LegacyResource.java": """
                    package api;
                    import designators.WILDCARD_BAD;
                    @javax.ws.rs.Path("/legacy")
                    class LegacyResource {
                        @WILDCARD_BAD public void get() {}
                    }
                """,
            },
            "jaxrx",
        )
        self.assertEqual(endpoints, [])
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("JAX-RS", diagnostic)

    def test_02_spr_001_one_level_composed_mapping_renames_path(self):
        endpoints = self.analyze_module(
            "one-level-composed",
            {
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.ElementType;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import java.lang.annotation.Target;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Target({ElementType.TYPE, ElementType.METHOD})
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Read;
                    class Api {
                        @Read(route = "/items") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/items", "Api.list")},
        )

    def test_02_spr_001_ignored_produces_alias_does_not_hide_route(self):
        endpoints = self.analyze_module(
            "ignored-non-route-alias",
            {
                "annotations/JsonRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface JsonRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                        @AliasFor(annotation = RequestMapping.class, attribute = "produces")
                        String[] media() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.JsonRead;
                    class Api {
                        @JsonRead(
                            route = "/json",
                            media = "application/json"
                        )
                        void json() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/json", "Api.json")},
        )

    def test_02_spr_001_ordinary_no_element_composed_mapping_emits(self):
        endpoints = self.analyze_module(
            "ordinary-composed",
            {
                "annotations/Health.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/health", method = RequestMethod.GET)
                    public @interface Health {}
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Health;
                    class Api {
                        @Health void health() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/health", "Api.health")},
        )

    def test_02_spr_002_multi_level_composed_annotation_path_alias(self):
        endpoints = self.analyze_module(
            "multi-level-composed",
            {
                "annotations/HttpRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface HttpRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "annotations/JsonRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    @Retention(RetentionPolicy.RUNTIME)
                    @HttpRead
                    public @interface JsonRead {
                        @AliasFor(annotation = HttpRead.class, attribute = "route")
                        String[] api() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.JsonRead;
                    class Api {
                        @JsonRead(api = "/multi") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/multi", "Api.list")},
        )

    def test_02_spr_002_unrelated_custom_meta_alias_keeps_fixed_mapping(self):
        endpoints = self.analyze_module(
            "unrelated-custom-meta-alias",
            {
                "annotations/Inner.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/fixed", method = RequestMethod.GET)
                    public @interface Inner {
                        String description() default "";
                    }
                """,
                "annotations/Outer.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    @Retention(RetentionPolicy.RUNTIME)
                    @Inner
                    public @interface Outer {
                        @AliasFor(annotation = Inner.class, attribute = "description")
                        String note();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Outer;
                    class Api {
                        @Outer(note = "docs") void documented() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/fixed", "Api.documented")},
        )

    def test_02_spr_002_unrelated_primitive_meta_alias_keeps_fixed_mapping(self):
        endpoints = self.analyze_module(
            "unrelated-primitive-meta-alias",
            {
                "annotations/Inner.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/secure", method = RequestMethod.GET)
                    public @interface Inner {
                        boolean secure() default false;
                    }
                """,
                "annotations/Outer.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    @Retention(RetentionPolicy.RUNTIME)
                    @Inner
                    public @interface Outer {
                        @AliasFor(annotation = Inner.class, attribute = "secure")
                        boolean flag();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Outer;
                    class Api {
                        @Outer(flag = true) void secure() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/secure", "Api.secure")},
        )

    def test_02_spr_002_transitive_scalar_to_array_path_alias_emits(self):
        endpoints = self.analyze_module(
            "transitive-scalar-to-array-alias",
            {
                "annotations/Inner.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Inner {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "annotations/Outer.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    @Retention(RetentionPolicy.RUNTIME)
                    @Inner
                    public @interface Outer {
                        @AliasFor(annotation = Inner.class, attribute = "route")
                        String api();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Outer;
                    class Api {
                        @Outer(api = "/scalar-deep") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/scalar-deep", "Api.list")},
        )

    def test_02_spr_002_direct_sibling_meta_attribute_alias_emits(self):
        endpoints = self.analyze_module(
            "direct-sibling-meta-alias",
            {
                "annotations/Security.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    @Retention(RetentionPolicy.RUNTIME)
                    public @interface Security {
                        String role() default "";
                    }
                """,
                "annotations/SecuredRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @Security
                    @RequestMapping(path = "/secured", method = RequestMethod.GET)
                    public @interface SecuredRead {
                        @AliasFor(annotation = Security.class, attribute = "role")
                        String access();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.SecuredRead;
                    class Api {
                        @SecuredRead(access = "admin") void secured() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/secured", "Api.secured")},
        )

    def test_02_spr_002_distinct_sibling_alias_targets_do_not_conflict(self):
        endpoints = self.analyze_module(
            "distinct-sibling-meta-aliases",
            {
                "annotations/Security.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    @Retention(RetentionPolicy.RUNTIME)
                    public @interface Security {
                        String role() default "user";
                    }
                """,
                "annotations/Audit.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    @Retention(RetentionPolicy.RUNTIME)
                    public @interface Audit {
                        String action() default "read";
                    }
                """,
                "annotations/SecuredRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @Security
                    @Audit
                    @RequestMapping(path = "/secured-audit", method = RequestMethod.GET)
                    public @interface SecuredRead {
                        @AliasFor(annotation = Security.class, attribute = "role")
                        String access() default "user";
                        @AliasFor(annotation = Audit.class, attribute = "action")
                        String event() default "read";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.SecuredRead;
                    class Api {
                        @SecuredRead(access = "admin", event = "write")
                        void secured() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/secured-audit", "Api.secured")},
        )

    def test_02_spr_003_default_preserves_fixed_path_and_explicit_overrides(self):
        endpoints = self.analyze_module(
            "fixed-and-override",
            {
                "annotations/FixedRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/fixed", method = RequestMethod.GET)
                    public @interface FixedRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.FixedRead;
                    class Api {
                        @FixedRead void fixed() {}
                        @FixedRead(route = "/override") void overridden() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/fixed", "Api.fixed"),
                ("GET", "/override", "Api.overridden"),
            },
        )

    def test_02_spr_004_alias_to_request_mapping_method_fans_out(self):
        endpoints = self.analyze_module(
            "method-alias",
            {
                "annotations/VerbRoute.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/tasks")
                    public @interface VerbRoute {
                        @AliasFor(annotation = RequestMapping.class, attribute = "method")
                        RequestMethod[] verbs() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.VerbRoute;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    class Api {
                        @VerbRoute(verbs = {RequestMethod.GET, RequestMethod.POST})
                        void tasks() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/tasks", "Api.tasks"),
                ("POST", "/tasks", "Api.tasks"),
            },
        )

    def test_02_spr_004_scalar_alias_component_types_emit(self):
        endpoints = self.analyze_module(
            "scalar-alias-components",
            {
                "annotations/ScalarRoute.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping
                    public @interface ScalarRoute {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String route();
                        @AliasFor(annotation = RequestMapping.class, attribute = "method")
                        RequestMethod verb();
                        @AliasFor(annotation = RequestMapping.class, attribute = "produces")
                        String media();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.ScalarRoute;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    class Api {
                        @ScalarRoute(
                            route = "/scalar",
                            verb = RequestMethod.POST,
                            media = "application/json"
                        )
                        void scalar() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("POST", "/scalar", "Api.scalar")},
        )

    def test_02_spr_005_local_aliases_converge_on_one_mapping_target(self):
        endpoints = self.analyze_module(
            "converging-aliases",
            {
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                        @AliasFor(annotation = RequestMapping.class, attribute = "value")
                        String[] value() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Read;
                    class Api {
                        @Read(route = "/same", value = "/same") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            [(endpoint["method"], endpoint["uri"], endpoint["SFunction"])
             for endpoint in endpoints],
            [("GET", "/same", "Api.list")],
        )

    def test_02_spr_006_invalid_alias_graphs_are_diagnosed_and_skipped(self):
        endpoints = self.analyze_module(
            "invalid-composed",
            {
                "fake/AliasFor.java": """
                    package fake;
                    public @interface AliasFor {
                        Class<?> annotation() default Object.class;
                        String attribute() default "";
                        String value() default "";
                    }
                """,
                "bad/WrongProvenance.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import fake.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface WrongProvenance {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "bad/ConflictingRead.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface ConflictingRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                        @AliasFor(annotation = RequestMapping.class, attribute = "value")
                        String[] value() default {};
                    }
                """,
                "bad/CycleA.java": """
                    package bad;
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @CycleB public @interface CycleA {}
                """,
                "bad/CycleB.java": """
                    package bad;
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    @CycleA public @interface CycleB {}
                """,
                "bad/MissingTarget.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface MissingTarget {
                        @AliasFor(annotation = RequestMapping.class, attribute = "missing")
                        String[] route() default {};
                    }
                """,
                "bad/ReadLeaf.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface ReadLeaf {}
                """,
                "bad/WriteLeaf.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.POST)
                    public @interface WriteLeaf {}
                """,
                "bad/MultipleLeaves.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    @Retention(RetentionPolicy.RUNTIME)
                    @ReadLeaf @WriteLeaf
                    public @interface MultipleLeaves {}
                """,
                "bad/ClassRetention.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.CLASS)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface ClassRetention {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "bad/DifferingAliasDefaults.java": """
                    package bad;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface DifferingAliasDefaults {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {"/left"};
                        @AliasFor(annotation = RequestMapping.class, attribute = "value")
                        String[] value() default {"/right"};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import bad.*;
                    class Api {
                        @WrongProvenance(route = "/wrong") void wrong() {}
                        @ConflictingRead(route = "/a", value = "/b")
                        void conflict() {}
                        @ConflictingRead(route = "x", value = "/x")
                        void rawConflict() {}
                        @CycleA void cycle() {}
                        @MissingTarget(route = "/missing") void missing() {}
                        @MultipleLeaves void multiple() {}
                        @ClassRetention(route = "/class-retention")
                        void nonRuntime() {}
                        @DifferingAliasDefaults void differingDefaults() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_non_reciprocal_local_route_alias_is_rejected(self):
        endpoints = self.analyze_module(
            "one-way-local-alias",
            {
                "annotations/OneWayRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface OneWayRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] a() default {};
                        @AliasFor("a")
                        String[] b() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.OneWayRead;
                    class Api {
                        @OneWayRead(b = "/one-way") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_alias_for_value_and_attribute_both_rejected(self):
        endpoints = self.analyze_module(
            "alias-for-dual-target-name",
            {
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(
                            annotation = RequestMapping.class,
                            value = "path",
                            attribute = "path"
                        )
                        String[] route() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Read;
                    class Api {
                        @Read(route = "/dual") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_alias_cannot_target_outer_annotation(self):
        endpoints = self.analyze_module(
            "backward-alias-target",
            {
                "annotations/A.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    @Retention(RetentionPolicy.RUNTIME)
                    @B(b = "/bad")
                    public @interface A {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] a() default {};
                    }
                """,
                "annotations/B.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface B {
                        @AliasFor(annotation = A.class, attribute = "a")
                        String[] b() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.A;
                    class Api {
                        @A(a = "/outer") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_alias_target_must_be_present_as_meta_annotation(self):
        endpoints = self.analyze_module(
            "missing-sibling-meta-target",
            {
                "annotations/Security.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    @Retention(RetentionPolicy.RUNTIME)
                    public @interface Security {
                        String role() default "";
                    }
                """,
                "annotations/SecuredRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/must-skip", method = RequestMethod.GET)
                    public @interface SecuredRead {
                        @AliasFor(annotation = Security.class, attribute = "role")
                        String access();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.SecuredRead;
                    class Api {
                        @SecuredRead(access = "admin") void secured() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_alias_for_wildcard_collision_is_rejected(self):
        endpoints = self.analyze_module(
            "alias-for-wildcard-collision",
            {
                "fake/AliasFor.java": """
                    package fake;
                    public @interface AliasFor {
                        Class<?> annotation() default Object.class;
                        String attribute() default "";
                        String value() default "";
                    }
                """,
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import fake.*;
                    import org.springframework.core.annotation.*;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Read;
                    class Api {
                        @Read(route = "/ambiguous-alias") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_ignored_alias_with_incompatible_type_is_rejected(self):
        endpoints = self.analyze_module(
            "incompatible-ignored-alias",
            {
                "annotations/BadProducesRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface BadProducesRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                        @AliasFor(annotation = RequestMapping.class, attribute = "produces")
                        int[] mediaTypes() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.BadProducesRead;
                    class Api {
                        @BadProducesRead(route = "/bad-type") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_scalar_path_alias_rejects_array_initializer(self):
        endpoints = self.analyze_module(
            "scalar-alias-array-use",
            {
                "annotations/ScalarRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface ScalarRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String route();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.ScalarRead;
                    class Api {
                        @ScalarRead(route = {"/bad"}) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_mixed_scalar_array_alias_group_is_rejected(self):
        endpoints = self.analyze_module(
            "mixed-scalar-array-alias-group",
            {
                "annotations/MixedRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface MixedRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String scalar() default "/same";
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] array() default {"/same"};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.MixedRead;
                    class Api {
                        @MixedRead void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_transitive_array_to_scalar_path_alias_is_rejected(self):
        endpoints = self.analyze_module(
            "transitive-array-to-scalar-alias",
            {
                "annotations/Inner.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Inner {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String route() default "";
                    }
                """,
                "annotations/Outer.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    @Retention(RetentionPolicy.RUNTIME)
                    @Inner
                    public @interface Outer {
                        @AliasFor(annotation = Inner.class, attribute = "route")
                        String[] api() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Outer;
                    class Api {
                        @Outer(api = {"/array-deep"}) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_fake_request_method_values_are_rejected(self):
        endpoints = self.analyze_module(
            "fake-request-method-values",
            {
                "fake/Verb.java": """
                    package fake;
                    public enum Verb { GET }
                """,
                "annotations/UsedVerbRoute.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/used")
                    public @interface UsedVerbRoute {
                        @AliasFor(annotation = RequestMapping.class, attribute = "method")
                        RequestMethod[] verbs() default {};
                    }
                """,
                "annotations/DefaultVerbRoute.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/default")
                    public @interface DefaultVerbRoute {
                        @AliasFor(annotation = RequestMapping.class, attribute = "method")
                        RequestMethod[] verbs() default fake.Verb.GET;
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.DefaultVerbRoute;
                    import annotations.UsedVerbRoute;
                    class Api {
                        @UsedVerbRoute(verbs = fake.Verb.GET) void used() {}
                        @DefaultVerbRoute void defaulted() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_bare_request_method_static_wildcards_are_ambiguous(self):
        endpoints = self.analyze_module(
            "request-method-static-wildcards",
            {
                "fake/Verb.java": """
                    package fake;
                    public enum Verb { GET }
                """,
                "annotations/VerbRoute.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/ambiguous")
                    public @interface VerbRoute {
                        @AliasFor(annotation = RequestMapping.class, attribute = "method")
                        RequestMethod[] verbs() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import static fake.Verb.*;
                    import static org.springframework.web.bind.annotation.RequestMethod.*;
                    import annotations.VerbRoute;
                    class Api {
                        @VerbRoute(verbs = GET) void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_fake_runtime_static_imports_do_not_establish_retention(self):
        endpoints = self.analyze_module(
            "fake-runtime-retention",
            {
                "fake/RetentionPolicy.java": """
                    package fake;
                    public enum RetentionPolicy { RUNTIME }
                """,
                "annotations/ExactRuntimeRead.java": """
                    package annotations;
                    import static fake.RetentionPolicy.RUNTIME;
                    import java.lang.annotation.Retention;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface ExactRuntimeRead {}
                """,
                "annotations/WildcardRuntimeRead.java": """
                    package annotations;
                    import static fake.RetentionPolicy.*;
                    import java.lang.annotation.Retention;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface WildcardRuntimeRead {}
                """,
                "api/Api.java": """
                    package api;
                    import annotations.ExactRuntimeRead;
                    import annotations.WildcardRuntimeRead;
                    class Api {
                        @ExactRuntimeRead void exact() {}
                        @WildcardRuntimeRead void wildcard() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_fake_string_imports_invalidate_alias_types(self):
        endpoints = self.analyze_module(
            "fake-string-alias-types",
            {
                "fake/String.java": """
                    package fake;
                    public class String {}
                """,
                "annotations/ExactStringRead.java": """
                    package annotations;
                    import fake.String;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface ExactStringRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "annotations/WildcardStringRead.java": """
                    package annotations;
                    import fake.*;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface WildcardStringRead {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.ExactStringRead;
                    import annotations.WildcardStringRead;
                    class Api {
                        @ExactStringRead(route = "/exact") void exact() {}
                        @WildcardStringRead(route = "/wildcard") void wildcard() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_missing_required_non_alias_element_is_rejected(self):
        endpoints = self.analyze_module(
            "missing-required-composed-element",
            {
                "annotations/RequiredRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/required", method = RequestMethod.GET)
                    public @interface RequiredRead {
                        String description();
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.RequiredRead;
                    class Api {
                        @RequiredRead void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_package_private_composed_annotation_is_not_importable(self):
        endpoints = self.analyze_module(
            "package-private-composed",
            {
                "annotations/HiddenRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/hidden", method = RequestMethod.GET)
                    @interface HiddenRead {}
                """,
                "api/Api.java": """
                    package api;
                    import annotations.HiddenRead;
                    class Api {
                        @HiddenRead void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_006_get_mapping_meta_declaration_is_rejected(self):
        endpoints = self.analyze_module(
            "invalid-get-mapping-meta",
            {
                "annotations/InvalidRead.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.GetMapping;
                    @Retention(RetentionPolicy.RUNTIME)
                    @GetMapping("/invalid-meta")
                    public @interface InvalidRead {}
                """,
                "api/Api.java": """
                    package api;
                    import annotations.InvalidRead;
                    class Api {
                        @InvalidRead void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])
        self.assert_diagnostic_was_written()

    def test_02_spr_007_direct_mapping_remains_beside_composed_mapping(self):
        endpoints = self.analyze_module(
            "direct-and-composed",
            {
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Read;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping("/direct") void direct() {}
                        @Read(route = "/composed") void composed() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/direct", "Api.direct"),
                ("GET", "/composed", "Api.composed"),
            },
        )

    def test_02_spr_007_direct_mapping_wildcard_collision_is_rejected(self):
        endpoints = self.analyze_module(
            "direct-mapping-wildcard-collision",
            {
                "fake/GetMapping.java": """
                    package fake;
                    public @interface GetMapping {
                        String value() default "";
                    }
                """,
                "api/Api.java": """
                    package api;
                    import fake.*;
                    import org.springframework.web.bind.annotation.*;
                    class Api {
                        @GetMapping("/ambiguous") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])

    def test_02_spr_007_same_package_non_annotation_shadows_composed_wildcard(self):
        endpoints = self.analyze_module(
            "same-package-composed-shadow",
            {
                "composed/Read.java": """
                    package composed;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(path = "/composed", method = RequestMethod.GET)
                    public @interface Read {}
                """,
                "api/Read.java": """
                    package api;
                    public class Read {}
                """,
                "api/Api.java": """
                    package api;
                    import composed.*;
                    class Api {
                        @Read void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])

    def test_02_spr_007_non_annotation_get_mapping_shadows_spring_wildcard(self):
        endpoints = self.analyze_module(
            "direct-mapping-non-annotation-shadow",
            {
                "sibling/GetMapping.java": """
                    package sibling;
                    public class GetMapping {}
                """,
                "sibling/Api.java": """
                    package sibling;
                    import org.springframework.web.bind.annotation.*;
                    class Api {
                        @GetMapping("/sibling") void list() {}
                    }
                """,
                "local/Api.java": """
                    package local;
                    import org.springframework.web.bind.annotation.*;
                    class Api {
                        static class GetMapping {}
                        @GetMapping("/local") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(endpoints, [])

    def test_02_spr_007_unrelated_nested_type_does_not_shadow_exact_mapping(self):
        endpoints = self.analyze_module(
            "owner-aware-direct-mapping-shadow",
            {
                "api/Unrelated.java": """
                    package api;
                    class Unrelated {
                        static class GetMapping {}
                    }
                """,
                "api/Api.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @GetMapping("/ok") void list() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/ok", "Api.list")},
        )

    def test_02_spr_007_first_recognized_direct_or_composed_mapping_wins(self):
        endpoints = self.analyze_module(
            "first-direct-or-composed",
            {
                "annotations/Read.java": """
                    package annotations;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import org.springframework.core.annotation.AliasFor;
                    import org.springframework.web.bind.annotation.RequestMapping;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    @Retention(RetentionPolicy.RUNTIME)
                    @RequestMapping(method = RequestMethod.GET)
                    public @interface Read {
                        @AliasFor(annotation = RequestMapping.class, attribute = "path")
                        String[] route() default {};
                    }
                """,
                "api/Api.java": """
                    package api;
                    import annotations.Read;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class Api {
                        @Read(route = "/composed-first")
                        @GetMapping("/ignored-direct")
                        void composedFirst() {}

                        @GetMapping("/direct-first")
                        @Read(route = "/ignored-composed")
                        void directFirst() {}
                    }
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/composed-first", "Api.composedFirst"),
                ("GET", "/direct-first", "Api.directFirst"),
            },
        )

    def test_02_gen_001_spring_only_does_not_run_jax_enrichment(self):
        endpoints = self.analyze_module(
            "spring-only-isolation",
            {
                "api/SpringApi.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    class SpringApi {
                        @GetMapping("/spring") void list() {}
                    }
                """,
                "jax/BrokenApplication.java": """
                    package jax;
                    @jakarta.ws.rs.ApplicationPath(Missing.ROOT)
                    public class BrokenApplication
                        extends jakarta.ws.rs.core.Application {}
                """,
                "jax/BROKEN.java": """
                    package jax;
                    @jakarta.ws.rs.HttpMethod(Missing.METHOD)
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    public @interface BROKEN {}
                """,
            },
            "spring",
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {("GET", "/spring", "SpringApi.list")},
        )
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertNotIn("Skipped JAX-RS", diagnostic)

    def test_02_gen_001_repeated_full_framework_analysis_is_deterministic(self):
        files = {
            "paths/Paths.java": """
                package paths;
                public final class Paths {
                    public static final String ROOT = "/stable";
                }
            """,
            "api/SpringApi.java": """
                package api;
                import paths.Paths;
                import org.springframework.web.bind.annotation.GetMapping;
                class SpringApi {
                    @GetMapping(Paths.ROOT + "/spring") void list() {}
                }
            """,
            "api/JaxResource.java": """
                package api;
                import paths.Paths;
                @jakarta.ws.rs.Path(Paths.ROOT + "/jax")
                class JaxResource {
                    @jakarta.ws.rs.GET public void list() {}
                }
            """,
        }
        first = self.analyze_module("deterministic", files)
        second = self.analyze_module("deterministic", dict(reversed(list(files.items()))))
        self.assertEqual(first, second)
        self.assertEqual(
            self.endpoint_keys(first),
            {
                ("GET", "/stable/spring", "SpringApi.list"),
                ("GET", "/stable/jax", "JaxResource.list"),
            },
        )


if __name__ == "__main__":
    unittest.main()
