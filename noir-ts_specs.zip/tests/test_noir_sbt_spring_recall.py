from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_spring_recall  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class SpringRecallExtensionTests(unittest.TestCase):
    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze(self, directory_name, files, *, include_annotations=False):
        module_root = self.root / directory_name
        source_by_file = {}
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
            source_by_file[str(source_file)] = source.encode("utf8")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        workspace = noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=noir_sbt.build_jax_runtime(),
            include_jax=False,
        )
        endpoints = noir_sbt_spring_recall.analyze_spring_recall(
            workspace, noir_sbt
        )
        if include_annotations:
            spring_runtime = noir_sbt.build_spring_runtime()
            for fname in sorted(source_by_file):
                endpoints.extend(
                    noir_sbt.SpringBoot_Analyzer(
                        fname,
                        source_by_file[fname],
                        runtime=spring_runtime,
                        workspace=workspace,
                    )
                )
        return endpoints

    @staticmethod
    def endpoint_keys(endpoints):
        return {
            (
                endpoint["method"],
                endpoint["uri"],
                endpoint["SFunction"],
                endpoint["uri_params"],
            )
            for endpoint in endpoints
        }

    def assert_recall_diagnostic(self):
        diagnostic = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("Skipped Spring recall", diagnostic)

    def test_host_analyze_module_runs_additive_spring_recall_once(self):
        module_root = self.root / "host-integration"
        source_file = module_root / "api/Routes.java"
        source_file.parent.mkdir(parents=True, exist_ok=True)
        source_file.write_text(
            """
                package api;
                import org.springframework.context.annotation.Bean;
                import org.springframework.web.servlet.function.RouterFunction;
                import org.springframework.web.servlet.function.RouterFunctions;
                import org.springframework.web.servlet.function.ServerRequest;
                import org.springframework.web.servlet.function.ServerResponse;
                import org.springframework.web.bind.annotation.GetMapping;
                class Routes {
                    @GetMapping("/annotated") String annotated() { return ""; }
                    @Bean RouterFunction<ServerResponse> routes() {
                        return RouterFunctions.route()
                            .GET("/functional", this::functional)
                            .build();
                    }
                    ServerResponse functional(ServerRequest request) { return null; }
                }
            """,
            encoding="utf8",
        )
        Path(noir_sbt.log_file).write_text("", encoding="utf8")
        endpoints = noir_sbt.analyze_module(module_root, "spring")
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/annotated", "Routes.annotated", ""),
                (
                    "GET",
                    "/functional",
                    "Routes.functional",
                    "ServerRequest request",
                ),
            },
        )
        self.assertEqual(len(endpoints), 2)

    def test_functional_routes_are_additive_for_hybrid_servlet_and_webflux(self):
        endpoints = self.analyze(
            "functional-hybrid",
            {
                "api/HybridController.java": """
                    package api;
                    import org.springframework.web.bind.annotation.GetMapping;
                    import org.springframework.web.bind.annotation.RestController;
                    @RestController
                    public class HybridController {
                        @GetMapping("/annotated")
                        public String annotated() { return ""; }
                    }
                """,
                "api/WebRoutes.java": """
                    package api;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.RequestPredicates;
                    import org.springframework.web.reactive.function.server.ServerRequest;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    public class WebRoutes {
                        private static final String GET_PATH = "/web-get";
                        @Bean
                        RouterFunction<ServerResponse> routes() {
                            return RouterFunctions.route(
                                RequestPredicates.GET(GET_PATH), this::get
                            ).andRoute(
                                RequestPredicates.POST("/web-post"), this::post
                            );
                        }
                        ServerResponse get(ServerRequest request) { return null; }
                        ServerResponse post(ServerRequest request) { return null; }
                    }
                """,
                "api/ServletRoutes.java": """
                    package api;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.servlet.function.RouterFunction;
                    import org.springframework.web.servlet.function.RouterFunctions;
                    import org.springframework.web.servlet.function.ServerRequest;
                    import org.springframework.web.servlet.function.ServerResponse;
                    public class ServletRoutes {
                        @Bean
                        RouterFunction<ServerResponse> routes() {
                            return RouterFunctions.route()
                                .PUT("/servlet-put", this::put)
                                .DELETE("/servlet-delete", this::delete)
                                .build();
                        }
                        ServerResponse put(ServerRequest request) { return null; }
                        ServerResponse delete(ServerRequest request) { return null; }
                    }
                """,
            },
            include_annotations=True,
        )
        self.assertEqual(len(endpoints), 5)
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/annotated", "HybridController.annotated", ""),
                (
                    "GET",
                    "/web-get",
                    "WebRoutes.get",
                    "ServerRequest request",
                ),
                (
                    "POST",
                    "/web-post",
                    "WebRoutes.post",
                    "ServerRequest request",
                ),
                (
                    "PUT",
                    "/servlet-put",
                    "ServletRoutes.put",
                    "ServerRequest request",
                ),
                (
                    "DELETE",
                    "/servlet-delete",
                    "ServletRoutes.delete",
                    "ServerRequest request",
                ),
            },
        )

    def test_functional_noir_fixture_nested_predicates_and_handler_fallback(self):
        endpoints = self.analyze(
            "functional-noir-parity",
            {
                "routes/MyRoutingConfiguration.java": """
                    package routes;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.http.MediaType;
                    import org.springframework.web.reactive.function.server.RequestPredicate;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
                    import static org.springframework.web.reactive.function.server.RouterFunctions.route;
                    public class MyRoutingConfiguration {
                        private static final RequestPredicate ACCEPT_JSON =
                            accept(MediaType.APPLICATION_JSON);
                        @Bean
                        RouterFunction<ServerResponse> monoRouterFunction(
                            /* docs */ MyUserHandler userHandler
                        ) {
                            return /* docs */ route()
                                .GET("/{user}" /* docs */, ACCEPT_JSON, userHandler::getUser)
                                .HEAD("/{user}/metadata", ACCEPT_JSON, userHandler::getUser)
                                .GET("/{user}/customers", ACCEPT_JSON, userHandler::getUserCustomers)
                                .GET("/{user}/stream", ACCEPT_JSON, userHandler::getUserCustomers)
                                .DELETE("/{user}", ACCEPT_JSON, userHandler::deleteUser)
                                .POST("/{user}", ACCEPT_JSON, userHandler::getUser)
                                .PUT("/{user}", ACCEPT_JSON, userHandler::getUserCustomers)
                                .OPTIONS("/{user}/options", ACCEPT_JSON, userHandler::getUserCustomers)
                                .build();
                        }
                    }
                """,
                "routes/QuoteRouter.java": """
                    package routes;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.http.MediaType;
                    import org.springframework.web.reactive.function.server.RequestPredicates;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
                    import static org.springframework.web.reactive.function.server.RequestPredicates.POST;
                    import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
                    import static org.springframework.web.reactive.function.server.RequestPredicates.contentType;
                    public class QuoteRouter {
                        @Bean
                        RouterFunction<ServerResponse> routes(QuoteHandler quoteHandler) {
                            return RouterFunctions.route(
                                GET("/hello" /* docs */).and(accept(MediaType.TEXT_PLAIN)),
                                quoteHandler::hello
                            ).andRoute(
                                POST("/echo").and(
                                    accept(MediaType.TEXT_PLAIN).and(contentType(MediaType.TEXT_PLAIN))
                                ), quoteHandler::echo
                            ).andRoute(
                                RequestPredicates.PATCH("/quotes/{id}"), quoteHandler::patch
                            ).andRoute(
                                GET("/quotes").and(accept(MediaType.APPLICATION_JSON)),
                                quoteHandler::fetchQuotes
                            ).andRoute(
                                GET("/quotes/stream"), quoteHandler::streamQuotes
                            );
                        }
                    }
                """,
                "routes/ProductRouter.java": """
                    package routes;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.http.MediaType;
                    import org.springframework.web.servlet.function.RequestPredicates;
                    import org.springframework.web.servlet.function.RouterFunction;
                    import org.springframework.web.servlet.function.ServerResponse;
                    import static org.springframework.web.servlet.function.RequestPredicates.accept;
                    import static org.springframework.web.servlet.function.RequestPredicates.path;
                    import static org.springframework.web.servlet.function.RouterFunctions.route;
                    public class ProductRouter {
                        private static final String PRODUCT_ROOT = "/product";
                        private static final String API_ROOT = "/api";
                        private static final String API_VERSION = "/v1";
                        private static final String CATALOG_ROOT = "/catalog";
                        @Bean
                        RouterFunction<ServerResponse> productSearch() {
                            return route().nest(
                                RequestPredicates.path(PRODUCT_ROOT),
                                builder -> builder
                                    .GET("/name/{name}", request -> null)
                                    .GET("/id/{id}", request -> null)
                            ).build();
                        }
                        @Bean
                        RouterFunction<ServerResponse> catalogRoutes() {
                            return route().nest(
                                path(API_ROOT).and(accept(MediaType.APPLICATION_JSON)),
                                api -> api.nest(
                                    path(API_VERSION),
                                    v1 -> v1
                                        .GET(CATALOG_ROOT + "/{id}", request -> null)
                                        .POST(CATALOG_ROOT, request -> null)
                                )
                            ).build();
                        }
                    }
                """,
            },
        )
        expected_routes = {
            ("GET", "/{user}"),
            ("HEAD", "/{user}/metadata"),
            ("GET", "/{user}/customers"),
            ("GET", "/{user}/stream"),
            ("DELETE", "/{user}"),
            ("POST", "/{user}"),
            ("PUT", "/{user}"),
            ("OPTIONS", "/{user}/options"),
            ("GET", "/hello"),
            ("POST", "/echo"),
            ("PATCH", "/quotes/{id}"),
            ("GET", "/quotes"),
            ("GET", "/quotes/stream"),
            ("GET", "/product/name/{name}"),
            ("GET", "/product/id/{id}"),
            ("GET", "/api/v1/catalog/{id}"),
            ("POST", "/api/v1/catalog"),
        }
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"]) for endpoint in endpoints},
            expected_routes,
        )
        self.assertEqual(len(endpoints), 17)
        for endpoint in endpoints:
            if endpoint["uri"].startswith("/product") or endpoint["uri"].startswith("/api/"):
                self.assertEqual(endpoint["SFunction"], "ProductRouter." + (
                    "productSearch" if endpoint["uri"].startswith("/product") else "catalogRoutes"
                ))
                self.assertEqual(endpoint["uri_params"], "")
            elif endpoint["uri"].startswith("/quotes") or endpoint["uri"] in {"/hello", "/echo"}:
                self.assertEqual(endpoint["SFunction"], "QuoteRouter.routes")
                self.assertEqual(endpoint["uri_params"], "QuoteHandler quoteHandler")
            else:
                self.assertEqual(endpoint["SFunction"], "MyRoutingConfiguration.monoRouterFunction")
                self.assertEqual(
                    endpoint["uri_params"],
                    "/* docs */ MyUserHandler userHandler",
                )
            self.assertEqual(endpoint["RouteSrcFile"], endpoint["SrcFile"])

    def test_functional_block_nest_and_static_nest_emit_composed_routes(self):
        endpoints = self.analyze(
            "functional-valid-nest-forms",
            {
                "routes/NestedRoutes.java": """
                    package routes;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.servlet.function.RouterFunction;
                    import org.springframework.web.servlet.function.RouterFunctions;
                    import org.springframework.web.servlet.function.ServerRequest;
                    import org.springframework.web.servlet.function.ServerResponse;
                    import static org.springframework.web.servlet.function.RequestPredicates.GET;
                    import static org.springframework.web.servlet.function.RequestPredicates.path;
                    import static org.springframework.web.servlet.function.RouterFunctions.route;
                    public class NestedRoutes {
                        @Bean
                        RouterFunction<ServerResponse> builderRoutes() {
                            return route().nest(path("/api"), nested -> {
                                nested.GET("/a", this::a);
                                nested.POST("/b", this::b);
                            }).build();
                        }

                        @Bean
                        RouterFunction<ServerResponse> staticRoutes() {
                            return RouterFunctions.nest(
                                path("/root"),
                                route(GET("/x"), this::x)
                            );
                        }

                        ServerResponse a(ServerRequest request) { return null; }
                        ServerResponse b(ServerRequest request) { return null; }
                        ServerResponse x(ServerRequest request) { return null; }
                    }
                """,
            },
        )

        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (
                    "GET",
                    "/api/a",
                    "NestedRoutes.a",
                    "ServerRequest request",
                ),
                (
                    "POST",
                    "/api/b",
                    "NestedRoutes.b",
                    "ServerRequest request",
                ),
                (
                    "GET",
                    "/root/x",
                    "NestedRoutes.x",
                    "ServerRequest request",
                ),
            },
        )
        self.assertEqual(len(endpoints), 3)

    def test_functional_nested_dynamic_and_identity_affecting_predicates_fail_closed(self):
        endpoints = self.analyze(
            "functional-nested-negative",
            {
                "bad/DynamicPath.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.servlet.function.RouterFunction;
                    import org.springframework.web.servlet.function.RouterFunctions;
                    import org.springframework.web.servlet.function.ServerResponse;
                    public class DynamicPath {
                        @Bean RouterFunction<ServerResponse> routes(String path) {
                            return RouterFunctions.route()
                                .GET(path, request -> null)
                                .build();
                        }
                    }
                """,
                "bad/DynamicNest.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.servlet.function.RequestPredicates;
                    import org.springframework.web.servlet.function.RouterFunction;
                    import org.springframework.web.servlet.function.RouterFunctions;
                    import org.springframework.web.servlet.function.ServerResponse;
                    public class DynamicNest {
                        @Bean RouterFunction<ServerResponse> routes(String prefix) {
                            return RouterFunctions.route().nest(
                                RequestPredicates.path(prefix),
                                nested -> nested.GET("/leaf", request -> null)
                            ).build();
                        }
                    }
                """,
                "bad/SecondPath.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RequestPredicates;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    public class SecondPath {
                        @Bean RouterFunction<ServerResponse> routes() {
                            return RouterFunctions.route(
                                RequestPredicates.GET("/first").and(
                                    RequestPredicates.path("/second")
                                ), request -> null
                            );
                        }
                    }
                """,
                "bad/BlockNest.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.servlet.function.RequestPredicates;
                    import org.springframework.web.servlet.function.RouterFunction;
                    import org.springframework.web.servlet.function.RouterFunctions;
                    import org.springframework.web.servlet.function.ServerResponse;
                    public class BlockNest {
                        @Bean RouterFunction<ServerResponse> routes(boolean enabled) {
                            return RouterFunctions.route().nest(
                                RequestPredicates.path("/nested"),
                                nested -> {
                                    if (enabled) return nested.GET("/one", request -> null);
                                    return nested.GET("/two", request -> null);
                                }
                            ).build();
                        }
                    }
                """,
                "bad/ShadowedPredicate.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.servlet.function.RequestPredicate;
                    import org.springframework.web.servlet.function.RouterFunction;
                    import org.springframework.web.servlet.function.RouterFunctions;
                    import org.springframework.web.servlet.function.ServerResponse;
                    import static org.springframework.web.servlet.function.RequestPredicates.accept;
                    public class ShadowedPredicate {
                        private static final RequestPredicate FILTER = accept(null);
                        @Bean RouterFunction<ServerResponse> routes(RequestPredicate FILTER) {
                            return RouterFunctions.route().GET(
                                "/shadowed", FILTER, request -> null
                            ).build();
                        }
                    }
                """,
            },
        )
        self.assertEqual(endpoints, [])
        self.assert_recall_diagnostic()

    def test_functional_static_imports_resolve_but_lexical_shadowing_fails_closed(self):
        endpoints = self.analyze(
            "functional-static",
            {
                "api/StaticRoutes.java": """
                    package api;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.ServerRequest;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    import static org.springframework.web.reactive.function.server.RouterFunctions.route;
                    import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
                    public class StaticRoutes {
                        @Bean RouterFunction<ServerResponse> routes() {
                            return route(GET("/static"), this::handle);
                        }
                        ServerResponse handle(ServerRequest request) { return null; }
                    }
                """,
                "api/ShadowedRoutes.java": """
                    package api;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.ServerRequest;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    import static org.springframework.web.reactive.function.server.RouterFunctions.route;
                    import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
                    public class ShadowedRoutes {
                        @Bean RouterFunction<ServerResponse> route() {
                            return route(GET("/must-skip"), this::handle);
                        }
                        ServerResponse handle(ServerRequest request) { return null; }
                    }
                """,
            },
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                (
                    "GET",
                    "/static",
                    "StaticRoutes.handle",
                    "ServerRequest request",
                )
            },
        )
        self.assert_recall_diagnostic()

    def test_functional_fake_mixed_and_control_flow_fail_closed_with_handler_fallback(self):
        endpoints = self.analyze(
            "functional-negative",
            {
                "bad/FakeBean.java": """
                    package bad;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.RequestPredicates;
                    import org.springframework.web.reactive.function.server.ServerRequest;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    @interface Bean {}
                    public class FakeBean {
                        @Bean RouterFunction<ServerResponse> routes() {
                            return RouterFunctions.route(
                                RequestPredicates.GET("/fake"), this::handle
                            );
                        }
                        ServerResponse handle(ServerRequest request) { return null; }
                    }
                """,
                "bad/Mixed.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.ServerRequest;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    public class Mixed {
                        @Bean RouterFunction<ServerResponse> routes() {
                            return RouterFunctions.route(
                                org.springframework.web.servlet.function.RequestPredicates.GET("/mixed"),
                                this::handle
                            );
                        }
                        ServerResponse handle(ServerRequest request) { return null; }
                    }
                """,
                "bad/Lambda.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.RequestPredicates;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    public class Lambda {
                        @Bean RouterFunction<ServerResponse> routes() {
                            return RouterFunctions.route(
                                RequestPredicates.GET("/lambda"), request -> null
                            );
                        }
                    }
                """,
                "bad/Overloaded.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.RequestPredicates;
                    import org.springframework.web.reactive.function.server.ServerRequest;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    public class Overloaded {
                        @Bean RouterFunction<ServerResponse> routes() {
                            return RouterFunctions.route(
                                RequestPredicates.GET("/overloaded"), this::handle
                            );
                        }
                        ServerResponse handle(ServerRequest request) { return null; }
                        ServerResponse handle(Object request) { return null; }
                    }
                """,
                "bad/Conditional.java": """
                    package bad;
                    import org.springframework.context.annotation.Bean;
                    import org.springframework.web.reactive.function.server.RouterFunction;
                    import org.springframework.web.reactive.function.server.RouterFunctions;
                    import org.springframework.web.reactive.function.server.RequestPredicates;
                    import org.springframework.web.reactive.function.server.ServerRequest;
                    import org.springframework.web.reactive.function.server.ServerResponse;
                    public class Conditional {
                        @Bean RouterFunction<ServerResponse> routes(boolean enabled) {
                            if (enabled) {
                                return RouterFunctions.route(
                                    RequestPredicates.GET("/conditional"), this::handle
                                );
                            }
                            return RouterFunctions.route(
                                RequestPredicates.GET("/fallback"), this::handle
                            );
                        }
                        ServerResponse handle(ServerRequest request) { return null; }
                    }
                """,
            },
        )
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/lambda", "Lambda.routes", ""),
                ("GET", "/overloaded", "Overloaded.routes", ""),
            },
        )
        self.assert_recall_diagnostic()

    def test_programmatic_split_locals_inline_fanout_and_reflection_overload(self):
        endpoints = self.analyze(
            "programmatic-positive",
            {
                "api/Handler.java": """
                    package api;
                    public class Handler {
                        public String get(Long id) { return ""; }
                        public String get(String id) { return ""; }
                        public String save(String body) { return ""; }
                    }
                """,
                "api/Registration.java": """
                    package api;
                    import java.lang.reflect.Method;
                    import org.springframework.beans.factory.annotation.Autowired;
                    import org.springframework.context.annotation.Configuration;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
                    import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
                    import static org.springframework.web.bind.annotation.RequestMethod.GET;
                    @Configuration
                    public class Registration {
                        private static final String ROOT = "/registered-one";
                        @Autowired
                        void register(
                            RequestMappingHandlerMapping mapping,
                            Handler handler
                        ) throws NoSuchMethodException {
                            RequestMappingInfo info = RequestMappingInfo
                                .paths(ROOT, "/registered-two")
                                .methods(GET, RequestMethod.POST)
                                .build();
                            Method reflected = Handler.class.getMethod("get", Long.class);
                            mapping.registerMapping(info, handler, reflected);
                            mapping.registerMapping(
                                RequestMappingInfo.paths("/registered-any").build(),
                                handler,
                                Handler.class.getMethod("save", String.class)
                            );
                        }
                    }
                """,
            },
        )
        self.assertEqual(len(endpoints), 5)
        self.assertEqual(
            self.endpoint_keys(endpoints),
            {
                ("GET", "/registered-one", "Handler.get", "Long id"),
                ("POST", "/registered-one", "Handler.get", "Long id"),
                ("GET", "/registered-two", "Handler.get", "Long id"),
                ("POST", "/registered-two", "Handler.get", "Long id"),
                ("ANY", "/registered-any", "Handler.save", "String body"),
            },
        )
        self.assertTrue(
            all(endpoint["SrcFile"].endswith("api/Handler.java") for endpoint in endpoints)
        )

    def test_programmatic_activation_builder_data_flow_and_binding_fail_closed(self):
        endpoints = self.analyze(
            "programmatic-negative",
            {
                "bad/Handlers.java": """
                    package bad;
                    class HandlerA { public String get(Long id) { return ""; } }
                    class HandlerB { public String get(Long id) { return ""; } }
                """,
                "bad/Conditional.java": """
                    package bad;
                    import org.springframework.beans.factory.annotation.Autowired;
                    import org.springframework.context.annotation.Configuration;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
                    import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
                    @Configuration class Conditional {
                        @Autowired void register(RequestMappingHandlerMapping mapping, HandlerA handler)
                                throws Exception {
                            if (handler != null) {
                                mapping.registerMapping(
                                    RequestMappingInfo.paths("/conditional")
                                        .methods(RequestMethod.GET).build(),
                                    handler,
                                    HandlerA.class.getMethod("get", Long.class)
                                );
                            }
                        }
                    }
                """,
                "bad/Mutated.java": """
                    package bad;
                    import org.springframework.beans.factory.annotation.Autowired;
                    import org.springframework.context.annotation.Configuration;
                    import org.springframework.web.bind.annotation.RequestMethod;
                    import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
                    import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
                    @Configuration class Mutated {
                        @Autowired void register(RequestMappingHandlerMapping mapping, HandlerA handler)
                                throws Exception {
                            RequestMappingInfo info = RequestMappingInfo.paths("/first")
                                .methods(RequestMethod.GET).build();
                            info = RequestMappingInfo.paths("/second")
                                .methods(RequestMethod.GET).build();
                            mapping.registerMapping(
                                info, handler,
                                HandlerA.class.getMethod("get", Long.class)
                            );
                        }
                    }
                """,
                "bad/UnsupportedBuilder.java": """
                    package bad;
                    import org.springframework.beans.factory.annotation.Autowired;
                    import org.springframework.context.annotation.Configuration;
                    import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
                    import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
                    @Configuration class UnsupportedBuilder {
                        @Autowired void register(RequestMappingHandlerMapping mapping, HandlerA handler)
                                throws Exception {
                            mapping.registerMapping(
                                RequestMappingInfo.paths("/headers")
                                    .headers("X-Flag=yes").build(),
                                handler,
                                HandlerA.class.getMethod("get", Long.class)
                            );
                        }
                    }
                """,
                "bad/Mismatch.java": """
                    package bad;
                    import org.springframework.beans.factory.annotation.Autowired;
                    import org.springframework.context.annotation.Configuration;
                    import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
                    import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
                    @Configuration class Mismatch {
                        @Autowired void register(RequestMappingHandlerMapping mapping, HandlerA handler)
                                throws Exception {
                            mapping.registerMapping(
                                RequestMappingInfo.paths("/mismatch").build(),
                                handler,
                                HandlerB.class.getMethod("get", Long.class)
                            );
                        }
                    }
                """,
                "bad/OptionalAutowired.java": """
                    package bad;
                    import org.springframework.beans.factory.annotation.Autowired;
                    import org.springframework.context.annotation.Configuration;
                    import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
                    import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
                    @Configuration class OptionalAutowired {
                        @Autowired(required = false)
                        void register(RequestMappingHandlerMapping mapping, HandlerA handler)
                                throws Exception {
                            mapping.registerMapping(
                                RequestMappingInfo.paths("/optional").build(),
                                handler,
                                HandlerA.class.getMethod("get", Long.class)
                            );
                        }
                    }
                """,
            },
        )
        self.assertEqual(endpoints, [])
        self.assert_recall_diagnostic()


if __name__ == "__main__":
    unittest.main()
