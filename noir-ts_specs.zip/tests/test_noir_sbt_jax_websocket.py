from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402
import noir_sbt_jax_websocket  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class JaxWebSocketRecallTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runtime = noir_sbt.build_jax_runtime()

    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")
        Path(noir_sbt.log_file).write_text("", encoding="utf8")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze(self, files):
        source_by_file = {
            str(self.root / relative_name): source.encode("utf8")
            for relative_name, source in files.items()
        }
        workspace = noir_sbt.build_jax_workspace(
            source_by_file,
            runtime=self.runtime,
        )
        return noir_sbt_jax_websocket.analyze_jax_websocket(workspace, noir_sbt)

    @staticmethod
    def keys(endpoints):
        return {
            (
                endpoint["protocol"],
                endpoint["method"],
                endpoint["uri"],
                endpoint["SFunction"],
            )
            for endpoint in endpoints
        }

    def test_03_jax_ws_001_genuine_families_constants_and_prefix_isolation(self):
        endpoints = self.analyze(
            {
                "paths/Paths.java": """
                    package paths;
                    public final class Paths {
                        public static final String SOCKET = "/socket";
                    }
                """,
                "api/Chat.java": """
                    package api;
                    import jakarta.websocket.server.ServerEndpoint;
                    import paths.Paths;
                    @ServerEndpoint(
                        value = Paths.SOCKET + "/chat",
                        subprotocols = {"chat.v1"}
                    )
                    public class Chat {}
                """,
                "Legacy.java": """
                    @javax.websocket.server.ServerEndpoint("legacy")
                    public record Legacy() {}
                """,
                "api/App.java": """
                    package api;
                    @jakarta.ws.rs.ApplicationPath("/rest")
                    public class App extends jakarta.ws.rs.core.Application {}
                """,
            }
        )
        self.assertEqual(len(endpoints), 2)
        self.assertEqual(
            self.keys(endpoints),
            {
                ("ws", "GET", "/socket/chat", "Chat"),
                ("ws", "GET", "/legacy", "Legacy"),
            },
        )
        self.assertTrue(
            all(endpoint["direction"] == "inbound" for endpoint in endpoints)
        )

    def test_03_jax_ws_002_invalid_identity_path_and_construction_fail_closed(self):
        endpoints = self.analyze(
            {
                "fake/ServerEndpoint.java": """
                    package fake;
                    public @interface ServerEndpoint { String value(); }
                """,
                "api/Fake.java": """
                    package api;
                    import fake.ServerEndpoint;
                    @ServerEndpoint("/fake") public class Fake {}
                """,
                "api/AbstractSocket.java": """
                    package api;
                    @jakarta.websocket.server.ServerEndpoint("/abstract")
                    public abstract class AbstractSocket {}
                """,
                "api/NoDefault.java": """
                    package api;
                    @jakarta.websocket.server.ServerEndpoint("/ctor")
                    public class NoDefault { public NoDefault(String value) {} }
                """,
                "api/Stateful.java": """
                    package api;
                    @javax.websocket.server.ServerEndpoint("/stateful")
                    public record Stateful(String value) {}
                """,
                "api/BadPath.java": """
                    package api;
                    @javax.websocket.server.ServerEndpoint("#fragment")
                    public class BadPath {}
                """,
                "api/Valid.java": """
                    package api;
                    @javax.websocket.server.ServerEndpoint("/valid")
                    public class Valid { public Valid() {} }
                """,
                "duplicates/one/Same.java": """
                    package duplicates;
                    @jakarta.websocket.server.ServerEndpoint("/duplicate-one")
                    public class Same {}
                """,
                "duplicates/two/Same.java": """
                    package duplicates;
                    @jakarta.websocket.server.ServerEndpoint("/duplicate-two")
                    public class Same {}
                """,
            }
        )
        self.assertEqual(self.keys(endpoints), {("ws", "GET", "/valid", "Valid")})
        log = Path(noir_sbt.log_file).read_text(encoding="utf8")
        self.assertIn("Skipped WebSocket endpoint", log)
        self.assertIn("AbstractSocket", log)
        self.assertIn("NoDefault", log)
        self.assertIn("Stateful", log)
        self.assertIn("BadPath", log)
        self.assertIn("duplicate or ambiguous source type identity", log)

    def test_host_runs_websocket_once_and_formats_protocol(self):
        source_file = self.root / "api" / "Socket.java"
        source_file.parent.mkdir(parents=True, exist_ok=True)
        source_file.write_text(
            """
                package api;
                @jakarta.websocket.server.ServerEndpoint("/socket")
                public class Socket {}
            """,
            encoding="utf8",
        )
        endpoints = noir_sbt.analyze_module(self.root, "jaxrx")
        self.assertEqual(self.keys(endpoints), {("ws", "GET", "/socket", "Socket")})
        rows = [
            noir_sbt.format_endpoint(endpoint, "module", self.root)
            for endpoint in endpoints
        ]
        self.assertEqual(rows[0]["interface_type"], "ws GET")


if __name__ == "__main__":
    unittest.main()
