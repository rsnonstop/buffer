from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE_ROOT / "src"))

import noir_sbt  # noqa: E402


TREE_SITTER_AVAILABLE = noir_sbt.tsjava is not None and all(
    value is not None
    for value in (
        noir_sbt.Language,
        noir_sbt.Parser,
        noir_sbt.Query,
        noir_sbt.QueryCursor,
    )
)


@unittest.skipUnless(TREE_SITTER_AVAILABLE, "Tree-sitter dependencies are not installed")
class JaxRSTreeSitterIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runtime = noir_sbt.build_jax_runtime()

    def setUp(self):
        self._old_log_file = noir_sbt.log_file
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self._temporary_directory.name)
        noir_sbt.log_file = str(self.root / "analysis.log")

    def tearDown(self):
        noir_sbt.log_file = self._old_log_file
        self._temporary_directory.cleanup()

    def analyze(self, source, file_name="Api.java", workspace=None):
        return noir_sbt.JaxRS_Analyzer(
            str(self.root / file_name),
            source.encode("utf8"),
            runtime=self.runtime,
            workspace=workspace,
        )

    def write_module(self, directory_name, files):
        module_root = self.root / directory_name
        for relative_name, source in files.items():
            source_file = module_root / relative_name
            source_file.parent.mkdir(parents=True, exist_ok=True)
            source_file.write_text(source, encoding="utf8")
        return module_root

    def analyze_module(self, directory_name, files):
        module_root = self.write_module(directory_name, files)
        with mock.patch("builtins.print"):
            return noir_sbt.analyze_module(module_root, "jaxrx")

    def test_01_jax_001_javax_and_jakarta_direct_resources(self):
        endpoints = self.analyze(
            """
            @javax.ws.rs.Path("/legacy")
            class LegacyResource {
                @javax.ws.rs.GET
                @javax.ws.rs.Path("/items")
                public void items(String value) {}
            }

            @jakarta.ws.rs.Path("/modern")
            class ModernResource {
                @jakarta.ws.rs.POST
                @jakarta.ws.rs.Path("/items")
                public void create(String value) {}
            }
            """
        )
        self.assertEqual(
            {
                (endpoint["method"], endpoint["uri"], endpoint["SFunction"])
                for endpoint in endpoints
            },
            {
                ("GET", "/legacy/items", "LegacyResource.items"),
                ("POST", "/modern/items", "ModernResource.create"),
            },
        )

    def test_01_jax_002_all_standard_designators_and_get_parentheses(self):
        endpoints = self.analyze(
            """
            import jakarta.ws.rs.*;

            @Path("/verbs")
            class VerbResource {
                @GET() @Path("/get") public void get() {}
                @POST @Path("/post") public void post() {}
                @PUT @Path("/put") public void put() {}
                @DELETE @Path("/delete") public void delete() {}
                @PATCH @Path("/patch") public void patch() {}
                @HEAD @Path("/head") public void head() {}
                @OPTIONS @Path("/options") public void options() {}
            }
            """
        )
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"]) for endpoint in endpoints},
            {
                ("GET", "/verbs/get"),
                ("POST", "/verbs/post"),
                ("PUT", "/verbs/put"),
                ("DELETE", "/verbs/delete"),
                ("PATCH", "/verbs/patch"),
                ("HEAD", "/verbs/head"),
                ("OPTIONS", "/verbs/options"),
            },
        )

    def test_01_jax_003_annotation_provenance_and_shadowing(self):
        accepted_sources = (
            """
            import jakarta.ws.rs.Path;
            import jakarta.ws.rs.GET;
            @Path("/exact") class Exact {
                @GET public void run() {}
            }
            """,
            """
            import javax.ws.rs.*;
            @Path("/wildcard") class Wildcard {
                @GET public void run() {}
            }
            """,
            """
            @jakarta.ws.rs.Path("/qualified") class Qualified {
                @jakarta.ws.rs.GET public void run() {}
            }
            """,
        )
        endpoints = []
        for index, source in enumerate(accepted_sources):
            endpoints.extend(self.analyze(source, f"Accepted{index}.java"))

        rejected_sources = (
            """
            import com.example.Path;
            import com.example.GET;
            @Path("/wrong") class Wrong {
                @GET public void run() {}
            }
            """,
            """
            import jakarta.ws.rs.*;
            @interface Path { String value(); }
            @interface GET {}
            @Path("/shadow") class Shadowed {
                @GET public void run() {}
            }
            """,
            """
            import jakarta.ws.rs.*;
            import javax.ws.rs.*;
            @Path("/ambiguous") class Ambiguous {
                @GET public void run() {}
            }
            """,
            """
            @jakarta.ws.rs.Path("/mixed") class MixedFamily {
                @javax.ws.rs.GET public void run() {}
            }
            """,
            """
            package jakarta.ws.rs;
            @interface Path { String value(); }
            @interface GET {}
            @Path("/same-package-shadow") class SamePackageShadow {
                @GET public void run() {}
            }
            """,
        )
        for index, source in enumerate(rejected_sources):
            self.assertEqual(self.analyze(source, f"Rejected{index}.java"), [])

        same_package_shadow = self.analyze_module(
            "same-package-shadow",
            {
                "app/Path.java": """
                    package app;
                    public @interface Path { String value(); }
                """,
                "app/GET.java": """
                    package app;
                    public @interface GET {}
                """,
                "app/Resource.java": """
                    package app;
                    import jakarta.ws.rs.*;
                    @Path("/shadow") class Resource {
                        @GET public void run() {}
                    }
                """,
            },
        )
        self.assertEqual(same_package_shadow, [])

        self.assertEqual(
            {(endpoint["method"], endpoint["uri"]) for endpoint in endpoints},
            {
                ("GET", "/exact"),
                ("GET", "/wildcard"),
                ("GET", "/qualified"),
            },
        )

    def test_01_jax_004_paths_constants_escapes_and_raw_parameters(self):
        endpoints = self.analyze(
            r"""
            import jakarta.ws.rs.*;

            @Path(ROOT + "/\u0061pi")
            class Api {
                static final String ROOT = ("/v" + "1");
                static final String ITEM = "/items";

                @GET
                @Path(value = (ITEM + "/{id}"))
                public void item(
                    @Deprecated java.util.Map<String, java.util.List<Integer>> value,
                    String... names
                ) {}

                @POST
                @Path("/literal" + "/tail")
                public void create() {}

                @OPTIONS
                public void options() {}
            }
            """
        )
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"]) for endpoint in endpoints},
            {
                ("GET", "/v1/api/items/{id}"),
                ("POST", "/v1/api/literal/tail"),
                ("OPTIONS", "/v1/api"),
            },
        )
        item = next(endpoint for endpoint in endpoints if endpoint["method"] == "GET")
        self.assertEqual(
            item["uri_params"],
            "@Deprecated java.util.Map<String, java.util.List<Integer>> value,\n"
            "                    String... names",
        )

    def test_01_jax_005_missing_unresolved_paths_and_locator(self):
        endpoints = self.analyze(
            """
            import jakarta.ws.rs.*;

            class MissingRoot {
                @GET public void ignored() {}
            }

            @Path(pathFactory())
            class UnresolvedRoot {
                @GET public void ignored() {}
            }

            @Path("/ok")
            class Good {
                @GET public void direct() {}

                @GET @Path(pathFactory())
                public void unresolvedMethod() {}

                @GET @Path()
                public void missingMethodValue() {}

                @Path("/child")
                public Object locate() { return null; }
            }
            """
        )
        self.assertEqual(
            [(endpoint["method"], endpoint["uri"], endpoint["SFunction"])
             for endpoint in endpoints],
            [("GET", "/ok", "Good.direct")],
        )
        log = Path(noir_sbt.log_file).read_text(encoding="utf8").lower()
        self.assertIn("unresolved", log)
        self.assertIn("unresolvedroot", log)
        self.assertIn("good.unresolvedmethod", log)

    def test_01_jax_006_application_path_single_and_longest_package(self):
        single = self.analyze_module(
            "single-app",
            {
                "deployment/LegacyApplication.java": """
                    package deployment;
                    import javax.ws.rs.ApplicationPath;
                    import javax.ws.rs.core.Application;
                    @ApplicationPath("/base")
                    public class LegacyApplication extends Application {}
                """,
                "resources/Items.java": """
                    package resources;
                    import javax.ws.rs.*;
                    @Path("/items") class Items {
                        @GET public void list() {}
                    }
                """,
            },
        )
        self.assertEqual(
            [(endpoint["method"], endpoint["uri"]) for endpoint in single],
            [("GET", "/base/items")],
        )

        multiple = self.analyze_module(
            "multiple-apps",
            {
                "com/RootApplication.java": """
                    package com;
                    import jakarta.ws.rs.ApplicationPath;
                    import jakarta.ws.rs.core.Application;
                    @ApplicationPath("/global")
                    public class RootApplication extends Application {}
                """,
                "com/alpha/AlphaApplication.java": """
                    package com.alpha;
                    import jakarta.ws.rs.ApplicationPath;
                    import jakarta.ws.rs.core.Application;
                    @ApplicationPath("/alpha")
                    public class AlphaApplication extends Application {}
                """,
                "com/alpha/api/AlphaResource.java": """
                    package com.alpha.api;
                    import jakarta.ws.rs.*;
                    @Path("/items") class AlphaResource {
                        @GET public void list() {}
                    }
                """,
                "com/other/OtherResource.java": """
                    package com.other;
                    import jakarta.ws.rs.*;
                    @Path("/health") class OtherResource {
                        @GET public void health() {}
                    }
                """,
            },
        )
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"]) for endpoint in multiple},
            {("GET", "/alpha/items"), ("GET", "/global/health")},
        )

        ambiguous = self.analyze_module(
            "ambiguous-apps",
            {
                "com/FirstApplication.java": """
                    package com;
                    @jakarta.ws.rs.ApplicationPath("/first")
                    public class FirstApplication
                        extends jakarta.ws.rs.core.Application {}
                """,
                "com/SecondApplication.java": """
                    package com;
                    @jakarta.ws.rs.ApplicationPath("/second")
                    public class SecondApplication
                        extends jakarta.ws.rs.core.Application {}
                """,
                "com/Resource.java": """
                    package com;
                    @jakarta.ws.rs.Path("/items") class Resource {
                        @jakarta.ws.rs.GET public void list() {}
                    }
                """,
            },
        )
        self.assertEqual(ambiguous, [])

    def test_01_jax_007_local_and_imported_custom_http_methods(self):
        endpoints = self.analyze_module(
            "custom-methods",
            {
                "designators/PROPFIND.java": """
                    package designators;
                    @jakarta.ws.rs.HttpMethod(value = "PROPFIND")
                    @java.lang.annotation.Retention(
                        java.lang.annotation.RetentionPolicy.RUNTIME
                    )
                    public @interface PROPFIND {}
                """,
                "api/DavResource.java": """
                    package api;
                    import jakarta.ws.rs.Path;
                    import designators.PROPFIND;
                    @Path("/dav") class DavResource {
                        @PROPFIND public void inspect() {}
                    }
                """,
                "local/ReportResource.java": """
                    package local;
                    import javax.ws.rs.HttpMethod;
                    import javax.ws.rs.Path;
                    import java.lang.annotation.Retention;
                    import java.lang.annotation.RetentionPolicy;
                    import static java.lang.annotation.RetentionPolicy.RUNTIME;
                    import static javax.ws.rs.HttpMethod.OPTIONS;

                    @HttpMethod("REPORT")
                    @Retention(RetentionPolicy.RUNTIME)
                    @interface REPORT {}

                    @HttpMethod(HttpMethod.PATCH)
                    @Retention(RetentionPolicy.RUNTIME)
                    @interface UPDATE {}

                    @HttpMethod(OPTIONS)
                    @Retention(RUNTIME)
                    @interface CHECK {}

                    @Path("/reports") class ReportResource {
                        @REPORT public void report() {}
                        @UPDATE @Path("/patch") public void update() {}
                        @CHECK @Path("/check") public void check() {}
                    }
                """,
            },
        )
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"], endpoint["SFunction"])
             for endpoint in endpoints},
            {
                ("PROPFIND", "/dav", "DavResource.inspect"),
                ("REPORT", "/reports", "ReportResource.report"),
                ("PATCH", "/reports/patch", "ReportResource.update"),
                ("OPTIONS", "/reports/check", "ReportResource.check"),
            },
        )

    def test_01_jax_008_invalid_and_multiple_designators_are_skipped(self):
        endpoints = self.analyze(
            """
            import jakarta.ws.rs.*;
            import java.lang.annotation.Retention;
            import java.lang.annotation.RetentionPolicy;

            @interface FAKE {}

            @HttpMethod("COPY")
            @Retention(RetentionPolicy.CLASS)
            @interface COPY {}

            @HttpMethod(external.Verbs.METHOD)
            @Retention(RetentionPolicy.RUNTIME)
            @interface UNRESOLVED {}

            @HttpMethod("BAD VERB")
            @Retention(RetentionPolicy.RUNTIME)
            @interface BAD_TOKEN {}

            @Path("/invalid") class InvalidResource {
                @FAKE public void fake() {}
                @COPY public void nonRuntime() {}
                @UNRESOLVED public void unresolved() {}
                @BAD_TOKEN public void badToken() {}
                @GET @POST public void multipleStandard() {}
            }
            """
        )
        self.assertEqual(endpoints, [])
        log = Path(noir_sbt.log_file).read_text(encoding="utf8").lower()
        self.assertIn("multiple", log)
        self.assertIn("invalidresource.multiplestandard", log)

    def test_01_jax_009_public_concrete_nested_and_package_less(self):
        endpoints = self.analyze(
            """
            import jakarta.ws.rs.*;

            @Path("/outer")
            class Outer {
                @GET
                public void visible(
                    @Deprecated java.util.List<String> values,
                    String... names
                ) {}

                @GET void hidden() {}

                @Path("/inner")
                static class Inner {
                    @POST @Path("/run") public void run(int value) {}
                }

                @Path("/abstract-nested")
                abstract static class AbstractNested {
                    @GET public void skipped() {}
                }
            }

            @Path("/abstract")
            abstract class AbstractResource {
                @GET public void skipped() {}
            }

            @Path("/contract")
            interface Contract {
                @GET public void skipped();
            }
            """
        )
        self.assertEqual(
            {(endpoint["method"], endpoint["uri"], endpoint["SFunction"])
             for endpoint in endpoints},
            {
                ("GET", "/outer", "Outer.visible"),
                ("POST", "/inner/run", "Outer.Inner.run"),
            },
        )
        visible = next(endpoint for endpoint in endpoints if endpoint["method"] == "GET")
        self.assertEqual(
            visible["uri_params"],
            "@Deprecated java.util.List<String> values,\n"
            "                    String... names",
        )


if __name__ == "__main__":
    unittest.main()
