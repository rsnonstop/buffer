# Standalone ALT Linux 10.4 build kit

**This is build automation, not a prebuilt Noir binary/full runtime bundle.**

This archive carries its own complete helpers, templates, tests and handoff.
It does not require the other target's archive. Shared-source helper code
and both entry-point definitions are retained for testing consistency, but
use the following entry point only on the actual named distribution.

Assumption: x86_64. Read README.md, STATUS.json and CODEX_HANDOFF.md first.

```bash
cd noir-1.4.0-alt104-build-kit
./build-alt104.sh all
```

Run as an ordinary user with sudo in an online disposable ALT Linux 10.4 VM.
The output goes under `out/alt104/`. Its binary and full archives
must still be qualified in a separate clean target VM offline.
