"""Bounded source-only JAX-RS hierarchy and subresource recall.

This module deliberately does not import :mod:`noir_sbt`.  The integrating
analyzer passes that module as ``host`` together with an already-built JAX
workspace.  Keeping the dependency one-way lets the host opt into this recall
pass without an import-time cycle.

``analyze_jax_recall`` is a workspace-level operation.  Its result contains
only rows which the host's direct JAX pass cannot produce: hierarchy-bound
root methods and leaves reached through at least one subresource locator.
"""

# WHY THIS PASS EXISTS — the host's direct JAX analyzer sees annotations on a
# concrete root's own explicit methods.  This additions-only analyzer recovers
# two source-proven endpoint families that require a workspace graph:
#
# 1. annotation inheritance by exact erased Java signature; and
# 2. recursive subresource locator paths to concrete source leaves.
#
# Hierarchy example (one emitted GET /api/contracts/items/{id}):
#
#   @jakarta.ws.rs.Path("/contracts")
#   interface Contract<T> {
#       @jakarta.ws.rs.GET
#       @jakarta.ws.rs.Path("/items/{id}")
#       T item(String id);
#   }
#
#   class Item { /* source-visible or unambiguously imported declaration */ }
#
#   @jakarta.ws.rs.Path("/api")
#   class Resource implements Contract<Item> {
#       public Item item(String id) { ... }
#   }
#
# The concrete method supplies handler attribution and parameters.  The exact
# Contract<Item> edge adapts the signature, and the selected interface supplies
# its type/method @Path plus GET bundle.  A superclass annotation source wins;
# otherwise one maximally specific interface origin must remain.
#
# Locator example (one emitted GET /root/users/{id}/profile):
#
#   @Path("/root") class Root {
#       @Path("/users/{id}") public UserResource user() { ... }
#   }
#   class UserResource {
#       @GET @Path("/profile") public Profile profile() { ... }
#   }
#
# A path-only effective method is a locator.  Its declared source return type
# must resolve to one concrete workspace class/record.  The returned type's
# class-level @Path is intentionally *not* composed; only root/application,
# locator-method, selected interface-type, and leaf-method paths participate.
#
# FAIL CLOSED — duplicate FQNs, incomplete/ambiguous type resolution, wildcard
# type arguments, unresolved generic signatures, conflicting annotation
# origins, Javax/Jakarta mixing, classpath-only ancestors/targets, abstract or
# interface locator targets, runtime polymorphism, cycles, and exhausted graph
# or path bounds never produce guessed endpoints.  Direct methods can survive
# an unrelated incomplete hierarchy, but inherited binding cannot.

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


MAX_HIERARCHY_DEPTH = 12
MAX_HIERARCHY_STATES = 256
MAX_SUBRESOURCE_DEPTH = 16
MAX_SUBRESOURCE_STATES = 4096
MAX_COMPOSED_PATH = 8192

# These are independent safety dimensions.  Depth stops long chains, state
# count stops broad graphs, branch-local active sets stop cycles, and path
# length stops a cycle whose textual path grows on every traversal.

JAVA_LANG_TYPES = {
    "Boolean",
    "Byte",
    "Character",
    "CharSequence",
    "Class",
    "Comparable",
    "Double",
    "Enum",
    "Float",
    "Integer",
    "Iterable",
    "Long",
    "Number",
    "Object",
    "Short",
    "String",
    "Throwable",
    "Void",
}

JAX_METHOD_ANNOTATIONS = {
    "BeanParam",
    "Consumes",
    "CookieParam",
    "DefaultValue",
    "Encoded",
    "FormParam",
    "HeaderParam",
    "MatrixParam",
    "Path",
    "PathParam",
    "Produces",
    "QueryParam",
    "Context",
    "Suspended",
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
}

PRIMITIVE_NODE_TYPES = {
    "boolean_type",
    "floating_point_type",
    "integral_type",
    "void_type",
}


# FLOW: TypeRef
# WHY: Represent a Java type independently of Tree-sitter nodes so generic
# substitution, erasure, signature comparison, and target proof share one value.
# IN/OUT: Constructed from parsed type syntax; consumed as immutable kind/name/
# arguments/dimensions data by every hierarchy and locator type operation.
# CALL FLOW: Parse helpers create it; adaptation/signature/edge/target helpers consume it.
# EXAMPLE: ``List<T>[]`` retains declaration, variable argument, and one dimension.
@dataclass(frozen=True)
class TypeRef:
    # ``kind`` distinguishes exact declarations, type variables, primitives,
    # and erasure-only bounds.  Erasure-only refs can match a method signature
    # but are deliberately ineligible as runtime subresource targets.
    kind: str
    name: str
    args: tuple["TypeRef", ...] = ()
    dimensions: int = 0


# FLOW: MethodRecord
# WHY: Preserve the concrete source method separately from an inherited method
# that may later lend it one atomic JAX-RS annotation bundle.
# IN/OUT: ``_parse_methods`` fills AST, owner, annotations, modifiers, and parsed
# types; effective binding and endpoint attribution consume the mutable record.
# CALL FLOW: Index construction creates records; hierarchy/binding/collection read them.
@dataclass
class MethodRecord:
    # Source method fact retained separately from whichever ancestor eventually
    # supplies its effective JAX-RS annotation bundle.
    id: tuple[Any, ...]
    owner: "TypeRecord"
    node: Any
    name: str
    parameters_node: Any
    return_node: Any
    parameter_nodes: tuple[Any, ...]
    annotations: tuple[dict[str, Any], ...]
    parameter_annotations: tuple[dict[str, Any], ...]
    modifiers: frozenset[str]
    method_type_parameters: tuple[str, ...]
    method_type_bounds: dict[str, TypeRef]
    parameter_refs: tuple[TypeRef, ...] | None
    return_ref: TypeRef | None


# FLOW: TypeRecord
# WHY: Hold one unique workspace type plus its generic bounds, explicit methods,
# superclass, and interfaces as the source hierarchy graph node.
# IN/OUT: First created from a unique FQN, then populated by parse passes; graph
# traversal and locator-target selection consume it.
# CALL FLOW: ``_build_index`` creates/populates it; all hierarchy/collection stages use it.
@dataclass
class TypeRecord:
    # One unique workspace FQN plus parsed generic, method, and hierarchy edges.
    fqn: str
    unit: dict[str, Any]
    type_info: dict[str, Any]
    kind: str
    type_parameters: tuple[str, ...]
    type_bounds: dict[str, TypeRef] = field(default_factory=dict)
    methods: list[MethodRecord] = field(default_factory=list)
    superclass: TypeRef | None = None
    superclass_declared: bool = False
    interfaces: tuple[TypeRef, ...] = ()
    interfaces_valid: bool = True


# FLOW: TypeState
# WHY: Make a subresource traversal state include its adapted generic environment,
# preventing both false cycle merges and endless revisits of the same exact state.
# IN/OUT: Resource FQN plus stable environment key -> immutable/hashable state.
# CALL FLOW: ``_collect`` constructs it; branch-local active-type guards consume it.
@dataclass(frozen=True)
class TypeState:
    # Generic environment is part of traversal identity: Box<A> and Box<B> are
    # distinct states even when they share the same source declaration.
    record_fqn: str
    env_key: tuple[tuple[str, TypeRef], ...]


# FLOW: HierarchyContext
# WHY: Return the class chain, interface entry points, and completeness proof as
# one unit so callers cannot accidentally inherit from a partially resolved graph.
# IN/OUT: ``_hierarchy`` constructs ordered states and Boolean; effective-method
# selection consumes all three fields atomically.
# CALL FLOW: Hierarchy construction produces it; ``_effective_methods`` consumes it.
@dataclass
class HierarchyContext:
    # ``complete`` is a proof gate for inherited binding.  Direct annotated
    # methods remain independently usable when an unrelated edge is incomplete.
    class_states: list[tuple[TypeRecord, dict[str, TypeRef]]]
    interface_roots: list[tuple[TypeRecord, dict[str, TypeRef]]]
    complete: bool


# FLOW: EffectiveMethod
# WHY: Join one eligible implementation, its adapted environment, the selected
# annotation source, decoded leaf/locator binding, and exact erased signature.
# IN/OUT: Effective-method analysis creates records; recursive collection turns
# them into endpoint rows or follows their locator return types.
# CALL FLOW: ``_effective_methods`` produces it; path/target/endpoint helpers consume it.
@dataclass
class EffectiveMethod:
    # Keep implementation and annotation source distinct.  This prevents an
    # interface declaration from masquerading as the concrete request handler.
    implementation: MethodRecord
    implementation_env: dict[str, TypeRef]
    annotation_source: MethodRecord
    binding: dict[str, Any]
    hierarchy_added: bool
    signature: tuple[str, tuple[str, ...]] | None


# FLOW: JaxRecallAnalyzer
# WHY: Own the per-workspace indexes/caches and coordinate exact hierarchy
# annotation inheritance plus recursive JAX-RS subresource discovery.
# IN/OUT: Constructed with a built host workspace and host helper API; ``analyze``
# returns additions that the host appends to direct JAX-RS facts.
# CALL FLOW: ``analyze_jax_recall`` constructs it; its methods feed final host formatting.
class JaxRecallAnalyzer:
# FLOW: JaxRecallAnalyzer.__init__
# WHY: Establish analyzer-local type/signature/effective-method state once so
# every root and locator branch reuses identical source identities and caches.
# IN/OUT: Built workspace plus host API -> initialized analyzer with populated type index.
# CALL FLOW: The public adapter calls it; ``_build_index`` runs immediately and ``analyze`` follows.
    def __init__(self, workspace: dict[str, Any], host: Any):
        # ``host`` provides the already-tested parser helpers, provenance-aware
        # annotation resolution, constants, path composition, and diagnostics.
        self.workspace = workspace
        self.host = host
        self.types: dict[str, TypeRecord] = {}
        self._signature_cache: dict[tuple[Any, ...], tuple[str, tuple[str, ...]] | None] = {}
        self._effective_cache: dict[tuple[Any, ...], list[EffectiveMethod]] = {}
        self._build_index()

# FLOW: JaxRecallAnalyzer.log
# WHY: Route every graph/binding rejection through the host's consistent JAX
# diagnostic format while deriving the correct method or type owner label.
# IN/OUT: MethodRecord/TypeRecord, reason, optional expression -> host log side effect.
# CALL FLOW: Traversal and decoding gates call this leaf; diagnostics consume output.
    def log(self, method_or_type: Any, message: str, expression: str | None = None) -> None:
        # Diagnostics always name the effective source owner; unsupported graph
        # evidence is observable instead of silently becoming a partial route.
        if isinstance(method_or_type, MethodRecord):
            unit = method_or_type.owner.unit
            owner = f"{method_or_type.owner.type_info['display_name']}.{method_or_type.name}"
        else:
            unit = method_or_type.unit
            owner = method_or_type.type_info["display_name"]
        self.host.log_jax_issue(unit["fname"], owner, message, expression)

    # ------------------------------------------------------------------
    # Workspace source/type model

# FLOW: JaxRecallAnalyzer._build_index
# WHY: Build unique source type identities before parsing any cross-file edge,
# method signature, or generic bound, eliminating source-order dependence.
# IN/OUT: Reads host ``type_declarations``; fills ``self.types`` and each record's
# bounds, edges, and explicit methods.  Duplicate FQNs contribute no record.
# CALL FLOW: ``__init__`` calls it; all later hierarchy/locator operations consume index.
# EXAMPLE: Two declarations of ``p.Api`` make every graph edge to that FQN unresolved.
    def _build_index(self) -> None:
        # Only unique workspace-visible identities can take part.  Duplicate
        # declarations stay absent, so every edge to one fails closed.
        for fqn, declarations in self.workspace.get("type_declarations", {}).items():
            if len(declarations) != 1:
                # No first-wins binding when two scanned modules declare the
                # same FQN: every edge to that identity remains unresolved.
                continue
            declaration = declarations[0]
            info = declaration["type_info"]
            if info["node"].type not in {
                "class_declaration",
                "interface_declaration",
                "record_declaration",
            }:
                continue
            parameters, _bound_nodes = self._type_parameter_nodes(info["node"])
            self.types[fqn] = TypeRecord(
                fqn=fqn,
                unit=declaration["unit"],
                type_info=info,
                kind=info["node"].type,
                type_parameters=tuple(parameters),
            )

        # Parse after every identity exists, so cross-file edges and method
        # types use one consistent resolver.
        for record in self.types.values():
            # Two-phase construction matters: all exact type identities exist
            # before any cross-file edge or method signature is parsed.
            parameters, bound_nodes = self._type_parameter_nodes(record.type_info["node"])
            type_vars = set(parameters)
            record.type_bounds = {
                name: (
                    self._parse_type_ref(record, bound_nodes.get(name), type_vars)
                    or TypeRef("decl", "java.lang.Object")
                )
                for name in parameters
            }
            self._parse_edges(record, type_vars)
            self._parse_methods(record, type_vars)

# FLOW: JaxRecallAnalyzer._type_parameter_nodes
# WHY: Extract declared generic variable names and first erasure-bound syntax
# without evaluating full Java intersection semantics.
# IN/OUT: Type or method declaration AST -> ordered names and name-to-bound-node map.
# CALL FLOW: Index/method parsing call it; type-reference parsing consumes bound nodes.
# EXAMPLE: ``<T extends A & B>`` returns T with A as its bounded erasure source.
    def _type_parameter_nodes(self, declaration_node: Any) -> tuple[list[str], dict[str, Any]]:
        # Extract only the first declared bound for erasure.  For an
        # intersection such as ``T extends A & B``, this bounded model uses A
        # and deliberately ignores the additional bounds rather than modeling
        # their complete member/intersection semantics.
        parameters_node = next(
            (child for child in declaration_node.named_children if child.type == "type_parameters"),
            None,
        )
        names: list[str] = []
        bounds: dict[str, Any] = {}
        if parameters_node is None:
            return names, bounds
        for parameter in parameters_node.named_children:
            if parameter.type != "type_parameter" or not parameter.named_children:
                continue
            name_node = parameter.named_children[0]
            name = self.host.node_text(self._unit_source_for_node(declaration_node), name_node)
            names.append(name)
            bound = next(
                (child for child in parameter.named_children if child.type == "type_bound"),
                None,
            )
            if bound is not None and bound.named_children:
                bounds[name] = bound.named_children[0]
        return names, bounds

# FLOW: JaxRecallAnalyzer._unit_source_for_node
# WHY: Recover the correct file bytes for a Tree-sitter node whose byte offsets
# are only meaningful inside its owning parsed tree.
# IN/OUT: Any retained node -> matching workspace unit's immutable source bytes;
# raises when the supplied node does not belong to this workspace.
# CALL FLOW: Type-parameter parsing calls this leaf; host ``node_text`` consumes bytes.
    def _unit_source_for_node(self, node: Any) -> bytes:
        # Nodes are kept alive by their workspace unit.  Byte ranges alone are
        # not globally unique, so locate the containing tree by ancestry.
        current = node
        # A Tree-sitter byte range is file-local, so root-node ownership—not
        # offsets alone—selects the correct source bytes.
        while getattr(current, "parent", None) is not None:
            current = current.parent
        for unit in self.workspace["units"].values():
            if unit["tree"].root_node == current:
                return unit["source"]
        raise KeyError("Tree-sitter node is not owned by the supplied workspace")

# FLOW: JaxRecallAnalyzer._modifier_names
# WHY: Normalize direct Java modifier tokens into a set used by eligibility and
# override rules without repeated AST walking.
# IN/OUT: Declaration node -> immutable modifier-name set, empty when absent.
# CALL FLOW: Method parsing calls it; implementation/ancestor gates consume the set.
    @staticmethod
    def _modifier_names(node: Any) -> frozenset[str]:
        modifiers = next((child for child in node.children if child.type == "modifiers"), None)
        if modifiers is None:
            return frozenset()
        return frozenset(child.type for child in modifiers.children)

# FLOW: JaxRecallAnalyzer._parse_methods
# WHY: Convert only explicit source method declarations into exact method facts;
# implicit record accessors remain the direct host analyzer's responsibility.
# IN/OUT: TypeRecord plus owner type-variable names -> appends MethodRecords with
# annotations, raw nodes, modifiers, and parsed parameter/return references.
# CALL FLOW: ``_build_index`` calls it; signature and effective-binding stages consume methods.
# EXAMPLE: One unsupported overload parameter makes that method's signature ``None``.
    def _parse_methods(self, record: TypeRecord, owner_type_vars: set[str]) -> None:
        # Only explicit method_declaration nodes enter this graph.  Compiler-
        # synthesized record accessors are handled by the host's direct pass
        # and do not become inherited handlers or locator leaves here.
        body = self.host.child_by_field(record.type_info["node"], "body")
        if body is None:
            return
        for method_node in body.named_children:
            if method_node.type != "method_declaration":
                continue
            name_node = self.host.child_by_field(method_node, "name")
            parameters_node = self.host.child_by_field(method_node, "parameters")
            return_node = self.host.child_by_field(method_node, "type")
            if name_node is None or parameters_node is None or return_node is None:
                continue
            method_params, method_bound_nodes = self._type_parameter_nodes(method_node)
            all_type_vars = owner_type_vars | set(method_params)
            method_bounds = {
                name: (
                    self._parse_type_ref(record, method_bound_nodes.get(name), all_type_vars)
                    or TypeRef("decl", "java.lang.Object")
                )
                for name in method_params
            }
            parameter_nodes = tuple(
                child
                for child in parameters_node.named_children
                if child.type in {"formal_parameter", "spread_parameter"}
            )
            parameter_refs: list[TypeRef] = []
            # Signature binding is atomic: one unsupported parameter type makes
            # the complete erased signature unavailable.
            parameters_valid = True
            for parameter in parameter_nodes:
                ref = self._parse_parameter_ref(record, parameter, all_type_vars)
                if ref is None:
                    parameters_valid = False
                    break
                parameter_refs.append(ref)
            annotations = tuple(self.host.direct_annotation_records(method_node))
            parameter_annotations = tuple(
                annotation
                for parameter in parameter_nodes
                for annotation in self.host.direct_annotation_records(parameter)
            )
            record.methods.append(
                MethodRecord(
                    id=(record.unit["fname"], method_node.start_byte, method_node.end_byte),
                    owner=record,
                    node=method_node,
                    name=self.host.node_text(record.unit["source"], name_node),
                    parameters_node=parameters_node,
                    return_node=return_node,
                    parameter_nodes=parameter_nodes,
                    annotations=annotations,
                    parameter_annotations=parameter_annotations,
                    modifiers=self._modifier_names(method_node),
                    method_type_parameters=tuple(method_params),
                    method_type_bounds=method_bounds,
                    parameter_refs=tuple(parameter_refs) if parameters_valid else None,
                    return_ref=self._parse_type_ref(record, return_node, all_type_vars),
                )
            )

# FLOW: JaxRecallAnalyzer._parse_edges
# WHY: Preserve exact declared superclass/interface relationships and distinguish
# absent edges from edges whose syntax or identity could not be proven.
# IN/OUT: TypeRecord plus its type variables -> populates superclass/interface
# refs and validity flags; no graph traversal occurs here.
# CALL FLOW: ``_build_index`` calls it; ``_hierarchy`` and ``_edge_state`` consume edges.
# EXAMPLE: One unresolved implemented interface marks the complete interface set invalid.
    def _parse_edges(self, record: TypeRecord, type_vars: set[str]) -> None:
        # Preserve the distinction between "no superclass declared" and "a
        # superclass was declared but could not be parsed/resolved".  Only the
        # latter makes inherited graph evidence incomplete.
        node = record.type_info["node"]
        superclass_node = self.host.child_by_field(node, "superclass")
        record.superclass_declared = superclass_node is not None
        if superclass_node is not None and len(superclass_node.named_children) == 1:
            record.superclass = self._parse_type_ref(
                record, superclass_node.named_children[0], type_vars
            )

        interfaces_node = self.host.child_by_field(node, "interfaces")
        if interfaces_node is None and record.kind == "interface_declaration":
            interfaces_node = next(
                (child for child in node.named_children if child.type == "extends_interfaces"),
                None,
            )
        if interfaces_node is None:
            return
        type_list = next(
            (child for child in interfaces_node.named_children if child.type == "type_list"),
            None,
        )
        edge_nodes = type_list.named_children if type_list is not None else interfaces_node.named_children
        edges: list[TypeRef] = []
        for edge_node in edge_nodes:
            ref = self._parse_type_ref(record, edge_node, type_vars)
            if ref is None:
                # One unresolved implemented/extended interface invalidates
                # inherited selection for this owner; do not use a partial set.
                record.interfaces_valid = False
            else:
                edges.append(ref)
        record.interfaces = tuple(edges)

# FLOW: JaxRecallAnalyzer._parse_parameter_ref
# WHY: Parse a formal parameter's base type and faithfully add Java array/varargs
# dimensions needed for erased overload identity.
# IN/OUT: Owner record, parameter AST, visible type variables -> TypeRef or ``None``.
# CALL FLOW: ``_parse_methods`` calls it; ``_signature`` later consumes the reference.
# EXAMPLE: ``String... values`` becomes the same erased dimension as ``String[]``.
    def _parse_parameter_ref(
        self, record: TypeRecord, parameter: Any, type_vars: set[str]
    ) -> TypeRef | None:
        type_node = self.host.child_by_field(parameter, "type")
        extra_dimensions = 0
        if parameter.type == "spread_parameter":
            # Java varargs erase like one additional array dimension.
            extra_dimensions = 1
            type_node = next(
                (
                    child
                    for child in parameter.named_children
                    if child.type not in {"modifiers", "identifier", "dimensions"}
                ),
                None,
            )
        dimensions = self.host.child_by_field(parameter, "dimensions")
        if dimensions is not None:
            extra_dimensions += self.host.node_text(record.unit["source"], dimensions).count("[")
        ref = self._parse_type_ref(record, type_node, type_vars)
        return self._with_dimensions(ref, extra_dimensions)

# FLOW: JaxRecallAnalyzer._with_dimensions
# WHY: Add array dimensions without mutating immutable TypeRef values and carry
# parse failure through unchanged.
# IN/OUT: Optional TypeRef plus nonnegative extra count -> copied TypeRef or ``None``.
# CALL FLOW: Parameter/type parsing and adaptation call this leaf; signatures consume result.
    @staticmethod
    def _with_dimensions(ref: TypeRef | None, extra: int) -> TypeRef | None:
        if ref is None:
            return None
        return TypeRef(ref.kind, ref.name, ref.args, ref.dimensions + extra)

# FLOW: JaxRecallAnalyzer._parse_type_ref
# WHY: Translate the supported Java type-syntax subset into an exact structural
# TypeRef while rejecting wildcards and shapes unsafe for substitution.
# IN/OUT: Owner record, optional type AST, and in-scope variables -> TypeRef or
# ``None``.  Arrays/generics recurse; declaration names use provenance resolution.
# CALL FLOW: Index/method/edge parsing call it; generic adaptation and signatures consume refs.
# EXAMPLE: ``Map<String,T>`` retains exact arguments, while ``List<?>`` fails closed.
    def _parse_type_ref(
        self, owner: TypeRecord, node: Any | None, type_vars: set[str]
    ) -> TypeRef | None:
        if node is None:
            return None
        if node.type in PRIMITIVE_NODE_TYPES:
            return TypeRef("primitive", self.host.node_text(owner.unit["source"], node).strip())
        if node.type == "array_type":
            base = next((child for child in node.named_children if child.type != "dimensions"), None)
            dimensions = sum(
                self.host.node_text(owner.unit["source"], child).count("[")
                for child in node.named_children
                if child.type == "dimensions"
            )
            return self._with_dimensions(self._parse_type_ref(owner, base, type_vars), dimensions)
        if node.type == "annotated_type":
            children = [
                child
                for child in node.named_children
                if child.type not in {"annotation", "marker_annotation"}
            ]
            return self._parse_type_ref(owner, children[-1] if len(children) == 1 else None, type_vars)
        if node.type == "generic_type":
            # Exact generic arguments are retained for substitution.  Wildcard
            # and type-bound nodes are rejected rather than flattened.
            base = next((child for child in node.named_children if child.type != "type_arguments"), None)
            arguments_node = next(
                (child for child in node.named_children if child.type == "type_arguments"),
                None,
            )
            if base is None or arguments_node is None:
                return None
            base_ref = self._parse_type_ref(owner, base, type_vars)
            if base_ref is None or base_ref.kind != "decl" or base_ref.dimensions:
                return None
            arguments: list[TypeRef] = []
            for argument in arguments_node.named_children:
                if argument.type in {"wildcard", "type_bound"}:
                    return None
                parsed = self._parse_type_ref(owner, argument, type_vars)
                if parsed is None:
                    return None
                arguments.append(parsed)
            return TypeRef("decl", base_ref.name, tuple(arguments))
        if node.type not in {"type_identifier", "scoped_type_identifier", "identifier"}:
            return None
        spelling = self.host.node_text(owner.unit["source"], node).strip()
        if node.type in {"type_identifier", "identifier"} and spelling in type_vars:
            return TypeRef("variable", spelling)
        identity = self._resolve_type_identity(owner, spelling)
        return TypeRef("decl", identity) if identity is not None else None

# FLOW: JaxRecallAnalyzer._resolve_type_identity
# WHY: Resolve a Java type spelling with lexical/import/package precedence so a
# familiar simple name cannot bind to the wrong source or classpath identity.
# IN/OUT: Owner TypeRecord plus spelling -> one FQN/external identity or ``None``.
# CALL FLOW: ``_parse_type_ref`` calls it; parsed TypeRefs feed signatures/graph edges.
# EXAMPLE: Competing accessible wildcard imports make a simple spelling ambiguous.
    def _resolve_type_identity(self, owner: TypeRecord, spelling: str) -> str | None:
        unit = owner.unit
        owner_name = owner.type_info["display_name"]
        # Qualified source or explicit external spelling.
        if "." in spelling:
            candidates = self.host.resolve_workspace_owner_fqns(
                unit, spelling, owner_name, self.workspace
            )
            if len(candidates) == 1:
                return candidates[0]
            # A fully qualified external type has usable identity for method
            # signatures, but never becomes a traversal target.
            if spelling[0].islower() and not candidates:
                # A qualified external type is useful in an erased signature,
                # but absence from ``self.types`` prevents graph traversal.
                return spelling
            return None

        # Lexical member types have the highest source tier.
        for lexical_owner in self.host.lexical_owner_fqns(unit, owner_name):
            candidate = f"{lexical_owner}.{spelling}"
            if self.host.workspace_type_fqn_accessible(
                self.workspace, unit, owner_name, candidate
            ):
                return candidate

        exact = unit["imports"]["exact"].get(spelling)
        # Java-like precedence is lexical member -> exact import -> same
        # package -> unique wildcard import -> selected java.lang type.
        if exact is not None:
            if not exact:
                return None
            declarations = self.workspace["type_declarations"].get(exact, [])
            if declarations:
                return exact if self.host.workspace_type_fqn_accessible(
                    self.workspace, unit, owner_name, exact
                ) else None
            return exact

        same_package = f"{unit['package']}.{spelling}" if unit["package"] else spelling
        if self.host.workspace_type_fqn_accessible(
            self.workspace, unit, owner_name, same_package
        ):
            return same_package

        candidates = {
            f"{package}.{spelling}"
            for package in unit["imports"]["wildcards"]
            if self.host.workspace_type_fqn_accessible(
                self.workspace, unit, owner_name, f"{package}.{spelling}"
            )
        }
        if spelling in JAVA_LANG_TYPES:
            candidates.add(f"java.lang.{spelling}")
        return next(iter(candidates)) if len(candidates) == 1 else None

    # ------------------------------------------------------------------
    # Generic adaptation and signatures

# FLOW: JaxRecallAnalyzer._default_env
# WHY: Supply erasure-only substitutions for raw uses of generic source types,
# allowing signature comparison without claiming an exact runtime locator target.
# IN/OUT: TypeRecord -> map from each type parameter to nonexact bound/Object ref.
# CALL FLOW: Root/edge/target traversal calls it; adaptation/signature logic consumes env.
# EXAMPLE: Raw ``Box`` with ``T extends Item`` maps T to erasure(Item), not exact Item.
    def _default_env(self, record: TypeRecord) -> dict[str, TypeRef]:
        # Raw generic use adapts through the declared/Object bound for erasure,
        # then marks that value nonexact so it cannot identify a runtime target.
        return {
            parameter: self._nonexact_ref(
                self._adapt_ref(
                    record.type_bounds.get(
                        parameter, TypeRef("decl", "java.lang.Object")
                    ),
                    {},
                )
                or TypeRef("decl", "java.lang.Object")
            )
            for parameter in record.type_parameters
        }

# FLOW: JaxRecallAnalyzer._nonexact_ref
# WHY: Mark a bound-derived/raw substitution as usable for erasure but ineligible
# to prove runtime dispatch or a concrete subresource target.
# IN/OUT: Exact/bound TypeRef -> same structural data with ``erasure`` kind.
# CALL FLOW: ``_default_env`` calls this leaf; signature erasure accepts it, target proof rejects it.
    @staticmethod
    def _nonexact_ref(ref: TypeRef) -> TypeRef:
        """Mark a raw/bound substitution as erasure-only, not a runtime target."""

        return TypeRef("erasure", ref.name, ref.args, ref.dimensions)

# FLOW: JaxRecallAnalyzer._adapt_ref
# WHY: Apply an owner/method generic environment recursively while detecting
# variable cycles and preserving arguments and array dimensions.
# IN/OUT: Optional TypeRef, substitution map, recursion stack -> adapted TypeRef
# or ``None`` when a variable is missing/cyclic or a nested argument fails.
# CALL FLOW: Signature, edge, default-env, and locator-target helpers call it; graph facts consume result.
# EXAMPLE: Under T=Item, ``List<T>[]`` becomes ``List<Item>[]``.
    def _adapt_ref(
        self, ref: TypeRef | None, env: dict[str, TypeRef], stack: tuple[str, ...] = ()
    ) -> TypeRef | None:
        if ref is None:
            return None
        if ref.kind == "variable":
            # A stack detects recursive substitutions such as T -> U -> T.
            if ref.name in stack:
                return None
            replacement = env.get(ref.name)
            if replacement is None:
                return None
            adapted = self._adapt_ref(replacement, env, stack + (ref.name,))
            return self._with_dimensions(adapted, ref.dimensions)
        args: list[TypeRef] = []
        for argument in ref.args:
            adapted = self._adapt_ref(argument, env, stack)
            if adapted is None:
                return None
            args.append(adapted)
        return TypeRef(ref.kind, ref.name, tuple(args), ref.dimensions)

# FLOW: JaxRecallAnalyzer._erased_type
# WHY: Reduce an adapted type to Java overload-comparison spelling while retaining
# array rank and refusing an unsubstituted variable.
# IN/OUT: Optional TypeRef -> erased FQN/primitive plus ``[]`` suffixes, or ``None``.
# CALL FLOW: ``_signature`` calls this leaf; hierarchy signature matching consumes strings.
    @staticmethod
    def _erased_type(ref: TypeRef | None) -> str | None:
        if ref is None or ref.kind == "variable":
            return None
        suffix = "[]" * ref.dimensions
        return f"{ref.name}{suffix}"

# FLOW: JaxRecallAnalyzer._env_key
# WHY: Turn a generic substitution mapping into deterministic hashable identity
# for caches, graph states, and cycle/specificity comparisons.
# IN/OUT: Parameter-to-TypeRef map -> sorted tuple of key/value pairs.
# CALL FLOW: Signature/hierarchy/collection helpers call this leaf; caches and guards consume key.
    @staticmethod
    def _env_key(env: dict[str, TypeRef]) -> tuple[tuple[str, TypeRef], ...]:
        return tuple(sorted(env.items()))

# FLOW: JaxRecallAnalyzer._method_env
# WHY: Extend an owner generic environment with bounded substitutions for method
# type parameters before erasing its parameter or return types.
# IN/OUT: MethodRecord and owner environment -> combined substitution dictionary.
# CALL FLOW: Signature and locator-target helpers call it; ``_adapt_ref`` consumes env.
# EXAMPLE: ``<U extends Base> m(U x)`` adds U=Base when comparing signatures.
    def _method_env(self, method: MethodRecord, owner_env: dict[str, TypeRef]) -> dict[str, TypeRef]:
        env = dict(owner_env)
        for parameter in method.method_type_parameters:
            bound = method.method_type_bounds.get(
                parameter, TypeRef("decl", "java.lang.Object")
            )
            env[parameter] = self._adapt_ref(bound, env) or TypeRef(
                "decl", "java.lang.Object"
            )
        return env

# FLOW: JaxRecallAnalyzer._signature
# WHY: Compute exact erased override identity and cache it per method plus adapted
# owner environment, never falling back to method name alone.
# IN/OUT: MethodRecord and owner environment -> ``(name, parameter types)`` or ``None``.
# CALL FLOW: Hierarchy/effective-method lookups call it; override matching consumes result.
# EXAMPLE: Unresolved parameter syntax leaves an overload ineligible for inheritance.
    def _signature(
        self, method: MethodRecord, owner_env: dict[str, TypeRef]
    ) -> tuple[str, tuple[str, ...]] | None:
        key = (method.id, self._env_key(owner_env))
        if key in self._signature_cache:
            return self._signature_cache[key]
        if method.parameter_refs is None:
            # Method name alone is never enough: unresolved overloads must not
            # suppress or acquire inherited annotations.
            self._signature_cache[key] = None
            return None
        env = self._method_env(method, owner_env)
        parameters: list[str] = []
        for ref in method.parameter_refs:
            erased = self._erased_type(self._adapt_ref(ref, env))
            if erased is None:
                self._signature_cache[key] = None
                return None
            parameters.append(erased)
        result = (method.name, tuple(parameters))
        self._signature_cache[key] = result
        return result

# FLOW: JaxRecallAnalyzer._edge_state
# WHY: Follow one declared hierarchy edge only when generic adaptation identifies
# an exact indexed source declaration with compatible argument arity.
# IN/OUT: Edge TypeRef and current environment -> target TypeRecord/environment
# pair or ``None``.  Raw target use receives its default erasure environment.
# CALL FLOW: Class/interface traversals call it; hierarchy contexts/subtype proof consume states.
# EXAMPLE: A classpath-only identity can match signatures but returns ``None`` here.
    def _edge_state(
        self, edge: TypeRef, env: dict[str, TypeRef]
    ) -> tuple[TypeRecord, dict[str, TypeRef]] | None:
        adapted = self._adapt_ref(edge, env)
        if adapted is None or adapted.kind != "decl" or adapted.dimensions:
            return None
        target = self.types.get(adapted.name)
        # Classpath-only declarations have an identity for signature erasure but
        # no source TypeRecord, so they cannot become hierarchy graph edges.
        if target is None:
            return None
        if adapted.args:
            if len(adapted.args) != len(target.type_parameters):
                return None
            target_env = dict(zip(target.type_parameters, adapted.args))
        else:
            target_env = self._default_env(target)
        return target, target_env

    # ------------------------------------------------------------------
    # Hierarchy graph and effective method binding

# FLOW: JaxRecallAnalyzer._hierarchy
# WHY: Build one bounded, generically adapted class chain and interface graph and
# carry a completeness proof that gates every inherited annotation decision.
# IN/OUT: Root TypeRecord and root environment -> HierarchyContext of ordered class
# states, interface roots, and complete/incomplete status.
# CALL FLOW: ``_effective_methods`` calls it; implementation/annotation selection consumes context.
# EXAMPLE: Reaching one generic interface under two unequal environments marks incomplete.
    def _hierarchy(self, root: TypeRecord, root_env: dict[str, TypeRef]) -> HierarchyContext:
        # Superclasses are linear and ordered nearest-first.  Interfaces form a
        # separately bounded transitive graph reached from every class state.
        complete = True
        class_states: list[tuple[TypeRecord, dict[str, TypeRef]]] = []
        seen_classes: set[str] = set()
        current = (root, root_env)
        while current is not None:
            record, env = current
            if record.fqn in seen_classes or len(class_states) >= MAX_HIERARCHY_DEPTH:
                complete = False
                break
            seen_classes.add(record.fqn)
            class_states.append(current)
            if not record.superclass_declared:
                break
            if record.superclass is None:
                complete = False
                break
            following = self._edge_state(record.superclass, env)
            if following is None or following[0].kind != "class_declaration":
                complete = False
                break
            current = following

        interface_roots: list[tuple[TypeRecord, dict[str, TypeRef]]] = []
        state_envs: dict[str, tuple[tuple[str, TypeRef], ...]] = {}
        expanded = 0

# FLOW: JaxRecallAnalyzer._hierarchy.visit
# WHY: Recursively validate the transitive interface portion under independent
# depth/state/cycle bounds while detecting conflicting generic environments.
# IN/OUT: Interface record/environment, depth, active FQNs -> mutates enclosing
# completeness/state maps; it has no standalone return value.
# CALL FLOW: ``_hierarchy`` invokes it for each interface root; HierarchyContext consumes state.
# EXAMPLE: An interface cycle or the 257th expanded state makes inheritance incomplete.
        def visit(record: TypeRecord, env: dict[str, TypeRef], depth: int, active: frozenset[str]) -> None:
            nonlocal complete, expanded
            if depth > MAX_HIERARCHY_DEPTH or expanded >= MAX_HIERARCHY_STATES:
                complete = False
                return
            if record.fqn in active:
                complete = False
                return
            env_key = self._env_key(env)
            previous = state_envs.get(record.fqn)
            if previous is not None:
                if previous != env_key:
                    # Reaching the same generic interface with incompatible
                    # environments makes its adapted signatures ambiguous.
                    complete = False
                return
            state_envs[record.fqn] = env_key
            expanded += 1
            if not record.interfaces_valid:
                complete = False
                return
            for edge in record.interfaces:
                following = self._edge_state(edge, env)
                if following is None or following[0].kind != "interface_declaration":
                    complete = False
                    continue
                visit(following[0], following[1], depth + 1, active | {record.fqn})

        for class_record, class_env in class_states:
            if not class_record.interfaces_valid:
                complete = False
                continue
            for edge in class_record.interfaces:
                following = self._edge_state(edge, class_env)
                if following is None or following[0].kind != "interface_declaration":
                    complete = False
                    continue
                interface_roots.append(following)
                visit(following[0], following[1], 1, frozenset())
        return HierarchyContext(class_states, interface_roots, complete)

# FLOW: JaxRecallAnalyzer._is_public_implementation
# WHY: Enforce the bounded Java method shapes that may serve as concrete handlers,
# distinguishing class/record public instances from real interface defaults.
# IN/OUT: MethodRecord -> Boolean implementation eligibility.
# CALL FLOW: Effective/default-method selection calls this leaf; handler choice consumes it.
# EXAMPLE: Static/private/abstract methods fail; an interface method needs default plus body.
    @staticmethod
    def _is_public_implementation(method: MethodRecord) -> bool:
        # Concrete class/record handlers must be public and instance methods.
        # An interface handler implementation must be a real default body.
        if "static" in method.modifiers or "private" in method.modifiers or "abstract" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return "default" in method.modifiers and method.node.child_by_field_name("body") is not None
        return "public" in method.modifiers

# FLOW: JaxRecallAnalyzer._is_ancestor_annotation_method
# WHY: Filter ancestor declarations to members that can participate in Java-style
# overriding and therefore legitimately lend an annotation bundle.
# IN/OUT: MethodRecord -> Boolean ancestor-source eligibility.
# CALL FLOW: ``_annotation_source`` calls this leaf; superclass precedence consumes matches.
    @staticmethod
    def _is_ancestor_annotation_method(method: MethodRecord) -> bool:
        # An ancestor may supply annotations without being the concrete handler;
        # private/static members cannot participate in Java overriding.
        if "static" in method.modifiers or "private" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return True
        return "public" in method.modifiers or "protected" in method.modifiers

# FLOW: JaxRecallAnalyzer._methods_for_signature
# WHY: Centralize exact erased-signature lookup for one adapted type state.
# IN/OUT: TypeRecord, environment, signature -> all matching MethodRecords.
# CALL FLOW: Interface/class binding helpers call it; ambiguity and precedence logic consume list.
    def _methods_for_signature(
        self,
        record: TypeRecord,
        env: dict[str, TypeRef],
        signature: tuple[str, tuple[str, ...]],
    ) -> list[MethodRecord]:
        return [method for method in record.methods if self._signature(method, env) == signature]

# FLOW: JaxRecallAnalyzer._is_genuine_override
# WHY: Exclude only provenance-proven ``java.lang.Override`` from the atomic
# annotation-bundle rule; a user annotation named Override must still block merging.
# IN/OUT: MethodRecord and annotation record -> Boolean genuine-Override status.
# CALL FLOW: ``_has_atomic_annotation_bundle`` calls this leaf; inheritance gating consumes result.
    def _is_genuine_override(self, method: MethodRecord, annotation: dict[str, Any]) -> bool:
        return self.host.resolve_known_annotation(
            method.owner.unit,
            annotation["name_node"],
            {"Override"},
            ("java.lang",),
        ) is not None

# FLOW: JaxRecallAnalyzer._has_atomic_annotation_bundle
# WHY: Prevent piecemeal merging of method/parameter annotations from different
# hierarchy declarations, including unknown NameBinding-like source annotations.
# IN/OUT: MethodRecord -> Boolean indicating that this declaration owns a bundle.
# CALL FLOW: Annotation-source and direct-method logic call it; branch traversal stops at true.
# EXAMPLE: Genuine Override alone is transparent; Override plus Path is atomic.
    def _has_atomic_annotation_bundle(self, method: MethodRecord) -> bool:
        # Unknown direct annotations conservatively block inheritance.  This
        # covers source NameBinding annotations without guessing their meta
        # provenance.  Genuine @Override is the sole ignored marker.
        if any(not self._is_genuine_override(method, annotation) for annotation in method.annotations):
            # The bundle is atomic: Path, verb, Consumes, a custom designator,
            # or even an unknown/NameBinding annotation blocks piecemeal merge.
            return True
        return bool(method.parameter_annotations)

# FLOW: JaxRecallAnalyzer._interface_branches
# WHY: Search each interface branch for the first exact-signature default
# implementation or atomic annotation source without flattening branch precedence.
# IN/OUT: Adapted interface state, signature, mode, bounds/memo -> candidate
# method/environment identities plus an invalid/incomplete Boolean.
# CALL FLOW: Annotation/default selection invokes it recursively; specificity filtering consumes candidates.
# EXAMPLE: An unannotated child redeclaration allows search to continue to its parent.
    def _interface_branches(
        self,
        state: tuple[TypeRecord, dict[str, TypeRef]],
        signature: tuple[str, tuple[str, ...]],
        mode: str,
        depth: int = 0,
        active: frozenset[str] = frozenset(),
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] | None = None,
    ) -> tuple[set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]], bool]:
        if memo is None:
            memo = {}
        record, env = state
        memo_key = (record.fqn, self._env_key(env), signature, mode)
        if memo_key in memo:
            cached_candidates, cached_invalid = memo[memo_key]
            return set(cached_candidates), cached_invalid
        if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
            return set(), True
        matches = self._methods_for_signature(record, env, signature)
        if len(matches) > 1:
            return set(), True
        if matches:
            method = matches[0]
            if mode == "default":
                # In implementation mode the interface declaration must itself
                # be an eligible default method with a body.
                if self._is_public_implementation(method):
                    result = ({(method.id, self._env_key(env))}, False)
                    memo[memo_key] = result
                    return set(result[0]), result[1]
                return set(), True
            if self._has_atomic_annotation_bundle(method):
                # In annotation mode the first annotated redeclaration on a
                # branch supplies the entire bundle.
                result = ({(method.id, self._env_key(env))}, False)
                memo[memo_key] = result
                return set(result[0]), result[1]
            # An unannotated interface redeclaration does not suppress an
            # annotation bundle on its parent declaration.
        if not record.interfaces_valid:
            return set(), True
        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
        blocked = False
        for edge in record.interfaces:
            following = self._edge_state(edge, env)
            if following is None or following[0].kind != "interface_declaration":
                blocked = True
                continue
            found, invalid = self._interface_branches(
                following,
                signature,
                mode,
                depth + 1,
                active | {record.fqn},
                memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        memo[memo_key] = (set(candidates), blocked)
        return candidates, blocked

# FLOW: JaxRecallAnalyzer._method_from_candidate
# WHY: Convert a stable candidate identity back into the retained source method
# and adapted environment needed for specificity and endpoint attribution.
# IN/OUT: Method-id/environment-key tuple -> MethodRecord/environment pair or ``None``.
# CALL FLOW: Specificity/annotation/default selection calls this leaf; binding consumes pair.
    def _method_from_candidate(
        self,
        candidate: tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]],
    ) -> tuple[MethodRecord, dict[str, TypeRef]] | None:
        method_id, env_key = candidate
        for record in self.types.values():
            for method in record.methods:
                if method.id == method_id:
                    return method, dict(env_key)
        return None

# FLOW: JaxRecallAnalyzer._interface_subtype
# WHY: Prove whether one candidate interface is more specific than another under
# bounded, exact source hierarchy traversal.
# IN/OUT: Candidate method/environment and ancestor FQN -> ``(is_subtype, invalid)``.
# CALL FLOW: ``_maximally_specific_candidates`` calls it; dominance filtering consumes result.
# EXAMPLE: A cycle, unresolved edge, or exceeded bound returns invalid rather than false certainty.
    def _interface_subtype(
        self,
        child: tuple[MethodRecord, dict[str, TypeRef]],
        ancestor_fqn: str,
    ) -> tuple[bool, bool]:
        record = child[0].owner
        env = child[1]
        pending = [(record, env, 0)]
        visited: set[tuple[str, tuple[tuple[str, TypeRef], ...]]] = set()
        while pending:
            current, current_env, depth = pending.pop()
            state_key = (current.fqn, self._env_key(current_env))
            if state_key in visited:
                continue
            visited.add(state_key)
            if depth > MAX_HIERARCHY_DEPTH or len(visited) > MAX_HIERARCHY_STATES:
                return False, True
            if current.fqn == ancestor_fqn and current.fqn != record.fqn:
                return True, False
            if not current.interfaces_valid:
                return False, True
            for edge in current.interfaces:
                following = self._edge_state(edge, current_env)
                if following is None or following[0].kind != "interface_declaration":
                    return False, True
                pending.append((following[0], following[1], depth + 1))
        return False, False

# FLOW: JaxRecallAnalyzer._maximally_specific_candidates
# WHY: Apply Java's most-specific-interface rule and preserve graph uncertainty
# instead of selecting an unrelated surviving declaration by iteration order.
# IN/OUT: Candidate identity set -> undominated set plus invalid Boolean.
# CALL FLOW: Annotation/default selection calls it after branch search; one-origin gates consume result.
# EXAMPLE: Child interface declaration dominates its ancestor; unrelated origins remain ambiguous.
    def _maximally_specific_candidates(
        self,
        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]],
    ) -> tuple[set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]], bool]:
        resolved = {
            candidate: self._method_from_candidate(candidate)
            for candidate in candidates
        }
        if any(value is None for value in resolved.values()):
            return set(), True
        dominated: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
        # Java's more-specific interface wins.  Unrelated surviving origins are
        # ambiguous and are rejected by the caller.
        for candidate, value in resolved.items():
            for other, other_value in resolved.items():
                if candidate == other:
                    continue
                is_subtype, invalid = self._interface_subtype(
                    other_value, value[0].owner.fqn
                )
                if invalid:
                    return set(), True
                if is_subtype:
                    dominated.add(candidate)
                    break
        return candidates - dominated, False

# FLOW: JaxRecallAnalyzer._annotation_source
# WHY: Select one complete atomic annotation origin for an implementation using
# direct, nearest-superclass, then maximally-specific-interface precedence.
# IN/OUT: Implementation/environment/signature, hierarchy context, class index ->
# selected MethodRecord or ``None`` when absent, ambiguous, or incomplete.
# CALL FLOW: ``_effective_methods`` calls it; ``_decode_binding`` consumes source annotations.
# EXAMPLE: An annotated nearest superclass wins before every interface candidate.
    def _annotation_source(
        self,
        implementation: MethodRecord,
        implementation_env: dict[str, TypeRef],
        signature: tuple[str, tuple[str, ...]],
        hierarchy: HierarchyContext,
        implementation_class_index: int | None,
    ) -> MethodRecord | None:
        if self._has_atomic_annotation_bundle(implementation):
            return implementation

        start = (implementation_class_index + 1) if implementation_class_index is not None else 0
        for record, env in hierarchy.class_states[start:]:
            # Nearest eligible superclass annotation source has precedence over
            # every interface source.
            matches = [
                method
                for method in self._methods_for_signature(record, env, signature)
                if self._is_ancestor_annotation_method(method)
            ]
            if len(matches) > 1:
                return None
            if matches and self._has_atomic_annotation_bundle(matches[0]):
                return matches[0]

        candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self._interface_branches(
                interface_root, signature, "annotation", memo=memo
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self._maximally_specific_candidates(candidates)
        blocked = blocked or specificity_invalid
        # A single source declaration reached through a diamond is one origin.
        source_ids = {candidate[0] for candidate in candidates}
        if blocked or len(source_ids) != 1:
            return None
        return self._method_from_candidate(next(iter(candidates)))[0]

# FLOW: JaxRecallAnalyzer._annotation_kind
# WHY: Classify one annotation enough to detect Path/binding evidence while keeping
# invalid or ambiguous custom-designator evidence inside the atomic bundle.
# IN/OUT: MethodRecord and annotation record -> standard name, ``custom``, or ``other``.
# CALL FLOW: Binding/interface-path decoding calls it; path/designator gates consume kind.
# EXAMPLE: Any custom status except ``none`` is custom here and rejected later if unresolved.
    def _annotation_kind(self, method: MethodRecord, annotation: dict[str, Any]) -> str:
        # Standard annotations are classified by proven package identity.
        # Any custom-designator status other than ``none`` is marked custom at
        # this grouping stage—including invalid/ambiguous evidence—so later
        # effective-method binding can reject the entire conflicting bundle.
        unit = method.owner.unit
        for package_group in (
            self.host.JAX_RS_PACKAGES,
            self.host.JAX_RS_CORE_PACKAGES,
            ("jakarta.ws.rs.container", "javax.ws.rs.container"),
        ):
            resolved = self.host.resolve_known_annotation(
                unit,
                annotation["name_node"],
                JAX_METHOD_ANNOTATIONS,
                package_group,
            )
            if resolved is not None:
                return resolved["name"]
        custom = self.host.resolve_custom_designator(
            unit,
            annotation["name_node"],
            self.workspace,
            f"{method.owner.type_info['display_name']}.{method.name}",
        )
        return "custom" if custom["status"] != "none" else "other"

# FLOW: JaxRecallAnalyzer._standard_jax_annotation_family
# WHY: Determine the proven Javax/Jakarta family of a standard method/parameter
# annotation so one effective bundle cannot silently mix API generations.
# IN/OUT: MethodRecord and annotation record -> namespace string or ``None``.
# CALL FLOW: ``_decode_binding`` calls this leaf over the full bundle; namespace gate consumes it.
    def _standard_jax_annotation_family(
        self, method: MethodRecord, annotation: dict[str, Any]
    ) -> str | None:
        unit = method.owner.unit
        package_groups = (
            self.host.JAX_RS_PACKAGES,
            self.host.JAX_RS_CORE_PACKAGES,
            ("jakarta.ws.rs.container", "javax.ws.rs.container"),
        )
        for packages in package_groups:
            resolved = self.host.resolve_known_annotation(
                unit,
                annotation["name_node"],
                JAX_METHOD_ANNOTATIONS,
                packages,
            )
            if resolved is not None:
                return (
                    "jakarta.ws.rs"
                    if resolved["namespace"].startswith("jakarta.ws.rs")
                    else "javax.ws.rs"
                )
        return None

# FLOW: JaxRecallAnalyzer._decode_binding
# WHY: Decode one selected atomic annotation bundle into either a request leaf
# or a path-only subresource locator while enforcing one JAX namespace.
# IN/OUT: Annotation-source MethodRecord and expected namespace -> binding dict
# containing kind/path/designator evidence, or ``None`` on unsupported/conflict.
# CALL FLOW: ``_effective_methods`` calls it after source selection; ``_collect`` consumes binding.
# EXAMPLE: ``@GET`` with no Path is a leaf at the current URI; nonempty Path alone is a locator.
    def _decode_binding(
        self, method: MethodRecord, namespace: str
    ) -> dict[str, Any] | None:
        owner_name = f"{method.owner.type_info['display_name']}.{method.name}"
        for annotation in method.annotations + method.parameter_annotations:
            # A method bundle cannot cross the javax/jakarta family boundary,
            # including parameter annotations that affect the resource method.
            family = self._standard_jax_annotation_family(method, annotation)
            if family is not None and family != namespace:
                self.log(method, "mixed Javax/Jakarta effective annotation bundle")
                return None
        annotation_kinds = [self._annotation_kind(method, annotation) for annotation in method.annotations]
        designator_evidence = any(
            kind in set(self.host.JAX_RS_HTTP_METHODS) | {"custom"}
            for kind in annotation_kinds
        )
        path_evidence = "Path" in annotation_kinds
        designator = self.host.resolve_jax_method_designator(
            method.owner.unit,
            list(method.annotations),
            self.workspace,
            namespace,
            owner_name,
        )
        if designator_evidence and designator is None:
            return None
        method_path = self.host.resolve_jax_method_path(
            method.owner.unit,
            list(method.annotations),
            namespace,
            method.owner.type_info["display_name"],
            owner_name,
            self.workspace,
        )
        if method_path is None:
            return None
        if designator is not None:
            # A designator makes this a request-handling leaf.  Its optional
            # method path may be empty and still form a valid route.
            return {
                "kind": "leaf",
                "path": method_path,
                "method": designator["method"],
                "evidence_node": designator["node"],
            }
        if path_evidence and method_path:
            # A nonempty path without a request-method designator is a locator,
            # not an ANY/GET endpoint.
            path_node = next(
                (
                    annotation["node"]
                    for annotation, kind in zip(method.annotations, annotation_kinds)
                    if kind == "Path"
                ),
                method.node,
            )
            return {"kind": "locator", "path": method_path, "evidence_node": path_node}
        return None

# FLOW: JaxRecallAnalyzer._interface_type_path
# WHY: Recover the selected interface contract's direct type-level Path layer,
# matching Noir's composition while retaining exact provenance/namespace checks.
# IN/OUT: EffectiveMethod and namespace -> decoded path, empty identity layer, or
# ``None`` for ambiguous/mixed evidence.
# CALL FLOW: Recursive collection calls it before method-path composition; URI building consumes result.
# EXAMPLE: The module's Contract<T> example contributes ``/contracts`` here.
    def _interface_type_path(
        self, effective: EffectiveMethod, namespace: str
    ) -> str | None:
        """Return the selected interface contract's direct ``@Path`` layer.

        Noir composes an implemented interface's type path with the concrete
        root and method path.  Superclass type paths remain intentionally
        excluded.  Keep the stronger source identity and namespace checks of
        this analyzer while preserving that valid interface route layer.
        """

        source_owner = effective.annotation_source.owner
        # Only the selected interface annotation origin contributes its type
        # @Path.  Superclass type paths are excluded by JAX-RS locator/inheritance
        # semantics used by this analyzer.
        if (
            not effective.hierarchy_added
            or source_owner.kind != "interface_declaration"
        ):
            return ""
        unit = source_owner.unit
        modifiers = next(
            (
                child
                for child in source_owner.type_info["node"].named_children
                if child.type == "modifiers"
            ),
            None,
        )
        records = []
        if modifiers is not None:
            for annotation in modifiers.named_children:
                if annotation.type not in {"annotation", "marker_annotation"}:
                    continue
                name_node = self.host.child_by_field(annotation, "name")
                if name_node is not None:
                    records.append({"node": annotation, "name_node": name_node})
        candidates = []
        for record in records:
            resolved = self.host.resolve_known_annotation(
                unit,
                record["name_node"],
                {"Path"},
                self.host.JAX_RS_PACKAGES,
            )
            if resolved is not None:
                candidates.append((record, resolved))
        if not candidates:
            return ""
        if len(candidates) != 1 or candidates[0][1]["namespace"] != namespace:
            self.log(
                effective.annotation_source,
                "ambiguous or mixed interface type @Path",
            )
            return None
        owner_name = source_owner.type_info["display_name"]
        return self.host.decode_jax_path_annotation(
            unit,
            candidates[0][0],
            owner_name,
            owner_name,
            "interface type @Path value",
            self.workspace,
        )

# FLOW: JaxRecallAnalyzer._effective_methods
# WHY: Compute all request leaves/locators effectively available on one concrete
# resource by exact implementation and atomic annotation inheritance rules.
# IN/OUT: Resource TypeRecord, generic environment, namespace -> deterministic
# cached EffectiveMethod list; direct valid methods survive unrelated incomplete hierarchy.
# CALL FLOW: ``_collect`` calls it per resource state; binding/path/target processing consumes list.
# EXAMPLE: An unannotated public implementation may inherit one exact interface GET bundle.
    def _effective_methods(
        self, resource: TypeRecord, env: dict[str, TypeRef], namespace: str
    ) -> list[EffectiveMethod]:
        cache_key = (resource.fqn, self._env_key(env), namespace)
        if cache_key in self._effective_cache:
            return self._effective_cache[cache_key]

        hierarchy = self._hierarchy(resource, env)
        # Cache by exact resource + generic environment + API namespace because
        # all three dimensions can change effective signatures or annotations.
        effective: list[EffectiveMethod] = []
        handled_direct_ids: set[tuple[Any, ...]] = set()
        direct_signature_counts: dict[tuple[str, tuple[str, ...]], int] = {}
        for method in resource.methods:
            signature = self._signature(method, env)
            if signature is not None:
                direct_signature_counts[signature] = direct_signature_counts.get(signature, 0) + 1

        # Direct methods remain usable even when an unrelated hierarchy edge
        # cannot be resolved.  Only inherited binding requires a complete graph.
        for method in resource.methods:
            if not self._is_public_implementation(method):
                continue
            signature = self._signature(method, env)
            if signature is not None and direct_signature_counts[signature] != 1:
                self.log(method, "duplicate erased method signature")
                continue
            source = method
            # Direct atomic annotations always remain direct.  A genuinely
            # unannotated implementation may inherit only through a complete,
            # exact-signature graph.
            if not self._has_atomic_annotation_bundle(method):
                if not hierarchy.complete or signature is None:
                    continue
                source = self._annotation_source(method, env, signature, hierarchy, 0)
                if source is None:
                    continue
            binding = self._decode_binding(source, namespace)
            if binding is None:
                continue
            effective.append(
                EffectiveMethod(
                    implementation=method,
                    implementation_env=env,
                    annotation_source=source,
                    binding=binding,
                    hierarchy_added=source.id != method.id,
                    signature=signature,
                )
            )
            handled_direct_ids.add(method.id)

        if not hierarchy.complete:
            # Preserve valid direct results, but refuse every inherited guess.
            self._effective_cache[cache_key] = effective
            return effective

        signatures: set[tuple[str, tuple[str, ...]]] = set()
        unresolved_names = {method.name for method in resource.methods if self._signature(method, env) is None}
        # An unresolved overload of a name blocks inherited candidates with that
        # name: otherwise the analyzer could attach a route to the wrong overload.
        for record, state_env in hierarchy.class_states:
            signatures.update(
                signature
                for method in record.methods
                if (signature := self._signature(method, state_env)) is not None
            )

# FLOW: JaxRecallAnalyzer._effective_methods.collect_interface_signatures
# WHY: Gather exact signatures from the complete transitive interface graph so
# inherited defaults with no class declaration are considered as implementations.
# IN/OUT: Adapted interface state plus depth/active guards -> mutates enclosing
# ``signatures`` set and returns nothing.
# CALL FLOW: ``_effective_methods`` invokes it for each interface root; implementation selection consumes set.
# EXAMPLE: Active/depth guards stop cycles even though completeness was proved earlier.
        def collect_interface_signatures(
            state: tuple[TypeRecord, dict[str, TypeRef]],
            depth: int = 0,
            active: frozenset[str] = frozenset(),
        ) -> None:
            record, state_env = state
            if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
                return
            signatures.update(
                signature
                for method in record.methods
                if (signature := self._signature(method, state_env)) is not None
            )
            for edge in record.interfaces:
                following = self._edge_state(edge, state_env)
                if following is not None:
                    collect_interface_signatures(
                        following, depth + 1, active | {record.fqn}
                    )

        for interface_root in hierarchy.interface_roots:
            collect_interface_signatures(interface_root)

        for signature in sorted(signatures):
            if signature[0] in unresolved_names:
                continue
            implementation: MethodRecord | None = None
            implementation_env: dict[str, TypeRef] | None = None
            implementation_index: int | None = None
            malformed = False
            for index, (record, state_env) in enumerate(hierarchy.class_states):
                matches = self._methods_for_signature(record, state_env, signature)
                if not matches:
                    continue
                if len(matches) != 1 or not self._is_public_implementation(matches[0]):
                    malformed = True
                    break
                implementation = matches[0]
                implementation_env = state_env
                implementation_index = index
                break
            if malformed:
                continue
            if implementation is None:
                # No class implementation exists: one maximally specific source
                # default method may be both implementation and annotation source.
                candidates: set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]] = set()
                blocked = False
                memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
                for interface_root in hierarchy.interface_roots:
                    found, invalid = self._interface_branches(
                        interface_root, signature, "default", memo=memo
                    )
                    candidates.update(found)
                    blocked = blocked or invalid
                candidates, specificity_invalid = self._maximally_specific_candidates(
                    candidates
                )
                blocked = blocked or specificity_invalid
                if blocked or len({candidate[0] for candidate in candidates}) != 1:
                    continue
                resolved = self._method_from_candidate(next(iter(candidates)))
                if resolved is None:
                    continue
                implementation, implementation_env = resolved
            if implementation.id in handled_direct_ids:
                continue
            source = self._annotation_source(
                implementation,
                implementation_env,
                signature,
                hierarchy,
                implementation_index,
            )
            if source is None:
                continue
            binding = self._decode_binding(source, namespace)
            if binding is None:
                continue
            effective.append(
                EffectiveMethod(
                    implementation=implementation,
                    implementation_env=implementation_env,
                    annotation_source=source,
                    binding=binding,
                    hierarchy_added=True,
                    signature=signature,
                )
            )

        effective.sort(
            key=lambda item: (
                item.implementation.owner.fqn,
                item.implementation.name,
                item.signature or (item.implementation.name, ()),
                item.implementation.node.start_byte,
            )
        )
        self._effective_cache[cache_key] = effective
        return effective

    # ------------------------------------------------------------------
    # Recursive subresource collection

# FLOW: JaxRecallAnalyzer._target_from_return
# WHY: Prove a locator's adapted return denotes one concrete source class/record,
# not a dynamic interface, abstract, classpath-only, array, or erasure-only target.
# IN/OUT: Effective locator method -> target TypeRecord/environment pair or ``None``.
# CALL FLOW: ``_collect`` calls it for locator bindings; recursive traversal consumes target.
# EXAMPLE: Exact ``ItemResource`` and ``Class<ItemResource>`` pass; raw T does not.
# CLARIFICATION: Here raw T means an owner-generic erasure-only substitution;
# a method type variable whose parsed bound adapts to an exact declaration can pass.
    def _target_from_return(
        self, effective: EffectiveMethod
    ) -> tuple[TypeRecord, dict[str, TypeRef]] | None:
        method = effective.implementation
        env = self._method_env(method, effective.implementation_env)
        returned = self._adapt_ref(method.return_ref, env)
        # Supported locator targets are exact T or Class<T>.  Arrays, variables,
        # wrappers, interfaces, abstract types, classpath-only types, and
        # erasure-only bounds are deliberately not dynamically dispatched.
        if returned is None or returned.kind != "decl" or returned.dimensions:
            return None
        if returned.name == "java.lang.Class":
            if len(returned.args) != 1:
                return None
            returned = returned.args[0]
            if returned.kind != "decl" or returned.dimensions:
                return None
        target = self.types.get(returned.name)
        if (
            target is None
            or target.kind not in {"class_declaration", "record_declaration"}
            or target.type_info["abstract"]
        ):
            return None
        if returned.args:
            if len(returned.args) != len(target.type_parameters):
                return None
            target_env = dict(zip(target.type_parameters, returned.args))
        else:
            target_env = self._default_env(target)
        return target, target_env

# FLOW: JaxRecallAnalyzer._endpoint
# WHY: Project an effective leaf into the host's standard endpoint fact while
# attributing the real implementation and preserving its raw formal parameters.
# IN/OUT: EffectiveMethod and fully composed URI -> six-field-compatible fact dict.
# CALL FLOW: ``_collect`` calls this leaf for reportable leaves; host debug/final formatter consume fact.
    def _endpoint(
        self, effective: EffectiveMethod, uri: str
    ) -> dict[str, Any]:
        method = effective.implementation
        # Attribute the concrete/effective handler—not the contract that lent
        # annotations—and preserve that handler's raw formal parameter source.
        owner_name = f"{method.owner.type_info['display_name']}.{method.name}"
        return {
            "uri": uri,
            "method": effective.binding["method"],
            "uri_params": self.host.get_callable_parameters_as_is(
                method.owner.unit["source"], method.parameters_node
            ),
            "SrcFile": method.owner.unit["fname"],
            "SrcLine": method.node.start_point.row + 1,
            "SFunction": owner_name,
        }

# FLOW: JaxRecallAnalyzer._collect
# WHY: Traverse one root/subresource state, compose bounded route layers, emit
# additions-only leaves, and recursively follow exact locator edges.
# IN/OUT: Resource/environment/namespace/base plus branch guards and shared budget
# -> endpoint-fact list.  Active type/edge sets are copied per branch.
# CALL FLOW: ``analyze`` seeds it and locators recurse into it; final dedup consumes rows.
# EXAMPLE: ``/root`` + locator ``/users/{id}`` + leaf ``/profile`` yields the module example.
    def _collect(
        self,
        resource: TypeRecord,
        env: dict[str, TypeRef],
        namespace: str,
        base_uri: str,
        via_locator: bool,
        depth: int,
        active_types: frozenset[TypeState],
        active_edges: frozenset[tuple[Any, ...]],
        budget: dict[str, int],
    ) -> list[dict[str, Any]]:
        state = TypeState(resource.fqn, self._env_key(env))
        # Guards are branch-local.  Two sibling locators may legitimately reach
        # the same type under different paths; a global visited set would lose one.
        if state in active_types or depth > MAX_SUBRESOURCE_DEPTH:
            self.log(resource, "cyclic or over-depth subresource traversal")
            return []
        if budget["states"] >= MAX_SUBRESOURCE_STATES:
            self.log(resource, "over-state-limit subresource traversal")
            return []
        budget["states"] += 1
        branch_types = active_types | {state}
        endpoints: list[dict[str, Any]] = []
        for effective in self._effective_methods(resource, env, namespace):
            interface_path = self._interface_type_path(effective, namespace)
            if interface_path is None:
                continue
            composed = self.host.combine_paths(
                # Application/root/locator base + selected interface type path
                # + method path.  The returned target's class @Path is omitted.
                self.host.combine_paths(base_uri, interface_path),
                effective.binding["path"],
            )
            if len(composed) > MAX_COMPOSED_PATH:
                self.log(effective.implementation, "over-length subresource path")
                continue
            if effective.binding["kind"] == "leaf":
                if via_locator or effective.hierarchy_added:
                    # Direct root leaves belong to the host direct pass.  Emit
                    # here only if hierarchy or locator traversal added value.
                    endpoint = self._endpoint(effective, composed)
                    endpoints.append(endpoint)
                    self.host.debug_log(endpoint)
                continue

            target_state = self._target_from_return(effective)
            if target_state is None:
                self.log(effective.implementation, "unresolved subresource locator return type")
                continue
            target, target_env = target_state
            edge_key = (
                # Edge identity includes implementation, erased signature,
                # concrete target, and adapted target generic environment.
                effective.implementation.id,
                effective.signature,
                target.fqn,
                self._env_key(target_env),
            )
            if edge_key in active_edges:
                self.log(effective.implementation, "cyclic subresource locator edge")
                continue
            endpoints.extend(
                self._collect(
                    target,
                    target_env,
                    namespace,
                    composed,
                    True,
                    depth + 1,
                    branch_types,
                    active_edges | {edge_key},
                    budget,
                )
            )
        return endpoints

# FLOW: JaxRecallAnalyzer.analyze
# WHY: Seed recall only from genuine concrete direct Path roots, apply the shared
# deployment prefix, and return deterministic hierarchy/locator additions.
# IN/OUT: Analyzer's indexed workspace -> exact-deduplicated endpoint list.
# CALL FLOW: Public ``analyze_jax_recall`` invokes it; host aggregation/formatting consumes rows.
# EXAMPLE: Direct root leaves are omitted here unless hierarchy/locator traversal added value.
# CLARIFICATION: “Exact-deduplicated” means the stable internal identity tuple
# constructed below; ``SrcLine`` is intentionally not a separate identity field.
    def analyze(self) -> list[dict[str, Any]]:
        # Only concrete, workspace-visible class/record roots with a genuine
        # direct class @Path seed traversal.  Interfaces are annotation/handler
        # sources, never independent roots in this pass.
        endpoints: list[dict[str, Any]] = []
        for fqn in sorted(self.types):
            record = self.types[fqn]
            if (
                record.kind not in {"class_declaration", "record_declaration"}
                or record.type_info["abstract"]
                or not record.type_info["workspace_visible"]
            ):
                continue
            root = self.host.resolve_jax_root(record.unit, record.type_info, self.workspace)
            if root is None:
                continue
            application_path = self.host.select_jax_application_path(
                self.workspace,
                record.unit,
                root["namespace"],
                record.type_info["display_name"],
            )
            if application_path is None:
                # None means relevant deployment evidence was ambiguous; ""
                # means no selected base and is still a valid relative root.
                continue
            base_uri = self.host.combine_paths(application_path, root["path"])
            if len(base_uri) > MAX_COMPOSED_PATH:
                self.log(record, "over-length resource root path")
                continue
            endpoints.extend(
                self._collect(
                    record,
                    self._default_env(record),
                    root["namespace"],
                    base_uri,
                    False,
                    0,
                    frozenset(),
                    frozenset(),
                    {"states": 0},
                )
            )
        # The host's final six-column formatter/deduper remains authoritative;
        # remove exact internal duplicates here so standalone callers are also
        # deterministic.
        unique = {
            (
                endpoint["method"],
                endpoint["uri"],
                endpoint["SrcFile"],
                endpoint["SFunction"],
                endpoint["uri_params"],
            ): endpoint
            for endpoint in endpoints
        }
        return [unique[key] for key in sorted(unique)]


# FLOW: analyze_jax_recall
# WHY: Expose the hierarchy/subresource analyzer through the import-cycle-free
# function contract expected by the host coordinator.
# IN/OUT: Built workspace and host helper API -> additions-only endpoint list.
# CALL FLOW: Host ``analyze_module`` calls it after direct workspace setup; it constructs
# ``JaxRecallAnalyzer``, invokes ``analyze``, and returns rows for final aggregation.
def analyze_jax_recall(workspace: dict[str, Any], host: Any) -> list[dict[str, Any]]:
    """Return only hierarchy/subresource endpoint additions for ``workspace``.

    Call this once after ``host.build_jax_workspace`` and append its rows to
    the ordinary direct-JAX endpoint list before the host formatter/deduper.
    """

    return JaxRecallAnalyzer(workspace, host).analyze()
