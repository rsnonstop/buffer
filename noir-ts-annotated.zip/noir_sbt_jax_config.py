"""Project-scoped JAX-RS deployment-prefix discovery.

The Java host owns annotation/type provenance.  This module consumes only its
already validated ``ApplicationPath`` facts, associates them with source
projects, overlays bounded ``web.xml`` servlet mappings, and selects one base
path for a resource.  Both the direct and hierarchy/subresource analyzers call
the host selector, so one configured workspace is authoritative for all JAX-RS
HTTP rows.
"""

# ENDPOINT MODEL — this module supplies only the deployment prefix.  The host
# supplies @Path and HTTP-method facts and performs final composition.  For
# example, Java @ApplicationPath("/rest") + class @Path("/orders") + method
# @Path("/{id}") becomes /rest/orders/{id}.  An explicit web.xml mapping such
# as /api/* replaces /rest and makes the identity /api/orders/{id}.
#
# DATA FLOW — validated Java ApplicationPath facts -> source-project keys ->
# bounded web.xml servlet/application associations -> ambiguity-preserving base
# index -> one selector shared by direct, inherited, and subresource routes.
#
# FAIL CLOSED — conflicting application-specific Java/XML bases are kept as
# unresolved None, not chosen by scan order.  Conflicting project-global
# servlet fallbacks are ignored rather than overriding a usable Java base.
# Malformed/oversized/test XML, cross-project source candidates, filters,
# listeners, vendor runtime registries, Application.getClasses/getSingletons,
# classpath bytecode inspection, and full Servlet pattern semantics are outside
# this deliberately small model.  A dependency-supplied application FQN named
# explicitly in web.xml may still participate through the bounded package-name
# heuristic below; its class is not inspected.

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree


# These conventional source-layout markers define a *project ownership*
# boundary.  They do not restrict where web.xml may physically live; they keep
# configuration in one module from leaking into a sibling module.
PROJECT_MARKERS = (
    ("src", "main", "java"),
    ("src", "main", "resources"),
    ("src", "main", "webapp"),
)
# Only the portable Javax/Jakarta Application init-param names participate in
# exact application association.  Other vendor parameters are not guessed.
APPLICATION_INIT_PARAMS = {
    "javax.ws.rs.Application",
    "jakarta.ws.rs.Application",
}
CORE_APPLICATION_CLASSES = {
    "javax.ws.rs.core.Application",
    "jakarta.ws.rs.core.Application",
}
MAX_WEB_XML_BYTES = 10 * 1024 * 1024


# FLOW: _absolute_path
# WHY: Canonicalize a source/configuration spelling without touching the
# filesystem, so all later project keys compare one stable absolute identity.
# IN/OUT: A path plus analysis-root anchor -> normalized absolute string.
# CALL FLOW: ``infer_jax_project_root`` calls this leaf; marker ownership consumes it.
def _absolute_path(path: str | os.PathLike[str], analysis_root: str) -> str:
    # Normalized absolute spellings make relative and absolute references to
    # the same source share a configuration key; this performs no file I/O.
    value = os.fspath(path)
    if not os.path.isabs(value):
        value = os.path.join(analysis_root, value)
    return os.path.normpath(os.path.abspath(value))


# FLOW: infer_jax_project_root
# WHY: Assign a Java source or web.xml to one module and prevent a
# deployment prefix discovered in a sibling module from leaking across it.
# IN/OUT: Path and scan root -> nearest standard-layout project root, or
# the scan root for nonstandard layouts.  Discovery, keying, and selection call
# it; its result is the first element of every application/deployment key.
# CALL FLOW: XML discovery/key builders/selectors call it; scoped keys consume it.
def infer_jax_project_root(
    path: str | os.PathLike[str], analysis_root: str | os.PathLike[str]
) -> str:
    """Return the source project containing ``path``.

    A standard main-source marker owns the path.  Nonstandard layouts fall
    back to the explicit analysis root instead of borrowing configuration from
    a sibling source directory.
    """

    # Example: module/src/main/java/a/R.java and
    # module/src/main/webapp/WEB-INF/web.xml both belong to module.
    fallback = os.path.normpath(os.path.abspath(os.fspath(analysis_root)))
    absolute = Path(_absolute_path(path, fallback))
    parts = absolute.parts
    for index in range(max(0, len(parts) - 2)):
        if tuple(parts[index : index + 3]) in PROJECT_MARKERS:
            prefix = parts[:index]
            return os.path.normpath(os.fspath(Path(*prefix))) if prefix else os.path.sep
    return fallback


# FLOW: _is_test_path
# WHY: Classify integration/test descriptors as non-deployment evidence.
# IN/OUT: Candidate and scan root -> Boolean segment-aware test status.
# CALL FLOW: ``discover_web_xml_files`` calls this leaf before retaining paths.
# EXAMPLE: ``src/it/WEB-INF/web.xml`` is true,
# while a directory merely containing the letters ``test`` is not.
def _is_test_path(path: str, analysis_root: str) -> bool:
    # Deployment descriptors in src/test and src/it are fixtures, not runtime
    # application evidence.
    relative = os.path.relpath(path, start=analysis_root).replace("\\", "/")
    wrapped = f"/{relative.strip('/')}/"
    return "/src/test/" in wrapped or "/src/it/" in wrapped


# FLOW: discover_web_xml_files
# WHY: Bound deterministic deployment-descriptor discovery before any
# XML content can influence endpoint identity.
# IN/OUT: Analysis root and ignored directory names -> sorted safe file
# paths.  The configuration builder consumes them and separately parses each.
# CALL FLOW: The configuration builder calls this; XML parsing consumes each path.
# Boundary: symlinks, test trees, non-regular/oversized files, and races skip.
def discover_web_xml_files(
    analysis_root: str | os.PathLike[str], ignored_dirs: Iterable[str] = ()
) -> list[str]:
    """Find regular, non-test files whose basename is exactly ``web.xml``."""

    # Discovery is deterministic.  Symlinks, non-regular files, >10 MiB files,
    # test trees, ignored directories, and I/O races cannot become evidence.
    root = os.path.normpath(os.path.abspath(os.fspath(analysis_root)))
    ignored = set(ignored_dirs)
    discovered: list[str] = []
    for current_root, directory_names, file_names in os.walk(root):
        directory_names[:] = sorted(
            name for name in directory_names if name not in ignored
        )
        if _is_test_path(current_root, root):
            directory_names[:] = []
            continue
        if "web.xml" not in file_names:
            continue
        candidate = os.path.join(current_root, "web.xml")
        if _is_test_path(candidate, root) or os.path.islink(candidate):
            continue
        try:
            if not os.path.isfile(candidate) or os.path.getsize(candidate) > MAX_WEB_XML_BYTES:
                continue
        except OSError:
            continue
        discovered.append(os.path.normpath(candidate))
    return sorted(discovered)


# FLOW: _local_name
# WHY: Compare XML tags independently of a namespace URI or prefix.
# IN/OUT: Arbitrary ElementTree tag -> local-name string or ``""``.
# CALL FLOW: Child lookup and root selection call this leaf before structural joins.
# EXAMPLE: ``{urn:x}servlet`` becomes ``servlet``.
def _local_name(tag: object) -> str:
    # Accept namespace-qualified web.xml documents without binding a schema.
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1].rsplit(":", 1)[-1]


# FLOW: _children
# WHY: Select only direct XML children of the requested local name so
# nested unrelated declarations cannot be mistaken for web-app configuration.
# IN/OUT: Element plus local name -> ordered matching child list.
# CALL FLOW: Parsing and ``_child_text`` call it; web.xml joins consume the nodes.
def _children(node: ElementTree.Element, local_name: str):
    return [child for child in list(node) if _local_name(child.tag) == local_name]


# FLOW: _child_text
# WHY: Read one direct web.xml field with whitespace normalized while
# preserving the parser's first-child-only, fail-closed shape.
# IN/OUT: Element and local name -> stripped descendant text or ``""``.
# CALL FLOW: Servlet/init-param/mapping parsing calls it; name joins consume text.
def _child_text(node: ElementTree.Element, local_name: str) -> str:
    children = _children(node, local_name)
    if not children:
        return ""
    return "".join(children[0].itertext()).strip()


# FLOW: jaxrs_servlet_class
# WHY: Recognize a bounded set of common JAX-RS container class names
# solely for project-global servlet fallback classification.
# IN/OUT: Configured class-name string -> heuristic Boolean.
# CALL FLOW: XML parsing/package exclusion call this leaf; fallback grouping consumes it.
def jaxrs_servlet_class(class_name: str) -> bool:
    # This bounded Noir-compatible name heuristic only classifies an otherwise
    # valid mapping as a potential project-global fallback.  It never proves a
    # Java resource or crosses the inferred project boundary.
    if not class_name:
        return False
    return (
        "jersey" in class_name
        or "resteasy" in class_name
        or "RestEasy" in class_name
        or "JAXRSServlet" in class_name
        or "JAXRS" in class_name
        or "CxfNonSpringJaxrsServlet" in class_name
        or "CXFNonSpringJaxrsServlet" in class_name
        or class_name.endswith(".ServletContainer")
        or class_name.endswith(".HttpServletDispatcher")
    )


# FLOW: jaxrs_application_class_name
# WHY: Identify a syntactically plausible Application class named by
# web.xml when no inspectable source declaration may exist.
# IN/OUT: Class-name string -> bounded Boolean.
# CALL FLOW: XML parsing and package inference call it; servlet/key classification consumes it
# to mark a servlet JAX-RS-capable, and package inference reuses the same gate.
def jaxrs_application_class_name(class_name: str) -> bool:
    # Source-known names bind through the exact index later.  This syntactic
    # form exists for a dependency-supplied Application named in web.xml.
    return bool(
        class_name
        and (
            class_name in CORE_APPLICATION_CLASSES
            or ".Application" in class_name
            or class_name.endswith("Application")
        )
    )


# FLOW: package_from_application_class_name
# WHY: Derive only a qualified dependency application's package for
# namespace-neutral XML association, without inventing one for core/containers.
# IN/OUT: Class-name string -> package string or ``None``.
# CALL FLOW: ``_mapping_application_keys`` calls it; scoped fallback keys consume it.
def package_from_application_class_name(class_name: str) -> str | None:
    # Never manufacture a package for a core Application or container class.
    if (
        not jaxrs_application_class_name(class_name)
        or class_name in CORE_APPLICATION_CLASSES
        or jaxrs_servlet_class(class_name)
        or "." not in class_name
    ):
        return None
    package_name = class_name.rsplit(".", 1)[0]
    return package_name or None


# FLOW: normalize_servlet_pattern
# WHY: Convert the supported servlet URL-pattern slice into the route
# prefix composed with JAX-RS root/method paths.
# IN/OUT: Raw pattern -> slash-normalized bounded prefix string.
# CALL FLOW: Configuration construction calls it; base-path overlays consume it.
# EXAMPLE: ``/api/*`` -> ``/api`` and ``/``
# -> ``""``.  Extension-pattern semantics are deliberately not interpreted.
def normalize_servlet_pattern(pattern: str) -> str:
    """Match Noir's bounded servlet-pattern-to-prefix normalization."""

    # Examples: /api/* -> /api, api/* -> /api, / -> "".  Because wildcard
    # stripping happens first, /* -> /.  Extension mappings are preserved as a
    # bounded artifact; this is not a full Servlet URL-pattern interpreter.
    cleaned = pattern.strip()
    if cleaned.endswith("/*"):
        cleaned = cleaned[:-2]
    if len(cleaned) > 1 and cleaned.endswith("/"):
        cleaned = cleaned[:-1]
    if cleaned in {"/", "/*"}:
        return ""
    return cleaned if cleaned.startswith("/") else f"/{cleaned}"


# FLOW: parse_web_xml_jaxrs_mappings
# WHY: Join direct servlet declarations to direct servlet mappings by
# servlet-name and retain only facts relevant to a JAX-RS deployment prefix.
# IN/OUT: XML bytes/text -> mapping dictionaries containing original
# patterns, candidate Application names, and the container heuristic flag.
# CALL FLOW: Configuration construction calls it per discovered file; overlays consume facts.
# EXAMPLE: See the matched servlet/servlet-mapping XML immediately below.
def parse_web_xml_jaxrs_mappings(content: bytes | str) -> list[dict[str, Any]]:
    """Parse direct servlet declarations/mappings from one deployment file.

    The caller owns non-fatal error handling so standalone tests can assert
    malformed XML precisely.
    """

    # Matched XML shape (direct web-app children):
    #   <servlet><servlet-name>rest</servlet-name>
    #     <servlet-class>org.glassfish.jersey.servlet.ServletContainer</servlet-class>
    #     <init-param><param-name>jakarta.ws.rs.Application</param-name>
    #       <param-value>example.ApiApplication</param-value></init-param>
    #   </servlet>
    #   <servlet-mapping><servlet-name>rest</servlet-name>
    #     <url-pattern>/v1/*</url-pattern></servlet-mapping>
    # The name join produces the original pattern, candidate application names,
    # and a JAX-RS-container flag.  Unmatched names, unrelated params, nested
    # declarations, filters, and listeners contribute nothing.
    root = ElementTree.fromstring(content)
    if _local_name(root.tag) != "web-app":
        web_apps = [node for node in list(root) if _local_name(node.tag) == "web-app"]
        if web_apps:
            root = web_apps[0]

    servlets: dict[str, dict[str, Any]] = {}
    for servlet in _children(root, "servlet"):
        name = _child_text(servlet, "servlet-name")
        if not name:
            continue
        servlet_class = _child_text(servlet, "servlet-class")
        application_classes = [servlet_class] if servlet_class else []
        for parameter in _children(servlet, "init-param"):
            if _child_text(parameter, "param-name") not in APPLICATION_INIT_PARAMS:
                continue
            value = _child_text(parameter, "param-value")
            if value:
                application_classes.append(value)
        servlets[name] = {
            "application_classes": application_classes,
            "jaxrs_servlet": jaxrs_servlet_class(servlet_class)
            or any(jaxrs_application_class_name(value) for value in application_classes),
        }

    mappings: list[dict[str, Any]] = []
    for mapping in _children(root, "servlet-mapping"):
        name = _child_text(mapping, "servlet-name")
        servlet = servlets.get(name)
        if not name or servlet is None:
            continue
        for pattern_node in _children(mapping, "url-pattern"):
            pattern = "".join(pattern_node.itertext()).strip()
            if pattern:
                mappings.append(
                    {
                        "pattern": pattern,
                        "application_classes": list(servlet["application_classes"]),
                        "jaxrs_servlet": servlet["jaxrs_servlet"],
                    }
                )
    return mappings


# FLOW: _application_key
# WHY: Give a validated Java ApplicationPath fact a collision-resistant
# identity spanning project, package scope, and Javax/Jakarta namespace.
# IN/OUT: Host application fact plus scan root -> three-part tuple.
# CALL FLOW: Java-path coalescing/class indexing call it; configuration consumes keys.
def _application_key(application: dict[str, Any], analysis_root: str):
    # Namespace is part of identity: javax and jakarta evidence cannot combine.
    return (
        infer_jax_project_root(application["fname"], analysis_root),
        application["package"],
        application["namespace"],
    )


# FLOW: _has_project_marker
# WHY: Tell selection whether standard module ownership is provable,
# which disables the narrow single-root fallback for arbitrary layouts.
# IN/OUT: Filesystem spelling -> Boolean marker presence.
# CALL FLOW: ``select_jax_deployment_path`` calls this leaf before compatibility fallback.
def _has_project_marker(path: str | os.PathLike[str]) -> bool:
    # Standard layout disables the deliberately narrow nonstandard-root
    # fallback used later by select_jax_deployment_path.
    parts = Path(os.path.abspath(os.fspath(path))).parts
    return any(
        tuple(parts[index : index + 3]) in PROJECT_MARKERS
        for index in range(max(0, len(parts) - 2))
    )


# FLOW: _coalesced_java_paths
# WHY: Merge all validated Java ApplicationPath facts per exact key
# without letting file iteration choose among disagreement.
# IN/OUT: Application facts and scan root -> key-to-path/``None`` map.
# CALL FLOW: Configuration construction calls it; the shared selector consumes paths.
# EXAMPLE: two unequal paths for one key become ``None`` and block selection.
def _coalesced_java_paths(applications: list[dict[str, Any]], analysis_root: str):
    # A key is usable only if every fact resolved and all paths agree.  Store
    # None for conflict/unresolved input instead of choosing the first source.
    grouped: dict[tuple[str, str, str], list[str | None]] = {}
    for application in applications:
        grouped.setdefault(_application_key(application, analysis_root), []).append(
            application.get("path")
        )
    result: dict[tuple[str, str, str | None], str | None] = {}
    for key, paths in grouped.items():
        valid = {path for path in paths if path is not None}
        result[key] = (
            next(iter(valid))
            if len(valid) == 1 and all(path is not None for path in paths)
            else None
        )
    return result


# FLOW: _application_class_index
# WHY: Map both simple and fully qualified Application spellings back
# to every exact source key so web.xml association remains ambiguity-preserving.
# IN/OUT: Application facts -> sorted spelling-to-key-tuples index.
# CALL FLOW: Configuration construction calls it; mapping association consumes it.
def _application_class_index(
    applications: list[dict[str, Any]], analysis_root: str
) -> dict[str, tuple[tuple[str, str, str], ...]]:
    # Retain every project/package/namespace key under both simple and FQ names;
    # duplicate spellings remain explicit rather than first-wins aliases.
    index: dict[str, set[tuple[str, str, str]]] = {}
    for application in applications:
        key = _application_key(application, analysis_root)
        for name in (application.get("simple_name"), application.get("fqn")):
            if name:
                index.setdefault(name, set()).add(key)
    return {name: tuple(sorted(keys)) for name, keys in sorted(index.items())}


# FLOW: _mapping_application_keys
# WHY: Associate one servlet's configured Application names with local
# source identities or a bounded dependency-package identity.
# IN/OUT: Class names, source index, and project root -> set of scoped
# keys.  The configuration builder attaches each normalized XML path to them.
# CALL FLOW: Configuration construction calls it; explicit XML overlays consume keys.
# Boundary: an in-project source match wins; another project's match cannot.
def _mapping_application_keys(
    class_names: Iterable[str],
    class_index: dict[str, tuple[tuple[str, str, str], ...]],
    project_root: str,
) -> set[tuple[str, str, str | None]]:
    # Exact source identity wins only in this project.  Otherwise a qualified
    # dependency Application may contribute a package-scoped namespace-neutral
    # key.  A same-named source type in another module cannot steal the match.
    keys: set[tuple[str, str, str | None]] = set()
    for class_name in class_names:
        known = class_index.get(class_name)
        if known is not None:
            matching = {key for key in known if key[0] == project_root}
            if matching:
                keys.update(matching)
                continue
            # A same-named source application in another project must not
            # suppress this project's web.xml package-name association.  The
            # configured class can come from a dependency rather than source.
        package_name = package_from_application_class_name(class_name)
        if package_name:
            keys.add((project_root, package_name, None))
    return keys


# FLOW: build_jax_deployment_configuration
# WHY: Construct one immutable-style deployment snapshot shared by the
# direct and recall analyzers, so all JAX-RS HTTP rows choose prefixes identically.
# IN/OUT: Built host workspace, scan root, host helpers -> configuration
# dictionary also attached as ``workspace['jax_deployment']``.
# CALL FLOW: Host ``analyze_module`` calls it after indexing; direct/recall selectors consume it.
# EXAMPLE: The four-stage Java/XML overlay algorithm is enumerated below.
# Downstream
# ``select_jax_deployment_path`` overlays Java, explicit XML, then safe fallback.
def build_jax_deployment_configuration(
    workspace: dict[str, Any], analysis_root: str | os.PathLike[str], host: Any
) -> dict[str, Any]:
    """Build and attach the project/application/servlet-prefix index."""

    # Overlay algorithm:
    # 1. Coalesce genuine Java @ApplicationPath facts.
    # 2. Collect all XML mappings per exact/heuristic application key.
    # 3. Override Java only for one distinct XML path; conflict becomes None.
    # 4. Apply a unique project-global container mapping only when no explicit
    #    application mapping exists in that project.
    # The attached snapshot is shared by direct and recall passes.  Malformed
    # XML is isolated and cannot discard valid Java evidence in another file.
    root = os.path.normpath(os.path.abspath(os.fspath(analysis_root)))
    applications = list(workspace.get("applications", ()))
    base_paths = _coalesced_java_paths(applications, root)
    class_index = _application_class_index(applications, root)
    explicit_xml_keys: set[tuple[str, str, str | None]] = set()
    explicit_xml_paths: dict[tuple[str, str, str | None], set[str]] = {}
    global_candidates: dict[str, list[str]] = {}

    ignored_dirs = getattr(host, "IGNORED_DIRS", ())
    for xml_file in discover_web_xml_files(root, ignored_dirs):
        project_root = infer_jax_project_root(xml_file, root)
        try:
            with open(xml_file, "rb") as source_file:
                mappings = parse_web_xml_jaxrs_mappings(source_file.read())
        except (OSError, ElementTree.ParseError, ValueError) as error:
            host.write_log(f"Skipped JAX-RS malformed web.xml {xml_file}: {error}")
            continue

        for mapping in mappings:
            base_path = normalize_servlet_pattern(mapping["pattern"])
            keys = _mapping_application_keys(
                mapping["application_classes"], class_index, project_root
            )
            if not keys:
                if mapping["jaxrs_servlet"]:
                    global_candidates.setdefault(project_root, []).append(base_path)
                continue
            for key in keys:
                explicit_xml_paths.setdefault(key, set()).add(base_path)
                explicit_xml_keys.add(key)

    for key, paths in explicit_xml_paths.items():
        base_paths[key] = next(iter(paths)) if len(paths) == 1 else None

    for project_root, candidates in global_candidates.items():
        unique = set(candidates)
        if len(unique) != 1:
            continue
        if any(key[0] == project_root for key in explicit_xml_keys):
            continue
        fallback = next(iter(unique))
        for keys in class_index.values():
            for key in keys:
                if key[0] == project_root:
                    base_paths[key] = fallback

    configuration = {
        "analysis_root": root,
        "base_paths": base_paths,
        "application_class_index": class_index,
        "explicit_xml_keys": explicit_xml_keys,
    }
    workspace["jax_deployment"] = configuration
    return configuration


# FLOW: _package_is_ancestor
# WHY: Test Java package containment on dot-segment boundaries for
# longest-application-scope selection.
# IN/OUT: Candidate ancestor and resource package -> Boolean.
# CALL FLOW: Deployment selection calls this leaf while filtering candidates.
# EXAMPLE: ``a.b`` contains ``a.b.api``, not ``a.bad``.
def _package_is_ancestor(ancestor: str, package: str) -> bool:
    # Dot-segment boundary prevents package "a.b" from matching "a.bad".
    return not ancestor or package == ancestor or package.startswith(f"{ancestor}.")


# FLOW: _package_specificity
# WHY: Rank applicable Application packages so the nearest package
# scope wins rather than a broader ancestor.
# IN/OUT: Package spelling -> segment count, with root package -> zero.
# CALL FLOW: Deployment selection calls this leaf to find and retain its maximum tier.
def _package_specificity(package: str) -> int:
    return len(package.split(".")) if package else 0


# FLOW: select_jax_deployment_path
# WHY: Choose exactly one project/package/namespace-compatible base URI
# for a resource, preserving ambiguity as an endpoint-suppressing ``None``.
# IN/OUT: Attached configuration, source unit, JAX namespace, diagnostic
# owner, and host -> selected path, empty no-base path, or ambiguous ``None``.
# CALL FLOW: Host direct/recall selectors call it; URI composition consumes its output.
# EXAMPLE: The longest-package and explicit/namespace precedence example follows.
# Its output is
# composed before class/method paths.  Explicit XML outranks Java at one tier.
def select_jax_deployment_path(
    configuration: dict[str, Any],
    unit: dict[str, Any],
    namespace: str,
    owner_name: str,
    host: Any,
) -> str | None:
    """Select the longest package-scoped prefix inside the resource project."""

    # Example: applications in example and example.admin make a resource in
    # example.admin.users select the latter.  At equal specificity, explicit
    # XML candidates replace all non-explicit candidates.  Only when no
    # explicit candidate exists does an exact javax/jakarta namespace replace
    # neutral candidates.  Every survivor must resolve to the same path.
    #
    # Three-state return: "/api" is selected; "" means no applicable base;
    # None means applicable evidence is ambiguous and the endpoint must skip.
    project_root = infer_jax_project_root(
        unit["fname"], configuration["analysis_root"]
    )
    candidates = [
        (key, path)
        for key, path in configuration["base_paths"].items()
        if key[0] == project_root
        and key[2] in {None, namespace}
        and _package_is_ancestor(key[1], unit["package"])
    ]
    if not candidates:
        # Preserve the established single-application fallback for a
        # nonstandard source layout. Once multiple projects are identifiable,
        # never leak one module's deployment base into another.
        project_roots = {key[0] for key in configuration["base_paths"]}
        all_candidates = [
            (key, path)
            for key, path in configuration["base_paths"].items()
            if key[2] in {None, namespace}
        ]
        valid_paths = {
            path for _key, path in all_candidates if path is not None
        }
        if (
            not _has_project_marker(unit["fname"])
            and len(project_roots) == 1
            and project_roots == {project_root}
            and len(valid_paths) == 1
            and all(path is not None for _key, path in all_candidates)
        ):
            return next(iter(valid_paths))
        return ""
    specificity = max(_package_specificity(key[1]) for key, _path in candidates)
    candidates = [
        (key, path)
        for key, path in candidates
        if _package_specificity(key[1]) == specificity
    ]
    explicit = [
        item
        for item in candidates
        if item[0] in configuration["explicit_xml_keys"]
    ]
    if explicit:
        candidates = explicit
    else:
        exact_namespace = [item for item in candidates if item[0][2] == namespace]
        if exact_namespace:
            candidates = exact_namespace
    paths = {path for _key, path in candidates if path is not None}
    if len(paths) == 1 and all(path is not None for _key, path in candidates):
        return next(iter(paths))
    host.log_jax_issue(
        unit["fname"], owner_name, "ambiguous JAX-RS deployment prefix"
    )
    return None
