"""Project configuration and static-resource recall for :mod:`noir_sbt`.

The host analyzer passes its Java workspace and helper module into this file,
keeping the extension acyclic and reusing the host's exact Java name and
String-constant resolution.  The supported source/configuration shapes are
intentionally bounded:

* ``application.properties``, ``application.yml``, and ``application.yaml``
  at the three documented project locations;
* mapping-only YAML with String/integer leaves;
* nested Spring ``${key:default}`` path placeholders; and
* direct ``WebMvcConfigurer.addResourceHandlers`` registrations on a genuine
  ``ResourceHandlerRegistry`` parameter.

Unsupported configuration and Java control/data-flow shapes fail closed.  No
dependency metadata, runtime bean graph, profile activation, or physical
resource enumeration is attempted.
"""

# Reader's guide
# --------------
# This module has two independent jobs which deliberately share one project
# model:
#
# 1. infer project ownership and apply Spring configuration to paths already
#    discovered by the other analyzers; and
# 2. discover direct MVC static-resource handler registrations.
#
# Project ownership is inferred from a conventional source path.  Given
# ``shop/src/main/java/com/acme/Orders.java``, the owning root is ``shop``.
# Repeated ``src`` markers are ambiguous and produce no owner instead of
# borrowing configuration from an arbitrary ancestor.  Each project reads, in
# deterministic overwrite order:
#
#     src/main/resources/application.properties
#     src/main/resources/application.yml
#     src/main/resources/application.yaml
#     resources/... then project-root ...
#
# The YAML reader intentionally understands only nested mappings with simple
# scalar leaves.  Thus this is supported:
#
#     server:
#       servlet:
#         context-path: /edge
#     remote:
#       base: https://inventory.example
#
# Profiles, documents, lists, anchors, environment variables, and general
# Spring binding are not interpreted.  Structurally unsupported or
# structurally malformed YAML excludes the file as a unit.  Recognized mapping
# structure can retain supported String/integer leaves while ignoring
# unsupported or malformed scalar leaves such as booleans, nulls, floats, or
# an invalid quoted escape.
#
# Path application is surface-aware.  For ``/items`` with context path
# ``/edge`` an inbound MVC/Gateway/static/handshake fact becomes
# ``/edge/items``.  An outbound client receives placeholder substitution but
# never the server base.  A STOMP message destination such as ``/app/orders``
# likewise is not a servlet URL and receives no HTTP base.  The private
# ``_spring_configuration_applied`` marker makes this post-processing
# idempotent when several recall passes feed the same host pipeline.
#
# Static resources are endpoint patterns, not files.  For example:
#
#     class WebConfig implements WebMvcConfigurer {
#       public void addResourceHandlers(ResourceHandlerRegistry registry) {
#         registry.addResourceHandler("/assets/**")
#                 .addResourceLocations("classpath:/static/");
#       }
#     }
#
# proves inbound ``GET /assets/**``.  The resource location does not affect
# route identity.  Only the canonical genuine configurer signature, exact
# registry formal, top-level call, and resolvable patterns are accepted;
# receiver aliases, mutation, nested/control-flow calls, or unknown paths fail
# closed.

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
from typing import Any, Callable, Iterable, Mapping


WEB_MVC_CONFIG_PACKAGE = "org.springframework.web.servlet.config.annotation"
CONFIGURATION_FILENAMES = (
    "application.properties",
    "application.yml",
    "application.yaml",
)
MAX_PLACEHOLDER_SUBSTITUTIONS = 100
MAX_CONFIGURED_PATH_LENGTH = 8192
ELIGIBLE_HTTP_SURFACES = frozenset(
    {"server", "proxy", "gateway", "resource", "static-handler"}
)
ELIGIBLE_WS_SURFACES = frozenset({"websocket-handshake", "message"})

_PLACEHOLDER = re.compile(r"\$\{([^{}]+)\}")
_INTEGER = re.compile(r"[+-]?[0-9]+")
_FLOATISH = re.compile(
    r"[+-]?(?:[0-9]+\.[0-9]*|[0-9]*\.[0-9]+)(?:[eE][+-]?[0-9]+)?"
)
_PLAIN_YAML_KEY = re.compile(r"[A-Za-z0-9_.-]+")
_UNSUPPORTED_YAML_SCALARS = frozenset(
    {"null", "~", "true", "false", ".nan", ".inf", "+.inf", "-.inf"}
)


@dataclass(frozen=True)
# FLOW: SpringProjectConfiguration
# WHY: Keep one project's resolved values, base, and file evidence immutable and coherent.
# IN/OUT: Root, values, base path, and loaded files enter construction; immutable model out.
# CALL FLOW: `_read_project_configuration` creates it; all path applicators consume its fields.
# Purpose: immutable resolved configuration for one inferred project. Root,
# values, selected server base, and loaded-file evidence enter at construction;
# path applicators and diagnostics consume the stored fields downstream.
class SpringProjectConfiguration:
    """Resolved bounded configuration for one inferred source project."""

    root: str
    values: Mapping[str, str]
    base_path: str
    loaded_files: tuple[str, ...]


@dataclass(frozen=True)
# FLOW: SpringConfiguration
# WHY: Centralize invocation-wide source ownership so configuration cannot leak across modules.
# IN/OUT: Analysis root, project map, and source-owner map enter construction; immutable index out.
# CALL FLOW: `build_spring_configuration` creates it; every Spring path/WebSocket pass consumes it.
# Purpose: immutable invocation-wide ownership map. The builder supplies scan
# root, per-project models, and source-to-project links; all Spring path and
# WebSocket/message passes consume it to prevent cross-module leakage.
class SpringConfiguration:
    """Project/configuration ownership for one analyzer invocation."""

    analysis_root: str
    projects: Mapping[str, SpringProjectConfiguration]
    source_projects: Mapping[str, str | None]


# FLOW: _canonical_path
# WHY: Give configuration producers and endpoint consumers one stable source ownership key.
# IN/OUT: String or Path in; resolved absolute String out.
# CALL FLOW: Builder and application joins both call this leaf helper.
# Purpose: produce a stable absolute ownership key. A String/Path enters and a
# canonical String leaves; configuration building and endpoint application use
# the same spelling so source facts join their owning project deterministically.
def _canonical_path(path: str | Path) -> str:
    return str(Path(path).expanduser().resolve(strict=False))


# FLOW: _log
# WHY: Make rejected config/resource evidence visible without affecting endpoint output.
# IN/OUT: Optional host and message in; no value out.
# CALL FLOW: Project readers and resource recall call it; host diagnostics consume messages.
# Purpose: publish bounded configuration/resource rejections when a host logger
# exists. Host plus message enter, nothing leaves; readers and resource recall
# call it, while the shared diagnostic stream is the downstream consumer.
def _log(host: Any, message: str) -> None:
    if host is not None and callable(getattr(host, "write_log", None)):
        host.write_log(f"Skipped Spring configuration/resource {message}")


# FLOW: _infer_project_root
# WHY: Bind a source to one project conservatively instead of borrowing sibling configuration.
# IN/OUT: Source file and scan root in; project root or None out.
# CALL FLOW: `build_spring_configuration` calls it per unit; project readers consume roots.
# Purpose: bind one source file to one unambiguous project root. Source path and
# scan root enter; a root or None leaves for `build_spring_configuration`.
# Example: `shop/src/main/java/A.java` maps to `shop`; repeated cuts reject.
def _infer_project_root(source_file: str, analysis_root: Path) -> Path | None:
    """Infer one project root, rejecting repeated/ambiguous source markers."""

    # The cut is structural, not a substring heuristic.  Exactly one
    # ``src/main/java`` wins; otherwise exactly one ``src`` may serve as the
    # fallback.  This keeps sibling modules isolated under a broad scan root.
    source_path = Path(source_file).expanduser().resolve(strict=False)
    try:
        source_path.relative_to(analysis_root)
    except ValueError:
        return None

    parts = source_path.parts
    main_java_cuts = [
        index
        for index in range(max(0, len(parts) - 2))
        if parts[index : index + 3] == ("src", "main", "java")
    ]
    if main_java_cuts:
        if len(main_java_cuts) != 1:
            return None
        cut = main_java_cuts[0]
    else:
        src_cuts = [index for index, part in enumerate(parts[:-1]) if part == "src"]
        if len(src_cuts) > 1:
            return None
        if not src_cuts:
            return analysis_root
        cut = src_cuts[0]

    return Path(*parts[:cut]).resolve(strict=False)


# FLOW: _parse_properties
# WHY: Decode only the documented bounded properties subset with deterministic last-key wins.
# IN/OUT: Properties text in; String key/value mapping out.
# CALL FLOW: `_read_project_configuration` calls it; precedence merge consumes the mapping.
# Purpose: parse the deliberately small Spring properties subset. File text
# enters and a last-value-per-key mapping leaves for project precedence merge;
# continuation/escape semantics are intentionally not synthesized.
def _parse_properties(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", "!")):
            continue
        separators = [
            index for index in (stripped.find("="), stripped.find(":")) if index >= 0
        ]
        if not separators:
            continue
        separator = min(separators)
        key = stripped[:separator].strip()
        if key:
            values[key] = stripped[separator + 1 :].strip()
    return values


# FLOW: _strip_yaml_comment
# WHY: Separate YAML comments from quoted `#` data and detect unterminated quoting.
# IN/OUT: One physical line in; stripped line or None out.
# CALL FLOW: `_parse_mapping_yaml` calls this leaf before structural parsing.
# Purpose: remove a YAML comment without treating `#` inside quotes as syntax.
# One physical line enters; stripped text or None for unterminated quoting leaves
# for `_parse_mapping_yaml`, which treats structural failure atomically.
def _strip_yaml_comment(line: str) -> str | None:
    quote: str | None = None
    escaped = False
    for index, character in enumerate(line):
        if quote == '"':
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if quote == "'":
            if character == quote:
                if index + 1 < len(line) and line[index + 1] == quote:
                    continue
                quote = None
            continue
        if character in {'"', "'"}:
            quote = character
        elif character == "#" and (index == 0 or line[index - 1].isspace()):
            return line[:index].rstrip()
    return None if quote is not None else line.rstrip()


# FLOW: _split_yaml_mapping
# WHY: Split a mapping only at a colon outside quotes, preserving quoted URLs/data.
# IN/OUT: Stripped YAML line in; raw key/value pair or None out.
# CALL FLOW: `_parse_mapping_yaml` calls this leaf for each content line.
# Purpose: locate the first mapping colon outside quoted scalars. One stripped
# line enters; raw key/value pair or None leaves for the bounded YAML parser.
# This avoids splitting a quoted URL such as `"https://host"` at its colon.
def _split_yaml_mapping(line: str) -> tuple[str, str] | None:
    quote: str | None = None
    escaped = False
    for index, character in enumerate(line):
        if quote == '"':
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if quote == "'":
            if character == quote:
                if index + 1 < len(line) and line[index + 1] == quote:
                    continue
                quote = None
            continue
        if character in {'"', "'"}:
            quote = character
        elif character == ":":
            return line[:index].strip(), line[index + 1 :].strip()
    return None


# FLOW: _yaml_string
# WHY: Decode supported YAML String spellings while classifying unsupported scalar/key shapes.
# IN/OUT: Token and key-mode in; decoded String or None out.
# CALL FLOW: `_parse_mapping_yaml` uses it for keys/leaves and decides reject-versus-ignore context.
# Purpose: validate/decode one supported YAML key or scalar spelling. Token plus
# key-mode enter; a String or None leaves for `_parse_mapping_yaml`. None may be
# a leaf to ignore or a structural key failure, as decided by that caller.
def _yaml_string(token: str, *, key: bool = False) -> str | None:
    if token.startswith('"'):
        if not token.endswith('"') or len(token) < 2:
            return None
        try:
            value = json.loads(token)
        except (json.JSONDecodeError, TypeError):
            return None
        return value if isinstance(value, str) else None
    if token.startswith("'"):
        if not token.endswith("'") or len(token) < 2:
            return None
        return token[1:-1].replace("''", "'")
    if key:
        return token if _PLAIN_YAML_KEY.fullmatch(token) else None
    lowered = token.lower()
    if (
        not token
        or lowered in _UNSUPPORTED_YAML_SCALARS
        or _FLOATISH.fullmatch(token)
        or token.startswith(("[", "{", "&", "*", "!", "|", ">"))
    ):
        return None
    return token


# FLOW: _parse_mapping_yaml
# WHY: Flatten only safe nested mappings and avoid pretending to implement general YAML/Spring binding.
# IN/OUT: YAML text in; dotted String map or None for structural rejection out.
# CALL FLOW: Project reader calls it; precedence/base/placeholder consumers use retained values.
# Purpose: flatten bounded nested YAML mappings into dotted Spring keys. Text
# enters; a key/value mapping or None for structural rejection leaves for the
# project reader. Example: `server: {servlet...}` indentation becomes
# `server.servlet.context-path`; unsupported scalar leaves are skipped.
def _parse_mapping_yaml(text: str) -> dict[str, str] | None:
    """Parse only the mapping/scalar subset used by Spring path settings."""

    values: dict[str, str] = {}
    stack: list[tuple[int, str]] = []
    scalar_paths: set[str] = set()
    saw_content = False

    for raw_line in text.splitlines():
        if "\t" in raw_line[: len(raw_line) - len(raw_line.lstrip())]:
            return None
        without_comment = _strip_yaml_comment(raw_line)
        if without_comment is None:
            return None
        if not without_comment.strip():
            continue
        stripped = without_comment.strip()
        if stripped in {"---", "..."} or stripped.startswith("-"):
            return None
        saw_content = True
        indent = len(without_comment) - len(without_comment.lstrip(" "))
        pair = _split_yaml_mapping(stripped)
        if pair is None:
            return None
        raw_key, raw_value = pair
        key = _yaml_string(raw_key, key=True)
        if key is None:
            return None

        while stack and indent <= stack[-1][0]:
            stack.pop()
        if stack and indent <= stack[-1][0]:
            return None
        prefix = ".".join(part for _level, part in stack)
        path = f"{prefix}.{key}" if prefix else key
        if any(path == scalar or path.startswith(f"{scalar}.") for scalar in scalar_paths):
            return None

        if not raw_value:
            stack.append((indent, key))
            continue
        if "&" in raw_value or raw_value.startswith("*"):
            return None
        value = _yaml_string(raw_value)
        if value is None:
            if _INTEGER.fullmatch(raw_value):
                value = raw_value
            else:
                # Unsupported YAML scalar kinds are ignored rather than
                # coerced into path strings.
                continue
        values[path] = value
        scalar_paths.add(path)

    if not saw_content:
        return {}
    if any(
        key == "spring.config.activate.on-profile"
        or key == "spring.profiles"
        or key.startswith("spring.profiles.")
        for key in values
    ):
        return None
    return values


# FLOW: _normalize_optional_path
# WHY: Normalize configured path layers while preserving complete HTTP(S) authorities.
# IN/OUT: Optional path in; normalized String out.
# CALL FLOW: Project base selection and server/client applicators call this leaf.
# Purpose: normalize an optional configured path while preserving full HTTP(S)
# targets. A path/None enters and normalized String leaves for bases, clients,
# and placeholders. Empty or `/` becomes the neutral empty layer.
def _normalize_optional_path(path: str | None) -> str:
    if path is None:
        return ""
    trimmed = path.strip()
    if not trimmed or trimmed == "/":
        return ""
    if trimmed.lower().startswith(("http://", "https://")):
        return trimmed
    return trimmed if trimmed.startswith("/") else f"/{trimmed}"


# FLOW: _read_project_configuration
# WHY: Apply fixed directory/filename precedence and isolate malformed files per project.
# IN/OUT: Project root and host in; SpringProjectConfiguration out.
# CALL FLOW: `build_spring_configuration` calls it per owner root; path consumers use the model.
# Purpose: read fixed configuration locations in documented overwrite order.
# Project root/host enter; one immutable project model leaves for the invocation
# builder. Malformed structural YAML is logged/skipped, never partially merged.
def _read_project_configuration(root: Path, host: Any) -> SpringProjectConfiguration:
    # ``dict.update`` implements the documented precedence: later directories
    # and later filename variants replace earlier keys.  The selected WebFlux
    # base then wins over the servlet context path, matching the bounded
    # surface model used by the analyzer.
    values: dict[str, str] = {}
    loaded_files: list[str] = []
    resource_dirs = (root / "src/main/resources", root / "resources", root)
    for directory in dict.fromkeys(resource_dirs):
        for filename in CONFIGURATION_FILENAMES:
            path = directory / filename
            if not path.is_file():
                continue
            try:
                text = path.read_text(encoding="utf8")
            except (OSError, UnicodeError):
                _log(host, f"unreadable file {path}")
                continue
            if filename.endswith(".properties"):
                parsed = _parse_properties(text)
            else:
                parsed = _parse_mapping_yaml(text)
                if parsed is None:
                    _log(host, f"unsupported or malformed YAML file {path}")
                    continue
            values.update(parsed)
            loaded_files.append(str(path))

    servlet = _normalize_optional_path(values.get("server.servlet.context-path"))
    webflux = _normalize_optional_path(values.get("spring.webflux.base-path"))
    return SpringProjectConfiguration(
        root=str(root),
        values=dict(values),
        base_path=webflux or servlet,
        loaded_files=tuple(loaded_files),
    )


# FLOW: build_spring_configuration
# WHY: Create the single shared project/configuration model for one host analysis invocation.
# IN/OUT: Workspace and analysis root in; SpringConfiguration out.
# CALL FLOW: Host orchestration calls it; sibling analyzers and final postprocessing consume it.
# Purpose: public configuration-index builder called once by the host pipeline.
# Java workspace and analysis root enter; a project/source ownership model leaves
# for every Spring analyzer and the final configuration application pass.
def build_spring_configuration(
    workspace: Mapping[str, Any], analysis_root: str | Path, host: Any = None
) -> SpringConfiguration:
    """Load bounded, project-owned Spring path configuration for a workspace."""

    root = Path(analysis_root).expanduser().resolve(strict=False)
    source_projects: dict[str, str | None] = {}
    project_roots: set[str] = set()
    for fname in sorted(workspace.get("units", {})):
        project_root = _infer_project_root(fname, root)
        canonical_file = _canonical_path(fname)
        if project_root is None:
            source_projects[canonical_file] = None
            _log(host, f"ambiguous project ownership for {fname}")
            continue
        canonical_root = str(project_root)
        source_projects[canonical_file] = canonical_root
        project_roots.add(canonical_root)

    projects = {
        project_root: _read_project_configuration(Path(project_root), host)
        for project_root in sorted(project_roots)
    }
    return SpringConfiguration(str(root), projects, source_projects)


# FLOW: _resolve_placeholders
# WHY: Resolve nested Spring placeholders within explicit iteration/size bounds.
# IN/OUT: Path and project value map in; resolved String or None out.
# CALL FLOW: Server/client path applicators call it before normalization and joining.
# Purpose: boundedly resolve innermost Spring `${key:default}` expressions.
# Path and project values enter; resolved String or None leaves for path joining.
# Example: `${api:${fallback:/v1}}` resolves the inner default before the outer.
def _resolve_placeholders(path: str, values: Mapping[str, str]) -> str | None:
    # Resolve the innermost available ``${key:default}`` on every iteration.
    # Nested defaults naturally become eligible on a later iteration, e.g.
    # ``${api.base:${fallback:/api}}``.  A substitution count and output-size
    # bound prevent recursive configuration from becoming unbounded data flow.
    result = path
    for _iteration in range(MAX_PLACEHOLDER_SUBSTITUTIONS):
        match = _PLACEHOLDER.search(result)
        if match is None:
            return result if "${" not in result else None
        expression = match.group(1)
        key, separator, default = expression.partition(":")
        if not key:
            return None
        value = values.get(key, default if separator else "")
        result = result[: match.start()] + value + result[match.end() :]
        if len(result) > MAX_CONFIGURED_PATH_LENGTH:
            return None
    return result if _PLACEHOLDER.search(result) is None and "${" not in result else None


# FLOW: _collapse_path_slashes
# WHY: Canonicalize path separators without corrupting `://` authority delimiters.
# IN/OUT: Joined path String in; collapsed String out.
# CALL FLOW: Server/client applicators call this final leaf normalization step.
# Purpose: canonicalize repeated separators without damaging a URL authority.
# One joined path enters and one String leaves for facts; `https://h//x` keeps
# the scheme delimiter while collapsing duplicate path separators.
def _collapse_path_slashes(path: str) -> str:
    """Collapse repeated path separators without damaging a URL authority."""

    return re.sub(r"(?<!:)/{2,}", "/", path)


# FLOW: _join_paths
# WHY: Reuse host path semantics while keeping neutral-layer behavior explicit for isolated use.
# IN/OUT: Host, base, and child path in; joined String out.
# CALL FLOW: Server/client path application calls it before slash collapse.
# Purpose: centralize neutral-layer path composition, preferring host semantics.
# Host, base, and child enter; one joined String leaves for server/client path
# applicators. The local fallback keeps this module usable in isolated tests.
def _join_paths(host: Any, base: str, path: str) -> str:
    if host is not None and callable(getattr(host, "combine_paths", None)):
        return host.combine_paths(base, path)
    if not base and not path:
        return "/"
    if not base:
        return path
    if not path:
        return base
    return f"{base.rstrip('/')}/{path.lstrip('/')}"


# FLOW: apply_spring_path
# WHY: Apply placeholders and deployment bases only to endpoint namespaces where they are identity.
# IN/OUT: Raw path, source, configuration, and surface metadata in; final path or None out.
# CALL FLOW: Gateway callback and endpoint postprocessor call it; configured facts consume result.
# Purpose: apply the owning project's placeholders and eligible deployment base
# to one endpoint identity. Path/source/config/metadata enter; final String or
# None leaves for sibling analyzers and fact postprocessing. Surface gates keep
# servlet bases off outbound clients and broker message destinations.
def apply_spring_path(
    path: str,
    source_file: str,
    configuration: SpringConfiguration,
    host: Any = None,
    *,
    technology: str = "spring",
    protocol: str = "http",
    surface: str = "server",
    direction: str = "inbound",
) -> str | None:
    """Apply one source project's prefix/placeholders to one eligible path.

    The helper is intentionally public so the Gateway analyzer can use the
    same project/configuration layer when it constructs raw proxy facts.
    """

    # Eligibility is explicit because the same six-column output carries very
    # different namespaces.  In particular, applying a servlet base to an
    # outbound client or broker message would manufacture a different API.
    eligible_http = (
        protocol == "http"
        and direction == "inbound"
        and surface in ELIGIBLE_HTTP_SURFACES
    )
    eligible_client = (
        protocol == "http" and direction == "outbound" and surface == "client"
    )
    eligible_ws = (
        protocol == "ws"
        and direction == "inbound"
        and surface in ELIGIBLE_WS_SURFACES
    )
    if technology != "spring" or not (
        eligible_http or eligible_client or eligible_ws
    ):
        return path
    project_root = configuration.source_projects.get(_canonical_path(source_file))
    project = configuration.projects.get(project_root) if project_root else None
    values: Mapping[str, str] = project.values if project is not None else {}
    # Spring's deployment base applies to HTTP surfaces and the HTTP upgrade
    # path used by a STOMP/WebSocket handshake. Message destinations are not
    # servlet paths, but still consume the owning project's placeholders.
    base_path = (
        project.base_path
        if project is not None
        and (eligible_http or surface == "websocket-handshake")
        else ""
    )
    # Resolve before path normalization.  A client URL may be rooted in a
    # placeholder (for example ``${remote.base}/items``); adding ``/`` first
    # would corrupt an absolute value into ``/https://...``.
    resolved_path = _resolve_placeholders(path, values)
    resolved_base = _resolve_placeholders(base_path, values)
    if resolved_path is None or resolved_base is None:
        return None
    normalized = _normalize_optional_path(resolved_path)
    normalized_base = _normalize_optional_path(resolved_base)
    joined = _join_paths(host, normalized_base, normalized)
    return _collapse_path_slashes(joined)


# FLOW: _apply_spring_client_paths
# WHY: Resolve each retained client layer before deciding whether an inner URL replaces outer prefixes.
# IN/OUT: Layer iterable, source, configuration, host in; final client target or None out.
# CALL FLOW: `apply_spring_configuration` calls it for HTTP Interface facts with saved layers.
# Purpose: resolve retained HTTP Interface layers before absolute precedence.
# Layer sequence/source/config enter; final client target or None leaves for the
# configuration pass. An inner `https://...` replaces all relative outer layers.
def _apply_spring_client_paths(
    path_layers: Iterable[str],
    source_file: str,
    configuration: SpringConfiguration,
    host: Any = None,
) -> str | None:
    """Resolve HTTP-interface layers before deciding absolute precedence."""

    # Example: ["/v1", "${remote.base}/items"] with
    # remote.base=https://host resolves layer-by-layer.  The second layer is
    # complete, so the result is https://host/items rather than the malformed
    # /v1/https://host/items.
    project_root = configuration.source_projects.get(_canonical_path(source_file))
    project = configuration.projects.get(project_root) if project_root else None
    values: Mapping[str, str] = project.values if project is not None else {}
    combined = ""
    for path_layer in path_layers:
        resolved = _resolve_placeholders(path_layer, values)
        if resolved is None:
            return None
        normalized = _normalize_optional_path(resolved)
        # Any inner absolute URL is complete and replaces all lexical outer
        # prefixes, including when its scheme came from configuration.
        combined = (
            normalized
            if normalized.lower().startswith(("http://", "https://"))
            else _join_paths(host, combined, normalized)
        )
    return _collapse_path_slashes(combined)


# FLOW: spring_path_applicator
# WHY: Present one shared configuration policy in the callback shape expected by sibling analyzers.
# IN/OUT: Configuration and host in; path-applying closure out.
# CALL FLOW: Host builds it for Gateway; nested `apply` delegates each candidate to `apply_spring_path`.
# Purpose: adapt `apply_spring_path` into the callback shape expected by sibling
# analyzers. Configuration/host enter; a closure leaves for Gateway and similar
# passes, keeping one ownership and placeholder policy across extractors.
def spring_path_applicator(
    configuration: SpringConfiguration, host: Any = None
) -> Callable[..., str | None]:
    """Return a configuration-bound path callback for sibling analyzers.

    Callers may provide ``source_file`` directly or pass the shared Java
    ``unit`` mapping used by the Gateway analyzer.  Diagnostic-only context
    such as ``owner_name`` is accepted and ignored.
    """

    # FLOW: spring_path_applicator.apply
    # WHY: Translate sibling analyzer context into exact source and surface metadata.
    # IN/OUT: Raw path plus source/unit/context in; configured path or None out.
    # CALL FLOW: Gateway invokes this closure; it calls `apply_spring_path` and returns the result.
    # Purpose: resolve callback context into a source file and eligible metadata.
    # Raw path plus explicit source or unit enter; configured path/None leaves to
    # the calling analyzer. Diagnostic-only owner context is intentionally eaten.
    def apply(
        path: str,
        source_file: str | None = None,
        **context: Any,
    ) -> str | None:
        unit = context.pop("unit", None)
        context.pop("owner_name", None)
        if source_file is None and isinstance(unit, Mapping):
            source_file = unit.get("fname")
        if not isinstance(source_file, str) or not source_file:
            return None
        metadata = {
            key: context[key]
            for key in ("technology", "protocol", "surface", "direction")
            if key in context
        }
        return apply_spring_path(
            path, source_file, configuration, host, **metadata
        )

    return apply


# FLOW: apply_spring_configuration
# WHY: Apply shared configuration once to copied facts without mutating analyzer-owned dictionaries.
# IN/OUT: Endpoint iterable and configuration in; configured copied endpoint list out.
# CALL FLOW: Host postprocessing calls it after recall passes; global normalization/output consume result.
# Purpose: postprocess raw Spring facts exactly once without mutating producers.
# Endpoint iterable and configuration enter; copied configured facts leave for
# global normalization/output. Unresolvable placeholders drop only that fact.
def apply_spring_configuration(
    endpoints: Iterable[Mapping[str, Any]],
    configuration: SpringConfiguration,
    host: Any = None,
) -> list[dict[str, Any]]:
    """Return copied Spring facts with project configuration applied once."""

    # Copy facts rather than mutating analyzer-owned dictionaries.  Route
    # publisher ownership is carried as ProjectSrcFile for indirect routes; it
    # decides configuration even when the concrete handler lives elsewhere.
    configured: list[dict[str, Any]] = []
    for original in endpoints:
        endpoint = dict(original)
        if endpoint.get("_spring_configuration_applied"):
            configured.append(endpoint)
            continue
        technology = endpoint.get("technology", "spring")
        protocol = endpoint.get("protocol", "http")
        surface = endpoint.get("surface", "server")
        direction = endpoint.get("direction", "inbound")
        if technology != "spring":
            configured.append(endpoint)
            continue
        source_file = str(
            endpoint.get("ProjectSrcFile", endpoint.get("SrcFile", ""))
        )
        client_path_layers = endpoint.pop("_spring_client_path_layers", None)
        if (
            protocol == "http"
            and surface == "client"
            and direction == "outbound"
            and client_path_layers is not None
        ):
            resolved = _apply_spring_client_paths(
                (str(layer) for layer in client_path_layers),
                source_file,
                configuration,
                host,
            )
        else:
            resolved = apply_spring_path(
                str(endpoint.get("uri", "")),
                source_file,
                configuration,
                host,
                technology=technology,
                protocol=protocol,
                surface=surface,
                direction=direction,
            )
        if resolved is None:
            _log(
                host,
                "malformed or exhausted placeholder path in "
                f"{endpoint.get('SrcFile', '')} for {endpoint.get('SFunction', '')}",
            )
            continue
        endpoint.update(
            {
                "uri": resolved,
                "technology": technology,
                "protocol": protocol,
                "surface": surface,
                "direction": direction,
                "_spring_configuration_applied": True,
            }
        )
        configured.append(endpoint)
    return configured


# FLOW: _text
# WHY: Preserve exact Java spelling for static-resource syntax and identity checks.
# IN/OUT: Unit and node in; UTF-8 source slice out.
# CALL FLOW: All resource helpers use this leaf utility.
# Purpose: recover exact Java source spelling for a Tree-sitter node. Unit/node
# enter and UTF-8 String leaves; all resource syntax/provenance helpers consume
# it rather than depending on reconstructed AST values.
def _text(unit: Mapping[str, Any], node: Any) -> str:
    return unit["source"][node.start_byte : node.end_byte].decode("utf8")


# FLOW: _walk
# WHY: Traverse Java syntax deterministically for calls and mutations without recursion.
# IN/OUT: Root node in; pre-order node stream out.
# CALL FLOW: Resource candidate and mutation scanners consume this iterator.
# Purpose: provide deterministic pre-order traversal of a Java syntax subtree.
# A root node enters and nodes are yielded to mutation/call scanners; reversing
# children on the stack preserves lexical order without recursion.
def _walk(node: Any) -> Iterable[Any]:
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


# FLOW: _field
# WHY: Isolate Tree-sitter named-field lookup behind host compatibility helpers.
# IN/OUT: Host, node, field name in; child or None out.
# CALL FLOW: All resource syntax decoders use this leaf helper.
# Purpose: delegate named-child lookup to the shared parser compatibility layer.
# Host, syntax node, and field name enter; a child/None leaves for all resource
# helpers, isolating Tree-sitter version details in the host.
def _field(host: Any, node: Any, name: str) -> Any:
    return host.child_by_field(node, name)


# FLOW: _raw_type_node
# WHY: Remove bounded type wrappers before exact framework provenance resolution.
# IN/OUT: Type node in; raw node or None out.
# CALL FLOW: `_known_type` calls it; activation and registry gates consume the verdict.
# Purpose: peel bounded generic/annotation wrappers before Java type provenance
# resolution. A type node enters and raw node/None leaves for `_known_type`;
# excessive or ambiguous wrappers fail closed after the depth bound.
def _raw_type_node(node: Any) -> Any:
    current = node
    for _depth in range(16):
        if current is None:
            return None
        if current.type == "generic_type":
            children = list(current.named_children)
            current = children[0] if children else None
            continue
        if current.type == "annotated_type":
            candidates = [
                child for child in current.named_children if child.type != "annotation"
            ]
            current = candidates[-1] if len(candidates) == 1 else None
            continue
        return current
    return None


# FLOW: _known_type
# WHY: Reject same-named fake configurer/registry types through exact Spring MVC provenance.
# IN/OUT: Host, unit, type node, expected simple name in; Boolean out.
# CALL FLOW: Resource configurer and callback-formal proofs call this leaf.
# Purpose: prove one resource-config Java type belongs to the exact Spring MVC
# package. Unit/type/simple name enter and Boolean leaves; configurer activation
# and registry-formal checks consume it, rejecting same-named local fakes.
def _known_type(
    host: Any, unit: Mapping[str, Any], node: Any, simple_name: str
) -> bool:
    raw = _raw_type_node(node)
    return bool(
        raw is not None
        and host.resolve_known_type(
            unit,
            _text(unit, raw),
            simple_name,
            (WEB_MVC_CONFIG_PACKAGE,),
            raw,
        )
        == WEB_MVC_CONFIG_PACKAGE
    )


# FLOW: _direct_interface_types
# WHY: Normalize only directly implemented interface syntax for the bounded activation model.
# IN/OUT: Host and type node in; direct interface nodes out.
# CALL FLOW: `_resource_method_facts` calls it before genuine WebMvcConfigurer resolution.
# Purpose: normalize Tree-sitter's direct implements-list shapes. Host/type enter
# and direct interface nodes leave for resource configurer activation; inherited
# interfaces are intentionally outside this local proof.
def _direct_interface_types(host: Any, type_node: Any) -> list[Any]:
    interfaces = _field(host, type_node, "interfaces")
    if interfaces is None:
        return []
    children = list(interfaces.named_children)
    if len(children) == 1 and children[0].type == "type_list":
        return list(children[0].named_children)
    return children


# FLOW: _resource_method_facts
# WHY: Prove unique concrete canonical resource callback ownership before reading registrations.
# IN/OUT: Workspace and host in; callback evidence tuples yielded.
# CALL FLOW: Public resource analysis iterates it; call/path checks consume each tuple.
# Purpose: identify canonical genuine `addResourceHandlers` callbacks. Workspace
# and host enter; tuples of unit/owner/method/body/receiver are yielded to the
# endpoint collector. Unique concrete direct configurer identity is required.
def _resource_method_facts(
    workspace: Mapping[str, Any], host: Any
) -> Iterable[tuple[Mapping[str, Any], Mapping[str, Any], Any, Any, str, Any]]:
    # Activation proof is deliberately narrow: a unique, concrete, visible
    # source class must directly implement the genuine WebMvcConfigurer and
    # declare the canonical public non-static void method with exactly one
    # genuine ResourceHandlerRegistry parameter.
    for fname in sorted(workspace.get("units", {})):
        unit = workspace["units"][fname]
        for type_info in sorted(
            unit["type_infos"].values(), key=lambda info: info["node"].start_byte
        ):
            type_node = type_info["node"]
            if (
                type_node.type != "class_declaration"
                or type_info["abstract"]
                or not type_info["workspace_visible"]
            ):
                continue
            owner_fqn = host.qualified_type_name(unit, type_info)
            declarations = workspace["type_declarations"].get(owner_fqn, [])
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                continue
            genuine_interfaces = [
                node
                for node in _direct_interface_types(host, type_node)
                if _known_type(host, unit, node, "WebMvcConfigurer")
            ]
            if len(genuine_interfaces) != 1:
                continue
            body = _field(host, type_node, "body")
            if body is None:
                continue
            for method in body.named_children:
                if method.type != "method_declaration":
                    continue
                name_node = _field(host, method, "name")
                return_type = _field(host, method, "type")
                parameters = _field(host, method, "parameters")
                method_body = _field(host, method, "body")
                if (
                    None in (name_node, return_type, parameters, method_body)
                    or _text(unit, name_node) != "addResourceHandlers"
                    or _text(unit, return_type).strip() != "void"
                    or "public" not in host.declaration_modifier_names(method)
                    or "static" in host.declaration_modifier_names(method)
                ):
                    continue
                formals = [
                    child
                    for child in parameters.named_children
                    if child.type == "formal_parameter"
                ]
                if len(formals) != 1 or len(parameters.named_children) != 1:
                    continue
                parameter_type = _field(host, formals[0], "type")
                parameter_name = _field(host, formals[0], "name")
                if (
                    parameter_type is None
                    or parameter_name is None
                    or not _known_type(
                        host, unit, parameter_type, "ResourceHandlerRegistry"
                    )
                ):
                    continue
                yield (
                    unit,
                    type_info,
                    method,
                    method_body,
                    _text(unit, parameter_name),
                    parameters,
                )


# FLOW: _invocation_name
# WHY: Recover resource call names consistently with safe empty fallback.
# IN/OUT: Host, unit, invocation in; simple name String out.
# CALL FLOW: Candidate scanners use this leaf to match addResourceHandler only.
# Purpose: recover a Java invocation's simple method name. Host/unit/node enter
# and String leaves for registration scanners; absent names become neutral empty
# text, which cannot accidentally match an allowlisted call.
def _invocation_name(host: Any, unit: Mapping[str, Any], invocation: Any) -> str:
    name = _field(host, invocation, "name")
    return _text(unit, name) if name is not None else ""


# FLOW: _direct_registration_chain
# WHY: Exclude nested/control-flow registrations while allowing a direct fluent tail.
# IN/OUT: Host, registration call, callback body in; Boolean directness out.
# CALL FLOW: Public resource analysis gates each matching receiver call here.
# Purpose: prove a registration and any fluent tail form one top-level statement.
# Host/call/callback body enter and Boolean leaves for resource recall. Nested
# control-flow or argument-contained calls fail because their parent is not body.
def _direct_registration_chain(host: Any, invocation: Any, body: Any) -> bool:
    current = invocation
    while getattr(current, "parent", None) is not None:
        parent = current.parent
        if parent.type != "method_invocation":
            break
        object_node = _field(host, parent, "object")
        if object_node is None or (
            object_node.start_byte,
            object_node.end_byte,
        ) != (current.start_byte, current.end_byte):
            break
        current = parent
    statement = getattr(current, "parent", None)
    return bool(
        statement is not None
        and statement.type == "expression_statement"
        and getattr(statement, "parent", None) is not None
        and host.tree_node_key(statement.parent) == host.tree_node_key(body)
    )


# FLOW: _registry_is_mutated
# WHY: Reject uncertain reaching identity after assignment/update of the registry formal.
# IN/OUT: Host, unit, body, receiver name in; Boolean mutation verdict out.
# CALL FLOW: Public resource analysis calls it before scanning any registrations.
# Purpose: reject uncertain receiver reaching definitions. Host/unit/body/formal
# name enter and Boolean leaves for the resource collector; assignment/update of
# the exact registry formal suppresses all registrations in that callback.
def _registry_is_mutated(
    host: Any, unit: Mapping[str, Any], body: Any, registry_name: str
) -> bool:
    for node in _walk(body):
        if node.type == "assignment_expression":
            left = _field(host, node, "left")
            if (
                left is not None
                and left.type == "identifier"
                and _text(unit, left) == registry_name
            ):
                return True
        if node.type == "update_expression" and any(
            child.type == "identifier" and _text(unit, child) == registry_name
            for child in node.named_children
        ):
            return True
    return False


# FLOW: _deduplicate
# WHY: Preserve distinct evidence while collapsing exact duplicate resource facts deterministically.
# IN/OUT: Raw endpoint iterable in; sorted unique list out.
# CALL FLOW: Public resource analysis calls it; configuration/global collection consume output.
# Purpose: make static-resource facts evidence-unique and deterministic. Raw
# endpoint dictionaries enter; sorted unique rows leave for configuration and
# host collection. Identity retains source evidence, not merely path and verb.
def _deduplicate(endpoints: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[Any, ...], dict[str, Any]] = {}
    for endpoint in endpoints:
        key = tuple(
            endpoint[field]
            for field in (
                "uri",
                "method",
                "uri_params",
                "SrcFile",
                "SrcLine",
                "SFunction",
            )
        )
        unique[key] = endpoint
    return [unique[key] for key in sorted(unique)]


# FLOW: analyze_spring_resource_handlers
# WHY: Expose genuine direct MVC static-handler pattern recall through one host entry point.
# IN/OUT: Workspace and host in; provenance-bound GET facts out.
# CALL FLOW: Host orchestration calls it; callback/call/path helpers feed rows, then dedup returns them.
# Purpose: public recall of direct MVC static-handler URL patterns. Workspace
# and host enter; provenance-bound GET facts leave for project configuration and
# global output. Each resolvable argument is independent; physical files ignored.
def analyze_spring_resource_handlers(
    workspace: Mapping[str, Any], host: Any
) -> list[dict[str, Any]]:
    """Return provenance-bound direct Spring MVC static-handler patterns."""

    # Calls are first associated with the exact formal receiver, then checked
    # to be direct expression statements.  Every path argument resolves
    # independently through the guarded workspace String graph; physical
    # resource locations and chain options are intentionally not endpoint
    # evidence.
    endpoints: list[dict[str, Any]] = []
    for unit, owner_info, method, body, registry_name, _parameters in _resource_method_facts(
        workspace, host
    ):
        owner = owner_info["display_name"]
        function = f"{owner}.addResourceHandlers"
        if _registry_is_mutated(host, unit, body, registry_name):
            _log(host, f"mutated ResourceHandlerRegistry in {unit['fname']} for {function}")
            continue
        candidates = []
        for invocation in _walk(body):
            if (
                invocation.type != "method_invocation"
                or _invocation_name(host, unit, invocation) != "addResourceHandler"
            ):
                continue
            receiver = _field(host, invocation, "object")
            if (
                receiver is None
                or receiver.type != "identifier"
                or _text(unit, receiver) != registry_name
            ):
                continue
            candidates.append(invocation)

        for invocation in candidates:
            if not _direct_registration_chain(host, invocation, body):
                _log(host, f"nested resource registration in {unit['fname']} for {function}")
                continue
            arguments = _field(host, invocation, "arguments")
            argument_nodes = list(arguments.named_children) if arguments is not None else []
            if not argument_nodes:
                _log(host, f"resource registration without paths in {unit['fname']} for {function}")
                continue
            for argument in argument_nodes:
                value = host.resolve_workspace_string_expression(
                    unit, argument, workspace, owner
                )
                if value is None:
                    _log(
                        host,
                        "unresolved resource-handler path in "
                        f"{unit['fname']} for {function}: {_text(unit, argument).strip()}",
                    )
                    continue
                path = host.combine_paths("", host.normalize_spring_path(value))
                endpoint = {
                    "uri": path,
                    "method": "GET",
                    "uri_params": "",
                    "SrcFile": unit["fname"],
                    "SrcLine": invocation.start_point.row + 1,
                    "SFunction": function,
                    "RouteSrcFile": unit["fname"],
                    "RouteSrcLine": invocation.start_point.row + 1,
                    "HandlerSrcFile": unit["fname"],
                    "HandlerSrcLine": method.start_point.row + 1,
                    "technology": "spring",
                    "protocol": "http",
                    "surface": "static-handler",
                    "direction": "inbound",
                }
                endpoints.append(endpoint)
                if callable(getattr(host, "debug_log", None)):
                    host.debug_log(endpoint)
    return _deduplicate(endpoints)


__all__ = [
    "SpringConfiguration",
    "SpringProjectConfiguration",
    "analyze_spring_resource_handlers",
    "apply_spring_configuration",
    "apply_spring_path",
    "build_spring_configuration",
    "spring_path_applicator",
]
