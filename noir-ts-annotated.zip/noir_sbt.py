#!/usr/bin/env python3
# Usage examples:
#
# Analyze Spring Boot and JAX-RS sources:
# python3 src/noir_sbt.py \
#   --path "/mnt/app1" \
#   --output "endpoints.csv"
#
# Analyze only Spring Boot sources:
# python3 src/noir_sbt.py \
#   --path "/mnt/app1" \
#   --output "endpoints.csv" \
#   --framework spring
#
# Analyze only JAX-RS sources:
# python3 src/noir_sbt.py \
#   --path "/mnt/app1" \
#   --output "endpoints.csv" \
#   --framework jaxrx
#
# Arguments:
#   --path       application source directory (required)
#   --output     endpoint CSV path (required)
#   --framework  spring or jaxrx; omit to analyze with both

from __future__ import annotations

# ---------------------------------------------------------------------------
# 1. Host module and public report contract
# ---------------------------------------------------------------------------
#
# This file is the coordinator and the direct-annotation analyzer.  Its main
# data flow is:
#
#   Java files -> Tree-sitter trees and query matches -> workspace indexes
#              -> direct Spring/JAX-RS endpoint facts
#              -> sibling recall/configuration analyzers
#              -> normalized, deterministic six-column CSV rows
#
# The imported ``noir_sbt_*`` modules implement indirect surfaces such as
# functional/programmatic routes, hierarchy traversal, Gateway, clients,
# resources, deployment configuration, and WebSockets.  This file supplies
# their shared workspace and helper API, then combines their endpoint facts.

import csv
import json
import os
import re
import sys
from importlib import metadata
from pathlib import Path
import argparse
from datetime import datetime
from typing import Any, Dict, Iterable, List

from noir_sbt_jax_recall import analyze_jax_recall
from noir_sbt_jax_config import (
    build_jax_deployment_configuration,
    select_jax_deployment_path,
)
from noir_sbt_jax_websocket import analyze_jax_websocket
from noir_sbt_spring_config import (
    analyze_spring_resource_handlers,
    apply_spring_configuration,
    build_spring_configuration,
)
from noir_sbt_spring_clients import analyze_spring_clients
from noir_sbt_spring_gateway import analyze_spring_gateway
from noir_sbt_spring_hierarchy import analyze_spring_hierarchy
from noir_sbt_spring_recall import analyze_spring_recall
from noir_sbt_spring_websocket import analyze_spring_websocket

try:
    import tree_sitter_java as tsjava
    from tree_sitter import Language, Parser, Query, QueryCursor
except ModuleNotFoundError:
    # Keep imports side-effect free so helpers and CLI help remain usable in
    # environments where the analysis dependencies have not been installed.
    tsjava = None
    Language = Parser = Query = QueryCursor = None

#from tree_sitter_languages import get_parser


DELIM = ";"
# The stable external schema deliberately contains implementation evidence.
# Internal endpoint facts carry keys such as ``uri``, ``method``, ``SrcFile``,
# ``SrcLine``, ``SFunction`` and ``uri_params``; ``format_endpoint`` translates
# those facts to these exact columns.  Source lines and some richer evidence
# stay internal and are therefore not represented in the CSV.
CSV_FIELDNAMES = [
    "module_name",
    "interface_type",
    "endpoint",
    "source_file_name",
    "method_name",
    "parameters",
]
IGNORED_DIRS = {
    "node_modules",
    ".git",
    "dist",
    "build",
    "target",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "tmp",
    ".next",
    "out",
    "vendor",
    "test",
}
SPRING_MAPPING_PACKAGE = "org.springframework.web.bind.annotation"
SPRING_ALIAS_FOR_PACKAGE = "org.springframework.core.annotation"
SPRING_MAPPING_METHODS = {
    "GetMapping": "GET",
    "PostMapping": "POST",
    "PutMapping": "PUT",
    "DeleteMapping": "DELETE",
    "PatchMapping": "PATCH",
    "RequestMapping": None,
}
SPRING_HTTP_METHODS = (
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
    "TRACE",
)
SPRING_REQUEST_MAPPING_ATTRIBUTES = {
    "name",
    "value",
    "path",
    "method",
    "params",
    "headers",
    "consumes",
    "produces",
    "version",
}
SPRING_MAX_CONSTANT_DEPTH = 12
SPRING_MAX_CONSTANT_LENGTH = 8192
JAX_RS_PACKAGES = ("jakarta.ws.rs", "javax.ws.rs")
JAX_RS_CORE_PACKAGES = ("jakarta.ws.rs.core", "javax.ws.rs.core")
JAX_RS_HTTP_METHODS = (
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "PATCH",
    "HEAD",
    "OPTIONS",
)
JAX_HTTP_METHOD_STATIC_CONSTANTS = {
    f"{package}.HttpMethod": {
        method: method for method in JAX_RS_HTTP_METHODS
    }
    for package in JAX_RS_PACKAGES
}
HTTP_METHOD_TOKEN = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")
JAVA_ELEMENT_TYPES = {
    "ANNOTATION_TYPE",
    "CONSTRUCTOR",
    "FIELD",
    "LOCAL_VARIABLE",
    "METHOD",
    "MODULE",
    "PACKAGE",
    "PARAMETER",
    "RECORD_COMPONENT",
    "TYPE",
    "TYPE_PARAMETER",
    "TYPE_USE",
}

log_file = "noir_sbt.log"
input_srcdir = ""
module_name = ""
SUPPORTED_TREE_SITTER_VERSIONS = {
    "tree-sitter": "0.25.2",
    "tree-sitter-java": "0.23.5",
}

# ---------------------------------------------------------------------------
# 2. Tree-sitter query vocabulary
# ---------------------------------------------------------------------------
#
# Tree-sitter queries are S-expressions over the Java concrete syntax tree:
#
#   (method_declaration                       match a Java node type
#       name: (identifier) @method.name       constrain a named grammar field
#       parameters: (formal_parameters)       and capture its node
#           @method.parameters) @method.node
#
# Square brackets mean alternatives; ``(_ )`` (spelled ``(_)`` below) matches
# any named node; ``?`` makes the preceding node optional.  A capture such as
# ``@annotation.name`` is a label, not a string extraction: QueryCursor returns
# the actual syntax node under that label, retaining byte offsets and parents.
#
# One query can contain several top-level patterns.  Every match returned by
# ``QueryCursor.matches()`` keeps the captures from one structural occurrence
# associated.  That association is essential: independently pooling captures
# could attach annotation A to method B.  The code therefore never uses a flat
# captures-only API.
#
# Example input (illustrative Java, not executed here):
#
#   class Users {
#       @GetMapping("/users/{id}")
#       User get(@PathVariable String id) { ... }
#   }
#
# The ``method_annotation`` query yields one match whose capture map includes
# ``type.node=Users``, ``annotation.name=GetMapping``, ``annotation.node`` with
# its arguments, ``method.name=get``, ``method.parameters=(...)``, and the full
# ``method.node``.  Later stages resolve annotation provenance and values; the
# query itself does not declare that the spelling is genuinely Spring-owned.

SPRING_QUERY_SOURCES = {
# QUERY CARD: SPRING_QUERY_SOURCES.annotation_declaration
# MATCH: Java annotation-type declarations, including nested declarations.
# CAPTURES: annotation declaration name and complete declaration node.
# DOWNSTREAM: shadow checks and workspace source-annotation indexes.
# EXAMPLE: ``@interface GetMapping {}`` matches and can shadow Spring's name.
# QUERY ``annotation_declaration``
# Shape: every Java ``@interface Name`` declaration, including nested source
# annotations; ``@annotation.declaration.name`` captures ``Name`` and
# ``@annotation.declaration.node`` captures the complete declaration.
# Use: ``declared_annotation_names`` detects same-file shadowing, while the
# workspace indexes later attach meta-annotations/elements from richer queries.
# Example ``@interface GetMapping {}`` is captured here so its familiar name
# can block accidental ownership by Spring.
    "annotation_declaration": r"""
        (annotation_type_declaration
            name: (identifier) @annotation.declaration.name) @annotation.declaration.node
    """,
# QUERY CARD: SPRING_QUERY_SOURCES.field
# MATCH: ordinary fields plus interface/annotation constant declarations.
# CAPTURES: type, member name, optional initializer, declarator, and field node.
# DOWNSTREAM: same-file/workspace constant and static-member declaration indexes.
# EXAMPLE: ``public static final String API = "/api";`` supplies all captures.
# QUERY ``field``
# Shape: ordinary fields and interface/annotation ``constant_declaration``
# members.  It captures declared type, member name, optional initializer,
# declarator, and whole declaration; ``String API = "/api"`` is one match.
# Use: same-file and workspace constant indexes consume these nodes, then Java
# eligibility/access rules decide whether a path expression may follow them.
# Counterexample: an uninitialized field still matches syntax, but no route
# value can be resolved because ``@constant.value`` is absent.
    "field": r"""
        [
            (field_declaration
                type: (_) @constant.type
                declarator: (variable_declarator
                    name: (identifier) @constant.name
                    value: (_)? @constant.value) @constant.declarator)
            (constant_declaration
                type: (_) @constant.type
                declarator: (variable_declarator
                    name: (identifier) @constant.name
                    value: (_)? @constant.value) @constant.declarator)
        ] @constant.field
    """,
# QUERY CARD: SPRING_QUERY_SOURCES.import
# MATCH: every exact/wildcard, static/non-static Java import declaration.
# CAPTURES: the complete import node for later textual tier classification.
# DOWNSTREAM: parse_java_imports, then provenance/type/member resolution.
# EXAMPLE: ``import static example.Paths.API;`` is one import-node match.
# QUERY ``import``
# Shape: every Java import declaration as one ``@import.node``, covering exact,
# wildcard, static, and static-wildcard forms without interpreting text here.
# Use: ``parse_java_imports`` classifies the captured declaration; provenance,
# type, enum, annotation, and constant resolvers consult the resulting tiers.
# Examples ``import a.Path;`` and ``import static a.Paths.API;`` both match.
    "import": r"""
        (import_declaration) @import.node
    """,
# QUERY CARD: SPRING_QUERY_SOURCES.type
# MATCH: class, interface, enum, record, and annotation type declarations.
# CAPTURES: simple type name and complete type declaration node.
# DOWNSTREAM: lexical type facts, FQ identity, visibility, ownership, hierarchy.
# EXAMPLE: ``record User(String id) {}`` captures User and its record node.
# QUERY ``type``
# Shape: class, interface, enum, record, and annotation declarations.  Each
# match pairs ``@type.name`` with the complete ``@type.node``.
# Use: ``build_type_infos`` reconstructs lexical owner chains/visibility; all
# workspace identity, constants, hierarchy, and handler attribution build on
# those type facts.  Method-local types match syntactically but are later marked
# non-workspace-visible rather than silently becoming endpoint containers.
    "type": r"""
        [
            (class_declaration name: (identifier) @type.name)
            (interface_declaration name: (identifier) @type.name)
            (enum_declaration name: (identifier) @type.name)
            (record_declaration name: (identifier) @type.name)
            (annotation_type_declaration name: (identifier) @type.name)
        ] @type.node
    """,
# QUERY CARD: SPRING_QUERY_SOURCES.type_annotation
# MATCH: direct normal/marker annotations on class and record modifiers.
# CAPTURES: annotation name/node/optional args plus exact type name/body/node.
# DOWNSTREAM: direct Spring/JAX roots, applications, and type mapping grouping.
# EXAMPLE: ``@Path("/users") class Users {}`` associates Path with Users.
# QUERY ``type_annotation``
# Shape: each direct normal or marker annotation in the modifiers of a class or
# record.  Captures associate annotation name/node/optional arguments with the
# exact type name/body/node; interfaces are intentionally absent from this
# direct-root query.  ``@Path("/users") class Users {}`` is one match.
# Use: grouped by type for direct Spring mappings, JAX roots/ApplicationPath,
# custom metadata, and record roots; later provenance rejects fake spellings.
    "type_annotation": r"""
        (class_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @type.name
            body: (class_body) @type.body) @type.node
        (record_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @type.name
            body: (class_body) @type.body) @type.node
    """,
# QUERY CARD: SPRING_QUERY_SOURCES.method_annotation
# MATCH: direct normal/marker annotations on explicit class/record methods.
# CAPTURES: annotation data, enclosing type, method name/formals/full node.
# DOWNSTREAM: grouped direct mappings and shared source-method graph facts.
# EXAMPLE: ``@GET @Path("/{id}") Item get(String id)`` yields two matches.
# QUERY ``method_annotation``
# Shape: every direct annotation on an explicitly declared class/record method,
# preserving its enclosing type plus method name, formals, and whole method.
# Use: grouping by ``@method.node`` keeps several annotations on one method
# together for direct Spring/JAX decoding and downstream source method graphs.
# Example ``@GET @Path("/{id}") public Item get(String id)`` produces two
# structurally associated matches; an annotation on a constructor does not.
    "method_annotation": r"""
        (class_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
        (record_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
    """,
# QUERY CARD: SPRING_QUERY_SOURCES.record_component_annotation
# MATCH: annotations on ordinary and varargs record components.
# CAPTURES: annotation, record/type, component name/node and available type data.
# DOWNSTREAM: METHOD-target filtering and implicit-accessor route synthesis.
# EXAMPLE: ``record R(@GET String current) {}`` captures current's annotation.
# QUERY ``record_component_annotation``
# Shape: direct normal/marker annotations on ordinary or varargs record
# components.  Captures include record/type body, component node/name and,
# where present, component type/declarator.
# Use: direct analyzers filter annotations by METHOD target and synthesize the
# implicit accessor fact unless ``record_method`` proves an explicit accessor.
# Example ``record R(@GET String current) {}`` matches; whether GET can legally
# propagate is a later provenance/Target decision.
    "record_component_annotation": r"""
        (record_declaration
            name: (identifier) @type.name
            parameters: (formal_parameters
                (formal_parameter
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    type: (_) @component.type
                    name: (identifier) @component.name) @component.node)
            body: (class_body) @type.body) @type.node
        (record_declaration
            name: (identifier) @type.name
            parameters: (formal_parameters
                (spread_parameter
                    (modifiers
                        [
                            (annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name
                                arguments: (annotation_argument_list) @annotation.arguments)
                            (marker_annotation
                                name: [
                                    (identifier)
                                    (scoped_identifier)
                                ] @annotation.name)
                        ] @annotation.node)
                    (variable_declarator
                        name: (identifier) @component.name) @component.declarator) @component.node)
            body: (class_body) @type.body) @type.node
    """,
# QUERY CARD: SPRING_QUERY_SOURCES.record_method
# MATCH: every explicitly declared method in a record body, annotated or not.
# CAPTURES: record/type plus method name/formals/full method node.
# DOWNSTREAM: zero-formal explicit-accessor suppression for component synthesis.
# EXAMPLE: ``String value()`` suppresses an implicit value accessor candidate.
# QUERY ``record_method``
# Shape: every explicitly declared record-body method, capturing its record,
# method name/formals, and method node even when the method has no annotation.
# Use: ``record_explicit_zero_parameter_accessors`` builds the suppression set
# for synthetic component accessors.  ``String value()`` suppresses synthesis;
# ``String value(int index)`` does not because it is not the canonical accessor.
    "record_method": r"""
        (record_declaration
            name: (identifier) @type.name
            body: (class_body
                (method_declaration
                    name: (identifier) @method.name
                    parameters: (formal_parameters) @method.parameters) @method.node) @type.body) @type.node
    """,
}

JAX_QUERY_SOURCES = {
# JAX reuses all neutral Java/Spring structural queries and adds package,
# annotation-definition, annotation-element, and enum-constant facts.  The
# shared superset lets one root-wide workspace support both frameworks and the
# sibling analyzers without reparsing source into an unrelated model.
    **SPRING_QUERY_SOURCES,
# QUERY CARD: JAX_QUERY_SOURCES.package
# MATCH: simple or dotted Java package declarations; default package has none.
# CAPTURES: package name node and complete package declaration.
# DOWNSTREAM: unit package, FQNs, visibility, same-package and deployment logic.
# EXAMPLE: ``package com.example.api;`` captures ``com.example.api``.
# QUERY ``package`` (JAX/shared-workspace extension)
# Shape: one simple or dotted Java package declaration, capturing both the
# name and complete declaration.  Default-package files intentionally yield no
# match.  ``package com.example.api;`` captures ``com.example.api``.
# Use: ``java_package_name`` supplies FQNs, same-package resolution, visibility,
# application ancestry, and per-project deployment association.
    "package": r"""
        (package_declaration
            [
                (identifier)
                (scoped_identifier)
            ] @package.name) @package.node
    """,
# QUERY CARD: JAX_QUERY_SOURCES.annotation_meta
# MATCH: direct normal/marker meta-annotations on source annotation types.
# CAPTURES: meta name/node/args and owning annotation name/body/full node.
# DOWNSTREAM: custom JAX designator and Spring composed-mapping graphs.
# EXAMPLE: Retention and HttpMethod on PURGE associate with the same owner.
# QUERY ``annotation_meta`` (JAX/shared-workspace extension)
# Shape: each direct normal/marker meta-annotation on an annotation declaration;
# captures meta name/node/optional arguments plus declaration name/body/node.
# Use: custom JAX ``@HttpMethod``/retention indexing and Spring composed-mapping
# branch construction consume these associations.  ``@Retention(RUNTIME)
# @HttpMethod("PURGE") @interface PURGE {}`` yields two matches on one owner.
    "annotation_meta": r"""
        (annotation_type_declaration
            (modifiers
                [
                    (annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name
                        arguments: (annotation_argument_list) @annotation.arguments)
                    (marker_annotation
                        name: [
                            (identifier)
                            (scoped_identifier)
                        ] @annotation.name)
                ] @annotation.node)
            name: (identifier) @annotation.declaration.name
            body: (annotation_type_body) @annotation.declaration.body
        ) @annotation.declaration.node
    """,
# QUERY CARD: JAX_QUERY_SOURCES.annotation_element
# MATCH: each element declaration inside a source annotation type.
# CAPTURES: element type/name/optional default/node plus owning declaration.
# DOWNSTREAM: AliasFor edges, type/cardinality/default and use-site validation.
# EXAMPLE: ``String[] path() default {};`` captures type, name, and default.
# QUERY ``annotation_element`` (JAX/shared-workspace extension)
# Shape: each element declared inside an annotation type, capturing return type,
# element name, optional default, element node, and owning annotation node/name.
# Use: Spring AliasFor/type/default/cardinality validation and annotation-use
# decoding build element facts from it.  ``String[] path() default {};`` matches;
# inherited or dependency-only elements cannot because they have no source node.
    "annotation_element": r"""
        (annotation_type_declaration
            name: (identifier) @annotation.declaration.name
            body: (annotation_type_body
                (annotation_type_element_declaration
                    type: (_) @annotation.element.type
                    name: (identifier) @annotation.element.name
                    value: (_)? @annotation.element.default
                ) @annotation.element.node
            )
        ) @annotation.declaration.node
    """,
# QUERY CARD: JAX_QUERY_SOURCES.enum_constant
# MATCH: every named constant directly inside an enum body.
# CAPTURES: enum type/name/node and enum-constant name/node.
# DOWNSTREAM: member/static declaration ambiguity and identity indexes.
# EXAMPLE: ``enum Mode { FAST, SAFE }`` yields one match per constant.
# QUERY ``enum_constant`` (JAX/shared-workspace extension)
# Shape: each enum constant with its constant node/name and enclosing enum
# type/name.  ``enum Mode { FAST, SAFE }`` produces two matches.
# Use: the shared workspace exposes enum declarations to identity consumers;
# the direct route decoders still require their own allowlisted framework enum
# provenance, so an arbitrary enum constant named GET cannot become a verb.
    "enum_constant": r"""
        (enum_declaration
            name: (identifier) @enum.type.name
            body: (enum_body
                (enum_constant
                    name: (identifier) @enum.constant.name
                ) @enum.constant.node
            )
        ) @enum.type.node
    """,
}


# ---------------------------------------------------------------------------
# 3. Small syntax helpers and dependency/runtime gate
# ---------------------------------------------------------------------------

# FLOW: JaxRS_Detector
# WHY: Preserve the legacy public detector helper as a simple Java-extension predicate.
# IN/OUT: File name/content -> Boolean eligibility.
# CALL FLOW: No current host path calls it; `discover_java_files` performs the
# same suffix filtering directly before `analyze_module` invokes analyzers.
# Purpose/why: admit Java files to structural JAX analysis without brittle text markers.
# Input/output: file name/content in, Boolean extension decision out; upstream discovery, downstream JAX parser.
def JaxRS_Detector(fname,fcontent):
    # Every Java file is passed to the Tree-Sitter analyzer.
    # JAX-RS annotations, rather than text matching, decide whether endpoints exist.
    return(Path(fname).suffix.lower() == ".java")


# FLOW: SpringBoot_Detector
# WHY: Preserve the legacy public detector helper as a simple Java-extension predicate.
# IN/OUT: File name/content -> Boolean eligibility.
# CALL FLOW: No current host path calls it; `discover_java_files` performs the
# same suffix filtering directly before `analyze_module` invokes analyzers.
# Purpose/why: admit Java files to structural Spring analysis without regex framework detection.
# Input/output: file name/content in, Boolean extension decision out; upstream discovery, downstream Spring parser.
def SpringBoot_Detector(fname,fcontent):
    # Every Java file is passed to the Tree-Sitter analyzer.
    # Mapping annotations, rather than regex text matches, decide whether endpoints exist.
    return(Path(fname).suffix.lower() == ".java")

# FLOW: node_text
# WHY: Recover exact source spelling covered by one syntax node.
# IN/OUT: UTF-8 source and node -> decoded slice.
# CALL FLOW: Fact builders call it; semantic resolvers/diagnostics consume spelling.
# Purpose/why: recover the exact UTF-8 source spelling represented by one syntax node.
# Input/output: source bytes plus Tree-sitter node in, String slice out; used by every semantic decoder.
def node_text(source: bytes, node) -> str:
    return source[node.start_byte:node.end_byte].decode("utf8")

# FLOW: find_first
# WHY: Find one direct grammar child without recursive overreach.
# IN/OUT: Parent and type name -> child or None.
# CALL FLOW: Syntax decoders call it; modifier/body logic consumes the node.
# Purpose/why: select the first direct child of a requested grammar type without recursive guessing.
# Input/output: parent node/type name in, child or None out; upstream syntax tree, downstream modifier/body helpers.
def find_first(node, type_name: str):
    for child in node.children:
        if child.type == type_name:
            return child
    return None

# FLOW: child_by_field
# WHY: Contain grammar field lookup and represent absence explicitly.
# IN/OUT: Node and field name -> child or None.
# CALL FLOW: Parsers call it; downstream decoders branch on the optional field.
# Purpose/why: access stable named grammar fields while containing binding/API failures.
# Input/output: node/field in, child or None out; upstream Tree-sitter nodes, downstream all AST decoders.
def child_by_field(node, field_name: str):
    """Tree-sitter поля стабильнее структуры children."""
    try:
        return node.child_by_field_name(field_name)
    except Exception:
        return None

# FLOW: combine_paths
# WHY: Compose two resolved URI layers with a stable slash boundary.
# IN/OUT: Base and suffix -> combined route.
# CALL FLOW: Route-layer composers call it; endpoint facts consume the path.
# EXAMPLE: `/api/` plus `/users` becomes `/api/users`; two empty layers become `/`.
# Purpose/why: compose two already-resolved URI layers with one boundary slash and explicit root identity.
# Input/output: base/suffix Strings in, composed String out; upstream route layers, downstream endpoint facts.
def combine_paths(basepath, endpoint_path):
    if not basepath and not endpoint_path:
        return("/")
    if not basepath:
        return(endpoint_path)
    if not endpoint_path:
        return(basepath)
    return(basepath.rstrip('/')+'/'+endpoint_path.lstrip('/'))

# FLOW: get_callable_parameters_as_is
# WHY: Keep Java formal text as auditable metadata, not an inferred schema.
# IN/OUT: Source and formals node -> trimmed text.
# CALL FLOW: Method analyzers call it; endpoint facts carry it to CSV.
# Purpose/why: preserve auditable Java formal source without inventing structured API-input semantics.
# Input/output: source/formal node in, parentheses-trimmed text out; upstream method match, downstream uri_params/CSV.
def get_callable_parameters_as_is(source: bytes, params_node) -> str:
    if not params_node:
        return ""

    params_text=node_text(source, params_node)
    if params_text.startswith("(") and params_text.endswith(")"):
        params_text=params_text[1:-1]

    return(params_text.strip())



# FLOW: get_annotation_arguments
# WHY: Separate positional from named values while treating comments as trivia.
# IN/OUT: Annotation node -> positional list and named-node map.
# CALL FLOW: Spring/JAX decoders call it; value resolvers consume the AST nodes.
# EXAMPLE: `@Path("/x")` is positional; `@GetMapping(path="/x")` has named `path`.
# Purpose/why: separate positional and named annotation values while treating comments as trivia.
# Input/output: annotation node in, (positional list, named map) of AST nodes out; feeds Spring/JAX value decoders.
def get_annotation_arguments(annotation_node):
# Java permits either a positional annotation value (``@Path("/x")``) or
# named element/value pairs (``@RequestMapping(path="/x")``).  Returning AST
# nodes instead of decoded strings defers framework-specific validation and
# constant resolution.  Comments are named Java nodes but remain trivia here.
    positional=[]
    named=dict()
    arguments=child_by_field(annotation_node, "arguments")

    if not arguments:
        return(positional, named)

    for child in arguments.named_children:
        # Tree-sitter exposes comments as named children. They are trivia, not
        # additional annotation values (for example @GetMapping("/x" /*...*/)).
        if child.type in {"line_comment", "block_comment"}:
            continue
        if child.type == "element_value_pair":
            key_node=child_by_field(child, "key")
            value_node=child_by_field(child, "value")
            if key_node and value_node:
                key=key_node.text.decode('utf8')
                named[key]=value_node
        else:
            positional.append(child)

    return(positional, named)

# FLOW: require_tree_sitter
# WHY: Fail early unless the validated native parser/grammar pair is installed.
# IN/OUT: Installed dependency state -> success or RuntimeError.
# CALL FLOW: Runtime builders call it; parsing starts only after this gate.
# Purpose/why: fail before native parsing unless the validated parser/grammar distributions are exact.
# Input/output: installed-module metadata in, success or RuntimeError out; upstream CLI/runtime builders, downstream queries.
def require_tree_sitter():
# Import success alone is insufficient: the Python binding and the Java
# grammar are a native compatibility pair.  This exact pair was validated on
# large workspaces, so analysis fails before parsing when metadata differs or
# cannot be verified.
    if tsjava is None or any(value is None for value in (Language, Parser, Query, QueryCursor)):
        raise RuntimeError(
            "Spring/JAX-RS analysis requires the tree_sitter and "
            "tree_sitter_java Python packages"
        )
    installed_versions = {}
    for distribution_name in SUPPORTED_TREE_SITTER_VERSIONS:
        try:
            installed_versions[distribution_name] = metadata.version(distribution_name)
        except metadata.PackageNotFoundError:
            installed_versions[distribution_name] = None
    if installed_versions != SUPPORTED_TREE_SITTER_VERSIONS:
        actual = ", ".join(
            f"{name} {installed_versions[name] or 'unknown'}"
            for name in SUPPORTED_TREE_SITTER_VERSIONS
        )
        raise RuntimeError(
            f"unsupported Tree-sitter dependency pair ({actual}); install "
            "tree-sitter 0.25.2 with tree-sitter-java 0.23.5"
        )


# FLOW: build_java_runtime
# WHY: Compile one named query set around a reusable Java parser.
# IN/OUT: Query-source map and optional runtime parts -> runtime dictionary.
# CALL FLOW: Framework runtime builders call it; unit analyzers consume parser/queries.
# EXAMPLE: Query dictionary keys remain stable in `runtime["queries"]`.
# Purpose/why: compile one deterministic named query set around one reusable Java parser/language.
# Input/output: query-source map plus optional runtime objects in, language/parser/query map out; feeds source-unit parsing.
def build_java_runtime(query_sources, java_language=None, parser=None):
    """Create a reusable Java parser and compile a framework query set once."""
    require_tree_sitter()
    java_language = java_language or Language(tsjava.language())
    return {
        "language": java_language,
        "parser": parser or Parser(java_language),
        "queries": {
            name: Query(java_language, query_source)
            for name, query_source in sorted(query_sources.items())
        },
    }


# FLOW: build_spring_runtime
# WHY: Bind the neutral runtime builder to Spring query sources.
# IN/OUT: Optional language/parser -> Spring runtime.
# CALL FLOW: SpringBoot_Analyzer/analyze_module calls it; direct Spring parsing consumes it.
# Purpose/why: specialize the neutral runtime builder with direct Spring structural queries.
# Input/output: optional language/parser in, Spring runtime map out; called by direct analyzer and module host.
def build_spring_runtime(java_language=None, parser=None):
    """Create one reusable Java parser and compile all Spring queries once."""
    return build_java_runtime(
        SPRING_QUERY_SOURCES, java_language=java_language, parser=parser
    )


# FLOW: build_jax_runtime
# WHY: Bind the runtime builder to the JAX/workspace query superset.
# IN/OUT: Optional language/parser -> JAX runtime.
# CALL FLOW: Workspace/JAX analyzers call it; unit and root-wide passes consume it.
# Purpose/why: compile the shared superset needed for JAX and root-wide Java workspace facts.
# Input/output: optional language/parser in, JAX runtime map out; upstream host, downstream build_jax_unit/workspace.
def build_jax_runtime(java_language=None, parser=None):
    """Create one reusable Java parser and compile all JAX-RS queries once."""
    return build_java_runtime(
        JAX_QUERY_SOURCES, java_language=java_language, parser=parser
    )


# FLOW: run_query_matches
# WHY: Preserve match capture associations and native node lifetimes.
# IN/OUT: Query, root, optional owners -> match sequence.
# CALL FLOW: Unit builders call it; grouped structural fact builders consume matches.
# EXAMPLE: One match retains its capture-name-to-node-list association.
# Purpose/why: retain match-level capture associations and optionally keep native owners alive with their nodes.
# Input/output: compiled query/root/owner list in, QueryCursor matches out; feeds all grouped structural facts.
def run_query_matches(query, root, lifetime_owners=None):
    """Keep each QueryCursor match as the association unit."""
    cursor = QueryCursor(query)
    matches = cursor.matches(root)
    if lifetime_owners is not None:
        lifetime_owners.append((cursor, matches))
    return matches


# A query match is represented as ``(pattern_index, captures)``.  ``captures``
# maps each ``@capture.name`` to a list because one pattern may capture the same
# name repeatedly.  Most structural queries expect exactly one relevant node;
# callers explicitly choose the first and separately group repeated matches by
# stable byte spans.
# FLOW: first_capture
# WHY: Select an expected singleton from one match capture multimap.
# IN/OUT: Capture map and name -> first node or None.
# CALL FLOW: Fact builders call it; node-specific parsing follows.
# Purpose/why: read a query's expected singleton capture without flattening separate matches.
# Input/output: capture multimap/name in, first node or None out; upstream matches, downstream fact builders.
def first_capture(captures, name):
    nodes = captures.get(name, [])
    return nodes[0] if nodes else None


# FLOW: tree_node_key
# WHY: Make a stable file-local join key for one immutable syntax node.
# IN/OUT: Node -> `(start_byte, end_byte)`.
# CALL FLOW: Query passes call it; ownership/fact indexes join on it.
# Purpose/why: join facts from independent queries by one immutable node's file-local byte span.
# Input/output: syntax node in, (start,end) key out; upstream captures, downstream grouping/index maps.
def tree_node_key(node):
# Byte ranges are unique within one immutable parsed source tree and provide a
# compact key for joining matches from separate compiled queries.
    return (node.start_byte, node.end_byte)


# FLOW: nearest_enclosing_type
# WHY: Recover the nearest lexical Java type owner.
# IN/OUT: Node -> enclosing type declaration or None.
# CALL FLOW: Ownership/visibility helpers call it; access and display-name logic consume it.
# Purpose/why: recover lexical Java ownership without confusing blocks/methods with member types.
# Input/output: node in, nearest enclosing type or None out; feeds display names, visibility and constant ownership.
def nearest_enclosing_type(node):
    current = getattr(node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return current
        current = getattr(current, "parent", None)
    return None


# FLOW: type_is_abstract
# WHY: Identify abstract class containers that are not concrete roots.
# IN/OUT: Source/type node -> Boolean.
# CALL FLOW: build_type_infos calls it; root eligibility consumes the fact.
# Purpose/why: prevent abstract class declarations from acting as direct concrete endpoint containers.
# Input/output: source/type node in, Boolean out; upstream type query, downstream type/root eligibility.
def type_is_abstract(source, type_node):
    modifiers = find_first(type_node, "modifiers")
    return bool(
        type_node.type == "class_declaration"
        and modifiers
        and any(child.type == "abstract" for child in modifiers.children)
    )


# FLOW: type_is_workspace_visible
# WHY: Exclude method/block-local types from root-wide identity.
# IN/OUT: Type node -> Boolean visibility.
# CALL FLOW: build_type_infos calls it; workspace indexes/provenance consume it.
# Purpose/why: exclude method/block-local declarations from cross-file identity while retaining member nesting.
# Input/output: type node in, Boolean out; upstream type query, downstream workspace indexes/analyzers.
def type_is_workspace_visible(type_node):
    current = getattr(type_node, "parent", None)
    while current is not None:
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            return True
        if current.type in {
            "method_declaration",
            "constructor_declaration",
            "compact_constructor_declaration",
            "lambda_expression",
            "block",
            "constructor_body",
            "static_initializer",
        }:
            return False
        current = getattr(current, "parent", None)
    return True


# FLOW: build_type_infos
# WHY: Build lexical owner, name, visibility, and abstraction facts.
# IN/OUT: Source and type matches -> byte-keyed type-info map.
# CALL FLOW: Unit analyzers call it; workspace resolvers consume the map.
# EXAMPLE: `Outer.Inner` records Outer as owner and `Outer.Inner` as display name.
# Purpose/why: turn raw type matches into lexical owner, display-name, visibility and abstraction facts.
# Input/output: source/query matches in, byte-keyed type-info map out; upstream queries, downstream every workspace pass.
def build_type_infos(source, type_matches):
# Construct lexical owner identities before route decoding.  For
# ``Outer.Inner`` this records both the display name and the outer-node key;
# it also rejects method/block-local declarations from the root-wide source
# model while retaining genuine nested member types.
    infos = {}
    ordered = []
    for _pattern_index, captures in type_matches:
        type_node = first_capture(captures, "type.node")
        name_node = first_capture(captures, "type.name")
        if type_node is None or name_node is None:
            continue
        ordered.append((type_node.start_byte, type_node, node_text(source, name_node)))

    for _start_byte, type_node, simple_name in sorted(ordered):
        outer_node = nearest_enclosing_type(type_node)
        outer_key = tree_node_key(outer_node) if outer_node is not None else None
        outer_info = infos.get(outer_key)
        display_name = (
            f"{outer_info['display_name']}.{simple_name}"
            if outer_info is not None
            else simple_name
        )
        key = tree_node_key(type_node)
        infos[key] = {
            "node": type_node,
            "simple_name": simple_name,
            "display_name": display_name,
            "outer_key": outer_key if outer_info is not None else None,
            "abstract": type_is_abstract(source, type_node),
            "workspace_visible": type_is_workspace_visible(type_node)
            and (outer_info is None or outer_info["workspace_visible"]),
            "mapping": None,
        }
    return infos


# FLOW: visible_local_type_infos
# WHY: Model source types visible at a use site for shadowing.
# IN/OUT: Unit/context -> visible type-info records.
# CALL FLOW: Name resolvers call it; provenance decisions consume candidates.
# Purpose/why: model source types that can shadow an imported simple name at one lexical use site.
# Input/output: unit/context in, visible type-info list out; feeds genuine framework/type provenance resolution.
def visible_local_type_infos(unit, context_node=None):
    """Return source types that can lexically shadow a simple import."""
    infos = unit.get("type_infos", {})
    visible_keys = {
        key
        for key, info in infos.items()
        if info["outer_key"] is None and info["workspace_visible"]
    }
    if context_node is None:
        return [infos[key] for key in visible_keys]

    current = nearest_enclosing_type(context_node)
    scope_keys = set()
    while current is not None:
        key = tree_node_key(current)
        info = infos.get(key)
        if info is None:
            break
        scope_keys.add(key)
        visible_keys.add(key)
        current = (
            infos[info["outer_key"]]["node"]
            if info["outer_key"] in infos
            else None
        )
    visible_keys.update(
        key
        for key, info in infos.items()
        if info["workspace_visible"] and info["outer_key"] in scope_keys
    )
    return [infos[key] for key in visible_keys]


# FLOW: visible_local_type_names
# WHY: Project visible type records to simple-name shadows.
# IN/OUT: Unit/context -> simple-name set.
# CALL FLOW: Annotation/type resolvers call it; import precedence checks consume it.
# Purpose/why: project visible local type facts to the simple-name shadow set used by name resolution.
# Input/output: unit/context in, name set out; upstream visible_local_type_infos, downstream annotation/type resolvers.
def visible_local_type_names(unit, context_node=None):
    return {
        info["simple_name"]
        for info in visible_local_type_infos(unit, context_node)
    }


# FLOW: parse_java_imports
# WHY: Separate exact/wildcard and static/non-static Java imports.
# IN/OUT: Source and import matches -> four indexes.
# CALL FLOW: Unit builders call it; provenance/constant/type resolvers consume them.
# EXAMPLE: A static member import is indexed separately from a type import.
# Purpose/why: classify exact/wildcard and static/non-static imports into Java precedence tiers.
# Input/output: source/import matches in, four import indexes out; upstream query, downstream provenance/constants/types.
def parse_java_imports(source, import_matches):
# Four namespaces are kept separately because Java lookup precedence differs:
# exact type imports, on-demand type imports, exact static members, and
# on-demand static members.  A duplicate exact simple name becomes the empty
# ambiguity marker instead of silently selecting by scan order.
    exact = {}
    wildcards = set()
    static_exact = {}
    static_wildcards = set()
    for _pattern_index, captures in import_matches:
        import_node = first_capture(captures, "import.node")
        if import_node is None:
            continue
        declaration = node_text(source, import_node).strip()
        match = re.fullmatch(r"import\s+(static\s+)?([^;]+)\s*;", declaration)
        if not match:
            continue
        target = match.group(2).strip()
        if match.group(1):
            if target.endswith(".*"):
                static_wildcards.add(target[:-2])
                continue
            simple_name = target.rsplit(".", 1)[-1]
            previous = static_exact.get(simple_name)
            static_exact[simple_name] = (
                target if previous in (None, target) else ""
            )
            continue
        if target.endswith(".*"):
            wildcards.add(target[:-2])
            continue
        simple_name = target.rsplit(".", 1)[-1]
        previous = exact.get(simple_name)
        exact[simple_name] = target if previous in (None, target) else ""
    return {
        "exact": exact,
        "wildcards": wildcards,
        "static_exact": static_exact,
        "static_wildcards": static_wildcards,
    }


# FLOW: declared_annotation_names
# WHY: Expose same-file annotations that shadow framework spellings.
# IN/OUT: Source and declaration matches -> name set.
# CALL FLOW: SpringBoot_Analyzer calls it; mapping provenance consumes it.
# Purpose/why: expose same-file annotation declarations that shadow familiar framework simple names.
# Input/output: source/declaration matches in, name set out; upstream query, downstream direct Spring resolver.
def declared_annotation_names(source, declaration_matches):
    names = set()
    for _pattern_index, captures in declaration_matches:
        name_node = first_capture(captures, "annotation.declaration.name")
        if name_node is not None:
            names.add(node_text(source, name_node))
    return names


# FLOW: resolve_spring_mapping_name
# WHY: Prove a familiar spelling denotes Spring's genuine annotation.
# IN/OUT: Source/name/import/shadow context -> canonical name or None.
# CALL FLOW: decode_spring_mapping calls it; only proven names reach value decoding.
# EXAMPLE: A local `@interface GetMapping` makes bare `@GetMapping` fail closed.
# Purpose/why: prove a familiar mapping spelling denotes the genuine Spring package at its exact use site.
# Input/output: source/name/import/shadow context in, canonical simple name or None out; feeds direct mapping decoding.
def resolve_spring_mapping_name(
    source,
    annotation_name_node,
    imports,
    local_annotations,
    unit=None,
):
# Familiar spelling is only a candidate.  This resolver proves that, at the
# annotation use site, it denotes the expected Spring package and is not
# shadowed by a local/source type or competing wildcard import.  Thus a user
# annotation also named ``GetMapping`` cannot invent a Spring endpoint.
    spelling = node_text(source, annotation_name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in SPRING_MAPPING_METHODS:
        return None

    expected = f"{SPRING_MAPPING_PACKAGE}.{simple_name}"
    if "." in spelling:
        return simple_name if spelling == expected else None
    if unit is None and simple_name in local_annotations:
        return None
    if unit is not None and simple_name in visible_local_type_names(
        unit, annotation_name_node
    ):
        return None

    explicit = imports["exact"].get(simple_name)
    if explicit is not None:
        return simple_name if explicit == expected else None
    if unit is not None and simple_name in unit.get("package_types", set()):
        return None
    if SPRING_MAPPING_PACKAGE in imports["wildcards"]:
        wildcard_sources = (
            unit.get("wildcard_source_types", {}).get(simple_name, set())
            if unit is not None
            else set()
        )
        if wildcard_sources - {expected}:
            return None
        return simple_name
    return None


# FLOW: decode_java_string_literal
# WHY: Decode bounded ordinary Java String escapes without evaluating code.
# IN/OUT: Quoted literal spelling -> decoded string or None.
# CALL FLOW: Expression resolvers call it; path/alias decoders consume output.
# EXAMPLE: Malformed escapes and non-ordinary literals return None.
# Purpose/why: decode bounded Java String escapes without evaluating arbitrary Java expressions.
# Input/output: quoted literal spelling in, decoded String or None out; upstream AST values, downstream path/token resolver.
def decode_java_string_literal(literal):
    """Decode the bounded escape forms valid in an ordinary Java string."""
    if len(literal) < 2 or not (literal.startswith('"') and literal.endswith('"')):
        return None

    result = []
    index = 1
    end = len(literal) - 1
    simple_escapes = {
        "b": "\b",
        "t": "\t",
        "n": "\n",
        "f": "\f",
        "r": "\r",
        "s": " ",
        '"': '"',
        "'": "'",
        "\\": "\\",
    }
    while index < end:
        char = literal[index]
        if char != "\\":
            result.append(char)
            index += 1
            continue

        index += 1
        if index >= end:
            return None
        escaped = literal[index]
        if escaped in simple_escapes:
            result.append(simple_escapes[escaped])
            index += 1
            continue
        if escaped == "u":
            while index < end and literal[index] == "u":
                index += 1
            digits = literal[index:index + 4]
            if len(digits) != 4 or not re.fullmatch(r"[0-9a-fA-F]{4}", digits):
                return None
            result.append(chr(int(digits, 16)))
            index += 4
            continue
        if escaped in "01234567":
            max_digits = 3 if escaped in "0123" else 2
            digits = escaped
            index += 1
            while index < end and len(digits) < max_digits and literal[index] in "01234567":
                digits += literal[index]
                index += 1
            result.append(chr(int(digits, 8)))
            continue
        return None

    try:
        value = (
            "".join(result)
            .encode("utf-16-le", errors="surrogatepass")
            .decode("utf-16-le")
        )
    except UnicodeDecodeError:
        return None
    return value if len(value) <= SPRING_MAX_CONSTANT_LENGTH else None


# ---------------------------------------------------------------------------
# 4. Bounded Java String and route-value resolution
# ---------------------------------------------------------------------------
#
# The same-file index is a fast/local representation.  When a workspace is
# available, ``resolve_java_string_expression`` delegates to the stricter
# root-wide resolver below.  Supported expression graphs are deliberately
# small: literals, parentheses, ``+`` concatenation, and unambiguous constant
# references.  Calls, allocation, mutable fields, environment lookup, and
# arbitrary Java evaluation are not guessed.
#
# Example:
#
#   // Paths.java
#   public final class Paths {
#       public static final String API = "/api";
#   }
#   // Controller.java
#   import static example.Paths.API;
#   @GetMapping(API + "/users")
#
# resolves to ``/api/users``.  If two accessible wildcard-static imports both
# declare ``API``, identity is ambiguous and the route is skipped.  Eligibility
# never repairs ambiguity after Java name lookup.

# FLOW: build_same_file_constant_index
# WHY: Index same-file String candidates with owner/initializer facts.
# IN/OUT: Source, fields, type infos -> constant candidate index.
# CALL FLOW: Standalone Spring analysis calls it; local expression resolution consumes it.
# EXAMPLE: Duplicate names remain ambiguous instead of scan-order selected.
# Purpose/why: retain local String initializer nodes as a fallback when no root-wide workspace is supplied.
# Input/output: source/field/type facts in, qualified-member index out; feeds same-file String expression resolution.
def build_same_file_constant_index(source, field_matches, type_infos):
    by_qualified = {}
    for _pattern_index, captures in field_matches:
        type_node = first_capture(captures, "constant.type")
        name_node = first_capture(captures, "constant.name")
        value_node = first_capture(captures, "constant.value")
        field_node = first_capture(captures, "constant.field")
        if None in (type_node, name_node, value_node, field_node):
            continue
        field_type = node_text(source, type_node).strip()
        if field_type not in {"String", "java.lang.String"}:
            continue
        owner_node = nearest_enclosing_type(field_node)
        owner_info = type_infos.get(tree_node_key(owner_node)) if owner_node is not None else None
        owner_name = owner_info["display_name"] if owner_info is not None else ""
        name = node_text(source, name_node)
        record = {
            "id": (field_node.start_byte, name_node.start_byte),
            "name": name,
            "owner": owner_name,
            "value_node": value_node,
        }
        if owner_name:
            by_qualified.setdefault(f"{owner_name}.{name}", []).append(record)
            by_qualified.setdefault(f"{owner_name.rsplit('.', 1)[-1]}.{name}", []).append(record)
    return {"by_qualified": by_qualified}


# FLOW: constant_candidates
# WHY: Apply lexical owner/qualification rules to local constants.
# IN/OUT: Reference, owner, index -> candidate records.
# CALL FLOW: resolve_spring_string_expression calls it; unique candidates recurse.
# Purpose/why: resolve a local bare/qualified constant reference by lexical owner tiers and reject multiplicity.
# Input/output: spelling/owner/index in, candidate records out; upstream expression decoder, downstream recursive resolution.
def constant_candidates(reference, owner_name, constant_index):
    reference = reference.strip()
    if reference.startswith("this."):
        reference = reference[5:]

    candidates = []
    if "." not in reference:
        owner_parts = owner_name.split(".") if owner_name else []
        while owner_parts:
            qualified = f"{'.'.join(owner_parts)}.{reference}"
            current = constant_index["by_qualified"].get(qualified, [])
            if current:
                candidates.extend(current)
                break
            owner_parts.pop()
    else:
        candidates.extend(constant_index["by_qualified"].get(reference, []))

    unique = {record["id"]: record for record in candidates}
    return list(unique.values())


# FLOW: binary_expression_is_addition
# WHY: Distinguish concatenation from other binary operators.
# IN/OUT: Binary expression -> Boolean for `+`.
# CALL FLOW: String resolvers call it before decoding operands.
# Purpose/why: distinguish String concatenation from other binary operators across grammar binding variants.
# Input/output: source/binary/operand nodes in, Boolean out; gates both local and workspace recursive evaluators.
def binary_expression_is_addition(source, node, left, right):
    operator = child_by_field(node, "operator")
    if operator is not None:
        return node_text(source, operator).strip() == "+"
    return any(child.type == "+" for child in node.children) or (
        source[left.end_byte:right.start_byte].decode("utf8").strip() == "+"
    )


# FLOW: resolve_spring_string_expression
# WHY: Resolve bounded local literal/concatenation/constant graphs safely.
# IN/OUT: Expression context and recursion state -> string or None.
# CALL FLOW: resolve_java_string_expression dispatches here; annotation decoders consume output.
# EXAMPLE: `BASE + "/items"` requires one accessible, acyclic BASE initializer.
# Purpose/why: recursively evaluate the bounded same-file literal/parenthesis/plus/constant subset with cycle guards.
# Input/output: source AST/index/owner/state in, String or None out; fallback upstream, mapping path decoder downstream.
def resolve_spring_string_expression(
    source,
    expression_node,
    constant_index,
    owner_name,
    stack=(),
    depth=0,
):
# ``stack`` guards reference cycles and ``depth``/length bounds prevent a
# hostile or accidental declaration graph from expanding without limit.
    if expression_node is None or depth > SPRING_MAX_CONSTANT_DEPTH:
        return None

    node_type = expression_node.type
    if node_type == "string_literal":
        return decode_java_string_literal(node_text(source, expression_node))
    if node_type == "parenthesized_expression":
        children = expression_node.named_children
        if len(children) != 1:
            return None
        return resolve_spring_string_expression(
            source, children[0], constant_index, owner_name, stack, depth + 1
        )
    if node_type == "binary_expression":
        left = child_by_field(expression_node, "left")
        right = child_by_field(expression_node, "right")
        if left is None or right is None or not binary_expression_is_addition(source, expression_node, left, right):
            return None
        left_value = resolve_spring_string_expression(
            source, left, constant_index, owner_name, stack, depth + 1
        )
        right_value = resolve_spring_string_expression(
            source, right, constant_index, owner_name, stack, depth + 1
        )
        if left_value is None or right_value is None:
            return None
        value = left_value + right_value
        return value if len(value) <= SPRING_MAX_CONSTANT_LENGTH else None
    if node_type in {"identifier", "field_access", "scoped_identifier"}:
        reference = node_text(source, expression_node)
        candidates = constant_candidates(reference, owner_name, constant_index)
        if len(candidates) != 1:
            return None
        constant = candidates[0]
        if constant["id"] in stack:
            return None
        return resolve_spring_string_expression(
            source,
            constant["value_node"],
            constant_index,
            constant["owner"],
            stack + (constant["id"],),
            depth + 1,
        )
    return None


# FLOW: resolve_java_string_expression
# WHY: Select workspace-aware or same-file String resolution.
# IN/OUT: Expression plus local/workspace context -> string or None.
# CALL FLOW: Path/alias decoders call it; selected resolver supplies one atomic value.
# Purpose/why: choose workspace-aware resolution when possible while preserving standalone same-file semantics.
# Input/output: expression plus local/workspace context in, resolved String or None out; central path-value dispatcher.
def resolve_java_string_expression(
    source,
    expression_node,
    constant_index,
    owner_name,
    unit=None,
    workspace=None,
):
    """Resolve a bounded Java String expression in its declaration source."""
    if unit is not None and workspace is not None:
        return resolve_workspace_string_expression(
            unit, expression_node, workspace, owner_name
        )
    return resolve_spring_string_expression(
        source, expression_node, constant_index, owner_name
    )


# FLOW: normalize_spring_path
# WHY: Give nonempty Spring path layers one leading slash.
# IN/OUT: Decoded path -> normalized layer.
# CALL FLOW: Spring path decoders call it; combine_paths later composes layers.
# Purpose/why: give nonempty annotation path layers one leading slash without final whole-path normalization.
# Input/output: decoded path in, normalized layer out; upstream annotation values, downstream path composition.
def normalize_spring_path(path):
    if not path:
        return ""
    return path if path.startswith("/") else f"/{path}"


# FLOW: annotation_value_nodes
# WHY: Unify scalar/array annotation values and omit comment trivia.
# IN/OUT: Value node -> ordered value-node list.
# CALL FLOW: Path/verb/retention/alias decoders call it.
# Purpose/why: normalize scalar versus array annotation values and discard comment trivia uniformly.
# Input/output: value AST node in, ordered value-node list out; feeds path, verb and alias fan-out decoders.
def annotation_value_nodes(value_node):
    if value_node.type == "element_value_array_initializer":
        return [
            child
            for child in value_node.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
    return [value_node]


# FLOW: get_spring_annotation_paths
# WHY: Decode positional/value/path aliases atomically with array fan-out.
# IN/OUT: Annotation and resolution context -> values/unresolved/present fact.
# CALL FLOW: decode_spring_mapping calls it; routes or diagnostics consume the fact.
# EXAMPLE: Conflicting explicit `value` and `path` invalidates the mapping.
# Purpose/why: decode Spring positional/value/path aliases atomically and fan out arrays only when all values resolve.
# Input/output: annotation plus resolution context in, values/unresolved/present fact out; feeds decode_spring_mapping.
def get_spring_annotation_paths(
    source,
    annotation_node,
    constant_index,
    owner_name,
    unit=None,
    workspace=None,
):
# Spring declares ``value`` and ``path`` as aliases.  Positional syntax means
# ``value``; if both explicit aliases occur they must decode to identical
# ordered value sets.  Arrays fan out.  Missing path is represented by one
# empty segment, while an explicit unresolved path invalidates the mapping.
    positional, named = get_annotation_arguments(annotation_node)
    if len(positional) > 1 or (positional and "value" in named):
        return {
            "values": [],
            "unresolved": ["invalid positional/value alias declaration"],
            "present": True,
        }

    explicit_nodes = []
    if positional:
        explicit_nodes.append(("value", positional[0]))
    for attribute in ("value", "path"):
        if attribute in named:
            explicit_nodes.append((attribute, named[attribute]))
    if not explicit_nodes:
        return {"values": [""], "unresolved": [], "present": False}

    resolved_aliases = []
    unresolved = []
    for attribute, explicit_node in explicit_nodes:
        current_values = []
        value_nodes = annotation_value_nodes(explicit_node)
        if not value_nodes:
            current_values.append("")
        for value_node in value_nodes:
            value = resolve_java_string_expression(
                source,
                value_node,
                constant_index,
                owner_name,
                unit=unit,
                workspace=workspace,
            )
            if value is None:
                unresolved.append(node_text(source, value_node).strip())
            else:
                current_values.append(value)
        resolved_aliases.append((attribute, tuple(current_values)))

    if unresolved:
        return {"values": [], "unresolved": unresolved, "present": True}
    if len({values for _attribute, values in resolved_aliases}) != 1:
        return {
            "values": [],
            "unresolved": ["conflicting explicit path/value aliases"],
            "present": True,
        }
    raw_values = resolved_aliases[0][1]
    return {
        "values": list(
            dict.fromkeys(normalize_spring_path(value) for value in raw_values)
        ) or [""],
        "unresolved": [],
        "present": True,
    }


# FLOW: unwrap_parenthesized_node
# WHY: Remove only structurally simple redundant parentheses.
# IN/OUT: Expression -> inner node or None.
# CALL FLOW: Enum/type identity resolvers call it before provenance checks.
# Purpose/why: remove bounded redundant parentheses before identity-sensitive enum/type inspection.
# Input/output: expression node in, inner node or None out; upstream annotation values, downstream method/target resolvers.
def unwrap_parenthesized_node(node):
    current = node
    while current is not None and current.type == "parenthesized_expression":
        children = current.named_children
        if len(children) != 1:
            return None
        current = children[0]
    return current


# FLOW: owner_name_for_node
# WHY: Map a use site to its lexical display owner.
# IN/OUT: Unit/context -> owner display name or None.
# CALL FLOW: Member/constant resolvers call it; access checks consume the name.
# Purpose/why: map a use-site node back to its lexical display owner for access and shadow checks.
# Input/output: unit/context in, owner display name or None out; feeds static import accessibility.
def owner_name_for_node(unit, context_node):
    owner_node = nearest_enclosing_type(context_node) if context_node is not None else None
    owner_info = (
        unit.get("type_infos", {}).get(tree_node_key(owner_node))
        if owner_node is not None
        else None
    )
    return owner_info["display_name"] if owner_info is not None else None


# FLOW: static_member_resolves_to
# WHY: Prove a bare static member has one expected owner.
# IN/OUT: Unit/member/owner/context -> Boolean.
# CALL FLOW: Verb/retention resolvers call it; identity decoding consumes the verdict.
# EXAMPLE: A competing wildcard exposing the member makes it unresolved.
# Purpose/why: prove a bare static member comes from one expected owner rather than a competing wildcard source.
# Input/output: unit/member/expected owner/use site in, Boolean out; feeds enum and retention provenance.
def static_member_resolves_to(
    unit, member_name, expected_owner, context_node=None
):
    imports = unit["imports"]
    if member_name in imports["static_exact"]:
        return (
            imports["static_exact"][member_name]
            == f"{expected_owner}.{member_name}"
        )
    if expected_owner not in imports["static_wildcards"]:
        return False
    declarations = unit.get("workspace_static_member_declarations", {})
    consumer_owner_name = owner_name_for_node(unit, context_node)
    return not any(
        owner != expected_owner
        and any(
            workspace_static_member_declaration_accessible(
                record, unit, consumer_owner_name
            )
            for record in declarations.get((owner, member_name), [])
        )
        for owner in imports["static_wildcards"]
    )


# FLOW: resolve_spring_request_method_expression
# WHY: Resolve one verb to genuine Spring RequestMethod identity.
# IN/OUT: Source/value/import/unit -> HTTP verb or None.
# CALL FLOW: Method and alias decoders call it; method sets consume output.
# EXAMPLE: Bare GET needs proven static provenance; another enum's GET is rejected.
# Purpose/why: resolve a scalar verb to genuine Spring RequestMethod identity, never by token spelling alone.
# Input/output: source/value/import/unit in, HTTP method or None out; feeds generic mapping/alias method arrays.
def resolve_spring_request_method_expression(
    source,
    value_node,
    imports,
    unit=None,
):
# A verb spelling must resolve to the genuine Spring ``RequestMethod`` enum,
# including exact/static/wildcard import forms.  Merely seeing an identifier
# named GET is insufficient evidence.
    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = node_text(source, current).strip()
    method_name = spelling.rsplit(".", 1)[-1]
    if method_name not in SPRING_HTTP_METHODS:
        return None
    expected_owner = f"{SPRING_MAPPING_PACKAGE}.RequestMethod"
    if "." not in spelling:
        if unit is not None:
            return (
                method_name
                if static_member_resolves_to(
                    unit, method_name, expected_owner, current
                )
                else None
            )
        imported = imports["static_exact"].get(method_name)
        if imported is not None:
            return method_name if imported == f"{expected_owner}.{method_name}" else None
        return method_name if expected_owner in imports["static_wildcards"] else None

    qualifier = spelling.rsplit(".", 1)[0]
    if unit is not None:
        return (
            method_name
            if resolve_known_type(
                unit,
                qualifier,
                "RequestMethod",
                (SPRING_MAPPING_PACKAGE,),
                current,
            )
            == SPRING_MAPPING_PACKAGE
            else None
        )
    if qualifier == expected_owner:
        return method_name
    if qualifier != "RequestMethod":
        return None
    explicit = imports["exact"].get("RequestMethod")
    if explicit is not None:
        return method_name if explicit == expected_owner else None
    return (
        method_name
        if SPRING_MAPPING_PACKAGE in imports["wildcards"]
        else None
    )


# FLOW: get_spring_request_methods
# WHY: Decode scalar/array RequestMapping method evidence fail-closed.
# IN/OUT: Annotation/import context -> values/unresolved/present fact.
# CALL FLOW: decode_spring_mapping calls it; validity and verb fan-out consume it.
# EXAMPLE: An array yields verbs only for identities that resolve.
# Purpose/why: decode RequestMapping.method scalar/array evidence and retain unresolved expressions for fail-closed policy.
# Input/output: annotation/import context in, values/unresolved/present fact out; feeds decode_spring_mapping.
def get_spring_request_methods(
    source,
    annotation_node,
    imports,
    unit=None,
):
    _positional, named = get_annotation_arguments(annotation_node)
    method_node = named.get("method")
    if method_node is None:
        return {"values": [], "unresolved": [], "present": False}

    value_nodes = annotation_value_nodes(method_node)
    if not value_nodes:
        return {"values": [], "unresolved": [], "present": True}

    methods = []
    unresolved = []
    for value_node in value_nodes:
        expression = node_text(source, value_node).strip()
        method_name = resolve_spring_request_method_expression(
            source, value_node, imports, unit=unit
        )
        if method_name is not None:
            methods.append(method_name)
        else:
            unresolved.append(expression)
    return {"values": ordered_http_methods(methods), "unresolved": unresolved, "present": True}


# FLOW: ordered_http_methods
# WHY: Canonicalize verbs to deterministic framework order.
# IN/OUT: Verb iterable -> ordered unique list.
# CALL FLOW: Method/alias composition calls it; facts/output receive stable ordering.
# Purpose/why: canonicalize method sets to the declared framework order for deterministic facts/output.
# Input/output: method iterable in, de-duplicated ordered list out; used by mapping and alias composition.
def ordered_http_methods(methods):
    method_set = set(methods)
    return [method for method in SPRING_HTTP_METHODS if method in method_set]


# FLOW: combine_request_method_conditions
# WHY: Combine type and method verb layers consistently.
# IN/OUT: Two verb lists -> effective ordered verbs.
# CALL FLOW: Type/method route composition calls it; endpoint fan-out consumes output.
# Purpose/why: apply the analyzer's bounded type/method verb-layer combination consistently.
# Input/output: two method lists in, canonical effective list out; upstream decoded mappings, downstream endpoint fan-out.
def combine_request_method_conditions(class_methods, method_methods):
# This preserves the analyzer's documented class/method method-set behavior.
# Path layers are cross-producted separately by ``compose_type_mapping`` and
# the direct analyzer.
    if not class_methods:
        return list(method_methods)
    if not method_methods:
        return list(class_methods)
    return ordered_http_methods([*class_methods, *method_methods])


# FLOW: log_unresolved_mapping
# WHY: Emit one auditable diagnostic per unresolved path/verb.
# IN/OUT: File/owner/mapping/kind/expressions -> log side effects.
# CALL FLOW: decode_spring_mapping calls it; write_log emits diagnostics.
# Purpose/why: make every skipped Spring path/verb expression auditable without manufacturing partial identity.
# Input/output: source/owner/mapping/kind/expressions in, diagnostic side effect out; called by mapping decoder.
def log_unresolved_mapping(fname, owner_name, mapping_name, value_kind, expressions):
    for expression in expressions:
        write_log(
            f"Skipped unresolved Spring {value_kind} in {fname} "
            f"for {owner_name} @{mapping_name}: {expression}"
        )


# FLOW: decode_spring_mapping
# WHY: Decode one proven built-in mapping into an atomic route fact.
# IN/OUT: Annotation plus Java context -> mapping fact or None.
# CALL FLOW: first_spring_mapping calls it; route selection consumes paths/methods/validity.
# EXAMPLE: Shortcuts provide fixed verbs; unconstrained RequestMapping stays method-empty.
# Purpose/why: convert one proven built-in mapping annotation into path/method/validity declaration facts.
# Input/output: captured annotation and Java context in, mapping fact or None out; upstream query, downstream selection.
def decode_spring_mapping(
    fname,
    source,
    annotation_name_node,
    annotation_node,
    imports,
    local_annotations,
    constant_index,
    lexical_owner_name,
    diagnostic_owner_name=None,
    unit=None,
    workspace=None,
):
# Decoding produces a small route-declaration fact, not a CSV row.  A shortcut
# annotation supplies its fixed verb; generic RequestMapping decodes its
# explicit method array and later becomes ANY when unconstrained.
    mapping_name = resolve_spring_mapping_name(
        source, annotation_name_node, imports, local_annotations, unit=unit
    )
    if mapping_name is None:
        return None

    paths = get_spring_annotation_paths(
        source,
        annotation_node,
        constant_index,
        lexical_owner_name,
        unit=unit,
        workspace=workspace,
    )
    diagnostic_owner_name = diagnostic_owner_name or lexical_owner_name
    if paths["unresolved"]:
        log_unresolved_mapping(
            fname,
            diagnostic_owner_name,
            mapping_name,
            "path",
            paths["unresolved"],
        )

    if mapping_name == "RequestMapping":
        methods = get_spring_request_methods(
            source, annotation_node, imports, unit=unit
        )
        if methods["unresolved"]:
            log_unresolved_mapping(
                fname,
                diagnostic_owner_name,
                mapping_name,
                "method",
                methods["unresolved"],
            )
    else:
        methods = {
            "values": [SPRING_MAPPING_METHODS[mapping_name]],
            "unresolved": [],
            "present": False,
        }

    valid = bool(paths["values"]) and not (
        methods["present"] and methods["unresolved"] and not methods["values"]
    )
    return {
        "name": mapping_name,
        "paths": paths["values"],
        "methods": methods["values"],
        "valid": valid,
        "annotation_node": annotation_node,
    }


# FLOW: first_spring_mapping
# WHY: Select the first recognized built-in/composed mapping in source order.
# IN/OUT: Candidates and resolution context -> mapping fact or None.
# CALL FLOW: Spring type/method passes call it; chosen declaration feeds composition.
# EXAMPLE: Each use is tried as built-in then composed; later mappings are not merged.
# Purpose/why: enforce conservative source-order ownership across built-in and source-composed mapping uses.
# Input/output: candidate matches/context in, first mapping fact or None out; feeds type and method analyzers.
def first_spring_mapping(
    fname,
    source,
    candidates,
    imports,
    local_annotations,
    constant_index,
    lexical_owner_name,
    diagnostic_owner_name=None,
    unit=None,
    workspace=None,
):
# Java source order is significant for this conservative policy.  Each use is
# tried first as a genuine built-in mapping, then as a source-defined composed
# mapping.  The first recognized mapping owns the declaration; later mapping
# annotations are not merged or emitted as additional handlers.
    for captures in sorted(
        candidates,
        key=lambda item: first_capture(item, "annotation.node").start_byte,
    ):
        mapping = decode_spring_mapping(
            fname,
            source,
            first_capture(captures, "annotation.name"),
            first_capture(captures, "annotation.node"),
            imports,
            local_annotations,
            constant_index,
            lexical_owner_name,
            diagnostic_owner_name,
            unit,
            workspace,
        )
        if mapping is not None:
            return mapping
        if unit is not None and workspace is not None:
            composed = decode_spring_composed_mapping(
                fname,
                unit,
                first_capture(captures, "annotation.name"),
                first_capture(captures, "annotation.node"),
                lexical_owner_name,
                diagnostic_owner_name or lexical_owner_name,
                workspace,
            )
            if composed is not None:
                return composed
    return None


# FLOW: type_chain
# WHY: Reconstruct lexical type layers outermost to innermost.
# IN/OUT: Type key/index -> ordered type-info list.
# CALL FLOW: compose_type_mapping/access logic calls it; layer composition consumes it.
# Purpose/why: reconstruct a declaration's lexical outer-to-inner type layers for names, access and paths.
# Input/output: type key/index in, ordered type-info chain out; feeds mapping composition and workspace access.
def type_chain(type_key, type_infos):
    chain = []
    current_key = type_key
    while current_key is not None and current_key in type_infos:
        info = type_infos[current_key]
        chain.append(info)
        current_key = info["outer_key"]
    return list(reversed(chain))


# FLOW: compose_type_mapping
# WHY: Cross-product valid lexical type paths and verb evidence.
# IN/OUT: Type key/index -> paths/methods fact or None.
# CALL FLOW: SpringBoot_Analyzer calls it; method route creation consumes output.
# EXAMPLE: Any invalid recognized layer fails the chain atomically.
# Purpose/why: cross-product every valid lexical type path and combine type-level verb evidence atomically.
# Input/output: type key/index in, paths/methods fact or None out; upstream type mappings, downstream direct Spring rows.
def compose_type_mapping(type_key, type_infos):
# Begin with the identity path, walk lexical owner layers outer-to-inner, and
# form the Cartesian product of path arrays.  Invalid recognized type mapping
# evidence fails the whole type chain instead of dropping an unresolved prefix.
    paths = [""]
    methods = []
    for info in type_chain(type_key, type_infos):
        mapping = info["mapping"]
        if mapping is None:
            continue
        if not mapping["valid"]:
            return None
        paths = [
            combine_paths(base_path, current_path)
            for base_path in paths
            for current_path in mapping["paths"]
        ]
        methods = combine_request_method_conditions(methods, mapping["methods"])
    return {"paths": list(dict.fromkeys(paths)), "methods": methods}


# FLOW: SpringBoot_Analyzer
# WHY: Orchestrate direct Spring extraction for one Java unit.
# IN/OUT: File/content/runtime/workspace -> endpoint fact list.
# CALL FLOW: analyze_module calls it; additions/config/output consume returned facts.
# EXAMPLE: See the nearby direct Spring 2 x 2 x 2 route worked example.
# Purpose/why: identify direct annotated Spring class/record methods and method-applicable implicit record accessors.
# Input/output: one source plus optional runtime/workspace in, endpoint fact list out; upstream host, downstream additions/config.
def SpringBoot_Analyzer(fname, fcontent=None, runtime=None, workspace=None):
    """Extract supported Spring MVC annotation routes from one Java source."""
    fname = str(fname)
    runtime = runtime or build_spring_runtime()
    if isinstance(fcontent, bytes):
        source = fcontent
    elif isinstance(fcontent, str):
        source = fcontent.encode("utf8")
    else:
        with open(fname, "rb") as source_file:
            source = source_file.read()

    write_log(f"{fname}:")
    tree = runtime["parser"].parse(source)
    root = tree.root_node
    query_lifetime_owners = [tree]
    matches = {
        name: run_query_matches(query, root, query_lifetime_owners)
        for name, query in runtime["queries"].items()
    }
    type_infos = build_type_infos(source, matches["type"])
    imports = parse_java_imports(source, matches["import"])
    local_annotations = declared_annotation_names(
        source, matches["annotation_declaration"]
    )
    constant_index = build_same_file_constant_index(
        source, matches["field"], type_infos
    )

# Direct Spring example:
#
#   @RequestMapping(path={"/v1", "/v2"})
#   class Catalog {
#       @RequestMapping(path={"/items", "/products"},
#                       method={RequestMethod.GET, RequestMethod.POST})
#       Object list(String filter) { ... }
#   }
#
# After genuine annotation/enum provenance and value resolution, the loops
# below emit 2 class paths x 2 method paths x 2 verbs = 8 endpoint facts.  Each
# fact keeps the concrete ``Catalog.list`` attribution and raw ``String
# filter`` formal text.  Configuration and final path normalization happen
# later, after all Spring route families have contributed facts.
    workspace_unit = (
        workspace.get("units", {}).get(fname)
        if workspace is not None
        else None
    )

    type_candidates = {}
    for _pattern_index, captures in matches["type_annotation"]:
        type_node = first_capture(captures, "type.node")
        if type_node is not None:
            type_candidates.setdefault(tree_node_key(type_node), []).append(captures)

    for type_key, info in type_infos.items():
        info["mapping"] = first_spring_mapping(
            fname,
            source,
            type_candidates.get(type_key, []),
            imports,
            local_annotations,
            constant_index,
            info["display_name"],
            unit=workspace_unit,
            workspace=workspace,
        )

    method_candidates = {}
    for _pattern_index, captures in matches["method_annotation"]:
        method_node = first_capture(captures, "method.node")
        if method_node is not None:
            method_candidates.setdefault(tree_node_key(method_node), []).append(captures)
    record_component_candidates = group_query_captures(
        matches["record_component_annotation"], "component.node"
    )
    record_explicit_accessors = record_explicit_zero_parameter_accessors(
        source, matches["record_method"]
    )

    endpoints = []
# ``method_candidates`` joins all annotation matches for the same actual
# method node.  Type facts supply lexical path layers; method facts supply the
# final layer and handler evidence.  This separation prevents a similarly
# named method elsewhere in the file from borrowing the annotation.
    for method_key in sorted(method_candidates):
        candidates = method_candidates[method_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        method_name_node = first_capture(representative, "method.name")
        parameters_node = first_capture(representative, "method.parameters")
        if None in (type_node, method_name_node, parameters_node):
            continue

        owner_key = tree_node_key(type_node)
        owner_info = type_infos.get(owner_key)
        if (
            owner_info is None
            or owner_info["abstract"]
            or not owner_info["workspace_visible"]
        ):
            continue
        method_name = node_text(source, method_name_node)
        owner_name = f"{owner_info['display_name']}.{method_name}"
        mapping = first_spring_mapping(
            fname,
            source,
            candidates,
            imports,
            local_annotations,
            constant_index,
            owner_info["display_name"],
            owner_name,
            workspace_unit,
            workspace,
        )
        if mapping is None or not mapping["valid"]:
            continue

        type_mapping = compose_type_mapping(owner_key, type_infos)
        if type_mapping is None:
            continue
        effective_methods = combine_request_method_conditions(
            type_mapping["methods"], mapping["methods"]
        ) or ["ANY"]
        parameters = get_callable_parameters_as_is(source, parameters_node)
        line = mapping["annotation_node"].start_point.row + 1

        for base_path in type_mapping["paths"]:
            for method_path in mapping["paths"]:
                uri = combine_paths(base_path, method_path)
                for http_method in effective_methods:
                    endpoint = {
                        "uri": uri,
                        "method": http_method,
                        "uri_params": parameters,
                        "SrcFile": fname,
                        "SrcLine": line,
                        "SFunction": owner_name,
                    }
                    endpoints.append(endpoint)
                    debug_log(endpoint)

    for component_key in sorted(record_component_candidates):
# Java copies a record-component annotation to the implicit accessor only when
# that annotation is applicable to METHOD.  For example, a genuine mapping on
# ``record Lookup(@GetMapping("/current") String current)`` can describe the
# implicit ``Lookup.current()`` route.  A source-declared zero-argument
# ``current()`` suppresses synthesis because Java then has no implicit accessor
# to receive the propagated annotation.
        candidates = record_component_candidates[component_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        component_name_node = first_capture(representative, "component.name")
        if type_node is None or component_name_node is None:
            continue

        owner_key = tree_node_key(type_node)
        owner_info = type_infos.get(owner_key)
        if (
            owner_info is None
            or owner_info["abstract"]
            or not owner_info["workspace_visible"]
        ):
            continue
        component_name = node_text(source, component_name_node)
        if (owner_key, component_name) in record_explicit_accessors:
            continue

        owner_name = f"{owner_info['display_name']}.{component_name}"
        applicable_candidates = spring_method_applicable_component_candidates(
            source,
            candidates,
            imports,
            local_annotations,
            workspace_unit,
            workspace,
            owner_info["display_name"],
        )
        mapping = first_spring_mapping(
            fname,
            source,
            applicable_candidates,
            imports,
            local_annotations,
            constant_index,
            owner_info["display_name"],
            owner_name,
            workspace_unit,
            workspace,
        )
        if mapping is None or not mapping["valid"]:
            continue

        type_mapping = compose_type_mapping(owner_key, type_infos)
        if type_mapping is None:
            continue
        effective_methods = combine_request_method_conditions(
            type_mapping["methods"], mapping["methods"]
        ) or ["ANY"]
        line = mapping["annotation_node"].start_point.row + 1

        for base_path in type_mapping["paths"]:
            for method_path in mapping["paths"]:
                uri = combine_paths(base_path, method_path)
                for http_method in effective_methods:
                    endpoint = {
                        "uri": uri,
                        "method": http_method,
                        "uri_params": "",
                        "SrcFile": fname,
                        "SrcLine": line,
                        "SFunction": owner_name,
                    }
                    endpoints.append(endpoint)
                    debug_log(endpoint)

    return endpoints

# ---------------------------------------------------------------------------
# 5. Source units, annotation provenance, and workspace identity
# ---------------------------------------------------------------------------
#
# A unit owns one immutable source byte string, syntax tree, match inventory,
# import/package data, lexical types, and grouped route candidates.  A
# workspace joins all units by Java identities before any cross-file value,
# annotation, hierarchy, or application association is attempted.

# FLOW: java_source_bytes
# WHY: Normalize caller-supplied or on-disk Java source to parser bytes.
# IN/OUT: File path and optional bytes/string content -> source bytes.
# CALL FLOW: analyze_module/workspace builders call it; parsers and byte-span decoders consume output.
def java_source_bytes(fname, fcontent=None):
    if isinstance(fcontent, bytes):
        return fcontent
    if isinstance(fcontent, str):
        return fcontent.encode("utf8")
    with open(fname, "rb") as source_file:
        return source_file.read()


# FLOW: java_package_name
# WHY: Decode a unique package declaration without guessing on conflicting captures.
# IN/OUT: Source and package-query matches -> package string or empty string.
# CALL FLOW: build_jax_unit calls it; FQN, access, import, and application logic consume the package.
# EXAMPLE: A default-package unit has no match and returns the empty package identity.
def java_package_name(source, package_matches):
    names = []
    for _pattern_index, captures in package_matches:
        name_node = first_capture(captures, "package.name")
        if name_node is not None:
            names.append(node_text(source, name_node).strip())
    return names[0] if len(set(names)) == 1 else ""


# FLOW: group_query_captures
# WHY: Join multiple annotation matches to their one captured declaration node.
# IN/OUT: Match sequence and declaration capture name -> node-keyed capture lists.
# CALL FLOW: Unit/Spring builders call it; route and meta-annotation passes consume groups.
# EXAMPLE: Two annotations on one method remain two captures under one method byte-span key.
def group_query_captures(matches, capture_name):
# Multiple annotations yield multiple matches for one declaration.  Grouping
# by the captured declaration node preserves that many-to-one relationship.
    grouped = {}
    for _pattern_index, captures in matches:
        node = first_capture(captures, capture_name)
        if node is not None:
            grouped.setdefault(tree_node_key(node), []).append(captures)
    return grouped


# FLOW: annotation_records
# WHY: Deduplicate annotation captures while retaining name and node identity.
# IN/OUT: Capture candidates -> source-ordered annotation record list.
# CALL FLOW: Direct/composed route passes call it; identity resolvers consume the records.
def annotation_records(candidates):
    records = {}
    for captures in candidates:
        annotation_node = first_capture(captures, "annotation.node")
        name_node = first_capture(captures, "annotation.name")
        if annotation_node is None or name_node is None:
            continue
        records[tree_node_key(annotation_node)] = {
            "node": annotation_node,
            "name_node": name_node,
        }
    return [records[key] for key in sorted(records)]


# FLOW: record_explicit_zero_parameter_accessors
# WHY: Detect explicit record accessors that suppress Java's implicit accessor.
# IN/OUT: Source and record-method matches -> set of type-key/method-name pairs.
# CALL FLOW: Unit/Spring builders call it; record-component route synthesis checks the set.
# EXAMPLE: `String value()` suppresses component `value`; `value(int)` does not.
def record_explicit_zero_parameter_accessors(source, matches):
    accessors = set()
    for _pattern_index, captures in matches:
        type_node = first_capture(captures, "type.node")
        method_name_node = first_capture(captures, "method.name")
        parameters_node = first_capture(captures, "method.parameters")
        if None in (type_node, method_name_node, parameters_node):
            continue
        if any(
            child.type in {"formal_parameter", "spread_parameter"}
            for child in parameters_node.named_children
        ):
            continue
        accessors.add(
            (tree_node_key(type_node), node_text(source, method_name_node))
        )
    return accessors


# FLOW: build_jax_unit
# WHY: Assemble all immutable per-unit syntax and provenance facts from one Java source.
# IN/OUT: File/source/runtime/optional tree -> unit dictionary.
# CALL FLOW: Workspace or standalone JAX analysis calls it; root-wide and route passes consume the unit.
# EXAMPLE: All named queries run on one tree retained alongside its captured nodes.
def build_jax_unit(fname, source, runtime, parsed_tree=None):
# All compiled queries run over the same tree.  ``lifetime_owners`` retains the
# tree/cursors/match containers for the lifetime of the nodes stored in the
# unit; consumers can safely follow parent links and byte spans later.
    tree = parsed_tree or runtime["parser"].parse(source)
    root = tree.root_node
    lifetime_owners = [tree]
    matches = {
        name: run_query_matches(query, root, lifetime_owners)
        for name, query in runtime["queries"].items()
    }
    type_infos = build_type_infos(source, matches["type"])
    return {
        "fname": fname,
        "source": source,
        "tree": tree,
        "lifetime_owners": lifetime_owners,
        "matches": matches,
        "type_infos": type_infos,
        "imports": parse_java_imports(source, matches["import"]),
        "package": java_package_name(source, matches["package"]),
        "local_annotations": declared_annotation_names(
            source, matches["annotation_declaration"]
        ),
        "local_types": {info["simple_name"] for info in type_infos.values()},
        "constant_index": build_same_file_constant_index(
            source, matches["field"], type_infos
        ),
        "type_candidates": group_query_captures(matches["type_annotation"], "type.node"),
        "method_candidates": group_query_captures(
            matches["method_annotation"], "method.node"
        ),
        "record_component_candidates": group_query_captures(
            matches["record_component_annotation"], "component.node"
        ),
        "record_explicit_accessors": record_explicit_zero_parameter_accessors(
            source, matches["record_method"]
        ),
        "meta_candidates": group_query_captures(
            matches["annotation_meta"], "annotation.declaration.node"
        ),
        "element_candidates": group_query_captures(
            matches["annotation_element"], "annotation.declaration.node"
        ),
    }


# FLOW: resolve_known_source_name
# WHY: Apply bounded Java precedence to prove one allowlisted package identity.
# IN/OUT: Unit, spelling, expected name/packages, shadows -> package or None.
# CALL FLOW: resolve_known_annotation/type call it; framework provenance gates consume the result.
# EXAMPLE: A same-package type or competing wildcard makes a familiar simple name unresolved.
def resolve_known_source_name(unit, spelling, simple_name, packages, local_names):
# This is a provenance resolver, not suffix matching.  It models fully
# qualified spelling, lexical shadowing, exact imports, same-package types and
# wildcard ambiguity to prove that a familiar annotation/type name belongs to
# an allowlisted framework package.
    if spelling.rsplit(".", 1)[-1] != simple_name:
        return None
    if "." in spelling:
        for package in packages:
            if spelling == f"{package}.{simple_name}":
                return package
        return None

    if simple_name in local_names:
        return None
    if simple_name in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][simple_name]
        for package in packages:
            if imported == f"{package}.{simple_name}":
                return package
        return None
    if simple_name in unit.get("package_types", set()):
        return None

    candidates = set()
    if "java.lang" in packages:
        candidates.add("java.lang")
    if unit["package"] in packages:
        candidates.add(unit["package"])
    candidates.update(
        package for package in packages if package in unit["imports"]["wildcards"]
    )
    expected_source_types = {
        f"{package}.{simple_name}" for package in candidates
    }
    if unit.get("wildcard_source_types", {}).get(simple_name, set()) - expected_source_types:
        return None
    return next(iter(candidates)) if len(candidates) == 1 else None


# FLOW: resolve_known_annotation
# WHY: Resolve an annotation use to an allowlisted name and namespace.
# IN/OUT: Unit, name node, expected names/packages -> identity record or None.
# CALL FLOW: Route/meta/application passes call it; decoders consume proven identities.
def resolve_known_annotation(unit, name_node, simple_names, packages):
    spelling = node_text(unit["source"], name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in simple_names:
        return None
    package = resolve_known_source_name(
        unit,
        spelling,
        simple_name,
        packages,
        visible_local_type_names(unit, name_node),
    )
    if package is None:
        return None
    return {"name": simple_name, "namespace": package, "spelling": spelling}


# FLOW: resolve_known_type
# WHY: Resolve a type spelling through shared source-name provenance rules.
# IN/OUT: Unit, spelling, expected name/packages/context -> package or None.
# CALL FLOW: Application, enum, String, AliasFor, and access checks call it.
def resolve_known_type(unit, spelling, simple_name, packages, context_node=None):
    return resolve_known_source_name(
        unit,
        spelling.strip(),
        simple_name,
        packages,
        visible_local_type_names(unit, context_node),
    )


# FLOW: annotation_single_value_node
# WHY: Validate annotation syntax that permits exactly one positional or `value` element.
# IN/OUT: Annotation node -> value node and optional error message.
# CALL FLOW: JAX path, HttpMethod, and Retention decoders call it; scalar resolution consumes valid nodes.
# EXAMPLE: Both positional and named `value` produce an explicit error.
def annotation_single_value_node(annotation_node):
    positional, named = get_annotation_arguments(annotation_node)
    if set(named) - {"value"}:
        return None, "unsupported named attribute"
    if positional and "value" in named:
        return None, "both positional and named values"
    if "value" in named:
        return named["value"], None
    if len(positional) == 1:
        return positional[0], None
    if not positional:
        return None, "missing value"
    return None, "multiple positional values"


# FLOW: log_jax_issue
# WHY: Format conservative JAX-RS skip reasons with source and owner context.
# IN/OUT: File, owner, message, optional expression -> diagnostic side effect.
# CALL FLOW: JAX decoders/resolvers call it; write_log emits the audit trail.
def log_jax_issue(fname, owner_name, message, expression=None):
    suffix = f": {expression}" if expression else ""
    write_log(f"Skipped JAX-RS {message} in {fname} for {owner_name}{suffix}")


# FLOW: decode_jax_path_annotation
# WHY: Decode one genuine JAX Path/ApplicationPath scalar in its lexical workspace context.
# IN/OUT: Unit, annotation record, owners/kind/workspace -> normalized path or None.
# CALL FLOW: Application/resource/method path passes call it; route composition consumes the segment.
# EXAMPLE: Multiple, malformed, or unresolved scalar values fail atomically.
def decode_jax_path_annotation(
    unit,
    record,
    constant_owner,
    diagnostic_owner,
    kind,
    workspace=None,
):
# JAX ``Path``/``ApplicationPath`` accept one scalar String value.  The value
# is resolved in its real lexical/workspace context, normalized to a path
# segment, and rejected atomically when malformed or unresolved.
    value_node, error = annotation_single_value_node(record["node"])
    if error:
        log_jax_issue(unit["fname"], diagnostic_owner, f"invalid {kind}", error)
        return None
    value = resolve_java_string_expression(
        unit["source"],
        value_node,
        unit["constant_index"],
        constant_owner,
        unit=unit,
        workspace=workspace,
    )
    if value is None:
        log_jax_issue(
            unit["fname"],
            diagnostic_owner,
            f"unresolved {kind}",
            node_text(unit["source"], value_node).strip(),
        )
        return None
    return normalize_spring_path(value)


# FLOW: annotation_has_no_values
# WHY: Validate marker-style annotations without accepting unexpected arguments.
# IN/OUT: Annotation node -> Boolean.
# CALL FLOW: JAX verb/root resolution calls it before accepting built-in designators.
def annotation_has_no_values(annotation_node):
    arguments = child_by_field(annotation_node, "arguments")
    return arguments is None or not arguments.named_children


# FLOW: type_directly_extends_jax_application
# WHY: Prove a type's direct superclass is genuine JAX Application.
# IN/OUT: Unit and type info -> JAX namespace or None.
# CALL FLOW: index_jax_applications calls it; deployment-root selection consumes the namespace.
def type_directly_extends_jax_application(unit, type_info):
    superclass = child_by_field(type_info["node"], "superclass")
    if superclass is None or len(superclass.named_children) != 1:
        return None
    spelling = node_text(unit["source"], superclass.named_children[0]).strip()
    core_package = resolve_known_type(
        unit,
        spelling,
        "Application",
        JAX_RS_CORE_PACKAGES,
        superclass.named_children[0],
    )
    return core_package.rsplit(".", 1)[0] if core_package is not None else None


# FLOW: retention_is_runtime
# WHY: Prove a Retention value denotes genuine RetentionPolicy.RUNTIME.
# IN/OUT: Unit and Retention annotation -> Boolean.
# CALL FLOW: Custom JAX/Spring annotation indexes call it; composed/designator eligibility consumes the verdict.
# EXAMPLE: Bare RUNTIME needs genuine static provenance; foreign enum values are rejected.
def retention_is_runtime(unit, annotation_node):
    value_node, error = annotation_single_value_node(annotation_node)
    if error:
        return False
    current = unwrap_parenthesized_node(value_node)
    if current is None:
        return False
    spelling = node_text(unit["source"], current).strip()
    if spelling == "RUNTIME":
        return static_member_resolves_to(
            unit,
            "RUNTIME",
            "java.lang.annotation.RetentionPolicy",
            current,
        )
    if "." not in spelling or spelling.rsplit(".", 1)[-1] != "RUNTIME":
        return False
    qualifier = spelling.rsplit(".", 1)[0]
    return (
        resolve_known_type(
            unit,
            qualifier,
            "RetentionPolicy",
            ("java.lang.annotation",),
            current,
        )
        == "java.lang.annotation"
    )


# FLOW: decode_custom_http_method
# WHY: Validate a source annotation's bounded custom HTTP verb token.
# IN/OUT: Unit, HttpMethod record, owner, workspace -> token or None.
# CALL FLOW: index_jax_custom_designators calls it; method-designator resolution consumes the token.
# EXAMPLE: See the nearby `@HttpMethod("PURGE")` worked example and constraints.
def decode_custom_http_method(unit, annotation_record, owner_name, workspace):
# Example custom designator:
#
#   @Retention(RUNTIME)
#   @HttpMethod("PURGE")
#   public @interface PURGE {}
#
# A resource method annotated ``@PURGE`` emits method PURGE only after the
# annotation declaration, runtime retention, matching Javax/Jakarta namespace,
# bounded String value, and RFC-token character shape all validate.
    value_node, error = annotation_single_value_node(annotation_record["node"])
    if error:
        log_jax_issue(
            unit["fname"], owner_name, "custom @HttpMethod value", error
        )
        return None
    token = resolve_workspace_string_expression(
        unit,
        value_node,
        workspace,
        owner_name,
        known_static_constants=JAX_HTTP_METHOD_STATIC_CONSTANTS,
    )
    if (
        token is None
        or len(token) > 128
        or HTTP_METHOD_TOKEN.fullmatch(token) is None
    ):
        log_jax_issue(
            unit["fname"],
            owner_name,
            "invalid custom @HttpMethod value",
            node_text(unit["source"], value_node).strip(),
        )
        return None
    return token


# FLOW: qualified_type_name
# WHY: Combine package and lexical display name into Java source identity.
# IN/OUT: Unit and type info -> fully qualified name.
# CALL FLOW: Workspace indexes call it; cross-file resolution consumes the identity.
def qualified_type_name(unit, type_info):
    display_name = type_info["display_name"]
    return f"{unit['package']}.{display_name}" if unit["package"] else display_name


# FLOW: declaration_modifier_names
# WHY: Extract access/static/final tokens from one declaration.
# IN/OUT: Declaration node -> modifier-name set.
# CALL FLOW: Workspace type/member access checks call it; Java visibility predicates consume the set.
def declaration_modifier_names(declaration_node):
    modifiers = find_first(declaration_node, "modifiers")
    return {
        child.type
        for child in modifiers.children
        if child.is_named or child.type in {"public", "protected", "private", "static", "final"}
    } if modifiers is not None else set()


# FLOW: workspace_type_accessible
# WHY: Model nested Java type visibility from declaration to consumer.
# IN/OUT: Type record and consumer unit/owner -> Boolean.
# CALL FLOW: Type/name/constant resolvers call it; candidate tiers retain accessible declarations.
# EXAMPLE: A cross-package nested type requires every owner layer to be public.
def workspace_type_accessible(type_record, consumer_unit, consumer_owner_name):
    declaration_unit = type_record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    type_info = type_record["type_info"]
    chain = type_chain(tree_node_key(type_info["node"]), declaration_unit["type_infos"])
    access = []
    for current in chain:
        modifiers = declaration_modifier_names(current["node"])
        outer_node = nearest_enclosing_type(current["node"])
        implicitly_public = bool(
            outer_node is not None
            and outer_node.type
            in {"interface_declaration", "annotation_type_declaration"}
        )
        access.append(
            {
                "public": implicitly_public or "public" in modifiers,
                "private": "private" in modifiers,
            }
        )
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and type_info["display_name"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        return not any(part["private"] for part in access) or same_nest
    if any(part["private"] for part in access):
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return all(part["public"] for part in access)


# FLOW: index_workspace_types
# WHY: Index workspace-visible types by FQN without hiding duplicate declarations.
# IN/OUT: Workspace -> mutated type and per-unit package/wildcard indexes.
# CALL FLOW: build_jax_workspace calls it after parsing; provenance/owner resolution consumes indexes.
# EXAMPLE: Duplicate FQNs remain multiple records so later identity resolution fails closed.
def index_workspace_types(workspace):
# Preserve every declaration per fully qualified name.  A duplicate FQN stays
# visible as ambiguity and must not be converted into a scan-order winner.
    declarations = {}
    for unit in workspace["units"].values():
        for type_info in unit["type_infos"].values():
            if not type_info["workspace_visible"]:
                continue
            fqn = qualified_type_name(unit, type_info)
            declarations.setdefault(fqn, []).append(
                {"fqn": fqn, "unit": unit, "type_info": type_info}
            )
    workspace["type_declarations"] = declarations


# FLOW: index_workspace_constants
# WHY: Index constants and all member declarations with Java access facts.
# IN/OUT: Workspace -> mutated constant/member/static-member indexes.
# CALL FLOW: build_jax_workspace calls it; value and static-import resolution consume records.
# EXAMPLE: Fields without initializers still record declarations that can create ambiguity.
def index_workspace_constants(workspace):
# Constant indexing records Java eligibility and accessibility separately from
# identity.  Classes need suitable static/final String members for cross-file
# use; interface/annotation constants have implicit language modifiers.  The
# resolver first determines which declaration a spelling denotes, then asks
# whether that declaration is an allowed constant source.
    by_owner_member = {}
    member_declarations = {}
    static_member_declarations = {}
    for unit in workspace["units"].values():
        records = []
        for _pattern_index, captures in unit["matches"]["field"]:
            type_node = first_capture(captures, "constant.type")
            name_node = first_capture(captures, "constant.name")
            value_node = first_capture(captures, "constant.value")
            field_node = first_capture(captures, "constant.field")
            if None in (type_node, name_node, field_node):
                continue
            owner_node = nearest_enclosing_type(field_node)
            owner_info = (
                unit["type_infos"].get(tree_node_key(owner_node))
                if owner_node is not None
                else None
            )
            if owner_info is None or not owner_info["workspace_visible"]:
                continue
            member_name = node_text(unit["source"], name_node)
            owner_fqn = qualified_type_name(unit, owner_info)
            declaration_id = (
                unit["fname"],
                field_node.start_byte,
                field_node.end_byte,
                name_node.start_byte,
            )
            member_declarations.setdefault((owner_fqn, member_name), set()).add(
                declaration_id
            )
            modifiers = declaration_modifier_names(field_node)
            implicit_constant = field_node.type == "constant_declaration"
            owner_chain = type_chain(tree_node_key(owner_info["node"]), unit["type_infos"])
            owner_access = []
            for owner_part in owner_chain:
                owner_modifiers = declaration_modifier_names(owner_part["node"])
                outer_node = nearest_enclosing_type(owner_part["node"])
                implicitly_public = bool(
                    outer_node is not None
                    and outer_node.type
                    in {"interface_declaration", "annotation_type_declaration"}
                )
                owner_access.append(
                    {
                        "public": implicitly_public or "public" in owner_modifiers,
                        "private": "private" in owner_modifiers,
                    }
                )
            declaration_record = {
                "id": declaration_id,
                "owner": owner_info["display_name"],
                "owner_fqn": owner_fqn,
                "unit": unit,
                "static": implicit_constant or "static" in modifiers,
                "public": implicit_constant or "public" in modifiers,
                "private": "private" in modifiers,
                "owner_all_public": all(part["public"] for part in owner_access),
                "owner_has_private": any(part["private"] for part in owner_access),
            }
            if declaration_record["static"]:
                static_member_declarations.setdefault(
                    (owner_fqn, member_name), []
                ).append(declaration_record)
            if value_node is None:
                continue
            field_type = node_text(unit["source"], type_node).strip()
            if resolve_known_type(
                unit, field_type, "String", ("java.lang",), type_node
            ) != "java.lang":
                continue
            record = {
                **declaration_record,
                "name": member_name,
                "owner_type": owner_info["node"].type,
                "value_node": value_node,
                "final_constant": implicit_constant or "final" in modifiers,
                "static_final": implicit_constant
                or {"static", "final"}.issubset(modifiers),
                "protected": "protected" in modifiers,
            }
            records.append(record)
            by_owner_member.setdefault(
                (record["owner_fqn"], record["name"]), []
            ).append(record)
        for _pattern_index, captures in unit["matches"]["enum_constant"]:
            type_node = first_capture(captures, "enum.type.node")
            name_node = first_capture(captures, "enum.constant.name")
            constant_node = first_capture(captures, "enum.constant.node")
            type_info = (
                unit["type_infos"].get(tree_node_key(type_node))
                if type_node is not None
                else None
            )
            if (
                type_info is None
                or name_node is None
                or constant_node is None
                or not type_info["workspace_visible"]
            ):
                continue
            member_declarations.setdefault(
                (
                    qualified_type_name(unit, type_info),
                    node_text(unit["source"], name_node),
                ),
                set(),
            ).add(
                (
                    unit["fname"],
                    constant_node.start_byte,
                    constant_node.end_byte,
                    name_node.start_byte,
                )
            )
            enum_owner_access = []
            for owner_part in type_chain(
                tree_node_key(type_info["node"]), unit["type_infos"]
            ):
                owner_modifiers = declaration_modifier_names(owner_part["node"])
                outer_node = nearest_enclosing_type(owner_part["node"])
                implicitly_public = bool(
                    outer_node is not None
                    and outer_node.type
                    in {"interface_declaration", "annotation_type_declaration"}
                )
                enum_owner_access.append(
                    {
                        "public": implicitly_public or "public" in owner_modifiers,
                        "private": "private" in owner_modifiers,
                    }
                )
            static_member_declarations.setdefault(
                (
                    qualified_type_name(unit, type_info),
                    node_text(unit["source"], name_node),
                ),
                [],
            ).append(
                {
                    "id": (
                        unit["fname"],
                        constant_node.start_byte,
                        constant_node.end_byte,
                        name_node.start_byte,
                    ),
                    "owner": type_info["display_name"],
                    "owner_fqn": qualified_type_name(unit, type_info),
                    "unit": unit,
                    "static": True,
                    "public": True,
                    "private": False,
                    "owner_all_public": all(
                        part["public"] for part in enum_owner_access
                    ),
                    "owner_has_private": any(
                        part["private"] for part in enum_owner_access
                    ),
                }
            )
        unit["workspace_constant_records"] = records
    workspace["constants_by_owner_member"] = by_owner_member
    workspace["member_declarations"] = member_declarations
    workspace["static_member_declarations"] = static_member_declarations
    for unit in workspace["units"].values():
        unit["workspace_member_declarations"] = member_declarations
        unit["workspace_static_member_declarations"] = static_member_declarations


# FLOW: workspace_constant_accessible
# WHY: Apply final/static, nest, package, and owner-chain access rules.
# IN/OUT: Constant record, consumer context, flags -> Boolean.
# CALL FLOW: workspace_member_records calls it; expression resolution consumes survivors.
def workspace_constant_accessible(
    record,
    consumer_unit,
    consumer_owner_name,
    require_static_final=False,
    require_final_constant=False,
):
    if require_static_final and not record["static_final"]:
        return False
    if require_final_constant and not record["final_constant"]:
        return False
    declaration_unit = record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and record["owner"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        if record["private"] or record["owner_has_private"]:
            return same_nest
        return True
    if (
        not record["static_final"]
        or record["private"]
        or record["owner_has_private"]
    ):
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return record["public"] and record["owner_all_public"]


# FLOW: workspace_member_records
# WHY: Fetch uniquely owned accessible constant records for a member.
# IN/OUT: Workspace, consumer, owner/member, flags -> candidate list.
# CALL FLOW: workspace_constant_candidates calls it per lookup tier; value decoding consumes candidates.
def workspace_member_records(
    workspace,
    consumer_unit,
    consumer_owner_name,
    owner_fqn,
    member_name,
    require_static_final=False,
    require_final_constant=False,
):
    if len(workspace["type_declarations"].get(owner_fqn, [])) != 1:
        return []
    return [
        record
        for record in workspace["constants_by_owner_member"].get(
            (owner_fqn, member_name), []
        )
        if workspace_constant_accessible(
            record,
            consumer_unit,
            consumer_owner_name,
            require_static_final=require_static_final,
            require_final_constant=require_final_constant,
        )
    ]


# FLOW: workspace_type_exists
# WHY: Detect any source declaration of an FQN, including duplicates.
# IN/OUT: Workspace and FQN -> Boolean.
# CALL FLOW: Known-external and owner resolvers call it; source declarations shadow external identities.
def workspace_type_exists(workspace, fqn):
    return bool(workspace["type_declarations"].get(fqn))


# FLOW: workspace_member_declared
# WHY: Detect a member even when it is not a resolvable String constant.
# IN/OUT: Workspace, owner FQN, member -> Boolean.
# CALL FLOW: Constant lookup calls it; declaration shadowing stops lookup at the correct tier.
def workspace_member_declared(workspace, owner_fqn, member_name):
    return bool(
        workspace["member_declarations"].get((owner_fqn, member_name))
    )


# FLOW: workspace_static_member_declaration_accessible
# WHY: Apply Java access, nest, and package rules to a static member.
# IN/OUT: Declaration record and consumer context -> Boolean.
# CALL FLOW: Static-import helpers call it; ambiguity checks consume the verdict.
def workspace_static_member_declaration_accessible(
    record, consumer_unit, consumer_owner_name
):
    declaration_unit = record["unit"]
    if consumer_unit["package"] and not declaration_unit["package"]:
        return False
    if declaration_unit is consumer_unit:
        same_nest = bool(
            consumer_owner_name
            and record["owner"].split(".", 1)[0]
            == consumer_owner_name.split(".", 1)[0]
        )
        if record["private"] or record["owner_has_private"]:
            return same_nest
        return True
    if record["private"] or record["owner_has_private"]:
        return False
    if declaration_unit["package"] == consumer_unit["package"]:
        return True
    return record["public"] and record["owner_all_public"]


# FLOW: workspace_static_member_declared
# WHY: Prove one unique owner exposes an accessible static member.
# IN/OUT: Workspace, consumer context, owner/member -> Boolean.
# CALL FLOW: Constant/enum static-import resolution calls it; wildcard tiers consume output.
def workspace_static_member_declared(
    workspace, consumer_unit, consumer_owner_name, owner_fqn, member_name
):
    if len(workspace["type_declarations"].get(owner_fqn, [])) != 1:
        return False
    return any(
        workspace_static_member_declaration_accessible(
            record, consumer_unit, consumer_owner_name
        )
        for record in workspace["static_member_declarations"].get(
            (owner_fqn, member_name), []
        )
    )


# FLOW: workspace_type_fqn_accessible
# WHY: Require exactly one accessible source type for an FQN.
# IN/OUT: Workspace, consumer context, FQN -> Boolean.
# CALL FLOW: resolve_workspace_owner_fqns calls it; qualifier tiers consume output.
def workspace_type_fqn_accessible(
    workspace, consumer_unit, consumer_owner_name, owner_fqn
):
    declarations = workspace["type_declarations"].get(owner_fqn, [])
    return len(declarations) == 1 and workspace_type_accessible(
        declarations[0], consumer_unit, consumer_owner_name
    )


# FLOW: lexical_owner_fqns
# WHY: Enumerate current/enclosing lexical owners inner-to-outer.
# IN/OUT: Unit and display owner -> ordered FQNs.
# CALL FLOW: workspace_constant_candidates calls it first; lexical lookup consumes each tier.
# EXAMPLE: `Outer.Inner` yields `pkg.Outer.Inner` then `pkg.Outer`.
def lexical_owner_fqns(unit, owner_name):
    parts = owner_name.split(".") if owner_name else []
    owners = []
    while parts:
        display = ".".join(parts)
        owners.append(f"{unit['package']}.{display}" if unit["package"] else display)
        parts.pop()
    return owners


# FLOW: resolve_workspace_owner_fqns
# WHY: Resolve a type qualifier at the first nonempty Java lookup tier.
# IN/OUT: Unit, qualifier, owner, workspace, external FQNs -> candidates.
# CALL FLOW: Constant/alias resolvers call it; member lookup consumes unique owners.
# EXAMPLE: Lexical scope precedes imports, package/global identities, and wildcards.
def resolve_workspace_owner_fqns(
    unit,
    qualifier,
    owner_name,
    workspace,
    external_type_fqns=None,
):
    """Return the first Java name-resolution tier for a type qualifier."""
    external_type_fqns = set(external_type_fqns or ())
    if qualifier in external_type_fqns:
        return [] if workspace_type_exists(workspace, qualifier) else [qualifier]

    lexical = []
    owner_parts = owner_name.split(".") if owner_name else []
    while owner_parts:
        display = f"{'.'.join(owner_parts)}.{qualifier}"
        fqn = f"{unit['package']}.{display}" if unit["package"] else display
        if workspace_type_fqn_accessible(
            workspace, unit, owner_name, fqn
        ):
            lexical.append(fqn)
        if lexical:
            return lexical
        owner_parts.pop()

    first, dot, suffix = qualifier.partition(".")
    if first in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][first]
        if not imported:
            return []
        imported_fqn = f"{imported}.{suffix}" if dot else imported
        if imported_fqn in external_type_fqns:
            return (
                []
                if workspace_type_exists(workspace, imported_fqn)
                else [imported_fqn]
            )
        return (
            [imported_fqn]
            if workspace_type_fqn_accessible(
                workspace, unit, owner_name, imported_fqn
            )
            else []
        )

    same_package = f"{unit['package']}.{qualifier}" if unit["package"] else qualifier
    if same_package in external_type_fqns:
        return (
            []
            if workspace_type_exists(workspace, same_package)
            else [same_package]
        )
    if workspace_type_fqn_accessible(
        workspace, unit, owner_name, same_package
    ):
        return [same_package]

    global_declarations = workspace["type_declarations"].get(qualifier, [])
    if global_declarations and (
        not unit["package"]
        or all(record["unit"]["package"] for record in global_declarations)
    ) and workspace_type_fqn_accessible(
        workspace, unit, owner_name, qualifier
    ):
        return [qualifier]

    candidates = set()
    for package in unit["imports"]["wildcards"]:
        imported_fqn = f"{package}.{qualifier}"
        if imported_fqn in external_type_fqns:
            if not workspace_type_exists(workspace, imported_fqn):
                candidates.add(imported_fqn)
            continue
        if workspace_type_fqn_accessible(
            workspace, unit, owner_name, imported_fqn
        ):
            candidates.add(imported_fqn)
    return sorted(candidates)


# FLOW: context_is_static_for_instance_constant
# WHY: Decide whether a use site forbids an enclosing instance field.
# IN/OUT: Context node -> Boolean.
# CALL FLOW: lexical_instance_constant_accessible calls it; candidate filtering consumes the verdict.
def context_is_static_for_instance_constant(context_node):
    current = getattr(context_node, "parent", None)
    while current is not None:
        if current.type in {"method_declaration", "field_declaration"}:
            return "static" in declaration_modifier_names(current)
        if current.type in {"static_initializer", "constant_declaration"}:
            return True
        if current.type in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        }:
            # A declaration annotation is outside the declared type's member scope.
            return True
        current = getattr(current, "parent", None)
    return True


# FLOW: lexical_instance_constant_accessible
# WHY: Model bounded enclosing-instance access for final non-static fields.
# IN/OUT: Constant record and consumer context/node -> Boolean.
# CALL FLOW: workspace_constant_candidates calls it; expression resolution consumes survivors.
# EXAMPLE: A static nested boundary blocks access to an outer instance field.
def lexical_instance_constant_accessible(
    record, consumer_unit, consumer_owner_name, context_node
):
    if record["static_final"]:
        return True
    if (
        record["unit"] is not consumer_unit
        or not consumer_owner_name
        or context_is_static_for_instance_constant(context_node)
    ):
        return False
    if record["owner"] == consumer_owner_name:
        return True
    if not consumer_owner_name.startswith(f"{record['owner']}."):
        return False

    infos_by_display = {
        info["display_name"]: info for info in consumer_unit["type_infos"].values()
    }
    current = infos_by_display.get(consumer_owner_name)
    while current is not None and current["display_name"] != record["owner"]:
        modifiers = declaration_modifier_names(current["node"])
        outer = (
            consumer_unit["type_infos"].get(current["outer_key"])
            if current["outer_key"] is not None
            else None
        )
        implicitly_static = current["node"].type in {
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
            "annotation_type_declaration",
        } or bool(
            outer is not None
            and outer["node"].type
            in {"interface_declaration", "annotation_type_declaration"}
        )
        if "static" in modifiers or implicitly_static:
            return False
        current = outer
    return current is not None and current["display_name"] == record["owner"]


# FLOW: known_static_constant_record
# WHY: Adapt a trusted framework constant to the workspace record shape.
# IN/OUT: Owner FQN, member, value -> synthetic resolved record.
# CALL FLOW: workspace_constant_candidates creates it; String resolution consumes its value.
def known_static_constant_record(owner_fqn, member_name, value):
    return {
        "id": ("known-static", owner_fqn, member_name),
        "owner_fqn": owner_fqn,
        "name": member_name,
        "resolved_value": value,
    }


# FLOW: workspace_constant_candidates
# WHY: Apply lexical/import/qualified/access/ambiguity tiers to a reference.
# IN/OUT: Unit/reference/owner/workspace/context/known constants -> records.
# CALL FLOW: resolve_workspace_string_expression calls it; one candidate may recurse or resolve.
# EXAMPLE: Competing wildcard owners declaring one bare member yield no candidate.
def workspace_constant_candidates(
    unit,
    reference,
    owner_name,
    workspace,
    context_node=None,
    known_static_constants=None,
):
    known_static_constants = known_static_constants or {}
    reference = reference.strip()
    if reference.startswith("this."):
        return []

    if "." not in reference:
        for owner_fqn in lexical_owner_fqns(unit, owner_name):
            records = workspace_member_records(
                workspace,
                unit,
                owner_name,
                owner_fqn,
                reference,
                require_final_constant=True,
            )
            records = [
                record
                for record in records
                if lexical_instance_constant_accessible(
                    record, unit, owner_name, context_node
                )
            ]
            if workspace_member_declared(
                workspace, owner_fqn, reference
            ):
                return records

        if reference in unit["imports"]["static_exact"]:
            target = unit["imports"]["static_exact"][reference]
            if not target or "." not in target:
                return []
            owner_fqn, member_name = target.rsplit(".", 1)
            known_value = known_static_constants.get(owner_fqn, {}).get(
                member_name
            )
            if known_value is not None:
                if workspace_type_exists(workspace, owner_fqn):
                    return []
                return [
                    known_static_constant_record(
                        owner_fqn, member_name, known_value
                    )
                ]
            return workspace_member_records(
                workspace,
                unit,
                owner_name,
                owner_fqn,
                member_name,
                require_static_final=True,
            )

        declaring_owners = []
        for owner_fqn in sorted(unit["imports"]["static_wildcards"]):
            known_declared = reference in known_static_constants.get(
                owner_fqn, {}
            )
            source_declared = workspace_static_member_declared(
                workspace, unit, owner_name, owner_fqn, reference
            )
            if known_declared or source_declared:
                declaring_owners.append(owner_fqn)
        if len(declaring_owners) != 1:
            return []
        declaring_owner = declaring_owners[0]
        known_value = known_static_constants.get(declaring_owner, {}).get(
            reference
        )
        if known_value is not None:
            if workspace_type_exists(workspace, declaring_owner):
                return []
            return [
                known_static_constant_record(
                    declaring_owner, reference, known_value
                )
            ]
        return workspace_member_records(
            workspace,
            unit,
            owner_name,
            declaring_owner,
            reference,
            require_static_final=True,
        )

    qualifier, member_name = reference.rsplit(".", 1)
    owner_fqns = resolve_workspace_owner_fqns(
        unit,
        qualifier,
        owner_name,
        workspace,
        external_type_fqns=known_static_constants,
    )
    if len(owner_fqns) != 1:
        return []
    owner_fqn = owner_fqns[0]
    known_value = known_static_constants.get(owner_fqn, {}).get(member_name)
    if known_value is not None:
        return [
            known_static_constant_record(owner_fqn, member_name, known_value)
        ]
    candidates = []
    candidates.extend(
        workspace_member_records(
            workspace,
            unit,
            owner_name,
            owner_fqn,
            member_name,
            require_static_final=True,
        )
    )
    return candidates


# FLOW: resolve_workspace_string_expression
# WHY: Resolve bounded cross-file String graphs in each declaration's unit.
# IN/OUT: Unit/expression/workspace/owner/recursion state -> string or None.
# CALL FLOW: Path, alias, and verb decoders call it; values feed endpoint identity.
# EXAMPLE: See nearby cross-unit comments; cycles and ambiguity fail closed.
def resolve_workspace_string_expression(
    unit,
    expression_node,
    workspace,
    owner_name,
    stack=(),
    depth=0,
    known_static_constants=None,
):
# Resolution recursively switches to the declaration's source unit.  Thus an
# imported constant can itself use imports/constants belonging to its own file
# rather than inheriting the controller's lexical context.  Exactly one
# identity-compatible candidate must survive at every reference hop.
    if expression_node is None or depth > SPRING_MAX_CONSTANT_DEPTH:
        return None

    source = unit["source"]
    node_type = expression_node.type
    if node_type == "string_literal":
        return decode_java_string_literal(node_text(source, expression_node))
    if node_type == "parenthesized_expression":
        children = expression_node.named_children
        if len(children) != 1:
            return None
        return resolve_workspace_string_expression(
            unit,
            children[0],
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
    if node_type == "binary_expression":
        left = child_by_field(expression_node, "left")
        right = child_by_field(expression_node, "right")
        if (
            left is None
            or right is None
            or not binary_expression_is_addition(source, expression_node, left, right)
        ):
            return None
        left_value = resolve_workspace_string_expression(
            unit,
            left,
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
        right_value = resolve_workspace_string_expression(
            unit,
            right,
            workspace,
            owner_name,
            stack,
            depth + 1,
            known_static_constants,
        )
        if left_value is None or right_value is None:
            return None
        value = left_value + right_value
        return value if len(value) <= SPRING_MAX_CONSTANT_LENGTH else None
    if node_type in {"identifier", "field_access", "scoped_identifier"}:
        reference = node_text(source, expression_node)
        candidates = workspace_constant_candidates(
            unit,
            reference,
            owner_name,
            workspace,
            expression_node,
            known_static_constants,
        )
        unique = {record["id"]: record for record in candidates}
        if len(unique) != 1:
            return None
        record = next(iter(unique.values()))
        if "resolved_value" in record:
            return record["resolved_value"]
        if record["id"] in stack:
            return None
        return resolve_workspace_string_expression(
            record["unit"],
            record["value_node"],
            workspace,
            record["owner"],
            stack + (record["id"],),
            depth + 1,
            known_static_constants,
        )
    return None


# FLOW: index_jax_annotation_declarations
# WHY: Index source annotation declarations by Java identity; retention and
# framework semantics are deliberately resolved by downstream passes.
# IN/OUT: Workspace -> newly returned FQN-to-declaration-list dict; this helper
# does not mutate the workspace itself.
# CALL FLOW: `build_jax_workspace` assigns the returned dict to
# `workspace["annotation_declarations"]`; designator/target resolution consumes it.
def index_jax_annotation_declarations(workspace):
# Source annotation declarations are indexed independently from their
# semantics.  Later passes prove custom JAX designators, Spring compositions,
# and record-component target applicability without assuming every annotation
# with a familiar simple name belongs to a framework.
    declarations = {}
    for unit in workspace["units"].values():
        for info in unit["type_infos"].values():
            if (
                info["node"].type != "annotation_type_declaration"
                or not info["workspace_visible"]
            ):
                continue
            record = {
                "fqn": qualified_type_name(unit, info),
                "simple_name": info["simple_name"],
                "unit": unit,
                "type_info": info,
            }
            declarations.setdefault(record["fqn"], []).append(record)
    return declarations


# FLOW: index_jax_custom_designators
# WHY: Discover runtime-retained annotations with genuine JAX HttpMethod.
# IN/OUT: Workspace -> mutated custom-designator map.
# CALL FLOW: build_jax_workspace calls it; JAX method resolution consumes tokens.
# EXAMPLE: A valid `@PURGE` maps its FQN to PURGE; ambiguity excludes it.
def index_jax_custom_designators(workspace):
# A custom JAX request method is a provenance graph:
#
#   resource use -> unique accessible annotation declaration
#                -> genuine @HttpMethod in the same JAX namespace
#                -> genuine @Retention(RUNTIME)
#                -> valid bounded HTTP token
#
# Candidate and resolved maps stay distinct so a malformed or ambiguous
# definition fails closed instead of masquerading as an unrelated annotation.
    custom_candidates = set()
    custom_designators = {}
    for unit in workspace["units"].values():
        for declaration_key, candidates in unit["meta_candidates"].items():
            type_info = unit["type_infos"].get(declaration_key)
            if type_info is None:
                continue
            owner_name = type_info["display_name"]
            fqn = qualified_type_name(unit, type_info)
            records = annotation_records(candidates)
            http_methods = []
            retentions = []
            for record in records:
                resolved_http_method = resolve_known_annotation(
                    unit, record["name_node"], {"HttpMethod"}, JAX_RS_PACKAGES
                )
                if resolved_http_method is not None:
                    http_methods.append((record, resolved_http_method))
                resolved_retention = resolve_known_annotation(
                    unit,
                    record["name_node"],
                    {"Retention"},
                    ("java.lang.annotation",),
                )
                if resolved_retention is not None:
                    retentions.append(record)

            if not http_methods:
                continue
            custom_candidates.add(fqn)
            if len(http_methods) != 1:
                log_jax_issue(
                    unit["fname"], owner_name, "ambiguous custom @HttpMethod declaration"
                )
                continue
            if len(retentions) != 1 or not retention_is_runtime(
                unit, retentions[0]["node"]
            ):
                log_jax_issue(
                    unit["fname"], owner_name, "non-runtime custom @HttpMethod declaration"
                )
                continue

            http_annotation, resolved = http_methods[0]
            token = decode_custom_http_method(
                unit,
                http_annotation,
                owner_name,
                workspace,
            )
            if token is None:
                continue
            custom_designators.setdefault(fqn, []).append(
                {
                    "fqn": fqn,
                    "simple_name": type_info["simple_name"],
                    "namespace": resolved["namespace"],
                    "method": token,
                    "fname": unit["fname"],
                }
            )
    workspace["custom_candidates"] = custom_candidates
    workspace["custom_designators"] = custom_designators


# FLOW: custom_annotation_identity_candidates
# WHY: Resolve a source annotation spelling through Java identity tiers.
# IN/OUT: Unit, spelling, context, workspace -> declaration candidates.
# CALL FLOW: JAX designator/Spring composed resolution call it; unique identity gates decoding.
def custom_annotation_identity_candidates(
    unit, spelling, workspace, context_node=None
):
    declarations = workspace["annotation_declarations"]
    simple_name = spelling.rsplit(".", 1)[-1]
    if "." in spelling:
        identities = [spelling]
        if unit["package"]:
            identities.append(f"{unit['package']}.{spelling}")
        return {identity for identity in identities if identity in declarations}

    visible_infos = visible_local_type_infos(unit, context_node)
    visible_identities = {
        f"{unit['package']}.{info['display_name']}"
        if unit["package"]
        else info["display_name"]
        for info in visible_infos
        if info["simple_name"] == simple_name
    }
    if visible_identities:
        return visible_identities & set(declarations)

    if simple_name in unit["imports"]["exact"]:
        imported = unit["imports"]["exact"][simple_name]
        return {imported} if imported in declarations else set()

    same_package = (
        f"{unit['package']}.{simple_name}" if unit["package"] else simple_name
    )
    if same_package in declarations:
        return {same_package}
    if simple_name in unit.get("package_types", set()):
        return set()

    return {
        f"{package}.{simple_name}"
        for package in unit["imports"]["wildcards"]
        if f"{package}.{simple_name}" in declarations
    }


# FLOW: direct_annotation_records
# WHY: Extract distinct direct annotations from one declaration's modifiers.
# IN/OUT: Declaration node -> source-ordered annotation records.
# CALL FLOW: Application/resource/method/composed passes call it; identity filters consume output.
def direct_annotation_records(declaration_node):
    modifiers = find_first(declaration_node, "modifiers")
    if modifiers is None:
        return []
    records = []
    for annotation_node in modifiers.named_children:
        if annotation_node.type not in {"annotation", "marker_annotation"}:
            continue
        name_node = child_by_field(annotation_node, "name")
        if name_node is not None:
            records.append({"node": annotation_node, "name_node": name_node})
    return sorted(records, key=lambda record: record["node"].start_byte)


# FLOW: build_spring_annotation_definitions
# WHY: Build source annotation schema/meta facts for composed mappings.
# IN/OUT: Workspace -> FQN-keyed definition map.
# CALL FLOW: build_jax_workspace calls it; alias graph/composed decoders consume definitions.
# EXAMPLE: Definitions retain element types/defaults and direct meta-annotation uses.
def build_spring_annotation_definitions(workspace):
# Build declaration facts before decoding any use site.  Each fact retains the
# declaring unit/type, direct meta-annotations, elements, defaults, and element
# annotations.  This supports an identity-checked AliasFor graph rather than a
# name-only recursive annotation search.
    definitions = {}
    for fqn, declarations in workspace["annotation_declarations"].items():
        for declaration in declarations:
            unit = declaration["unit"]
            type_info = declaration["type_info"]
            type_key = tree_node_key(type_info["node"])
            elements = {}
            for captures in unit["element_candidates"].get(type_key, []):
                element_node = first_capture(captures, "annotation.element.node")
                name_node = first_capture(captures, "annotation.element.name")
                type_node = first_capture(captures, "annotation.element.type")
                default_node = first_capture(captures, "annotation.element.default")
                if None in (element_node, name_node, type_node):
                    continue
                name = node_text(unit["source"], name_node)
                elements.setdefault(name, []).append(
                    {
                        "name": name,
                        "node": element_node,
                        "type_node": type_node,
                        "type_text": node_text(unit["source"], type_node).strip(),
                        "default_node": default_node,
                        "annotations": direct_annotation_records(element_node),
                    }
                )
            definitions.setdefault(fqn, []).append(
                {
                    **declaration,
                    "meta_annotations": annotation_records(
                        unit["meta_candidates"].get(type_key, [])
                    ),
                    "elements": elements,
                }
            )
    workspace["spring_annotation_definitions"] = definitions


# FLOW: spring_definition_runtime_retained
# WHY: Determine whether a source Spring annotation definition is runtime-retained.
# IN/OUT: Definition record -> Boolean.
# CALL FLOW: Composed-mapping indexing/decoding calls it; only runtime-eligible definitions proceed.
def spring_definition_runtime_retained(definition):
    unit = definition["unit"]
    retentions = [
        record
        for record in definition["meta_annotations"]
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"Retention"},
            ("java.lang.annotation",),
        )
        is not None
    ]
    return len(retentions) == 1 and retention_is_runtime(
        unit, retentions[0]["node"]
    )


# FLOW: resolve_spring_mapping_spelling
# WHY: Resolve a built-in or source-defined Spring mapping annotation spelling.
# IN/OUT: Unit, spelling, context -> built-in identity, source identity, or None.
# CALL FLOW: Alias/composed definition passes call it; graph construction consumes the identity.
def resolve_spring_mapping_spelling(unit, spelling, context_node=None):
    simple_name = spelling.rsplit(".", 1)[-1]
    if simple_name not in SPRING_MAPPING_METHODS:
        return None
    expected = f"{SPRING_MAPPING_PACKAGE}.{simple_name}"
    if "." in spelling:
        return simple_name if spelling == expected else None
    if simple_name in visible_local_type_names(unit, context_node):
        return None
    explicit = unit["imports"]["exact"].get(simple_name)
    if explicit is not None:
        return simple_name if explicit == expected else None
    if simple_name in unit.get("package_types", set()):
        return None
    if SPRING_MAPPING_PACKAGE not in unit["imports"]["wildcards"]:
        return None
    if unit.get("wildcard_source_types", {}).get(simple_name, set()) - {expected}:
        return None
    return simple_name


# FLOW: source_annotation_definition
# WHY: Resolve exactly one accessible source annotation definition at a use site.
# IN/OUT: Unit, name node/spelling, workspace -> definition or None.
# CALL FLOW: Spring alias/composed and JAX designator logic call it; schema checks consume it.
def source_annotation_definition(
    unit,
    name_node,
    workspace,
    consumer_owner_name,
):
    spelling = node_text(unit["source"], name_node).strip()
    simple_name = spelling.rsplit(".", 1)[-1]
    if (
        "." not in spelling
        and simple_name in SPRING_MAPPING_METHODS
        and simple_name not in unit["imports"]["exact"]
        and SPRING_MAPPING_PACKAGE in unit["imports"]["wildcards"]
        and unit.get("wildcard_source_types", {}).get(simple_name, set())
        - {f"{SPRING_MAPPING_PACKAGE}.{simple_name}"}
    ):
        return {"status": "ambiguous", "definition": None}
    identities = custom_annotation_identity_candidates(
        unit, spelling, workspace, name_node
    )
    if not identities:
        return {"status": "none", "definition": None}
    if len(identities) != 1:
        return {"status": "ambiguous", "definition": None}
    identity = next(iter(identities))
    definitions = workspace["spring_annotation_definitions"].get(identity, [])
    if len(definitions) != 1:
        return {
            "status": "ambiguous" if definitions else "missing",
            "definition": None,
        }
    if not workspace_type_accessible(
        definitions[0], unit, consumer_owner_name
    ):
        return {"status": "inaccessible", "definition": None}
    return {"status": "resolved", "definition": definitions[0]}


# FLOW: unresolved_java_target_reference
# WHY: Detect unsupported or unresolved Java `@Target` element references.
# IN/OUT: Unit and annotation record -> Boolean.
# CALL FLOW: METHOD applicability validation calls it; fail-closed target checks consume the verdict.
def unresolved_java_target_reference(unit, record):
    spelling = node_text(unit["source"], record["name_node"]).strip()
    if spelling.rsplit(".", 1)[-1] != "Target":
        return False
    if "." in spelling:
        return spelling == "java.lang.annotation.Target"
    if "Target" in visible_local_type_names(unit, record["name_node"]):
        return False
    explicit = unit["imports"]["exact"].get("Target")
    if explicit is not None:
        return explicit in {"", "java.lang.annotation.Target"}
    if "Target" in unit.get("package_types", set()):
        return False
    return "java.lang.annotation" in unit["imports"]["wildcards"]


# FLOW: resolve_java_element_type
# WHY: Prove one `ElementType` expression's genuine Java enum identity.
# IN/OUT: Unit and value node -> element token or None.
# CALL FLOW: Annotation target parsing calls it; method-applicability logic consumes METHOD evidence.
def resolve_java_element_type(unit, value_node):
    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = node_text(unit["source"], current).strip()
    element_type = spelling.rsplit(".", 1)[-1]
    if element_type not in JAVA_ELEMENT_TYPES:
        return None
    expected_owner = "java.lang.annotation.ElementType"
    if "." not in spelling:
        return (
            element_type
            if static_member_resolves_to(
                unit, element_type, expected_owner, current
            )
            else None
        )
    qualifier = spelling.rsplit(".", 1)[0]
    return (
        element_type
        if resolve_known_type(
            unit,
            qualifier,
            "ElementType",
            ("java.lang.annotation",),
            current,
        )
        == "java.lang.annotation"
        else None
    )


# FLOW: annotation_definition_is_method_applicable
# WHY: Evaluate whether a source annotation can legally propagate to methods.
# IN/OUT: Definition -> Boolean.
# CALL FLOW: Spring/JAX record-component candidate filters call it; implicit accessor synthesis consumes output.
# EXAMPLE: Absent Target permits methods; unresolved Target evidence fails closed.
def annotation_definition_is_method_applicable(definition):
    unit = definition["unit"]
    target_like = [
        record
        for record in definition["meta_annotations"]
        if node_text(unit["source"], record["name_node"])
        .strip()
        .rsplit(".", 1)[-1]
        == "Target"
    ]
    genuine = [
        record
        for record in target_like
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"Target"},
            ("java.lang.annotation",),
        )
        is not None
    ]
    if any(
        unresolved_java_target_reference(unit, record)
        for record in target_like
        if record not in genuine
    ):
        return False
    if not genuine:
        return True
    if len(genuine) != 1:
        return False

    value_node, error = annotation_single_value_node(genuine[0]["node"])
    if error:
        return False
    values = [
        resolve_java_element_type(unit, node)
        for node in annotation_value_nodes(value_node)
    ]
    return (
        bool(values)
        and all(value is not None for value in values)
        and len(values) == len(set(values))
        and "METHOD" in values
    )


# FLOW: source_annotation_is_method_applicable
# WHY: Resolve a source annotation and apply its Java Target schema.
# IN/OUT: Unit/name node/workspace -> Boolean.
# CALL FLOW: Record-component candidate filters call it before synthesizing accessors.
def source_annotation_is_method_applicable(
    unit, annotation_record, workspace, consumer_owner_name
):
    resolved = source_annotation_definition(
        unit,
        annotation_record["name_node"],
        workspace,
        consumer_owner_name,
    )
    return (
        resolved["status"] == "resolved"
        and annotation_definition_is_method_applicable(resolved["definition"])
    )


# FLOW: spring_method_applicable_component_candidates
# WHY: Keep only record-component Spring annotations applicable to METHOD.
# IN/OUT: Source candidates/imports/workspace/owner context -> filtered captures.
# CALL FLOW: SpringBoot_Analyzer calls it; implicit accessor mapping selection consumes output.
def spring_method_applicable_component_candidates(
    source,
    candidates,
    imports,
    local_annotations,
    unit,
    workspace,
    owner_name,
):
# The syntax query intentionally captures all record-component annotations.
# This semantic filter keeps only genuine built-ins or source annotations
# whose Target permits METHOD, because only those can propagate to Java's
# compiler-declared accessor.
    applicable = []
    for captures in candidates:
        name_node = first_capture(captures, "annotation.name")
        annotation_node = first_capture(captures, "annotation.node")
        if name_node is None or annotation_node is None:
            continue
        if resolve_spring_mapping_name(
            source, name_node, imports, local_annotations, unit=unit
        ) is not None:
            applicable.append(captures)
            continue
        if unit is None or workspace is None:
            continue
        if source_annotation_is_method_applicable(
            unit,
            {"node": annotation_node, "name_node": name_node},
            workspace,
            owner_name,
        ):
            applicable.append(captures)
    return applicable


# FLOW: jax_method_applicable_component_records
# WHY: Keep only record-component JAX annotations applicable to METHOD.
# IN/OUT: Unit, candidates, workspace, owner -> filtered annotation records.
# CALL FLOW: analyze_jax_unit calls it; implicit accessor route logic consumes output.
def jax_method_applicable_component_records(unit, candidates, workspace, owner_name):
    applicable = []
    for record in annotation_records(candidates):
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {*JAX_RS_HTTP_METHODS, "Path"},
            JAX_RS_PACKAGES,
        ) is not None or source_annotation_is_method_applicable(
            unit, record, workspace, owner_name
        ):
            applicable.append(record)
    return applicable


# FLOW: collect_spring_mapping_branches
# WHY: Traverse bounded composed-mapping meta-annotation branches without cycles.
# IN/OUT: Definition, workspace, stack/depth -> terminal mapping branches.
# CALL FLOW: decode_spring_composed_mapping calls it; alias overlay decoding consumes each branch.
# EXAMPLE: Cycle/depth guards reject recursive annotation graphs rather than loop.
def collect_spring_mapping_branches(definition, workspace, stack=(), depth=0):
# Follow direct source meta-annotations until a genuine RequestMapping leaf is
# reached.  Depth/cycle guards and the later exactly-one-leaf requirement make
# the selected composition deterministic.
    if depth > SPRING_MAX_CONSTANT_DEPTH:
        return [], ["composed-annotation depth limit"]
    if definition["fqn"] in stack:
        return [], ["composed-annotation cycle"]

    branches = []
    errors = []
    for meta_record in definition["meta_annotations"]:
        unit = definition["unit"]
        spelling = node_text(unit["source"], meta_record["name_node"]).strip()
        mapping_name = resolve_spring_mapping_spelling(
            unit, spelling, meta_record["name_node"]
        )
        if mapping_name is not None:
            if mapping_name != "RequestMapping":
                errors.append(
                    f"@{mapping_name} cannot target an annotation declaration"
                )
                continue
            branches.append(
                {
                    "definitions": [definition],
                    "instances": [],
                    "leaf_record": meta_record,
                    "leaf_name": mapping_name,
                    "leaf_fqn": f"{SPRING_MAPPING_PACKAGE}.{mapping_name}",
                }
            )
            continue

        resolved = source_annotation_definition(
            unit,
            meta_record["name_node"],
            workspace,
            definition["type_info"]["display_name"],
        )
        if resolved["status"] == "none":
            continue
        if resolved["status"] != "resolved":
            errors.append(
                f"{resolved['status']} composed meta-annotation {spelling}"
            )
            continue
        tails, tail_errors = collect_spring_mapping_branches(
            resolved["definition"],
            workspace,
            stack + (definition["fqn"],),
            depth + 1,
        )
        errors.extend(tail_errors)
        for tail in tails:
            branches.append(
                {
                    **tail,
                    "definitions": [definition, *tail["definitions"]],
                    "instances": [
                        {
                            "record": meta_record,
                            "unit": definition["unit"],
                            "owner_name": definition["type_info"]["display_name"],
                        },
                        *tail["instances"],
                    ],
                }
            )
    return branches, errors


# FLOW: decode_alias_string
# WHY: Resolve one AliasFor string attribute in its declaration workspace.
# IN/OUT: Unit, value node, workspace, owner -> string or None.
# CALL FLOW: Alias-edge parsing calls it; target attribute/annotation selection consumes output.
def decode_alias_string(unit, value_node, workspace, owner_name):
    value = resolve_workspace_string_expression(
        unit, value_node, workspace, owner_name
    )
    return value if value is not None else None


# FLOW: resolve_alias_annotation_target
# WHY: Resolve AliasFor's annotation/class target to one definition or self.
# IN/OUT: Definition, value node, workspace -> target definition or None.
# CALL FLOW: parse_spring_alias_edge calls it; alias graph construction consumes target identity.
def resolve_alias_annotation_target(definition, value_node, workspace):
    current = unwrap_parenthesized_node(value_node)
    if current is None or current.type != "class_literal" or not current.named_children:
        return None
    spelling = node_text(definition["unit"]["source"], current.named_children[0]).strip()
    mapping_name = resolve_spring_mapping_spelling(
        definition["unit"], spelling, current.named_children[0]
    )
    if mapping_name is not None:
        return f"{SPRING_MAPPING_PACKAGE}.{mapping_name}"
    identities = custom_annotation_identity_candidates(
        definition["unit"], spelling, workspace, current.named_children[0]
    )
    if len(identities) != 1:
        return None
    identity = next(iter(identities))
    declarations = workspace["annotation_declarations"].get(identity, [])
    if len(declarations) != 1 or not workspace_type_accessible(
        declarations[0],
        definition["unit"],
        definition["type_info"]["display_name"],
    ):
        return None
    return identity


# FLOW: parse_spring_alias_edge
# WHY: Validate and normalize one source `@AliasFor` declaration edge.
# IN/OUT: Definition, element, workspace -> edge record or None.
# CALL FLOW: Composed-mapping definition processing calls it; terminal alias traversal consumes edges.
# EXAMPLE: Invalid annotation/attribute combinations are omitted with conservative diagnostics.
def parse_spring_alias_edge(definition, element, workspace):
# AliasFor ``value`` and ``attribute`` are alternative target-name spellings;
# ``annotation`` can name a deeper annotation in the selected branch.  Edge
# parsing is only the first gate: terminal resolution later validates graph
# direction, identities, types, cardinality, accessibility and defaults.
    unit = definition["unit"]
    alias_like = [
        record
        for record in element["annotations"]
        if node_text(unit["source"], record["name_node"])
        .strip()
        .rsplit(".", 1)[-1]
        == "AliasFor"
    ]
    if not alias_like:
        return {"status": "none", "target": None, "attribute": None}
    genuine = [
        record
        for record in alias_like
        if resolve_known_annotation(
            unit,
            record["name_node"],
            {"AliasFor"},
            (SPRING_ALIAS_FOR_PACKAGE,),
        )
        is not None
    ]
    if len(alias_like) != 1 or len(genuine) != 1:
        return {"status": "invalid", "reason": "invalid @AliasFor provenance"}

    positional, named = get_annotation_arguments(genuine[0]["node"])
    if set(named) - {"value", "attribute", "annotation"} or len(positional) > 1:
        return {"status": "invalid", "reason": "unsupported @AliasFor arguments"}
    if positional and "value" in named:
        return {"status": "invalid", "reason": "duplicate @AliasFor value"}
    if "attribute" in named and (positional or "value" in named):
        return {
            "status": "invalid",
            "reason": "@AliasFor value and attribute are mutually exclusive",
        }

    value_node = named.get("value") or (positional[0] if positional else None)
    attribute_node = named.get("attribute")
    value_name = (
        decode_alias_string(unit, value_node, workspace, definition["type_info"]["display_name"])
        if value_node is not None
        else ""
    )
    attribute_name = (
        decode_alias_string(
            unit,
            attribute_node,
            workspace,
            definition["type_info"]["display_name"],
        )
        if attribute_node is not None
        else ""
    )
    if value_name is None or attribute_name is None:
        return {"status": "invalid", "reason": "unresolved @AliasFor attribute"}
    if value_name and attribute_name and value_name != attribute_name:
        return {"status": "invalid", "reason": "conflicting @AliasFor attributes"}
    target_attribute = value_name or attribute_name or element["name"]

    annotation_node = named.get("annotation")
    target = definition["fqn"]
    if annotation_node is not None:
        target = resolve_alias_annotation_target(definition, annotation_node, workspace)
        if target is None:
            return {"status": "invalid", "reason": "unresolved @AliasFor annotation"}
    return {
        "status": "resolved",
        "target": target,
        "attribute": target_attribute,
    }


# FLOW: spring_alias_element_type_valid
# WHY: Check an alias source element can carry the canonical path/method value type.
# IN/OUT: Element, canonical attribute, definition -> Boolean.
# CALL FLOW: Alias terminal resolution calls it; composed value overlays depend on the result.
def spring_alias_element_type_valid(element, canonical_attribute, definition):
    compact = re.sub(r"\s+", "", element["type_text"])
    base_type = compact[:-2] if compact.endswith("[]") else compact
    if canonical_attribute == "path":
        return resolve_known_type(
            definition["unit"],
            base_type,
            "String",
            ("java.lang",),
            element["type_node"],
        ) == "java.lang"
    if canonical_attribute != "method":
        return False
    return resolve_known_type(
        definition["unit"],
        base_type,
        "RequestMethod",
        (SPRING_MAPPING_PACKAGE,),
        element["type_node"],
    ) == SPRING_MAPPING_PACKAGE


# FLOW: spring_alias_non_output_type_valid
# WHY: Validate an intermediate alias element type against its target.
# IN/OUT: Element, expected type, definition -> Boolean.
# CALL FLOW: Alias graph traversal calls it; incompatible edges fail closed.
def spring_alias_non_output_type_valid(element, expected_type, definition):
    compact = re.sub(r"\s+", "", element["type_text"])
    if expected_type == "string_array":
        if compact.endswith("[]"):
            compact = compact[:-2]
    elif compact.endswith("[]"):
        return False
    return resolve_known_type(
        definition["unit"],
        compact,
        "String",
        ("java.lang",),
        element["type_node"],
    ) == "java.lang"


# FLOW: spring_alias_value_cardinality_valid
# WHY: Ensure one alias use-site value fits the declared scalar/array cardinality.
# IN/OUT: Element and value node -> Boolean.
# CALL FLOW: Composed annotation instance decoding calls it before value propagation.
def spring_alias_value_cardinality_valid(element, value_node):
    compact = re.sub(r"\s+", "", element["type_text"])
    if compact.endswith("[]"):
        return True
    current = unwrap_parenthesized_node(value_node)
    return bool(
        current is not None
        and current.type != "element_value_array_initializer"
        and len(annotation_value_nodes(value_node)) == 1
    )


# FLOW: spring_alias_known_type_shape
# WHY: Normalize a known Java alias element type to comparable shape facts.
# IN/OUT: Element and definition -> type-shape record or None.
# CALL FLOW: Alias compatibility checks call it; graph validation consumes shape identity.
def spring_alias_known_type_shape(element, definition):
    compact = re.sub(r"\s+", "", element["type_text"])
    is_array = compact.endswith("[]")
    base_type = compact[:-2] if is_array else compact
    if base_type in {
        "boolean",
        "byte",
        "short",
        "int",
        "long",
        "char",
        "float",
        "double",
    }:
        return (base_type, is_array)
    if resolve_known_type(
        definition["unit"],
        base_type,
        "String",
        ("java.lang",),
        element["type_node"],
    ) == "java.lang":
        return ("java.lang.String", is_array)
    if resolve_known_type(
        definition["unit"],
        base_type,
        "RequestMethod",
        (SPRING_MAPPING_PACKAGE,),
        element["type_node"],
    ) == SPRING_MAPPING_PACKAGE:
        return (f"{SPRING_MAPPING_PACKAGE}.RequestMethod", is_array)
    return None


# FLOW: spring_alias_custom_types_compatible
# WHY: Prove two source-defined alias element types denote the same declaration.
# IN/OUT: Source/target elements and definitions -> Boolean.
# CALL FLOW: Alias graph validation calls it for non-built-in types.
def spring_alias_custom_types_compatible(
    source_element, source_definition, target_element, target_definition
):
    source_shape = spring_alias_known_type_shape(source_element, source_definition)
    target_shape = spring_alias_known_type_shape(target_element, target_definition)
    if source_shape is None or target_shape is None:
        return False
    source_type, source_array = source_shape
    target_type, target_array = target_shape
    return source_type == target_type and (
        source_array == target_array or (target_array and not source_array)
    )


# FLOW: resolve_ignored_sibling_alias_target
# WHY: Resolve an ignored same-annotation sibling alias for consistency checks.
# IN/OUT: Definition, attribute, workspace -> canonical terminal or None.
# CALL FLOW: Alias value normalization calls it; conflicting sibling declarations are rejected.
def resolve_ignored_sibling_alias_target(
    definition, target_fqn, target_attribute, workspace
):
    definitions = workspace["spring_annotation_definitions"].get(target_fqn, [])
    if len(definitions) != 1:
        return {"status": "invalid", "reason": "ambiguous sibling alias target"}
    target_definition = definitions[0]
    if not workspace_type_accessible(
        target_definition,
        definition["unit"],
        definition["type_info"]["display_name"],
    ) or not spring_definition_runtime_retained(target_definition):
        return {"status": "invalid", "reason": "invalid sibling alias target"}

    target_records = []
    for record in definition["meta_annotations"]:
        spelling = node_text(
            definition["unit"]["source"], record["name_node"]
        ).strip()
        identities = custom_annotation_identity_candidates(
            definition["unit"], spelling, workspace, record["name_node"]
        )
        if identities == {target_fqn}:
            target_records.append(record)
    if len(target_records) != 1:
        return {"status": "invalid", "reason": "alias target is not a unique direct meta-annotation"}

    _values, instance_error = annotation_instance_values(
        target_definition, target_records[0]
    )
    target_elements = target_definition["elements"].get(target_attribute, [])
    if instance_error or len(target_elements) != 1:
        return {"status": "invalid", "reason": "missing sibling alias target element"}
    target_element = target_elements[0]
    if parse_spring_alias_edge(
        target_definition, target_element, workspace
    )["status"] != "none":
        return {"status": "invalid", "reason": "nested sibling alias is outside the bounded graph"}
    return {
        "status": "ignored_custom",
        "element": target_element,
        "definition": target_definition,
        "target_key": f"{target_fqn}#{target_attribute}",
    }


# FLOW: resolve_spring_alias_terminal
# WHY: Traverse AliasFor edges to one canonical mapping attribute.
# IN/OUT: Definition, attribute, workspace, recursion state -> terminal record or None.
# CALL FLOW: Composed mapping decoding calls it for declared/use-site attributes; overlays consume terminal identity.
# EXAMPLE: Cycles, ambiguity, invalid types, and conflicting terminals return None.
def resolve_spring_alias_terminal(
    definition,
    element_name,
    branch_definitions,
    branch_positions,
    leaf_fqn,
    leaf_name,
    workspace,
    stack=(),
):
    key = (definition["fqn"], element_name)
    if key in stack:
        return {"status": "invalid", "reason": "@AliasFor element cycle"}
    elements = definition["elements"].get(element_name, [])
    if len(elements) != 1:
        return {"status": "invalid", "reason": "missing or ambiguous alias element"}
    element = elements[0]
    edge = parse_spring_alias_edge(definition, element, workspace)
    if edge["status"] != "resolved":
        if edge["status"] == "none" and stack:
            return {
                "status": "ignored_custom",
                "element": element,
                "definition": definition,
                "target_key": f"{definition['fqn']}#{element_name}",
            }
        return (
            edge
            if edge["status"] == "invalid"
            else {"status": "invalid", "reason": "alias does not reach a mapping"}
        )

    if edge["target"] == leaf_fqn:
        target_attribute = edge["attribute"]
        if target_attribute in {"value", "path"}:
            canonical = "path"
        elif leaf_name == "RequestMapping" and target_attribute == "method":
            canonical = "method"
        elif (
            leaf_name == "RequestMapping"
            and target_attribute in SPRING_REQUEST_MAPPING_ATTRIBUTES
        ):
            expected_type = (
                "string"
                if target_attribute in {"name", "version"}
                else "string_array"
            )
            if not spring_alias_non_output_type_valid(
                element, expected_type, definition
            ):
                return {"status": "invalid", "reason": "incompatible alias element type"}
            return {
                "status": "ignored",
                "attribute": target_attribute,
                "expected_type": expected_type,
            }
        else:
            return {"status": "invalid", "reason": "unsupported mapping alias target"}
        if not spring_alias_element_type_valid(element, canonical, definition):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return {"status": "resolved", "attribute": canonical}

    if edge["target"] == definition["fqn"]:
        target_elements = definition["elements"].get(edge["attribute"], [])
        if len(target_elements) != 1 or edge["attribute"] == element_name:
            return {
                "status": "invalid",
                "reason": "invalid local @AliasFor target",
            }
        target_element = target_elements[0]
        reverse = parse_spring_alias_edge(definition, target_element, workspace)
        if (
            reverse["status"] != "resolved"
            or reverse["target"] != definition["fqn"]
            or reverse["attribute"] != element_name
        ):
            return {
                "status": "invalid",
                "reason": "local @AliasFor pair is not reciprocal",
            }
        if not spring_alias_custom_types_compatible(
            element, definition, target_element, definition
        ):
            return {
                "status": "invalid",
                "reason": "incompatible local alias element type",
            }

        # A reciprocal local pair on a composed RequestMapping can override a
        # meta-attribute by convention when one member bears that attribute's
        # name.  Collapse the pair before values/defaults are reconciled so a
        # single explicit member is propagated to its omitted mate.
        component_names = {element_name, edge["attribute"]}
        canonical = None
        if component_names & {"value", "path"}:
            canonical = "path"
        elif "method" in component_names and leaf_name == "RequestMapping":
            canonical = "method"
        if canonical is not None:
            if not all(
                spring_alias_element_type_valid(
                    current_element, canonical, definition
                )
                for current_element in (element, target_element)
            ):
                return {
                    "status": "invalid",
                    "reason": "incompatible local alias element type",
                }
            return {"status": "resolved", "attribute": canonical}

        ignored_attributes = component_names & SPRING_REQUEST_MAPPING_ATTRIBUTES
        if leaf_name == "RequestMapping" and len(ignored_attributes) == 1:
            ignored_attribute = next(iter(ignored_attributes))
            expected_type = (
                "string"
                if ignored_attribute in {"name", "version"}
                else "string_array"
            )
            if not all(
                spring_alias_non_output_type_valid(
                    current_element, expected_type, definition
                )
                for current_element in (element, target_element)
            ):
                return {
                    "status": "invalid",
                    "reason": "incompatible local alias element type",
                }
            return {
                "status": "ignored",
                "attribute": ignored_attribute,
                "expected_type": expected_type,
            }
        if ignored_attributes:
            return {
                "status": "invalid",
                "reason": "ambiguous local alias mapping target",
            }
        return {
            "status": "ignored_custom",
            "element": element,
            "definition": definition,
            "target_key": "local:"
            + definition["fqn"]
            + "#"
            + ",".join(sorted(component_names)),
        }
    target_definition = branch_definitions.get(edge["target"])
    if target_definition is None:
        terminal = resolve_ignored_sibling_alias_target(
            definition, edge["target"], edge["attribute"], workspace
        )
        if terminal["status"] != "ignored_custom":
            return terminal
        if not spring_alias_custom_types_compatible(
            element,
            definition,
            terminal["element"],
            terminal["definition"],
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if branch_positions[edge["target"]] <= branch_positions[definition["fqn"]]:
        return {"status": "invalid", "reason": "alias targets an outer annotation"}
    target_elements = target_definition["elements"].get(edge["attribute"], [])
    if len(target_elements) != 1 or not spring_alias_custom_types_compatible(
        element,
        definition,
        target_elements[0] if target_elements else element,
        target_definition,
    ):
        return {"status": "invalid", "reason": "incompatible alias element type"}
    terminal = resolve_spring_alias_terminal(
        target_definition,
        edge["attribute"],
        branch_definitions,
        branch_positions,
        leaf_fqn,
        leaf_name,
        workspace,
        stack + (key,),
    )
    if terminal["status"] == "ignored_custom":
        if not spring_alias_custom_types_compatible(
            element,
            definition,
            terminal["element"],
            terminal["definition"],
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if terminal["status"] == "ignored":
        if not spring_alias_non_output_type_valid(
            element, terminal["expected_type"], definition
        ):
            return {"status": "invalid", "reason": "incompatible alias element type"}
        return terminal
    if terminal["status"] != "resolved":
        return terminal
    if not spring_alias_element_type_valid(
        element, terminal["attribute"], definition
    ):
        return {"status": "invalid", "reason": "incompatible alias element type"}
    return terminal


# FLOW: annotation_instance_values
# WHY: Map a source annotation use to its explicit/default element value nodes.
# IN/OUT: Definition and annotation record -> element-value map plus errors.
# CALL FLOW: decode_spring_composed_mapping calls it; alias/cardinality decoders consume values.
def annotation_instance_values(definition, annotation_record):
    positional, named = get_annotation_arguments(annotation_record["node"])
    if set(named) - set(definition["elements"]):
        return None, "unknown composed-annotation attribute"
    values = dict(named)
    if positional:
        if len(positional) != 1 or "value" not in definition["elements"] or "value" in values:
            return None, "invalid positional composed-annotation value"
        values["value"] = positional[0]
    missing_required = [
        element_name
        for element_name, elements in definition["elements"].items()
        if element_name not in values
        and any(element["default_node"] is None for element in elements)
    ]
    if missing_required:
        return None, "missing required composed-annotation attribute"
    return values, None


# FLOW: decode_spring_alias_path_value
# WHY: Decode one canonical path alias value with workspace constants and arrays.
# IN/OUT: Value unit/node plus owner/workspace -> normalized path list or None.
# CALL FLOW: Composed mapping decoding calls it; branch path overlays consume output.
def decode_spring_alias_path_value(
    value_unit, value_owner_name, value_node, workspace
):
    values = []
    for current in annotation_value_nodes(value_node):
        value = resolve_workspace_string_expression(
            value_unit,
            current,
            workspace,
            value_owner_name,
        )
        if value is None:
            return None
        values.append(value)
    return tuple(dict.fromkeys(values))


# FLOW: decode_spring_alias_method_value
# WHY: Decode one canonical method alias value to Spring RequestMethod identities.
# IN/OUT: Value unit and node -> ordered methods or None.
# CALL FLOW: Composed mapping decoding calls it; branch verb overlays consume output.
def decode_spring_alias_method_value(value_unit, value_node):
    methods = []
    for current in annotation_value_nodes(value_node):
        method_name = resolve_spring_request_method_expression(
            value_unit["source"],
            current,
            value_unit["imports"],
            unit=value_unit,
        )
        if method_name is None:
            return None
        methods.append(method_name)
    return tuple(methods)


# FLOW: invalid_spring_composed_mapping
# WHY: Construct a recognized-but-invalid mapping fact for atomic failure.
# IN/OUT: Annotation node -> invalid mapping fact.
# CALL FLOW: Composed decoder returns it on malformed recognized evidence; route selection stops partial emission.
def invalid_spring_composed_mapping(annotation_node):
    return {
        "name": "ComposedMapping",
        "paths": [],
        "methods": [],
        "valid": False,
        "annotation_node": annotation_node,
    }


# FLOW: log_spring_composed_issue
# WHY: Emit an auditable diagnostic for skipped composed mapping evidence.
# IN/OUT: File, owner, spelling, reason -> log side effect.
# CALL FLOW: Composed decoder/alias validation calls it; write_log emits the reason.
def log_spring_composed_issue(fname, owner_name, spelling, reason):
    write_log(
        f"Skipped invalid Spring composed mapping in {fname} for "
        f"{owner_name} @{spelling}: {reason}"
    )


# FLOW: decode_spring_composed_mapping
# WHY: Decode one source-defined composed annotation through meta branches and aliases.
# IN/OUT: File/unit/name/use/owners/workspace -> mapping fact or None.
# CALL FLOW: first_spring_mapping calls it after built-in decoding; route composition consumes valid facts.
# EXAMPLE: See nearby AliasFor worked example; all recognized malformed overlays fail atomically.
def decode_spring_composed_mapping(
    fname,
    use_unit,
    annotation_name_node,
    annotation_node,
    lexical_owner_name,
    diagnostic_owner_name,
    workspace,
):
# Example (illustrative):
#
#   @Retention(RUNTIME)
#   @RequestMapping(method=RequestMethod.GET)
#   @interface ReadRoute {
#       @AliasFor(annotation=RequestMapping.class, attribute="path")
#       String[] route() default {};
#   }
#   @ReadRoute(route="/health") Object health() { ... }
#
# The declaration supplies GET and the use-site ``route`` value travels to
# RequestMapping.path through a genuine AliasFor edge.  Every value is decoded
# in the source unit where it is written.  Conflicts, bad retention, cycles,
# missing elements, incompatible types, multiple leaves, or ambiguous source
# identity invalidate the complete mapping rather than yielding a partial URI.
    spelling = node_text(use_unit["source"], annotation_name_node).strip()
    resolved = source_annotation_definition(
        use_unit,
        annotation_name_node,
        workspace,
        lexical_owner_name,
    )
    if resolved["status"] == "none":
        return None
    if resolved["status"] != "resolved":
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, resolved["status"]
        )
        return invalid_spring_composed_mapping(annotation_node)

    definition = resolved["definition"]
    branches, errors = collect_spring_mapping_branches(definition, workspace)
    if not branches and not errors:
        return None
    if errors or len(branches) != 1:
        reason = errors[0] if errors else "multiple mapping leaves"
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, reason
        )
        return invalid_spring_composed_mapping(annotation_node)

    branch = branches[0]
    if any(
        not spring_definition_runtime_retained(current)
        for current in branch["definitions"]
    ):
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, "non-runtime annotation"
        )
        return invalid_spring_composed_mapping(annotation_node)

    leaf_definition = branch["definitions"][-1]
    leaf_unit = leaf_definition["unit"]
    leaf_record = branch["leaf_record"]
    mapping = decode_spring_mapping(
        leaf_unit["fname"],
        leaf_unit["source"],
        leaf_record["name_node"],
        leaf_record["node"],
        leaf_unit["imports"],
        leaf_unit["local_annotations"],
        leaf_unit["constant_index"],
        leaf_definition["type_info"]["display_name"],
        diagnostic_owner_name,
        leaf_unit,
        workspace,
    )
    if mapping is None or not mapping["valid"]:
        log_spring_composed_issue(
            fname, diagnostic_owner_name, spelling, "invalid mapping leaf"
        )
        return invalid_spring_composed_mapping(annotation_node)

    definitions_by_fqn = {
        current["fqn"]: current for current in branch["definitions"]
    }
    definition_positions = {
        current["fqn"]: index
        for index, current in enumerate(branch["definitions"])
    }
    terminals = {}
    for current in branch["definitions"]:
        for element_name, elements in current["elements"].items():
            for element in elements:
                edge = parse_spring_alias_edge(current, element, workspace)
                if edge["status"] == "none":
                    continue
                if edge["status"] == "invalid":
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        edge["reason"],
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                terminal = resolve_spring_alias_terminal(
                    current,
                    element_name,
                    definitions_by_fqn,
                    definition_positions,
                    branch["leaf_fqn"],
                    branch["leaf_name"],
                    workspace,
                )
                if terminal["status"] == "ignored":
                    terminals[(current["fqn"], element_name)] = (
                        f"ignored:{terminal['attribute']}"
                    )
                    continue
                if terminal["status"] == "ignored_custom":
                    terminals[(current["fqn"], element_name)] = (
                        f"ignored-custom:{terminal['target_key']}"
                    )
                    continue
                if terminal["status"] != "resolved":
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        terminal["reason"],
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                terminals[(current["fqn"], element_name)] = terminal["attribute"]

    for current in branch["definitions"]:
        terminal_attributes = {
            terminal_attribute
            for (definition_fqn, _element_name), terminal_attribute in terminals.items()
            if definition_fqn == current["fqn"]
        }
        for terminal_attribute in terminal_attributes:
            aliased_elements = [
                current["elements"][element_name][0]
                for definition_fqn, element_name in terminals
                if definition_fqn == current["fqn"]
                and terminals[(definition_fqn, element_name)] == terminal_attribute
                and len(current["elements"].get(element_name, [])) == 1
            ]
            if len(aliased_elements) < 2:
                continue
            declared_types = {
                re.sub(r"\s+", "", element["type_text"])
                for element in aliased_elements
            }
            if len(declared_types) != 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "implicit alias return types differ",
                )
                return invalid_spring_composed_mapping(annotation_node)
            defaults = []
            for element in aliased_elements:
                if element["default_node"] is None:
                    defaults = None
                    break
                if not spring_alias_value_cardinality_valid(
                    element, element["default_node"]
                ):
                    defaults = None
                    break
                default = (
                    decode_spring_alias_path_value(
                        current["unit"],
                        current["type_info"]["display_name"],
                        element["default_node"],
                        workspace,
                    )
                    if terminal_attribute != "method"
                    else decode_spring_alias_method_value(
                        current["unit"], element["default_node"]
                    )
                )
                if default is None:
                    defaults = None
                    break
                defaults.append(default)
            if defaults is None or len(set(defaults)) != 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "implicit alias defaults differ",
                )
                return invalid_spring_composed_mapping(annotation_node)

    instances = [
        {
            "record": {"node": annotation_node, "name_node": annotation_name_node},
            "unit": use_unit,
            "owner_name": lexical_owner_name,
        },
        *branch["instances"],
    ]
    overrides = {}
    for current, instance_info in reversed(list(zip(branch["definitions"], instances))):
        explicit, error = annotation_instance_values(
            current, instance_info["record"]
        )
        if error:
            log_spring_composed_issue(
                fname, diagnostic_owner_name, spelling, error
            )
            return invalid_spring_composed_mapping(annotation_node)
        layer = {}
        grouped_elements = {}
        for element_name, elements in current["elements"].items():
            if len(elements) != 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "ambiguous composed-annotation element",
                )
                return invalid_spring_composed_mapping(annotation_node)
            terminal_attribute = terminals.get((current["fqn"], element_name))
            if terminal_attribute is None:
                continue
            if terminal_attribute.startswith("ignored-custom:"):
                continue
            element = elements[0]
            grouped_elements.setdefault(terminal_attribute, []).append(
                (element_name, element)
            )

        for terminal_attribute, group in grouped_elements.items():
            supplied = [
                (element_name, element, explicit[element_name])
                for element_name, element in group
                if element_name in explicit
            ]
            selected = supplied or [
                (element_name, element, element["default_node"])
                for element_name, element in group
                if element["default_node"] is not None
            ]
            decoded_values = []
            for element_name, element, value_node in selected:
                if not spring_alias_value_cardinality_valid(element, value_node):
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        "invalid composed-annotation value cardinality",
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                if supplied:
                    value_unit = instance_info["unit"]
                    value_owner_name = instance_info["owner_name"]
                else:
                    value_unit = current["unit"]
                    value_owner_name = current["type_info"]["display_name"]
                value = (
                    decode_spring_alias_path_value(
                        value_unit, value_owner_name, value_node, workspace
                    )
                    if terminal_attribute != "method"
                    else decode_spring_alias_method_value(value_unit, value_node)
                )
                if value is None:
                    log_spring_composed_issue(
                        fname,
                        diagnostic_owner_name,
                        spelling,
                        "unresolved composed-annotation value",
                    )
                    return invalid_spring_composed_mapping(annotation_node)
                if value and any(value):
                    decoded_values.append(value)
            if len(set(decoded_values)) > 1:
                log_spring_composed_issue(
                    fname,
                    diagnostic_owner_name,
                    spelling,
                    "conflicting composed-annotation values",
                )
                return invalid_spring_composed_mapping(annotation_node)
            if decoded_values:
                layer[terminal_attribute] = decoded_values[0]
        overrides.update(layer)

    if "path" in overrides:
        mapping["paths"] = [
            normalize_spring_path(value) for value in overrides["path"]
        ]
    if "method" in overrides:
        mapping["methods"] = ordered_http_methods(overrides["method"])
    mapping["annotation_node"] = annotation_node
    return mapping


# FLOW: resolve_custom_designator
# WHY: Resolve one custom JAX HTTP-method annotation use to its token.
# IN/OUT: Unit, name node, workspace, owner -> token or None.
# CALL FLOW: resolve_jax_method_designator calls it after built-ins; endpoint verbs consume unique tokens.
def resolve_custom_designator(unit, name_node, workspace, owner_name):
    spelling = node_text(unit["source"], name_node).strip()
    identities = custom_annotation_identity_candidates(
        unit, spelling, workspace, name_node
    )
    relevant = {
        identity
        for identity in identities
        if identity in workspace["custom_candidates"]
        or identity in workspace["custom_designators"]
    }
    if not relevant:
        return {"status": "none", "record": None}
    if len(identities) != 1 or len(relevant) != 1:
        return {"status": "ambiguous", "record": None}
    identity = next(iter(relevant))
    declarations = workspace["annotation_declarations"].get(identity, [])
    if len(declarations) != 1 or not workspace_type_accessible(
        declarations[0], unit, owner_name
    ):
        return {"status": "invalid", "record": None}
    records = workspace["custom_designators"].get(identity, [])
    if len(records) == 1:
        return {"status": "resolved", "record": records[0]}
    return {
        "status": "invalid" if not records else "ambiguous",
        "record": None,
    }


# FLOW: index_jax_applications
# WHY: Collect source classes carrying ApplicationPath only when their direct
# core Application relationship and namespace can be proven.
# IN/OUT: Workspace in -> no return value; the helper mutates
# `workspace["applications"]` to the collected application-fact list.
# CALL FLOW: `build_jax_workspace` calls it after annotation indexes are ready;
# deployment construction and resource-root selection consume the stored list.
# EXAMPLE: An unannotated Application is deliberately absent; a valid direct
# subclass annotated `@ApplicationPath("/api")` contributes `/api`.
def index_jax_applications(workspace):
# ApplicationPath counts as deployment evidence only on a concrete class that
# directly extends the matching Javax/Jakarta core Application in this bounded
# direct model.  Retaining all application facts permits later project/package
# association and makes conflicts explicit instead of source-order dependent.
    applications = []
    for unit in workspace["units"].values():
        for type_key, type_info in unit["type_infos"].items():
            if type_info["node"].type != "class_declaration":
                continue
            records = annotation_records(unit["type_candidates"].get(type_key, []))
            application_annotations = []
            for record in records:
                resolved = resolve_known_annotation(
                    unit,
                    record["name_node"],
                    {"ApplicationPath"},
                    JAX_RS_PACKAGES,
                )
                if resolved is not None:
                    application_annotations.append((record, resolved))
            if not application_annotations:
                continue
            owner_name = type_info["display_name"]
            if type_info["abstract"]:
                log_jax_issue(
                    unit["fname"], owner_name, "@ApplicationPath on an abstract Application"
                )
                continue
            if len(application_annotations) != 1:
                log_jax_issue(
                    unit["fname"], owner_name, "ambiguous @ApplicationPath annotations"
                )
                for _record, resolved in application_annotations:
                    applications.append(
                        {
                            "namespace": resolved["namespace"],
                            "package": unit["package"],
                            "path": None,
                            "fname": unit["fname"],
                            "simple_name": type_info["simple_name"],
                            "fqn": qualified_type_name(unit, type_info),
                        }
                    )
                continue

            record, resolved = application_annotations[0]
            application_namespace = type_directly_extends_jax_application(
                unit, type_info
            )
            if application_namespace != resolved["namespace"]:
                log_jax_issue(
                    unit["fname"],
                    owner_name,
                    "@ApplicationPath on a non-matching direct Application subclass",
                )
                continue
            path = decode_jax_path_annotation(
                unit,
                record,
                owner_name,
                owner_name,
                "@ApplicationPath value",
                workspace,
            )
            applications.append(
                {
                    "namespace": resolved["namespace"],
                    "package": unit["package"],
                    "path": path,
                    "fname": unit["fname"],
                    "simple_name": type_info["simple_name"],
                    "fqn": qualified_type_name(unit, type_info),
                }
            )
    workspace["applications"] = applications


# FLOW: build_jax_workspace
# WHY: Orchestrate root-wide parse, identity, constant, annotation, hierarchy, and application indexes.
# IN/OUT: Files/content/runtime -> workspace dictionary.
# CALL FLOW: analyze_module/JaxRS_Analyzer calls it; Spring/JAX per-unit analyzers consume the complete model.
# EXAMPLE: Index order is deliberate: types precede constants, then annotations/designators/applications.
def build_jax_workspace(
    source_by_file,
    runtime=None,
    parsed_trees=None,
    include_jax=True,
):
# Build order is semantic: units first; package/wildcard visibility next; then
# type and constant indexes; finally annotation definitions, custom methods,
# and applications.  Later resolution sees the complete in-root source set
# (including forward declarations) but never guesses from outside the root.
    runtime = runtime or build_jax_runtime()
    parsed_trees = parsed_trees or {}
    normalized_sources = {
        str(fname): source for fname, source in source_by_file.items()
    }
    normalized_trees = {
        str(fname): tree for fname, tree in parsed_trees.items()
    }
    units = {}
    for fname in sorted(normalized_sources):
        source = java_source_bytes(fname, normalized_sources[fname])
        units[fname] = build_jax_unit(
            fname, source, runtime, parsed_tree=normalized_trees.get(fname)
        )
    package_types = {}
    for unit in units.values():
        names = package_types.setdefault(unit["package"], set())
        names.update(
            info["simple_name"]
            for info in unit["type_infos"].values()
            if info["outer_key"] is None
        )
    for unit in units.values():
        own_top_level_names = {
            info["simple_name"]
            for info in unit["type_infos"].values()
            if info["outer_key"] is None
        }
        unit["package_types"] = package_types[unit["package"]] - own_top_level_names
        wildcard_source_types = {}
        for imported_package in unit["imports"]["wildcards"]:
            for simple_name in package_types.get(imported_package, set()):
                wildcard_source_types.setdefault(simple_name, set()).add(
                    f"{imported_package}.{simple_name}"
                )
        unit["wildcard_source_types"] = wildcard_source_types
    workspace = {"runtime": runtime, "units": units}
    index_workspace_types(workspace)
    index_workspace_constants(workspace)
    workspace["annotation_declarations"] = index_jax_annotation_declarations(workspace)
    build_spring_annotation_definitions(workspace)
    if include_jax:
        index_jax_custom_designators(workspace)
        index_jax_applications(workspace)
    else:
        workspace["custom_candidates"] = set()
        workspace["custom_designators"] = {}
        workspace["applications"] = []
    return workspace


# FLOW: package_is_ancestor
# WHY: Test dot-segment package ancestry without prefix false positives.
# IN/OUT: Ancestor and package strings -> Boolean.
# CALL FLOW: JAX application deployment selection calls it; candidate scopes consume the verdict.
def package_is_ancestor(ancestor, package):
    return not ancestor or package == ancestor or package.startswith(f"{ancestor}.")


# FLOW: package_specificity
# WHY: Score package depth for nearest deployment selection.
# IN/OUT: Package string -> segment count.
# CALL FLOW: select_jax_application_path uses it to choose the most specific ancestor deployment.
def package_specificity(package):
    return len(package.split(".")) if package else 0


# FLOW: select_jax_application_path
# WHY: Associate a resource unit with one unambiguous most-specific JAX ApplicationPath.
# IN/OUT: Workspace, unit, namespace, owner -> path or None.
# CALL FLOW: analyze_jax_unit calls it; resource and method paths compose beneath the deployment root.
# EXAMPLE: Tied most-specific applications are ambiguous and suppress a guessed deployment root.
def select_jax_application_path(workspace, unit, namespace, owner_name):
# Deployment-aware selection is delegated when XML/project configuration has
# been built.  The fallback shown here chooses a unique namespace-compatible
# ApplicationPath, preferring the longest package ancestor and rejecting
# equal-specificity disagreement rather than guessing by scan order.
    deployment = workspace.get("jax_deployment")
    if deployment is not None:
        return select_jax_deployment_path(
            deployment, unit, namespace, owner_name, sys.modules[__name__]
        )
    applications = [
        application
        for application in workspace["applications"]
        if application["namespace"] == namespace
    ]
    if not applications:
        return ""

    valid_paths = {
        application["path"]
        for application in applications
        if application["path"] is not None
    }
    invalid_count = sum(application["path"] is None for application in applications)
    if not invalid_count and len(valid_paths) == 1:
        return next(iter(valid_paths))
    if len(applications) == 1:
        log_jax_issue(
            unit["fname"], owner_name, "unresolved @ApplicationPath association"
        )
        return None

    candidates = [
        application
        for application in applications
        if package_is_ancestor(application["package"], unit["package"])
    ]
    if candidates:
        specificity = max(
            package_specificity(application["package"])
            for application in candidates
        )
        candidates = [
            application
            for application in candidates
            if package_specificity(application["package"]) == specificity
        ]
    candidate_paths = {
        application["path"]
        for application in candidates
        if application["path"] is not None
    }
    if candidates and all(
        application["path"] is not None for application in candidates
    ) and len(candidate_paths) == 1:
        return next(iter(candidate_paths))

    log_jax_issue(
        unit["fname"], owner_name, "ambiguous @ApplicationPath association"
    )
    return None


# FLOW: method_is_public
# WHY: Check whether a Java method carries public access.
# IN/OUT: Method node -> Boolean.
# CALL FLOW: analyze_jax_unit calls it; JAX resource-method eligibility consumes the verdict.
def method_is_public(method_node):
    modifiers = find_first(method_node, "modifiers")
    return bool(modifiers and any(child.type == "public" for child in modifiers.children))


# FLOW: resolve_jax_root
# WHY: Resolve one concrete type's direct JAX Path root and namespace.
# IN/OUT: Unit, type info, workspace -> root fact or None.
# CALL FLOW: analyze_jax_unit calls it; deployment/type/method route composition consumes output.
def resolve_jax_root(unit, type_info, workspace):
# A direct root needs one genuine Javax/Jakarta class-level Path on a concrete,
# workspace-visible class or record.  Annotation namespace becomes part of the
# root fact so method annotations from the other namespace cannot be mixed in.
    type_key = tree_node_key(type_info["node"])
    records = annotation_records(unit["type_candidates"].get(type_key, []))
    paths = []
    for record in records:
        resolved = resolve_known_annotation(
            unit, record["name_node"], {"Path"}, JAX_RS_PACKAGES
        )
        if resolved is not None:
            paths.append((record, resolved))
    if not paths:
        return None
    owner_name = type_info["display_name"]
    if len(paths) != 1:
        log_jax_issue(unit["fname"], owner_name, "ambiguous class @Path annotations")
        return None
    record, resolved = paths[0]
    path = decode_jax_path_annotation(
        unit,
        record,
        owner_name,
        owner_name,
        "class @Path value",
        workspace,
    )
    if path is None:
        return None
    return {"path": path, "namespace": resolved["namespace"]}


# FLOW: resolve_jax_method_designator
# WHY: Resolve built-in or custom JAX HTTP designators on one method.
# IN/OUT: Unit, annotation records, workspace, namespace, owner -> verb or None.
# CALL FLOW: analyze_jax_unit calls it; endpoint identity uses the selected HTTP method.
# EXAMPLE: Multiple distinct designators are ambiguous and suppress a guessed method.
def resolve_jax_method_designator(unit, records, workspace, namespace, owner_name):
# Standard annotations and source-defined custom designators share one
# selection point.  Exactly one valid request-method annotation must remain;
# unlike a first-wins decoder, multiple designators are diagnosed as ambiguous.
    designators = []
    invalid = False
    for record in records:
        standard = resolve_known_annotation(
            unit, record["name_node"], set(JAX_RS_HTTP_METHODS), JAX_RS_PACKAGES
        )
        if standard is not None:
            if standard["namespace"] != namespace:
                invalid = True
                log_jax_issue(
                    unit["fname"], owner_name, "mixed Javax/Jakarta designator"
                )
                continue
            if not annotation_has_no_values(record["node"]):
                invalid = True
                log_jax_issue(
                    unit["fname"], owner_name, "invalid standard designator arguments"
                )
                continue
            designators.append(
                {"method": standard["name"], "node": record["node"]}
            )
            continue

        custom = resolve_custom_designator(
            unit, record["name_node"], workspace, owner_name
        )
        if custom["status"] == "none":
            continue
        if custom["status"] != "resolved":
            invalid = True
            log_jax_issue(
                unit["fname"], owner_name, f"{custom['status']} custom designator"
            )
            continue
        custom_record = custom["record"]
        if custom_record["namespace"] != namespace:
            invalid = True
            log_jax_issue(
                unit["fname"], owner_name, "mixed Javax/Jakarta custom designator"
            )
            continue
        designators.append(
            {"method": custom_record["method"], "node": record["node"]}
        )

    if invalid:
        return None
    if len(designators) > 1:
        log_jax_issue(
            unit["fname"], owner_name, "multiple request-method designators"
        )
        return None
    return designators[0] if designators else None


# FLOW: resolve_jax_method_path
# WHY: Resolve an optional JAX method-level Path atomically.
# IN/OUT: Unit, records, workspace, owner -> path string or None/sentinel fact.
# CALL FLOW: analyze_jax_unit calls it; deployment/resource/method paths compose afterward.
def resolve_jax_method_path(
    unit, records, namespace, type_owner, owner_name, workspace
):
    paths = []
    for record in records:
        resolved = resolve_known_annotation(
            unit, record["name_node"], {"Path"}, JAX_RS_PACKAGES
        )
        if resolved is not None:
            paths.append((record, resolved))
    if not paths:
        return ""
    if len(paths) != 1 or paths[0][1]["namespace"] != namespace:
        log_jax_issue(
            unit["fname"], owner_name, "ambiguous or mixed method @Path annotation"
        )
        return None
    return decode_jax_path_annotation(
        unit,
        paths[0][0],
        type_owner,
        owner_name,
        "method @Path value",
        workspace,
    )


# FLOW: analyze_jax_unit
# WHY: Extract JAX endpoints from one indexed unit using workspace deployment and identity facts.
# IN/OUT: Unit and workspace -> endpoint fact list.
# CALL FLOW: JaxRS_Analyzer/analyze_module calls it; additions/config/output consume returned facts.
# EXAMPLE: See nearby direct JAX example; record accessors obey METHOD target and explicit-accessor suppression.
def analyze_jax_unit(unit, workspace):
# Direct JAX-RS example:
#
#   @ApplicationPath("/api")
#   class App extends jakarta.ws.rs.core.Application {}
#
#   @Path("/users")
#   class Users {
#       @GET @Path("/{id}")
#       public User get(@PathParam("id") String id) { ... }
#   }
#
# With genuine, namespace-consistent annotations, this yields the fact
# ``GET /api/users/{id}``, source-attributed to ``Users.get`` with its complete
# raw formal declaration.  Application, root and method paths are separate
# evidence layers and are composed exactly once.  Structured parameter
# semantics are intentionally not inferred in this six-column endpoint tool.
    roots = {}
    for type_key, type_info in unit["type_infos"].items():
        if (
            type_info["node"].type
            not in {"class_declaration", "record_declaration"}
            or type_info["abstract"]
            or not type_info["workspace_visible"]
        ):
            continue
        root = resolve_jax_root(unit, type_info, workspace)
        if root is not None:
            roots[type_key] = root

    endpoints = []
# Route identity comes only from a method belonging to a resolved root, one
# designator, a public concrete source declaration, an optional same-namespace
# Path, and an unambiguous deployment prefix.  Each failed prerequisite skips
# the candidate and leaves an audit diagnostic where applicable.
    for method_key in sorted(unit["method_candidates"]):
        candidates = unit["method_candidates"][method_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        method_node = first_capture(representative, "method.node")
        method_name_node = first_capture(representative, "method.name")
        parameters_node = first_capture(representative, "method.parameters")
        if None in (type_node, method_node, method_name_node, parameters_node):
            continue
        type_key = tree_node_key(type_node)
        root = roots.get(type_key)
        type_info = unit["type_infos"].get(type_key)
        if root is None or type_info is None:
            continue

        method_name = node_text(unit["source"], method_name_node)
        owner_name = f"{type_info['display_name']}.{method_name}"
        records = annotation_records(candidates)
        designator = resolve_jax_method_designator(
            unit, records, workspace, root["namespace"], owner_name
        )
        if designator is None:
            continue
        if not method_is_public(method_node):
            log_jax_issue(unit["fname"], owner_name, "non-public resource method")
            continue
        method_path = resolve_jax_method_path(
            unit,
            records,
            root["namespace"],
            type_info["display_name"],
            owner_name,
            workspace,
        )
        if method_path is None:
            continue
        application_path = select_jax_application_path(
            workspace, unit, root["namespace"], owner_name
        )
        if application_path is None:
            continue

        uri = combine_paths(
            combine_paths(application_path, root["path"]), method_path
        )
        endpoint = {
            "uri": uri,
            "method": designator["method"],
            "uri_params": get_callable_parameters_as_is(
                unit["source"], parameters_node
            ),
            "SrcFile": unit["fname"],
            "SrcLine": designator["node"].start_point.row + 1,
            "SFunction": owner_name,
        }
        endpoints.append(endpoint)
        debug_log(endpoint)

    for component_key in sorted(unit["record_component_candidates"]):
        candidates = unit["record_component_candidates"][component_key]
        representative = candidates[0]
        type_node = first_capture(representative, "type.node")
        component_name_node = first_capture(representative, "component.name")
        if type_node is None or component_name_node is None:
            continue
        type_key = tree_node_key(type_node)
        root = roots.get(type_key)
        type_info = unit["type_infos"].get(type_key)
        if root is None or type_info is None:
            continue

        component_name = node_text(unit["source"], component_name_node)
        if (type_key, component_name) in unit["record_explicit_accessors"]:
            continue
        owner_name = f"{type_info['display_name']}.{component_name}"
        records = jax_method_applicable_component_records(
            unit, candidates, workspace, type_info["display_name"]
        )
        designator = resolve_jax_method_designator(
            unit, records, workspace, root["namespace"], owner_name
        )
        if designator is None:
            continue
        method_path = resolve_jax_method_path(
            unit,
            records,
            root["namespace"],
            type_info["display_name"],
            owner_name,
            workspace,
        )
        if method_path is None:
            continue
        application_path = select_jax_application_path(
            workspace, unit, root["namespace"], owner_name
        )
        if application_path is None:
            continue

        uri = combine_paths(
            combine_paths(application_path, root["path"]), method_path
        )
        endpoint = {
            "uri": uri,
            "method": designator["method"],
            "uri_params": "",
            "SrcFile": unit["fname"],
            "SrcLine": designator["node"].start_point.row + 1,
            "SFunction": owner_name,
        }
        endpoints.append(endpoint)
        debug_log(endpoint)
    return endpoints


# FLOW: JaxRS_Analyzer
# WHY: Provide standalone or prepared-workspace JAX analysis for one source.
# IN/OUT: File/content/runtime/workspace -> endpoint fact list.
# CALL FLOW: analyze_module or library callers invoke it; endpoint additions consume output.
def JaxRS_Analyzer(fname, fcontent=None, runtime=None, workspace=None):
    """Extract direct JAX-RS resource methods from one workspace source."""
    fname = str(fname)
    if workspace is None:
        runtime = runtime or build_jax_runtime()
        source = java_source_bytes(fname, fcontent)
        workspace = build_jax_workspace({fname: source}, runtime=runtime)
    unit = workspace["units"].get(fname)
    if unit is None:
        return []
    write_log(f"{fname}:")
    return analyze_jax_unit(unit, workspace)

# ---------------------------------------------------------------------------
# 6. Endpoint facts, identity normalization, and CSV serialization
# ---------------------------------------------------------------------------
#
# Direct analyzers and sibling modules use a common fact shape.  A minimal
# direct fact resembles:
#
#   {"uri": "/api/users", "method": "GET", "uri_params": "String q",
#    "SrcFile": "/scan/app/Users.java", "SrcLine": 12,
#    "SFunction": "Users.list"}
#
# Specialized facts may additionally carry protocol/surface/direction and
# separate route/handler evidence.  Formatting selects the stable report
# projection; path normalization and full-row dedup happen only after all
# analyzers and configuration passes have finished.

# FLOW: debug_log
# WHY: Render one endpoint fact into the analyzer's always-attempted diagnostic log.
# IN/OUT: Endpoint fact -> append-only log side effect.
# CALL FLOW: Spring/JAX analyzers call it after fact creation; write_log sends formatted text.
def debug_log(ep):
    line=ep["SrcLine"]
    uri=ep["uri"]
    verb=ep["method"]
    uri_params=ep["uri_params"]
    sf=ep["SFunction"]
    ep_s=f'{line } {verb} {uri} {sf} {uri_params}'
    write_log(ep_s)


# FLOW: write_log
# WHY: Append timestamped diagnostics to the configured `log_file` path.
# IN/OUT: Message -> output side effect.
# CALL FLOW: Resolvers/analyzers call it; the adjacent file is the sole sink
# here—this helper does not write stderr.
def write_log(message):
    with open(log_file, "a", encoding="utf8") as rpt:
        now = datetime.now()
        dt = now.strftime('%Y-%m-%d %H:%M:%S')
        rpt.write(dt + ' ' + message + '\n')


# FLOW: safe_str
# WHY: Convert arbitrary endpoint fields to stable CSV-safe strings.
# IN/OUT: Any value -> string.
# CALL FLOW: `deduplicate_and_sort_rows` and `write_csv` call it while preparing
# stable field values; `format_endpoint` does not.
def safe_str(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, (str, int, float, bool)):
        return str(x)
    try:
        return json.dumps(x, ensure_ascii=False)
    except Exception:
        return str(x)


# FLOW: get_source_file_name
# WHY: Render a source path relative to the analysis root when possible.
# IN/OUT: File path and optional root -> display path.
# CALL FLOW: format_endpoint calls it; CSV SrcFile consumes the result.
def get_source_file_name(fname, analysis_root=None):
    root = analysis_root or input_srcdir
    relative_path = os.path.relpath(os.path.abspath(fname), start=root)
    return Path(relative_path).as_posix()


# FLOW: format_endpoint
# WHY: Convert an internal endpoint fact to the stable public CSV row schema.
# IN/OUT: Endpoint fact plus module/root context -> CSV row dictionary.
# CALL FLOW: analyze_module calls it after analyzers; normalization/deduplication consume rows.
def format_endpoint(ep, current_module_name=None, analysis_root=None):
# Surface-aware labels keep unlike callable interfaces distinct in the fixed
# schema: direct inbound HTTP remains ``http GET``; examples of specialized
# labels are ``http-client GET``, ``http-gateway ANY``, and ``ws SEND``.
    protocol = ep.get("protocol", "http")
    surface = ep.get("surface", "server")
    interface_kind = (
        protocol
        if protocol != "http" or surface in {"", "server"}
        else f"{protocol}-{surface}"
    )
    return {
        "module_name": current_module_name or module_name,
        "interface_type": interface_kind + " " + ep["method"],
        "endpoint": ep["uri"],
        "source_file_name": get_source_file_name(ep["SrcFile"], analysis_root),
        "method_name": ep["SFunction"],
        "parameters": ep["uri_params"],
    }


# FLOW: normalize_spring_regex_templates
# WHY: Remove Spring `{name:regex}` constraints while preserving template identity.
# IN/OUT: Path string -> normalized template path.
# CALL FLOW: normalize_endpoint_path calls it for all route facts; CSV identity consumes output.
# EXAMPLE: `/users/{id:[0-9]+}` becomes `/users/{id}` with nested braces handled.
def normalize_spring_regex_templates(path):
    """Drop bounded Spring ``{name:regex}`` constraints from a URI path.

    Regexes can contain their own brace quantifiers, so a flat regular
    expression cannot safely find the outer template delimiter.
    """

    value = str(path or "")
    output = []
    cursor = 0
    length = len(value)
    name_pattern = re.compile(r"[A-Za-z_$][\w$]*")
    while cursor < length:
        if value[cursor] != "{" or (cursor > 0 and value[cursor - 1] == "$"):
            output.append(value[cursor])
            cursor += 1
            continue
        name_match = name_pattern.match(value, cursor + 1)
        if name_match is None or name_match.end() >= length or value[name_match.end()] != ":":
            output.append(value[cursor])
            cursor += 1
            continue

        depth = 1
        escaped = False
        end = name_match.end() + 1
        while end < length:
            character = value[end]
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == "{":
                depth += 1
            elif character == "}":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        if depth != 0:
            output.append(value[cursor])
            cursor += 1
            continue
        output.append("{" + name_match.group(0) + "}")
        cursor = end + 1
    return "".join(output)


# FLOW: normalize_endpoint_path
# WHY: Canonicalize endpoint paths without corrupting schemes or template segments.
# IN/OUT: Path and protocol -> normalized path.
# CALL FLOW: format_endpoint/output preparation calls it; comparison-ready URI fields consume output.
def normalize_endpoint_path(path, protocol="http"):
    """Apply endpoint-identity normalization shared with Noir's optimizer.

    Preserve non-path absolute URL authority delimiters, collapse repeated
    path separators, normalize Spring regex templates, and turn unresolved
    Spring placeholders into stable brace parameters.
    """

    value = normalize_spring_regex_templates(path)
    value = re.sub(
        r"\$\{([^{}]+)\}",
        lambda match: "{" + (
            re.findall(r"[A-Za-z_$][\w$]*", match.group(1)) or ["value"]
        )[-1] + "}",
        value,
    )
    value = re.sub(r"(?<!:)/{2,}", "/", value)
    if (
        protocol == "http"
        and value
        and not value.startswith("/")
        and not value.lower().startswith(("http://", "https://"))
    ):
        value = f"/{value}"
    return value


# FLOW: deduplicate_and_sort_rows
# WHY: Collapse exact public endpoint identities and impose deterministic order.
# IN/OUT: Rows and schema -> sorted unique row list.
# CALL FLOW: analyze_module calls it before write_csv/return; reports consume deterministic rows.
def deduplicate_and_sort_rows(rows, fieldnames=CSV_FIELDNAMES):
# Example projection:
#
#   internal uri ``api//users/{id:[0-9]{1,8}}`` with protocol http
#       -> endpoint ``/api/users/{id}``
#       -> key ``(module, interface, endpoint, source, function, parameters)``
#
# Normalizing before the key collapses spelling-only path differences.  Using
# all six fields preserves distinct concrete implementations/evidence instead
# of merging every identical method/path pair across source files.
    unique = {}
    for row in rows:
        normalized = {
            field: "" if row.get(field) is None else safe_str(row.get(field))
            for field in fieldnames
        }
        interface = normalized.get("interface_type", "")
        protocol = interface.split(" ", 1)[0].split("-", 1)[0] or "http"
        normalized["endpoint"] = normalize_endpoint_path(
            normalized.get("endpoint", ""), protocol
        )
        key = tuple(normalized[field] for field in fieldnames)
        unique[key] = normalized
    return [unique[key] for key in sorted(unique)]


# FLOW: write_csv
# WHY: Serialize stable endpoint rows with an explicit header schema.
# IN/OUT: Path, field names, row iterable -> CSV file side effect.
# CALL FLOW: main calls it after analyze_module; users and comparison tooling consume the report.
def write_csv(path: Path, fieldnames: List[str], rows: Iterable[Dict[str, Any]]) -> None:
# UTF-8 with BOM and semicolon delimiters are deliberate compatibility details
# of the public report.  ``newline=""`` lets the csv module correctly preserve
# raw formal text that itself contains newlines.
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, delimiter=DELIM, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else safe_str(r.get(k))) for k in fieldnames})


# FLOW: build_argument_parser
# WHY: Define the standalone noir-ts CLI contract and defaults.
# IN/OUT: No input -> configured ArgumentParser.
# CALL FLOW: main calls it; parsed options control root, framework, output, logging, and additions.
def build_argument_parser():
    parser = argparse.ArgumentParser(
        description=(
            "Identify Java Spring Boot and JAX-RS HTTP endpoints from source "
            "with Tree-sitter"
        )
    )
    parser.add_argument(
        "--path",
        required=True,
        help="directory containing the application source code",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="path of the endpoint CSV file to create",
    )
    parser.add_argument(
        "--framework",
        choices=["spring", "jaxrx"],
        help="analyze only Spring or JAX-RS; omit to run both analyzers",
    )
    return parser


# ---------------------------------------------------------------------------
# 7. Root discovery and whole-analysis orchestration
# ---------------------------------------------------------------------------

# FLOW: is_ignored_source_file
# WHY: Apply bounded generated/build/vendor path exclusions relative to analysis root.
# IN/OUT: File path and optional root -> Boolean.
# CALL FLOW: discover_java_files calls it; workspace construction sees only admitted sources.
def is_ignored_source_file(file_path, analysis_root=None):
    root = analysis_root or input_srcdir
    relative_path = Path(os.path.relpath(file_path, start=root))
    return any(directory in IGNORED_DIRS for directory in relative_path.parts[:-1])


# FLOW: discover_java_files
# WHY: Enumerate deterministic non-ignored Java sources beneath one root.
# IN/OUT: Analysis root -> sorted file list.
# CALL FLOW: analyze_module calls it first; workspace parsing consumes the paths.
def discover_java_files(analysis_root):
# Sorting both directory traversal and the final root-relative path list makes
# parsing, diagnostics and output independent of filesystem enumeration order.
# Ignored directory components are pruned before descent.
    discovered = []
    for current_root, directory_names, file_names in os.walk(analysis_root):
        directory_names[:] = sorted(
            directory for directory in directory_names if directory not in IGNORED_DIRS
        )
        for file_name in sorted(file_names):
            if file_name.lower().endswith(".java"):
                discovered.append(os.path.join(current_root, file_name))
    return sorted(
        discovered,
        key=lambda file_name: get_source_file_name(file_name, analysis_root),
    )


# FLOW: analyze_module
# WHY: Orchestrate discovery, shared workspace construction, framework analysis, and public row shaping.
# IN/OUT: Analysis root and optional framework -> deterministic CSV-row list.
# CALL FLOW: main/library callers invoke it; write_csv or callers consume the comparison-ready report.
# EXAMPLE: Spring and JAX share one parsed workspace so identity/constant facts are consistent.
def analyze_module(analysis_root, framework=None):
# The host first reads an immutable source snapshot and constructs one neutral
# root-wide Java/JAX-capable workspace.  Direct per-file passes then contribute
# facts, followed by additive workspace passes:
#
#   Spring direct annotations
#     + functional/programmatic recall and record-related additions
#     + controller hierarchy
#     + Gateway Java DSL
#     + resource handlers
#     + outbound clients
#     + raw/STOMP WebSocket and messaging
#     -> one project configuration/placeholder application
#
#   JAX-RS direct resources
#     + hierarchy and recursive subresource recall
#     + annotated WebSocket handshakes
#
# JAX deployment configuration is built before direct/recall analysis so every
# JAX HTTP branch selects the same ApplicationPath/web.xml base.  Spring
# configuration is applied after all Spring branches so a server prefix is not
# duplicated and clients/messages remain on their correct surface.
    require_tree_sitter()
    selected = {framework} if framework else {"spring", "jaxrx"}
    java_files = discover_java_files(analysis_root)
    source_by_file = {}
    for file_name in java_files:
        with open(file_name, "rb") as source_file:
            source_by_file[file_name] = source_file.read()
    endpoints = []
    workspace_runtime = build_jax_runtime()
    java_workspace = build_jax_workspace(
        source_by_file,
        runtime=workspace_runtime,
        include_jax="jaxrx" in selected,
    )
    if "jaxrx" in selected:
        build_jax_deployment_configuration(
            java_workspace, analysis_root, sys.modules[__name__]
        )

    spring_runtime = build_spring_runtime() if "spring" in selected else None
    if "spring" in selected:
        print("Found SpringBoot Annotation")
        spring_endpoints = []
        for file_name in java_files:
            spring_endpoints.extend(
                SpringBoot_Analyzer(
                    file_name,
                    source_by_file[file_name],
                    runtime=spring_runtime,
                    workspace=java_workspace,
                )
            )
        if java_workspace.get("units"):
            spring_endpoints.extend(
                analyze_spring_recall(java_workspace, sys.modules[__name__])
            )
            spring_endpoints.extend(
                analyze_spring_hierarchy(java_workspace, sys.modules[__name__])
            )
            spring_endpoints.extend(
                analyze_spring_gateway(java_workspace, sys.modules[__name__])
            )
            spring_endpoints.extend(
                analyze_spring_resource_handlers(
                    java_workspace, sys.modules[__name__]
                )
            )
            spring_endpoints.extend(
                analyze_spring_clients(java_workspace, sys.modules[__name__])
            )
            spring_configuration = build_spring_configuration(
                java_workspace, analysis_root, sys.modules[__name__]
            )
            spring_endpoints.extend(
                analyze_spring_websocket(
                    java_workspace,
                    sys.modules[__name__],
                    spring_configuration,
                )
            )
            spring_endpoints = apply_spring_configuration(
                spring_endpoints, spring_configuration, sys.modules[__name__]
            )
        endpoints.extend(spring_endpoints)

    if "jaxrx" in selected:
        print("Found JaxRS")
        for file_name in java_files:
            endpoints.extend(
                JaxRS_Analyzer(
                    file_name,
                    source_by_file[file_name],
                    runtime=workspace_runtime,
                    workspace=java_workspace,
                )
            )
        if java_workspace.get("units"):
            endpoints.extend(
                analyze_jax_recall(java_workspace, sys.modules[__name__])
            )
            endpoints.extend(
                analyze_jax_websocket(java_workspace, sys.modules[__name__])
            )

    return endpoints


# FLOW: main
# WHY: Implement the CLI boundary, error handling, logging configuration, analysis, additions, and CSV write.
# IN/OUT: Optional argv -> process-style exit code.
# CALL FLOW: The Python entry point calls it; build_argument_parser/analyze_module/write_csv execute downstream.
# EXAMPLE: A dependency or analysis error is logged and returns nonzero without emitting guessed rows.
def main(argv=None):
# CLI orchestration is intentionally thin: validate paths, initialize the
# adjacent diagnostic log, collect internal facts, project them to rows,
# normalize/deduplicate/sort once, and write the deterministic report.
    global input_srcdir, module_name, log_file

    argument_parser = build_argument_parser()
    args = argument_parser.parse_args(argv)
    input_path = Path(args.path).expanduser().resolve()
    if not input_path.is_dir():
        argument_parser.error("--path must be an existing directory")

    input_srcdir = str(input_path)
    module_name = input_path.name
    output_path = Path(args.output).expanduser()
    log_file = f"{output_path}.log"
    with open(log_file, "w", encoding="utf8"):
        pass

    write_log(
        f"Framework mode: {args.framework}"
        if args.framework
        else "Framework mode: spring and jaxrx"
    )
    try:
        endpoints = analyze_module(input_srcdir, args.framework)
    except RuntimeError as error:
        argument_parser.error(str(error))

    formatted_rows = [
        format_endpoint(endpoint, module_name, input_srcdir)
        for endpoint in endpoints
    ]
    rows = deduplicate_and_sort_rows(formatted_rows)
    write_csv(output_path, CSV_FIELDNAMES, rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
