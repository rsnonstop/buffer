"""Bounded Spring endpoint-recall extensions for :mod:`noir_sbt`.

The module deliberately does not import ``noir_sbt``.  The host module is
passed to :func:`analyze_spring_recall`, which keeps integration acyclic and
lets this implementation reuse the host's Java provenance and String
resolution rules.

Supported source shapes are intentionally small:

* Servlet/WebFlux ``@Bean RouterFunction`` return expressions using direct
  predicates, ``andRoute``, or the fixed-verb fluent builder; and
* canonical Servlet MVC ``@Configuration`` + ``@Autowired`` calls to
  ``RequestMappingHandlerMapping.registerMapping``.

Every decoder fails closed when activation, Java identity, data flow, path,
verb, or handler binding is not statically unambiguous.
"""

# Reader's guide
# --------------
# This module contains two distinct recall analyzers which share a method/type
# index but never share route grammar:
#
# * functional Servlet/WebFlux ``RouterFunction`` publication; and
# * explicit Servlet MVC ``registerMapping`` publication.
#
# Both are additive.  An annotated controller and a functional route in the
# same Java file are analyzed independently, avoiding the exclusive-fallback
# loss present in the inspected Noir implementation.
#
# Functional example:
#
#     @Bean
#     RouterFunction<ServerResponse> routes() {
#       return RouterFunctions.route()
#         .GET("/items/{id}", accept(APPLICATION_JSON), this::get)
#         .nest(path("/admin"), r -> r.DELETE("/items/{id}", this::delete))
#         .build();
#     }
#
# proves ``GET /items/{id}`` and ``DELETE /admin/items/{id}``.  The first
# predicate selects path and verb; ``accept(...)`` is validated as
# identity-neutral.  A second path or method predicate is not neutral and
# rejects the graph instead of being silently discarded.  A unique same-owner
# ``this::get`` binds concrete handler/formals.  A valid lambda or cross-owner
# variable reference proves publication but conservatively attributes the row
# to the @Bean publisher because this analyzer does not emulate javac target
# typing.
#
# Programmatic example:
#
#     @Configuration
#     class Routes {
#       @Autowired
#       void register(RequestMappingHandlerMapping mappings, Handler handler)
#           throws Exception {
#         RequestMappingInfo info = RequestMappingInfo.paths("/manual")
#             .methods(RequestMethod.POST).build();
#         Method method = Handler.class.getMethod("create", String.class);
#         mappings.registerMapping(info, handler, method);
#       }
#     }
#
# proves ``POST /manual`` only after all three arguments agree: the builder
# supplies path/verb, the handler formal resolves to the same source FQN named
# by the class literal, and reflection resolves one public exact parameter
# signature.  Inline expressions and one initialized, prior, single-write
# local are accepted.
#
# Precision boundary: framework types and annotations require genuine source
# provenance.  Functional graphs have explicit step/nest/route budgets and
# reject aliases, mutations, helper-returned routers, mixed Servlet/WebFlux
# families, dynamic identity, and non-straight-line flow.  Programmatic graphs
# require the canonical lifecycle and Servlet MVC builder; constructors,
# reactive mappings, control flow, unregister/re-register state, aliases,
# mutation, unsupported RequestMappingInfo conditions, ambiguous reflection,
# and classpath-only handlers fail closed.

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable


SPRING_CONTEXT_ANNOTATION_PACKAGE = "org.springframework.context.annotation"
SPRING_BEANS_ANNOTATION_PACKAGE = "org.springframework.beans.factory.annotation"

FUNCTIONAL_FAMILIES = {
    "webflux": "org.springframework.web.reactive.function.server",
    "servlet": "org.springframework.web.servlet.function",
}
FUNCTIONAL_VERBS = {
    "GET",
    "HEAD",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "OPTIONS",
}
FUNCTIONAL_MAX_CHAIN_STEPS = 256
FUNCTIONAL_MAX_NEST_DEPTH = 16
FUNCTIONAL_MAX_ROUTES = 4096

MVC_HANDLER_MAPPING_PACKAGE = "org.springframework.web.servlet.mvc.method.annotation"
MVC_REQUEST_MAPPING_INFO_PACKAGE = "org.springframework.web.servlet.mvc.method"
REFLECT_PACKAGE = "java.lang.reflect"

JAVA_LANG_TYPES = {
    "Boolean",
    "Byte",
    "Character",
    "Class",
    "Double",
    "Enum",
    "Float",
    "Integer",
    "Long",
    "Number",
    "Object",
    "Short",
    "String",
    "Throwable",
    "Void",
}

CONTROL_FLOW_NODES = {
    "do_statement",
    "enhanced_for_statement",
    "for_statement",
    "if_statement",
    "lambda_expression",
    "return_statement",
    "switch_expression",
    "switch_statement",
    "synchronized_statement",
    "throw_statement",
    "try_statement",
    "while_statement",
}


@dataclass(frozen=True)
# FLOW: FormalParameter
# WHY: Preserve each Java formal's name/type/varargs syntax for exact handler and lifecycle binding.
# IN/OUT: Constructed from parsed formal nodes; exposes immutable parameter evidence.
# CALL FLOW: `_formal_parameters` creates it; method indexing, reflection, and registration analysis consume it.
class FormalParameter:
    name: str
    type_node: Any
    node: Any
    varargs: bool = False


@dataclass(frozen=True)
# FLOW: MethodFact
# WHY: Carry one source method's ownership, syntax, modifiers, and formals consistently across both recall branches.
# IN/OUT: Constructed from workspace syntax; exposes immutable fact data and derived names.
# CALL FLOW: `_build_method_index` creates it; functional/programmatic decoders and endpoint attribution consume it.
class MethodFact:
    unit: dict[str, Any]
    owner_info: dict[str, Any]
    owner_fqn: str
    node: Any
    name_node: Any
    return_type_node: Any
    parameters_node: Any
    body_node: Any
    parameters: tuple[FormalParameter, ...]
    modifiers: frozenset[str]

    @property
# FLOW: MethodFact.name
# WHY: Recover the indexed method name from exact source once through a common accessor.
# IN/OUT: This fact's unit/name node in; method-name String out.
# CALL FLOW: Indexing, handler binding, reflection, logging, and endpoint attribution read it.
    def name(self) -> str:
        return _text(self.unit, self.name_node)

    @property
# FLOW: MethodFact.owner_name
# WHY: Centralize the lexical display owner used for resolution, diagnostics, and output.
# IN/OUT: This fact's owner metadata in; display-name String out.
# CALL FLOW: Nearly every recall decoder reads this leaf property when resolving owner-scoped evidence.
    def owner_name(self) -> str:
        return self.owner_info["display_name"]


@dataclass(frozen=True)
# FLOW: MethodIndex
# WHY: Keep exact owner/name method buckets so helper and handler resolution never becomes a global name guess.
# IN/OUT: Receives all MethodFacts and keyed tuples; exposes immutable index state.
# CALL FLOW: `_build_method_index` creates it; both functional and programmatic analyzers consume it.
class MethodIndex:
    methods: tuple[MethodFact, ...]
    by_owner_name: dict[tuple[str, str], tuple[MethodFact, ...]]


# FLOW: _text
# WHY: Preserve exact Java spelling for Tree-sitter evidence nodes.
# IN/OUT: Unit/node in; UTF-8 source slice out.
# CALL FLOW: All recall syntax, type, resolution, and attribution helpers use this leaf utility.
def _text(unit: dict[str, Any], node: Any) -> str:
    return unit["source"][node.start_byte : node.end_byte].decode("utf8")


# FLOW: _walk
# WHY: Traverse Java syntax deterministically without recursive Python stack growth.
# IN/OUT: Root syntax node in; pre-order node stream out.
# CALL FLOW: Method indexing, flow guards, call searches, and mutation checks consume this iterator.
def _walk(node: Any) -> Iterable[Any]:
    """Iteratively walk named nodes so deeply chained calls cannot recurse here."""
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


# FLOW: _field
# WHY: Isolate Tree-sitter named-field compatibility in the shared host.
# IN/OUT: Host/node/field name in; child node or None out.
# CALL FLOW: All recall decoders use this leaf helper to navigate syntax safely.
def _field(host: Any, node: Any, name: str) -> Any:
    return host.child_by_field(node, name)


# FLOW: _only_named_child
# WHY: Require wrapper statements/expressions to contain exactly one semantic child.
# IN/OUT: Syntax node in; sole child or None out.
# CALL FLOW: Parenthesis, return, and direct-expression helpers use it before deeper decoding.
def _only_named_child(node: Any) -> Any:
    children = [
        child
        for child in node.named_children
        if child.type not in {"line_comment", "block_comment"}
    ]
    return children[0] if len(children) == 1 else None


# FLOW: _unwrap_parentheses
# WHY: Accept harmless expression grouping while bounding malformed or excessively deep wrappers.
# IN/OUT: Possibly grouped node in; underlying node or None out.
# CALL FLOW: Functional, reflection, and registration decoders normalize inputs through this leaf helper.
def _unwrap_parentheses(node: Any) -> Any:
    current = node
    for _depth in range(16):
        if current is None or current.type != "parenthesized_expression":
            return current
        current = _only_named_child(current)
    return None


# FLOW: _arguments
# WHY: Distinguish valid invocation arguments from absent/malformed call syntax.
# IN/OUT: Host/invocation in; named argument nodes or None out.
# CALL FLOW: Every functional/programmatic call-shape decoder consumes this leaf result.
def _arguments(host: Any, invocation: Any) -> list[Any] | None:
    arguments = _field(host, invocation, "arguments")
    return (
        [
            child
            for child in arguments.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
        if arguments is not None
        else None
    )


# FLOW: _invocation_name
# WHY: Read call names consistently and fail closed for non-invocation syntax.
# IN/OUT: Host/unit/node in; simple invocation name or None out.
# CALL FLOW: Predicate, builder, reflection, and registration decoders use this leaf helper.
def _invocation_name(host: Any, unit: dict[str, Any], invocation: Any) -> str | None:
    if invocation is None or invocation.type != "method_invocation":
        return None
    name_node = _field(host, invocation, "name")
    return _text(unit, name_node) if name_node is not None else None


# FLOW: _formal_parameters
# WHY: Normalize supported Java formals into reusable exact parameter facts.
# IN/OUT: Host/unit/parameter-list in; FormalParameter tuple or None out.
# CALL FLOW: `_build_method_index` calls it; handler, lifecycle, and reflection binders consume facts.
def _formal_parameters(host: Any, unit: dict[str, Any], parameters_node: Any) -> tuple[FormalParameter, ...] | None:
    records: list[FormalParameter] = []
    for parameter in parameters_node.named_children:
        if parameter.type in {"line_comment", "block_comment"}:
            continue
        if parameter.type == "formal_parameter":
            type_node = _field(host, parameter, "type")
            name_node = _field(host, parameter, "name")
            if type_node is None or name_node is None:
                return None
            records.append(
                FormalParameter(_text(unit, name_node), type_node, parameter)
            )
            continue
        if parameter.type == "spread_parameter":
            declarators = [
                child
                for child in parameter.named_children
                if child.type == "variable_declarator"
            ]
            type_nodes = [
                child
                for child in parameter.named_children
                if child.type not in {"modifiers", "variable_declarator"}
            ]
            if len(declarators) != 1 or len(type_nodes) != 1:
                return None
            name_node = _field(host, declarators[0], "name")
            if name_node is None:
                return None
            records.append(
                FormalParameter(
                    _text(unit, name_node), type_nodes[0], parameter, varargs=True
                )
            )
            continue
        # Receiver parameters and syntactically unsupported forms are outside
        # the bounded source model.
        return None
    return tuple(records)


# FLOW: _build_method_index
# WHY: Parse/index source methods once for owner-scoped handler, helper, and reflected-method lookup.
# IN/OUT: Workspace/host in; MethodIndex out.
# CALL FLOW: `analyze_spring_recall` calls it; functional and programmatic branches share the result.
# Example: duplicate `create` names in different owners remain separate `(owner_fqn, name)` buckets.
def _build_method_index(workspace: dict[str, Any], host: Any) -> MethodIndex:
    # Index directly declared source methods by exact owner FQN and name.  The
    # later binders add arity/type constraints; duplicate or unsupported type
    # evidence is never resolved by scan order.
    methods: list[MethodFact] = []
    for fname in sorted(workspace["units"]):
        unit = workspace["units"][fname]
        for node in _walk(unit["tree"].root_node):
            if node.type != "method_declaration":
                continue
            parent = getattr(node, "parent", None)
            owner_node = host.nearest_enclosing_type(node)
            if (
                parent is None
                or parent.type != "class_body"
                or owner_node is None
                or getattr(parent, "parent", None) is None
                or host.tree_node_key(parent.parent) != host.tree_node_key(owner_node)
            ):
                continue
            owner_info = unit["type_infos"].get(host.tree_node_key(owner_node))
            if owner_info is None or not owner_info["workspace_visible"]:
                continue
            name_node = _field(host, node, "name")
            return_type_node = _field(host, node, "type")
            parameters_node = _field(host, node, "parameters")
            body_node = _field(host, node, "body")
            if None in (name_node, return_type_node, parameters_node, body_node):
                continue
            parameters = _formal_parameters(host, unit, parameters_node)
            if parameters is None:
                continue
            methods.append(
                MethodFact(
                    unit=unit,
                    owner_info=owner_info,
                    owner_fqn=host.qualified_type_name(unit, owner_info),
                    node=node,
                    name_node=name_node,
                    return_type_node=return_type_node,
                    parameters_node=parameters_node,
                    body_node=body_node,
                    parameters=parameters,
                    modifiers=frozenset(host.declaration_modifier_names(node)),
                )
            )

    methods.sort(key=lambda fact: (fact.unit["fname"], fact.node.start_byte))
    grouped: dict[tuple[str, str], list[MethodFact]] = {}
    for fact in methods:
        grouped.setdefault((fact.owner_fqn, fact.name), []).append(fact)
    return MethodIndex(
        methods=tuple(methods),
        by_owner_name={key: tuple(value) for key, value in grouped.items()},
    )


# FLOW: _log
# WHY: Make rejected recall/data-flow shapes visible without converting uncertainty into rows.
# IN/OUT: Host/unit/owner/reason/evidence in; no value out.
# CALL FLOW: Both analyzers call it; the host diagnostic stream consumes formatted messages.
def _log(host: Any, unit: dict[str, Any], owner: str, message: str, node: Any = None) -> None:
    expression = f": {_text(unit, node).strip()}" if node is not None else ""
    host.write_log(
        f"Skipped Spring recall {message} in {unit['fname']} for {owner}{expression}"
    )


# FLOW: _known_direct_annotation
# WHY: Prove exact direct Spring annotation provenance and optionally marker-only use.
# IN/OUT: Host/unit/declaration/expected identity in; annotation record or None out.
# CALL FLOW: Bean, Autowired, and Configuration activation gates call it before route decoding.
def _known_direct_annotation(
    host: Any,
    unit: dict[str, Any],
    declaration_node: Any,
    simple_name: str,
    package: str,
    *,
    marker_only: bool = False,
) -> Any:
    matches = []
    for record in host.direct_annotation_records(declaration_node):
        if (
            host.resolve_known_annotation(
                unit, record["name_node"], {simple_name}, (package,)
            )
            is not None
        ):
            matches.append(record)
    if len(matches) != 1:
        return None
    if marker_only and not host.annotation_has_no_values(matches[0]["node"]):
        return None
    return matches[0]


# FLOW: _raw_type_node
# WHY: Peel bounded generic/annotation wrappers before raw Java type identity checks.
# IN/OUT: Type syntax in; raw node or None out.
# CALL FLOW: Functional family, known-type, canonical-type, and source-type helpers consume it.
def _raw_type_node(node: Any) -> Any:
    current = node
    for _depth in range(16):
        if current is None:
            return None
        if current.type == "generic_type":
            children = list(current.named_children)
            current = children[0] if children else None
            continue
        if current.type == "annotated_type":
            candidates = [
                child for child in current.named_children if child.type != "annotation"
            ]
            current = candidates[-1] if len(candidates) == 1 else None
            continue
        return current
    return None


# FLOW: _known_type_node
# WHY: Prove a framework type belongs to one exact package rather than trusting its simple name.
# IN/OUT: Host/unit/type/expected identity in; Boolean verdict out.
# CALL FLOW: Functional family, mapping lifecycle, local-kind, and reflection gates call it.
def _known_type_node(
    host: Any,
    unit: dict[str, Any],
    type_node: Any,
    simple_name: str,
    package: str,
) -> bool:
    raw = _raw_type_node(type_node)
    return bool(
        raw is not None
        and host.resolve_known_type(
            unit, _text(unit, raw), simple_name, (package,), raw
        )
        == package
    )


# FLOW: _owner_is_concrete_class
# WHY: Restrict publisher/activation methods to concrete class owners capable of runtime publication.
# IN/OUT: MethodFact in; Boolean owner-category verdict out.
# CALL FLOW: Functional and Configuration activation gates use this leaf proof.
def _owner_is_concrete_class(fact: MethodFact) -> bool:
    return (
        fact.owner_info["node"].type == "class_declaration"
        and not fact.owner_info["abstract"]
        and fact.owner_info["workspace_visible"]
    )


# FLOW: _owner_is_unique
# WHY: Reject duplicate FQN ownership so method/annotation evidence has one deterministic source meaning.
# IN/OUT: Workspace/MethodFact in; Boolean uniqueness out.
# CALL FLOW: Both recall branches gate activation owners with this leaf helper.
def _owner_is_unique(workspace: dict[str, Any], fact: MethodFact) -> bool:
    declarations = workspace["type_declarations"].get(fact.owner_fqn, [])
    return bool(
        len(declarations) == 1
        and declarations[0]["unit"] is fact.unit
        and declarations[0]["type_info"] is fact.owner_info
    )


# FLOW: _method_variable_names
# WHY: Identify local/formal names that shadow unqualified static framework calls.
# IN/OUT: Host/MethodFact in; set of declared variable names out.
# CALL FLOW: `_unqualified_static_member_resolves` uses it before accepting a static-import call.
def _method_variable_names(host: Any, fact: MethodFact) -> set[str]:
    names = {parameter.name for parameter in fact.parameters}
    for node in _walk(fact.body_node):
        if node.type != "variable_declarator":
            continue
        name_node = _field(host, node, "name")
        if name_node is not None:
            names.add(_text(fact.unit, name_node))
    return names


# FLOW: _unqualified_static_member_resolves
# WHY: Prove an unqualified framework call via static imports while excluding variable shadowing.
# IN/OUT: Host/fact/member/expected owner/node in; Boolean provenance verdict out.
# CALL FLOW: `_call_has_owner` delegates here; predicate and builder owner checks consume the verdict.
def _unqualified_static_member_resolves(
    fact: MethodFact,
    member: str,
    expected_owner: str,
    method_index: MethodIndex,
) -> bool:
    # A member declared in the lexical class wins over a static import.
    if method_index.by_owner_name.get((fact.owner_fqn, member)):
        return False
    imports = fact.unit["imports"]
    if member in imports["static_exact"]:
        return imports["static_exact"][member] == f"{expected_owner}.{member}"
    if expected_owner not in imports["static_wildcards"]:
        return False
    # Without dependency bytecode, two on-demand owners are ambiguous for a
    # static method name.  An exact source model must not guess which declares
    # the member.
    return imports["static_wildcards"] == {expected_owner}


# FLOW: _call_has_owner
# WHY: Bind a call to an exact framework static owner or supported qualified type receiver.
# IN/OUT: Host/fact/call/member/owner/index in; Boolean ownership verdict out.
# CALL FLOW: Functional predicates/builders and RequestMappingInfo decoding call it before interpreting names.
def _call_has_owner(
    host: Any,
    fact: MethodFact,
    invocation: Any,
    member: str,
    expected_owner: str,
    method_index: MethodIndex,
) -> bool:
    if _invocation_name(host, fact.unit, invocation) != member:
        return False
    object_node = _field(host, invocation, "object")
    if object_node is None:
        return _unqualified_static_member_resolves(
            fact, member, expected_owner, method_index
        )
    if object_node.type not in {"identifier", "scoped_identifier"}:
        return False
    spelling = _text(fact.unit, object_node).strip()
    if object_node.type == "identifier" and spelling in _method_variable_names(host, fact):
        return False
    simple_name = expected_owner.rsplit(".", 1)[-1]
    package = expected_owner.rsplit(".", 1)[0]
    return (
        host.resolve_known_type(
            fact.unit, spelling, simple_name, (package,), object_node
        )
        == package
    )


# FLOW: _functional_family
# WHY: Select exactly one Servlet or WebFlux RouterFunction family before decoding parallel DSL names.
# IN/OUT: Host/publisher fact in; family package String or None out.
# CALL FLOW: `_analyze_functional` activates here; all downstream predicate/builder owner proofs use the family.
def _functional_family(host: Any, fact: MethodFact) -> str | None:
    # Servlet and WebFlux expose parallel simple names.  Resolve the raw return
    # type to exactly one package before interpreting any route/predicate call,
    # preventing mixed-family chains from acquiring accidental semantics.
    raw = _raw_type_node(fact.return_type_node)
    if raw is None:
        return None
    spelling = _text(fact.unit, raw)
    packages = tuple(FUNCTIONAL_FAMILIES.values())
    package = host.resolve_known_type(
        fact.unit, spelling, "RouterFunction", packages, raw
    )
    for family, expected_package in FUNCTIONAL_FAMILIES.items():
        if package == expected_package:
            return family
    return None


# FLOW: _single_direct_return
# WHY: Bound functional publication/helper flow to one direct return and reject nested competing returns.
# IN/OUT: MethodFact in; returned expression node or None out.
# CALL FLOW: Functional publisher analysis calls it before `_decode_functional_expression`.
# Example: `return route(...);` passes; `if (...) return ...;` does not.
def _single_direct_return(fact: MethodFact) -> Any:
    returns = [node for node in _walk(fact.body_node) if node.type == "return_statement"]
    direct = [
        node
        for node in fact.body_node.named_children
        if node.type == "return_statement"
    ]
    if len(returns) != 1 or len(direct) != 1 or returns[0] != direct[0]:
        return None
    return _only_named_child(direct[0])


# FLOW: _resolve_path
# WHY: Resolve a functional/programmatic path through the guarded workspace String graph.
# IN/OUT: Host/fact/workspace/expression in; normalized Spring path or None out.
# CALL FLOW: Predicate, builder-route, and RequestMappingInfo decoders call it; endpoint builders consume output.
def _resolve_path(host: Any, fact: MethodFact, workspace: dict[str, Any], node: Any) -> str | None:
    value = host.resolve_workspace_string_expression(
        fact.unit, node, workspace, fact.owner_name
    )
    if value is None:
        return None
    return host.combine_paths("", host.normalize_spring_path(value))


# FLOW: _direct_variable_initializer
# WHY: Resolve one unique same-owner final RequestPredicate field without
# implementing general reaching-definition or alias analysis.
# IN/OUT: Host, publisher fact, field name, required simple type/package ->
# initializer expression or None.
# CALL FLOW: `_valid_extra_predicate` calls it for an identifier predicate;
# recursive neutral-predicate validation consumes the initializer.
# Example: `static final RequestPredicate JSON = accept(APPLICATION_JSON);`
# may prove that `route(GET("/x").and(JSON), handler)` keeps GET `/x` identity.
def _direct_variable_initializer(
    host: Any,
    fact: MethodFact,
    name: str,
    simple_type: str,
    package: str,
) -> Any:
    """Resolve one directly declared, typed final-field initializer.

    This deliberately is not general Java data flow.  It exists so a common
    functional-route predicate such as ``static final RequestPredicate JSON =
    accept(...)`` can be proven route-identity-neutral without accepting an
    arbitrary identifier that might conceal another path or HTTP method.
    """
    candidates = []
    owner_body = _field(host, fact.owner_info["node"], "body")
    if owner_body is not None:
        for declaration in owner_body.named_children:
            if declaration.type != "field_declaration":
                continue
            if "final" not in host.declaration_modifier_names(declaration):
                continue
            type_node = _field(host, declaration, "type")
            if type_node is None or not _known_type_node(
                host, fact.unit, type_node, simple_type, package
            ):
                continue
            for declarator in declaration.named_children:
                if declarator.type != "variable_declarator":
                    continue
                name_node = _field(host, declarator, "name")
                value_node = _field(host, declarator, "value")
                if (
                    name_node is not None
                    and value_node is not None
                    and _text(fact.unit, name_node) == name
                ):
                    candidates.append(value_node)

    return candidates[0] if len(candidates) == 1 else None


# FLOW: _valid_extra_predicate
# WHY: Accept only identity-neutral extra predicates and reject hidden path/method selectors.
# IN/OUT: Context plus predicate expression in; Boolean validity out.
# CALL FLOW: Selecting-predicate and fluent builder argument decoders call it before retaining route identity.
# Example: `accept(APPLICATION_JSON)` is neutral; a second `path("/y")` is not.
def _valid_extra_predicate(
    host: Any,
    fact: MethodFact,
    family: str,
    node: Any,
    method_index: MethodIndex,
    *,
    depth: int = 0,
    resolving: frozenset[str] = frozenset(),
) -> bool:
    """Validate a predicate that cannot change the emitted path or verb."""
    if depth > FUNCTIONAL_MAX_NEST_DEPTH:
        return False
    current = _unwrap_parentheses(node)
    if current is None:
        return False
    package = FUNCTIONAL_FAMILIES[family]
    if current.type == "identifier":
        name = _text(fact.unit, current)
        if name in resolving or name in _method_variable_names(host, fact):
            return False
        initializer = _direct_variable_initializer(
            host, fact, name, "RequestPredicate", package
        )
        return bool(
            initializer is not None
            and _valid_extra_predicate(
                host,
                fact,
                family,
                initializer,
                method_index,
                depth=depth + 1,
                resolving=resolving | {name},
            )
        )
    if current.type != "method_invocation":
        return False

    name = _invocation_name(host, fact.unit, current)
    arguments = _arguments(host, current)
    receiver = _field(host, current, "object")
    if name in {"and", "or"}:
        return bool(
            receiver is not None
            and arguments is not None
            and len(arguments) == 1
            and _valid_extra_predicate(
                host,
                fact,
                family,
                receiver,
                method_index,
                depth=depth + 1,
                resolving=resolving,
            )
            and _valid_extra_predicate(
                host,
                fact,
                family,
                arguments[0],
                method_index,
                depth=depth + 1,
                resolving=resolving,
            )
        )
    if name == "negate":
        return bool(
            receiver is not None
            and arguments == []
            and _valid_extra_predicate(
                host,
                fact,
                family,
                receiver,
                method_index,
                depth=depth + 1,
                resolving=resolving,
            )
        )
    if name is None or arguments is None:
        return False
    # A second path/method predicate changes endpoint identity and cannot be
    # silently treated as metadata.  Header/media/query predicates are safe
    # to omit from the six-column endpoint identity.
    if name in FUNCTIONAL_VERBS or name in {"path", "method"}:
        return False
    expected_owner = f"{package}.RequestPredicates"
    return _call_has_owner(
        host, fact, current, name, expected_owner, method_index
    )


# FLOW: _bind_this_handler
# WHY: Bind `this::method` only to one non-static same-owner source method with
# exactly one formal, the bounded RouterFunction handler shape modeled here.
# IN/OUT: Publisher fact, method-reference node, and source index -> MethodFact
# or None; no arity argument is supplied or inferred.
# CALL FLOW: `_decode_handler` calls it; `_handler_endpoint` uses the concrete handler evidence when found.
def _bind_this_handler(
    host: Any,
    fact: MethodFact,
    node: Any,
    method_index: MethodIndex,
) -> MethodFact | None:
    current = _unwrap_parentheses(node)
    if current is None or current.type != "method_reference":
        return None
    children = list(current.named_children)
    if (
        len(children) != 2
        or children[0].type != "this"
        or children[1].type != "identifier"
    ):
        return None
    name = _text(fact.unit, children[1])
    candidates = method_index.by_owner_name.get((fact.owner_fqn, name), ())
    # Even differently aritied overloads can participate in Java method-
    # reference inference.  The bounded analyzer does not emulate javac.
    if len(candidates) != 1:
        return None
    candidate = candidates[0]
    if len(candidate.parameters) != 1 or "static" in candidate.modifiers:
        return None
    return candidate


# FLOW: _decode_handler
# WHY: Classify supported method references, lambdas, and handler variables without javac target typing guesses.
# IN/OUT: Handler expression plus context/arity in; bound MethodFact or conservative None out.
# CALL FLOW: Functional predicate/builder decoders call it; endpoint attribution consumes the optional binding.
def _decode_handler(
    host: Any,
    fact: MethodFact,
    node: Any,
    method_index: MethodIndex,
) -> tuple[bool, MethodFact | None]:
    """Accept valid bounded handler expressions and bind when exact.

    Cross-owner references and lambdas establish route publication but do not
    provide enough source identity to claim a concrete handler declaration.
    Those shapes intentionally return ``None`` so endpoint attribution falls
    back to the publishing ``@Bean`` method.
    """
    current = _unwrap_parentheses(node)
    if current is None:
        return False, None
    if current.type == "lambda_expression":
        return True, None
    if current.type != "method_reference":
        return False, None
    children = list(current.named_children)
    if len(children) != 2 or children[1].type != "identifier":
        return False, None
    if children[0].type == "this":
        name = _text(fact.unit, children[1])
        if not method_index.by_owner_name.get((fact.owner_fqn, name)):
            return False, None
        return True, _bind_this_handler(host, fact, current, method_index)
    if children[0].type == "identifier":
        qualifier = _text(fact.unit, children[0])
        if qualifier not in _method_variable_names(host, fact):
            return False, None
        return True, None
    return False, None


# FLOW: _decode_selecting_predicate
# WHY: Decode one genuine RequestPredicates verb selector plus path and neutral trailing predicates.
# IN/OUT: Predicate invocation/context in; `(verb, path)` or None out.
# CALL FLOW: `_decode_predicate` and functional publication decoding call it; handler tuples consume identity.
# Example: `GET("/items", accept(JSON))` yields GET plus `/items`.
def _decode_selecting_predicate(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
    selector: str,
) -> str | None:
    """Decode ``SELECTOR(path).and(route-neutral-predicate)...``."""
    current = _unwrap_parentheses(node)
    for _depth in range(FUNCTIONAL_MAX_NEST_DEPTH + 1):
        if current is None or current.type != "method_invocation":
            return None
        if _invocation_name(host, fact.unit, current) != "and":
            break
        arguments = _arguments(host, current)
        receiver = _field(host, current, "object")
        if (
            arguments is None
            or len(arguments) != 1
            or receiver is None
            or not _valid_extra_predicate(
                host, fact, family, arguments[0], method_index
            )
        ):
            return None
        current = _unwrap_parentheses(receiver)
    else:
        return None

    expected_owner = f"{FUNCTIONAL_FAMILIES[family]}.RequestPredicates"
    if not _call_has_owner(
        host, fact, current, selector, expected_owner, method_index
    ):
        return None
    arguments = _arguments(host, current)
    if arguments is None or len(arguments) != 1:
        return None
    return _resolve_path(host, fact, workspace, arguments[0])


# FLOW: _decode_predicate
# WHY: Normalize supported direct selector and bounded neutral-composition predicate forms.
# IN/OUT: Predicate expression/context in; `(verb, path)` or None out.
# CALL FLOW: Static `route(predicate, handler)` decoding calls it before handler binding.
def _decode_predicate(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
) -> tuple[str, str] | None:
    invocation = _unwrap_parentheses(node)
    while (
        invocation is not None
        and invocation.type == "method_invocation"
        and _invocation_name(host, fact.unit, invocation) == "and"
    ):
        receiver = _field(host, invocation, "object")
        if receiver is None:
            return None
        invocation = _unwrap_parentheses(receiver)
    verb = _invocation_name(host, fact.unit, invocation)
    if verb not in FUNCTIONAL_VERBS:
        return None
    path = _decode_selecting_predicate(
        host, fact, workspace, family, node, method_index, verb
    )
    return (verb, path) if path is not None else None


# FLOW: _lambda_parameter_and_body
# WHY: Bind one supported lambda receiver and expose its body without inferring multi-parameter flow.
# IN/OUT: Host/fact/lambda in; `(parameter_name, body_node)` or None out.
# CALL FLOW: Nest and fluent-builder decoders call it; builder-chain recursion consumes both values.
def _lambda_parameter_and_body(
    host: Any, fact: MethodFact, node: Any
) -> tuple[str, Any] | None:
    current = _unwrap_parentheses(node)
    if current is None or current.type != "lambda_expression":
        return None
    parameters = _field(host, current, "parameters")
    body = _field(host, current, "body")
    if parameters is None or body is None or parameters.type != "identifier":
        return None
    return _text(fact.unit, parameters), body


# FLOW: _decode_builder_route_arguments
# WHY: Decode one fluent verb step's path, neutral predicates, and terminal handler atomically.
# IN/OUT: Builder call arguments/context in; `(path, handler_fact)` or None out.
# CALL FLOW: `_decode_builder_chain` calls it for GET/POST/etc.; route tuple accumulation consumes output.
def _decode_builder_route_arguments(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    invocation: Any,
    method_index: MethodIndex,
) -> tuple[str, MethodFact | None] | None:
    arguments = _arguments(host, invocation)
    if arguments is None or len(arguments) not in {2, 3}:
        return None
    if len(arguments) == 3 and not _valid_extra_predicate(
        host, fact, family, arguments[1], method_index
    ):
        return None
    handler_node = arguments[-1]
    valid_handler, handler = _decode_handler(
        host, fact, handler_node, method_index
    )
    path = _resolve_path(host, fact, workspace, arguments[0])
    if not valid_handler or path is None:
        return None
    return path, handler


# FLOW: _decode_builder_chain
# WHY: Interpret a bounded fluent RouterFunctions builder with immutable branch-local nest prefixes.
# IN/OUT: Builder expression/root/prefix/context/budget in; validity plus route tuples out.
# CALL FLOW: `_decode_builder` starts it and nest lambdas recurse into it; functional analyzer consumes routes.
# Example: `.nest(path("/admin"), r -> r.DELETE("/x", h))` yields DELETE `/admin/x`.
def _decode_builder_chain(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
    *,
    prefix: str = "",
    base_alias: str | None = None,
    nest_depth: int = 0,
    budget: dict[str, int] | None = None,
) -> tuple[bool, list[tuple[str, str, MethodFact | None, Any]]]:
    # Decode receivers from the builder root outward.  ``prefix`` is immutable
    # branch state: entering nest(path("/v1"), r -> ...) creates a child prefix
    # without changing sibling routes.  In block consumers every statement
    # must be a direct chain rooted at the exact lambda receiver; declarations,
    # assignment, return, or control flow would require reaching-definition
    # analysis and therefore reject the block.
    budget = budget if budget is not None else {"steps": 0, "routes": 0}
    budget["steps"] += 1
    if (
        budget["steps"] > FUNCTIONAL_MAX_CHAIN_STEPS
        or nest_depth > FUNCTIONAL_MAX_NEST_DEPTH
    ):
        return False, []
    current = _unwrap_parentheses(node)
    if current is None:
        return False, []
    if current.type == "block" and base_alias is not None:
        routes: list[tuple[str, str, MethodFact | None, Any]] = []
        for statement in current.named_children:
            if statement.type in {"line_comment", "block_comment"}:
                continue
            if statement.type != "expression_statement":
                return False, []
            expression = _only_named_child(statement)
            if expression is None:
                return False, []
            valid, statement_routes = _decode_builder_chain(
                host,
                fact,
                workspace,
                family,
                expression,
                method_index,
                prefix=prefix,
                base_alias=base_alias,
                nest_depth=nest_depth,
                budget=budget,
            )
            if not valid:
                return False, []
            routes.extend(statement_routes)
        return True, routes
    if base_alias is not None and current.type == "identifier":
        return (_text(fact.unit, current) == base_alias), []
    if current.type != "method_invocation":
        return False, []

    name = _invocation_name(host, fact.unit, current)
    receiver = _field(host, current, "object")
    if name == "route" and base_alias is None:
        expected_owner = f"{FUNCTIONAL_FAMILIES[family]}.RouterFunctions"
        return bool(
            _call_has_owner(
                host, fact, current, "route", expected_owner, method_index
            )
            and _arguments(host, current) == []
        ), []
    if receiver is None:
        return False, []

    valid, decoded = _decode_builder_chain(
        host,
        fact,
        workspace,
        family,
        receiver,
        method_index,
        prefix=prefix,
        base_alias=base_alias,
        nest_depth=nest_depth,
        budget=budget,
    )
    if not valid:
        return False, []

    if name in FUNCTIONAL_VERBS:
        route = _decode_builder_route_arguments(
            host, fact, workspace, family, current, method_index
        )
        if route is None:
            return False, []
        path, handler = route
        budget["routes"] += 1
        if budget["routes"] > FUNCTIONAL_MAX_ROUTES:
            return False, []
        decoded.append(
            (name, host.combine_paths(prefix, path), handler, current)
        )
        return True, decoded

    if name != "nest":
        return False, []
    arguments = _arguments(host, current)
    if arguments is None or len(arguments) != 2:
        return False, []
    nested_path = _decode_selecting_predicate(
        host,
        fact,
        workspace,
        family,
        arguments[0],
        method_index,
        "path",
    )
    lambda_parts = _lambda_parameter_and_body(host, fact, arguments[1])
    if nested_path is None or lambda_parts is None:
        return False, []
    alias, body = lambda_parts
    nested_prefix = host.combine_paths(prefix, nested_path)
    nested_valid, nested_routes = _decode_builder_chain(
        host,
        fact,
        workspace,
        family,
        body,
        method_index,
        prefix=nested_prefix,
        base_alias=alias,
        nest_depth=nest_depth + 1,
        budget=budget,
    )
    if not nested_valid:
        return False, []
    return True, decoded + nested_routes


# FLOW: _decode_builder
# WHY: Prove a complete `RouterFunctions.route()...build()` root before fluent-chain interpretation.
# IN/OUT: Build invocation/context/prefix/depth/budget in; validity and route tuples out.
# CALL FLOW: Functional-expression dispatcher calls it; it delegates to `_decode_builder_chain`.
def _decode_builder(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    build_call: Any,
    method_index: MethodIndex,
) -> tuple[bool, list[tuple[str, str, MethodFact | None, Any]]]:
    if _arguments(host, build_call) != []:
        return False, []
    receiver = _field(host, build_call, "object")
    if receiver is None:
        return False, []
    return _decode_builder_chain(
        host, fact, workspace, family, receiver, method_index
    )


# FLOW: _decode_functional_expression
# WHY: Dispatch among supported direct route, andRoute, nest, and fluent publication grammars atomically.
# IN/OUT: Publisher expression/context/family/depth/budget in; validity and complete route tuples out.
# CALL FLOW: `_analyze_functional` starts here; recursive composition and builder/predicate/handler decoders feed it.
# Example: any unsupported branch returns false so a partial RouterFunction is never presented as complete.
def _decode_functional_expression(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    family: str,
    node: Any,
    method_index: MethodIndex,
    *,
    nest_depth: int = 0,
) -> tuple[bool, list[tuple[str, str, MethodFact | None, Any]]]:
    # This dispatcher accepts the three published graph families:
    # direct route(predicate, handler), chained andRoute, and fluent
    # route()...build(), plus bounded static/qualified nest composition.
    # Returning (False, []) is atomic for the @Bean graph so a partially
    # decoded router is never presented as its complete runtime publication.
    invocation = _unwrap_parentheses(node)
    if invocation is None or invocation.type != "method_invocation":
        return False, []
    name = _invocation_name(host, fact.unit, invocation)
    if name == "build":
        return _decode_builder(
            host, fact, workspace, family, invocation, method_index
        )
    if name == "andRoute":
        arguments = _arguments(host, invocation)
        receiver = _field(host, invocation, "object")
        if receiver is None or arguments is None or len(arguments) != 2:
            return False, []
        valid, routes = _decode_functional_expression(
            host,
            fact,
            workspace,
            family,
            receiver,
            method_index,
            nest_depth=nest_depth,
        )
        predicate = _decode_predicate(
            host, fact, workspace, family, arguments[0], method_index
        )
        valid_handler, handler = _decode_handler(
            host, fact, arguments[1], method_index
        )
        if not valid or predicate is None or not valid_handler:
            return False, []
        verb, path = predicate
        return True, routes + [(verb, path, handler, invocation)]
    expected_owner = f"{FUNCTIONAL_FAMILIES[family]}.RouterFunctions"
    if name == "nest":
        if nest_depth >= FUNCTIONAL_MAX_NEST_DEPTH or not _call_has_owner(
            host, fact, invocation, "nest", expected_owner, method_index
        ):
            return False, []
        arguments = _arguments(host, invocation)
        if arguments is None or len(arguments) != 2:
            return False, []
        nested_path = _decode_selecting_predicate(
            host,
            fact,
            workspace,
            family,
            arguments[0],
            method_index,
            "path",
        )
        if nested_path is None:
            return False, []
        valid, routes = _decode_functional_expression(
            host,
            fact,
            workspace,
            family,
            arguments[1],
            method_index,
            nest_depth=nest_depth + 1,
        )
        if not valid:
            return False, []
        return True, [
            (verb, host.combine_paths(nested_path, path), handler, route_node)
            for verb, path, handler, route_node in routes
        ]
    if name != "route":
        return False, []
    if not _call_has_owner(
        host, fact, invocation, "route", expected_owner, method_index
    ):
        return False, []
    arguments = _arguments(host, invocation)
    if arguments is None or len(arguments) != 2:
        return False, []
    predicate = _decode_predicate(
        host, fact, workspace, family, arguments[0], method_index
    )
    valid_handler, handler = _decode_handler(
        host, fact, arguments[1], method_index
    )
    if predicate is None or not valid_handler:
        return False, []
    verb, path = predicate
    return True, [(verb, path, handler, invocation)]


# FLOW: _handler_endpoint
# WHY: Convert one proven functional/programmatic identity into the shared endpoint fact schema.
# IN/OUT: Verb/path/optional handler/publisher/evidence in; endpoint dictionary out.
# CALL FLOW: Both recall branches call it; Spring configuration, deduplication, and host output consume rows.
def _handler_endpoint(
    host: Any,
    method: str,
    path: str,
    handler: MethodFact | None,
    *,
    publisher: MethodFact | None = None,
    route_node: Any = None,
) -> dict[str, Any]:
    # Route evidence belongs to the @Bean/registration publisher; handler
    # evidence belongs to the exactly bound method when available.  Keeping
    # ProjectSrcFile on the publisher also gives the configuration pass the
    # correct owning project for an indirect route.
    publisher = publisher or handler
    if publisher is None:
        raise ValueError("Spring route endpoint requires publisher evidence")
    effective_handler = handler or publisher
    route_node = publisher.node if route_node is None else route_node
    endpoint = {
        "uri": path,
        "method": method,
        "uri_params": host.get_callable_parameters_as_is(
            effective_handler.unit["source"], effective_handler.parameters_node
        ),
        "SrcFile": effective_handler.unit["fname"],
        "SrcLine": effective_handler.node.start_point.row + 1,
        "SFunction": f"{effective_handler.owner_name}.{effective_handler.name}",
        "RouteSrcFile": publisher.unit["fname"],
        "RouteSrcLine": route_node.start_point.row + 1,
        "HandlerSrcFile": effective_handler.unit["fname"],
        "HandlerSrcLine": effective_handler.node.start_point.row + 1,
        "ProjectSrcFile": publisher.unit["fname"],
        "technology": "spring",
        "protocol": "http",
        "surface": "server",
        "direction": "inbound",
    }
    host.debug_log(endpoint)
    return endpoint


# FLOW: _analyze_functional
# WHY: Activate and decode genuine Bean RouterFunction publications independently of annotations.
# IN/OUT: Workspace/host/shared MethodIndex in; raw functional endpoint list out.
# CALL FLOW: Public recall calls it; family/return/expression decoders feed it and `_handler_endpoint` materializes rows.
def _analyze_functional(
    workspace: dict[str, Any], host: Any, method_index: MethodIndex
) -> list[dict[str, Any]]:
    # Activation is deliberately stronger than seeing a method named route:
    # unique concrete owner + genuine direct @Bean + one genuine RouterFunction
    # return family + one direct return-expression graph.
    endpoints: list[dict[str, Any]] = []
    for fact in method_index.methods:
        if not _owner_is_concrete_class(fact) or not _owner_is_unique(
            workspace, fact
        ):
            continue
        bean = _known_direct_annotation(
            host,
            fact.unit,
            fact.node,
            "Bean",
            SPRING_CONTEXT_ANNOTATION_PACKAGE,
        )
        if bean is None:
            continue
        family = _functional_family(host, fact)
        if family is None:
            _log(host, fact.unit, fact.owner_name, "@Bean with unsupported RouterFunction type", fact.return_type_node)
            continue
        return_expression = _single_direct_return(fact)
        if return_expression is None:
            _log(host, fact.unit, fact.owner_name, "functional route with non-direct return flow", fact.node)
            continue
        valid, routes = _decode_functional_expression(
            host,
            fact,
            workspace,
            family,
            return_expression,
            method_index,
        )
        if not valid or not routes:
            _log(host, fact.unit, fact.owner_name, "unsupported functional route expression", return_expression)
            continue
        for verb, path, handler, route_node in routes:
            endpoints.append(
                _handler_endpoint(
                    host,
                    verb,
                    path,
                    handler,
                    publisher=fact,
                    route_node=route_node,
                )
            )
    return endpoints


# FLOW: _resolve_source_type
# WHY: Bind a Java type expression to one unique accessible workspace source FQN.
# IN/OUT: Host/unit/type/owner/workspace in; FQN or None out.
# CALL FLOW: Reflection owner and handler-formal checks call it before agreeing on programmatic target identity.
def _resolve_source_type(
    host: Any,
    unit: dict[str, Any],
    type_node: Any,
    owner_name: str,
    workspace: dict[str, Any],
) -> str | None:
    raw = _raw_type_node(type_node)
    if raw is None:
        return None
    candidates = host.resolve_workspace_owner_fqns(
        unit, _text(unit, raw).strip(), owner_name, workspace
    )
    if len(candidates) != 1:
        return None
    fqn = candidates[0]
    declarations = workspace["type_declarations"].get(fqn, [])
    if len(declarations) != 1:
        return None
    return (
        fqn
        if host.workspace_type_accessible(declarations[0], unit, owner_name)
        else None
    )


# FLOW: _canonical_named_type
# WHY: Canonicalize a non-array Java type from source, imports, qualification, or java.lang without guessing wildcards.
# IN/OUT: Host/unit/node/owner/workspace in; canonical FQN or None out.
# CALL FLOW: `_canonical_type` delegates here; reflected signature matching consumes the canonical String.
def _canonical_named_type(
    host: Any,
    unit: dict[str, Any],
    node: Any,
    owner_name: str,
    workspace: dict[str, Any],
) -> str | None:
    spelling = _text(unit, node).strip()
    source_candidates = host.resolve_workspace_owner_fqns(
        unit, spelling, owner_name, workspace
    )
    if len(source_candidates) == 1:
        return source_candidates[0]
    if source_candidates:
        return None

    if "." in spelling:
        first, suffix = spelling.split(".", 1)
        imported = unit["imports"]["exact"].get(first)
        if imported:
            return f"{imported}.{suffix}"
        # A lower-case leading package segment is an explicitly qualified
        # external identity.  Upper-case relative nested types require source
        # resolution and were rejected above.
        if first and first[0].islower():
            return spelling
        return None

    imported = unit["imports"]["exact"].get(spelling)
    if imported:
        return imported
    if spelling in JAVA_LANG_TYPES:
        return f"java.lang.{spelling}"
    return None


# FLOW: _canonical_type
# WHY: Produce reflection-comparable canonical primitive/reference/array/varargs parameter identities.
# IN/OUT: Type syntax and resolution context in; canonical type String or None out.
# CALL FLOW: Class-literal and source-method signature decoders call it before exact list comparison.
# Example: `String...` and reflected `String[].class` canonicalize to compatible array spelling.
def _canonical_type(
    host: Any,
    unit: dict[str, Any],
    type_node: Any,
    owner_name: str,
    workspace: dict[str, Any],
    *,
    varargs: bool = False,
) -> str | None:
    node = _raw_type_node(type_node)
    if node is None:
        return None
    suffix = "[]" if varargs else ""
    if node.type == "array_type":
        element = _field(host, node, "element")
        if element is None:
            return None
        base = _canonical_type(host, unit, element, owner_name, workspace)
        dimensions = sum(
            max(1, _text(unit, child).count("["))
            for child in node.named_children
            if child.type == "dimensions"
        )
        return f"{base}{'[]' * dimensions}{suffix}" if base is not None else None
    if node.type in {
        "boolean_type",
        "floating_point_type",
        "integral_type",
        "void_type",
    }:
        return f"{_text(unit, node).strip()}{suffix}"
    if node.type not in {"type_identifier", "scoped_type_identifier"}:
        return None
    base = _canonical_named_type(host, unit, node, owner_name, workspace)
    return f"{base}{suffix}" if base is not None else None


# FLOW: _class_literal_type
# WHY: Restrict reflected parameter evidence to genuine Java `.class` literal syntax.
# IN/OUT: Class-literal expression/context in; canonical type String or None out.
# CALL FLOW: `_decode_reflected_method` calls it for every getMethod parameter literal.
def _class_literal_type(
    host: Any,
    unit: dict[str, Any],
    node: Any,
    owner_name: str,
    workspace: dict[str, Any],
) -> str | None:
    current = _unwrap_parentheses(node)
    if current is None or current.type != "class_literal":
        return None
    children = list(current.named_children)
    if len(children) != 1:
        return None
    return _canonical_type(
        host, unit, children[0], owner_name, workspace
    )


# FLOW: _decode_reflected_method
# WHY: Bind `Source.class.getMethod(...)` to one exact public non-static workspace method.
# IN/OUT: Activation/workspace/index/expression in; `(MethodFact, owner_fqn)` or None out.
# CALL FLOW: Registration analysis calls it; handler-argument agreement and endpoint attribution consume result.
# Example: `Handler.class.getMethod("create", String.class)` must match exactly one source signature.
def _decode_reflected_method(
    host: Any,
    activation: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    node: Any,
) -> tuple[MethodFact, str] | None:
    # Decode ``SourceHandler.class.getMethod(name, parameterClassLiterals...)``.
    # Java's public reflection contract is mirrored narrowly: owner, method
    # name, and canonical source parameter types must resolve to exactly one
    # public non-static source method.
    invocation = _unwrap_parentheses(node)
    if _invocation_name(host, activation.unit, invocation) != "getMethod":
        return None
    object_node = _field(host, invocation, "object")
    arguments = _arguments(host, invocation)
    if (
        object_node is None
        or object_node.type != "class_literal"
        or arguments is None
        or not arguments
    ):
        return None
    owner_children = list(object_node.named_children)
    if len(owner_children) != 1:
        return None
    target_fqn = _resolve_source_type(
        host,
        activation.unit,
        owner_children[0],
        activation.owner_name,
        workspace,
    )
    if target_fqn is None:
        return None
    target_declarations = workspace["type_declarations"].get(target_fqn, [])
    target_info = target_declarations[0]["type_info"]
    if target_info["node"].type != "class_declaration" or target_info["abstract"]:
        return None

    method_name = host.resolve_workspace_string_expression(
        activation.unit,
        arguments[0],
        workspace,
        activation.owner_name,
    )
    if not method_name:
        return None
    reflected_parameters: list[str] = []
    for argument in arguments[1:]:
        canonical = _class_literal_type(
            host,
            activation.unit,
            argument,
            activation.owner_name,
            workspace,
        )
        if canonical is None:
            return None
        reflected_parameters.append(canonical)

    matches: list[MethodFact] = []
    for candidate in method_index.by_owner_name.get((target_fqn, method_name), ()):
        if "public" not in candidate.modifiers or "static" in candidate.modifiers:
            continue
        canonical_parameters = [
            _canonical_type(
                host,
                candidate.unit,
                parameter.type_node,
                candidate.owner_name,
                workspace,
                varargs=parameter.varargs,
            )
            for parameter in candidate.parameters
        ]
        if None in canonical_parameters:
            continue
        if canonical_parameters == reflected_parameters:
            matches.append(candidate)
    return (matches[0], target_fqn) if len(matches) == 1 else None


# FLOW: _decode_mapping_info
# WHY: Decode only identity-complete Servlet RequestMappingInfo path/method builder grammar.
# IN/OUT: Activation/workspace/index/expression in; unique paths/methods or None out.
# CALL FLOW: Registration analysis calls it; Cartesian endpoint creation consumes output.
# Example: `.paths("/x").methods(POST).build()` passes; `.headers(...)` rejects.
def _decode_mapping_info(
    host: Any,
    activation: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    node: Any,
) -> tuple[list[str], list[str]] | None:
    # Accepted builder grammar is exactly:
    #
    #   RequestMappingInfo.paths(paths...)[.methods(methods...)].build()
    #
    # Omitting methods means ANY.  Additional conditions such as params,
    # headers, consumes, or produces can affect dispatch; ignoring them would
    # overstate identity, so their presence makes the shape unsupported.
    build_call = _unwrap_parentheses(node)
    if _invocation_name(host, activation.unit, build_call) != "build":
        return None
    if _arguments(host, build_call) != []:
        return None
    current = _field(host, build_call, "object")
    methods: list[str] = []
    if _invocation_name(host, activation.unit, current) == "methods":
        method_arguments = _arguments(host, current)
        if not method_arguments:
            return None
        for argument in method_arguments:
            value = host.resolve_spring_request_method_expression(
                activation.unit["source"],
                argument,
                activation.unit["imports"],
                unit=activation.unit,
            )
            if value is None:
                return None
            methods.append(value)
        current = _field(host, current, "object")
    if _invocation_name(host, activation.unit, current) != "paths":
        return None
    expected_owner = f"{MVC_REQUEST_MAPPING_INFO_PACKAGE}.RequestMappingInfo"
    if not _call_has_owner(
        host,
        activation,
        current,
        "paths",
        expected_owner,
        method_index,
    ):
        return None
    path_arguments = _arguments(host, current)
    if not path_arguments:
        return None
    paths: list[str] = []
    for argument in path_arguments:
        path = _resolve_path(host, activation, workspace, argument)
        if path is None:
            return None
        paths.append(path)
    return list(dict.fromkeys(paths)), list(dict.fromkeys(methods or ["ANY"]))


# FLOW: _local_declarators
# WHY: Normalize variable-declarator children for tracked straight-line locals.
# IN/OUT: Host/local declaration in; declarator nodes out.
# CALL FLOW: Registration local indexing and mutation checks consume this leaf helper.
def _local_declarators(host: Any, local: Any) -> list[Any]:
    return [
        child for child in local.named_children if child.type == "variable_declarator"
    ]


# FLOW: _tracked_local_kind
# WHY: Track only genuine RequestMappingInfo and reflection Method locals relevant to endpoint identity.
# IN/OUT: Host/activation/local declaration in; `info`, `method`, or None out.
# CALL FLOW: Registration analysis classifies direct locals here before reaching-definition checks.
def _tracked_local_kind(host: Any, activation: MethodFact, local: Any) -> str | None:
    type_node = _field(host, local, "type")
    if type_node is None:
        return None
    if _known_type_node(
        host,
        activation.unit,
        type_node,
        "RequestMappingInfo",
        MVC_REQUEST_MAPPING_INFO_PACKAGE,
    ):
        return "info"
    if _known_type_node(
        host, activation.unit, type_node, "Method", REFLECT_PACKAGE
    ):
        return "method"
    return None


# FLOW: _direct_expression
# WHY: Require publication calls to be top-level expression statements in straight-line method flow.
# IN/OUT: Host/statement in; sole expression or None out.
# CALL FLOW: Registration analysis uses it to index exact direct registerMapping statements.
def _direct_expression(host: Any, statement: Any) -> Any:
    if statement.type != "expression_statement":
        return None
    return _only_named_child(statement)


# FLOW: _mapping_invocations
# WHY: Find exact calls on the proven RequestMappingHandlerMapping formal, not same-named calls elsewhere.
# IN/OUT: Host/activation/receiver/call name in; matching invocation nodes out.
# CALL FLOW: Registration analysis queries register/unregister calls before direct-flow validation.
def _mapping_invocations(
    host: Any, activation: MethodFact, mapping_name: str, call_name: str
) -> list[Any]:
    calls = []
    for node in _walk(activation.body_node):
        if _invocation_name(host, activation.unit, node) != call_name:
            continue
        receiver = _field(host, node, "object")
        if (
            receiver is not None
            and receiver.type == "identifier"
            and _text(activation.unit, receiver) == mapping_name
        ):
            calls.append(node)
    return calls


# FLOW: _has_tracked_mutation
# WHY: Reject assignments, updates, or nested shadow declarations that make tracked values ambiguous.
# IN/OUT: Host/activation/protected names/direct locals in; Boolean mutation verdict out.
# CALL FLOW: Registration analysis gates the complete activation method with this helper before decoding calls.
def _has_tracked_mutation(
    host: Any, activation: MethodFact, tracked_names: set[str], direct_locals: set[tuple[int, int]]
) -> bool:
    for node in _walk(activation.body_node):
        if node.type == "local_variable_declaration":
            for declarator in _local_declarators(host, node):
                name_node = _field(host, declarator, "name")
                if (
                    name_node is not None
                    and _text(activation.unit, name_node) in tracked_names
                    and (node.start_byte, node.end_byte) not in direct_locals
                ):
                    return True
        if node.type == "assignment_expression":
            left = _field(host, node, "left")
            if (
                left is not None
                and left.type == "identifier"
                and _text(activation.unit, left) in tracked_names
            ):
                return True
        if node.type == "update_expression":
            for child in node.named_children:
                if child.type == "identifier" and _text(activation.unit, child) in tracked_names:
                    return True
    return False


# FLOW: _resolve_local_argument
# WHY: Resolve an inline expression or one prior typed single-write local at a registration use site.
# IN/OUT: Unit/expression/expected kind/local index/statement position in; value node or None out.
# CALL FLOW: Registration analysis resolves mapping-info and reflected-method arguments through this helper.
def _resolve_local_argument(
    unit: dict[str, Any],
    node: Any,
    expected_kind: str,
    locals_by_name: dict[str, tuple[str, Any, int]],
    statement_index: int,
) -> Any:
    current = _unwrap_parentheses(node)
    if current is None or current.type != "identifier":
        return current
    record = locals_by_name.get(_text(unit, current))
    if record is None:
        return None
    kind, value, declaration_index = record
    return value if kind == expected_kind and declaration_index < statement_index else None


# FLOW: _configuration_owner
# WHY: Activate programmatic registration only inside a concrete genuine Spring Configuration source owner.
# IN/OUT: Host/MethodFact in; Boolean activation-owner verdict out.
# CALL FLOW: `_analyze_programmatic` caches this per owner before scanning Autowired lifecycle methods.
def _configuration_owner(host: Any, fact: MethodFact) -> bool:
    return bool(
        _owner_is_concrete_class(fact)
        and _known_direct_annotation(
            host,
            fact.unit,
            fact.owner_info["node"],
            "Configuration",
            SPRING_CONTEXT_ANNOTATION_PACKAGE,
        )
        is not None
    )


# FLOW: _analyze_registration_method
# WHY: Interpret one Autowired method as a bounded straight-line registerMapping data-flow program.
# IN/OUT: Workspace/host/index/activation fact in; programmatic endpoint rows out.
# CALL FLOW: `_analyze_programmatic` calls it; local/reflection/mapping decoders feed atomic `_handler_endpoint` creation.
# Example: prior single-write `RequestMappingInfo` and `Method` locals may feed one direct three-argument registration.
def _analyze_registration_method(
    workspace: dict[str, Any], host: Any, method_index: MethodIndex, activation: MethodFact
) -> list[dict[str, Any]]:
    # Treat the canonical method body as a small straight-line data-flow
    # program.  First prove activation and forbid unregister/control flow;
    # next index direct typed locals with declaration order; then bind each
    # direct registerMapping call atomically.  Assignments, duplicate locals,
    # shadowing, and nested calls invalidate the relevant proof rather than
    # choosing a reaching value heuristically.
    if "static" in activation.modifiers or _text(activation.unit, activation.return_type_node).strip() != "void":
        return []
    autowired = _known_direct_annotation(
        host,
        activation.unit,
        activation.node,
        "Autowired",
        SPRING_BEANS_ANNOTATION_PACKAGE,
        marker_only=True,
    )
    if autowired is None:
        return []
    mapping_parameters = [
        parameter
        for parameter in activation.parameters
        if _known_type_node(
            host,
            activation.unit,
            parameter.type_node,
            "RequestMappingHandlerMapping",
            MVC_HANDLER_MAPPING_PACKAGE,
        )
    ]
    if len(mapping_parameters) != 1:
        _log(host, activation.unit, activation.owner_name, "programmatic registration with ambiguous mapping parameter", activation.node)
        return []
    mapping_name = mapping_parameters[0].name
    register_calls = _mapping_invocations(
        host, activation, mapping_name, "registerMapping"
    )
    if not register_calls:
        return []
    if _mapping_invocations(host, activation, mapping_name, "unregisterMapping"):
        _log(host, activation.unit, activation.owner_name, "registration paired with unregisterMapping", activation.node)
        return []
    if any(
        node is not activation.body_node and node.type in CONTROL_FLOW_NODES
        for node in _walk(activation.body_node)
    ):
        _log(host, activation.unit, activation.owner_name, "registration with unsupported control flow", activation.node)
        return []

    statements = list(activation.body_node.named_children)
    direct_register: dict[tuple[int, int], int] = {}
    for index, statement in enumerate(statements):
        expression = _direct_expression(host, statement)
        if expression is not None and expression.type == "method_invocation":
            direct_register[(expression.start_byte, expression.end_byte)] = index
    if any(
        (call.start_byte, call.end_byte) not in direct_register
        for call in register_calls
    ):
        _log(host, activation.unit, activation.owner_name, "nested programmatic registration", activation.node)
        return []

    locals_by_name: dict[str, tuple[str, Any, int]] = {}
    direct_locals: set[tuple[int, int]] = set()
    invalid_locals = False
    for index, statement in enumerate(statements):
        if statement.type != "local_variable_declaration":
            continue
        kind = _tracked_local_kind(host, activation, statement)
        if kind is None:
            continue
        direct_locals.add((statement.start_byte, statement.end_byte))
        declarators = _local_declarators(host, statement)
        if len(declarators) != 1:
            invalid_locals = True
            continue
        name_node = _field(host, declarators[0], "name")
        value_node = _field(host, declarators[0], "value")
        if name_node is None or value_node is None:
            invalid_locals = True
            continue
        name = _text(activation.unit, name_node)
        if name in locals_by_name:
            invalid_locals = True
            continue
        locals_by_name[name] = (kind, value_node, index)
    tracked_names = set(locals_by_name)
    protected_names = tracked_names | {
        parameter.name for parameter in activation.parameters
    }
    if invalid_locals or _has_tracked_mutation(
        host, activation, protected_names, direct_locals
    ):
        _log(host, activation.unit, activation.owner_name, "mutated or ambiguous registration local", activation.node)
        return []

    formals_by_name = {parameter.name: parameter for parameter in activation.parameters}
    endpoints: list[dict[str, Any]] = []
    for call in register_calls:
        statement_index = direct_register[(call.start_byte, call.end_byte)]
        arguments = _arguments(host, call)
        if arguments is None or len(arguments) != 3:
            _log(host, activation.unit, activation.owner_name, "registerMapping with unsupported arguments", call)
            continue
        info_expression = _resolve_local_argument(
            activation.unit,
            arguments[0],
            "info",
            locals_by_name,
            statement_index,
        )
        method_expression = _resolve_local_argument(
            activation.unit,
            arguments[2],
            "method",
            locals_by_name,
            statement_index,
        )
        info = (
            _decode_mapping_info(
                host,
                activation,
                workspace,
                method_index,
                info_expression,
            )
            if info_expression is not None
            else None
        )
        reflected = (
            _decode_reflected_method(
                host,
                activation,
                workspace,
                method_index,
                method_expression,
            )
            if method_expression is not None
            else None
        )
        handler_argument = _unwrap_parentheses(arguments[1])
        if (
            info is None
            or reflected is None
            or handler_argument is None
            or handler_argument.type != "identifier"
        ):
            _log(host, activation.unit, activation.owner_name, "unresolved registerMapping arguments", call)
            continue
        handler_parameter = formals_by_name.get(
            _text(activation.unit, handler_argument)
        )
        handler_method, target_fqn = reflected
        handler_fqn = (
            _resolve_source_type(
                host,
                activation.unit,
                handler_parameter.type_node,
                activation.owner_name,
                workspace,
            )
            if handler_parameter is not None
            else None
        )
        if handler_fqn != target_fqn:
            _log(host, activation.unit, activation.owner_name, "handler/reflection type mismatch", call)
            continue
        paths, methods = info
        for path in paths:
            for method in methods:
                endpoints.append(
                    _handler_endpoint(
                        host,
                        method,
                        path,
                        handler_method,
                        publisher=activation,
                        route_node=call,
                    )
                )
    return endpoints


# FLOW: _analyze_programmatic
# WHY: Find explicit Servlet MVC registrations independently of functional and annotated routes.
# IN/OUT: Workspace/host/shared MethodIndex in; raw programmatic endpoint rows out.
# CALL FLOW: Public recall calls it; owner activation and per-method analysis feed the result.
def _analyze_programmatic(
    workspace: dict[str, Any], host: Any, method_index: MethodIndex
) -> list[dict[str, Any]]:
    endpoints: list[dict[str, Any]] = []
    configuration_owners: dict[str, bool] = {}
    for fact in method_index.methods:
        configured = configuration_owners.setdefault(
            fact.owner_fqn,
            _owner_is_unique(workspace, fact) and _configuration_owner(host, fact),
        )
        if not configured:
            continue
        endpoints.extend(
            _analyze_registration_method(workspace, host, method_index, fact)
        )
    return endpoints


# FLOW: _deduplicate
# WHY: Collapse exact evidence-equivalent recall rows while preserving distinct publications.
# IN/OUT: Functional/programmatic row iterable in; sorted unique list out.
# CALL FLOW: `analyze_spring_recall` calls it after additive branch merge; host collection consumes output.
def _deduplicate(endpoints: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[Any, ...], dict[str, Any]] = {}
    for endpoint in endpoints:
        key = tuple(
            endpoint[field]
            for field in (
                "uri",
                "method",
                "uri_params",
                "SrcFile",
                "SrcLine",
                "SFunction",
            )
        )
        unique[key] = endpoint
    return [unique[key] for key in sorted(unique)]


# FLOW: analyze_spring_recall
# WHY: Expose additive functional and programmatic Spring endpoint recall through one host entry point.
# IN/OUT: Workspace/host in; unique endpoint facts out.
# CALL FLOW: Host orchestration calls it; builds one MethodIndex, runs both analyzers, merges, and deduplicates.
def analyze_spring_recall(
    workspace: dict[str, Any], host: Any
) -> list[dict[str, Any]]:
    """Return bounded functional and programmatic Spring endpoints.

    ``workspace`` must be a workspace returned by the host's
    ``build_jax_workspace`` (``include_jax`` may be false).  The function has
    no side effects other than using the host's existing diagnostics/debug
    logging, and it never suppresses annotation endpoints collected by the
    host.
    """

    # Build the relatively expensive source method index once, run both
    # independent branches, then deduplicate only exact evidence-equivalent
    # facts.  Neither branch suppresses host-collected annotation routes.
    method_index = _build_method_index(workspace, host)
    endpoints = _analyze_functional(workspace, host, method_index)
    endpoints.extend(_analyze_programmatic(workspace, host, method_index))
    return _deduplicate(endpoints)


__all__ = ["analyze_spring_recall"]
