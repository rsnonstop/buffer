"""Bounded source-only Spring HTTP client contract identification.

The host supplies its already-built Java workspace and source/provenance
helpers.  This pass identifies outbound Spring HTTP Interface declarations
and Feign interfaces without reclassifying them as inbound server handlers.
Only direct, genuinely resolved framework annotations on unique source
interfaces participate; unresolved or ambiguous endpoint identity fails
closed.
"""

# Reader's guide
# --------------
# This file models declarations made for an HTTP client proxy.  They are API
# endpoints in the sense that the application calls them, but they are not
# server handlers.  That distinction is carried in every emitted fact as
# ``surface=client`` and ``direction=outbound`` and later renders as
# ``http-client VERB``.
#
# The HTTP Interface path is assembled from every lexical interface layer and
# the method declaration.  For example:
#
#     @HttpExchange("/catalog")
#     interface CatalogApi {
#         @GetExchange("/items/{id}")
#         Item get(@PathVariable String id);
#     }
#
# proves the outbound identity ``GET /catalog/items/{id}``.  Nested interfaces
# add another type layer.  Each array-valued layer is a fan-out, so the code
# deliberately computes a Cartesian product rather than selecting one value.
# A configured method URL such as ``${inventory.url}/items`` can resolve to an
# absolute URL; the innermost absolute layer then replaces all outer relative
# prefixes in ``noir_sbt_spring_config.py``.
#
# Feign uses the ordinary Spring MVC mapping decoder after an exact
# ``org.springframework.cloud.openfeign.FeignClient`` marker proves that the
# interface is a client contract:
#
#     @FeignClient(name = "inventory", path = "/runtime-container")
#     @RequestMapping("/api")
#     interface InventoryClient {
#         @GetMapping("/items") Item[] items();
#     }
#
# The resulting declared contract is ``GET /api/items``.  ``FeignClient.path``
# is intentionally not added: this branch follows the inspected Noir contract,
# where that member classifies/configures the proxy but is not route evidence.
#
# Precision boundary: only one workspace-visible source interface, genuine
# annotation provenance, statically resolved String paths/method tokens, and
# usable non-private/non-static methods are accepted.  Duplicate FQNs,
# conflicting ``value``/``url`` aliases, unsupported annotation members, and
# unresolved values reject the affected mapping instead of inventing a URL.

from __future__ import annotations

from typing import Any, Iterable


HTTP_EXCHANGE_PACKAGE = "org.springframework.web.service.annotation"
FEIGN_CLIENT_PACKAGE = "org.springframework.cloud.openfeign"

HTTP_EXCHANGE_METHODS = {
    "GetExchange": "GET",
    "PostExchange": "POST",
    "PutExchange": "PUT",
    "DeleteExchange": "DELETE",
    "PatchExchange": "PATCH",
    "HttpExchange": None,
}

HTTP_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "method", "contentType", "accept", "headers"}
)
FIXED_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "contentType", "accept", "headers"}
)


# FLOW: _log
# WHY: Preserve observable precision failures without emitting guessed client rows.
# IN/OUT: Host, source unit, owner, and rejection reason in; no value out.
# CALL FLOW: Client decoders call this leaf; the host diagnostic sink consumes the message.
# Purpose: route a client-specific rejection to host diagnostics. Inputs are
# host, source unit, owner, and reason; there is no output. All guarded client
# decoders call this, and the host log is the downstream consumer.
def _log(host: Any, unit: dict[str, Any], owner: str, message: str) -> None:
    host.write_log(
        f"Skipped Spring client in {unit['fname']} for {owner}: {message}"
    )


# FLOW: _direct_methods
# WHY: Keep contract recall bounded to methods syntactically declared by this interface.
# IN/OUT: Host and interface node in; source-ordered direct method nodes out.
# CALL FLOW: HTTP Interface and Feign collectors call it; their mapping loops consume results.
# Purpose: enumerate methods declared directly in one interface. An interface
# syntax node enters and source-ordered method nodes leave; HTTP Interface and
# Feign collectors consume them. Inherited methods require a separate proof.
def _direct_methods(host: Any, interface_node: Any) -> list[Any]:
    body = host.child_by_field(interface_node, "body")
    if body is None:
        return []
    return sorted(
        (
            child
            for child in body.named_children
            if child.type == "method_declaration"
        ),
        key=lambda node: node.start_byte,
    )


# FLOW: _usable_contract_method
# WHY: Exclude helper declarations that cannot be proxy operations under the supported model.
# IN/OUT: Host and method node in; Boolean modifier verdict out.
# CALL FLOW: Both direct-method loops gate annotation decoding with this leaf check.
# Purpose: gate proxy operations by Java modifiers. A method node enters and a
# Boolean leaves; both client collectors call it before annotation decoding, so
# private/static helpers cannot flow into endpoint construction.
def _usable_contract_method(host: Any, method_node: Any) -> bool:
    modifiers = host.declaration_modifier_names(method_node)
    return "private" not in modifiers and "static" not in modifiers


# FLOW: _resolved_exchange_annotations
# WHY: Require genuine Spring HTTP Exchange identity instead of a matching simple name.
# IN/OUT: Host, unit, declaration node in; canonical annotation record/name pairs out.
# CALL FLOW: Type/method HTTP Interface mapping collection calls it before decoding values.
# Purpose: prove direct Spring HTTP Exchange annotation provenance. A unit and
# declaration node enter; canonical record/name pairs leave for type/method
# mapping decoders. Look-alike simple names produce an empty result.
def _resolved_exchange_annotations(
    host: Any, unit: dict[str, Any], declaration_node: Any
) -> list[tuple[dict[str, Any], str]]:
    resolved: list[tuple[dict[str, Any], str]] = []
    for record in host.direct_annotation_records(declaration_node):
        identity = host.resolve_known_annotation(
            unit,
            record["name_node"],
            set(HTTP_EXCHANGE_METHODS),
            (HTTP_EXCHANGE_PACKAGE,),
        )
        if identity is not None:
            resolved.append((record, identity["name"]))
    return resolved


# FLOW: _resolve_string_values
# WHY: Make selected annotation String resolution atomic across scalar or array syntax.
# IN/OUT: Resolution context and value node in; ordered String tuple or None out.
# CALL FLOW: Exchange path and generic-method decoders call it; mapping assembly consumes output.
# Purpose: resolve one scalar/array annotation expression through the workspace
# String graph. Syntax and owner context enter; an ordered tuple or None leaves
# for path/method decoders. Any unresolved selected value fails the set closed.
def _resolve_string_values(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    value_node: Any,
) -> tuple[str, ...] | None:
    values: list[str] = []
    for current in host.annotation_value_nodes(value_node):
        value = host.resolve_workspace_string_expression(
            unit, current, workspace, owner
        )
        if value is None:
            return None
        values.append(value)
    # Noir's Java mapping decoder fans out array-shaped annotation input even
    # for annotations whose library declaration is scalar.  Retain that
    # source-recovery behavior, but only after genuine annotation provenance.
    return tuple(dict.fromkeys(values)) if values else ("",)


# FLOW: _normalize_client_path
# WHY: Normalize relative routes without corrupting absolute or placeholder-rooted targets.
# IN/OUT: Host and resolved String in; normalized client path String out.
# CALL FLOW: Exchange path decoding calls this leaf; lexical composition consumes its result.
# Purpose: normalize relative client paths without corrupting complete URLs or
# placeholder roots. One String enters and one path leaves for composition; for
# example `${base}/x` stays unprefixed until configuration resolves `base`.
def _normalize_client_path(host: Any, value: str) -> str:
    return (
        value
        if value.lower().startswith(("http://", "https://"))
        # Configuration is applied after recall.  Preserve a root placeholder
        # until then so an absolute configured base is not prefixed with `/`.
        or value.startswith("${")
        else host.normalize_spring_path(value)
    )


# FLOW: _combine_client_paths
# WHY: Respect an inner complete HTTP target while joining lexical contract layers.
# IN/OUT: Host, outer path, inner path in; one effective client path out.
# CALL FLOW: HTTP Interface fan-out calls it; configuration later consumes the retained composition.
# Purpose: compose two lexical client layers while honoring an inner absolute
# HTTP(S) target. Outer/inner paths enter and one effective path leaves for the
# HTTP-interface endpoint loop and later configuration pass.
def _combine_client_paths(host: Any, type_path: str, method_path: str) -> str:
    # A method-level absolute client URL is already complete and must not be
    # appended to a type-level contract prefix.
    if method_path.lower().startswith(("http://", "https://")):
        return method_path
    return host.combine_paths(type_path, method_path)


# FLOW: _decode_exchange_paths
# WHY: Reconcile `value`/`url` aliases without selecting an arbitrary source-order winner.
# IN/OUT: Genuine annotation and String context in; normalized path list or None out.
# CALL FLOW: `_decode_exchange_mapping` calls it; HTTP Interface layer products consume paths.
# Purpose: reconcile HttpExchange `value`/`url` aliases. A genuine annotation
# and String-resolution context enter; normalized paths or None leave for the
# combined mapping. Conflicting explicit aliases reject rather than pick one.
def _decode_exchange_paths(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_node: Any,
) -> list[str] | None:
    # ``value`` and ``url`` are aliases in Spring HTTP Interfaces.  Decode all
    # explicitly supplied spellings independently, then require identical
    # ordered values.  This avoids a source-order "winner" when Java presents
    # contradictory route declarations.
    positional, named = host.get_annotation_arguments(annotation_node)
    if len(positional) > 1 or (positional and "value" in named):
        _log(host, unit, owner, "invalid positional/value URL aliases")
        return None

    explicit: list[tuple[str, Any]] = []
    if positional:
        explicit.append(("value", positional[0]))
    for attribute in ("value", "url"):
        if attribute in named:
            explicit.append((attribute, named[attribute]))
    if not explicit:
        return [""]

    aliases: list[tuple[str, tuple[str, ...]]] = []
    for attribute, node in explicit:
        values = _resolve_string_values(host, unit, workspace, owner, node)
        if values is None:
            _log(
                host,
                unit,
                owner,
                f"unresolved @{attribute} client path: "
                f"{host.node_text(unit['source'], node).strip()}",
            )
            return None
        aliases.append((attribute, values))
    if len({values for _attribute, values in aliases}) != 1:
        _log(host, unit, owner, "conflicting explicit value/url aliases")
        return None
    return list(
        dict.fromkeys(
            _normalize_client_path(host, value) for value in aliases[0][1]
        )
    )


# FLOW: _decode_exchange_methods
# WHY: Derive verbs only from fixed annotation identity or guarded generic method Strings.
# IN/OUT: Annotation identity/syntax and context in; ordered verbs or None out.
# CALL FLOW: `_decode_exchange_mapping` calls it; effective-method composition consumes output.
# Purpose: derive fixed Exchange verbs or decode generic `method`. Annotation
# identity/syntax enter; an ordered verb list or None leaves for the mapping.
# Example: `@HttpExchange(method="PROPFIND")` yields `PROPFIND`.
def _decode_exchange_methods(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_name: str,
    annotation_node: Any,
) -> list[str] | None:
    # Fixed exchange annotations prove their verb from annotation identity.
    # Generic @HttpExchange(method = "PROPFIND") is source data, so it passes
    # through the bounded Java String resolver and HTTP-token validation.
    _positional, named = host.get_annotation_arguments(annotation_node)
    if annotation_name != "HttpExchange":
        if "method" in named:
            _log(host, unit, owner, f"invalid method on @{annotation_name}")
            return None
        return [HTTP_EXCHANGE_METHODS[annotation_name]]

    method_node = named.get("method")
    if method_node is None:
        return []
    resolved = _resolve_string_values(
        host, unit, workspace, owner, method_node
    )
    if resolved is None:
        _log(
            host,
            unit,
            owner,
            "unresolved @HttpExchange method: "
            f"{host.node_text(unit['source'], method_node).strip()}",
        )
        return None

    methods: list[str] = []
    for value in resolved:
        token = value.strip().upper()
        if not token:
            continue
        if len(token) > 128 or host.HTTP_METHOD_TOKEN.fullmatch(token) is None:
            _log(host, unit, owner, f"invalid @HttpExchange method token: {value}")
            return None
        methods.append(token)
    return list(dict.fromkeys(methods))


# FLOW: _decode_exchange_mapping
# WHY: Validate and join one Exchange annotation's path, verb, and evidence components.
# IN/OUT: Annotation record plus workspace context in; mapping dictionary or None out.
# CALL FLOW: HTTP Interface type/method scans call it; endpoint products consume the mapping.
# Purpose: join one Exchange annotation's validated paths, verbs, and evidence.
# A record plus workspace context enter; a small mapping dictionary or None
# leaves for type/method collection in `_http_interface_endpoints`.
def _decode_exchange_mapping(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    record: dict[str, Any],
    annotation_name: str,
) -> dict[str, Any] | None:
    _positional, named = host.get_annotation_arguments(record["node"])
    allowed = (
        HTTP_EXCHANGE_ATTRIBUTES
        if annotation_name == "HttpExchange"
        else FIXED_EXCHANGE_ATTRIBUTES
    )
    unsupported = sorted(set(named) - allowed)
    if unsupported:
        _log(
            host,
            unit,
            owner,
            "unsupported @"
            f"{annotation_name} attributes: {', '.join(unsupported)}",
        )
        return None
    paths = _decode_exchange_paths(
        host, unit, workspace, owner, record["node"]
    )
    methods = _decode_exchange_methods(
        host,
        unit,
        workspace,
        owner,
        annotation_name,
        record["node"],
    )
    if paths is None or methods is None:
        return None
    return {
        "paths": paths,
        "methods": methods,
        "annotation_node": record["node"],
    }


# FLOW: _ordered_methods
# WHY: Guarantee deterministic known-verb then extension-token ordering.
# IN/OUT: Host and verb iterable in; unique ordered verb list out.
# CALL FLOW: `_combine_methods` calls this leaf; endpoint fan-out consumes its list.
# Purpose: make verb fan-out deterministic. An iterable enters; known Spring
# verbs then extension tokens leave uniquely ordered for `_combine_methods`.
def _ordered_methods(host: Any, methods: Iterable[str]) -> list[str]:
    unique = set(methods)
    known = [method for method in host.SPRING_HTTP_METHODS if method in unique]
    return known + sorted(unique - set(known))


# FLOW: _combine_methods
# WHY: Compute one effective verb condition from lexical type and method declarations.
# IN/OUT: Type-level and method-level iterables in; ordered effective verbs out.
# CALL FLOW: HTTP Interface collection calls it before constructing endpoint products.
# Purpose: merge type and method verb conditions under the analyzer's union
# semantics. Two iterables enter; effective ordered verbs leave for endpoint
# fan-out. An empty side inherits the conditions from the other side.
def _combine_methods(
    host: Any, type_methods: Iterable[str], method_methods: Iterable[str]
) -> list[str]:
    type_methods = list(type_methods)
    method_methods = list(method_methods)
    if not type_methods:
        return _ordered_methods(host, method_methods)
    if not method_methods:
        return _ordered_methods(host, type_methods)
    return _ordered_methods(host, [*type_methods, *method_methods])


# FLOW: _endpoint
# WHY: Preserve client direction/surface and route/handler evidence in the common fact schema.
# IN/OUT: Identity, source nodes, and optional path layers in; one endpoint dictionary out.
# CALL FLOW: HTTP Interface and Feign loops call it; dedup/configuration consume the row.
# Purpose: materialize one proven client path/verb as the host fact schema.
# Route/handler evidence and identity enter; one outbound dictionary leaves for
# deduplication/configuration. Optional layers preserve absolute precedence.
def _endpoint(
    host: Any,
    unit: dict[str, Any],
    owner: str,
    method_node: Any,
    parameters_node: Any,
    mapping_node: Any,
    path: str,
    http_method: str,
    *,
    path_layers: tuple[str, ...] | None = None,
) -> dict[str, Any]:
    # Keep declaration and implementation evidence separate even though a
    # source interface has no concrete proxy method body.  For this surface
    # both point at the contract method, while the explicit client metadata
    # prevents collision with an inbound controller of the same path/verb.
    endpoint = {
        "uri": path,
        "method": http_method,
        "uri_params": host.get_callable_parameters_as_is(
            unit["source"], parameters_node
        ),
        "SrcFile": unit["fname"],
        "SrcLine": mapping_node.start_point.row + 1,
        "SFunction": owner,
        "RouteSrcFile": unit["fname"],
        "RouteSrcLine": mapping_node.start_point.row + 1,
        "HandlerSrcFile": unit["fname"],
        "HandlerSrcLine": method_node.start_point.row + 1,
        "ProjectSrcFile": unit["fname"],
        "technology": "spring",
        "protocol": "http",
        "surface": "client",
        "direction": "outbound",
    }
    if path_layers is not None:
        endpoint["_spring_client_path_layers"] = path_layers
    host.debug_log(endpoint)
    return endpoint


# FLOW: _http_interface_endpoints
# WHY: Recover all guarded operations of one unique Spring HTTP Interface declaration.
# IN/OUT: Workspace, host, and declaration in; raw outbound endpoint list out.
# CALL FLOW: Public client analysis calls it; mapping helpers feed it and configuration consumes rows.
# Purpose: identify every operation of one unique Spring HTTP Interface. The
# shared workspace/host and declaration enter; raw outbound facts leave for the
# public analyzer, then configuration resolves retained path layers.
def _http_interface_endpoints(
    workspace: dict[str, Any], host: Any, declaration: dict[str, Any]
) -> list[dict[str, Any]]:
    # Phase 1 collects enclosing/type mappings.  Phase 2 decodes direct method
    # mappings.  The final nested loops are intentional products of:
    #
    #   lexical path layer 1 x ... x lexical path layer N x method paths
    #   x effective HTTP methods
    #
    # A path layer is retained on the fact until project placeholders have
    # been resolved, because only then can an inner layer be known absolute.
    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_owner = type_info["display_name"]
    type_node = type_info["node"]
    path_layers: list[tuple[str, ...]] = []
    type_methods: list[str] = []
    for layer in host.type_chain(
        host.tree_node_key(type_node), unit["type_infos"]
    ):
        type_annotations = [
            (record, name)
            for record, name in _resolved_exchange_annotations(
                host, unit, layer["node"]
            )
            if name == "HttpExchange"
        ]
        if len(type_annotations) > 1:
            _log(
                host,
                unit,
                type_owner,
                "multiple type-level @HttpExchange mappings",
            )
            return []
        if not type_annotations:
            continue
        mapping = _decode_exchange_mapping(
            host,
            unit,
            workspace,
            layer["display_name"],
            type_annotations[0][0],
            type_annotations[0][1],
        )
        if mapping is None:
            return []
        path_layers.append(tuple(mapping["paths"]))
        type_methods = _combine_methods(host, type_methods, mapping["methods"])
    if not path_layers:
        path_layers = [("",)]

    endpoints: list[dict[str, Any]] = []
    for method_node in _direct_methods(host, type_node):
        if not _usable_contract_method(host, method_node):
            continue
        name_node = host.child_by_field(method_node, "name")
        parameters_node = host.child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = host.node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        mappings = _resolved_exchange_annotations(
            host, unit, method_node
        )
        for record, annotation_name in mappings:
            mapping = _decode_exchange_mapping(
                host,
                unit,
                workspace,
                owner,
                record,
                annotation_name,
            )
            if mapping is None:
                continue
            methods = _combine_methods(
                host, type_methods, mapping["methods"]
            ) or ["ANY"]
            combinations: list[tuple[str, ...]] = [()]
            for layer_paths in [*path_layers, tuple(mapping["paths"])]:
                combinations = [
                    (*prefix, current)
                    for prefix in combinations
                    for current in layer_paths
                ]
            for layers in combinations:
                path = ""
                for current in layers:
                    path = _combine_client_paths(host, path, current)
                for http_method in methods:
                    endpoints.append(
                        _endpoint(
                            host,
                            unit,
                            owner,
                            method_node,
                            parameters_node,
                            mapping["annotation_node"],
                            path,
                            http_method,
                            path_layers=layers,
                        )
                    )
    return endpoints


# FLOW: _resolve_feign_marker
# WHY: Separate genuine Feign activation proof from ordinary MVC route declarations.
# IN/OUT: Host, unit, type node in; genuine direct Feign marker records out.
# CALL FLOW: `_feign_endpoints` calls it and requires exactly one before route decoding.
# Purpose: prove exact direct FeignClient activation. Unit/type syntax enter and
# genuine marker records leave; `_feign_endpoints` requires exactly one before
# interpreting ordinary MVC mappings as outbound operations.
def _resolve_feign_marker(
    host: Any, unit: dict[str, Any], type_node: Any
) -> list[dict[str, Any]]:
    markers = []
    for record in host.direct_annotation_records(type_node):
        resolved = host.resolve_known_annotation(
            unit,
            record["name_node"],
            {"FeignClient"},
            (FEIGN_CLIENT_PACKAGE,),
        )
        if resolved is not None:
            markers.append(record)
    return markers


# FLOW: _decode_mvc_mapping
# WHY: Share host direct/composed MVC provenance and constant semantics for Feign routes.
# IN/OUT: Workspace, host, annotation, and owner context in; mapping or None out.
# CALL FLOW: First/all Feign mapping selectors call it; their endpoint composer consumes output.
# Purpose: reuse host direct/composed MVC mapping semantics for Feign contracts.
# One annotation and owner context enter; a decoded mapping or None leaves for
# first/all selection helpers, preserving shared provenance and constants.
def _decode_mvc_mapping(
    workspace: dict[str, Any],
    host: Any,
    unit: dict[str, Any],
    record: dict[str, Any],
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    mapping = host.decode_spring_mapping(
        unit["fname"],
        unit["source"],
        record["name_node"],
        record["node"],
        unit["imports"],
        unit["local_annotations"],
        unit["constant_index"],
        lexical_owner,
        diagnostic_owner,
        unit,
        workspace,
    )
    if mapping is not None:
        return mapping
    return host.decode_spring_composed_mapping(
        unit["fname"],
        unit,
        record["name_node"],
        record["node"],
        lexical_owner,
        diagnostic_owner,
        workspace,
    )


# FLOW: _first_mvc_mapping
# WHY: Mirror host source-order policy for one lexical Feign type mapping layer.
# IN/OUT: Declaration and resolution context in; first recognized mapping or None out.
# CALL FLOW: `_feign_endpoints` calls it while building type path/method conditions.
# Purpose: select the first recognized MVC mapping on a lexical Feign type layer.
# Declaration/context enter and one mapping or None leaves; `_feign_endpoints`
# consumes it to build enclosing type paths in host source order.
def _first_mvc_mapping(
    workspace: dict[str, Any],
    host: Any,
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    for record in host.direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            host,
            unit,
            record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            return mapping
    return None


# FLOW: _all_mvc_mappings
# WHY: Retain each recognized direct method mapping as independently evidenced client identity.
# IN/OUT: Method declaration and context in; source-ordered mapping list out.
# CALL FLOW: `_feign_endpoints` calls it; nested path/verb loops consume every mapping.
# Purpose: decode every recognized MVC mapping directly on one Feign method.
# Method syntax/context enter and a source-ordered list leaves; the Feign loop
# fans each declaration into its independently evidenced client rows.
def _all_mvc_mappings(
    workspace: dict[str, Any],
    host: Any,
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> list[dict[str, Any]]:
    mappings = []
    for record in host.direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            host,
            unit,
            record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            mappings.append(mapping)
    return mappings


# FLOW: _feign_endpoints
# WHY: Recover outbound MVC operations only after exact Feign interface activation.
# IN/OUT: Workspace, host, and unique declaration in; raw outbound facts out.
# CALL FLOW: Public client analysis calls it; marker/MVC helpers feed it and dedup consumes rows.
# Purpose: identify MVC-mapped operations of one proven Feign interface. Shared
# context/declaration enter; outbound facts leave for merge and deduplication.
# FeignClient.path intentionally never enters route composition.
def _feign_endpoints(
    workspace: dict[str, Any], host: Any, declaration: dict[str, Any]
) -> list[dict[str, Any]]:
    # Feign activation and route decoding are separate proofs: @FeignClient
    # proves "outbound client", while genuine direct/composed MVC annotations
    # supply path and verb identity.  An interface with only @FeignClient has
    # no statically declared operation and therefore emits nothing here.
    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_node = type_info["node"]
    type_owner = type_info["display_name"]
    markers = _resolve_feign_marker(host, unit, type_node)
    if not markers:
        return []
    if len(markers) != 1:
        _log(host, unit, type_owner, "multiple @FeignClient annotations")
        return []

    # FeignClient.value/path are classification metadata in Noir's Spring
    # analyzer and deliberately do not contribute a container path.  Ordinary
    # MVC mappings on all lexical type layers do contribute.
    type_paths = [""]
    type_methods: list[str] = []
    for layer in host.type_chain(
        host.tree_node_key(type_node), unit["type_infos"]
    ):
        mapping = _first_mvc_mapping(
            workspace,
            host,
            unit,
            layer["node"],
            layer["display_name"],
            type_owner,
        )
        if mapping is None:
            continue
        if not mapping["valid"]:
            return []
        type_paths = [
            host.combine_paths(prefix, current)
            for prefix in type_paths
            for current in mapping["paths"]
        ]
        type_methods = host.combine_request_method_conditions(
            type_methods, mapping["methods"]
        )

    endpoints: list[dict[str, Any]] = []
    for method_node in _direct_methods(host, type_node):
        if not _usable_contract_method(host, method_node):
            continue
        name_node = host.child_by_field(method_node, "name")
        parameters_node = host.child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = host.node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        for mapping in _all_mvc_mappings(
            workspace, host, unit, method_node, type_owner, owner
        ):
            if not mapping["valid"]:
                continue
            methods = host.combine_request_method_conditions(
                type_methods, mapping["methods"]
            ) or ["ANY"]
            for type_path in type_paths:
                for method_path in mapping["paths"]:
                    path = host.combine_paths(type_path, method_path)
                    for http_method in methods:
                        endpoints.append(
                            _endpoint(
                                host,
                                unit,
                                owner,
                                method_node,
                                parameters_node,
                                mapping["annotation_node"],
                                path,
                                http_method,
                            )
                        )
    return endpoints


# FLOW: _deduplicate
# WHY: Collapse only evidence-identical client facts and make ordering reproducible.
# IN/OUT: Raw HTTP Interface/Feign iterable in; sorted unique endpoint list out.
# CALL FLOW: `analyze_spring_clients` calls it; Spring configuration consumes its result.
# Purpose: collapse evidence-identical client facts deterministically. Raw HTTP
# Interface/Feign rows enter; sorted unique rows leave for Spring configuration
# and the host's global endpoint collection.
def _deduplicate(endpoints: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    fields = (
        "uri",
        "method",
        "uri_params",
        "SrcFile",
        "SrcLine",
        "SFunction",
        "surface",
        "direction",
        "_spring_client_path_layers",
    )
    unique = {
        tuple(endpoint.get(field) for field in fields): endpoint
        for endpoint in endpoints
    }
    return [unique[key] for key in sorted(unique)]


# FLOW: analyze_spring_clients
# WHY: Expose both supported Spring client-contract families through one host entry point.
# IN/OUT: Built Java workspace and host helpers in; unique outbound client facts out.
# CALL FLOW: Host orchestration calls it; family collectors run, merge, and feed dedup/configuration.
# Purpose: public client-recall entry point called by the host. A built Java
# workspace plus helpers enter; unique outbound HTTP Interface and Feign facts
# leave for Spring configuration, global normalization, and CSV rendering.
def analyze_spring_clients(
    workspace: dict[str, Any], host: Any
) -> list[dict[str, Any]]:
    """Return outbound Spring HTTP Interface and Feign endpoint facts."""

    # Walk the FQN index, not files or simple names.  Requiring exactly one
    # declaration per FQN is what makes subsequent annotation and lexical-type
    # binding deterministic across a multi-module source tree.
    endpoints: list[dict[str, Any]] = []
    for fqn in sorted(workspace.get("type_declarations", {})):
        declarations = workspace["type_declarations"][fqn]
        # Duplicate source identities are not safe client containers.
        if len(declarations) != 1:
            continue
        declaration = declarations[0]
        type_info = declaration["type_info"]
        if (
            type_info["node"].type != "interface_declaration"
            or not type_info["workspace_visible"]
        ):
            continue
        endpoints.extend(
            _http_interface_endpoints(workspace, host, declaration)
        )
        endpoints.extend(_feign_endpoints(workspace, host, declaration))
    return _deduplicate(endpoints)


__all__ = ["analyze_spring_clients"]
