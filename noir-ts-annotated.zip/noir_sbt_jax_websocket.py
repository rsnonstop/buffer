"""Bounded Javax/Jakarta WebSocket handshake endpoint extraction.

The module is intentionally host-parameterized and import-cycle free.  It
consumes the Java workspace already built by :mod:`noir_sbt`, reusing that
workspace's annotation provenance and guarded String-expression resolver.
"""

# ENDPOINT MODEL — this analyzer identifies the HTTP upgrade URI represented
# by one genuine @ServerEndpoint annotation.  It emits one inbound ``ws GET``
# fact; @OnOpen/@OnMessage callbacks, encoders, decoders, subprotocols, and the
# configurator do not create additional URI identities.
#
# Accepted Java example:
#
#   public final class Paths {
#       public static final String CHAT = "/chat";
#   }
#
#   @jakarta.websocket.server.ServerEndpoint(
#       value = Paths.CHAT,
#       subprotocols = {"chat.v1"})
#   public class ChatSocket {
#       public ChatSocket() {}
#   }
#
# The workspace constant resolver proves /chat; unrelated named annotation
# options are intentionally ignored because they do not alter the handshake
# route.  No JAX-RS ApplicationPath, web.xml REST prefix, or Spring server
# prefix is applied to this independent protocol surface.
#
# FAIL CLOSED — a fake/simple-name annotation, duplicate FQN, multiple genuine
# annotations, unresolved/empty/query/fragment path, non-public or abstract
# type, non-static nested class, inaccessible enclosure, or nonconstructible
# class/record emits nothing.  Programmatic ServerContainer.addEndpoint,
# ServerEndpointConfig builders, dependency-only types, and runtime container
# registration are outside this annotated-handshake slice.

from __future__ import annotations

from typing import Any


SERVER_ENDPOINT_PACKAGES = (
    "jakarta.websocket.server",
    "javax.websocket.server",
)


# FLOW: _log
# WHY: Make each fail-closed WebSocket rejection auditable without
# manufacturing an endpoint from incomplete evidence.
# IN/OUT: Host, owning unit/type, and reason -> one host log side effect.
# CALL FLOW: All scan proof gates call this leaf; no endpoint consumer uses its return.
def _log(host: Any, unit: dict[str, Any], owner: str, message: str) -> None:
    # Every rejection carries source and owner context; callers do not convert
    # unsupported evidence into a guessed GET route.
    host.write_log(
        f"Skipped WebSocket endpoint in {unit['fname']} for {owner}: {message}"
    )


# FLOW: _direct_constructors
# WHY: Isolate constructors declared directly by the annotated class,
# excluding methods or constructors belonging to nested declarations.
# IN/OUT: Host and type AST node -> constructor-node list.
# CALL FLOW: The constructibility gate calls it and consumes empty as the
# Java's implicit default-constructor case.
def _direct_constructors(host: Any, type_node: Any) -> list[Any]:
    # Only constructors lexically declared by this exact class participate.
    body = host.child_by_field(type_node, "body")
    if body is None:
        return []
    return [
        child for child in body.named_children if child.type == "constructor_declaration"
    ]


# FLOW: _has_public_zero_arg_constructor
# WHY: Approximate whether a WebSocket container can instantiate a
# source class using the portable public no-argument constructor contract.
# IN/OUT: Host and class node -> eligibility Boolean.
# CALL FLOW: ``_eligible_type`` calls it; the top-level scan consumes its gate.
# EXAMPLE: Explicit constructors replace the implicit case,
# so ``public Socket(String x)`` alone returns false.
def _has_public_zero_arg_constructor(host: Any, type_node: Any) -> bool:
    # No explicit constructor means Java supplies the implicit zero-argument
    # constructor.  Once any constructor exists, require a public zero-arg one.
    constructors = _direct_constructors(host, type_node)
    if not constructors:
        return True
    for constructor in constructors:
        if "public" not in host.declaration_modifier_names(constructor):
            continue
        parameters = host.child_by_field(constructor, "parameters")
        if parameters is not None and not any(
            child.type in {"formal_parameter", "spread_parameter"}
            for child in parameters.named_children
        ):
            return True
    return False


# FLOW: _is_zero_component_record
# WHY: Recognize the only record shape whose canonical constructor has
# zero parameters in this bounded container-constructibility model.
# IN/OUT: Host and record node -> Boolean.
# CALL FLOW: ``_eligible_type`` calls it; component-bearing records fail its gate.
def _is_zero_component_record(host: Any, type_node: Any) -> bool:
    # A zero-component record has a zero-argument canonical constructor.  A
    # component-bearing record is not treated as container-constructible here.
    parameters = host.child_by_field(type_node, "parameters")
    return parameters is not None and not any(
        child.type in {"formal_parameter", "spread_parameter"}
        for child in parameters.named_children
    )


# FLOW: _eligible_type
# WHY: Prove a genuine annotated source type is publicly accessible and
# conservatively constructible before its route can become a handshake fact.
# IN/OUT: Host, owning unit, and type-info -> ``None`` when eligible or
# a diagnostic reason string.  The top-level analyzer logs/skips any reason.
# CALL FLOW: The top-level analyzer calls it after FQN proof; route decoding follows.
# EXAMPLE: A public static nested class with a public zero-arg constructor passes;
# a public non-static inner class fails because it needs an outer instance.
def _eligible_type(host: Any, unit: dict[str, Any], type_info: dict[str, Any]) -> str | None:
    # Runtime construction is approximated conservatively from source.  Public
    # visibility includes every lexical enclosure, and a nested class must be
    # static so it does not require an outer instance.
    type_node = type_info["node"]
    owner = type_info["display_name"]
    modifiers = host.declaration_modifier_names(type_node)
    if not type_info.get("workspace_visible", False):
        return "type is not workspace-visible"
    if "public" not in modifiers:
        return "type is not public"
    outer = host.nearest_enclosing_type(type_node)
    while outer is not None:
        if "public" not in host.declaration_modifier_names(outer):
            return "enclosing type is not public"
        outer = host.nearest_enclosing_type(outer)
    if type_node.type == "class_declaration":
        if host.type_is_abstract(unit["source"], type_node):
            return "type is abstract"
        outer = host.nearest_enclosing_type(type_node)
        if outer is not None and "static" not in modifiers:
            return "nested class is not static"
        if not _has_public_zero_arg_constructor(host, type_node):
            return "class has no public zero-argument constructor"
        return None
    if type_node.type == "record_declaration":
        if not _is_zero_component_record(host, type_node):
            return "record has components and no zero-argument canonical constructor"
        return None
    return f"unsupported annotated {type_node.type}"


# FLOW: _server_endpoint_record
# WHY: Distinguish one genuine Javax/Jakarta ServerEndpoint annotation
# from same-simple-name annotations and duplicate genuine declarations.
# IN/OUT: Host, unit, type node -> enriched annotation record or absence,
# plus an optional ambiguity reason.  ``analyze_jax_websocket`` consumes both.
# CALL FLOW: The top-level scan calls it first; identity/eligibility gates consume success.
def _server_endpoint_record(
    host: Any,
    unit: dict[str, Any],
    type_node: Any,
) -> tuple[dict[str, Any] | None, str | None]:
    # Resolve the declaring package/import/FQ identity; the trailing spelling
    # ``ServerEndpoint`` alone is never sufficient evidence.
    genuine = []
    for record in host.direct_annotation_records(type_node):
        resolved = host.resolve_known_annotation(
            unit,
            record["name_node"],
            {"ServerEndpoint"},
            SERVER_ENDPOINT_PACKAGES,
        )
        if resolved is not None:
            genuine.append((record, resolved))
    if not genuine:
        return None, None
    if len(genuine) != 1:
        return None, "multiple genuine ServerEndpoint annotations"
    record, resolved = genuine[0]
    return {**record, **resolved}, None


# FLOW: _server_endpoint_value_node
# WHY: Select exactly the identity-bearing ``value`` expression while
# ignoring encoders/decoders/subprotocol/configurator options that do not alter URI.
# IN/OUT: Host and annotation node -> expression node or ``None``, plus
# an optional validation reason.  The analyzer sends a valid node to the shared
# workspace String resolver; positional and named value together fail closed.
# CALL FLOW: The top-level scan calls it after type eligibility; String resolution follows.
# EXAMPLE: Both accepted positional/named spellings are shown in the nearby doc/comment.
def _server_endpoint_value_node(host: Any, annotation_node: Any) -> tuple[Any, str | None]:
    """Return the endpoint path while ignoring unrelated annotation options.

    ``ServerEndpoint`` also accepts encoders, decoders, subprotocols, and a
    configurator.  Those options do not change handshake-route identity, so
    rejecting them would lose an otherwise statically identifiable endpoint.
    """

    # Accepted path spellings are @ServerEndpoint("/chat") and
    # @ServerEndpoint(value = "/chat").  Supplying both or multiple positional
    # values is ambiguous even when one value looks usable.
    positional, named = host.get_annotation_arguments(annotation_node)
    if positional and "value" in named:
        return None, "both positional and named values"
    if "value" in named:
        return named["value"], None
    if len(positional) == 1:
        return positional[0], None
    if not positional:
        return None, "missing value"
    return None, "multiple positional values"


# FLOW: analyze_jax_websocket
# WHY: Perform the complete additions-only annotated-handshake scan over
# the already indexed Java workspace and emit protocol-distinct endpoint facts.
# IN/OUT: Host workspace and helper module -> list of inbound ``ws GET``
# dictionaries.  The host invokes it once and later formats/deduplicates rows.
# CALL FLOW: Host ``analyze_module`` calls it; debug logging and final formatting consume rows.
# EXAMPLE: Genuine annotation -> unique FQN -> constructible class -> one
# resolvable ``/chat`` value -> enriched route/handler evidence -> debug log.
def analyze_jax_websocket(
    workspace: dict[str, Any],
    host: Any,
) -> list[dict[str, Any]]:
    """Return one additions-only handshake row per valid source endpoint."""

    # Deterministic file/type iteration is followed by five proof gates:
    # genuine annotation -> unique source identity -> constructible type ->
    # one path expression -> resolved route-safe path.  A later gate never
    # weakens an earlier failure.
    endpoints: list[dict[str, Any]] = []
    for fname in sorted(workspace.get("units", {})):
        unit = workspace["units"][fname]
        for type_key in sorted(unit.get("type_infos", {})):
            type_info = unit["type_infos"][type_key]
            type_node = type_info["node"]
            record, annotation_error = _server_endpoint_record(
                host, unit, type_node
            )
            if record is None:
                if annotation_error:
                    _log(host, unit, type_info["display_name"], annotation_error)
                continue

            owner = type_info["display_name"]
            owner_fqn = host.qualified_type_name(unit, type_info)
            # A duplicate FQN makes imports/type identity ambiguous even if one
            # declaration happens to be encountered first.
            declarations = workspace.get("type_declarations", {}).get(
                owner_fqn, []
            )
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                _log(host, unit, owner, "duplicate or ambiguous source type identity")
                continue
            eligibility_error = _eligible_type(host, unit, type_info)
            if eligibility_error:
                _log(host, unit, owner, eligibility_error)
                continue

            value_node, value_error = _server_endpoint_value_node(
                host, record["node"]
            )
            if value_error:
                _log(host, unit, owner, f"invalid annotation value: {value_error}")
                continue
            value = host.resolve_workspace_string_expression(
                unit,
                value_node,
                workspace,
                owner,
            )
            if value is None:
                expression = host.node_text(unit["source"], value_node).strip()
                _log(host, unit, owner, f"unresolved path: {expression}")
                continue
            value = value.strip()
            # Query/fragment text is not part of a WebSocket endpoint path and
            # is rejected rather than normalized into a different identity.
            if not value or "?" in value or "#" in value:
                _log(host, unit, owner, "path is empty or contains query/fragment syntax")
                continue
            uri = host.normalize_spring_path(value)
            # normalize_spring_path is the host's slash/path normalizer; the
            # name is historical and does not apply Spring deployment config.
            endpoint = {
                "uri": uri,
                "method": "GET",
                # A WebSocket opening handshake is represented as GET while
                # protocol/surface keep it distinct from a REST GET at /chat.
                "protocol": "ws",
                "surface": "websocket",
                "direction": "inbound",
                "technology": "jax-websocket",
                "uri_params": "",
                "SrcFile": unit["fname"],
                "SrcLine": record["node"].start_point.row + 1,
                "SFunction": owner,
                # Route evidence is the annotation; handler evidence is the
                # constructible annotated type.  The stable CSV later projects
                # this richer internal evidence into its existing six fields.
                "RouteSrcFile": unit["fname"],
                "RouteSrcLine": record["node"].start_point.row + 1,
                "HandlerSrcFile": unit["fname"],
                "HandlerSrcLine": type_node.start_point.row + 1,
            }
            endpoints.append(endpoint)
            host.debug_log(endpoint)
    return endpoints
