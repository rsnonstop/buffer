"""Bounded source-only Spring controller hierarchy recall.

The host supplies the already-built Java workspace and its public source
helpers.  This pass deliberately emits additions only: direct mappings remain
owned by ``SpringBoot_Analyzer`` while this module binds mappings declared on
source interfaces or abstract bases to one concrete, genuinely activated
controller implementation.
"""

# Reader's guide
# --------------
# Spring permits request mappings to be declared on controller interfaces and
# abstract base methods while a concrete controller supplies the executable
# implementation.  Direct annotation scanning alone cannot join those facts.
# This additive pass performs that join by resolved Java type identity and
# adapted erased method signature.
#
# Example:
#
#     @RequestMapping("/contracts")
#     interface OrderApi<T> {
#       @GetMapping("/{id}") T get(String id);
#     }
#
#     @RestController
#     @RequestMapping("/v1")
#     final class OrderController implements OrderApi<Order> {
#       public Order get(String id) { ... }
#     }
#
# yields ``GET /v1/contracts/{id}``, attributed to the concrete
# ``OrderController.get`` while retaining the interface annotation as route
# evidence.  Generic substitution and full parameter signatures prevent a
# same-named overload from suppressing or borrowing the wrong mapping.
#
# Selection follows Java-like precedence in a deliberately bounded source
# graph: a mapped abstract-class declaration is considered before interface
# declarations; among interfaces, exactly one maximally specific mapping
# origin must remain.  A usable implementation is a concrete class method or
# a source default-interface method.  A mapping directly declared on the
# concrete controller is left to the host's ordinary analyzer and suppresses
# an inherited duplicate here.
#
# Precision boundary: the root must be a unique genuine concrete
# ``@Controller``/``@RestController`` source class.  All relevant hierarchy
# edges, generic environments, signatures, mapping identities, accessibility,
# and implementation bodies must resolve within the workspace and depth
# bounds.  Duplicate FQNs, cycles, inaccessible owners, unresolved signatures,
# competing interface origins, or incomplete graphs fail closed; there is no
# method-name-only or classpath-bytecode fallback.

from __future__ import annotations

from typing import Any

from noir_sbt_jax_recall import (
    JaxRecallAnalyzer,
    MAX_HIERARCHY_DEPTH,
    MethodRecord,
    TypeRecord,
    TypeRef,
)


SPRING_CONTROLLER_PACKAGES = (
    "org.springframework.stereotype",
    "org.springframework.web.bind.annotation",
)


# FLOW: SpringHierarchyAnalyzer
# WHY: Join inherited Spring mapping declarations to concrete implementations with shared Java graph semantics.
# IN/OUT: Constructed from workspace and host; exposes `analyze()` returning endpoint facts.
# CALL FLOW: `analyze_spring_hierarchy` creates it; graph, mapping, implementation, and endpoint methods cooperate downstream.
class SpringHierarchyAnalyzer:
    """Bind Spring mapping contracts by source identity and erased signature."""

    # FLOW: SpringHierarchyAnalyzer.__init__
    # WHY: Build one shared hierarchy graph and memo tables for a deterministic analysis invocation.
    # IN/OUT: Workspace/host in; initialized analyzer state out via `self`.
    # CALL FLOW: Public wrapper calls it; every other analyzer method consumes graph/caches established here.
    def __init__(self, workspace: dict[str, Any], host: Any):
        self.workspace = workspace
        self.host = host
        # The neutral type/signature portion of the JAX recall model already
        # supplies the exact workspace identity, generic adaptation, hierarchy
        # bounds, and maximally-specific-interface machinery needed here.
        self.graph = JaxRecallAnalyzer(workspace, host)
        self._method_mapping_cache: dict[tuple[Any, ...], dict[str, Any] | None] = {}
        self._type_mapping_cache: dict[str, dict[str, Any] | None] = {}

    # FLOW: SpringHierarchyAnalyzer._log
    # WHY: Surface incomplete/ambiguous hierarchy proof without inventing inherited endpoints.
    # IN/OUT: TypeRecord and reason in; no value out.
    # CALL FLOW: Controller analysis calls it; host diagnostic logging consumes the formatted context.
    def _log(self, record: TypeRecord, message: str) -> None:
        self.host.write_log(
            "Skipped Spring hierarchy in "
            f"{record.unit['fname']} for {record.type_info['display_name']}: "
            f"{message}"
        )

    # FLOW: SpringHierarchyAnalyzer._is_controller
    # WHY: Activate only unique concrete source controllers with genuine Spring stereotype provenance.
    # IN/OUT: TypeRecord in; Boolean verdict out.
    # CALL FLOW: `analyze` gates graph roots here before `_controller_endpoints` performs inheritance joins.
    def _is_controller(self, record: TypeRecord) -> bool:
        if (
            record.kind != "class_declaration"
            or record.type_info["abstract"]
            or not record.type_info["workspace_visible"]
        ):
            return False
        for annotation in self.host.direct_annotation_records(
            record.type_info["node"]
        ):
            resolved = self.host.resolve_known_annotation(
                record.unit,
                annotation["name_node"],
                {"Controller", "RestController"},
                SPRING_CONTROLLER_PACKAGES,
            )
            if resolved is not None and (
                (resolved["name"] == "Controller"
                 and resolved["namespace"] == "org.springframework.stereotype")
                or (
                    resolved["name"] == "RestController"
                    and resolved["namespace"]
                    == "org.springframework.web.bind.annotation"
                )
            ):
                return True
        return False

    @staticmethod
    # FLOW: SpringHierarchyAnalyzer._contract_owner
    # WHY: Restrict inherited mapping origins to interfaces or abstract classes.
    # IN/OUT: TypeRecord in; Boolean owner-category verdict out.
    # CALL FLOW: `_mapping_source` calls this leaf gate when selecting class/interface declarations.
    def _contract_owner(record: TypeRecord) -> bool:
        return record.kind == "interface_declaration" or (
            record.kind == "class_declaration" and record.type_info["abstract"]
        )

    # FLOW: SpringHierarchyAnalyzer._type_accessible
    # WHY: Preserve Java source accessibility when borrowing a contract from another type.
    # IN/OUT: Declaration and consumer records in; Boolean accessibility out.
    # CALL FLOW: Interface traversal and mapping selection call it before accepting cross-owner evidence.
    def _type_accessible(self, declaration: TypeRecord, consumer: TypeRecord) -> bool:
        return self.host.workspace_type_fqn_accessible(
            self.workspace,
            consumer.unit,
            consumer.type_info["display_name"],
            declaration.fqn,
        )

    # FLOW: SpringHierarchyAnalyzer._method_accessible
    # WHY: Prevent private/package-inaccessible methods from becoming inherited handler/mapping evidence.
    # IN/OUT: MethodRecord and consumer in; Boolean accessibility out.
    # CALL FLOW: Interface mapping traversal and class mapping selection consume this leaf proof.
    def _method_accessible(
        self, method: MethodRecord, consumer: TypeRecord
    ) -> bool:
        if "private" in method.modifiers or "static" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return True
        if "public" in method.modifiers or "protected" in method.modifiers:
            return True
        return method.owner.unit["package"] == consumer.unit["package"]

    # FLOW: SpringHierarchyAnalyzer._implementation_usable
    # WHY: Require an actual request-capable implementation rather than abstract/static/private declarations.
    # IN/OUT: MethodRecord in; Boolean usability out.
    # CALL FLOW: `_implementation` filters candidate class/default-interface methods through this gate.
    def _implementation_usable(self, method: MethodRecord) -> bool:
        if (
            "private" in method.modifiers
            or "static" in method.modifiers
            or "abstract" in method.modifiers
        ):
            return False
        body = self.host.child_by_field(method.node, "body")
        if method.owner.kind == "interface_declaration":
            return "default" in method.modifiers and body is not None
        return body is not None

    # FLOW: SpringHierarchyAnalyzer._decode_annotations
    # WHY: Reuse direct/composed Spring mapping semantics while retaining contract evidence ownership.
    # IN/OUT: Unit, annotation records, lexical/diagnostic owners in; one mapping or None out.
    # CALL FLOW: Method/type mapping caches call it; `_mapping_conditions` and endpoint composition consume result.
    # Example: a source-composed `@ReadRoute` can resolve exactly as it does in the direct analyzer.
    def _decode_annotations(
        self,
        unit: dict[str, Any],
        annotations: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        lexical_owner: str,
        diagnostic_owner: str,
    ) -> dict[str, Any] | None:
        # Reuse the host's direct and composed mapping semantics.  Selecting
        # the first recognized annotation here mirrors direct analyzer ordering
        # while retaining the contract method/type as the declaration source.
        for annotation in sorted(
            annotations, key=lambda record: record["node"].start_byte
        ):
            mapping = self.host.decode_spring_mapping(
                unit["fname"],
                unit["source"],
                annotation["name_node"],
                annotation["node"],
                unit["imports"],
                unit["local_annotations"],
                unit["constant_index"],
                lexical_owner,
                diagnostic_owner,
                unit,
                self.workspace,
            )
            if mapping is not None:
                return mapping
            mapping = self.host.decode_spring_composed_mapping(
                unit["fname"],
                unit,
                annotation["name_node"],
                annotation["node"],
                lexical_owner,
                diagnostic_owner,
                self.workspace,
            )
            if mapping is not None:
                return mapping
        return None

    # FLOW: SpringHierarchyAnalyzer._method_mapping
    # WHY: Memoize mapping decoding per exact source method so graph traversal cannot drift or duplicate work.
    # IN/OUT: MethodRecord in; cached decoded mapping or None out.
    # CALL FLOW: Interface/class selection and `_mapping_conditions` call it; `_decode_annotations` fills cache.
    def _method_mapping(self, method: MethodRecord) -> dict[str, Any] | None:
        if method.id not in self._method_mapping_cache:
            owner = method.owner.type_info["display_name"]
            self._method_mapping_cache[method.id] = self._decode_annotations(
                method.owner.unit,
                method.annotations,
                owner,
                f"{owner}.{method.name}",
            )
        return self._method_mapping_cache[method.id]

    # FLOW: SpringHierarchyAnalyzer._type_mapping
    # WHY: Memoize direct type-level mapping for each exact source FQN.
    # IN/OUT: TypeRecord in; cached mapping or None out.
    # CALL FLOW: `_controller_endpoints` requests controller/contract path conditions; annotation decoder fills cache.
    def _type_mapping(self, record: TypeRecord) -> dict[str, Any] | None:
        if record.fqn not in self._type_mapping_cache:
            owner = record.type_info["display_name"]
            self._type_mapping_cache[record.fqn] = self._decode_annotations(
                record.unit,
                self.host.direct_annotation_records(record.type_info["node"]),
                owner,
                owner,
            )
        return self._type_mapping_cache[record.fqn]

    # FLOW: SpringHierarchyAnalyzer._interface_mapping_branches
    # WHY: Find maximally relevant interface mapping origins while propagating incomplete-graph evidence separately.
    # IN/OUT: Interface state/signature/consumer plus recursion state in; candidate set and invalid flag out.
    # CALL FLOW: `_mapping_source` starts traversal; Java graph edge/signature helpers feed it, specificity selection consumes it.
    # Example: an unresolved sibling interface marks the result invalid even if another branch has one apparent mapping.
    def _interface_mapping_branches(
        self,
        state: tuple[TypeRecord, dict[str, TypeRef]],
        signature: tuple[str, tuple[str, ...]],
        consumer: TypeRecord,
        depth: int = 0,
        active: frozenset[str] = frozenset(),
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] | None = None,
    ) -> tuple[
        set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]], bool
    ]:
        # Return candidate (method, generic-environment) pairs plus a separate
        # invalid flag.  The flag matters: "no mapping on this branch" is safe,
        # but "the branch could not be resolved" makes a unique-looking result
        # untrustworthy and therefore blocks emission.
        if memo is None:
            memo = {}
        record, env = state
        memo_key = (record.fqn, self.graph._env_key(env), signature)
        if memo_key in memo:
            cached, invalid = memo[memo_key]
            return set(cached), invalid
        if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
            return set(), True
        if not self._type_accessible(record, consumer):
            return set(), True

        matches = self.graph._methods_for_signature(record, env, signature)
        if len(matches) > 1:
            return set(), True
        if matches:
            method = matches[0]
            mapping = self._method_mapping(method)
            if mapping is not None:
                if not self._method_accessible(method, consumer):
                    return set(), True
                result = ({(method.id, self.graph._env_key(env))}, False)
                memo[memo_key] = result
                return set(result[0]), result[1]

        if not record.interfaces_valid:
            return set(), True
        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]
        ] = set()
        blocked = False
        for edge in record.interfaces:
            following = self.graph._edge_state(edge, env)
            if following is None or following[0].kind != "interface_declaration":
                blocked = True
                continue
            found, invalid = self._interface_mapping_branches(
                following,
                signature,
                consumer,
                depth + 1,
                active | {record.fqn},
                memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        memo[memo_key] = (set(candidates), blocked)
        return candidates, blocked

    # FLOW: SpringHierarchyAnalyzer._mapping_source
    # WHY: Select one mapping declaration using implementation, abstract-class, then interface precedence.
    # IN/OUT: Implementation/signature/hierarchy/root context in; mapped MethodRecord/environment or None out.
    # CALL FLOW: `_controller_endpoints` calls it per signature; mapping conditions and fact construction consume selection.
    # Example: a root's direct mapping returns None here because the host direct analyzer already owns that row.
    def _mapping_source(
        self,
        implementation: MethodRecord,
        signature: tuple[str, tuple[str, ...]],
        hierarchy: Any,
        implementation_index: int | None,
        root: TypeRecord,
    ) -> tuple[MethodRecord, dict[str, TypeRef]] | None:
        # Mapping-origin precedence:
        #   1. a supported inherited implementation carrying its own mapping;
        #   2. the nearest mapped abstract-class declaration;
        #   3. one maximally specific interface declaration.
        # A concrete-root mapping is intentionally not returned because the
        # direct analyzer already owns it.
        direct = self._method_mapping(implementation)
        if direct is not None:
            if (
                implementation.owner is not root
                and self._contract_owner(implementation.owner)
                and self._method_accessible(implementation, root)
            ):
                implementation_env = (
                    hierarchy.class_states[implementation_index][1]
                    if implementation_index is not None
                    else self.graph._default_env(implementation.owner)
                )
                return implementation, implementation_env
            # A direct mapping on the concrete root is emitted by the host and
            # suppresses the inherited declaration.  Mappings on an unsupported
            # owner also fail closed instead of being reinterpreted.
            return None

        start = (
            implementation_index + 1
            if implementation_index is not None
            else 0
        )
        for record, env in hierarchy.class_states[start:]:
            matches = self.graph._methods_for_signature(record, env, signature)
            if len(matches) > 1:
                return None
            if not matches:
                continue
            method = matches[0]
            mapping = self._method_mapping(method)
            if mapping is None:
                continue
            if (
                not self._contract_owner(record)
                or not self._type_accessible(record, root)
                or not self._method_accessible(method, root)
            ):
                return None
            return method, env

        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]
        ] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self._interface_mapping_branches(
                interface_root, signature, root, memo=memo
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self.graph._maximally_specific_candidates(
            candidates
        )
        blocked = blocked or specificity_invalid
        if blocked or len({candidate[0] for candidate in candidates}) != 1:
            return None
        return self.graph._method_from_candidate(next(iter(candidates)))

    # FLOW: SpringHierarchyAnalyzer._all_signatures
    # WHY: Enumerate adapted erased signatures across the complete class/interface graph and flag unresolved names.
    # IN/OUT: Resolved hierarchy in; signature set plus unresolved-name set out.
    # CALL FLOW: `_controller_endpoints` calls it before binding implementations; graph signature/edge helpers supply data.
    def _all_signatures(
        self, hierarchy: Any
    ) -> tuple[set[tuple[str, tuple[str, ...]]], set[str]]:
        signatures: set[tuple[str, tuple[str, ...]]] = set()
        unresolved_names: set[str] = set()

        # FLOW: SpringHierarchyAnalyzer._all_signatures.add_methods
        # WHY: Add one type's resolvable adapted signatures while recording names whose types remain unknown.
        # IN/OUT: TypeRecord/environment in; mutates enclosing signature and unresolved-name sets, returns nothing.
        # CALL FLOW: `_all_signatures` invokes it for class/interface states; implementation binding consumes the sets.
        def add_methods(record: TypeRecord, env: dict[str, TypeRef]) -> None:
            for method in record.methods:
                signature = self.graph._signature(method, env)
                if signature is None:
                    unresolved_names.add(method.name)
                else:
                    signatures.add(signature)

        for record, env in hierarchy.class_states:
            add_methods(record, env)

        visited: set[tuple[str, tuple[tuple[str, TypeRef], ...]]] = set()

        # FLOW: SpringHierarchyAnalyzer._all_signatures.visit
        # WHY: Traverse reachable interfaces once per generic environment under the hierarchy depth bound.
        # IN/OUT: Interface state/depth in; updates enclosing signature sets, no direct return value.
        # CALL FLOW: `_all_signatures` starts it at interface roots; it recurses through resolved graph edges and calls add_methods.
        def visit(
            state: tuple[TypeRecord, dict[str, TypeRef]], depth: int = 0
        ) -> None:
            record, env = state
            state_key = (record.fqn, self.graph._env_key(env))
            if state_key in visited or depth > MAX_HIERARCHY_DEPTH:
                return
            visited.add(state_key)
            add_methods(record, env)
            for edge in record.interfaces:
                following = self.graph._edge_state(edge, env)
                if following is not None:
                    visit(following, depth + 1)

        for interface_root in hierarchy.interface_roots:
            visit(interface_root)
        return signatures, unresolved_names

    # FLOW: SpringHierarchyAnalyzer._implementation
    # WHY: Bind one signature to a unique usable concrete-class method or unambiguous default interface method.
    # IN/OUT: Signature/hierarchy in; implementation, generic environment, class index or None out.
    # CALL FLOW: `_controller_endpoints` calls it; `_mapping_source` then uses implementation location for precedence.
    # Example: same-name overloads remain separate because the input is the full adapted erased signature.
    def _implementation(
        self,
        signature: tuple[str, tuple[str, ...]],
        hierarchy: Any,
    ) -> tuple[MethodRecord, dict[str, TypeRef], int | None] | None:
        # Walk the concrete class chain first.  Only if no class implementation
        # exists may one unambiguous default interface method implement the
        # signature.  Abstract/static/private methods cannot handle a request.
        for index, (record, env) in enumerate(hierarchy.class_states):
            matches = self.graph._methods_for_signature(record, env, signature)
            if not matches:
                continue
            if len(matches) != 1 or not self._implementation_usable(matches[0]):
                return None
            return matches[0], env, index

        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]
        ] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self.graph._interface_branches(
                interface_root, signature, "default", memo=memo
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self.graph._maximally_specific_candidates(
            candidates
        )
        if blocked or specificity_invalid or len(
            {candidate[0] for candidate in candidates}
        ) != 1:
            return None
        resolved = self.graph._method_from_candidate(next(iter(candidates)))
        if resolved is None or not self._implementation_usable(resolved[0]):
            return None
        return resolved[0], resolved[1], None

    # FLOW: SpringHierarchyAnalyzer._mapping_conditions
    # WHY: Project one already decoded mapping fact into validated path and verb lists.
    # IN/OUT: Mapping dict/None in; `(paths, methods)` or None out. Absence is
    # the identity mapping `([""], [])`; an explicitly invalid mapping rejects.
    # CALL FLOW: `_controller_endpoints` calls it after source selection; endpoint Cartesian products consume output.
    def _mapping_conditions(
        self, mapping: dict[str, Any] | None
    ) -> tuple[list[str], list[str]] | None:
        if mapping is None:
            return [""], []
        if not mapping["valid"]:
            return None
        return list(mapping["paths"]), list(mapping["methods"])

    # FLOW: SpringHierarchyAnalyzer._controller_endpoints
    # WHY: Join one concrete controller's hierarchy, implementation, and mapping conditions atomically.
    # IN/OUT: Controller TypeRecord in; inherited endpoint dictionaries out.
    # CALL FLOW: `analyze` calls it; all signature/source/condition helpers feed it, host collection consumes rows.
    # Example: `/v1` controller x `/contracts` interface x `/{id}` method yields `/v1/contracts/{id}`.
    def _controller_endpoints(self, root: TypeRecord) -> list[dict[str, Any]]:
        # Complete hierarchy proof is atomic for a controller.  Once complete,
        # each signature independently binds an implementation and a mapping
        # source, then composes:
        #
        #   concrete controller path x contract type path x method path
        #   x effective controller/contract/method verbs
        #
        # ProjectSrcFile remains the concrete controller so configuration from
        # a contract in another module cannot leak into the published route.
        root_env = self.graph._default_env(root)
        hierarchy = self.graph._hierarchy(root, root_env)
        if not hierarchy.complete:
            self._log(root, "incomplete or ambiguous type hierarchy")
            return []

        controller_conditions = self._mapping_conditions(self._type_mapping(root))
        if controller_conditions is None:
            return []
        controller_paths, controller_methods = controller_conditions
        signatures, unresolved_names = self._all_signatures(hierarchy)
        endpoints: list[dict[str, Any]] = []

        for signature in sorted(signatures):
            if signature[0] in unresolved_names:
                continue
            implementation_state = self._implementation(signature, hierarchy)
            if implementation_state is None:
                continue
            implementation, _implementation_env, implementation_index = (
                implementation_state
            )
            source_state = self._mapping_source(
                implementation,
                signature,
                hierarchy,
                implementation_index,
                root,
            )
            if source_state is None:
                continue
            source, _source_env = source_state
            mapping = self._method_mapping(source)
            if mapping is None or not mapping["valid"]:
                continue
            contract_conditions = self._mapping_conditions(
                self._type_mapping(source.owner)
            )
            if contract_conditions is None:
                continue
            contract_paths, contract_methods = contract_conditions
            effective_methods = self.host.combine_request_method_conditions(
                controller_methods, contract_methods
            )
            effective_methods = self.host.combine_request_method_conditions(
                effective_methods, mapping["methods"]
            ) or ["ANY"]
            owner_name = (
                f"{implementation.owner.type_info['display_name']}."
                f"{implementation.name}"
            )
            parameters = self.host.get_callable_parameters_as_is(
                implementation.owner.unit["source"],
                implementation.parameters_node,
            )
            for controller_path in controller_paths:
                for contract_path in contract_paths:
                    base_path = self.host.combine_paths(
                        controller_path, contract_path
                    )
                    for method_path in mapping["paths"]:
                        uri = self.host.combine_paths(base_path, method_path)
                        for http_method in effective_methods:
                            endpoint = {
                                "uri": uri,
                                "method": http_method,
                                "uri_params": parameters,
                                "SrcFile": implementation.owner.unit["fname"],
                                "SrcLine": implementation.node.start_point.row + 1,
                                "SFunction": owner_name,
                                "RouteSrcFile": source.owner.unit["fname"],
                                "RouteSrcLine": mapping["annotation_node"].start_point.row + 1,
                                "HandlerSrcFile": implementation.owner.unit["fname"],
                                "HandlerSrcLine": implementation.node.start_point.row + 1,
                                "ProjectSrcFile": root.unit["fname"],
                                "technology": "spring",
                                "protocol": "http",
                                "surface": "server",
                                "direction": "inbound",
                            }
                            endpoints.append(endpoint)
                            self.host.debug_log(endpoint)
        return endpoints

    # FLOW: SpringHierarchyAnalyzer.analyze
    # WHY: Orchestrate hierarchy recall over deterministic source graph roots and deduplicate final evidence.
    # IN/OUT: Uses initialized analyzer state; returns sorted unique inherited endpoint facts.
    # CALL FLOW: Public wrapper invokes it; `_is_controller` and `_controller_endpoints` run per type, host consumes result.
    def analyze(self) -> list[dict[str, Any]]:
        endpoints: list[dict[str, Any]] = []
        for fqn in sorted(self.graph.types):
            record = self.graph.types[fqn]
            if self._is_controller(record):
                endpoints.extend(self._controller_endpoints(record))
        return endpoints


# FLOW: analyze_spring_hierarchy
# WHY: Provide the host-facing functional entry point without exposing analyzer lifecycle details.
# IN/OUT: Workspace/host in; inherited Spring endpoint list out.
# CALL FLOW: Host orchestration calls it; constructs `SpringHierarchyAnalyzer`, then delegates to `analyze()`.
def analyze_spring_hierarchy(
    workspace: dict[str, Any], host: Any
) -> list[dict[str, Any]]:
    """Return signature-bound Spring controller hierarchy additions."""

    return SpringHierarchyAnalyzer(workspace, host).analyze()


__all__ = ["analyze_spring_hierarchy"]
