"""Bounded Spring Cloud Gateway Java-DSL endpoint extraction.

The module is deliberately host-parameterized and does not import
``noir_sbt``.  :func:`analyze_spring_gateway` accepts the host workspace and
uses its provenance-aware Java type and String resolvers.

Only a published, direct ``@Bean RouteLocator`` construction is accepted.  A
route predicate can be written directly in its lambda or delegated through
one exact, same-owner ``PredicateSpec`` helper. Normal terminal ``filter`` or
``filters`` steps, a dynamic route ID, and a dynamic destination expression do
not affect route identity. Unsupported predicate algebra, control flow,
dynamic path values, or ambiguous source identity fail closed.
"""

# Reader's guide
# --------------
# This pass identifies the inbound side of Spring Cloud Gateway's Java DSL.
# The upstream destination is deliberately not reported as an endpoint: the
# externally callable identity comes from the route predicate.  A canonical
# accepted example is:
#
#     @Bean
#     RouteLocator routes(RouteLocatorBuilder builder) {
#       return builder.routes()
#         .route("inventory", p -> p.path("/api/items/**")
#                                    .and().method(HttpMethod.GET)
#                                    .filters(f -> f.stripPrefix(1))
#                                    .uri(inventoryUri()))
#         .build();
#     }
#
# This proves inbound proxy identity ``GET /api/items/**``.  The dynamic route
# ID, filter details, and destination expression can change forwarding but do
# not change which inbound path/method selects the route, so the bounded code
# validates their call shape and otherwise ignores them.
#
# A second supported form delegates only the predicate construction to one
# exact same-owner helper:
#
#     private BooleanSpec inventory(PredicateSpec p) {
#       return p.path(PATH).and().method(HttpMethod.GET);
#     }
#     ... route(p -> inventory(p).uri("lb://inventory")) ...
#
# Matching happens in four stages: index source methods; prove a genuine
# ``@Bean RouteLocator`` publisher with exactly one genuine builder formal;
# decode the direct ``builder.routes().route(...).build()`` chain; then decode
# each lambda's predicate.  Paths use the shared workspace String resolver and
# optional project configuration callback.  Methods require genuine Spring
# ``HttpMethod`` or MVC ``RequestMethod`` provenance.
#
# Precision boundary: the route publisher must be a unique concrete source
# owner.  Only direct expression lambdas, ``path`` with optional ``method``,
# terminal filter calls, and one exact helper layer are modeled.  Block
# lambdas, fields/locals, host/custom predicate algebra, dynamic paths,
# arbitrary helpers, ambiguous enum owners, malformed publication, and
# identity-affecting unsupported predicates reject that route.  One rejected
# route remains branch-local and does not suppress valid sibling routes.

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable


SPRING_CONTEXT_ANNOTATION_PACKAGE = "org.springframework.context.annotation"
GATEWAY_ROUTE_PACKAGE = "org.springframework.cloud.gateway.route"
GATEWAY_BUILDER_PACKAGE = "org.springframework.cloud.gateway.route.builder"
SPRING_HTTP_PACKAGE = "org.springframework.http"


PathTransformer = Callable[..., str | None]


@dataclass(frozen=True)
# FLOW: FormalParameter
# WHY: Keep a parameter's resolved syntax/name together for exact builder and helper gates.
# IN/OUT: Constructed from Java type/name nodes; exposes immutable parameter evidence.
# CALL FLOW: `_formal_parameters` creates it; method indexing and publisher/helper checks consume it.
class FormalParameter:
    name: str
    type_node: Any
    node: Any


@dataclass(frozen=True)
# FLOW: MethodFact
# WHY: Give later Gateway phases one provenance-bound source-method representation.
# IN/OUT: Constructed from unit/owner/method syntax and formals; exposes facts and derived names.
# CALL FLOW: `_build_method_index` creates it; publisher, helper, predicate, and endpoint phases consume it.
class MethodFact:
    unit: dict[str, Any]
    owner_info: dict[str, Any]
    owner_fqn: str
    node: Any
    name_node: Any
    return_type_node: Any
    parameters_node: Any
    body_node: Any
    parameters: tuple[FormalParameter, ...]
    modifiers: frozenset[str]

    @property
# FLOW: MethodFact.name
# WHY: Centralize exact source recovery for the indexed Java method name.
# IN/OUT: Uses this fact's name node/unit; returns the method-name String.
# CALL FLOW: Logging, helper indexing, and endpoint attribution read this leaf property.
    def name(self) -> str:
        return _text(self.unit, self.name_node)

    @property
# FLOW: MethodFact.owner_name
# WHY: Centralize the human-readable lexical owner used in diagnostics and output.
# IN/OUT: Uses owner metadata; returns one display-name String.
# CALL FLOW: Path resolution, logging, and endpoint attribution read this leaf property.
    def owner_name(self) -> str:
        return self.owner_info["display_name"]


@dataclass(frozen=True)
# FLOW: MethodIndex
# WHY: Prevent global same-name method guesses by retaining exact owner/name keys.
# IN/OUT: Receives all MethodFacts and an owner/name multimap; exposes immutable index state.
# CALL FLOW: `_build_method_index` creates it; helper binding and public analysis consume it.
class MethodIndex:
    methods: tuple[MethodFact, ...]
    by_owner_name: dict[tuple[str, str], tuple[MethodFact, ...]]


@dataclass(frozen=True)
# FLOW: PredicateShape
# WHY: Separate proven inbound selector identity from Gateway DSL syntax and destination metadata.
# IN/OUT: Receives unique path/method tuples; exposes the Cartesian-product dimensions.
# CALL FLOW: Predicate decoders create it; `_endpoint` fan-out consumes it.
class PredicateShape:
    paths: tuple[str, ...]
    methods: tuple[str, ...]


# FLOW: _text
# WHY: Preserve exact Java source spelling instead of reconstructing Tree-sitter nodes.
# IN/OUT: Unit and node in; UTF-8 source slice out.
# CALL FLOW: All Gateway syntax/type helpers use this leaf utility.
def _text(unit: dict[str, Any], node: Any) -> str:
    return unit["source"][node.start_byte : node.end_byte].decode("utf8")


# FLOW: _walk
# WHY: Provide bounded-memory deterministic syntax traversal for indexing and flow checks.
# IN/OUT: Root node in; pre-order node stream out.
# CALL FLOW: `_build_method_index` and return/control-flow helpers consume this leaf iterator.
def _walk(node: Any) -> Iterable[Any]:
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


# FLOW: _field
# WHY: Isolate parser-version named-field lookup behind the shared host compatibility layer.
# IN/OUT: Host/node/field-name in; child node or None out.
# CALL FLOW: Nearly every Gateway decoder uses this leaf helper.
def _field(host: Any, node: Any, name: str) -> Any:
    return host.child_by_field(node, name)


# FLOW: _only_named_child
# WHY: Require expression wrappers to contain exactly one semantic child before decoding.
# IN/OUT: Syntax node in; sole named child or None out.
# CALL FLOW: Parenthesis and return decoders call it; predicate/publication stages consume results.
def _only_named_child(node: Any) -> Any:
    children = [
        child
        for child in node.named_children
        if child.type not in {"line_comment", "block_comment"}
    ]
    return children[0] if len(children) == 1 else None


# FLOW: _unwrap_parentheses
# WHY: Accept harmless grouping while bounding malformed/deep wrapper traversal.
# IN/OUT: Possibly parenthesized node in; underlying node or None out.
# CALL FLOW: Invocation, lambda, publisher, and predicate decoders use this leaf normalizer.
def _unwrap_parentheses(node: Any) -> Any:
    current = node
    for _depth in range(16):
        if current is None or current.type != "parenthesized_expression":
            return current
        current = _only_named_child(current)
    return None


# FLOW: _arguments
# WHY: Distinguish a real invocation argument list from malformed/non-invocation syntax.
# IN/OUT: Host/invocation in; named argument nodes or None out.
# CALL FLOW: All Gateway call-shape decoders consume this leaf helper.
def _arguments(host: Any, invocation: Any) -> list[Any] | None:
    arguments = _field(host, invocation, "arguments")
    return (
        [
            child
            for child in arguments.named_children
            if child.type not in {"line_comment", "block_comment"}
        ]
        if arguments is not None
        else None
    )


# FLOW: _invocation_name
# WHY: Read one call name consistently and fail closed when syntax lacks it.
# IN/OUT: Host/unit/invocation in; simple call-name String or None out.
# CALL FLOW: Chain, predicate, helper, and publisher decoders use this leaf helper.
def _invocation_name(host: Any, unit: dict[str, Any], invocation: Any) -> str | None:
    if invocation is None or invocation.type != "method_invocation":
        return None
    name_node = _field(host, invocation, "name")
    return _text(unit, name_node) if name_node is not None else None


# FLOW: _raw_type_node
# WHY: Remove bounded generic/annotation wrappers before genuine type resolution.
# IN/OUT: Java type node in; raw node or None out.
# CALL FLOW: `_known_type` calls it; activation and helper gates consume the Boolean result.
def _raw_type_node(node: Any) -> Any:
    current = node
    for _depth in range(16):
        if current is None:
            return None
        if current.type == "generic_type":
            children = list(current.named_children)
            current = children[0] if children else None
            continue
        if current.type == "annotated_type":
            candidates = [
                child for child in current.named_children if child.type != "annotation"
            ]
            current = candidates[-1] if len(candidates) == 1 else None
            continue
        return current
    return None


# FLOW: _known_type
# WHY: Prove exact Spring Gateway package identity rather than matching a simple name.
# IN/OUT: Unit/type/simple-name/package in; Boolean provenance verdict out.
# CALL FLOW: Parameter indexing, publisher activation, lambda typing, and helper binding call it.
def _known_type(
    host: Any,
    unit: dict[str, Any],
    type_node: Any,
    simple_name: str,
    package: str,
) -> bool:
    raw = _raw_type_node(type_node)
    return bool(
        raw is not None
        and host.resolve_known_type(
            unit, _text(unit, raw), simple_name, (package,), raw
        )
        == package
    )


# FLOW: _formal_parameters
# WHY: Normalize supported Java formal syntax into exact reusable parameter facts.
# IN/OUT: Host/unit/parameter-list in; tuple of FormalParameter or None out.
# CALL FLOW: `_build_method_index` calls it; MethodFact and all signature gates consume output.
def _formal_parameters(
    host: Any, unit: dict[str, Any], parameters_node: Any
) -> tuple[FormalParameter, ...] | None:
    records: list[FormalParameter] = []
    for parameter in parameters_node.named_children:
        if parameter.type in {"line_comment", "block_comment"}:
            continue
        # Varargs, receiver parameters, and syntactically unusual parameters
        # are not needed by the bounded publisher/helper contracts.
        if parameter.type != "formal_parameter":
            return None
        type_node = _field(host, parameter, "type")
        name_node = _field(host, parameter, "name")
        if type_node is None or name_node is None:
            return None
        records.append(FormalParameter(_text(unit, name_node), type_node, parameter))
    return tuple(records)


# FLOW: _build_method_index
# WHY: Index source methods once so helper resolution stays owner-scoped and deterministic.
# IN/OUT: Workspace/host in; MethodIndex out.
# CALL FLOW: `analyze_spring_gateway` calls it; publisher scan and `_helper_shape` consume it.
# Example: two owners with `inventory(...)` remain distinct owner/name buckets.
def _build_method_index(workspace: dict[str, Any], host: Any) -> MethodIndex:
    # The index retains owner FQN plus method name.  It is used only after the
    # publisher/helper shapes prove exact ownership; no global same-name helper
    # search is allowed.
    methods: list[MethodFact] = []
    for fname in sorted(workspace["units"]):
        unit = workspace["units"][fname]
        for node in _walk(unit["tree"].root_node):
            if node.type != "method_declaration":
                continue
            parent = getattr(node, "parent", None)
            owner_node = host.nearest_enclosing_type(node)
            if (
                parent is None
                or parent.type != "class_body"
                or owner_node is None
                or getattr(parent, "parent", None) is None
                or host.tree_node_key(parent.parent)
                != host.tree_node_key(owner_node)
            ):
                continue
            owner_info = unit["type_infos"].get(host.tree_node_key(owner_node))
            if owner_info is None or not owner_info["workspace_visible"]:
                continue
            name_node = _field(host, node, "name")
            return_type_node = _field(host, node, "type")
            parameters_node = _field(host, node, "parameters")
            body_node = _field(host, node, "body")
            if None in (name_node, return_type_node, parameters_node, body_node):
                continue
            parameters = _formal_parameters(host, unit, parameters_node)
            if parameters is None:
                continue
            methods.append(
                MethodFact(
                    unit=unit,
                    owner_info=owner_info,
                    owner_fqn=host.qualified_type_name(unit, owner_info),
                    node=node,
                    name_node=name_node,
                    return_type_node=return_type_node,
                    parameters_node=parameters_node,
                    body_node=body_node,
                    parameters=parameters,
                    modifiers=frozenset(host.declaration_modifier_names(node)),
                )
            )

    methods.sort(key=lambda fact: (fact.unit["fname"], fact.node.start_byte))
    grouped: dict[tuple[str, str], list[MethodFact]] = {}
    for fact in methods:
        grouped.setdefault((fact.owner_fqn, fact.name), []).append(fact)
    return MethodIndex(
        methods=tuple(methods),
        by_owner_name={key: tuple(value) for key, value in grouped.items()},
    )


# FLOW: _log
# WHY: Make rejected Gateway shapes observable without emitting speculative facts.
# IN/OUT: Host, MethodFact, message, optional evidence node in; no value out.
# CALL FLOW: Publisher and route decoders call it; host diagnostic logging consumes it.
def _log(
    host: Any,
    fact: MethodFact,
    message: str,
    node: Any = None,
) -> None:
    expression = f": {_text(fact.unit, node).strip()}" if node is not None else ""
    host.write_log(
        "Skipped Spring Gateway "
        f"{message} in {fact.unit['fname']} for {fact.owner_name}{expression}"
    )


# FLOW: _known_direct_annotation
# WHY: Prove exact direct annotation identity for the Gateway publication gate.
# IN/OUT: Host/fact/expected name/package in; resolved record or None out.
# CALL FLOW: `_publisher_builder_name` calls it; only a genuine Bean reaches route decoding.
def _known_direct_annotation(
    host: Any,
    fact: MethodFact,
    simple_name: str,
    package: str,
) -> Any:
    matches = []
    for record in host.direct_annotation_records(fact.node):
        if (
            host.resolve_known_annotation(
                fact.unit, record["name_node"], {simple_name}, (package,)
            )
            is not None
        ):
            matches.append(record)
    return matches[0] if len(matches) == 1 else None


# FLOW: _owner_is_unique_concrete_class
# WHY: Avoid attributing publication to abstract, non-class, or duplicate source identities.
# IN/OUT: Workspace and MethodFact in; Boolean owner verdict out.
# CALL FLOW: Public analysis gates each candidate publisher with this leaf proof.
def _owner_is_unique_concrete_class(
    workspace: dict[str, Any], fact: MethodFact
) -> bool:
    if (
        fact.owner_info["node"].type != "class_declaration"
        or fact.owner_info["abstract"]
        or not fact.owner_info["workspace_visible"]
    ):
        return False
    declarations = workspace["type_declarations"].get(fact.owner_fqn, [])
    return bool(
        len(declarations) == 1
        and declarations[0]["unit"] is fact.unit
        and declarations[0]["type_info"] is fact.owner_info
    )


# FLOW: _single_direct_return
# WHY: Limit supported data flow to one direct return expression, optionally rejecting nested returns.
# IN/OUT: MethodFact and policy in; returned expression node or None out.
# CALL FLOW: Helper and publisher decoders call it before interpreting fluent chains.
# Example: `return builder...build();` passes; an `if`-selected return does not.
def _single_direct_return(
    fact: MethodFact, *, reject_nested_returns: bool = True
) -> Any:
    returns = [node for node in _walk(fact.body_node) if node.type == "return_statement"]
    direct = [
        node for node in fact.body_node.named_children if node.type == "return_statement"
    ]
    if len(direct) != 1:
        return None
    if reject_nested_returns and (len(returns) != 1 or returns[0] != direct[0]):
        return None
    return _only_named_child(direct[0])


# FLOW: _publisher_builder_name
# WHY: Activate only genuine Bean RouteLocator publishers with one exact builder formal.
# IN/OUT: Host/MethodFact in; builder variable name or None out.
# CALL FLOW: Public analysis calls it; `_decode_publisher` consumes the proven receiver name.
def _publisher_builder_name(host: Any, fact: MethodFact) -> str | None:
    # Activation is an AND of three independent facts: genuine direct @Bean,
    # genuine RouteLocator return type, and exactly one genuine builder formal.
    # Merely seeing calls named route/path is never sufficient.
    if _known_direct_annotation(
        host, fact, "Bean", SPRING_CONTEXT_ANNOTATION_PACKAGE
    ) is None:
        return None
    if not _known_type(
        host,
        fact.unit,
        fact.return_type_node,
        "RouteLocator",
        GATEWAY_ROUTE_PACKAGE,
    ):
        return None
    builders = [
        parameter
        for parameter in fact.parameters
        if _known_type(
            host,
            fact.unit,
            parameter.type_node,
            "RouteLocatorBuilder",
            GATEWAY_BUILDER_PACKAGE,
        )
    ]
    return builders[0].name if len(builders) == 1 else None


# FLOW: _decode_lambda_parameter
# WHY: Bind a route lambda to exactly one supported PredicateSpec receiver spelling.
# IN/OUT: Host/publisher/lambda in; parameter name or None out.
# CALL FLOW: `_decode_route_lambda` calls it; predicate/helper decoders consume the name.
def _decode_lambda_parameter(host: Any, fact: MethodFact, node: Any) -> str | None:
    parameters = _field(host, node, "parameters")
    if parameters is None:
        return None
    if parameters.type == "identifier":
        return _text(fact.unit, parameters)
    if parameters.type == "inferred_parameters":
        children = list(parameters.named_children)
        return (
            _text(fact.unit, children[0])
            if len(children) == 1 and children[0].type == "identifier"
            else None
        )
    if parameters.type != "formal_parameters":
        return None
    formals = _formal_parameters(host, fact.unit, parameters)
    if formals is None or len(formals) != 1:
        return None
    formal = formals[0]
    return (
        formal.name
        if _known_type(
            host,
            fact.unit,
            formal.type_node,
            "PredicateSpec",
            GATEWAY_BUILDER_PACKAGE,
        )
        else None
    )


# FLOW: _resolve_path
# WHY: Resolve selector paths through shared Java Strings and optional project configuration.
# IN/OUT: Host/fact/workspace/expression/callback in; normalized path or None out.
# CALL FLOW: `_decode_predicate_chain` calls it; PredicateShape then endpoint fan-out consume it.
# Example: a constant `/api/**` can become configured `/edge/api/**`.
def _resolve_path(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    node: Any,
    apply_path: PathTransformer | None,
) -> str | None:
    value = host.resolve_workspace_string_expression(
        fact.unit, node, workspace, fact.owner_name
    )
    if value is None:
        return None
    path = host.combine_paths("", host.normalize_spring_path(value))
    if apply_path is not None:
        path = apply_path(
            path,
            unit=fact.unit,
            owner_name=fact.owner_name,
            surface="gateway",
        )
    return path if isinstance(path, str) and path else None


# FLOW: _resolve_http_method
# WHY: Accept only genuine Spring HttpMethod/RequestMethod enum provenance.
# IN/OUT: Host/fact/expression in; canonical verb or None out.
# CALL FLOW: Predicate decoding calls it; PredicateShape methods feed endpoint fan-out.
def _resolve_http_method(host: Any, fact: MethodFact, node: Any) -> str | None:
    current = _unwrap_parentheses(node)
    if current is None or current.type not in {
        "identifier",
        "field_access",
        "scoped_identifier",
    }:
        return None
    spelling = _text(fact.unit, current).strip()
    method = spelling.rsplit(".", 1)[-1]
    if method not in {*host.SPRING_HTTP_METHODS, "CONNECT"}:
        return None
    expected = (
        (SPRING_HTTP_PACKAGE, "HttpMethod", {*host.SPRING_HTTP_METHODS, "CONNECT"}),
        (
            "org.springframework.web.bind.annotation",
            "RequestMethod",
            set(host.SPRING_HTTP_METHODS),
        ),
    )
    if "." not in spelling:
        owners = [
            f"{package}.{simple_name}"
            for package, simple_name, allowed in expected
            if method in allowed
            if host.static_member_resolves_to(
                fact.unit, method, f"{package}.{simple_name}", current
            )
        ]
        return method if len(owners) == 1 else None
    qualifier = spelling.rsplit(".", 1)[0]
    owners = [
        package
        for package, simple_name, allowed in expected
        if method in allowed
        if host.resolve_known_type(
            fact.unit,
            qualifier,
            simple_name,
            (package,),
            current,
        )
        == package
    ]
    return method if len(owners) == 1 else None


# FLOW: _invocation_chain
# WHY: Linearize a bounded fluent receiver chain without scanning unrelated calls.
# IN/OUT: Host/fact/terminal node in; root plus lexical call list or None out.
# CALL FLOW: `_decode_predicate_chain` calls it, then validates its explicit grammar.
def _invocation_chain(
    host: Any, fact: MethodFact, node: Any
) -> tuple[Any, list[Any]] | None:
    calls: list[Any] = []
    current = _unwrap_parentheses(node)
    for _depth in range(16):
        if current is None or current.type != "method_invocation":
            return current, list(reversed(calls))
        if _arguments(host, current) is None:
            return None
        calls.append(current)
        current = _unwrap_parentheses(_field(host, current, "object"))
    return None


# FLOW: _decode_predicate_chain
# WHY: Extract only path/method selector identity while rejecting identity-changing predicates.
# IN/OUT: Context, expression, exact root, path callback in; PredicateShape or None out.
# CALL FLOW: Direct route lambdas and exact helpers call it; endpoint fan-out consumes shapes.
# Example: `p.path("/x").and().method(HttpMethod.GET)` yields `/x` x GET.
def _decode_predicate_chain(
    host: Any,
    fact: MethodFact,
    workspace: dict[str, Any],
    node: Any,
    root_name: str,
    apply_path: PathTransformer | None,
) -> PredicateShape | None:
    # The accepted identity grammar is intentionally explicit:
    #
    #   p.path(paths...)
    #   p.path(paths...).and().method(methods...)
    #   p.method(methods...).and().path(paths...)
    #
    # Every path x method combination is emitted.  With no method predicate,
    # ``ANY`` states that this route is not method-constrained.
    decoded = _invocation_chain(host, fact, node)
    if decoded is None:
        return None
    root, calls = decoded
    if (
        root is None
        or root.type != "identifier"
        or _text(fact.unit, root) != root_name
    ):
        return None
    names = [_invocation_name(host, fact.unit, call) for call in calls]
    filter_indexes = [
        index for index, name in enumerate(names) if name in {"filter", "filters"}
    ]
    if filter_indexes:
        first_filter = filter_indexes[0]
        if filter_indexes != list(range(first_filter, len(names))):
            return None
        for filter_call in calls[first_filter:]:
            filter_arguments = _arguments(host, filter_call)
            if filter_arguments is None or len(filter_arguments) != 1:
                return None
        calls = calls[:first_filter]
        names = names[:first_filter]
    if names not in (["path"], ["path", "and", "method"], ["method", "and", "path"]):
        return None

    paths: list[str] = []
    methods: list[str] = []
    for name, call in zip(names, calls):
        arguments = _arguments(host, call)
        if arguments is None:
            return None
        if name == "and":
            if arguments:
                return None
            continue
        if not arguments:
            return None
        if name == "path":
            for argument in arguments:
                path = _resolve_path(
                    host, fact, workspace, argument, apply_path
                )
                if path is None:
                    return None
                paths.append(path)
            continue
        for argument in arguments:
            method = _resolve_http_method(host, fact, argument)
            if method is None:
                return None
            methods.append(method)

    return PredicateShape(
        paths=tuple(dict.fromkeys(paths)),
        methods=tuple(dict.fromkeys(methods or ["ANY"])),
    )


# FLOW: _helper_shape
# WHY: Support one stateless same-owner predicate helper without global/data-flow guessing.
# IN/OUT: Publisher/index/helper invocation/lambda name in; PredicateShape or None out.
# CALL FLOW: `_decode_route_lambda` falls back here; this binds one helper then calls predicate decoding.
# Example: `p -> inventory(p).uri(...)` binds only `inventory(PredicateSpec)` on that owner.
def _helper_shape(
    host: Any,
    publisher: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    invocation: Any,
    lambda_parameter: str,
    apply_path: PathTransformer | None,
) -> PredicateShape | None:
    # Binding requires ``helper(theLambdaParameter)`` on the same publisher
    # owner, one PredicateSpec formal, one BooleanSpec return, and one direct
    # return expression.  These checks prevent an unrelated overloaded helper
    # or a stateful helper body from being treated as route identity.
    helper_name = _invocation_name(host, publisher.unit, invocation)
    arguments = _arguments(host, invocation)
    receiver = _field(host, invocation, "object")
    if (
        helper_name is None
        or arguments is None
        or len(arguments) != 1
        or arguments[0].type != "identifier"
        or _text(publisher.unit, arguments[0]) != lambda_parameter
        or (
            receiver is not None
            and not (
                receiver.type == "this" and _text(publisher.unit, receiver) == "this"
            )
        )
    ):
        return None
    candidates = [
        candidate
        for candidate in method_index.by_owner_name.get(
            (publisher.owner_fqn, helper_name), ()
        )
        if len(candidate.parameters) == 1
        and _known_type(
            host,
            candidate.unit,
            candidate.parameters[0].type_node,
            "PredicateSpec",
            GATEWAY_BUILDER_PACKAGE,
        )
        and _known_type(
            host,
            candidate.unit,
            candidate.return_type_node,
            "BooleanSpec",
            GATEWAY_BUILDER_PACKAGE,
        )
    ]
    if len(candidates) != 1:
        return None
    helper = candidates[0]
    expression = _single_direct_return(helper)
    if expression is None:
        return None
    return _decode_predicate_chain(
        host,
        helper,
        workspace,
        expression,
        helper.parameters[0].name,
        apply_path,
    )


# FLOW: _decode_route_lambda
# WHY: Separate inbound predicate identity from the one-argument upstream `uri` destination.
# IN/OUT: Route lambda plus analysis context in; PredicateShape or None out.
# CALL FLOW: `_decode_publisher` calls it per route; direct predicate or `_helper_shape` supplies output.
def _decode_route_lambda(
    host: Any,
    publisher: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    node: Any,
    apply_path: PathTransformer | None,
) -> PredicateShape | None:
    if node.type != "lambda_expression":
        return None
    parameter = _decode_lambda_parameter(host, publisher, node)
    body = _unwrap_parentheses(_field(host, node, "body"))
    if parameter is None or body is None or body.type != "method_invocation":
        return None
    if _invocation_name(host, publisher.unit, body) != "uri":
        return None
    uri_arguments = _arguments(host, body)
    predicate = _unwrap_parentheses(_field(host, body, "object"))
    if uri_arguments is None or len(uri_arguments) != 1 or predicate is None:
        return None
    # The destination does not participate in the inbound route identity.
    # Spring accepts dynamic URI expressions here and Noir deliberately
    # ignores them, so only the one-argument call shape is required.

    direct = _decode_predicate_chain(
        host,
        publisher,
        workspace,
        predicate,
        parameter,
        apply_path,
    )
    if direct is not None:
        return direct
    if predicate.type != "method_invocation":
        return None
    return _helper_shape(
        host,
        publisher,
        workspace,
        method_index,
        predicate,
        parameter,
        apply_path,
    )


# FLOW: _route_lambda_argument
# WHY: Normalize one- and two-argument `route` overloads while ignoring route ID metadata.
# IN/OUT: Host/publisher/workspace/call in; lambda node or None out.
# CALL FLOW: `_decode_publisher` calls this leaf helper before decoding each route branch.
def _route_lambda_argument(
    host: Any,
    publisher: MethodFact,
    workspace: dict[str, Any],
    call: Any,
) -> Any:
    arguments = _arguments(host, call)
    if arguments is None or len(arguments) not in {1, 2}:
        return None
    # The optional route ID is diagnostic/runtime bookkeeping, not inbound
    # endpoint identity. Dynamic IDs remain valid and are deliberately ignored.
    candidate = arguments[-1]
    return candidate if candidate.type == "lambda_expression" else None


# FLOW: _decode_publisher
# WHY: Prove one exact `builder.routes().route(...).build()` publication chain.
# IN/OUT: Publisher/index/builder/path callback in; decoded shape/evidence pairs or None out.
# CALL FLOW: Public analysis calls it; it invokes route-lambda decoding and returns rows for `_endpoint`.
# Example: one unsupported route is skipped while valid sibling calls remain branch-local.
def _decode_publisher(
    host: Any,
    publisher: MethodFact,
    workspace: dict[str, Any],
    method_index: MethodIndex,
    builder_name: str,
    apply_path: PathTransformer | None,
) -> list[tuple[PredicateShape, Any]] | None:
    # A rejected route lambda may itself contain a return statement.  It must
    # not invalidate valid sibling route calls in the publisher chain.
    # Starting at build() and walking receivers backwards proves that each
    # accepted route belongs to this exact builder formal; scanning arbitrary
    # calls named route would confuse helper and dead-code calls with published
    # routes.
    expression = _unwrap_parentheses(
        _single_direct_return(publisher, reject_nested_returns=False)
    )
    if expression is None or _invocation_name(host, publisher.unit, expression) != "build":
        return None
    if _arguments(host, expression) != []:
        return None

    route_calls: list[Any] = []
    current = _unwrap_parentheses(_field(host, expression, "object"))
    for _depth in range(256):
        name = _invocation_name(host, publisher.unit, current)
        if name == "route":
            route_calls.append(current)
            current = _unwrap_parentheses(_field(host, current, "object"))
            continue
        if name != "routes" or _arguments(host, current) != []:
            return None
        root = _unwrap_parentheses(_field(host, current, "object"))
        if (
            root is None
            or root.type != "identifier"
            or _text(publisher.unit, root) != builder_name
        ):
            return None
        break
    else:
        return None

    if not route_calls:
        return None
    decoded: list[tuple[PredicateShape, Any]] = []
    for call in reversed(route_calls):
        lambda_node = _route_lambda_argument(
            host, publisher, workspace, call
        )
        shape = (
            _decode_route_lambda(
                host,
                publisher,
                workspace,
                method_index,
                lambda_node,
                apply_path,
            )
            if lambda_node is not None
            else None
        )
        if shape is None:
            _log(host, publisher, "unsupported route lambda", call)
            continue
        decoded.append((shape, call))
    return decoded


# FLOW: _endpoint
# WHY: Materialize one proven Gateway selector as an inbound proxy fact.
# IN/OUT: Publisher, route evidence, verb, path in; endpoint dictionary out.
# CALL FLOW: Public analysis creates it from PredicateShape products; host configuration/output consume it.
def _endpoint(
    host: Any,
    publisher: MethodFact,
    route_call: Any,
    method: str,
    path: str,
) -> dict[str, Any]:
    endpoint = {
        "uri": path,
        "method": method,
        "uri_params": "",
        "SrcFile": publisher.unit["fname"],
        "SrcLine": route_call.start_point.row + 1,
        "SFunction": f"{publisher.owner_name}.{publisher.name}",
        "RouteSrcFile": publisher.unit["fname"],
        "RouteSrcLine": route_call.start_point.row + 1,
        "HandlerSrcFile": publisher.unit["fname"],
        "HandlerSrcLine": publisher.node.start_point.row + 1,
        "protocol": "http",
        "surface": "gateway",
        "direction": "inbound",
        "technology": "spring",
    }
    host.debug_log(endpoint)
    return endpoint


# FLOW: _deduplicate
# WHY: Collapse exact Gateway evidence duplicates and guarantee deterministic order.
# IN/OUT: Raw endpoint iterable in; sorted unique list out.
# CALL FLOW: `analyze_spring_gateway` is the sole caller; global collection consumes result.
def _deduplicate(endpoints: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[Any, ...], dict[str, Any]] = {}
    fields = ("uri", "method", "uri_params", "SrcFile", "SrcLine", "SFunction")
    for endpoint in endpoints:
        unique[tuple(endpoint[field] for field in fields)] = endpoint
    return [unique[key] for key in sorted(unique)]


# FLOW: analyze_spring_gateway
# WHY: Expose bounded Spring Cloud Gateway Java-DSL endpoint recall to the host.
# IN/OUT: Workspace, host, optional configured-path callback in; unique inbound proxy facts out.
# CALL FLOW: Host orchestration calls it; method index, publisher decoder, endpoint builder, and dedup run downstream.
def analyze_spring_gateway(
    workspace: dict[str, Any],
    host: Any,
    *,
    apply_path: PathTransformer | None = None,
) -> list[dict[str, Any]]:
    """Return source-proven Spring Cloud Gateway proxy endpoint rows.

    ``workspace`` is the host's shared Java workspace.  ``apply_path`` is an
    optional integration callback for the owning project's placeholder and
    prefix layer.  It receives ``(path, unit=..., owner_name=...,
    surface="gateway")`` and must return one final path or ``None``.
    """

    # Output carries the publisher as both project owner and conservative
    # handler evidence.  A Gateway route has no local application handler in
    # this source shape; its destination remains forwarding metadata.
    method_index = _build_method_index(workspace, host)
    endpoints: list[dict[str, Any]] = []
    for publisher in method_index.methods:
        if not _owner_is_unique_concrete_class(workspace, publisher):
            continue
        builder_name = _publisher_builder_name(host, publisher)
        if builder_name is None:
            continue
        decoded = _decode_publisher(
            host,
            publisher,
            workspace,
            method_index,
            builder_name,
            apply_path,
        )
        if decoded is None:
            _log(host, publisher, "unsupported RouteLocator publication", publisher.node)
            continue
        for shape, route_call in decoded:
            for path in shape.paths:
                for method in shape.methods:
                    endpoints.append(
                        _endpoint(host, publisher, route_call, method, path)
                    )
    return _deduplicate(endpoints)


__all__ = ["analyze_spring_gateway"]
