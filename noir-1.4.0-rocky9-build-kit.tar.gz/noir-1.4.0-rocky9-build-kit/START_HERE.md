# Standalone Rocky Linux 9 build kit

**This is build automation, not a prebuilt Noir binary/full runtime bundle.**

This archive carries its own complete helpers, templates, tests and handoff.
It does not require the other target's archive. Shared-source helper code
and both entry-point definitions are retained for testing consistency, but
use the following entry point only on the actual named distribution.

Assumption: x86_64. Read README.md, STATUS.json and CODEX_HANDOFF.md first.

```bash
cd noir-1.4.0-rocky9-build-kit
./build-rocky9.sh all
```

Run as an ordinary user with sudo in an online disposable Rocky Linux 9 VM.
The output goes under `out/rocky9/`. Its binary and full archives
must still be qualified in a separate clean target VM offline.
