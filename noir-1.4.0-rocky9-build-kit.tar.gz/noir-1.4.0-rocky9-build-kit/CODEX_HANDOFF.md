# Codex handoff: native Noir 1.4.0 builds and offline installation

## Read this first

The user requested real source-built binary bundles and self-contained offline
runtime bundles for **Rocky Linux 9** and **ALT Linux 10.4**, separately, plus all
build/packaging/install scripts and a maintainable handoff. Architecture was not
specified; this implementation assumes **x86_64**. No change to the Noir source
or upgrade to a later release has been authorized by the task.

**The current delivery is a build kit, not the requested finished native binaries.**
The creation environment was Debian with no target VMs, Crystal/shards, native RPM
toolchain or container engine, and external artifact acquisition was unavailable.
Public upstream files were inspected through web research. Do not mistake that
for fetching/verifying tarballs inside the compiler environment. No Rocky/ALT
Noir build or actual offline installation was performed. Local helper tests and
syntax checks have evidence in `evidence/`; several helper tests deliberately mock
RPM command output. Consult `STATUS.json` before reporting completion.

## Existing implementation

| File | Responsibility |
|---|---|
| `build-rocky9.sh`, `build-alt104.sh` | Native target entry points, default `all` |
| `make-full-rocky9.sh`, `make-full-alt104.sh` | Full bundle from an existing binary staging tree |
| `scripts/bootstrap.sh` | Native development-package installation with sudo |
| `scripts/build.sh` | Pinned acquisition, separate cache/source, compile/test phases |
| `profiles/versions.env` | Noir commit and compiler version/archive SHA-256 |
| `lib/input_audit.py` | First-acquisition byte inventory and prebuild change detection |
| `lib/rpm_bundle.py` | Installed RPM closure, exact acquisition, signature and RPM checks |
| `lib/package.py` | Native bundle layout, passive rules, source snapshot, smoke, tar output |
| `lib/seal.py`, `templates/verify.sh` | Payload SHA-256 inventory and strict verification |
| `templates/noir` | Relocatable launcher; supported bundled-rules environment variable |
| `templates/install.sh` | Offline RPM plan/apply; explicit version-change policy |
| `tests/smoke.py` | Real Noir fixture tests; not run in the creation environment |
| `tests/acceptance-vm.sh` | Destructive-on-test-VM offline install and non-root smoke receipt |
| `tests/test_helpers.py` | Locally runnable unit/shell tests |

The generated binary contains `app/bin/noir`, `app/libexec/noir`, rules, license
material, source/shard snapshot, installer, verifier, manifest and metadata.
A full bundle adds exact native RPM dependencies. `manifest.json` keeps
`clean_target_offline_install: not-yet-tested` and candidate state; a separate
receipt establishes qualification without mutating a checksummed archive.

## Pinned upstream basis

* Noir v1.4.0 commit: `8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4`.
* Crystal 1.21.0 archive: `crystal-1.21.0-1-linux-x86_64.tar.gz`.
* Compiler SHA-256: `744561ee3cee1b06d106cf9ae99b8064b4e017518ac414d6dd23cfafe36560c9`.
* Upstream `shard.yml` declares version 1.4.0 and a Crystal `~> 1.19` constraint;
  its tagged Dockerfile uses Crystal 1.21.0. Do not read that constraint as an
  instruction to ignore the known upstream compiler choice.
* Upstream production lock resolves acp 0.2.0, crest 1.4.1, har 1.2.0,
  http-client-digest_auth 0.6.0, http_proxy 0.15.1, sarif 0.2.0 and toml 0.8.1.
  The lock also lists development-only ameba 1.7.0.
* `src/ext/tree_sitter` C object generation is part of the source build. Reuse of
  those objects across target distributions is forbidden.
* Passive rules are a separate repository. The kit uses a reviewed supplied
  commit or records its first-resolved HEAD. This is not a preverified static pin.
* Noir supports `NOIR_BUNDLED_RULES_PATH`; user-managed rules have precedence.
  Git is required for revision comparisons. Offline local analysis is the scope,
  not remote AI/proxy/target access or automatic rules updates.

All primary source URLs and research caveats are in `docs/SOURCES.md`.

## Priority zero: turn implementation into evidence

1. Read `AGENTS.md`, `README.md`, `STATUS.json`, `docs/ARCHITECTURE.md` and
   `docs/ACCEPTANCE.md`; run `make check`.
2. Obtain actual online x86_64 Rocky 9 and ALT 10.4 build environments matching
   the user's deployment editions and baselines. Record image/ISO provenance,
   package repository configuration and exact `/etc/os-release`. Do not substitute
   a generic p10 rootfs for an unspecified ALT 10.4 edition and claim validation.
3. Run each native `all` wrapper as an ordinary user. Fix observed failures with
   preserved logs and focused regression tests. Do not relax pins/signatures or
   turn off tests merely to emit an archive. Keep each target's working directories,
   compiler and shards cache physically separate.
4. Produce all four actual archives and checksum sidecars. Verify each archive's
   manifest, independent source build, ELF link, source snapshot, passive rules,
   native RPM set and empty-RPM-database transaction result.
5. Install each full archive in a separate clean target VM with networking disabled;
   execute the provided acceptance runner and real project scans. Add native
   negative tests. Write an auditable receipt linked to actual artifact hashes.
6. Update status honestly: archive existence, native build results, qualification
   results and remaining gaps. Never fill missing binaries with placeholders.

## High-priority native risks to investigate

**ALT APT-RPM:** exact `--print-uris --download-only --reinstall` behavior,
`name=epoch:version-release` selection, package split/names and signature output
were not executed on ALT. Some official ALT resources were behind an anti-bot
challenge during research. Inspect native `apt-get --help`, man pages and package
metadata. Test on the user's edition without changing branch. If a different
native acquisition mechanism is needed, preserve exact identity/signature checks
and the final native RPM solver check; do not use Debian dpkg/deb tooling.

**Compiler/native link:** verify the official 1.21.0 tar extraction structure and
compiler execution on both distributions. Confirm clearing compiler library path
variables actually yields native system libraries. Inspect tree-sitter C macro
flags. Check all required native devel packages; add narrowly justified candidates
if needed. Do not fall back to an upstream generic prebuilt Noir executable.

**RPM closure:** Python intentionally over-approximates installed alternatives
rather than implementing RPM's dependency solver. RPM's empty-database `--test`
is authoritative; investigate missing/conflicting packages on failure. Confirm
non-root temporary RPM database operation on both RPM versions. All downloaded
RPMs must have trusted signatures, not merely valid payload digests. Confirm the
target's official trust keyring rather than importing arbitrary bundle keys.

**Functional tests:** fixture syntax/CLI assumptions were checked against source
but not executed. Verify Flask/Spring detection, strict-mode JSON, OAS3 JSON and
Git diff output on real Noir. Investigate upstream suite external prerequisites
without bypassing the suite. A library closure alone cannot prove every optional
plugin/external tool is present; extend seed packages only for explicit workflows.

**Security/operations:** use trusted private transfer/extraction directories;
review installer behavior on real conflicting baseline versions and signature
formats. An RPM transaction is not atomic with application placement; use clean
VM snapshots. Test SELinux behavior on Rocky without disabling enforcement. The
kit does not claim FIPS qualification or carry the complete corresponding sources
for every redistributed OS RPM. Review license obligations before distribution.

## Extending after successful native qualification

Useful next features: immutable native repository snapshots; signed archives;
SPDX/CycloneDX SBOM and license/source-offer handling; exact shard Git revision
pins; an explicitly pinned default passive-rules revision; native Noir RPMs;
install receipts and controlled upgrade/uninstall commands; VM-based CI; tested
CPU/OS-baseline matrix; and a **separate** fully offline rebuild bundle with its
compiler, development RPM closure and shard cache. An offline-runtime bundle
must not be renamed an offline-build bundle without those additional inputs.

Preserve output schema/status compatibility or version it. Keep status tests
honest. Add new functionality only after retaining the original four artifacts'
independence and offline qualification. Do not store credentials/private source
or unreviewed package-repository secrets in public logs or the handoff.

See `docs/NEXT_PROMPTS.md` for ready-to-use continuation requests.
