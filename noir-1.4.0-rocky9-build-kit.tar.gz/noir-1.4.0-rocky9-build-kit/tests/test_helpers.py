#!/usr/bin/env python3
"""Local helper unit tests. These never claim to compile or execute Noir."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

KIT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(KIT / 'lib'))
from rpm_bundle import Package, InstalledClosure, dynamic_paths, parse_packages, rich_names, verify_signature
from seal import seal, digest
from input_audit import inventory
from package import archive_tree, reset_dir


def result(stdout='', stderr='', returncode=0):
    return subprocess.CompletedProcess([], returncode, stdout, stderr)


class RpmIdentityTests(unittest.TestCase):
    def test_absent_epoch(self):
        p = Package.parse('libfoo\t(none)\t1.0\t1.el9\tx86_64')
        self.assertEqual(p.epoch, '0')
        self.assertEqual(p.dnf_spec, 'libfoo-0:1.0-1.el9.x86_64')
        self.assertEqual(p.apt_spec, 'libfoo=1.0-1.el9')
    def test_nonzero_epoch(self):
        p = Package.parse('libfoo\t2\t1.0\talt1\tx86_64')
        self.assertEqual(p.apt_spec, 'libfoo=2:1.0-alt1')
    def test_roundtrip(self):
        p = Package('a', '0', '1', '1', 'noarch')
        self.assertEqual(parse_packages(p.tsv()+'\n'), [p])
    def test_invalid_identity(self):
        with self.assertRaises(ValueError): Package.parse('oops')
    def test_invalid_epoch(self):
        with self.assertRaises(ValueError): Package.parse('x\tNaN\t1\t1\tnoarch')
    def test_rich_simple(self):
        self.assertEqual(rich_names('(foo or bar)'), ['foo', 'bar'])
    def test_rich_elf_and_versions(self):
        self.assertEqual(rich_names('(libfoo.so.1()(64bit) and (bar >= 1.2))'), ['libfoo.so.1()(64bit)', 'bar'])
    def test_rich_conditional(self):
        self.assertEqual(rich_names('(foo if bar else baz)'), ['foo', 'bar', 'baz'])
    def test_valid_signature(self):
        with patch('rpm_bundle.run', return_value=result('Header V4 RSA/SHA256 Signature, key ID 1234: OK\n')):
            self.assertIn('OK', verify_signature('dummy.rpm'))
    def test_unsigned_digest_is_rejected(self):
        with patch('rpm_bundle.run', return_value=result('Header SHA256 digest: OK\nPayload SHA256 digest: OK')):
            with self.assertRaises(RuntimeError): verify_signature('dummy.rpm')
    def test_untrusted_signature(self):
        with patch('rpm_bundle.run', return_value=result('Header V4 RSA/SHA256 Signature: NOKEY\n')):
            with self.assertRaises(RuntimeError): verify_signature('dummy.rpm')
    def test_failed_signature(self):
        with patch('rpm_bundle.run', return_value=result('Signature: BAD', returncode=1)):
            with self.assertRaises(RuntimeError): verify_signature('dummy.rpm')
    def test_dynamic_libraries(self):
        output = ('linux-vdso.so.1 (0xabc)\n'
                  ' libfoo.so.1 => /lib64/libfoo.so.1 (0xabcd)\n'
                  ' /lib64/ld-linux-x86-64.so.2 (0xabcd)\n')
        with patch('rpm_bundle.run', return_value=result(output)):
            self.assertEqual(dynamic_paths('own-test-file'), ['/lib64/ld-linux-x86-64.so.2', '/lib64/libfoo.so.1'])
    def test_missing_dynamic_library(self):
        with patch('rpm_bundle.run', return_value=result('libfoo.so => not found\n')):
            with self.assertRaises(RuntimeError): dynamic_paths('own-test-file')
    def test_static_binary_rejected(self):
        with patch('rpm_bundle.run', return_value=result('statically linked\n')):
            with self.assertRaises(RuntimeError): dynamic_paths('own-test-file')
    def test_closure_cycles_and_rich_alternative(self):
        a = Package('app', '0', '1', '1', 'x86_64')
        b = Package('lib', '0', '1', '1', 'x86_64')
        def fake(args, check=True):
            if '--whatprovides' in args:
                cap = args[args.index('--whatprovides')+1]
                if cap == 'app': return result(a.tsv()+'\n')
                if cap == 'lib.so()(64bit)': return result(b.tsv()+'\n')
                return result(returncode=1)
            if '--requires' in args:
                if args[-1] == a.query: return result('(lib.so()(64bit) or absent)\nrpmlib(Test) = 1\n')
                if args[-1] == b.query: return result('app >= 1\n')
            raise AssertionError(args)
        with patch('rpm_bundle.run', side_effect=fake):
            self.assertEqual(InstalledClosure().walk(['app']), [a,b])
    def test_missing_provider(self):
        with patch('rpm_bundle.run', return_value=result(returncode=1)):
            with self.assertRaises(RuntimeError): InstalledClosure().walk(['absent'])
    def test_wrong_arch_provider(self):
        with patch('rpm_bundle.run', return_value=result('x\t0\t1\t1\taarch64\n')):
            with self.assertRaises(RuntimeError): InstalledClosure().walk(['x'])


class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / 'bundle'; self.root.mkdir()
        shutil.copy2(KIT/'templates/verify.sh', self.root/'verify.sh')
        (self.root/'app').mkdir()
        (self.root/'app/data.txt').write_text('real unit-test data\n')
        seal(self.root)
    def tearDown(self): self.tmp.cleanup()
    def verify(self):
        return subprocess.run([self.root/'verify.sh'], capture_output=True, text=True)
    def test_valid(self): self.assertEqual(self.verify().returncode,0)
    def test_tamper(self):
        (self.root/'app/data.txt').write_text('tampered')
        self.assertNotEqual(self.verify().returncode,0)
    def test_missing(self):
        (self.root/'app/data.txt').unlink()
        self.assertNotEqual(self.verify().returncode,0)
    def test_extra(self):
        (self.root/'unexpected').write_text('extra')
        self.assertNotEqual(self.verify().returncode,0)
    def test_symlink(self):
        (self.root/'link').symlink_to('/etc/passwd')
        self.assertNotEqual(self.verify().returncode,0)
    def test_symlink_seal_rejected(self):
        (self.root/'link').symlink_to('/etc/passwd')
        with self.assertRaises(ValueError): seal(self.root)
    def test_traversal(self):
        (self.root/'SHA256SUMS').write_text('0'*64+'  ./../elsewhere\n')
        self.assertNotEqual(self.verify().returncode,0)
    def test_unsafe_filename(self):
        (self.root/'spaces here').write_text('oops')
        with self.assertRaises(ValueError): seal(self.root)
    def test_duplicate_manifest(self):
        p = self.root/'SHA256SUMS'; p.write_text(p.read_text()*2)
        self.assertNotEqual(self.verify().returncode,0)
    def test_archive_and_checksum(self):
        path = self.root.parent/'test.tar.gz'
        archive_tree(self.root, path)
        self.assertEqual(path.with_name(path.name+'.sha256').read_text().split()[0], digest(path))
        with tarfile.open(path) as archive:
            self.assertIn('bundle/app/data.txt', archive.getnames())
    def test_reset_guard(self):
        with self.assertRaises(ValueError): reset_dir(self.root.parent, self.root)


class InputAuditTests(unittest.TestCase):
    def test_modification_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'src').mkdir(); (root/'tool').mkdir()
            file=root/'src/test.cr'; file.write_text('first')
            before=inventory(root/'src',root/'tool'); file.write_text('second')
            self.assertNotEqual(before,inventory(root/'src',root/'tool'))
    def test_generated_outputs_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'src/bin').mkdir(parents=True); (root/'tool').mkdir()
            (root/'src/test.cr').write_text('source'); before=inventory(root/'src',root/'tool')
            (root/'src/bin/noir').write_bytes(b'unit-test-only'); (root/'src/parser.o').write_bytes(b'unit-test-only')
            self.assertEqual(before,inventory(root/'src',root/'tool'))
    def test_toolchain_changes_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'src').mkdir(); (root/'tool').mkdir()
            file=root/'tool/compiler'; file.write_text('first')
            before=inventory(root/'src',root/'tool'); file.write_text('second')
            self.assertNotEqual(before,inventory(root/'src',root/'tool'))


class EntryPointTests(unittest.TestCase):
    def test_shell_syntax(self):
        for path in list(KIT.rglob('*.sh')) + [KIT/'templates/noir']:
            if 'work' not in path.parts and 'out' not in path.parts:
                with self.subTest(path=str(path)):
                    p = subprocess.run(['bash','-n',path],capture_output=True,text=True)
                    self.assertEqual(p.returncode,0,p.stderr)
    def test_installer_help(self):
        p = subprocess.run([KIT/'templates/install.sh','--help'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('--plan',p.stdout)
    def test_build_help(self):
        for target in ['rocky9','alt104']:
            p = subprocess.run([KIT/f'build-{target}.sh','--help'],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
    def test_invalid_target(self):
        p = subprocess.run([KIT/'scripts/build.sh','not-a-target','fetch'],capture_output=True,text=True)
        self.assertNotEqual(p.returncode,0)
        self.assertIn('Unknown target',p.stderr)
    @unittest.skipUnless('ID=debian' in Path('/etc/os-release').read_text(), 'guard evidence specific to this Debian host')
    def test_debian_rejected(self):
        for target in ['rocky9','alt104']:
            p = subprocess.run([KIT/f'build-{target}.sh','all'],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
            self.assertIn('Need ',p.stderr)

if __name__ == '__main__': unittest.main(verbosity=2)
