#!/usr/bin/env python3
"""Functional Noir smoke test. Only generated local source fixtures are scanned."""
import argparse
import json
import os
import re
import socket
import subprocess
import tempfile
from pathlib import Path


def strings(value):
    if isinstance(value, dict):
        for key, item in value.items():
            yield str(key)
            yield from strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from strings(item)
    elif isinstance(value, str):
        yield value


def smoke(app, output, require_no_net=False):
    app, output = Path(app).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    interfaces = sorted(name for _, name in socket.if_nameindex())
    isolated = not any(name != 'lo' for name in interfaces)
    if require_no_net and not isolated:
        raise RuntimeError('Network isolation required, found interfaces: ' + repr(interfaces))
    results = {'network_interfaces': interfaces, 'network_isolated': isolated,
               'scope': 'generated local fixtures; not a clean-VM install test', 'tests': []}
    with tempfile.TemporaryDirectory(prefix='noir-smoke-') as tmp:
        root = Path(tmp)
        home = root / 'home'; home.mkdir()
        project = root / 'project'; project.mkdir()
        env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'HOME': str(home),
               'NOIR_HOME': str(home / 'noir'), 'LC_ALL': 'C', 'LANG': 'C',
               'NO_COLOR': '1', 'GIT_CONFIG_NOSYSTEM': '1',
               'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0'}
        exe = app / 'bin/noir'
        def command(name, args, cwd=None):
            p = subprocess.run([str(x) for x in args], cwd=cwd, env=env,
                               text=True, capture_output=True, timeout=180)
            (output / (name + '.stdout')).write_text(p.stdout)
            (output / (name + '.stderr')).write_text(p.stderr)
            if p.returncode != 0:
                raise RuntimeError('{} exited {}: {}'.format(name, p.returncode, p.stderr))
            results['tests'].append(name)
            return p.stdout
        version = command('version', [exe, 'version'])
        if not re.search(r'(?<![\d.])1\.4\.0(?![\d.])', version):
            raise RuntimeError('Unexpected Noir version: ' + version)
        command('help', [exe, '--help'])
        techs = command('techs', [exe, 'list', 'techs'])
        if 'flask' not in techs.lower() or 'spring' not in techs.lower():
            raise RuntimeError('Missing Flask/Spring analyzer registrations.')
        (project / 'requirements.txt').write_text('Flask==3.0.0\n')
        app_py = project / 'app.py'
        app_py.write_text('from flask import Flask\napp = Flask(__name__)\n'
                          '@app.route("/healthz", methods=["GET"])\n'
                          'def healthz():\n    return "ok"\n')
        (project / 'pom.xml').write_text('<project><dependencies><dependency>'
            '<groupId>org.springframework.boot</groupId>'
            '<artifactId>spring-boot-starter-web</artifactId>'
            '</dependency></dependencies></project>\n')
        (project / 'DemoController.java').write_text(
            'import org.springframework.web.bind.annotation.*;\n'
            '@RestController\n@RequestMapping("/api")\n'
            'public class DemoController {\n'
            '  @GetMapping("/ping") public String ping() { return "pong"; }\n}\n')
        common = ['scan', str(project), '--no-color', '--no-log', '--no-spinner', '--strict']
        scan = json.loads(command('scan-json', [exe] + common + ['-f', 'json']))
        values = set(strings(scan))
        if '/healthz' not in values or '/api/ping' not in values:
            raise RuntimeError('Expected Flask /healthz and Spring /api/ping endpoints were not found.')
        oas = json.loads(command('scan-oas3', [exe] + common + ['-f', 'oas3']))
        if not str(oas.get('openapi', '')).startswith('3.') or '/healthz' not in oas.get('paths', {}):
            raise RuntimeError('Invalid OAS3 smoke-test output.')
        rules = app / 'share/passive_rules'
        if not list(rules.rglob('*.yml')) and not list(rules.rglob('*.yaml')):
            raise RuntimeError('Bundled passive rules are missing.')
        # Cold NOIR_HOME: exercise the upstream bundled-rules fallback, not a cache.
        # --strict makes zero loaded rules/analyzer failures a nonzero exit.
        json.loads(command('passive-cold-home', [exe] + common + ['-P', '-f', 'json']))
        git = ['git', '-C', str(project)]
        command('git-init', git + ['init', '-q'])
        command('git-add-1', git + ['add', '.'])
        identity = ['-c', 'user.name=Noir Bundle Test', '-c', 'user.email=noir-test@example.invalid',
                    '-c', 'commit.gpgsign=false', '-c', 'core.hooksPath=/dev/null']
        command('git-commit-1', git + identity + ['commit', '-qm', 'baseline'])
        with app_py.open('a') as f:
            f.write('\n@app.route("/new-endpoint", methods=["GET"])\n'
                    'def newer():\n    return "new"\n')
        command('git-add-2', git + ['add', '.'])
        command('git-commit-2', git + identity + ['commit', '-qm', 'new endpoint'])
        diff = json.loads(command('diff-ref', [exe] + common + ['--diff-ref', 'HEAD~1', '-f', 'json'], cwd=project))
        if '/new-endpoint' not in set(strings(diff)):
            raise RuntimeError('Git revision comparison did not report the new endpoint.')
    results['status'] = 'passed'
    (output / 'smoke-results.json').write_text(json.dumps(results, indent=2) + '\n')
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--require-no-net', action='store_true')
    args = parser.parse_args()
    print(json.dumps(smoke(args.app, args.out, args.require_no_net), indent=2))
