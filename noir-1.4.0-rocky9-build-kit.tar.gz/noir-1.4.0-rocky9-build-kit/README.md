# OWASP Noir 1.4.0 — independent Rocky 9 / ALT 10.4 build and handoff kit

**Delivery status: build automation and handoff, not prebuilt Noir binaries.**
No native Rocky/ALT compilation or clean-target installation was executed in the
creation environment. The requested two binary archives and two full runtime
archives are **not included**. They are the outputs of running this kit on the
respective real target distributions. See `STATUS.json` and `evidence/` for the
exact executed checks. Native integration remains unvalidated, especially the
ALT APT-RPM acquisition path; do not treat this as a production-qualified release.

## Contract and assumptions

| Item | Choice |
|---|---|
| Noir | v1.4.0; exact commit `8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4` |
| Architecture | x86_64 only; other architectures need a separate implementation |
| Rocky | Real Rocky Linux 9 installation, preferably cloned from your target baseline |
| ALT | Real ALT Linux 10.4 installation of the same edition/baseline as your target |
| Compiler | Crystal 1.21.0, archive SHA-256 pinned in `profiles/versions.env` |
| Linkage | Each platform's native dynamic libraries; no shared/private glibc |
| Full bundle | Offline installation/runtime closure for a normal installed base OS |
| Not included | Full offline compiler environment, OS image, AI models or remote services |

The ALT label is deliberately **not** treated as interchangeable with any generic
p10/p11/Sisyphus image. Existing repository configuration is retained. Record
`/etc/os-release`, the exact edition, repository branch and VM/image provenance.
The host distribution's CPU baseline still applies even with generic codegen.

## Start with two separate online build VMs

Use disposable native VMs, ordinary users with sudo, and separate copies of the
kit. No Docker registry or cross-compilation is required. A developer workstation
or an air-gapped production host is not the place to install build dependencies.
Plan an initial allocation of 4 vCPU, 8 GiB RAM and 20 GiB free disk per VM as an
**untested planning allowance**, then measure. Large upstream tests may require
more resources. `CRYSTAL_WORKERS=2` is the default.

On the **Rocky Linux 9** builder:

```bash
cd /path/to/noir-1.4.0-build-handoff
./build-rocky9.sh all
```

On the **ALT Linux 10.4** builder:

```bash
cd /path/to/noir-1.4.0-build-handoff
./build-alt104.sh all
```

Do not prefix these build commands with sudo. The bootstrap step invokes sudo
for OS packages; source compilation runs as the ordinary user. Rocky bootstrap
enables CRB. ALT bootstrap uses APT-RPM and resolves development-library names
from enabled native repository metadata. Neither path uses the other OS's RPMs.

Each `all` run is intended to install build dependencies, acquire and verify
inputs, compile Noir and vendored C code, run upstream tests, create and test a
binary bundle, gather its native RPM closure, validate that closure and create a
full bundle. A failed phase stops the pipeline and preserves diagnostic logs.
Native execution may expose additional fixes needed; failure is not converted
into a successful-looking empty archive.

### Expected outputs — generated only after successful native execution

```text
out/rocky9/noir-1.4.0-rocky9-x86_64-binary.tar.gz
out/rocky9/noir-1.4.0-rocky9-x86_64-full.tar.gz
out/alt104/noir-1.4.0-alt104-x86_64-binary.tar.gz
out/alt104/noir-1.4.0-alt104-x86_64-full.tar.gz
```

Each archive receives an adjacent `.sha256` file. Each extracted bundle includes
its own `SHA256SUMS`, `manifest.json`, `verify.sh`, `install.sh`, source snapshot,
license material, native ELF and logs. The full bundle additionally includes
`rpms/` and dependency/signature validation metadata. They are **candidate**
bundles until independently installed and tested on clean targets offline.

## Binary versus full bundle

The binary bundle contains the independently compiled ELF executable, a
relocatable `bin/noir` launcher, passive rules, source/shard snapshot and metadata.
It does not include native runtime RPMs. It can be run from an extracted folder
when the required native libraries and Git already exist:

```bash
./app/bin/noir version
./app/bin/noir scan /path/to/source -f json --no-color --no-spinner
```

The full bundle contains the same application plus exact native RPM dependencies,
including Git, CA certificates, Python for verification, installer prerequisites
and the dependencies those packages themselves require. This may be considerably
larger than the direct ELF library set. It is not a complete Linux distribution.

The underlying program remains upstream Noir; no source patch is applied. The
launcher supplies the shipped passive-rules path through Noir's supported
environment variable. It does not modify `LD_LIBRARY_PATH` or hide an alternate
libc. Local static scanning does not need Java/Python application frameworks to
be installed merely to read their source files. Optional actions that invoke
external tools or remote services must be qualified separately.

## Offline deployment

Read `docs/RUNTIME-README.md` before moving a full archive to an air gap. Verify
the external archive checksum through a separately trusted channel, extract as
an ordinary user, inspect it, then use its local installer:

```bash
sha256sum -c noir-1.4.0-rocky9-x86_64-full.tar.gz.sha256
tar -xzf noir-1.4.0-rocky9-x86_64-full.tar.gz
cd noir-1.4.0-rocky9-x86_64-full
./verify.sh
sudo ./install.sh --plan
sudo ./install.sh --apply
noir version
```

Use the ALT filename on ALT, never the Rocky filename. The installer is offline
only; it does not contact repository servers. It verifies trusted RPM signatures,
checks installed versions and runs an RPM test transaction before committing.
It refuses to replace an unrelated `noir` command or application prefix.

**Different installed package versions are blocked by default.** Prefer a
matching baseline or rebuild for your target. After reviewing the plan and
creating a VM snapshot, `--allow-package-changes` permits normal RPM upgrades;
it never permits dependency bypasses, forced downgrades or package erasure.
Package installation is not an atomic/automatically reversible operation.

## Independent phases and options

```bash
./build-rocky9.sh bootstrap
./build-rocky9.sh fetch
./build-rocky9.sh build
./build-rocky9.sh binary
./make-full-rocky9.sh
# ALT equivalents: build-alt104.sh and make-full-alt104.sh
```

`all` performs bootstrap and all remaining phases. `make-full-*` requires an
existing verified binary staging tree and an unchanged builder RPM inventory.
Do not update the build VM between compilation and full-bundle creation.

```bash
WORK_ROOT=/srv/noir-work OUT_ROOT=/srv/noir-out ./build-rocky9.sh all
# Optional: provide the reviewed passive-rules 40-hex commit on first fetch.
RULES_COMMIT=REPLACE_WITH_REVIEWED_40_HEX_COMMIT ./build-rocky9.sh fetch
```

Do not run the last example literally with its placeholder. With no override,
the rules HEAD is resolved once and retained under `work/<target>/rules.commit`.
Reusing a workspace does not silently refresh it. For identical rules across two
independent builds, supply the same reviewed commit to both. Shards use Noir's
lock file and their exact first-acquired bytes are inventoried and archived.
This is controlled provenance, **not a claim of bit-for-bit reproducible builds**.

`RUN_UPSTREAM_TESTS=0` records an explicit upstream-test skip.
`REQUIRE_NETWORK_ISOLATION=0` disables builder smoke isolation for diagnostics.
Neither setting qualifies a release. `EXTRA_RUNTIME_PACKAGES="native names"`
adds explicit RPM seeds for an additional tested workflow. Paths used by the
build must be absolute and contain no whitespace or shell metacharacters.

## Validation and handoff

Run `make check` without network access for kit helper tests. This is not a
Noir compilation. Clean-native acceptance instructions are in
`docs/ACCEPTANCE.md`; `tests/acceptance-vm.sh` automates the installing test phase.

For Codex, begin with `CODEX_HANDOFF.md`, `AGENTS.md`, `STATUS.json`,
`docs/ACCEPTANCE.md` and `docs/SOURCES.md`. Suggested next prompts are in
`docs/NEXT_PROMPTS.md`. Do not mark runtime artifacts present until their bytes
exist and evidence identifies the actual target on which they were tested.
