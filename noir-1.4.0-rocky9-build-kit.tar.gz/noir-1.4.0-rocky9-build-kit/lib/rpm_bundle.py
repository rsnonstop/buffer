#!/usr/bin/env python3
"""Capture native RPM runtime dependencies without omitting installed packages.

The installed RPM database identifies the exact packages used by the build.
RPM's own transaction checker, against an EMPTY database, is the final closure
validator; the dependency walker is not claimed to be a replacement RPM solver.
"""
import argparse
import dataclasses
import json
import os
import re
import shlex
import subprocess
import tempfile
from pathlib import Path

QF = '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n'


def run(args, check=True):
    p = subprocess.run([str(x) for x in args], text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       env=dict(os.environ, LC_ALL='C'))
    if check and p.returncode:
        raise RuntimeError('Command failed: {}\n{}\n{}'.format(
            shlex.join([str(x) for x in args]), p.stdout, p.stderr))
    return p


@dataclasses.dataclass(frozen=True, order=True)
class Package:
    name: str
    epoch: str
    version: str
    release: str
    arch: str

    @classmethod
    def parse(cls, line):
        fields = line.strip().split('\t')
        if len(fields) != 5:
            raise ValueError('Invalid RPM identity: ' + repr(line))
        if fields[1] in ('(none)', '', '(null)'):
            fields[1] = '0'
        if not fields[1].isdigit():
            raise ValueError('Invalid RPM epoch: ' + repr(line))
        return cls(*fields)

    @property
    def query(self):
        return '{}-{}-{}.{}'.format(self.name, self.version, self.release, self.arch)

    @property
    def dnf_spec(self):
        return '{}-{}:{}-{}.{}'.format(self.name, self.epoch, self.version, self.release, self.arch)

    @property
    def apt_spec(self):
        evr = '{}-{}'.format(self.version, self.release)
        if self.epoch != '0':
            evr = self.epoch + ':' + evr
        return self.name + '=' + evr

    def tsv(self):
        return '\t'.join(dataclasses.astuple(self))


def parse_packages(text):
    return [Package.parse(x) for x in text.splitlines() if x.strip()]


def rich_names(requirement):
    """Over-approximate named atoms in a rich requirement, keeping ELF () intact.

    Include all INSTALLED alternatives. Missing alternatives are left to RPM's
    final transaction check, which understands conditionals and version ranges.
    """
    names = []
    skip_version = False
    for word in requirement.split():
        word = word.lstrip('(')
        while word.endswith(')') and word.count(')') > word.count('('):
            word = word[:-1]
        if not word:
            continue
        if skip_version:
            skip_version = False
            continue
        if word in ('>=', '<=', '=', '>', '<', '=='):
            skip_version = True
        elif word not in ('and', 'or', 'if', 'unless', 'else', 'with', 'without'):
            names.append(word)
    return names


def dynamic_paths(binary):
    output = run(['ldd', binary]).stdout
    if 'not found' in output:
        raise RuntimeError('Missing linked library:\n' + output)
    paths = set()
    for line in output.splitlines():
        m = re.search(r'=>\s+(/\S+)', line)
        if not m:
            m = re.match(r'\s*(/\S+)\s+\(', line)
        if m:
            paths.add(m.group(1))
    if not paths:
        raise RuntimeError('Expected native dynamic library paths from ldd.')
    return sorted(paths)


class InstalledClosure:
    def __init__(self):
        self.cache = {}
        self.edges = []

    def providers(self, capability, mandatory=True):
        if capability not in self.cache:
            p = run(['rpm', '-q', '--whatprovides', capability, '--qf', QF], check=False)
            self.cache[capability] = parse_packages(p.stdout) if p.returncode == 0 else []
        candidates = self.cache[capability]
        compatible = sorted(set(x for x in candidates if x.arch in ('x86_64', 'noarch')))
        if not compatible and mandatory:
            raise RuntimeError('No installed x86_64/noarch RPM provides: ' + capability)
        return compatible

    def walk(self, seeds):
        pending = []
        for seed in seeds:
            pending.extend(self.providers(seed))
        selected = set()
        while pending:
            package = pending.pop()
            if package in selected:
                continue
            selected.add(package)
            reqs = run(['rpm', '-q', '--requires', package.query]).stdout.splitlines()
            for req in reqs:
                req = req.strip()
                if not req or req.startswith('rpmlib('):
                    continue
                rich = req.startswith('(')
                names = rich_names(req) if rich else [req.split()[0]]
                for name in names:
                    if name.startswith('rpmlib('):
                        continue
                    for provider in self.providers(name, mandatory=not rich):
                        self.edges.append((package.query, req, provider.query))
                        if provider not in selected:
                            pending.append(provider)
        return sorted(selected)


def verify_signature(path):
    p = run(['rpm', '-Kv', path], check=False)
    text = p.stdout + p.stderr
    if (p.returncode or re.search(r'NOKEY|NOT OK|BAD|NOTTRUSTED', text, re.I)
            or not re.search(r'(?:signature|\bgpg\b|\bpgp\b).*\bOK\b', text, re.I)):
        raise RuntimeError('RPM signature is not trusted/valid: {}\n{}'.format(path, text))
    return text


def download_rpms(target, packages, directory, metadata):
    directory.mkdir(parents=True, exist_ok=True)
    log = metadata / 'download.log'
    if target == 'rocky9':
        # Exact NEVRA requests are intentionally not dependency-filtered by DNF.
        # Every installed package in the closure is downloaded explicitly.
        p = run(['dnf', 'download', '--arch=x86_64,noarch',
                 '--downloaddir=' + str(directory)] + [x.dnf_spec for x in packages])
        log.write_text(p.stdout + p.stderr)
    elif target == 'alt104':
        # APT-RPM, NOT Debian APT: --reinstall forces URIs for installed packages.
        # --print-uris avoids installing or altering the build machine.
        cache = directory.parent / 'apt-download-cache'
        (cache / 'partial').mkdir(parents=True, exist_ok=True)
        p = run(['apt-get', '-y', '--print-uris', '--download-only', '--reinstall',
                 '-o', 'Debug::NoLocking=1', '-o', 'Dir::Cache::archives=' + str(cache),
                 'install'] + [x.apt_spec for x in packages])
        log.write_text(p.stdout + p.stderr)
        uris = []
        for line in p.stdout.splitlines():
            if not line.startswith("'"):
                continue
            parts = shlex.split(line)
            if len(parts) < 2 or not re.match(r'^(https?|ftp)://', parts[0]):
                continue
            filename = parts[1]
            if not re.fullmatch(r'[A-Za-z0-9_+.:~%-]+\.rpm', filename):
                raise RuntimeError('Unexpected APT-RPM download filename: ' + filename)
            uris.append((parts[0], filename))
        if not uris:
            raise RuntimeError('APT-RPM returned no package URIs. Check exact versions and --reinstall support.')
        for uri, filename in uris:
            destination = directory / filename
            run(['curl', '--fail', '--location', '--retry', '3',
                 '--proto', '=https,http,ftp', '--output', str(destination) + '.part', uri])
            Path(str(destination) + '.part').replace(destination)
        # Cache is outside the sealed bundle and contains no runtime dependency.
    else:
        raise ValueError('Unknown target')


def capture(target, binary, directory, metadata, extra=()):
    directory = Path(directory).resolve()
    metadata = Path(metadata).resolve()
    metadata.mkdir(parents=True, exist_ok=True)
    # Include installer/verifier prerequisites as well as core Noir runtime.
    seeds = ['bash', 'coreutils', 'grep', 'sed', 'findutils', 'diffutils',
             'tar', 'gzip', 'rpm', 'ca-certificates', '/usr/bin/git', 'python3',
             'util-linux'] + list(extra)
    paths = dynamic_paths(binary)
    for path in paths:
        seeds.append(path)
        if os.path.realpath(path) != path:
            seeds.append(os.path.realpath(path))
    closure = InstalledClosure()
    packages = closure.walk(seeds)
    # Multiple versions of the same name/architecture cannot be deployed as one
    # ordinary upgrade transaction; fail rather than choosing an arbitrary one.
    keys = [(x.name, x.arch) for x in packages]
    if len(keys) != len(set(keys)):
        raise RuntimeError('Closure contains multiple versions of one RPM. Use a clean builder.')
    (metadata / 'runtime-rpms.tsv').write_text(''.join(x.tsv() + '\n' for x in packages))
    (metadata / 'runtime-seeds.json').write_text(json.dumps(seeds, indent=2) + '\n')
    (metadata / 'dependency-edges.tsv').write_text(''.join('\t'.join(x) + '\n' for x in sorted(set(closure.edges))))
    download_rpms(target, packages, directory, metadata)
    actual = {}
    signature_logs = []
    for path in sorted(directory.glob('*.rpm')):
        signature_logs.append(verify_signature(path))
        rows = parse_packages(run(['rpm', '-qp', '--qf', QF, path]).stdout)
        if len(rows) != 1 or rows[0] in actual:
            raise RuntimeError('Duplicate/invalid RPM: ' + str(path))
        # Repository cache names may contain percent-encoded epochs. Normalize
        # to a safe name without losing exact identity (which stays in metadata).
        canonical = directory / (rows[0].query + '.rpm')
        if not re.fullmatch(r'[A-Za-z0-9_.+@=-]+\.rpm', canonical.name):
            raise RuntimeError('Unsupported RPM identity filename: ' + canonical.name)
        if canonical != path:
            if canonical.exists():
                raise RuntimeError('RPM canonical filename collision: ' + canonical.name)
            path.rename(canonical)
        actual[rows[0]] = canonical
    if set(actual) != set(packages):
        raise RuntimeError('Downloaded RPM set differs from the exact requested closure.\nMissing: {}\nUnexpected: {}'.format(
            sorted(set(packages) - set(actual)), sorted(set(actual) - set(packages))))
    (metadata / 'rpm-signatures.log').write_text('\n'.join(signature_logs))
    with tempfile.TemporaryDirectory(prefix='noir-empty-rpmdb-') as temp:
        db = Path(temp) / 'db'
        db.mkdir()
        run(['rpm', '--dbpath', db, '--initdb'])
        # This executes NO package scriptlets and changes NO system packages.
        # RPM itself checks version predicates and rich/conditional dependencies.
        p = run(['rpm', '--dbpath', db, '-U', '--test', '--ignoresize'] +
                [actual[x] for x in sorted(actual)])
        (metadata / 'empty-rpmdb-closure-test.log').write_text(p.stdout + p.stderr + '\nPASS\n')
    return packages


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target', choices=['rocky9', 'alt104'], required=True)
    p.add_argument('--binary', required=True)
    p.add_argument('--rpms', required=True)
    p.add_argument('--metadata', required=True)
    p.add_argument('--extra', nargs='*', default=[])
    args = p.parse_args()
    capture(args.target, args.binary, args.rpms, args.metadata, args.extra)
