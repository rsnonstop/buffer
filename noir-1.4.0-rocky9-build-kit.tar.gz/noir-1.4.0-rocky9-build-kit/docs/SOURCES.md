# Primary sources and useful continuation references

Research date: **2026-10-06**. Use tagged/commit-pinned source for the 1.4.0 build.
Moving documentation and repository branches may describe newer behavior. The
following were public references, not downloaded input artifacts in this kit.

## Noir release and implementation

| Source | Why it matters |
|---|---|
| [Repository](https://github.com/owasp-noir/noir) | Upstream code, issues, documentation |
| [v1.4.0 release](https://github.com/owasp-noir/noir/releases/tag/v1.4.0) | Requested release and release notes; published September 27, 2026 |
| [Pinned commit](https://github.com/owasp-noir/noir/commit/8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4) | Exact source identity used by this kit |
| [Tagged shard.yml](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/shard.yml) | Version, compiler constraint, main target and shard dependencies |
| [Tagged shard.lock](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/shard.lock) | Locked upstream dependency versions |
| [Tagged Dockerfile](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/Dockerfile) | Upstream Crystal 1.21.0 choice, production build, rules/Git runtime handling |
| [Tagged justfile](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/justfile) | Release/test commands and generated C object cleanup |
| [Tagged C/tree-sitter source tree](https://github.com/owasp-noir/noir/tree/v1.4.0/src/ext/tree_sitter) | Native C build inputs and third-party notices |
| [Tagged spec suite](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/spec/suite.cr) | Upstream test entry point |
| [CLI router](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/src/cli/router.cr) | Version/list/scan commands and legacy argument handling |
| [Scan command](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/src/cli/commands/scan.cr) | Strict mode, passive options, output and revision-diff CLI |
| [OAS3 output builder](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/src/output_builder/oas3.cr) | Confirms that `-f oas3` emits JSON with OpenAPI paths |
| [Passive-rules updater](https://raw.githubusercontent.com/owasp-noir/noir/v1.4.0/src/utils/passive_rules_updater.cr) | Supported rules env variable, user/bundled precedence and fetch behavior |
| [Passive-rules repository](https://github.com/owasp-noir/noir-passive-rules) | Separate rules input; choose and record an exact revision |

## Crystal and Shards

| Source | Why it matters |
|---|---|
| [Crystal 1.21.0 release](https://github.com/crystal-lang/crystal/releases/tag/1.21.0) | Compiler release context |
| [1.21.0 asset list and checksums](https://github.com/crystal-lang/crystal/releases/expanded_assets/1.21.0) | Archive name and SHA-256 verified in public release metadata |
| [Selected compiler archive](https://github.com/crystal-lang/crystal/releases/download/1.21.0/crystal-1.21.0-1-linux-x86_64.tar.gz) | Connected builder downloads this independently for each OS |
| [Tarball installation](https://crystal-lang.org/install/from_targz/) | Compiler archive layout and native development libraries |
| [Crystal 1.21 manual](https://crystal-lang.org/reference/1.21/man/crystal/index.html) | Build/link flags and library-path environment variables |
| [Shards 1.21 manual](https://crystal-lang.org/reference/1.21/man/shards/index.html) | Production lock behavior and install/check commands |
| [Compiler distribution build scripts](https://github.com/crystal-lang/distribution-scripts) | Why compiler tarballs and optional library assets need inspection |
| [Distribution Linux Dockerfile](https://raw.githubusercontent.com/crystal-lang/distribution-scripts/master/linux/Dockerfile) | Moving reference only; inspect exact release behavior natively |

Selected archive SHA-256:
`744561ee3cee1b06d106cf9ae99b8064b4e017518ac414d6dd23cfafe36560c9`.
It is pinned in `profiles/versions.env`. A SHA published beside an archive is not
an independent cryptographic attestation of publisher identity. Authenticating
upstream acquisition remains part of supply-chain policy.

## Native package management and target information

| Source | Why it matters |
|---|---|
| [DNF download plugin](https://dnf-plugins-core.readthedocs.io/en/latest/download.html) | Installed packages can otherwise be omitted; exact acquisition/--alldeps distinctions |
| [RPM manual](https://rpm.org/docs/4.20.x/man/rpm.8.html) | Native query, signature and transaction concepts; consult target-installed version too |
| [Rocky documentation](https://docs.rockylinux.org/) | Native OS/repository administration; use the actual 9.x target baseline |
| [ALT/BaseALT documentation catalog](https://www.basealt.ru/documentation) | Actual products/editions; do not equate every p10 image with ALT 10.4 |
| [ALT APT documentation](https://www.altlinux.org/APT_%D0%B2_ALT_Linux) | APT-RPM context; target-native man pages are important |
| [ALT Docker documentation](https://www.altlinux.org/Docker) | Useful future container context, not proof of exact 10.4 edition identity |
| [ALT p10 package catalog](https://packages.altlinux.org/en/p10/) | Native package names, builds and source RPMs |
| [ALT p10 zstd source package](https://packages.altlinux.org/en/p10/srpms/zstd/) | Example native devel package naming |

**ALT research limitation:** some wiki/package pages returned an anti-bot challenge
in this session. Exact APT-RPM flag behavior and all devel package names were not
validated on a live ALT system. Candidate package-name resolution in bootstrap
reduces guessing but is not native proof. Codex should inspect `apt-get --help`,
`man apt-get`, `apt-cache show`, `rpm --version` and enabled repository configuration
on the actual ALT 10.4 edition before calling the path supported.

The future release process should save immutable source identities and repository
snapshot metadata alongside the artifacts, not merely this links document.
