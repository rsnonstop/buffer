# Using a generated Noir binary or full offline bundle

This file is included in the build kit and copied into each generated runtime
archive. Its presence inside the **build kit** does not mean a runtime archive
has already been generated. Inspect `bundle-kind.txt` and `manifest.json` in an
actual extracted runtime archive.

## What “offline” means

A **full** bundle is intended to install on an already functioning, compatible
Rocky 9 or ALT 10.4 x86_64 OS without fetching packages. Bash, RPM and ordinary
base-OS utilities must already be runnable to launch the installer. It does not
bootstrap an empty disk, install Linux, include development tools for rebuilding,
or reproduce remote services/AI models. Optional Noir requests to remote URLs,
proxies, repository hosts or AI endpoints cannot work without those services.
Local source analysis and the packaged passive rules are the qualified scope.

The target's distribution, edition and native package baseline matter. A bundle
from one OS is not a replacement for a build for the other OS. A later Rocky 9
build is not automatically compatible with every earlier Rocky 9 minor-version
baseline. ALT repositories must match the actual deployed edition and branch.

## Verify before privileged execution

On the connected side, obtain the archive and its `.sha256`. Authenticate the
checksum through a trusted channel outside the archive. A checksum delivered
alongside malicious bytes is not an authenticity proof. RPM signatures are
checked separately against the target OS's already trusted keyring. The installer
will not import a key from its own untrusted payload.

Move both files through your approved air-gap transfer process. Extract as an
ordinary user in a private directory, not a group/world-writable staging area.
Check the archive before extraction and inspect its top-level paths. For Rocky:

```bash
sha256sum -c noir-1.4.0-rocky9-x86_64-full.tar.gz.sha256
tar -tzf noir-1.4.0-rocky9-x86_64-full.tar.gz
tar -xzf noir-1.4.0-rocky9-x86_64-full.tar.gz
cd noir-1.4.0-rocky9-x86_64-full
./verify.sh
sudo ./install.sh --plan
```

For ALT use the `alt104` archive. Keep test logs and extra files **outside** the
extracted bundle; its verifier rejects unexpected files, missing files, symlinks
and modified bytes. Protect the staging folder from other users throughout the
privileged installation. Do not execute a downloaded installer just to discover
whether it is authentic.

## Install and run

After reviewing the plan and taking a VM snapshot:

```bash
sudo ./install.sh --apply
noir version
noir scan /path/to/source -f json --no-color --no-spinner
```

The default application prefix is:

```text
/opt/owasp-noir/1.4.0-rocky9-x86_64
/opt/owasp-noir/1.4.0-alt104-x86_64
```

The default command symlink is `/usr/local/bin/noir`. An unrelated command or
symlink is never overwritten. Use `--no-link` or an alternate `--link` path to
avoid a collision. `--prefix` supports another absolute, root-controlled system
directory. The privileged installer rejects symlink ancestors and writable or
non-root-owned installation ancestors. It is not a per-user installer; the binary
bundle's `app/bin/noir` launcher is the relocatable, no-install alternative.

For an intentionally controlled passive-rules selection on Rocky:

```bash
noir scan /path/to/source -P \
  --passive-scan-path /opt/owasp-noir/1.4.0-rocky9-x86_64/share/passive_rules \
  -f json --no-color --no-spinner --strict
```

Use `alt104` in that path on ALT. The wrapper sets the upstream bundled-rules
environment variable, but an existing user-managed rules directory has upstream
precedence. An explicit path avoids depending on an old user cache. Do not run
`noir rules update` or enable automatic rule updates in the air gap. Update rules
by producing and reviewing a new bundle on the connected side. A pinned snapshot
is not a permanent prohibition on networking: enforce the network boundary in
your environment as well.

## RPM changes and recovery

Exact already installed versions are kept. Missing packages are proposed for
installation. Different installed versions block the default plan/application.
This catches unreviewed base-OS drift instead of silently changing glibc/OpenSSL
or other foundational packages. Following review and a snapshot:

```bash
sudo ./install.sh --plan --allow-package-changes
sudo ./install.sh --apply --allow-package-changes
```

The switch permits a normal RPM upgrade transaction only. Downgrades, conflicts,
missing dependencies, bad signatures and missing signing keys remain errors.
There is no `--nodeps`, `--force`, package erasure or GPG-check bypass. Do not
manually add such options to make a failed bundle appear installable.

RPM scriptlets may have effects outside the application directory. An RPM test
transaction does not prove those scriptlets will succeed, does not guarantee
recovery from power loss, and is not a clean-target test. Application files are
staged and moved into place after checks; this does not make the whole RPM-plus-
application installation atomic. Restore the VM snapshot if the package phase
fails and a safe repair is unclear. Native application files themselves are not
registered as a Noir RPM package; dependency RPMs remain managed by RPM.

Reapplying the identical bundle is supported for an unmodified app prefix. A
new bundle, even with the same Noir version, requires a new prefix or explicit
operator-managed replacement. Back up user configuration/rules separately.
Uninstalling the app means removing its exact command symlink and exact app
prefix after review. **Do not automatically remove shared dependency RPMs.**

## Proof that the bundle works offline

On a separate clean target VM, physically disconnect its virtual NIC or use the
network-isolated acceptance script from the build kit. It installs with no
external network interface and runs Noir as a non-root user. The tests exercise
version/help, Flask and Spring route extraction, JSON/OAS3 output, passive rules
with a fresh user home and Git revision comparison. The test never runs the
fixture's Java/Python application code.

A builder smoke test is not the clean-target acceptance test. Check the manifest's
`clean_target_offline_install` field and any separately supplied qualification
receipt. Retain the receipt alongside the immutable archive; do not edit a
checksummed runtime archive to claim tests have passed.
