# Continuation prompts for Codex

## First: finish the requested real artifacts

```text
Read AGENTS.md, CODEX_HANDOFF.md, STATUS.json, README.md, docs/ACCEPTANCE.md
and docs/SOURCES.md in the attached Noir build/handoff kit.

Finish the original task: produce separate real source-built Noir 1.4.0 x86_64
binary bundles and full offline installation bundles for Rocky Linux 9 and
ALT Linux 10.4, using the actual target editions/baselines. The kit is not a
prebuilt binary delivery. Inspect the available execution environments before
claiming target support. Use separate native VMs, source trees and caches.

Run helper tests; execute native builds; fix observed problems while preserving
source/compiler pins, RPM signature checks and dependency/conflict checks.
Pay particular attention to ALT APT-RPM package acquisition and the native
Crystal/tree-sitter link. Qualify each full bundle in a separate clean target VM
with networking disabled, including the supplied functional and negative tests.

Return the four real runtime archives, all corresponding checksums, tested
scripts, native build logs and offline qualification receipts linked to artifact
hashes. Update STATUS.json honestly and list any still-unexecuted tests. Do not
substitute upstream prebuilt Noir executables or label helper mocks native tests.
```

## Next: add features without losing qualification

```text
Read the existing Noir handoff and native qualification receipts. Preserve Noir
1.4.0, the independent Rocky9/ALT10.4 builds, signature checks and offline behavior.
Implement this additional feature: [DESCRIBE FEATURE]. Add regression tests and
update user instructions. Rebuild and requalify every affected target. Report
which artifact hashes changed and which tests were actually executed.
```

## Optional separate deliverable: offline rebuilding

```text
Extend the qualified workflow with independent offline REBUILD bundles, separate
from the existing offline runtime-install bundles. Include the pinned compiler,
all native development RPMs and their hard dependency closure, the exact Noir and
shard source inputs, passive rules, licenses and trusted provenance metadata.
Demonstrate a fresh source build with no network in a clean matching native VM
for each OS. Do not describe runtime-only dependency bundles as rebuild bundles.
```
