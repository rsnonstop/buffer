# Native qualification checklist

## Required environment matrix

| Build | Deployment test | Initial state |
|---|---|---|
| Actual Rocky 9 x86_64, matched baseline | Separate clean Rocky 9 VM | No Noir, no compiler/devel packages added for the test |
| Actual ALT 10.4 x86_64, matched edition/branch | Separate clean ALT 10.4 VM | No Noir, no compiler/devel packages added for the test |

Record the exact installation media/image identity, checksum when available,
`/etc/os-release`, package inventories, repository identities and CPU features.
Two ordinary VMs are preferred over a generic p10 container standing in for an
unknown ALT edition. Save a snapshot before bootstrap and before offline install.
The kit does not create these operating-system VMs automatically.

## 1. Local kit checks

```bash
make check
```

These checks exercise helper code and shell syntax only. They cannot validate
a native Crystal link, downloaded RPM signatures, ALT's package manager or an
actual Noir analysis. Some helper tests mock RPM output; this is stated in the
test source and evidence. Never report those mocks as real runtime tests.

## 2. Online build and provenance

As a non-root user with sudo in each disposable native builder, run its `all`
wrapper. Keep `RUN_UPSTREAM_TESTS=1` and `REQUIRE_NETWORK_ISOLATION=1`. Retain full
logs, source/shard lock and byte inventory, compiler/GCC versions, ELF metadata,
RPM inventory/signature logs and the saved rules commit. Inspect the C build log.

Confirm both source trees and caches are separate. Confirm the pinned Noir commit
and checksum-pinned compiler were used. Inspect the exact resulting `ldd` library
owners on that OS, absence of RPATH/RUNPATH, and empty-RPM-database closure PASS.
The production ELF must not be an upstream downloaded application binary or a
copy of the other platform's build. Record real archive SHA-256 values and sizes.

## 3. Clean target with no network

Copy the **full** archive, checksum, and build kit's acceptance script/helpers to
a separate clean native test VM through the approved channel. Verify and extract
as an ordinary user. The files must be readable by the designated non-root test
user and protected against modification by others. Do not install developer
packages to make a broken runtime test pass.

As an example, use an existing non-root account `tester` and a new evidence path:

```bash
sudo tests/acceptance-vm.sh --ack-clean-vm \
  /home/tester/noir-1.4.0-rocky9-x86_64-full \
  /var/tmp/noir-acceptance-rocky9 tester
```

Use the ALT bundle and a distinct output path on ALT. Run the script from the
build-kit directory. The acknowledgement is an operator attestation, not an
automatic proof that the VM is clean. The script refuses an existing default Noir
prefix and an existing evidence directory. It records before/after RPM inventories
and runs both the installation and subsequent smoke with no external network
interface. Noir itself runs as the non-root user.

Baseline package differences are blocked by default. Review them first. When
intentionally accepting normal RPM upgrades on the disposable test VM, append
`--allow-package-changes` to the acceptance command. This does not permit forced
downgrades, ignored dependencies or package removal. For a representative air-gap
test, also detach the VM's NIC and document that hypervisor setting.

## 4. Functional criteria

`tests/smoke.py` creates only local, artificial source fixtures. It checks the
reported version, help and technology registration; Flask `/healthz`; Spring
`/api/ping`; parseable JSON and OAS3 output; passive rules from an initially empty
user environment; and Git `HEAD~1` comparison including `/new-endpoint`.
No network access is needed, and fixture application code is not executed.

After these tests, run Noir on representative authorized real source trees,
including the user's Java/Spring/JAX-RS projects if available. Compare expected
endpoints, error/strict-mode behavior, resource use and execution time. The basic
fixtures do not constitute full semantic coverage of every Noir analyzer.

## 5. Negative and operational cases

On disposable VM snapshots, establish all of the following:

* Wrong target/architecture, modified/missing/extra payload file, bad signature or
  missing trusted RPM key is rejected before a package commit.
* Missing RPM and incompatible installed version are rejected. An explicit normal
  upgrade works only when RPM's dependency/conflict checks pass.
* Existing unrelated `/usr/local/bin/noir` is not overwritten. Reapplying the same
  unmodified bundle is idempotent; different bundle contents need a new prefix.
* An old user rules cache cannot silently replace an explicitly selected bundled
  rules path. Cold-home passive scans still work without remote access.
* Root-controlled installed files have expected permissions. An ordinary user can
  analyze source without modifying `/opt` or requesting elevated privileges.

The unit suite verifies several helper-level versions of these conditions; the
native VM tests must verify the actual RPM and application paths too.

## 6. Release decision and receipt

Keep runtime archives immutable. Store qualification evidence alongside them,
including archive hash, manifest hash, target image identity, rules revision,
commands and PASS/FAIL results. `tests/acceptance-vm.sh` produces an installing-test
receipt but does not rewrite the runtime manifest. Review it and the upstream
suite logs before calling the archive qualified. Tests skipped for diagnostics
must be rerun. A newer edition/minor-baseline or rules update needs new evidence.

For the creation session of this kit: **no entries in the native matrix have
been executed**. `STATUS.json` is authoritative about this delivery.
