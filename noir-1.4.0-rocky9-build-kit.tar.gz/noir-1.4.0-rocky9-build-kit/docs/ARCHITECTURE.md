# Design and operational boundaries

## Two genuinely independent build lines

```text
Rocky 9 native VM                   ALT 10.4 native VM
  own compiler archive/cache         own compiler archive/cache
  own pinned source/shards tree      own pinned source/shards tree
  own GCC/native libraries           own GCC/native libraries
             |                                  |
  fresh Crystal + C build             fresh Crystal + C build
             |                                  |
  rocky9 binary candidate             alt104 binary candidate
             |                                  |
  Rocky RPM runtime closure           ALT RPM runtime closure
             |                                  |
  rocky9 full candidate               alt104 full candidate
             |                                  |
  clean Rocky offline VM              clean ALT offline VM
             |                                  |
  qualification receipt               qualification receipt
```

No ELF executable, compiled tree-sitter object, source working directory or
compiler cache is copied from one target build to the other. The same compiler
release may be independently acquired; independence does not require different
compiler versions or different source revisions. Each standalone build-kit
archive includes its own copies of all helpers; it does not depend on its sibling.

`check_target` rejects compilation on the wrong distribution or architecture.
Per-target workspace markers and file locks prevent accidental concurrent reuse.
The builder must not be updated between compilation and RPM collection; the full
stage compares its installed RPM inventory with the recorded compilation state.
Use two fresh VM clones of the intended deployment baseline, not one mutable
container filesystem alternately labelled Rocky and ALT.

## Native dynamic linking rather than a renamed upstream executable

Noir's upstream image builds a static executable using an Alpine Crystal image.
This kit instead builds the pinned source separately against each target OS's
native development libraries. That preserves native glibc/OpenSSL/library ABI
choices and produces distinct artifacts with separate provenance. The output
ELF must be x86_64, dynamically linked, have no RPATH/RUNPATH and have no unresolved
libraries on the builder. `readelf` and `ldd` output are retained.

The selected compiler archive is checksum-pinned. The generic compiler tarball
can also contain native library assets intended for its own build environment.
`CRYSTAL_LIBRARY_PATH` and `CRYSTAL_LIBRARY_RPATH` are cleared so those do not become
the application's link inputs. The application is not run with a global
`LD_LIBRARY_PATH`, and the bundle does not vendor a separate glibc. Native
execution must verify that the compiler/toolchain behaves as intended on both OSs.

The Crystal build uses `--mcpu x86-64`. C objects are deleted before rebuilding;
C/C++ flags request generic x86-64 code generation. Some upstream C build macros
may supply their own flags, so inspect retained compilation logs rather than
assuming every macro consumes `CFLAGS`. OS CPU minimums still apply.

## Dependency acquisition is tied to the actual build

The direct runtime library paths come from `ldd` on the kit's own trusted build,
not on an arbitrary user-provided executable. RPM resolves file/capability owners.
The seed set also includes Git, certificates, verification Python and base
installer utilities. The walker follows installed RPM hard requirements,
including an over-approximation of installed branches of rich dependencies.
It does not pretend to implement the RPM version-comparison/transaction solver.

Every selected exact installed identity is downloaded, even when already present
on the builder. For Rocky this uses `dnf download` with explicit NEVRAs. For ALT it
uses native APT-RPM `--print-uris --download-only --reinstall`, exact EVRs, and
fetches only the returned RPM URLs. Header identity and trusted signatures are
then checked. A missing or unexpected package is fatal.

The complete resulting set is submitted to **RPM's own test transaction with an
empty RPM database**. This is the final check for hard dependency/version/rich
conditional closure, not the Python walk alone. A repository that has removed
an installed version makes the build fail; use a matching repository snapshot
or rebase/rebuild the whole builder, never silently substitute a newer dependency.

The exact ALT APT-RPM options, package naming, signature formatting and edition
behavior require native validation. Documentation pages for some ALT resources
were blocked by an anti-bot challenge during research. The implementation must
be tested before describing ALT support as verified.

Hard dependencies and exercised workflows are covered by this design. RPM weak
recommendations, dynamically discovered optional plugins, organization-specific
PKCS#11/FIPS engines, unusual locales, credentials, custom certificates and every
possible external executable are **not** proven covered by a direct ELF scan.
Native clean-target functional qualification and explicit extra RPM seeds are
how additional workflows enter the supported scope. OS crypto policies are not
modified. FIPS compatibility is not claimed.

## Input provenance, source material and trust

Noir is pinned to a full Git commit; the compiler is pinned to an exact SHA-256.
`shards install --production` uses the upstream lock and refuses lock changes.
The initial fetched source/shard/toolchain bytes are inventoried; the build stage
checks that inventory. Generated binary/object files are excluded from that
input comparison and are rebuilt. The exact source and downloaded shard tree
are archived in each runtime bundle for audit and retained license notices.

The passive-rules commit is either operator-supplied on first fetch or first-
resolved from upstream HEAD and then saved. Shard version tags and first-fetched
rules still rely on their repository trust at acquisition. A subsequent explicit
fetch may re-inventory inputs. The input manifest is not a publisher signature.
For stable builds across targets, review and provide one rules commit to both.

Archives have SHA-256 sidecars; extracted file inventories reject tampering,
missing/extra files and symlinks. Integrity does not establish publisher identity.
RPM signatures rely on the native OS's existing trust database. Archive signing,
SBOM tooling and immutable repository snapshots are prioritized extensions, not
features silently claimed to exist. Review GPL/LGPL/source-offer obligations
before external redistribution of dependency RPMs; retaining Noir/shard sources
alone is not a complete corresponding-source package for every OS component.

## Validation and release state

A binary candidate is created only after compile checks and functional smoke
execution. By default smoke runs in an empty network namespace. If user network
namespaces are unavailable, sudo creates the namespace and drops the app process
back to the original user. A smoke success on a developer machine can still hide
an undeclared installed dependency: therefore a separate clean-target installation
is mandatory. The manifest remains a candidate and records any skipped suite or
disabled network isolation. An independent acceptance receipt identifies the
bundle manifest hash, target baseline, package changes and test results.

No bit-for-bit reproducibility, arbitrary-minor-version portability, universal
optional-feature dependency completeness or successful native execution is
asserted by this build-kit delivery. Those are claims requiring evidence.
