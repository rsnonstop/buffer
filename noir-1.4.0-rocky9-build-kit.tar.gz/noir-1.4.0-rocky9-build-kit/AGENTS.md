# Repository rules for coding agents

This repository implements the user's OWASP Noir **1.4.0** native build and
offline-install workflow for Rocky 9 and ALT 10.4, assumed x86_64.

- Read CODEX_HANDOFF.md and STATUS.json before modifying or claiming completion.
  The initial delivery contains no native Noir ELF or full runtime RPM archive.
- Do not upgrade Noir, replace its pinned commit/compiler checksum, substitute
  prebuilt Noir downloads or combine the two operating systems' artifacts.
- Native correctness requires real target execution. Unit mocks, syntax checks,
  a Debian build or a generic ALT branch image are not target qualification.
- Run `make check` after changes. Add focused tests. Retain native failure logs
  and never replace an observed failure with a fabricated PASS or empty archive.
- Compile as an ordinary user. Restrict privilege to reviewed OS package changes,
  namespace setup and installation. Test installs only in disposable VM snapshots.
- Preserve RPM signature/identity checks, source pins, strict manifests, default
  version-change refusal and RPM's final dependency test. Never add --nodeps,
  --force, --oldpackage, GPG bypass or automatic untrusted signing-key import.
- Preserve the distinction between offline runtime installation and offline
  rebuilding. Preserve candidate/qualified status and immutable artifact hashes.
- Do not call best-effort dependency discovery universal optional-feature
  coverage. Qualify each additional workflow in a clean offline native VM.
- Keep secrets, credentials and user's private project source out of archives and
  logs. Review redistribution duties for native dependency RPMs.
- Artifact names must identify version, OS and architecture. Status/evidence must
  say exactly what ran, where it ran, and which real artifact hashes it validated.
