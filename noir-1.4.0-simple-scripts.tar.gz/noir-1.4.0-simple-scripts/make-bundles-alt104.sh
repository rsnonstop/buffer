#!/usr/bin/env bash
# Optional packaging AFTER the standalone ALT build has finished.
# This helper uses the supplied libraries; build-alt104.sh does not call it.
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

# Use the readable exact native RPM copies prepared by prepare-offline-alt104.sh.
export ALT_NATIVE_RPM_CACHE_DIR=/var/tmp/noir-1.4.0-simple-alt104-native-rpms

# Create the binary bundle and test it in an isolated network namespace.
python3 lib/package.py binary --kit "$PWD" \
  --work /var/tmp/noir-1.4.0-simple-alt104 \
  --out /var/tmp/noir-1.4.0-simple-alt104/bundles --target alt104

# Add exact signed native RPM dependencies for offline installation.
python3 lib/package.py full --kit "$PWD" \
  --work /var/tmp/noir-1.4.0-simple-alt104 \
  --out /var/tmp/noir-1.4.0-simple-alt104/bundles --target alt104
