#!/usr/bin/env bash
# Run ONLY on a connected Linux machine, before copying dled to the Rocky target.
# Prepare compiler, seven shard tarballs and two complete Git bundle files.
# Neither standalone build script calls this preparation script.
set -Eeuo pipefail

if [[ ${1:-} == --help && $# == 1 ]]; then
    printf '%s\n' 'Usage: bash predownload-rocky97-inputs.sh' \
      'Requires curl, git, tar and sha256sum on the connected machine.' \
      'Creates all ten build inputs plus two bundle checksum sidecars in sibling ../dled.' \
      'Keeps reusable Git preparation repositories in sibling ../dled-preparation-rocky97.'
    exit 0
fi
[[ $# == 0 ]] || { printf '%s\n' 'Unknown argument. Use --help.' >&2; exit 2; }
# A caller may previously have pasted the offline build's file-only Git setting.
# This preparation step deliberately needs HTTPS; the target build does not.
unset GIT_ALLOW_PROTOCOL
export GIT_TERMINAL_PROMPT=0
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p ../dled ../dled-preparation-rocky97
cd ../dled

# Fetch and verify the same official compiler archive used by the native builds.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 1200 --proto '=https' --tlsv1.2 \
  https://github.com/crystal-lang/crystal/releases/download/1.21.0/crystal-1.21.0-1-linux-x86_64.tar.gz \
  --output crystal-1.21.0-1-linux-x86_64.tar.gz.part
printf '%s\n' '744561ee3cee1b06d106cf9ae99b8064b4e017518ac414d6dd23cfafe36560c9  crystal-1.21.0-1-linux-x86_64.tar.gz.part' | sha256sum --check --strict -
mv -f crystal-1.21.0-1-linux-x86_64.tar.gz.part crystal-1.21.0-1-linux-x86_64.tar.gz

# acp 0.2.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/hahwul/acp.cr/tar.gz/dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3' \
  --output acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz.part
printf '%s\n' '04745f9ecbd1dbfc151da81b8d509abb78659f567c7dd73ba8ae4c2b6514237e  acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz.part' | sha256sum --check --strict -
mv -f acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz.part acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz

# crest 1.4.1: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/mamantoha/crest/tar.gz/d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a' \
  --output crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz.part
printf '%s\n' 'fca747876255e5dbbf46a99a1b6c1a9589733d9a29e72133afc4d91e0861c43d  crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz.part' | sha256sum --check --strict -
mv -f crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz.part crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz

# har 1.2.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/neuralegion/har/tar.gz/ed748a76ddb83bee8881f7699fe265fda06e9a47' \
  --output har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz.part
printf '%s\n' 'bde6adb8b88dd5db82ebabc8d7209b2fcce7d489e2fd84ee7255226f87caf4fd  har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz.part' | sha256sum --check --strict -
mv -f har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz.part har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz

# http-client-digest_auth 0.6.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/mamantoha/http-client-digest_auth/tar.gz/bab7df78e6693bb52ec251ea4ff8eece24d6494c' \
  --output http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz.part
printf '%s\n' 'b0420556cc842eb5bf16023195cb5e9c664f0b154e4c0cd0ccb865dbd13b691e  http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz.part' | sha256sum --check --strict -
mv -f http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz.part http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz

# http_proxy 0.15.1: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/mamantoha/http_proxy/tar.gz/017f84f1f4c3a4b6f5ce2261bedcd34c59044932' \
  --output http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz.part
printf '%s\n' 'acbe0336a45dafec7ff181d8cf4f45388b00aaeeafde1f17a8923fc36ac17082  http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz.part' | sha256sum --check --strict -
mv -f http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz.part http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz

# sarif 0.2.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/hahwul/sarif.cr/tar.gz/d9d8ada14b8f7a386db02469f8417720600a5f39' \
  --output sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz.part
printf '%s\n' '1193c2ec943754e6873cfc8bea0032e169dd1de73258327a7ca83878c8737df4  sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz.part' | sha256sum --check --strict -
mv -f sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz.part sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz

# toml 0.8.1: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/crystal-community/toml.cr/tar.gz/030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c' \
  --output toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz.part
printf '%s\n' '7976e009d34d8a0f4a5594f67669744cd0fb5df01ceaa8fdadeea28e4be7988e  toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz.part' | sha256sum --check --strict -
mv -f toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz.part toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz

# Fetch the complete history reachable from the pinned Noir commit. Do NOT add
# --depth: shallow bundles omit parent objects needed for a valid offline repo.
git init --bare ../dled-preparation-rocky97/noir.git
git -C ../dled-preparation-rocky97/noir.git fetch --no-tags \
  https://github.com/owasp-noir/noir.git \
  8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4:refs/heads/offline
git -C ../dled-preparation-rocky97/noir.git rev-parse refs/heads/offline | grep -qx '8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4'
[[ $(git -C ../dled-preparation-rocky97/noir.git rev-parse --is-shallow-repository) == false ]]
git -C ../dled-preparation-rocky97/noir.git fsck --full
git -C ../dled-preparation-rocky97/noir.git bundle create --version=2 \
  ../../dled/noir-8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4.bundle.part refs/heads/offline
git -C ../dled-preparation-rocky97/noir.git bundle verify \
  ../../dled/noir-8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4.bundle.part
mv -f noir-8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4.bundle.part noir-8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4.bundle
sha256sum noir-8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4.bundle > noir-8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4.bundle.sha256

# Prepare the pinned rules repository with complete history in the same way.
git init --bare ../dled-preparation-rocky97/rules.git
git -C ../dled-preparation-rocky97/rules.git fetch --no-tags \
  https://github.com/owasp-noir/noir-passive-rules.git \
  427754d45fd70f4ab360bd5b3ba39b666cc233a5:refs/heads/offline
git -C ../dled-preparation-rocky97/rules.git rev-parse refs/heads/offline | grep -qx '427754d45fd70f4ab360bd5b3ba39b666cc233a5'
[[ $(git -C ../dled-preparation-rocky97/rules.git rev-parse --is-shallow-repository) == false ]]
git -C ../dled-preparation-rocky97/rules.git fsck --full
git -C ../dled-preparation-rocky97/rules.git bundle create --version=2 \
  ../../dled/noir-passive-rules-427754d45fd70f4ab360bd5b3ba39b666cc233a5.bundle.part refs/heads/offline
git -C ../dled-preparation-rocky97/rules.git bundle verify \
  ../../dled/noir-passive-rules-427754d45fd70f4ab360bd5b3ba39b666cc233a5.bundle.part
mv -f noir-passive-rules-427754d45fd70f4ab360bd5b3ba39b666cc233a5.bundle.part noir-passive-rules-427754d45fd70f4ab360bd5b3ba39b666cc233a5.bundle
sha256sum noir-passive-rules-427754d45fd70f4ab360bd5b3ba39b666cc233a5.bundle > noir-passive-rules-427754d45fd70f4ab360bd5b3ba39b666cc233a5.bundle.sha256

# Verify the generated transfer sidecars. The target also checks pinned HEADs,
# full Git object consistency, locked versions and original source input bytes.
sha256sum --check --strict noir-8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4.bundle.sha256 noir-passive-rules-427754d45fd70f4ab360bd5b3ba39b666cc233a5.bundle.sha256
printf '%s\n' 'All user-mode Rocky build inputs are ready in sibling dled.' \
  'Copy dled (including the two .sha256 files) beside the build-script directory.'
