#!/usr/bin/env bash
# Optional packaging AFTER the standalone Rocky build has finished.
# This helper uses the supplied libraries; build-rocky97.sh does not call it.
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

# Create the binary bundle and test it in an isolated network namespace.
python3 lib/package.py binary --kit "$PWD" \
  --work /var/tmp/noir-1.4.0-simple-rocky97 \
  --out /var/tmp/noir-1.4.0-simple-rocky97/bundles --target rocky9

# Add exact signed native RPM dependencies for offline installation.
python3 lib/package.py full --kit "$PWD" \
  --work /var/tmp/noir-1.4.0-simple-rocky97 \
  --out /var/tmp/noir-1.4.0-simple-rocky97/bundles --target rocky9
