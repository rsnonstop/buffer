#!/usr/bin/env bash
# Standalone native ALT Server 10.4 build. No other build-kit files are used.
# 1. sudo ./build-alt104.sh --bootstrap
# 2. Optional full bundles: sudo ./prepare-offline-alt104.sh BEFORE compiling.
# 3. ./build-alt104.sh
# A fresh build deliberately refuses an existing work directory. Keep old runs.
set -Eeuo pipefail

if [[ ${1:-} == --help && $# == 1 ]]; then
    printf '%s\n' 'Usage: sudo ./build-alt104.sh --bootstrap' \
      '       ./build-alt104.sh' \
      'Builds pinned Noir 1.4.0 and runs its complete upstream suite as an ordinary user.' \
      'Fresh work: /var/tmp/noir-1.4.0-simple-alt104' \
      'Run the separate make-bundles-alt104.sh afterward to create runtime archives.'
    exit 0
fi
[[ $# == 0 || ( $# == 1 && $1 == --bootstrap ) ]] || { printf '%s\n' 'Unknown argument. Use --help.' >&2; exit 2; }
if [[ $(uname -m) != x86_64 ]] || \
  ! grep -Eq '^ID="?altlinux"?$' /etc/os-release || \
  ! grep -Eq '^VERSION_ID="?10\.4"?$' /etc/os-release; then
    printf '%s\n' 'Requires ALT Server 10.4 x86_64.' >&2
    exit 2
fi

if [[ ${1:-} == --bootstrap ]]; then
    [[ $EUID == 0 ]] || { printf '%s\n' 'Use sudo for --bootstrap only.' >&2; exit 2; }
    # Keep the installed ALT 10.4/p10 repository configuration. No branch switch.
    apt-get update
    apt-get -y install gcc gcc-c++ make git-core curl tar gzip xz findutils \
      diffutils coreutils binutils pkg-config libssl-devel libgc-devel \
      libpcre2-devel libevent-devel libyaml-devel libxml2-devel libzstd-devel \
      zlib-devel libgmp-devel python3 rpm ca-certificates util-linux gnupg alt-gpgkeys

    printf '%s\n' 'Bootstrap complete. Run ./build-alt104.sh as an ordinary user.'
    exit 0
fi

[[ $EUID != 0 ]] || { printf '%s\n' 'Compile as an ordinary user. Root is for --bootstrap only.' >&2; exit 2; }
[[ ! -e /var/tmp/noir-1.4.0-simple-alt104 && ! -L /var/tmp/noir-1.4.0-simple-alt104 ]] || { printf '%s\n' 'Work path exists; preserve or move it before starting a fresh build.' >&2; exit 2; }
mkdir -m 0700 /var/tmp/noir-1.4.0-simple-alt104
cd /var/tmp/noir-1.4.0-simple-alt104
mkdir -p downloads toolchain cache/crystal cache/shards tmp logs metadata suite-home/.config
chmod 0700 tmp suite-home
printf 'alt104\n' > target
exec > >(tee logs/driver.log) 2>&1
trap 'printf "Build failed at line %s; preserve /var/tmp/noir-1.4.0-simple-alt104/logs\n" "$LINENO" >&2' ERR

# Everything belongs to this new target build, including temporary/compiler data.
# Clear generic compiler library overrides so native ALT libraries are linked.
export TMPDIR=/var/tmp/noir-1.4.0-simple-alt104/tmp
export TMP=/var/tmp/noir-1.4.0-simple-alt104/tmp
export TEMP=/var/tmp/noir-1.4.0-simple-alt104/tmp
export CRYSTAL_CACHE_DIR=/var/tmp/noir-1.4.0-simple-alt104/cache/crystal
export SHARDS_CACHE_PATH=/var/tmp/noir-1.4.0-simple-alt104/cache/shards
export CRYSTAL_WORKERS=2
export CRYSTAL_LIBRARY_PATH='' CRYSTAL_LIBRARY_RPATH='' CRYSTAL_OPTS=''
unset SHARDS_OVERRIDE CRYSTAL_PATH LD_LIBRARY_PATH LIBRARY_PATH CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH || true
export CC=/usr/bin/gcc CXX=/usr/bin/g++
export CFLAGS='-O2 -fPIC -march=x86-64 -mtune=generic'
export CXXFLAGS='-O2 -fPIC -march=x86-64 -mtune=generic'
export PATH=/var/tmp/noir-1.4.0-simple-alt104/toolchain/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export GIT_TERMINAL_PROMPT=0

# Independently download and checksum the pinned bootstrap compiler.
curl --fail --location --retry 3 --proto '=https' --tlsv1.2 \
  https://github.com/crystal-lang/crystal/releases/download/1.21.0/crystal-1.21.0-1-linux-x86_64.tar.gz \
  -o downloads/crystal-1.21.0-1-linux-x86_64.tar.gz
printf '%s\n' '744561ee3cee1b06d106cf9ae99b8064b4e017518ac414d6dd23cfafe36560c9  downloads/crystal-1.21.0-1-linux-x86_64.tar.gz' | sha256sum -c -
tar -xzf downloads/crystal-1.21.0-1-linux-x86_64.tar.gz -C toolchain --strip-components=1
[[ $(crystal --version) == 'Crystal 1.21.0 '* ]]

# Pin the upstream application and retain its production shard lock unchanged.
git clone --depth 1 --branch v1.4.0 https://github.com/owasp-noir/noir.git source
[[ $(git -C source rev-parse HEAD) == 8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4 ]]
git -C source diff --quiet
git -C source diff --cached --quiet
if [[ -f source/.gitmodules ]]; then git -C source submodule update --init --recursive; fi
lock_hash=$(sha256sum source/shard.lock | cut -d ' ' -f 1)
(cd source && shards install --production) 2>&1 | tee logs/shards-install.log
[[ $(sha256sum source/shard.lock | cut -d ' ' -f 1) == "$lock_hash" ]]
(cd source && shards check --production)
printf '%s\n' "$lock_hash" > shard-lock.sha256
cp source/shard.lock metadata/shard.lock

# Pin the same reviewed passive-rules revision; do not resolve moving HEAD.
git init rules-source
git -C rules-source remote add origin https://github.com/owasp-noir/noir-passive-rules.git
git -C rules-source fetch --depth 1 origin 427754d45fd70f4ab360bd5b3ba39b666cc233a5
git -C rules-source checkout --detach FETCH_HEAD
[[ $(git -C rules-source rev-parse HEAD) == 427754d45fd70f4ab360bd5b3ba39b666cc233a5 ]]
git -C rules-source diff --quiet
git -C rules-source diff --cached --quiet
printf '427754d45fd70f4ab360bd5b3ba39b666cc233a5\n' > rules.commit
cp rules.commit metadata/rules.commit
cat > metadata/versions.env.txt <<'PINS'
NOIR_VERSION=1.4.0
NOIR_TAG=v1.4.0
NOIR_COMMIT=8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4
NOIR_REPO=https://github.com/owasp-noir/noir.git
CRYSTAL_VERSION=1.21.0
CRYSTAL_ARCHIVE=crystal-1.21.0-1-linux-x86_64.tar.gz
CRYSTAL_SHA256=744561ee3cee1b06d106cf9ae99b8064b4e017518ac414d6dd23cfafe36560c9
RULES_REPO=https://github.com/owasp-noir/noir-passive-rules.git
RULES_COMMIT=427754d45fd70f4ab360bd5b3ba39b666cc233a5
PINS

# Inventory actual source/shard/compiler bytes before compiling, without imports
# from a build kit. Directory symlinks are recorded and never traversed.
/usr/bin/python3 - <<'PY'
import hashlib
import json
import os
from pathlib import Path
entries = {}
for label in ('source', 'toolchain'):
    root = Path(label)
    for base, directories, files in os.walk(root, followlinks=False):
        directories[:] = sorted(x for x in directories if x not in ('.git', '__pycache__', '.crystal'))
        for name in list(directories):
            if (Path(base) / name).is_symlink():
                files.append(name)
                directories.remove(name)
        for name in sorted(files):
            path = Path(base) / name
            relative = path.relative_to(root).as_posix()
            if name == '.git' or (label == 'source' and (name.endswith(('.o', '.a')) or relative in ('bin/noir', 'bin/noir_spec'))):
                continue
            if path.is_symlink():
                entries[label + '/' + relative] = 'symlink:' + os.readlink(path)
            elif path.is_file():
                entries[label + '/' + relative] = hashlib.sha256(path.read_bytes()).hexdigest()
            else:
                raise RuntimeError('Nonregular input: ' + str(path))
Path('metadata/input-files.json').write_text(json.dumps(entries, indent=2, sort_keys=True) + '\n')
print('Recorded independent source/compiler inputs:', len(entries))
PY

# Fresh target-native C and Crystal outputs. Older ALT GC requires Noir's
# upstream-supported cooperative-fiber mode, so CPU parallelism is disabled.
SOURCE_DATE_EPOCH=$(git -C source show -s --format=%ct HEAD)
export SOURCE_DATE_EPOCH
find source/src/ext -type f \( -name '*.o' -o -name '*.a' \) -delete
mkdir -p source/bin
rm -f source/bin/noir source/bin/noir_spec
printf '%s\n' '-Dwithout_mt' > metadata/crystal-build-flags.txt
(cd source && crystal build src/noir.cr --release --no-debug --mcpu x86-64 \
  -Dwithout_mt --verbose -o bin/noir) 2>&1 | tee logs/compile.log
readelf -h source/bin/noir > metadata/elf-header.txt
readelf -d source/bin/noir > metadata/elf-dynamic.txt
readelf --version-info source/bin/noir > metadata/elf-versions.txt
grep -q 'Advanced Micro Devices X86-64' metadata/elf-header.txt
grep -q '(NEEDED)' metadata/elf-dynamic.txt
if grep -Eq 'RPATH|RUNPATH' metadata/elf-dynamic.txt; then printf '%s\n' 'Unexpected private runtime library path.' >&2; exit 1; fi
ldd source/bin/noir > metadata/ldd.txt
if grep -q 'not found' metadata/ldd.txt; then printf '%s\n' 'Unresolved native runtime library.' >&2; exit 1; fi
source/bin/noir version > metadata/noir-version.txt
grep -qx '1.4.0' metadata/noir-version.txt
crystal --version > metadata/crystal-version.txt
shards --version > metadata/shards-version.txt
gcc --version > metadata/gcc-version.txt
cp /etc/os-release metadata/build-os-release.txt
rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > metadata/builder-rpms.tsv
sha256sum source/bin/noir | cut -d ' ' -f 1 > metadata/noir.sha256
printf '8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4\n' > metadata/noir.commit

# Recheck the complete original source/shard/compiler inventory, including
# untracked inputs. Generated objects and application/spec binaries stay excluded.
/usr/bin/python3 - <<'PY'
import hashlib
import json
import os
from pathlib import Path
current = {}
for label in ('source', 'toolchain'):
    root = Path(label)
    for base, directories, files in os.walk(root, followlinks=False):
        directories[:] = sorted(x for x in directories if x not in ('.git', '__pycache__', '.crystal'))
        for name in list(directories):
            if (Path(base) / name).is_symlink():
                files.append(name)
                directories.remove(name)
        for name in sorted(files):
            path = Path(base) / name
            relative = path.relative_to(root).as_posix()
            if name == '.git' or (label == 'source' and (name.endswith(('.o', '.a')) or relative in ('bin/noir', 'bin/noir_spec'))):
                continue
            if path.is_symlink():
                current[label + '/' + relative] = 'symlink:' + os.readlink(path)
            elif path.is_file():
                current[label + '/' + relative] = hashlib.sha256(path.read_bytes()).hexdigest()
            else:
                raise RuntimeError('Nonregular input: ' + str(path))
saved = json.loads(Path('metadata/input-files.json').read_text())
changed = sorted(key for key in set(saved) | set(current) if saved.get(key) != current.get(key))
if changed:
    raise RuntimeError('Source/shard/compiler inputs changed: ' + repr(changed[:20]))
print('Verified unchanged source/compiler inputs:', len(current))
PY

# Run every upstream spec. The suite-only linker option avoids the observed
# large debug-ELF symbol/version-table failure; the release binary omits it.
printf '%s\n' '--link-flags=-Wl,--no-export-dynamic' > metadata/upstream-suite-link-flags.txt
printf '/var/tmp/noir-1.4.0-simple-alt104/suite-home\n' > metadata/upstream-suite-home.txt
(cd source && crystal build spec/suite.cr --mcpu x86-64 -Dwithout_mt \
  --link-flags=-Wl,--no-export-dynamic -o bin/noir_spec && \
  HOME=/var/tmp/noir-1.4.0-simple-alt104/suite-home \
  XDG_CONFIG_HOME=/var/tmp/noir-1.4.0-simple-alt104/suite-home/.config bin/noir_spec) \
  2>&1 | tee logs/upstream-tests.log
[[ $(git -C source rev-parse HEAD) == 8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4 ]]
git -C source diff --quiet
git -C source diff --cached --quiet
[[ $(sha256sum source/shard.lock | cut -d ' ' -f 1) == "$lock_hash" ]]
printf 'passed\n' > metadata/upstream-tests.status

printf '%s\n' 'Native ALT source build and complete upstream suite passed.' \
  'Binary: /var/tmp/noir-1.4.0-simple-alt104/source/bin/noir' \
  'Next: ./make-bundles-alt104.sh (separate optional binary/full packaging).'
