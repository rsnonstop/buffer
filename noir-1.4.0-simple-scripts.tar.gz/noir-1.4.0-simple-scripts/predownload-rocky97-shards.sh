#!/usr/bin/env bash
# Run on a Linux machine with working HTTPS access, BEFORE copying to the target.
# This optional downloader is never called by either standalone build script.
# It creates dled as the sibling of the directory containing this file.
# Every URL uses the immutable commit from the previously validated shard tag.
set -Eeuo pipefail

if [[ ${1:-} == --help && $# == 1 ]]; then
    printf '%s\n' 'Usage: bash predownload-rocky97-shards.sh' \
      'Downloads seven pinned source archives into sibling ../dled.' \
      'Copy that dled directory beside the build-script directory on Rocky.'
    exit 0
fi
[[ $# == 0 ]] || { printf '%s\n' 'Unknown argument. Use --help.' >&2; exit 2; }
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p ../dled
cd ../dled

# acp 0.2.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/hahwul/acp.cr/tar.gz/dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3' \
  --output acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz.part
printf '%s\n' '04745f9ecbd1dbfc151da81b8d509abb78659f567c7dd73ba8ae4c2b6514237e  acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz.part' | sha256sum --check --strict -
mv -f acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz.part acp-dd4e3a8d0fc9df9a5b654d305779ffdc82bcdce3.tar.gz

# crest 1.4.1: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/mamantoha/crest/tar.gz/d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a' \
  --output crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz.part
printf '%s\n' 'fca747876255e5dbbf46a99a1b6c1a9589733d9a29e72133afc4d91e0861c43d  crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz.part' | sha256sum --check --strict -
mv -f crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz.part crest-d3cfbf4102630b0f9c5b53bf8b357d9e472eff2a.tar.gz

# har 1.2.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/neuralegion/har/tar.gz/ed748a76ddb83bee8881f7699fe265fda06e9a47' \
  --output har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz.part
printf '%s\n' 'bde6adb8b88dd5db82ebabc8d7209b2fcce7d489e2fd84ee7255226f87caf4fd  har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz.part' | sha256sum --check --strict -
mv -f har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz.part har-ed748a76ddb83bee8881f7699fe265fda06e9a47.tar.gz

# http-client-digest_auth 0.6.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/mamantoha/http-client-digest_auth/tar.gz/bab7df78e6693bb52ec251ea4ff8eece24d6494c' \
  --output http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz.part
printf '%s\n' 'b0420556cc842eb5bf16023195cb5e9c664f0b154e4c0cd0ccb865dbd13b691e  http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz.part' | sha256sum --check --strict -
mv -f http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz.part http-client-digest_auth-bab7df78e6693bb52ec251ea4ff8eece24d6494c.tar.gz

# http_proxy 0.15.1: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/mamantoha/http_proxy/tar.gz/017f84f1f4c3a4b6f5ce2261bedcd34c59044932' \
  --output http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz.part
printf '%s\n' 'acbe0336a45dafec7ff181d8cf4f45388b00aaeeafde1f17a8923fc36ac17082  http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz.part' | sha256sum --check --strict -
mv -f http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz.part http_proxy-017f84f1f4c3a4b6f5ce2261bedcd34c59044932.tar.gz

# sarif 0.2.0: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/hahwul/sarif.cr/tar.gz/d9d8ada14b8f7a386db02469f8417720600a5f39' \
  --output sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz.part
printf '%s\n' '1193c2ec943754e6873cfc8bea0032e169dd1de73258327a7ca83878c8737df4  sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz.part' | sha256sum --check --strict -
mv -f sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz.part sarif-d9d8ada14b8f7a386db02469f8417720600a5f39.tar.gz

# toml 0.8.1: download an ordinary source tarball, verify, then publish.
curl --fail --location --retry 3 --connect-timeout 30 --max-time 180 --proto '=https' --tlsv1.2 \
  'https://codeload.github.com/crystal-community/toml.cr/tar.gz/030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c' \
  --output toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz.part
printf '%s\n' '7976e009d34d8a0f4a5594f67669744cd0fb5df01ceaa8fdadeea28e4be7988e  toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz.part' | sha256sum --check --strict -
mv -f toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz.part toml-030a3866af395bfb9fe2cce234d9b3d0d8f3ad3c.tar.gz

printf '%s\n' 'All seven pinned shard archives are ready in sibling dled.' \
  'The Rocky build reads them locally; compiler/Noir/passive-rule acquisition remains online.'
