#!/usr/bin/env bash
# Disposable native-root integration test; shares the host kernel, not a VM gate.
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
if [[ ${1:-} == --help || $# -lt 4 ]]; then
    echo 'Usage: sudo tests/lab-rocky9-offline-chroot.sh --ack-disposable-root FULL_ARCHIVE NEW_ROOT NEW_EVIDENCE [VAULT_MINOR]'
    echo 'NEW_ROOT must be a new /var/tmp/noir-rocky9-* directory. VAULT_MINOR example: 9.7.'
    echo 'Baseline preparation needs network. Installation and non-root smoke run in a network namespace.'
    exit 0
fi
[[ $1 == --ack-disposable-root && $# -le 5 ]] || die 'Explicit disposable-root acknowledgement required.'
(( EUID == 0 )) || die 'Run as administrator on the native Rocky lab host.'
check_target rocky9
archive=$(readlink -f -- "$2"); root=$(readlink -m -- "$3"); evidence=$(readlink -m -- "$4")
safe_work_path "$archive"; safe_work_path "$root"; safe_work_path "$evidence"
[[ $root == /var/tmp/noir-rocky9-* && ! -e $root && ! -e $evidence ]] || die 'Use new disposable root and evidence directories.'
[[ $evidence/ != "$root/"* && $root/ != "$evidence/"* ]] || die 'Keep evidence outside the root.'
[[ -f $archive && -f $archive.sha256 ]] || die 'Archive and checksum sidecar required.'
(cd -- "$(dirname -- "$archive")"; sha256sum --check --strict "$(basename -- "$archive").sha256")
mkdir -p "$evidence"
chmod 0750 "$evidence"
collect_evidence() { [[ ! -d $root/evidence ]] || cp -a "$root/evidence/." "$evidence/" || true; }
trap collect_evidence EXIT
sha256sum "$archive" > "$evidence/archive.sha256"
cp /etc/os-release "$evidence/build-host-os-release.txt"
systemd-detect-virt > "$evidence/host-virtualization.txt" || true
getenforce > "$evidence/host-selinux.txt" || true
minor=${5:-9}
[[ $minor == 9 || $minor =~ ^9\.[0-9]+$ ]] || die 'Expected Rocky 9 minor such as 9.7.'
# The lab builder has older signed revisions of these base libraries/release
# packages than the newest 9.7 vault baseline. Select their exact identities at
# initial creation of an EMPTY root; the later installer still forbids forced
# downgrades. Never adjust already installed host packages to match the bundle.
tar -xOzf "$archive" noir-1.4.0-rocky9-x86_64-full/metadata/rpm/runtime-rpms.tsv \
    > "$evidence/bundle-runtime-rpms.tsv"
baseline_pins=()
while IFS=$'\t' read -r name epoch version release arch; do
    case $name in
      libcap|libarchive|rocky-gpg-keys|rocky-release|rocky-repos|libnghttp2|systemd-libs|krb5-libs)
        baseline_pins+=("$name-$epoch:$version-$release.$arch") ;;
    esac
done < "$evidence/bundle-runtime-rpms.tsv"
(( ${#baseline_pins[@]} == 8 )) || die 'Expected all eight matching Rocky baseline pin packages.'
printf '%s\n' "${baseline_pins[@]}" > "$evidence/baseline-pins.txt"
repos=(--disablerepo='*')
if [[ $minor == 9 ]]; then
    repos+=('--enablerepo=baseos,appstream,crb')
else
    for pair in baseos:BaseOS appstream:AppStream; do
        key=${pair%%:*}; directory=${pair#*:}
        repos+=("--repofrompath=noir-lab-$key,https://dl.rockylinux.org/vault/rocky/$minor/$directory/x86_64/os/"
                "--enablerepo=noir-lab-$key" "--setopt=noir-lab-$key.gpgcheck=1"
                "--setopt=noir-lab-$key.gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-Rocky-9")
    done
fi
dnf -y "--installroot=$root" "--releasever=$minor" --setopt=install_weak_deps=False \
    "${repos[@]}" install bash coreutils rpm python3 util-linux \
    shadow-utils tar gzip findutils grep sed diffutils gawk ca-certificates "${baseline_pins[@]}" \
    2>&1 | tee "$evidence/baseline-prepare.log"
# Installroots have no device manager. Supply only standard local devices.
rm -f -- "$root/dev/null"
for device in null:3 zero:5 random:8 urandom:9; do
    mknod -m 0666 "$root/dev/${device%%:*}" c 1 "${device#*:}"
done
chroot "$root" useradd --create-home --shell /bin/bash noirtest
cp "$root/etc/os-release" "$evidence/target-os-release.txt"
rpm --root "$root" -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$evidence/before-rpms.tsv"
for package in gcc gcc-c++ gc gc-devel git git-core; do
    if rpm --root "$root" -q "$package" >/dev/null 2>&1; then
        die "The minimal baseline unexpectedly contains $package."
    fi
done
install -d -m 0755 "$root/bundle" "$root/proc" "$root/evidence"
tar -xzf "$archive" -C "$root/bundle" --no-same-owner
mapfile -t bundle_roots < <(find "$root/bundle" -mindepth 1 -maxdepth 1 -type d)
(( ${#bundle_roots[@]} == 1 )) || die 'Expected one bundle directory.'
bundle=${bundle_roots[0]#"$root"}
[[ $(cat "$root$bundle/target.txt") == rocky9 && $(cat "$root$bundle/bundle-kind.txt") == full ]] || die 'Expected a Rocky9 full bundle.'
mkdir "$root/evidence/smoke"
chown 1000:1000 "$root/evidence/smoke"
# The root and application never see the host's network or process namespace.
unshare --mount --net --pid --fork -- bash -s -- "$root" "$bundle" <<'WORKER' 2>&1 | tee "$evidence/offline-driver.log"
set -Eeuo pipefail
root=$1; bundle=$2
mount --make-rprivate /
mount -t proc proc "$root/proc"
trap 'umount "$root/proc"' EXIT
set +e
chroot "$root" "$bundle/install.sh" --plan > "$root/evidence/default-plan.log" 2>&1
plan_rc=$?
set -e
printf '%s\n' "$plan_rc" > "$root/evidence/default-plan.exit"
# This explicit option permits normal reviewed upgrades. RPM still rejects
# downgrades and dependency/conflict failures, and no host packages are touched.
chroot "$root" "$bundle/install.sh" --plan --allow-package-changes > "$root/evidence/reviewed-plan.log" 2>&1
chroot "$root" "$bundle/install.sh" --apply --allow-package-changes > "$root/evidence/install.log" 2>&1
chroot "$root" runuser -u noirtest -- /usr/bin/python3 "$bundle/tests/smoke.py" \
    --app /opt/owasp-noir/1.4.0-rocky9-x86_64 --out /evidence/smoke --require-no-net \
    > "$root/evidence/smoke-driver.log" 2>&1
chroot "$root" "$bundle/install.sh" --apply --allow-package-changes > "$root/evidence/idempotent.log" 2>&1
cp -L "$root/etc/os-release" "$root/evidence/os-release.original"
printf 'ID=altlinux\nVERSION_ID=10.4\n' > "$root/etc/os-release"
set +e
chroot "$root" "$bundle/install.sh" --apply --allow-package-changes > "$root/evidence/wrong-os-rejection.log" 2>&1
wrong_os_rc=$?
set -e
cp "$root/evidence/os-release.original" "$root/etc/os-release"
rm "$root/evidence/os-release.original"
(( wrong_os_rc != 0 )) || { echo 'Wrong OS identity was accepted'; exit 1; }
printf '%s\n' "$wrong_os_rc" > "$root/evidence/wrong-os-rejection.exit"
cp "$root$bundle/app/bin/noir" "$root/evidence/launcher.original"
printf '\n# tampered fixture\n' >> "$root$bundle/app/bin/noir"
set +e
chroot "$root" "$bundle/install.sh" --apply --allow-package-changes > "$root/evidence/tamper-rejection.log" 2>&1
tamper_rc=$?
set -e
cp "$root/evidence/launcher.original" "$root$bundle/app/bin/noir"
rm "$root/evidence/launcher.original"
(( tamper_rc != 0 )) || { echo 'Tampered payload was accepted'; exit 1; }
printf '%s\n' "$tamper_rc" > "$root/evidence/tamper-rejection.exit"
chroot "$root" "$bundle/verify.sh" > "$root/evidence/final-verification.log" 2>&1
echo 'PASS: offline disposable native root install, non-root cold-home smoke, idempotence, wrong-OS and payload rejection.'
WORKER
cp -a "$root/evidence/." "$evidence/"
rpm --root "$root" -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$evidence/after-rpms.tsv"
"$HERE/tests/lab-rocky9-negative-chroot.sh" --ack-disposable-root "$root" "$evidence"
printf 'PASS: offline disposable Rocky9 root installation and non-root smoke.\nThis shares the host kernel; separate VM and SELinux qualification remain unperformed.\n' > "$evidence/RESULT.txt"
log "Evidence: $evidence; retained disposable root: $root"
