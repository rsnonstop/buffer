#!/usr/bin/env python3
"""Acquire exact trusted native RPMs for the disposable ALT acceptance root.

This is a test fixture, separate from Noir's offline runtime bundle.
"""
import argparse
import json
import os
import platform
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lib'))
from rpm_bundle import InstalledClosure, QF, download_rpms, parse_packages, run, verify_alt_identity, verify_signature
from seal import digest

SEEDS = ['bash', 'coreutils', 'grep', 'sed', 'findutils', 'diffutils', 'tar',
         'gzip', 'rpm', '/usr/bin/awk', '/usr/bin/ldd', 'util-linux',
         'shadow-utils', '/etc/os-release', '/etc/altlinux-release',
         '/etc/apt/vendors.list.d/alt.list']
CONFLICT_SHA256 = 'b09ad32a503a257ea14dfe89c345c3994b757bc61d1716a28478c045ea10a27d'
CONFLICT_URL = ('http://ftp.altlinux.org/pub/distributions/archive/p10/date/2025/03/01/'
                'x86_64/RPMS.classic/libcurl-8.12.0-alt1.x86_64.rpm')


def prepare_version_conflict(out):
    """A signed historical native RPM tests the default version-change refusal."""
    fixture = out / 'version-conflict'
    fixture.mkdir()
    destination = fixture / 'libcurl-old.rpm'
    cache_dir = Path(os.environ.get('ALT_NATIVE_RPM_CACHE_DIR', '/var/cache/apt/archives'))
    try:
        cached = next((path for path in cache_dir.glob('libcurl_8.12.0-alt1*.rpm')
                       if digest(path) == CONFLICT_SHA256), None)
    except PermissionError:
        cached = None
    if cached is not None:
        shutil.copy2(cached, destination)
        origin = str(cached)
    else:
        run(['curl', '--fail', '--location', '--retry', '3', '--proto', '=http,https',
             '--output', destination, CONFLICT_URL])
        origin = CONFLICT_URL
    if digest(destination) != CONFLICT_SHA256:
        raise RuntimeError('Historical version-conflict fixture checksum mismatch')
    signature = verify_signature(destination)
    old = parse_packages(run(['rpm', '-qp', '--qf', QF, destination]).stdout)
    if len(old) != 1 or (old[0].name, old[0].epoch, old[0].version, old[0].release, old[0].arch) != ('libcurl', '0', '8.12.0', 'alt1', 'x86_64'):
        raise RuntimeError('Historical version-conflict fixture identity mismatch')
    current = InstalledClosure().walk(['libcurl'])
    if old[0] in current:
        raise RuntimeError('Historical fixture matches current libcurl; this baseline needs a new conflict fixture')
    (fixture / 'dependency-rpms.tsv').write_text(''.join(x.tsv() + '\n' for x in current if x.name != 'libcurl'))
    (fixture / 'signature.log').write_text(signature)
    (fixture / 'provenance.json').write_text(json.dumps({'source': origin, 'official_snapshot_url': CONFLICT_URL,
         'sha256': CONFLICT_SHA256, 'purpose': 'disposable version-refusal test only'}, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    release = dict(line.rstrip().split('=', 1) for line in Path('/etc/os-release').read_text().splitlines()
                   if '=' in line)
    if platform.machine() != 'x86_64' or release.get('ID', '').strip('"') != 'altlinux' or release.get('VERSION_ID', '').strip('"') != '10.4':
        raise RuntimeError('This fixture requires native ALT Linux 10.4 x86_64')
    out = args.out.resolve()
    if out.exists():
        raise RuntimeError('Choose a new empty baseline-cache directory')
    metadata = out / 'metadata'
    metadata.mkdir(parents=True)
    # runuser may inherit a root-private current directory from its SSH caller.
    os.chdir(out)
    packages = InstalledClosure().walk(SEEDS)
    forbidden = {'git-core', 'python3', 'libgc', 'noir', 'crystal'}
    if forbidden.intersection(x.name for x in packages):
        raise RuntimeError('Baseline unexpectedly contains application/toolchain dependencies')
    (metadata / 'baseline-rpms.tsv').write_text(''.join(x.tsv() + '\n' for x in packages))
    (metadata / 'baseline-seeds.json').write_text(json.dumps(SEEDS, indent=2) + '\n')
    (metadata / 'builder-os-release.txt').write_text(Path('/etc/os-release').read_text())
    directory = out / 'rpms'
    download_rpms('alt104', packages, directory, metadata)
    actual = {}
    signatures = []
    for path in sorted(directory.glob('*.rpm')):
        signatures.append(verify_signature(path))
        rows = parse_packages(run(['rpm', '-qp', '--qf', QF, path]).stdout)
        if len(rows) != 1 or rows[0] in actual:
            raise RuntimeError('Duplicate/invalid baseline RPM')
        verify_alt_identity(path, rows[0])
        destination = directory / (rows[0].query + '.rpm')
        path.rename(destination)
        actual[rows[0]] = destination
    if set(actual) != set(packages):
        raise RuntimeError('Baseline download differs from exact installed closure. Missing: {} Unexpected: {}'.format(
            sorted(set(packages) - set(actual)), sorted(set(actual) - set(packages))))
    (metadata / 'signatures.log').write_text('\n'.join(signatures))
    with tempfile.TemporaryDirectory(prefix='noir-alt-base-db-') as temp:
        db = Path(temp) / 'db'
        db.mkdir()
        run(['rpm', '--dbpath', db, '--initdb'])
        result = run(['rpm', '--dbpath', db, '-U', '--test', '--ignoresize'] + [actual[x] for x in packages])
        (metadata / 'empty-rpmdb-test.log').write_text(result.stdout + result.stderr + '\nPASS\n')
    prepare_version_conflict(out)
    inventory = {str(path.relative_to(out)): digest(path) for path in sorted(out.rglob('*')) if path.is_file()}
    (out / 'baseline-files.json').write_text(json.dumps(inventory, indent=2) + '\n')
    print('Prepared exact signed ALT 10.4 baseline RPMs:', len(packages))


if __name__ == '__main__':
    main()
