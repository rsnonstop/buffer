#!/usr/bin/env bash
# Run ONLY inside a disposable, actually clean VM of the requested target OS.
# This script installs packages/application files and writes qualification evidence.
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
if [[ ${1:-} == --help || $# -lt 4 ]]; then
    echo 'Usage: sudo tests/acceptance-vm.sh --ack-clean-vm BUNDLE_DIR OUTPUT_DIR NONROOT_USER [--allow-package-changes]'
    echo 'OUTPUT_DIR must be outside the checksummed bundle. Take a VM snapshot first.'
    exit 0
fi
[[ "$1" == --ack-clean-vm ]] || die 'Explicit clean-VM acknowledgement required.'
(( EUID == 0 )) || die 'Use sudo in the disposable target VM.'
bundle=$(readlink -f -- "$2"); output=$(readlink -m -- "$3"); test_user=$4
safe_work_path "$bundle"; safe_work_path "$output"
[[ "$output/" != "$bundle/"* && "$output/" != "$HERE/"* ]] || die 'Evidence must be outside the bundle and kit.'
[[ "$test_user" =~ ^[a-zA-Z_][a-zA-Z0-9_-]*$ && $(id -u "$test_user") != 0 ]] || die 'Supply an existing non-root test user.'
extra=()
if (( $# == 5 )); then [[ "$5" == --allow-package-changes ]] || die 'Invalid option'; extra+=("$5"); fi
(( $# <= 5 )) || die 'Too many arguments'
[[ $(cat "$bundle/bundle-kind.txt") == full ]] || die 'Acceptance requires a full bundle.'
target=$(cat "$bundle/target.txt"); check_target "$target"
[[ ! -e "$output" ]] || die 'Choose a new evidence directory.'
mkdir -p "$output"
cp /etc/os-release "$output/target-os-release.txt"
rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$output/before-rpms.tsv"
sha256sum "$bundle/SHA256SUMS" > "$output/bundle-manifest-hash.txt"
prefix=/opt/owasp-noir/1.4.0-$target-x86_64
[[ ! -e "$prefix" ]] || die 'This is not a clean application prefix.'
# Kernel-created network namespace has loopback only. Both package scriptlets
# and application tests inherit it, so even attempted network requests cannot
# reach an external interface. This is stronger than a PATH-based curl wrapper.
unshare --net -- "$bundle/install.sh" --apply "${extra[@]}" 2>&1 | tee "$output/install.log"
mkdir "$output/smoke"
chown "$test_user" "$output/smoke"
unshare --net -- runuser -u "$test_user" -- python3 "$bundle/tests/smoke.py" \
    --app "$prefix" --out "$output/smoke" --require-no-net 2>&1 | tee "$output/smoke-driver.log"
rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$output/after-rpms.tsv"
printf 'PASS: installation and smoke test with no external network interface.\nOperator attested that the target VM was clean.\n' > "$output/RESULT.txt"
log "Qualification evidence: $output (review before calling the bundle qualified)."
