#!/usr/bin/env bash
# Additional native rejection probes for the already installed disposable root.
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
if [[ ${1:-} == --help || $# != 3 ]]; then
    echo 'Usage: sudo tests/lab-rocky9-negative-chroot.sh --ack-disposable-root ROOT EVIDENCE'
    exit 0
fi
[[ $1 == --ack-disposable-root && $EUID == 0 ]] || die 'Use an administrator and explicit disposable-root acknowledgement.'
check_target rocky9
root=$(readlink -f -- "$2"); evidence=$(readlink -f -- "$3")
safe_work_path "$root"; safe_work_path "$evidence"
[[ $root == /var/tmp/noir-rocky9-* && -d $root/opt/owasp-noir/1.4.0-rocky9-x86_64 && -d $evidence ]] || die 'Expected an installed disposable Rocky test root and evidence.'
bundle=/bundle/noir-1.4.0-rocky9-x86_64-full
[[ -f $root$bundle/SHA256SUMS ]] || die 'Expected the unchanged extracted full bundle.'
unshare --mount --net --pid --fork -- bash -s -- "$root" "$bundle" "$evidence" <<'PROBES'
set -Eeuo pipefail
export LC_ALL=C
root=$1; bundle=$2; evidence=$3
mount --make-rprivate /
mount -t proc proc "$root/proc"
trap 'umount "$root/proc"' EXIT
prefix=/opt/owasp-noir/1.4.0-rocky9-x86_64
rejected() {
    local name=$1 pattern=$2
    shift 2
    set +e
    "$@" > "$evidence/$name.log" 2>&1
    local rc=$?
    set -e
    printf '%s\n' "$rc" > "$evidence/$name.exit"
    (( rc != 0 )) && grep -Eq "$pattern" "$evidence/$name.log"
}
chroot "$root" runuser -u noirtest -- /usr/bin/python3 -c \
    'import json,os,socket; print(json.dumps({"uid":os.getuid(), "network_interfaces":[n for _,n in socket.if_nameindex()]}))' \
    > "$evidence/network-isolation.json"
rejected nonroot-prefix-write 'Permission denied' chroot "$root" runuser -u noirtest -- \
    touch "$prefix/nonroot-write-probe"
[[ ! -e $root$prefix/nonroot-write-probe ]]
mv "$root/usr/local/bin/noir" "$root/usr/local/bin/noir.negative-original"
printf 'unrelated existing program\n' > "$root/usr/local/bin/noir"
rejected unrelated-link 'Refusing to replace an existing non-symlink' \
    chroot "$root" "$bundle/install.sh" --plan --allow-package-changes
rm "$root/usr/local/bin/noir"
mv "$root/usr/local/bin/noir.negative-original" "$root/usr/local/bin/noir"
gc_path=$(chroot "$root" readlink -f /lib64/libgc.so.1)
mv "$root$gc_path" "$root$gc_path.negative-original"
rejected missing-runtime 'libgc.so.1.*cannot open shared object file' \
    chroot "$root" runuser -u noirtest -- "$prefix/bin/noir" version
mv "$root$gc_path.negative-original" "$root$gc_path"
mapfile -t keys < <(rpm --root "$root" -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\n')
(( ${#keys[@]} > 0 ))
rpm --root "$root" -e "${keys[@]}"
rejected missing-native-signing-keys 'RPM verification failed|signature is absent or not trusted' \
    chroot "$root" "$bundle/install.sh" --plan --allow-package-changes
# Restore ONLY the trusted key installed by the native baseline's official
# rocky-gpg-keys package. No key from the application bundle is imported.
chroot "$root" rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-Rocky-9
rpm --root "$root" -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort \
    > "$evidence/after-negative-rpms.tsv"
cmp "$evidence/after-rpms.tsv" "$evidence/after-negative-rpms.tsv"
chroot "$root" runuser -u noirtest -- "$prefix/bin/noir" version > "$evidence/restored-version.stdout"
chroot "$root" runuser -u noirtest -- /usr/bin/python3 - <<'INSTALLED_COMMAND' > "$evidence/installed-command.log" 2>&1
import os, pathlib, pwd, shutil, socket, subprocess, tempfile
home = pathlib.Path(pwd.getpwuid(os.getuid()).pw_dir)
os.chdir(home)
with tempfile.TemporaryDirectory(prefix="installed-cli-home.", dir=home) as cold:
    env = dict(os.environ, HOME=cold, PATH="/usr/local/bin:/usr/bin:/bin")
    command = shutil.which("noir", path=env["PATH"])
    print("Network namespace interfaces:", [name for _, name in socket.if_nameindex()], flush=True)
    print("Ordinary context:", subprocess.check_output(["id"], text=True).strip(), flush=True)
    print("Accessible cwd:", os.getcwd(), flush=True)
    print("Cold HOME:", cold, flush=True)
    print("PATH command:", command, flush=True)
    print("Installed symlink:", os.readlink("/usr/local/bin/noir"), flush=True)
    print("Invoked argv:", command, "version", flush=True)
    result = subprocess.run([command, "version"], env=env, text=True, capture_output=True)
    print(result.stdout, end="", flush=True)
    if result.stderr:
        print(result.stderr, end="", flush=True)
    assert result.returncode == 0 and result.stdout.strip() == "1.4.0", "Installed Noir command failed"
INSTALLED_COMMAND
printf 'PASS: non-root prefix write, unrelated link, missing runtime and missing trusted signing keys rejected; fixtures restored.\n' \
    > "$evidence/additional-negative-RESULT.txt"
PROBES
