#!/usr/bin/env bash
# A disposable native minimal-root integration test; not clean-VM qualification.
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
if [[ ${1:-} == --help || $# -ne 4 ]]; then
    printf '%s\n' 'Usage: sudo tests/acceptance-alt104-chroot.sh --ack-disposable-root FULL_ARCHIVE BASE_CACHE OUTPUT_DIR' \
      'Prepare BASE_CACHE with prepare-alt104-chroot-base.py first. OUTPUT_DIR must be new.' \
      'Creates a native package-generated ALT 10.4 root in /var/tmp; preserves it for review.'
    exit 0
fi
(( EUID == 0 )) || die 'The disposable chroot and network namespace require root.'
check_target alt104
[[ "$1" == --ack-disposable-root || "$1" == --inside-namespace ]] || die 'Explicit disposable-root acknowledgement required.'
archive=$(readlink -f "$2"); base=$(readlink -f "$3"); output=$(readlink -m "$4")
safe_work_path "$archive"; safe_work_path "$base"; safe_work_path "$output"
if [[ "$1" == --ack-disposable-root ]]; then
    [[ ! -e "$output" ]] || die 'Choose a new evidence directory.'
    mkdir -p "$output"
    exec unshare --mount --net -- bash "$0" --inside-namespace "$archive" "$base" "$output"
fi
mount --make-rprivate /
for command in rpm rpm2cpio cpio python3 gpg chroot mount mknod; do need "$command"; done
testroot=$(mktemp -d /var/tmp/noir-alt104-root.XXXXXXXX)
# Ordinary users inside the chroot must be able to traverse its root directory.
chmod 0755 "$testroot"
printf '%s\n' "$testroot" > "$output/test-root-path.txt"
trap 'log "ALT disposable test root retained: $testroot"' EXIT
exec > >(tee -a "$output/driver.log") 2>&1
expected=$(awk 'NR == 1 { print $1 }' "$archive.sha256")
[[ "$expected" =~ ^[a-f0-9]{64}$ && $(sha_file "$archive") == "$expected" ]] || die 'Full archive sidecar checksum mismatch.'
printf '%s\n' "$expected" > "$output/full-archive.sha256"
python3 - "$base" <<'PY'
import hashlib, json, sys
from pathlib import Path
root=Path(sys.argv[1]); inventory=json.loads((root/'baseline-files.json').read_text())
for name, expected in inventory.items():
    path=root/name
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise RuntimeError('Baseline cache bytes changed: '+name)
print('Baseline cache byte inventory verified')
PY
python3 - "$output" <<'PY'
import json, socket, sys
from pathlib import Path
interfaces=sorted(name for _,name in socket.if_nameindex())
if any(name!='lo' for name in interfaces): raise RuntimeError('External network interface remains')
(Path(sys.argv[1])/'network-isolation.json').write_text(json.dumps({'interfaces':interfaces,'external_network':False},indent=2)+'\n')
PY
shopt -s nullglob
base_rpms=("$base"/rpms/*.rpm)
(( ${#base_rpms[@]} )) || die 'Baseline cache has no RPMs.'
for package in "${base_rpms[@]}"; do
    signature=$(rpm -Kv "$package" 2>&1) || die "Untrusted baseline RPM: $signature"
    grep -Eiq '(signature|gpg|pgp).*OK' <<<"$signature" || die 'Unsigned baseline RPM.'
    ! grep -Eiq 'NOKEY|NOT OK|\bBAD\b|NOTTRUSTED' <<<"$signature" || die 'Invalid baseline RPM signature.'
    printf '%s\n' "$signature" >> "$output/baseline-signatures.log"
    rpm2cpio "$package" | (cd "$testroot" && cpio -idm --quiet)
done
mkdir -p "$testroot"/{proc,dev,base-rpms,bundle,test-evidence}
mount -t proc proc "$testroot/proc"
mount -t tmpfs -o mode=0755,size=1m tmpfs "$testroot/dev"
mknod -m 0666 "$testroot/dev/null" c 1 3
mknod -m 0666 "$testroot/dev/zero" c 1 5
mknod -m 0666 "$testroot/dev/random" c 1 8
mknod -m 0666 "$testroot/dev/urandom" c 1 9
cp -- "${base_rpms[@]}" "$testroot/base-rpms/"
chroot "$testroot" /usr/bin/rpm --initdb
(chroot "$testroot" /usr/bin/rpm -Kv "/base-rpms/$(basename "${base_rpms[0]}")" || true) > "$output/negative-missing-baseline-signing-keys.log" 2>&1
grep -q NOKEY "$output/negative-missing-baseline-signing-keys.log" || die 'Fresh baseline RPM database unexpectedly trusts native signing keys.'
printf '%s\n' missing-baseline-signing-keys >> "$output/negative-tests-passed.txt"
keyhome=$(mktemp -d /var/tmp/noir-alt104-test-keys.XXXXXXXX)
chmod 0700 "$keyhome"
for fingerprint in 49B01E70C64124E6742EAE7195C584D5AE4AE412 DF6C02E5F174D7CDF792A9CDFF979DEDDA2773BB 357BE37422F73D9CB3A0C8D142F343A2C7EB80F9; do
    actual=$(gpg --no-options --homedir "$keyhome" --batch --no-default-keyring --keyring /usr/lib/alt-gpgkeys/pubring.gpg \
      --with-colons --fingerprint "$fingerprint" | awk -F: '$1=="fpr" { print $10; exit }')
    [[ "$actual" == "$fingerprint" ]] || die 'Reviewed native OS signing key mismatch.'
    gpg --no-options --homedir "$keyhome" --batch --no-default-keyring --keyring /usr/lib/alt-gpgkeys/pubring.gpg \
      --armor --export "$fingerprint" > "$testroot/$fingerprint.asc"
    chroot "$testroot" /usr/bin/rpm --import "/$fingerprint.asc"
done
rm -rf -- "$keyhome"
# Initialize only the disposable baseline's shadow database before package
# scriptlets run. ALT's packaged login.defs enables TCB, while shadow-convert's
# first-install pwconv needs a traditional shadow file for tcb_convert to read.
# Use the native conversion tools and restore the exact packaged configuration.
[[ ! -e "$testroot/etc/shadow" && ! -e "$testroot/etc/tcb" ]] || die 'Baseline auth database unexpectedly exists before initialization.'
cp -p "$testroot/etc/login.defs" "$testroot/login.defs.bootstrap.saved"
sed -i 's/^USE_TCB[[:space:]].*/USE_TCB no/' "$testroot/etc/login.defs"
chroot "$testroot" /usr/sbin/pwconv 2>&1 | tee "$output/baseline-auth-initialization.log"
cp -p "$testroot/login.defs.bootstrap.saved" "$testroot/etc/login.defs"
cmp "$testroot/login.defs.bootstrap.saved" "$testroot/etc/login.defs"
rm "$testroot/login.defs.bootstrap.saved"
chroot "$testroot" /bin/bash -c 'rpm -Uvh /base-rpms/*.rpm' 2>&1 | tee "$output/baseline-install.log"
[[ -d "$testroot/etc/tcb/root" ]] || die 'Native baseline package scriptlets did not initialize TCB shadow files.'
if grep -Eiq 'scriptlet failed|(^|[[:space:]])error:' "$output/baseline-install.log"; then die 'Native baseline package scriptlet failed.'; fi
chroot "$testroot" /bin/bash -c 'cat /etc/os-release; cat /etc/altlinux-release; rpm -qf /etc/os-release /etc/altlinux-release' > "$output/baseline-os-release.txt"
chroot "$testroot" /bin/bash -c '. /etc/os-release; test "$ID" = altlinux; test "$VERSION_ID" = 10.4'
for package in git-core python3 libgc noir crystal; do
    if chroot "$testroot" /usr/bin/rpm -q "$package"; then die "Baseline contains forbidden application/toolchain package: $package"; fi
done
[[ ! -e "$testroot/opt/owasp-noir" && ! -e "$testroot/usr/local/bin/noir" ]] || die 'Baseline contains Noir files.'
chroot "$testroot" /usr/bin/rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$output/before-rpms.tsv"
tar -xzf "$archive" --strip-components=1 -C "$testroot/bundle"
[[ $(cat "$testroot/bundle/target.txt") == alt104 && $(cat "$testroot/bundle/bundle-kind.txt") == full ]] || die 'Wrong target/bundle type.'
chroot "$testroot" /bundle/verify.sh > "$output/bundle-verification.log"
expect_failure() {
    local name=$1; shift
    if "$@" > "$output/negative-$name.log" 2>&1; then die "Negative test unexpectedly succeeded: $name"; fi
    printf '%s\n' "$name" >> "$output/negative-tests-passed.txt"
}
cp -p "$testroot/bundle/app/bin/noir" "$testroot/launcher.saved"
printf '\n# tamper acceptance test\n' >> "$testroot/bundle/app/bin/noir"
expect_failure tampered-bundle chroot "$testroot" /bundle/install.sh --plan
cp -p "$testroot/launcher.saved" "$testroot/bundle/app/bin/noir"
cp -L "$testroot/etc/os-release" "$testroot/os-release.saved"
sed -i 's/^VERSION_ID=.*/VERSION_ID=0/' "$testroot/etc/os-release"
expect_failure wrong-os chroot "$testroot" /bundle/install.sh --plan
cp "$testroot/os-release.saved" "$testroot/etc/os-release"
mkdir -p "$testroot/usr/local/bin"
ln -s /tmp/unrelated "$testroot/usr/local/bin/noir"
expect_failure unrelated-link chroot "$testroot" /bundle/install.sh --plan
rm "$testroot/usr/local/bin/noir"
expect_failure missing-runtime chroot "$testroot" /bundle/app/libexec/noir version
[[ -f "$base/version-conflict/libcurl-old.rpm" ]] || die 'Baseline lacks the signed version-conflict fixture.'
mkdir -p "$testroot/version-fixture"
cp "$base/version-conflict/libcurl-old.rpm" "$testroot/version-fixture/libcurl-old.rpm"
conflict_pending=(/version-fixture/libcurl-old.rpm)
qf='%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n'
while IFS=$'\t' read -r name epoch version release arch; do
    package="$testroot/bundle/rpms/$name-$version-$release.$arch.rpm"
    [[ -f "$package" ]] || die "Full bundle lacks version-fixture dependency: $package"
    identity=$(rpm -qp --qf "$qf" "$package" | sed 's/(none)/0/g; s/(null)/0/g')
    installed=$(chroot "$testroot" /usr/bin/rpm -q "$name" --qf "$qf" 2>/dev/null | sed 's/(none)/0/g; s/(null)/0/g' || true)
    if ! grep -Fxq "$identity" <<<"$installed"; then
        cp "$package" "$testroot/version-fixture/"
        conflict_pending+=("/version-fixture/$(basename "$package")")
    fi
done < "$base/version-conflict/dependency-rpms.tsv"
chroot "$testroot" /usr/bin/rpm -U --test "${conflict_pending[@]}" 2>&1 | tee "$output/version-fixture-rpm-test.log"
chroot "$testroot" /usr/bin/rpm -Uvh "${conflict_pending[@]}" 2>&1 | tee "$output/version-fixture-install.log"
expect_failure package-version-change chroot "$testroot" /bundle/install.sh --plan
grep -Eq 'BLOCKED[[:space:]]+libcurl:' "$output/negative-package-version-change.log" || die 'Version-conflict test failed for an unrelated reason.'
chroot "$testroot" /usr/bin/rpm -e libcurl
chroot "$testroot" /bundle/install.sh --plan 2>&1 | tee "$output/plan.log"
chroot "$testroot" /bundle/install.sh --apply 2>&1 | tee "$output/install.log"
chroot "$testroot" /usr/bin/rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$output/after-rpms.tsv"
mapfile -t fixture_keys < <(chroot "$testroot" /usr/bin/rpm -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\n')
(( ${#fixture_keys[@]} )) || die 'Disposable RPM key fixture is empty.'
chroot "$testroot" /usr/bin/rpm -e "${fixture_keys[@]}"
expect_failure missing-native-signing-keys chroot "$testroot" /bundle/install.sh --plan
chroot "$testroot" /bundle/scripts/alt-import-os-rpm-keys.sh 2>&1 | tee "$output/bundled-trust-helper.log"
chroot "$testroot" /bundle/install.sh --apply 2>&1 | tee "$output/idempotent-install.log"
chroot "$testroot" /usr/bin/rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > "$output/idempotent-after-rpms.tsv"
cmp "$output/after-rpms.tsv" "$output/idempotent-after-rpms.tsv"
chroot "$testroot" /usr/sbin/useradd -m -u 61001 -s /bin/bash noirtest
chroot "$testroot" /sbin/runuser -u noirtest -- /usr/bin/id > "$output/nonroot-context.txt"
[[ $(chroot "$testroot" /sbin/runuser -u noirtest -- /usr/bin/id -u) == 61001 ]] || die 'Noir acceptance user has an unexpected UID.'
expect_failure nonroot-install-prefix-write chroot "$testroot" /sbin/runuser -u noirtest -- \
  /bin/touch /opt/owasp-noir/1.4.0-alt104-x86_64/nonroot-write-test
mkdir -p "$testroot/test-evidence/smoke"
chroot "$testroot" /bin/chown noirtest:noirtest /test-evidence/smoke
chroot "$testroot" /sbin/runuser -u noirtest -- /usr/bin/python3 /bundle/tests/smoke.py \
  --app /opt/owasp-noir/1.4.0-alt104-x86_64 --out /test-evidence/smoke --require-no-net 2>&1 | tee "$output/smoke-driver.log"
cp -a "$testroot/test-evidence/smoke" "$output/smoke"
python3 - "$output" "$testroot" <<'PY'
import json, sys
from pathlib import Path
out=Path(sys.argv[1])
receipt={'schema':1,'target':'alt104','architecture':'x86_64','result':'PASS',
 'scope':'native disposable package-generated minimal chroot; not a clean VM',
 'clean_vm_qualification':False,'full_archive_sha256':(out/'full-archive.sha256').read_text().strip(),
 'test_root':sys.argv[2],'offline_install':True,'nonroot_smoke':True,'nonroot_uid':61001,
 'baseline_absent':['git-core','python3','libgc','noir','crystal'],
 'idempotent_install':True,'negative_tests':(out/'negative-tests-passed.txt').read_text().splitlines()}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
PY
log "PASS: ALT offline minimal-root install and smoke; evidence $output"
