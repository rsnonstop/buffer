#!/usr/bin/env python3
"""Check delivered archives and recorded native evidence without extracting RPMs.

This is an independent byte/content audit, not native execution or a fresh RPM
signature verification. Native test receipts remain separate from the archives.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import tarfile
import tempfile

COMMIT = '8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256_file(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def sealed_inventory(path):
    """Hash every regular tar member, rejecting unsafe/duplicate/special files."""
    files, kept, binary_header = {}, {}, b''
    root = None
    with tarfile.open(path, 'r|gz') as archive:
        names = set()
        for member in archive:
            parts = PurePosixPath(member.name).parts
            require(parts and not member.name.startswith('/') and '..' not in parts,
                    'Unsafe archive member: ' + member.name)
            require(member.name not in names, 'Duplicate archive member: ' + member.name)
            names.add(member.name)
            if root is None:
                root = parts[0]
            require(parts[0] == root, 'Archive contains multiple roots')
            require(member.isdir() or member.isfile(), 'Non-regular archive member: ' + member.name)
            if member.isdir():
                continue
            relative = '/'.join(parts[1:])
            require(re.fullmatch(r'[A-Za-z0-9_./+@=-]+', relative), 'Unsafe payload name: ' + relative)
            keep = (relative in ('SHA256SUMS', 'manifest.json', 'target.txt', 'bundle-kind.txt', 'app/libexec/noir',
                                 'sources/noir-source-and-shards.tar.gz') or
                    (relative.startswith('metadata/') and not relative.endswith('.log')) or
                    relative in ('metadata/rpm/rpm-signatures.log',
                                 'metadata/rpm/empty-rpmdb-closure-test.log'))
            if keep:
                require(member.size <= 128*1024*1024, 'Oversized audit metadata: ' + relative)
            chunks = []
            h = hashlib.sha256()
            with archive.extractfile(member) as stream:
                first = True
                for block in iter(lambda: stream.read(1024*1024), b''):
                    h.update(block)
                    if keep:
                        chunks.append(block)
                    if relative == 'app/libexec/noir' and first:
                        binary_header = block[:64]
                    first = False
            files[relative] = h.hexdigest()
            if keep:
                kept[relative] = b''.join(chunks)
    require('SHA256SUMS' in kept, 'Missing SHA256SUMS')
    expected = {}
    for line in kept['SHA256SUMS'].decode().splitlines():
        match = re.fullmatch(r'([a-f0-9]{64})  \./([A-Za-z0-9_./+@=-]+)', line)
        require(match is not None, 'Malformed checksum line')
        checksum, name = match.groups()
        require('..' not in PurePosixPath(name).parts and name not in expected,
                'Unsafe or duplicate checksum name: ' + name)
        expected[name] = checksum
    actual = {name: value for name, value in files.items() if name != 'SHA256SUMS'}
    require(expected == actual, 'Archive payload differs from its strict SHA256SUMS inventory')
    return root, files, kept, binary_header


def source_inventory(blob):
    entries = {}
    with tarfile.open(fileobj=io.BytesIO(blob), mode='r:gz') as source:
        for member in source:
            require(not member.name.startswith('/') and '..' not in PurePosixPath(member.name).parts,
                    'Unsafe source snapshot member')
            require(member.name not in ('source/bin/noir', 'source/bin/noir_spec') and
                    not member.name.endswith(('.o', '.a')), 'Build output inside source snapshot')
            if member.isfile():
                entries[member.name] = hashlib.sha256(source.extractfile(member).read()).hexdigest()
            elif member.issym():
                entries[member.name] = 'symlink:' + member.linkname
    return entries


def audit_archive(path):
    archive_hash = sha256_file(path)
    sidecar = path.with_name(path.name + '.sha256')
    require(sidecar.is_file(), 'Missing external checksum sidecar: ' + str(path))
    require(sidecar.read_text().strip() == archive_hash + '  ' + path.name,
            'External archive checksum mismatch: ' + str(path))
    root, files, kept, header = sealed_inventory(path)
    manifest = json.loads(kept['manifest.json'])
    target, kind = manifest['target'], manifest['kind']
    require(target in ('rocky9', 'alt104') and kind in ('binary', 'full'), 'Unsupported artifact identity')
    require(root == 'noir-1.4.0-{}-x86_64-{}'.format(target, kind) and path.name == root + '.tar.gz',
            'Archive filename/root identity mismatch')
    require(manifest['noir_version'] == '1.4.0' and manifest['noir_commit'] == COMMIT and
            manifest['architecture'] == 'x86_64', 'Version/source/architecture pin mismatch')
    require(kept['target.txt'].decode().strip() == target and kept['bundle-kind.txt'].decode().strip() == kind,
            'Installer artifact identity mismatch')
    require(len(header) == 64 and header[:6] == b'\x7fELF\x02\x01' and
            struct.unpack_from('<H', header, 18)[0] == 62, 'Noir is not an x86_64 ELF executable')
    require(files['app/libexec/noir'] == manifest['binary_sha256'] ==
            kept['metadata/noir.sha256'].decode().strip(), 'ELF digest provenance mismatch')
    require(kept['metadata/noir.commit'].decode().strip() == COMMIT, 'Native source commit record mismatch')
    flags = kept['metadata/crystal-build-flags.txt'].decode().splitlines()
    require(flags == ['-Dwithout_mt'] and manifest.get('crystal_build_flags') == flags,
            'Native GC-compatible compiler flags differ from artifact provenance')
    suite_flags = kept['metadata/upstream-suite-link-flags.txt'].decode().splitlines()
    require(suite_flags == ['--link-flags=-Wl,--no-export-dynamic'] and
            manifest.get('upstream_suite_link_flags') == suite_flags,
            'Native upstream-suite linker flags differ from artifact provenance')
    require(manifest['upstream_tests'] == 'passed' and
            kept['metadata/upstream-tests.status'].decode().strip() == 'passed', 'Upstream suite did not pass')
    smoke = json.loads(kept['metadata/smoke/smoke-results.json'])
    require(smoke == manifest['builder_smoke'] and smoke['status'] == 'passed' and
            smoke['network_isolated'] is True and smoke['network_interfaces'] == ['lo'],
            'Native builder smoke did not pass in an isolated network namespace')
    os_release = kept['metadata/build-os-release.txt'].decode()
    if target == 'rocky9':
        require(re.search(r'^ID="?rocky"?$', os_release, re.M) and
                re.search(r'^VERSION_ID="?9(?:\.[0-9]+)*"?$', os_release, re.M), 'Rocky builder OS identity mismatch')
    else:
        require(re.search(r'^ID="?altlinux"?$', os_release, re.M) and
                re.search(r'^VERSION_ID="?10\.4"?$', os_release, re.M), 'ALT builder OS identity mismatch')
    dynamic = kept['metadata/elf-dynamic.txt'].decode()
    require('(NEEDED)' in dynamic and not re.search(r'RPATH|RUNPATH', dynamic), 'Native dynamic-link record failed')
    with tempfile.TemporaryDirectory(prefix='noir-elf-audit-') as temporary:
        executable = Path(temporary)/'noir.elf'
        executable.write_bytes(kept['app/libexec/noir'])
        inspected = subprocess.run(['readelf', '--dynamic', executable], capture_output=True,
                                   text=True, env=dict(os.environ, LC_ALL='C'))
        require(inspected.returncode == 0, 'Actual delivered ELF cannot be inspected: ' + inspected.stderr)
        needed = lambda output: sorted(re.findall(r'\(NEEDED\).*Shared library: \[([^]]+)\]', output))
        require(needed(inspected.stdout) and needed(inspected.stdout) == needed(dynamic),
                'Actual ELF dependencies differ from native link metadata')
        require(not re.search(r'\((?:RPATH|RUNPATH)\)', inspected.stdout), 'Actual ELF carries RPATH/RUNPATH')
    require('not found' not in kept['metadata/ldd.txt'].decode(), 'Native link has unresolved libraries')
    inputs = json.loads(kept['metadata/input-files.json'])
    snapshot = source_inventory(kept['sources/noir-source-and-shards.tar.gz'])
    source_inputs = {name: value for name, value in inputs.items() if name.startswith('source/')}
    require(source_inputs and all(snapshot.get(name) == value for name, value in source_inputs.items()),
            'Source/shard snapshot differs from first-acquired input bytes')
    rpms = {name for name in files if name.startswith('rpms/') and name.endswith('.rpm')}
    if kind == 'full':
        rows = kept['metadata/rpm/runtime-rpms.tsv'].decode().splitlines()
        expected_rpms = set()
        for row in rows:
            fields = row.split('\t')
            require(len(fields) == 5 and fields[4] in ('x86_64', 'noarch'), 'Invalid runtime RPM identity')
            name, epoch, version, release, arch = fields
            expected_rpms.add('rpms/{}-{}-{}.{}.rpm'.format(name, version, release, arch))
        require(len(expected_rpms) == len(rows) == manifest['runtime_rpm_count'] and rpms == expected_rpms,
                'Full RPM payload differs from exact recorded native closure')
        if target == 'alt104':
            native_rows = kept['metadata/rpm/runtime-rpms-alt-native.tsv'].decode().splitlines()
            require(len(native_rows) == len(rows) and
                    { '\t'.join(row.split('\t')[:5]) for row in native_rows } == set(rows) and
                    all(len(row.split('\t')) == 7 and row.split('\t')[5] != '' and
                        row.split('\t')[6].isdigit() for row in native_rows),
                    'ALT DISTTAG/BUILDTIME identity evidence is incomplete')
        signature_log = kept['metadata/rpm/rpm-signatures.log'].decode()
        require(not re.search(r'\b(?:NOKEY|NOT OK|BAD|NOTTRUSTED)\b', signature_log, re.I) and
                len(re.findall(r'(?:signature|\bgpg\b|\bpgp\b).*\bOK\b', signature_log, re.I)) >= len(rpms),
                'Recorded trusted RPM signature evidence is incomplete')
        require(kept['metadata/rpm/empty-rpmdb-closure-test.log'].decode().rstrip().endswith('PASS'),
                'Recorded native empty-database RPM transaction did not pass')
    else:
        require(not rpms, 'Binary bundle unexpectedly carries RPM payload')
    return {'archive': str(path), 'sha256': archive_hash, 'bytes': path.stat().st_size,
            'target': target, 'kind': kind, 'binary_sha256': files['app/libexec/noir'],
            'payload_files': len(files), 'source_input_files': len(source_inputs),
            'runtime_rpm_count': len(rpms), 'builder_os_release': os_release,
            'status': 'passed'}


def audit_set(paths):
    results = [audit_archive(path) for path in paths]
    identities = {(row['target'], row['kind']) for row in results}
    require(len(identities) == len(results), 'Duplicate target/kind artifacts')
    for target in ('rocky9', 'alt104'):
        hashes = {row['binary_sha256'] for row in results if row['target'] == target}
        require(len(hashes) <= 1, 'Binary/full ELF differs for ' + target)
    by_target = {row['target']: row['binary_sha256'] for row in results}
    if len(by_target) == 2:
        require(by_target['rocky9'] != by_target['alt104'], 'Two distributions carry the same ELF bytes')
    return {'scope': 'archive bytes and recorded native evidence; no fresh target execution/signature verification',
            'artifacts': results, 'status': 'passed'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archives', nargs='+', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    report = json.dumps(audit_set(args.archives), indent=2) + '\n'
    if args.output:
        args.output.write_text(report)
    print(report, end='')
