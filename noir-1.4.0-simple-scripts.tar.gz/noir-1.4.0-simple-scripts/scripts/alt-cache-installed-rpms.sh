#!/usr/bin/env bash
# Preserve exact installed native RPM inputs from a protected OS cache.
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
. "$HERE/lib/common.sh"
check_target alt104
(( EUID == 0 )) || die 'Reading the protected OS cache requires administrator access.'
destination=${1:?Usage: alt-cache-installed-rpms.sh /absolute/readable/cache}
safe_work_path "$destination"
[[ ! -L "$destination" ]] || die 'Refusing a symlink cache destination.'
mkdir -p "$destination"
chmod 0755 "$destination"
qf='%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\t%{DISTTAG}\t%{BUILDTIME}\n'
shopt -s nullglob
copied=0
for path in /var/cache/apt/archives/*.rpm; do
    [[ -f "$path" && ! -L "$path" ]] || continue
    identity=$(rpm -qp --qf "$qf" "$path" 2>/dev/null) || continue
    name=${identity%%$'\t'*}
    installed=$(rpm -q --qf "$qf" "$name" 2>/dev/null) || continue
    grep -Fxq -- "$identity" <<<"$installed" || continue
    signature=$(rpm -Kv "$path" 2>&1) || continue
    if grep -Eiq '\b(NOKEY|NOT OK|BAD|NOTTRUSTED)\b' <<<"$signature" ||
       ! grep -Eiq '(signature|\bgpg\b|\bpgp\b).*\bOK\b' <<<"$signature"; then
        continue
    fi
    canonical=$(rpm -qp --qf '%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}.rpm' "$path")
    [[ "$canonical" =~ ^[A-Za-z0-9_.+@=-]+\.rpm$ ]] || die 'Unsupported RPM cache filename.'
    [[ ! -L "$destination/$canonical" ]] || die 'Symlink in RPM cache destination.'
    install -m 0644 -- "$path" "$destination/$canonical"
    copied=$((copied + 1))
done
log "Preserved $copied exact installed signed RPMs in $destination"
