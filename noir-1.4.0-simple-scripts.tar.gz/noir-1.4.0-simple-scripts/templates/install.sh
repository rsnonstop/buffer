#!/usr/bin/env bash
# Offline-only installer. Never calls a network client or package repository.
set -Eeuo pipefail
export LC_ALL=C
PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PATH
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
action=plan; allow_changes=0; prefix=''; link=/usr/local/bin/noir
usage() {
    cat <<'HELP'
Usage: sudo ./install.sh [--plan|--apply] [--allow-package-changes]
                        [--prefix /absolute/directory] [--link /absolute/link|--no-link]
Default: --plan (does not install files or packages).
Default prefix: /opt/owasp-noir/1.4.0-<target>-x86_64
Default link: /usr/local/bin/noir
A full bundle installs missing native RPMs from ./rpms only.
An installed RPM version different from the bundle is blocked by default.
--allow-package-changes permits a normal RPM upgrade; never a forced downgrade.
An existing application directory is accepted only for the identical bundle.
No network access, GPG key import, dependency bypass, or package erasure is used.
Verify the externally supplied archive checksum through a trusted channel first.
HELP
}
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
while (( $# )); do
    case "$1" in
        --plan) action=plan; shift;;
        --apply) action=apply; shift;;
        --allow-package-changes) allow_changes=1; shift;;
        --prefix|--link)
            (( $# >= 2 )) || fail "$1 needs a path"
            if [[ "$1" == --prefix ]]; then prefix=$2; else link=$2; fi
            shift 2;;
        --no-link) link=''; shift;;
        -h|--help) usage; exit 0;;
        *) fail "Unknown argument: $1";;
    esac
done
for cmd in bash rpm sha256sum find grep sort cmp cut sed awk readlink ldd cp mv mktemp stat \
           uname cat wc dirname mkdir rm chmod chown ln; do
    command -v "$cmd" >/dev/null || fail "The base OS is missing $cmd. This installer needs a normal installed target OS."
done
[[ $(uname -m) == x86_64 ]] || fail 'This bundle requires x86_64.'
"$ROOT/verify.sh"
target=$(cat "$ROOT/target.txt")
kind=$(cat "$ROOT/bundle-kind.txt")
[[ "$kind" == binary || "$kind" == full ]] || fail 'Invalid bundle kind.'
# /etc/os-release is part of the trusted, locally installed base OS, not the bundle.
. /etc/os-release
case "$target" in
    rocky9) [[ ${ID:-} == rocky && ( ${VERSION_ID:-} == 9 || ${VERSION_ID:-} == 9.* ) ]] || fail 'Requires Rocky Linux 9.';;
    alt104) [[ " ${ID:-} ${ID_LIKE:-} " == *alt* && ( ${VERSION_ID:-} == 10.4 || ${VERSION_ID:-} == 10.4.* ) ]] || fail 'Requires an actual ALT Linux 10.4 installation.';;
    *) fail 'Unknown target.';;
esac
prefix=${prefix:-/opt/owasp-noir/1.4.0-$target-x86_64}
check_path() {
    local path=$1 walk=$1
    [[ "$path" =~ ^/[A-Za-z0-9_./+-]+$ && "$path" != / && "$path" != */ && "$path" != *//* ]] || fail "Unsafe path: $path"
    [[ "/$path/" != *'/../'* && "/$path/" != *'/./'* ]] || fail 'Dot path components are not permitted.'
    while [[ "$walk" != / ]]; do
        [[ ! -L "$walk" ]] || fail "A path component is a symlink: $walk"
        walk=$(dirname -- "$walk")
    done
}
check_path "$prefix"
if [[ -n "$link" ]]; then
    check_path "$(dirname -- "$link")/noir-link-path-check"
    [[ "$link" =~ ^/[A-Za-z0-9_./+-]+$ && "$link" != */ && "$link" != *//* && "/$link/" != *'/../'* && "/$link/" != *'/./'* ]] || fail 'Unsafe link path.'
    if [[ -L "$link" ]]; then
        [[ $(readlink -- "$link") == "$prefix/bin/noir" ]] || fail "Refusing to replace an unrelated symlink: $link"
    elif [[ -e "$link" ]]; then
        fail "Refusing to replace an existing non-symlink: $link"
    fi
fi
archive_id=$(sha256sum "$ROOT/SHA256SUMS" | awk '{print $1}')
existing=0
if [[ -e "$prefix" ]]; then
    [[ -d "$prefix" && -f "$prefix/.bundle-manifest.sha256" ]] || fail "Application prefix already exists: $prefix"
    [[ $(cat "$prefix/.bundle-manifest.sha256") == "$archive_id" ]] || fail 'Prefix contains a different bundle; choose a new prefix or remove the old application explicitly.'
    # Verify all previously installed app bytes, not just the marker.
    (cd -- "$prefix"; sed -n 's@  ./app/@  ./@p' "$ROOT/SHA256SUMS" | sha256sum --check --strict >/dev/null) || fail 'Installed application has been modified.'
    existing=1
fi
printf 'Target: %s | bundle: %s | action: %s\nPrefix: %s\nLink: %s\n' "$target" "$kind" "$action" "$prefix" "${link:-(none)}"
pending=(); blocked=0
qf='%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n'
if [[ "$kind" == full ]]; then
    shopt -s nullglob
    rpms=("$ROOT"/rpms/*.rpm)
    (( ${#rpms[@]} > 0 )) || fail 'Full bundle contains no RPMs.'
    for file in "${rpms[@]}"; do
        # Reject unsigned packages too, even when RPM reports valid file digests.
        signature=$(rpm -Kv "$file" 2>&1) || fail "RPM verification failed: $file ($signature)"
        if grep -Eiq '\b(NOKEY|NOT OK|BAD|NOTTRUSTED)\b' <<<"$signature" || ! grep -Eiq '(signature|\bgpg\b|\bpgp\b).*\bOK\b' <<<"$signature"; then
            fail "RPM signature is absent or not trusted: $file. Provision the distro's official signing key through your trusted OS process."
        fi
        identity=$(rpm -qp --qf "$qf" "$file" | sed 's/(none)/0/g; s/(null)/0/g')
        [[ $(wc -l <<<"$identity") == 1 ]] || fail "Invalid RPM identity: $file"
        IFS=$'\t' read -r name epoch version release arch <<<"$identity"
        [[ "$arch" == x86_64 || "$arch" == noarch ]] || fail "Wrong RPM architecture: $arch"
        installed=$(rpm -q "$name" --qf "$qf" 2>/dev/null | sed 's/(none)/0/g; s/(null)/0/g' || true)
        if grep -Fxq -- "$identity" <<<"$installed"; then
            printf 'KEEP     %s-%s-%s.%s (exact version present)\n' "$name" "$version" "$release" "$arch"
        else
            if rpm -q "$name" >/dev/null 2>&1; then
                if (( allow_changes )); then
                    printf 'CHANGE   %s -> %s-%s.%s (subject to normal RPM checks)\n' "$name" "$version" "$release" "$arch"
                else
                    printf 'BLOCKED  %s: an installed version differs from the bundle\n' "$name" >&2
                    blocked=1
                fi
            else
                printf 'INSTALL  %s-%s-%s.%s\n' "$name" "$version" "$release" "$arch"
            fi
            pending+=("$file")
        fi
    done
    (( blocked == 0 )) || fail 'Review the base-OS differences. Prefer a matching target baseline or rebuild. Use --allow-package-changes only after review and a VM snapshot.'
    if (( ${#pending[@]} )); then
        printf '\nTesting the complete local RPM transaction...\n'
        # No --nodeps, --force, --oldpackage, --replacefiles or package erasure.
        rpm -U --test "${pending[@]}" || fail 'RPM transaction conflicts or dependencies are unresolved. No packages were installed.'
    fi
else
    printf 'Binary bundle: no operating-system packages are included or installed.\n'
fi
if [[ "$action" == plan ]]; then
    printf '\nPLAN ONLY: no packages or application files installed. Re-run with --apply to install.\n'
    exit 0
fi
(( EUID == 0 )) || fail 'Use sudo for --apply. Compilation and later analysis must run as an ordinary user.'
# Only root-controlled system prefixes are supported by the privileged installer.
trusted_ancestors() {
    local walk=$1 owner mode
    while [[ "$walk" != / ]]; do
        if [[ -e "$walk" ]]; then
            owner=$(stat -c %u -- "$walk"); mode=$(stat -c %a -- "$walk")
            [[ "$owner" == 0 ]] || fail "Install ancestor is not root-owned: $walk"
            (( (8#$mode & 8#022) == 0 )) || fail "Install ancestor is group/world-writable: $walk"
        fi
        walk=$(dirname -- "$walk")
    done
}
trusted_ancestors "$prefix"
[[ -z "$link" ]] || trusted_ancestors "$(dirname -- "$link")"
parent=$(dirname -- "$prefix")
mkdir -p -- "$parent"
check_path "$prefix"
stage=$(mktemp -d "$parent/.noir-install.XXXXXXXX")
cleanup() { [[ -z ${stage:-} ]] || rm -rf -- "$stage"; }
trap cleanup EXIT
cp -a -- "$ROOT/app/." "$stage/"
(cd -- "$stage"; sed -n 's@  ./app/@  ./@p' "$ROOT/SHA256SUMS" | sha256sum --check --strict >/dev/null) || fail 'Copied application failed checksum verification.'
if [[ "$kind" == full ]] && (( ${#pending[@]} )); then
    # Recheck bytes before committing, against the already authenticated tree.
    "$ROOT/verify.sh" >/dev/null
    rpm -Uvh "${pending[@]}" || fail 'RPM installation failed. Inspect the RPM database and restore the VM snapshot if necessary.'
fi
ldd_output=$(ldd "$stage/libexec/noir" 2>&1) || fail "The dynamic loader rejected this binary: $ldd_output"
if grep -q 'not found' <<<"$ldd_output"; then
    fail 'Application has missing shared libraries. Use the full bundle, or provision the matching native libraries.'
fi
for cmd in git python3; do command -v "$cmd" >/dev/null || fail "Runtime/verification dependency is missing: $cmd"; done
printf '%s\n' "$archive_id" > "$stage/.bundle-manifest.sha256"
cp -- "$ROOT/manifest.json" "$stage/.bundle-manifest.json"
chmod 755 "$stage"
chown -R root:root "$stage"
chmod -R go-w "$stage"
if (( existing == 0 )); then
    mv -T -- "$stage" "$prefix"
    stage=''
fi
if [[ -n "$link" && ! -L "$link" ]]; then
    mkdir -p -- "$(dirname -- "$link")"
    ln -s -- "$prefix/bin/noir" "$link"
fi
printf '\nInstalled: %s\nRun as an ordinary user: %q version\n' "$prefix" "${link:-$prefix/bin/noir}"
printf 'This installation is not a clean-VM qualification. Run tests/smoke.py with network isolation.\n'
