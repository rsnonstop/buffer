#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
cd -- "$ROOT"
[[ -s SHA256SUMS ]] || { echo 'Missing SHA256SUMS' >&2; exit 1; }
# Integrity is not authenticity: authenticate the external archive hash separately.
if find . -type l -print -quit | grep -q .; then
    echo 'Bundle contains a symlink; refusing.' >&2; exit 1
fi
if find . ! -type d ! -type f -print -quit | grep -q .; then
    echo 'Bundle contains a special file; refusing.' >&2; exit 1
fi
while IFS= read -r line; do
    [[ "$line" =~ ^[a-f0-9]{64}\ \ \./[A-Za-z0-9_./+@=-]+$ ]] || {
        echo 'Malformed manifest line.' >&2; exit 1;
    }
    name=${line:66}
    [[ "/$name/" != *'/../'* ]] || { echo 'Traversal in manifest.' >&2; exit 1; }
done < SHA256SUMS
expected=$(cut -c67- SHA256SUMS | sort)
actual=$(find . -type f ! -path ./SHA256SUMS -print | sort)
[[ "$actual" == "$expected" ]] || { echo 'Missing or unexpected bundle files.' >&2; exit 1; }
sha256sum --check --strict SHA256SUMS
