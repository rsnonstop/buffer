#!/usr/bin/env bash
# Build OWASP Noir 1.4.0 FROM SOURCE on Rocky Linux 9.7, x86_64.
# This is a standalone sequence of commands: it sources no configuration file
# and calls no other supplied script. The only downloads are upstream inputs.
#
# Run the dependency setup first as an administrator:
#   sudo ./build-rocky97.sh --bootstrap
# Then run the build as your ordinary account:
#   ./build-rocky97.sh
#
# The fixed working directory is /var/tmp/noir-1.4.0-simple-rocky97.
# A previous directory is deliberately NOT erased or reused. For another build,
# rename the old directory yourself before running this script again.
# The runnable result is source/bin/noir inside that working directory.
# Binary/full bundle creation is a separate, optional step.
set -Eeuo pipefail

# Help works on any system and does not create files or change packages.
if [[ ${1:-} == --help || ${1:-} == -h ]]; then
    printf '%s\n' 'Usage: sudo ./build-rocky97.sh --bootstrap' \
      '       ./build-rocky97.sh' \
      'Requires Rocky Linux 9.7 x86_64; compilation must run as an ordinary user.' \
      'Work: /var/tmp/noir-1.4.0-simple-rocky97' \
      'Result: /var/tmp/noir-1.4.0-simple-rocky97/source/bin/noir'
    exit 0
fi
if [[ $# -gt 1 || ( $# == 1 && $1 != --bootstrap ) ]]; then
    printf 'Only --bootstrap or --help is accepted.\n' >&2
    exit 2
fi

# Do not accidentally build on Rocky 9.8, ALT, another distribution, or ARM.
# Reading individual fields avoids sourcing /etc/os-release as shell code.
if [[ $(uname -m) != x86_64 ]] || \
   ! grep -Eq '^ID="?rocky"?$' /etc/os-release || \
   ! grep -Eq '^VERSION_ID="?9\.7"?$' /etc/os-release; then
    printf 'This script requires Rocky Linux 9.7 x86_64.\n' >&2
    exit 2
fi

# Administrator-only dependency setup. CRB supplies native development RPMs.
# Keep the existing distribution repositories; do not run a whole-system update
# or download a prebuilt Noir executable. The build uses these native libraries.
if [[ ${1:-} == --bootstrap ]]; then
    if (( EUID != 0 )); then
        printf 'Run --bootstrap as an administrator, for example with sudo.\n' >&2
        exit 2
    fi
    dnf -y install dnf-plugins-core
    dnf config-manager --set-enabled crb
    dnf -y install gcc gcc-c++ make git curl tar gzip xz findutils diffutils \
      coreutils binutils pkgconf-pkg-config openssl-devel gc-devel pcre2-devel \
      libevent-devel libyaml-devel libzstd-devel zlib-devel libxml2-devel \
      python3 rpm ca-certificates util-linux
    printf 'Dependencies installed. Run this script again as an ordinary user.\n'
    exit 0
fi

# Keep untrusted source compilation out of the administrator account.
if (( EUID == 0 )); then
    printf 'Run the build as an ordinary user; root is only for --bootstrap.\n' >&2
    exit 2
fi
if [[ -e /var/tmp/noir-1.4.0-simple-rocky97 || -L /var/tmp/noir-1.4.0-simple-rocky97 ]]; then
    printf 'Work directory already exists; rename it before starting a fresh build.\n' >&2
    exit 2
fi

# Make an entirely fresh workspace and enter it BEFORE starting Crystal. A root
# launcher can otherwise leave the builder with an inaccessible inherited cwd.
mkdir -m 0700 /var/tmp/noir-1.4.0-simple-rocky97
cd /var/tmp/noir-1.4.0-simple-rocky97
mkdir downloads toolchain cache tmp logs metadata suite-home
mkdir suite-home/.config
chmod 0700 tmp suite-home
printf 'rocky9\n' > target
exec > >(tee -a logs/driver.log) 2>&1
trap 'printf "Build failed at line %s; logs and inputs remain in /var/tmp/noir-1.4.0-simple-rocky97.\n" "$LINENO" >&2' ERR

# All build caches and temporary files belong to this fresh ordinary-user build.
# Disable the compiler archive's bundled library paths so native RPM libraries
# are used. Clear inherited settings that could inject another compiler/library.
export PATH='/var/tmp/noir-1.4.0-simple-rocky97/toolchain/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
export TMPDIR='/var/tmp/noir-1.4.0-simple-rocky97/tmp'
export TMP='/var/tmp/noir-1.4.0-simple-rocky97/tmp'
export TEMP='/var/tmp/noir-1.4.0-simple-rocky97/tmp'
export CRYSTAL_CACHE_DIR='/var/tmp/noir-1.4.0-simple-rocky97/cache/crystal'
export SHARDS_CACHE_PATH='/var/tmp/noir-1.4.0-simple-rocky97/cache/shards'
export CRYSTAL_WORKERS=2
export CRYSTAL_LIBRARY_PATH=''
export CRYSTAL_LIBRARY_RPATH=''
export CRYSTAL_OPTS=''
unset SHARDS_OVERRIDE CRYSTAL_PATH LD_LIBRARY_PATH LIBRARY_PATH CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH
export CC=/usr/bin/gcc CXX=/usr/bin/g++
export CFLAGS='-O2 -fPIC -march=x86-64 -mtune=generic'
export CXXFLAGS='-O2 -fPIC -march=x86-64 -mtune=generic'
export GIT_TERMINAL_PROMPT=0

# Fetch the fixed official bootstrap compiler and CHECK its archive hash before
# extraction. This compiler builds Noir; the script never downloads Noir binaries.
curl --fail --location --retry 3 --proto '=https' --tlsv1.2 \
  https://github.com/crystal-lang/crystal/releases/download/1.21.0/crystal-1.21.0-1-linux-x86_64.tar.gz \
  --output downloads/crystal-1.21.0-1-linux-x86_64.tar.gz
printf '%s\n' '744561ee3cee1b06d106cf9ae99b8064b4e017518ac414d6dd23cfafe36560c9  downloads/crystal-1.21.0-1-linux-x86_64.tar.gz' | sha256sum -c -
tar -xzf downloads/crystal-1.21.0-1-linux-x86_64.tar.gz -C toolchain --strip-components=1
crystal --version | tee metadata/crystal-version.txt
grep -q '^Crystal 1\.21\.0 ' metadata/crystal-version.txt
shards --version > metadata/shards-version.txt
gcc --version > metadata/gcc-version.txt

# Fetch the release source and reject a tag that no longer points to the exact
# reviewed commit. Shards installs the source dependencies from its lock file.
git clone --depth 1 --branch v1.4.0 https://github.com/owasp-noir/noir.git source
git -C source rev-parse HEAD | grep -qx '8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4'
git -C source submodule update --init --recursive
lock_before=$(sha256sum source/shard.lock | awk '{print $1}')
printf '%s\n' "$lock_before" > shard-lock.sha256
cd source
shards install --production 2>&1 | tee ../logs/shards-install.log
shards check --production
cd ..
sha256sum source/shard.lock | awk '{print $1}' | grep -qx "$lock_before"
git -C source diff --quiet
git -C source diff --cached --quiet
cp source/shard.lock metadata/shard.lock

# Include a fixed passive-rule source snapshot, rather than whatever upstream
# HEAD happens to contain on the day of a future build. No rule cache is reused.
git init rules-source
git -C rules-source remote add origin https://github.com/owasp-noir/noir-passive-rules.git
git -C rules-source fetch --depth 1 origin 427754d45fd70f4ab360bd5b3ba39b666cc233a5
git -C rules-source checkout --detach FETCH_HEAD
git -C rules-source rev-parse HEAD | grep -qx '427754d45fd70f4ab360bd5b3ba39b666cc233a5'
printf '427754d45fd70f4ab360bd5b3ba39b666cc233a5\n' > rules.commit
cp rules.commit metadata/rules.commit
printf '8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4\n' > metadata/noir.commit
cat > metadata/versions.env.txt <<'VERSIONS'
NOIR_VERSION=1.4.0
NOIR_TAG=v1.4.0
NOIR_COMMIT=8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4
NOIR_REPO=https://github.com/owasp-noir/noir.git
CRYSTAL_VERSION=1.21.0
CRYSTAL_ARCHIVE=crystal-1.21.0-1-linux-x86_64.tar.gz
CRYSTAL_SHA256=744561ee3cee1b06d106cf9ae99b8064b4e017518ac414d6dd23cfafe36560c9
RULES_REPO=https://github.com/owasp-noir/noir-passive-rules.git
RULES_COMMIT=427754d45fd70f4ab360bd5b3ba39b666cc233a5
VERSIONS

# Record exact source/dependency/compiler bytes BEFORE compiling. This inline
# Python uses only the OS standard library; it imports no build-kit module.
# Generated objects/binaries and Git/cache bookkeeping are excluded. Symlink
# targets are recorded without following directory links.
/usr/bin/python3 - <<'INPUTS'
import hashlib, json, os
from pathlib import Path
entries = {}
for label, root in [('source', Path('source')), ('toolchain', Path('toolchain'))]:
    for base, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(x for x in dirs if x not in ('.git', '__pycache__', '.crystal'))
        for name in list(dirs):
            if (Path(base) / name).is_symlink():
                files.append(name)
                dirs.remove(name)
        for name in sorted(files):
            path = Path(base) / name
            rel = path.relative_to(root).as_posix()
            if label == 'source' and (name.endswith(('.o', '.a')) or rel in ('bin/noir', 'bin/noir_spec')):
                continue
            if name == '.git':
                continue
            if path.is_symlink():
                entries[label + '/' + rel] = 'symlink:' + os.readlink(path)
            elif path.is_file():
                entries[label + '/' + rel] = hashlib.sha256(path.read_bytes()).hexdigest()
            else:
                raise SystemExit('Non-regular input: ' + str(path))
Path('metadata/input-files.json').write_text(json.dumps(entries, indent=2, sort_keys=True) + '\n')
print('Input inventory:', len(entries), 'entries')
INPUTS

# Capture the actual OS/package baseline after administrator dependency setup.
# The optional full-bundle helper requires this exact inventory to remain intact.
cp /etc/os-release metadata/build-os-release.txt
rpm -qa --qf '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n' | sort > metadata/builder-rpms.tsv
SOURCE_DATE_EPOCH=$(git -C source show -s --format=%ct HEAD)
export SOURCE_DATE_EPOCH
printf '%s\n' '-Dwithout_mt' > metadata/crystal-build-flags.txt
printf '%s\n' '-Dwithout_mt' > metadata/upstream-suite-flags.txt
printf '%s\n' '--link-flags=-Wl,--no-export-dynamic' > metadata/upstream-suite-link-flags.txt

# Compile with generic x86-64 instructions and the distro's native GC library.
# Rocky gc8.0 lacks the stack APIs required by Crystal's default scheduler.
# Noir supports -Dwithout_mt: worker tasks use cooperative fibers, with reduced
# CPU parallelism. No private libgc/glibc or Noir source patch is substituted.
mkdir -p source/bin
cd source
crystal build src/noir.cr --release --no-debug --mcpu x86-64 -Dwithout_mt \
  --verbose -o bin/noir 2>&1 | tee ../logs/compile.log
cd ..

# Inspect the resulting native ELF, reject private runtime search paths or
# unresolved libraries, and record the exact produced executable hash.
readelf -h source/bin/noir > metadata/elf-header.txt
readelf -d source/bin/noir > metadata/elf-dynamic.txt
readelf --version-info source/bin/noir > metadata/elf-versions.txt
grep -q 'Advanced Micro Devices X86-64' metadata/elf-header.txt
grep -q '(NEEDED)' metadata/elf-dynamic.txt
if grep -Eq 'RPATH|RUNPATH' metadata/elf-dynamic.txt; then
    printf 'Unexpected private runtime search path in compiled ELF.\n' >&2
    exit 1
fi
ldd source/bin/noir > metadata/ldd.txt
if grep -q 'not found' metadata/ldd.txt; then
    printf 'A native runtime library is missing.\n' >&2
    exit 1
fi
sha256sum source/bin/noir | awk '{print $1}' > metadata/noir.sha256
source/bin/noir version | tee metadata/noir-version.txt
grep -qx '1.4.0' metadata/noir-version.txt

# Recompute the inventory before compiling/running upstream specs. Git's tracked
# source check alone would miss edited shard files or an altered bootstrap
# compiler. Generated native objects and executables remain excluded.
/usr/bin/python3 - <<'CHECK_INPUTS'
import hashlib, json, os
from pathlib import Path
entries = {}
for label, root in [('source', Path('source')), ('toolchain', Path('toolchain'))]:
    for base, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(x for x in dirs if x not in ('.git', '__pycache__', '.crystal'))
        for name in list(dirs):
            if (Path(base) / name).is_symlink():
                files.append(name)
                dirs.remove(name)
        for name in sorted(files):
            path = Path(base) / name
            rel = path.relative_to(root).as_posix()
            if label == 'source' and (name.endswith(('.o', '.a')) or rel in ('bin/noir', 'bin/noir_spec')):
                continue
            if name == '.git':
                continue
            if path.is_symlink():
                entries[label + '/' + rel] = 'symlink:' + os.readlink(path)
            elif path.is_file():
                entries[label + '/' + rel] = hashlib.sha256(path.read_bytes()).hexdigest()
            else:
                raise SystemExit('Non-regular input: ' + str(path))
saved = json.loads(Path('metadata/input-files.json').read_text())
changed = sorted(k for k in set(saved) | set(entries) if saved.get(k) != entries.get(k))
if changed:
    raise SystemExit('Input files changed since fetch (first 20):\n' + '\n'.join(changed[:20]))
print('Input verification:', len(entries), 'unchanged entries')
CHECK_INPUTS

# Compile and run the COMPLETE upstream suite. A dedicated HOME with .config
# avoids warnings from a fresh account's configuration setup. The suite-only
# linker option avoids a malformed huge debug symbol-version table on Rocky's
# linker; the production release above does not need that option.
printf '/var/tmp/noir-1.4.0-simple-rocky97/suite-home\n' > metadata/upstream-suite-home.txt
cd source
crystal build spec/suite.cr --mcpu x86-64 -Dwithout_mt \
  --link-flags=-Wl,--no-export-dynamic -o bin/noir_spec 2>&1 | tee ../logs/upstream-tests.log
HOME=/var/tmp/noir-1.4.0-simple-rocky97/suite-home \
  XDG_CONFIG_HOME=/var/tmp/noir-1.4.0-simple-rocky97/suite-home/.config \
  bin/noir_spec 2>&1 | tee -a ../logs/upstream-tests.log
cd ..
printf 'passed\n' > metadata/upstream-tests.status

# A successful exit means the native ELF/linkage/version checks and the full
# upstream suite passed. Keep all inputs, logs and metadata for bundle creation.
git -C source diff --quiet
git -C source diff --cached --quiet
sha256sum source/shard.lock | awk '{print $1}' | grep -qx "$lock_before"
printf 'Build and upstream tests passed.\nRun: /var/tmp/noir-1.4.0-simple-rocky97/source/bin/noir version\n'
