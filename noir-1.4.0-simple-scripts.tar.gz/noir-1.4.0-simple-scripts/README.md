# Noir 1.4.0: simple commands for native builds

Copy this package onto the target Linux server. Open the corresponding build file
and read its comments; its commands can also be run section by section. The two
build files contain their own commands and use no supplied scripts, libraries or
configuration includes. They use ordinary OS tools, Crystal and Shards.

## Rocky Linux 9.7, x86_64

As an administrator, install the prerequisites:

```bash
sudo bash build-rocky97.sh --bootstrap
```

As an ordinary user, compile and test:

```bash
bash build-rocky97.sh
/var/tmp/noir-1.4.0-simple-rocky97/source/bin/noir version
```

The fixed working directory is `/var/tmp/noir-1.4.0-simple-rocky97`. The script
requires Rocky **9.7** and refuses to reuse an existing working directory.

## ALT Server 10.4, x86_64

As an administrator, install the prerequisites:

```bash
sudo bash build-alt104.sh --bootstrap
```

If you also want full offline bundles, prepare native RPM trust and the readable
cache before compiling:

```bash
sudo bash prepare-offline-alt104.sh
```

As an ordinary user, compile and test:

```bash
bash build-alt104.sh
/var/tmp/noir-1.4.0-simple-alt104/source/bin/noir version
```

The fixed working directory is `/var/tmp/noir-1.4.0-simple-alt104`. The script
requires ALT **10.4** and refuses to reuse an existing working directory.
The optional preparation file preserves trusted installed RPM originals in
`/var/tmp/noir-1.4.0-simple-alt104-native-rpms` for later offline packaging.
It uses the installed OS keyring and keeps `/usr/bin/python3` unchanged. The
standalone build works without this optional file; preparing trust afterward can
change the RPM inventory and require a new build before full packaging.

## Optional binary and full offline bundles

After the corresponding build succeeds, run the matching command as the same
ordinary builder, from this package's directory:

```bash
# On Rocky:
bash make-bundles-rocky97.sh
# On ALT:
bash make-bundles-alt104.sh
```

These optional packaging files use the supplied helper libraries. The two
standalone build files never call them. Each creates a binary bundle and a full
offline-install bundle in its fixed working directory's `bundles/` subdirectory,
with archive checksum sidecars. Keep the builder's RPM inventory unchanged
between compilation and packaging.

Binary packaging runs functional tests without an external network interface.
It needs permitted user network namespaces, or administrator authorization for
`sudo unshare --net -- runuser` to drop back to the builder. ALT may also require
wheel membership to execute sudo. Remove any temporary privilege after packaging.

The generated full bundles contain exact signed native runtime RPMs. Install using
`install.sh` inside a generated full bundle, following
[the runtime instructions](docs/RUNTIME-README.md). Files in `templates/` are
packaging inputs, not complete installers by themselves. Offline runtime
installation requires a compatible matching base OS; these scripts acquire their
build inputs online. Package-version and downgrade refusals remain enabled.

## Fixed inputs and validation

Noir is pinned to v1.4.0 commit
`8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4`. Crystal 1.21.0 is pinned by SHA-256.
Passive rules are pinned to `427754d45fd70f4ab360bd5b3ba39b666cc233a5`.
The commands use native libraries and `-Dwithout_mt` for native GC compatibility;
the upstream suite also uses `--link-flags=-Wl,--no-export-dynamic`.
They preserve input hashes, native linkage records and complete upstream results.

Run `make check` for the supplied helper/syntax checks. Verify an extracted package
before use with `sha256sum --check --strict SHA256SUMS`.
The scripts-only archive contains no compiled Noir, RPM payloads, compiler/source
downloads, caches, historical logs or credentials.
