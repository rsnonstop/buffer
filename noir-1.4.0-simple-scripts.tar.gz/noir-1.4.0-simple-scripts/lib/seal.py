#!/usr/bin/env python3
"""Seal a generated bundle. Reject links, devices and ambiguous manifest paths."""
import argparse
import hashlib
import re
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def seal(root):
    root = Path(root).resolve()
    lines = []
    for path in sorted(root.rglob('*')):
        name = path.relative_to(root).as_posix()
        if name == 'SHA256SUMS':
            continue
        if path.is_symlink() or not (path.is_dir() or path.is_file()):
            raise ValueError('Non-regular bundle member: ' + name)
        if not re.fullmatch(r'[A-Za-z0-9_./+@=-]+', name):
            raise ValueError('Unsafe/ambiguous bundle member name: ' + name)
        if path.is_file():
            lines.append('{}  ./{}\n'.format(digest(path), name))
    (root / 'SHA256SUMS').write_text(''.join(lines))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('directory')
    seal(p.parse_args().directory)
