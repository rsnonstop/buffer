#!/usr/bin/env python3
"""Create independently built binary/full runtime candidate bundles."""
import argparse
import datetime
import gzip
import hashlib
import json
import os
import pwd
import shlex
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

from rpm_bundle import capture
from seal import digest, seal

VERSION = '1.4.0'
COMMIT = '8b8d1683ba7b70387c4abf9f34c8d7f0a74b6ba4'


def command(args, **kwargs):
    return subprocess.run([str(x) for x in args], check=True, **kwargs)


def reset_dir(path, allowed_parent):
    path, allowed_parent = Path(path).resolve(), Path(allowed_parent).resolve()
    if path.parent != allowed_parent:
        raise ValueError('Refusing to remove a directory outside the staging root')
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True)


def archive_tree(root, output):
    root, output = Path(root), Path(output)
    temp = Path(str(output) + '.partial')
    with temp.open('wb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as tar:
                def clean(info):
                    info.uid = info.gid = 0
                    info.uname = info.gname = 'root'
                    info.mtime = 0
                    return info
                tar.add(root, arcname=root.name, filter=clean)
    temp.replace(output)
    output.with_name(output.name + '.sha256').write_text(digest(output) + '  ' + output.name + '\n')


def snapshot_source(source, output):
    with tarfile.open(output, 'w:gz') as tar:
        def keep(info):
            parts = Path(info.name).parts
            if '.git' in parts or '__pycache__' in parts:
                return None
            if info.name in ('source/bin/noir', 'source/bin/noir_spec') or info.name.endswith(('.o', '.a')):
                return None
            info.uid = info.gid = 0
            info.uname = info.gname = 'root'
            info.mtime = 0
            return info
        tar.add(source, arcname='source', filter=keep)


def run_smoke(kit, app, output):
    args = [sys.executable, kit / 'tests/smoke.py', '--app', app, '--out', output]
    isolated = os.environ.get('REQUIRE_NETWORK_ISOLATION', '1') == '1'
    if isolated:
        args += ['--require-no-net']
        test = subprocess.run(['unshare', '--user', '--map-root-user', '--net', 'true'],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if test.returncode == 0:
            args = ['unshare', '--user', '--map-root-user', '--net', '--'] + args
        else:
            if not shutil.which('sudo'):
                raise RuntimeError('Network namespace unavailable; install sudo or qualify on a detached-network VM.')
            user = pwd.getpwuid(os.getuid()).pw_name
            # The namespace is created as root, but the Noir process runs as the
            # original unprivileged user. No app scan is performed as host root.
            args = ['sudo', 'unshare', '--net', '--', 'runuser', '-u', user, '--'] + args
    command(args)
    return json.loads((output / 'smoke-results.json').read_text())


def binary(kit, work, out, target):
    base = 'noir-{}-{}-x86_64-binary'.format(VERSION, target)
    stage_parent = work / 'staging'; stage_parent.mkdir(exist_ok=True)
    root = stage_parent / base
    reset_dir(root, stage_parent)
    app = root / 'app'
    for directory in ['bin', 'libexec', 'share/passive_rules', 'share/licenses']:
        (app / directory).mkdir(parents=True)
    source = work / 'source'
    expected = (work / 'metadata/noir.sha256').read_text().strip()
    if digest(source / 'bin/noir') != expected:
        raise RuntimeError('Built binary does not match compilation record')
    shutil.copy2(source / 'bin/noir', app / 'libexec/noir')
    shutil.copy2(kit / 'templates/noir', app / 'bin/noir')
    rules_commit = (work / 'rules.commit').read_text().strip()
    # git archive excludes .git and all untracked/locally generated files.
    rules_tar = work / 'rules-snapshot.tar'
    with rules_tar.open('wb') as stream:
        command(['git', '-C', work / 'rules-source', 'archive', rules_commit], stdout=stream)
    command(['tar', '-xf', rules_tar, '-C', app / 'share/passive_rules'])
    (app / 'share/passive_rules/.revision').write_text(rules_commit + '\n')
    # Ship the exact sources and shard contents so notices/licenses remain
    # available. This is NOT a complete offline compiler/development environment.
    (root / 'sources').mkdir()
    snapshot_source(source, root / 'sources/noir-source-and-shards.tar.gz')
    for filename in ('LICENSE', 'LICENSE.md', 'LICENSE.txt'):
        if (source / filename).is_file():
            shutil.copy2(source / filename, app / 'share/licenses' / filename)
    if not any((app / 'share/licenses').iterdir()):
        raise RuntimeError('Upstream Noir license was not found')
    (app / 'share/licenses/THIRD-PARTY-NOTICES.txt').write_text(
        'Noir and its vendored tree-sitter sources contain third-party components.\n'
        'The exact source-and-shards archive in the distribution retains upstream\n'
        'licenses. Native library/Git RPMs in a full bundle retain their own\n'
        'license metadata and installed notices. Review redistribution duties.\n')
    shutil.copytree(work / 'metadata', root / 'metadata')
    for filename in ('compile.log', 'shards-install.log', 'upstream-tests.log'):
        if (work / 'logs' / filename).exists():
            shutil.copy2(work / 'logs' / filename, root / 'metadata' / filename)
    for filename in ('verify.sh', 'install.sh'):
        shutil.copy2(kit / 'templates' / filename, root / filename)
    if target == 'alt104':
        # ALT APT and RPM use different trust databases. This explicit helper
        # reads only the installed OS keyring; it imports no bundled keys.
        (root / 'scripts').mkdir()
        (root / 'lib').mkdir()
        shutil.copy2(kit / 'scripts/alt-import-os-rpm-keys.sh',
                     root / 'scripts/alt-import-os-rpm-keys.sh')
        shutil.copy2(kit / 'lib/common.sh', root / 'lib/common.sh')
    shutil.copy2(kit / 'docs/RUNTIME-README.md', root / 'README.md')
    (root / 'tests').mkdir()
    shutil.copy2(kit / 'tests/smoke.py', root / 'tests/smoke.py')
    (root / 'target.txt').write_text(target + '\n')
    (root / 'bundle-kind.txt').write_text('binary\n')
    smoke = run_smoke(kit, app, root / 'metadata/smoke')
    manifest = {
        'schema': 1, 'noir_version': VERSION, 'noir_commit': COMMIT,
        'target': target, 'architecture': 'x86_64', 'kind': 'binary',
        'built_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'binary_sha256': expected, 'rules_commit': rules_commit,
        'linkage': 'native distro dynamic libraries; no private glibc',
        'compiler': 'Crystal 1.21.0; upstream archive hash pinned in profiles/versions.env',
        'crystal_build_flags': (work / 'metadata/crystal-build-flags.txt').read_text().splitlines(),
        'scheduler': 'legacy cooperative fibers; -Dwithout_mt for native libgc compatibility',
        'cpu': 'x86-64 generic; target OS may itself require a higher CPU baseline',
        'upstream_tests': (work / 'metadata/upstream-tests.status').read_text().strip(),
        'upstream_suite_link_flags': (work / 'metadata/upstream-suite-link-flags.txt').read_text().splitlines(),
        'builder_smoke': smoke, 'clean_target_offline_install': 'not-yet-tested',
        'release_state': 'candidate; requires clean-target acceptance',
        'source_snapshot': 'sources/noir-source-and-shards.tar.gz',
        'offline_build_environment_included': False,
    }
    (root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    seal(root)
    command([root / 'verify.sh'], stdout=subprocess.DEVNULL)
    archive_tree(root, out / (base + '.tar.gz'))
    print('Created binary candidate:', out / (base + '.tar.gz'))


def full(kit, work, out, target):
    base = 'noir-{}-{}-x86_64-full'.format(VERSION, target)
    stage_parent = work / 'staging'
    binary_root = stage_parent / base.replace('-full', '-binary')
    if not binary_root.is_dir():
        raise RuntimeError('No binary staging tree; run the binary stage first.')
    command([binary_root / 'verify.sh'], stdout=subprocess.DEVNULL)
    manifest = json.loads((binary_root / 'manifest.json').read_text())
    if manifest['target'] != target or manifest['noir_commit'] != COMMIT:
        raise RuntimeError('Target/source mismatch in binary bundle')
    current = subprocess.check_output(
        ['rpm', '-qa', '--qf', '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n'], text=True)
    saved = (binary_root / 'metadata/builder-rpms.tsv').read_text()
    if sorted(current.splitlines()) != sorted(saved.splitlines()):
        raise RuntimeError('Builder RPM inventory changed after compilation. Rebuild before packaging dependencies.')
    root = stage_parent / base
    reset_dir(root, stage_parent)
    shutil.copytree(binary_root, root, dirs_exist_ok=True)
    (root / 'SHA256SUMS').unlink()
    packages = capture(target, root / 'app/libexec/noir', root / 'rpms',
                       root / 'metadata/rpm', shlex.split(os.environ.get('EXTRA_RUNTIME_PACKAGES', '')))
    # APT may create this scratch directory beside rpms; it is not an artefact.
    shutil.rmtree(root / 'apt-download-cache', ignore_errors=True)
    manifest.update(kind='full', runtime_rpm_count=len(packages),
                    runtime_closure_validation='passed: RPM --test against empty database',
                    runtime_rpm_signatures='verified against the native builder RPM keyring')
    (root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (root / 'bundle-kind.txt').write_text('full\n')
    seal(root)
    command([root / 'verify.sh'], stdout=subprocess.DEVNULL)
    archive_tree(root, out / (base + '.tar.gz'))
    print('Created full offline-install candidate:', out / (base + '.tar.gz'))
    print('Still required: clean target VM installation with network disconnected.')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('kind', choices=['binary', 'full'])
    p.add_argument('--kit', required=True, type=Path)
    p.add_argument('--work', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--target', required=True, choices=['rocky9', 'alt104'])
    args = p.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    globals()[args.kind](args.kit.resolve(), args.work.resolve(), args.out.resolve(), args.target)
