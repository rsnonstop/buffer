#!/usr/bin/env python3
"""Capture native RPM runtime dependencies without omitting installed packages.

The installed RPM database identifies the exact packages used by the build.
RPM's own transaction checker, against an EMPTY database, is the final closure
validator; the dependency walker is not claimed to be a replacement RPM solver.
"""
import argparse
import dataclasses
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import tempfile
from pathlib import Path

QF = '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\n'
ALT_STAMP_QF = '%{DISTTAG}\t%{BUILDTIME}\n'


def run(args, check=True):
    p = subprocess.run([str(x) for x in args], text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       env=dict(os.environ, LC_ALL='C'))
    if check and p.returncode:
        raise RuntimeError('Command failed: {}\n{}\n{}'.format(
            shlex.join([str(x) for x in args]), p.stdout, p.stderr))
    return p


def run_logged(args, log):
    """Retain native command failures as well as successful output."""
    p = run(args, check=False)
    log.write_text(p.stdout + p.stderr)
    if p.returncode:
        raise RuntimeError('Command failed: {}\n{}\n{}'.format(
            shlex.join([str(x) for x in args]), p.stdout, p.stderr))
    return p


@dataclasses.dataclass(frozen=True, order=True)
class Package:
    name: str
    epoch: str
    version: str
    release: str
    arch: str

    @classmethod
    def parse(cls, line):
        fields = line.strip().split('\t')
        if len(fields) != 5:
            raise ValueError('Invalid RPM identity: ' + repr(line))
        if fields[1] in ('(none)', '', '(null)'):
            fields[1] = '0'
        if not fields[1].isdigit():
            raise ValueError('Invalid RPM epoch: ' + repr(line))
        return cls(*fields)

    @property
    def query(self):
        return '{}-{}-{}.{}'.format(self.name, self.version, self.release, self.arch)

    @property
    def dnf_spec(self):
        return '{}-{}:{}-{}.{}'.format(self.name, self.epoch, self.version, self.release, self.arch)

    @property
    def apt_spec(self):
        evr = '{}-{}'.format(self.version, self.release)
        if self.epoch != '0':
            evr = self.epoch + ':' + evr
        return self.name + '=' + evr

    def tsv(self):
        return '\t'.join(dataclasses.astuple(self))


def parse_packages(text):
    return [Package.parse(x) for x in text.splitlines() if x.strip()]


def rich_names(requirement):
    """Over-approximate named atoms in a rich requirement, keeping ELF () intact.

    Include all INSTALLED alternatives. Missing alternatives are left to RPM's
    final transaction check, which understands conditionals and version ranges.
    """
    names = []
    skip_version = False
    for word in requirement.split():
        word = word.lstrip('(')
        while word.endswith(')') and word.count(')') > word.count('('):
            word = word[:-1]
        if not word:
            continue
        if skip_version:
            skip_version = False
            continue
        if word in ('>=', '<=', '=', '>', '<', '=='):
            skip_version = True
        elif word not in ('and', 'or', 'if', 'unless', 'else', 'with', 'without'):
            names.append(word)
    return names


def dynamic_paths(binary):
    output = run(['ldd', binary]).stdout
    if 'not found' in output:
        raise RuntimeError('Missing linked library:\n' + output)
    paths = set()
    for line in output.splitlines():
        m = re.search(r'=>\s+(/\S+)', line)
        if not m:
            m = re.match(r'\s*(/\S+)\s+\(', line)
        if m:
            paths.add(m.group(1))
    if not paths:
        raise RuntimeError('Expected native dynamic library paths from ldd.')
    return sorted(paths)


class InstalledClosure:
    def __init__(self):
        self.cache = {}
        self.edges = []

    def providers(self, capability, mandatory=True):
        if capability not in self.cache:
            p = run(['rpm', '-q', '--whatprovides', capability, '--qf', QF], check=False)
            self.cache[capability] = parse_packages(p.stdout) if p.returncode == 0 else []
        candidates = self.cache[capability]
        compatible = sorted(set(x for x in candidates if x.arch in ('x86_64', 'noarch')))
        if not compatible and mandatory:
            raise RuntimeError('No installed x86_64/noarch RPM provides: ' + capability)
        return compatible

    def walk(self, seeds):
        pending = []
        for seed in seeds:
            pending.extend(self.providers(seed))
        selected = set()
        while pending:
            package = pending.pop()
            if package in selected:
                continue
            selected.add(package)
            reqs = run(['rpm', '-q', '--requires', package.query]).stdout.splitlines()
            for req in reqs:
                req = req.strip()
                if not req or req.startswith('rpmlib('):
                    continue
                rich = req.startswith('(')
                names = rich_names(req) if rich else [req.split()[0]]
                for name in names:
                    if name.startswith('rpmlib('):
                        continue
                    for provider in self.providers(name, mandatory=not rich):
                        self.edges.append((package.query, req, provider.query))
                        if provider not in selected:
                            pending.append(provider)
        return sorted(selected)


def verify_signature(path):
    p = run(['rpm', '-Kv', path], check=False)
    text = p.stdout + p.stderr
    if (p.returncode or re.search(r'\b(?:NOKEY|NOT OK|BAD|NOTTRUSTED)\b', text, re.I)
            or not re.search(r'(?:signature|\bgpg\b|\bpgp\b).*\bOK\b', text, re.I)):
        raise RuntimeError('RPM signature is not trusted/valid: {}\n{}'.format(path, text))
    return text


def rocky_vault_repositories(os_release):
    """Official same-minor historical repositories, with no version substitution."""
    match = re.search(r'^VERSION_ID=[\"\']?(9\.[0-9]+)[\"\']?$', os_release, re.M)
    if not match:
        raise RuntimeError('Exact Rocky 9 minor release is needed for historical acquisition.')
    minor = match.group(1)
    return {'noir-vault-' + name.lower():
            'https://dl.rockylinux.org/vault/rocky/{}/{}/x86_64/os/'.format(minor, name)
            for name in ('BaseOS', 'AppStream', 'CRB')}


def verify_alt_identity(path, package):
    """ALT can republish one NEVRA; retain and match its native build identity."""
    installed = run(['rpm', '-q', package.query, '--qf', ALT_STAMP_QF]).stdout.strip()
    downloaded = run(['rpm', '-qp', path, '--qf', ALT_STAMP_QF]).stdout.strip()
    fields = installed.split('\t')
    # Older native RPMs legitimately predate ALT disttags. Preserve and compare
    # the literal missing-tag marker; BUILDTIME still identifies that build.
    if (len(fields) != 2 or not fields[0] or
            not fields[1].isdigit()):
        raise RuntimeError('Invalid installed ALT DISTTAG/BUILDTIME: ' + repr(installed))
    if installed != downloaded:
        raise RuntimeError('ALT native build identity differs for {}: installed {!r}, downloaded {!r}'.format(
            package.query, installed, downloaded))
    return installed


def fill_alt_native_cache(packages, directory, metadata, cache=None):
    """Use signed exact installed-build RPMs retained by the native OS cache."""
    if cache is None:
        explicit = os.environ.get('ALT_NATIVE_RPM_CACHE_DIR')
        if explicit:
            cache = Path(explicit)
        elif len(directory.parents) >= 3 and directory.parents[1].name == 'staging':
            # Also supports an all-stage process launched before the build
            # wrapper exported the dedicated native cache environment variable.
            candidate = directory.parents[2] / 'cache/native-rpms'
            cache = candidate if candidate.is_dir() else Path('/var/cache/apt/archives')
        else:
            cache = Path('/var/cache/apt/archives')
    present = set()
    for path in directory.glob('*.rpm'):
        rows = parse_packages(run(['rpm', '-qp', '--qf', QF, path]).stdout)
        if len(rows) == 1:
            present.add(rows[0])
    missing = set(packages) - present
    if not missing:
        return []
    provenance, rejected = [], []
    try:
        cached_files = sorted(cache.glob('*.rpm'))
    except PermissionError:
        cached_files = []
        rejected.append('Native cache is unreadable as the builder: ' + str(cache) +
                        '; use ALT_NATIVE_RPM_CACHE_DIR with a reviewed readable copy')
    for path in cached_files:
        if path.is_symlink() or not path.is_file():
            continue
        query = run(['rpm', '-qp', '--qf', QF, path], check=False)
        if query.returncode:
            continue
        rows = parse_packages(query.stdout)
        if len(rows) != 1 or rows[0] not in missing:
            continue
        package = rows[0]
        try:
            stamp = verify_alt_identity(path, package)
            verify_signature(path)
        except RuntimeError as error:
            rejected.append(str(error))
            continue
        destination = directory / (package.query + '.rpm')
        shutil.copyfile(path, destination)
        provenance.append({'identity': package.tsv(), 'native_build': stamp,
                           'cache_file': str(path), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
        missing.remove(package)
        if not missing:
            break
    (metadata / 'download-installed-cache.json').write_text(json.dumps(
        {'source': str(cache), 'copied': provenance, 'missing': [x.tsv() for x in sorted(missing)],
         'rejected_candidates': rejected}, indent=2) + '\n')
    return sorted(missing)


def fill_alt_official_snapshot(packages, directory, metadata):
    """Retrieve remaining exact originals from one reviewed official snapshot."""
    snapshot = os.environ.get('ALT_SNAPSHOT_DATE', '2025/01/25')
    if not re.fullmatch(r'[0-9]{4}/[0-9]{2}/[0-9]{2}', snapshot):
        raise RuntimeError('ALT_SNAPSHOT_DATE must be YYYY/MM/DD')
    # This snapshot was exercised for the lab's original perl/shadow/repo RPMs.
    # A different native baseline may require an explicitly reviewed other date.
    provenance = {'official_snapshot_date': snapshot, 'copied': []}
    record = metadata / 'download-official-snapshot.json'
    record.write_text(json.dumps(provenance, indent=2) + '\n')
    for package in packages:
        filename = package.query + '.rpm'
        if not re.fullmatch(r'[A-Za-z0-9_.+@=-]+\.rpm', filename):
            raise RuntimeError('Unsupported RPM identity filename: ' + filename)
        uri = 'https://ftp.altlinux.org/pub/distributions/archive/p10/date/{}/{}/RPMS.classic/{}'.format(
            snapshot, package.arch, filename)
        destination = directory / filename
        partial = Path(str(destination) + '.part')
        run_logged(['curl', '--fail', '--location', '--retry', '3', '--proto', '=https',
                    '--output', partial, uri], metadata / ('download-snapshot-' + package.query + '.log'))
        rows = parse_packages(run(['rpm', '-qp', '--qf', QF, partial]).stdout)
        if rows != [package]:
            raise RuntimeError('Official ALT snapshot RPM identity differs from requested original: ' + filename)
        stamp = verify_alt_identity(partial, package)
        verify_signature(partial)
        partial.replace(destination)
        provenance['copied'].append({'identity': package.tsv(), 'native_build': stamp,
                                     'uri': uri, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
        record.write_text(json.dumps(provenance, indent=2) + '\n')


def download_rpms(target, packages, directory, metadata):
    directory.mkdir(parents=True, exist_ok=True)
    log = metadata / 'download.log'
    if target == 'rocky9':
        # Exact NEVRA requests are intentionally not dependency-filtered by DNF.
        # Every installed package in the closure is downloaded explicitly.
        args = ['dnf', 'download', '--arch=x86_64,noarch',
                '--downloaddir=' + str(directory)]
        exact_specs = [x.dnf_spec for x in packages]
        try:
            run_logged(args + exact_specs, log)
        except RuntimeError:
            # Live Rocky repositories roll forward to the next minor release.
            # Keep the failed command evidence; retry only those SAME exact
            # installed identities with official native minor vaults added.
            repos = rocky_vault_repositories(Path('/etc/os-release').read_text())
            (metadata / 'download-vault-repositories.json').write_text(
                json.dumps({'reason': 'live exact-package download failed; see download.log',
                            'repositories': repos, 'requested_exact_nevras': exact_specs}, indent=2) + '\n')
            extra_args = ['--repofrompath={},{}'.format(name, url) for name, url in repos.items()]
            extra_args += ['--enablerepo=' + name for name in repos]
            run_logged(args + extra_args + exact_specs, metadata / 'download-vault.log')
    elif target == 'alt104':
        # APT-RPM, NOT Debian APT: --reinstall forces URIs for installed packages.
        # --print-uris avoids installing or altering the build machine.
        cache = directory.parent / 'apt-download-cache'
        (cache / 'partial').mkdir(parents=True, exist_ok=True)
        p = run_logged(['apt-get', '-y', '--print-uris', '--download-only', '--reinstall',
                 '-o', 'Debug::NoLocking=1', '-o', 'Dir::Cache::archives=' + str(cache),
                 'install'] + [x.apt_spec for x in packages], log)
        uris = []
        for line in p.stdout.splitlines():
            if not line.startswith("'"):
                continue
            parts = shlex.split(line)
            if len(parts) < 2 or not re.match(r'^(https?|ftp)://', parts[0]):
                continue
            filename = parts[1]
            # APT-RPM cache names contain the ALT disttag and @buildtime.
            if not re.fullmatch(r'[A-Za-z0-9_+.:~%@-]+\.rpm', filename):
                raise RuntimeError('Unexpected APT-RPM download filename: ' + filename)
            uris.append((parts[0], filename))
        for uri, filename in uris:
            destination = directory / filename
            run(['curl', '--fail', '--location', '--retry', '3',
                 '--proto', '=https,http,ftp', '--output', str(destination) + '.part', uri])
            Path(str(destination) + '.part').replace(destination)
        missing = fill_alt_native_cache(packages, directory, metadata)
        if missing:
            fill_alt_official_snapshot(missing, directory, metadata)
        # Cache is outside the sealed bundle and contains no runtime dependency.
    else:
        raise ValueError('Unknown target')


def capture(target, binary, directory, metadata, extra=()):
    directory = Path(directory).resolve()
    metadata = Path(metadata).resolve()
    metadata.mkdir(parents=True, exist_ok=True)
    # Include installer/verifier prerequisites as well as core Noir runtime.
    seeds = ['bash', 'coreutils', 'grep', 'sed', 'findutils', 'diffutils',
             'tar', 'gzip', 'rpm', 'ca-certificates', '/usr/bin/git', '/usr/bin/python3',
             '/usr/bin/awk', '/usr/bin/ldd',
             'util-linux'] + list(extra)
    if target == 'alt104':
        seeds += ['gnupg', 'alt-gpgkeys']
    paths = dynamic_paths(binary)
    for path in paths:
        seeds.append(path)
        if os.path.realpath(path) != path:
            seeds.append(os.path.realpath(path))
    closure = InstalledClosure()
    packages = closure.walk(seeds)
    # Multiple versions of the same name/architecture cannot be deployed as one
    # ordinary upgrade transaction; fail rather than choosing an arbitrary one.
    keys = [(x.name, x.arch) for x in packages]
    if len(keys) != len(set(keys)):
        raise RuntimeError('Closure contains multiple versions of one RPM. Use a clean builder.')
    (metadata / 'runtime-rpms.tsv').write_text(''.join(x.tsv() + '\n' for x in packages))
    (metadata / 'runtime-seeds.json').write_text(json.dumps(seeds, indent=2) + '\n')
    (metadata / 'dependency-edges.tsv').write_text(''.join('\t'.join(x) + '\n' for x in sorted(set(closure.edges))))
    download_rpms(target, packages, directory, metadata)
    actual = {}
    signature_logs = []
    alt_identities = []
    for path in sorted(directory.glob('*.rpm')):
        signature_logs.append(verify_signature(path))
        rows = parse_packages(run(['rpm', '-qp', '--qf', QF, path]).stdout)
        if len(rows) != 1 or rows[0] in actual:
            raise RuntimeError('Duplicate/invalid RPM: ' + str(path))
        if target == 'alt104':
            alt_identities.append(rows[0].tsv() + '\t' + verify_alt_identity(path, rows[0]))
        # Repository cache names may contain percent-encoded epochs. Normalize
        # to a safe name without losing exact identity (which stays in metadata).
        canonical = directory / (rows[0].query + '.rpm')
        if not re.fullmatch(r'[A-Za-z0-9_.+@=-]+\.rpm', canonical.name):
            raise RuntimeError('Unsupported RPM identity filename: ' + canonical.name)
        if canonical != path:
            if canonical.exists():
                raise RuntimeError('RPM canonical filename collision: ' + canonical.name)
            path.rename(canonical)
        actual[rows[0]] = canonical
    if set(actual) != set(packages):
        raise RuntimeError('Downloaded RPM set differs from the exact requested closure.\nMissing: {}\nUnexpected: {}'.format(
            sorted(set(packages) - set(actual)), sorted(set(actual) - set(packages))))
    (metadata / 'rpm-signatures.log').write_text('\n'.join(signature_logs))
    if target == 'alt104':
        (metadata / 'runtime-rpms-alt-native.tsv').write_text('\n'.join(alt_identities) + '\n')
    with tempfile.TemporaryDirectory(prefix='noir-empty-rpmdb-') as temp:
        db = Path(temp) / 'db'
        db.mkdir()
        run(['rpm', '--dbpath', db, '--initdb'])
        # This executes NO package scriptlets and changes NO system packages.
        # RPM itself checks version predicates and rich/conditional dependencies.
        log = metadata / 'empty-rpmdb-closure-test.log'
        p = run_logged(['rpm', '--dbpath', db, '-U', '--test', '--ignoresize'] +
                [actual[x] for x in sorted(actual)], log)
        log.write_text(p.stdout + p.stderr + '\nPASS\n')
    return packages


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target', choices=['rocky9', 'alt104'], required=True)
    p.add_argument('--binary', required=True)
    p.add_argument('--rpms', required=True)
    p.add_argument('--metadata', required=True)
    p.add_argument('--extra', nargs='*', default=[])
    args = p.parse_args()
    capture(args.target, args.binary, args.rpms, args.metadata, args.extra)
