#!/usr/bin/env bash
# Library sourced only by this build kit's scripts.
set -Eeuo pipefail
export LC_ALL=C
log() { printf '[noir-build] %s\n' "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"; }
root_cmd() { if (( EUID == 0 )); then "$@"; else need sudo; sudo -- "$@"; fi; }
check_target() {
    local target=$1
    [[ $(uname -m) == x86_64 ]] || die 'This kit supports x86_64 only.'
    [[ -r /etc/os-release ]] || die '/etc/os-release is missing.'
    local ID='' ID_LIKE='' VERSION_ID='' PRETTY_NAME=''
    # Trusted host configuration, not bundle-supplied shell code.
    . /etc/os-release
    case "$target" in
      rocky9) [[ "$ID" == rocky && ( "$VERSION_ID" == 9 || "$VERSION_ID" == 9.* ) ]] || die "Need Rocky Linux 9; found $ID $VERSION_ID" ;;
      alt104)
        [[ "$ID $ID_LIKE" == *alt* ]] || die "Need ALT Linux; found $ID $VERSION_ID"
        [[ "$VERSION_ID" == 10.4 || "$VERSION_ID" == 10.4.* ]] || die "Need actual ALT 10.4, not generic p10/p11/Sisyphus; found $VERSION_ID"
        ;;
      *) die "Unknown target: $target" ;;
    esac
}
sha_file() { sha256sum "$1" | awk '{print $1}'; }
# Avoid path metacharacters in compiler macros, APT paths, and RPM queries.
safe_work_path() {
    [[ "$1" == /* && "$1" != / && "$1" =~ ^/[A-Za-z0-9_./+-]+$ ]] || die "Use an absolute workspace path without whitespace: $1"
    [[ "/$1/" != *'/../'* ]] || die 'Parent traversal in workspace path.'
}
