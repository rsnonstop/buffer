#!/usr/bin/env python3
"""Record first-acquired input bytes; detect later changes before compilation.

This is not a publisher signature. The initial acquisition still relies on the
pinned Noir commit, compiler checksum, and each source repository's trust.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
from seal import digest


def inventory(source, toolchain):
    entries = {}
    for label, root in [('source', Path(source)), ('toolchain', Path(toolchain))]:
        for base, dirs, files in os.walk(root, followlinks=False):
            dirs[:] = sorted(x for x in dirs if x not in ('.git', '__pycache__', '.crystal'))
            # Record directory symlinks as symlinks, never follow them.
            for name in list(dirs):
                if (Path(base)/name).is_symlink():
                    files.append(name); dirs.remove(name)
            for name in sorted(files):
                path = Path(base)/name
                rel = path.relative_to(root).as_posix()
                if label == 'source' and (name.endswith(('.o', '.a')) or rel in ('bin/noir', 'bin/noir_spec')):
                    continue
                if name == '.git':
                    continue
                key = label + '/' + rel
                if path.is_symlink():
                    entries[key] = 'symlink:' + os.readlink(path)
                elif path.is_file():
                    entries[key] = digest(path)
                else:
                    raise RuntimeError('Non-regular input: ' + str(path))
    return entries


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['record','check'])
    p.add_argument('--source', required=True); p.add_argument('--toolchain', required=True)
    p.add_argument('--manifest', required=True, type=Path)
    a=p.parse_args(); current=inventory(a.source,a.toolchain)
    if a.action == 'record':
        a.manifest.write_text(json.dumps(current, indent=2, sort_keys=True)+'\n')
    else:
        saved=json.loads(a.manifest.read_text())
        changed=sorted(k for k in set(saved)|set(current) if saved.get(k)!=current.get(k))
        if changed:
            raise SystemExit('Input files changed since fetch (first 20):\n'+'\n'.join(changed[:20]))
    print('Input audit:',a.action,len(current),'entries')

if __name__ == '__main__': main()
