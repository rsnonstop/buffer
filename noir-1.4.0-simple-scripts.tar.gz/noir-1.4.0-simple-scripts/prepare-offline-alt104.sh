#!/usr/bin/env bash
# Optional root preparation for FULL offline bundles only.
# Run AFTER build-alt104.sh --bootstrap and BEFORE the ordinary source build.
# This file is standalone and is never called by build-alt104.sh.
set -Eeuo pipefail
if [[ ${1:-} == --help && $# == 1 ]]; then
    printf '%s\n' 'Usage: sudo ./prepare-offline-alt104.sh' \
      'Imports reviewed installed OS signers and copies exact trusted native RPM originals.' \
      'Run before compiling, so the recorded native RPM baseline includes these keys.'
    exit 0
fi
[[ $# == 0 ]] || { printf '%s\n' 'Unknown argument. Use --help.' >&2; exit 2; }
[[ $EUID == 0 ]] || { printf '%s\n' 'This optional OS-trust/cache preparation requires root.' >&2; exit 2; }
if [[ $(uname -m) != x86_64 ]] || \
  ! grep -Eq '^ID="?altlinux"?$' /etc/os-release || \
  ! grep -Eq '^VERSION_ID="?10\.4"?$' /etc/os-release; then
    printf '%s\n' 'Requires ALT Server 10.4 x86_64.' >&2
    exit 2
fi

# ALT APT trusts the installed OS keyring; RPM may have no imported keys.
# Import only these reviewed OS fingerprints, never downloaded bundle keys.
# Also preserve exact signed native RPM originals in a separate readable
# root-owned cache for the optional offline-bundle step. No OS Python changes.
/usr/bin/python3 - <<'PY'
import hashlib
import json
import re
import shutil
import stat
import subprocess
import tempfile
from pathlib import Path

keyring = Path('/usr/lib/alt-gpgkeys/pubring.gpg')
vendors = Path('/etc/apt/vendors.list.d/alt.list')
for path in (keyring, vendors):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise RuntimeError('Unsafe installed OS trust file: ' + str(path))
    owner = subprocess.check_output(['rpm', '-qf', '--qf', '%{NAME}\n', str(path)], text=True).strip()
    if path == keyring and owner != 'alt-gpgkeys':
        raise RuntimeError('Keyring is not owned by installed alt-gpgkeys')
fingerprints = ['49B01E70C64124E6742EAE7195C584D5AE4AE412',
                'DF6C02E5F174D7CDF792A9CDFF979DEDDA2773BB',
                '357BE37422F73D9CB3A0C8D142F343A2C7EB80F9']
# Historical p10 packages still need this reviewed OS signer. Expiration
# metadata comes from the installed OS keyring; RPM checks remain enabled.
with tempfile.TemporaryDirectory(prefix='noir-simple-alt104-trust-', dir='/var/tmp') as private:
    for fingerprint in fingerprints:
        if 'Fingerprint "' + fingerprint + '";' not in vendors.read_text():
            raise RuntimeError('Reviewed fingerprint absent from native APT vendor trust')
        gpg = ['gpg', '--no-options', '--homedir', private, '--batch', '--no-default-keyring',
               '--keyring', str(keyring)]
        listed = subprocess.check_output(gpg + ['--with-colons', '--fingerprint', fingerprint], text=True)
        actual = next(line.split(':')[9] for line in listed.splitlines() if line.startswith('fpr:'))
        if actual != fingerprint:
            raise RuntimeError('Native OS fingerprint mismatch')
        exported = Path(private) / (fingerprint + '.asc')
        exported.write_bytes(subprocess.check_output(gpg + ['--armor', '--export', fingerprint]))
        if not exported.stat().st_size:
            raise RuntimeError('Empty OS signer export')
        subprocess.run(['rpm', '--import', str(exported)], check=True)
        print('Imported reviewed native signer:', fingerprint)

cache = Path('/var/tmp/noir-1.4.0-simple-alt104-native-rpms')
cache.mkdir(mode=0o755, exist_ok=True)
info = cache.lstat()
if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
    raise RuntimeError('Readable native cache must be a root-owned nonwritable directory')
cache.chmod(0o755)
qf = '%{NAME}\t%{EPOCH}\t%{VERSION}\t%{RELEASE}\t%{ARCH}\t%{DISTTAG}\t%{BUILDTIME}\n'
installed = set(subprocess.check_output(['rpm', '-qa', '--qf', qf], text=True).splitlines())
copied = []
for path in sorted(Path('/var/cache/apt/archives').glob('*.rpm')):
    if path.is_symlink() or not path.is_file():
        continue
    query = subprocess.run(['rpm', '-qp', '--qf', qf, str(path)], text=True, capture_output=True)
    if query.returncode or query.stdout.strip() not in installed:
        continue
    signature = subprocess.run(['rpm', '-Kv', str(path)], text=True, capture_output=True)
    output = signature.stdout + signature.stderr
    if signature.returncode or re.search(r'\b(?:NOKEY|NOT OK|BAD|NOTTRUSTED)\b', output, re.I):
        raise RuntimeError('Native cache signature failed: ' + str(path))
    if not re.search(r'(?:signature|\bgpg\b|\bpgp\b).*\bOK\b', output, re.I):
        raise RuntimeError('Native cache package lacks trusted signature: ' + str(path))
    name, epoch, version, release, arch, disttag, buildtime = query.stdout.strip().split('\t')
    canonical = name + '-' + version + '-' + release + '.' + arch + '.rpm'
    if not re.fullmatch(r'[A-Za-z0-9_.+@=-]+\.rpm', canonical):
        raise RuntimeError('Unsupported canonical RPM filename')
    destination = cache / canonical
    if destination.is_symlink():
        raise RuntimeError('Symlink in native cache')
    shutil.copyfile(path, destination)
    destination.chmod(0o644)
    copied.append({'source': str(path), 'file': canonical,
                   'native_identity': query.stdout.strip().split('\t'),
                   'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
(cache / 'provenance.json').write_text(json.dumps(copied, indent=2) + '\n')
(cache / 'provenance.json').chmod(0o644)
print('Copied exact installed trusted native RPMs:', len(copied))
PY
printf '%s\n' 'Optional offline preparation complete; now compile as an ordinary user.'
