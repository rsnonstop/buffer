+++
title = "Using Noir with xAI"
description = "Integrate Noir with xAI Grok models for code analysis."
weight = 5
sort_by = "weight"

+++

Use [xAI](https://x.ai) Grok models for code analysis and endpoint discovery.

## Setup

1.  **API Key**: Get from [xAI website](https://x.ai/api)
2.  **Model**: Choose model (e.g., `grok-4.5`)

## Usage

Run Noir with xAI:

```bash
noir scan ./spec/functional_test/fixtures/hahwul \
     --ai-provider=xai \
     --ai-model=grok-4.5 \
     --ai-key=xai-...
```

