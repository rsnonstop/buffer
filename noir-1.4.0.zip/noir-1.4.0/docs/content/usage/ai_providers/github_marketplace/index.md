+++
title = "Using Noir with GitHub Marketplace Models"
description = "Use AI models from GitHub Marketplace with Noir for code analysis."
weight = 6
sort_by = "weight"

+++

Use AI models from the [GitHub Marketplace](https://github.com/marketplace/models) with Noir for code analysis.

## Setup

1.  **Generate a Personal Access Token**: Create a PAT following the [GitHub documentation](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens). Ensure it has permissions to access AI models.
2.  **Choose a Model**: Browse the [GitHub Marketplace](https://github.com/marketplace/models) for available models.

## Usage

**Using the GitHub API**:

```bash
noir scan ./spec/functional_test/fixtures/hahwul \
     --ai-provider=github \
     --ai-model=gpt-5.5 \
     --ai-key=github_pat_...
```

{% alert_warning() %}
GitHub Models used to be reachable through the shared Azure Inference endpoint (`--ai-provider=azure`), but that endpoint has been retired and `models.inference.ai.azure.com` no longer resolves in DNS. Use `--ai-provider=github` as shown above.
{% end %}
