+++
title = "셸 자동완성"
description = "Zsh, Bash, Fish, Elvish에서 Noir 셸 자동완성을 설정합니다."
weight = 2
sort_by = "weight"

+++

`Tab` 키를 누르면 Noir의 명령어, 플래그, 옵션이 자동완성됩니다. 네 가지 셸별로 완성 스크립트를 생성할 수 있습니다.

## Zsh

아래 명령으로 생성될 완성 스크립트를 미리 확인할 수 있습니다.

```bash
noir completion zsh
```

Zsh이 시작할 때 자동으로 로드하려면, 완성 스크립트를 디렉터리에 저장하고 그 디렉터리가 `compinit` 실행 전에 Zsh의 `fpath`에 포함되도록 합니다.

```bash
mkdir -p ~/.zsh/completion
noir completion zsh > ~/.zsh/completion/_noir
```

그다음 `~/.zshrc`에서 (`compinit` 호출 전에) 해당 디렉터리를 `fpath`에 추가하세요. `site-functions`처럼 이미 `fpath`에 있는 디렉터리에 저장했다면 이 단계는 필요 없습니다.

```bash
fpath=(~/.zsh/completion $fpath)
autoload -Uz compinit && compinit
```

## Bash

마찬가지로 먼저 미리 확인할 수 있습니다.

```bash
noir completion bash
```

`bash-completion` 표준 디렉터리에 저장하면 새 세션에서 자동으로 로드됩니다.

```bash
mkdir -p ~/.local/share/bash-completion/completions
noir completion bash > ~/.local/share/bash-completion/completions/noir
```

## Fish

미리 확인합니다.

```bash
noir completion fish
```

Fish의 완성 디렉터리에 저장하면 자동 로드됩니다.

```bash
mkdir -p ~/.config/fish/completions
noir completion fish > ~/.config/fish/completions/noir.fish
```

## Elvish

[Elvish](https://elv.sh) 는 모듈 경로에서 완성 스크립트를 로드합니다. 스크립트를 `noir.elv` 로 저장한 뒤 `rc.elv` 에서 `use noir` 하면 됩니다.

```bash
mkdir -p ~/.config/elvish/lib
noir completion elvish > ~/.config/elvish/lib/noir.elv
echo 'use noir' >> ~/.config/elvish/rc.elv
```

로드되면 `$edit:completion:arg-completer[noir]` 에 완성기가 등록되어, `noir <Tab>` 은 동사 목록, `noir scan <Tab>` 은 파일 경로, `noir scan -<Tab>` 은 scan 플래그를 보여줍니다.

## Homebrew 사용자

Homebrew로 설치했다면 셸 자동완성이 이미 설정되어 있어 별도 작업이 필요 없습니다.
