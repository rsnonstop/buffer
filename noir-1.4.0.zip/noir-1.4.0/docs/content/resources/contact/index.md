+++
title = "Contact Us"
description = "Get in touch with the OWASP Noir team."
weight = 5
sort_by = "weight"

+++

## GitHub

Reach us through the [GitHub repository](https://github.com/owasp-noir/noir):

*   **Bug reports and feature requests**: Open an [issue](https://github.com/owasp-noir/noir/issues).
*   **Questions and discussions**: Use the [discussions](https://github.com/orgs/owasp-noir/discussions) page.

## Project Leaders

{{ member(name="HAHWUL", role="Co-Lead, Creator", image="./hahwul.jpeg", links="𝕏|https://x.com/hahwul, GitHub|https://github.com/hahwul") }}
{{ member(name="KSG", role="Co-Lead", image="./ksg.jpeg", links="GitHub|https://github.com/ksg97031") }}
