+++
title = "Noir 설치"
description = "Homebrew, Snapcraft, Docker, Nix, AUR, .deb, .rpm, .apk, 바이너리 다운로드 또는 소스 빌드를 통해 OWASP Noir를 설치합니다."
weight = 2
sort_by = "weight"
prev_page_path = "/get_started/overview/"
prev_page_label = "Noir란?"
next_page_path = "/get_started/running/"
next_page_label = "첫 번째 스캔"

+++

{% mascot(mood="think") %}
Noir는 런타임 의존성 없이 단일 바이너리로 배포돼. 대부분의 사용자에게 Homebrew가 가장 빠르지만, 시스템에 맞는 걸 선택해.
{% end %}

아래 방법들은 모두 동일한 `noir` 바이너리를 설치하므로 하나만 고르면 됩니다. 대체로 간편한 순서로 정리했으니, 사용하는 플랫폼과 패키지 매니저에 맞는 항목을 선택하고 나머지는 건너뛰어도 됩니다.

## Homebrew (macOS 및 Linux)

가장 간편한 방법. Noir에는 공식 [Homebrew formula](https://formulae.brew.sh/formula/noir)가 있습니다.

설치:

```bash
brew install noir
```

업데이트:

```bash
brew upgrade noir
```

{% alert_info() %}
Zsh, Bash, Fish용 셸 자동완성이 함께 설치됩니다.
{% end %}

## Snapcraft (Linux)

[Snap](https://snapcraft.io) 패키지는 대부분의 Linux 배포판에서 동작하고, 백그라운드에서 자동 업데이트됩니다.

설치:

```bash
sudo snap install noir
```

수동 업데이트:

```bash
sudo snap refresh noir
```

## Docker

호스트에 직접 설치하고 싶지 않거나, CI/CD 파이프라인에서 쓸 때 유용합니다.

최신 이미지 다운로드/업데이트:

```bash
docker pull ghcr.io/owasp-noir/noir:latest
```

현재 디렉토리를 스캔하려면 아래와 같이 실행합니다.

```bash
docker run --rm -v $(pwd):/tmp ghcr.io/owasp-noir/noir:latest noir scan /tmp
```

이미지 태그는 OCI/Docker 컨벤션을 따라 `v` 프리픽스 없이 발행됩니다. 예: `:0.30.0`, `:0.30`, `:latest`. (v0.29.1까지는 `:vX.Y.Z` 형태를 썼으므로, 버전을 고정해 둔 참조가 있다면 업데이트하세요.) 사용 가능한 태그 목록은 [GitHub Packages 페이지](https://github.com/owasp-noir/noir/pkgs/container/noir)에서 확인할 수 있습니다.

## Nix

[Nix](https://nixos.org) 사용자라면 Flakes로 설치할 수 있습니다.

설치:

```bash
nix profile add github:owasp-noir/noir
```

업데이트:

```bash
nix profile upgrade noir
```

{% alert_info() %}
**팁:** Docker나 제한된 환경에서는 아래처럼 실험적 기능을 활성화해야 할 수 있습니다.
{% end %}

```bash
nix --extra-experimental-features "nix-command flakes" profile add github:owasp-noir/noir
```

설치 없이 한 번만 실행해 볼 수도 있습니다.

```bash
nix run github:owasp-noir/noir -- -h
```

## 직접 바이너리 사용

패키지 매니저가 없다면 [GitHub Releases](https://github.com/owasp-noir/noir/releases/latest)에서 빌드된 바이너리를 받을 수 있습니다. Linux와 macOS용이 제공됩니다.

설치 및 업데이트:

1. 플랫폼에 맞는 바이너리를 다운로드합니다(예: Linux는 `noir-v1.3.0-linux-x86_64`, macOS는 `noir-v1.3.0-osx-arm64.tar.gz`).
2. **Linux**: 실행 권한을 부여한 뒤 `PATH`로 옮깁니다.

    ```bash
    chmod +x noir-v*-linux-*
    sudo mv noir-v*-linux-* /usr/local/bin/noir
    ```

3. **macOS**: tarball을 풀고 `lib/` 디렉터리를 바이너리와 함께 유지합니다.

    ```bash
    # 시스템 전역 설치
    sudo mkdir -p /opt/noir
    sudo tar xzf noir-v*-osx-*.tar.gz -C /opt/noir
    sudo ln -sf /opt/noir/noir /usr/local/bin/noir
    ```

    `sudo` 없이 설치하려면 `~/.local/noir`에 풀고 `PATH`에 해당 디렉터리를 추가하세요.

    macOS 아카이브에는 OpenSSL 라이브러리가 `lib/`에 포함되어 있으므로, `noir` 바이너리만 따로 옮기지 마세요.

4. 설치를 확인합니다.

    ```bash
    noir --version
    ```

## Debian 패키지 (.deb)

Debian/Ubuntu 계열이라면 [GitHub Releases](https://github.com/owasp-noir/noir/releases/latest)의 `.deb` 패키지를 쓸 수 있습니다. `dpkg`/`apt`로 다른 시스템 패키지처럼 관리됩니다. `amd64`와 `arm64`가 모두 제공됩니다.

설치 및 업데이트:

1. 최신 버전을 조회하고 다운로드합니다.

    ```bash
    VERSION=$(curl -s https://api.github.com/repos/owasp-noir/noir/releases/latest | grep '"tag_name":' | sed -E 's/.*"v([^"]+)".*/\1/')
    wget "https://github.com/owasp-noir/noir/releases/download/v${VERSION}/noir_${VERSION}_amd64.deb"
    ```

2. 패키지를 설치하거나 업그레이드합니다.

    ```bash
    sudo dpkg -i "noir_${VERSION}_amd64.deb"
    ```

3. 의존성이 누락됐다면 아래 명령으로 해결합니다.

    ```bash
    sudo apt-get -f install
    ```

4. 설치를 확인합니다.

    ```bash
    noir --version
    ```

## Arch Linux (AUR)

Noir는 [AUR](https://aur.archlinux.org/packages/noir)에 공식 등록되어 있습니다.

설치 및 업데이트:

```bash
yay -S noir
```

## RPM 패키지 (.rpm)

Fedora, RHEL, CentOS, openSUSE 등 RPM 기반 배포판은 [GitHub Releases](https://github.com/owasp-noir/noir/releases/latest)의 `.rpm` 패키지를 사용할 수 있습니다. `x86_64`와 `aarch64`가 모두 제공됩니다.

설치:

1. 최신 버전을 조회하고 다운로드합니다.

    ```bash
    VERSION=$(curl -s https://api.github.com/repos/owasp-noir/noir/releases/latest | grep '"tag_name":' | sed -E 's/.*"v([^"]+)".*/\1/')
    wget "https://github.com/owasp-noir/noir/releases/download/v${VERSION}/noir-${VERSION}.x86_64.rpm"
    ```

2. 설치합니다.

    ```bash
    sudo rpm -i "noir-${VERSION}.x86_64.rpm"
    ```

    또는 `dnf`로 설치합니다.

    ```bash
    sudo dnf install "./noir-${VERSION}.x86_64.rpm"
    ```

업데이트:

1. 설치 단계에 안내된 대로 최신 버전을 다운로드합니다.
2. 업그레이드합니다.

    ```bash
    sudo rpm -U "noir-${VERSION}.x86_64.rpm"
    ```

    또는 `dnf`로 업그레이드합니다.

    ```bash
    sudo dnf upgrade "./noir-${VERSION}.x86_64.rpm"
    ```

3. 설치를 확인합니다.

    ```bash
    noir --version
    ```

## Alpine 패키지 (.apk)

Alpine Linux 사용자는 [GitHub Releases](https://github.com/owasp-noir/noir/releases/latest)의 `.apk` 패키지를 사용할 수 있습니다. `x86_64`와 `aarch64`가 모두 제공됩니다.

설치 및 업데이트:

1. 최신 버전을 조회하고 다운로드합니다.

    ```bash
    VERSION=$(curl -s https://api.github.com/repos/owasp-noir/noir/releases/latest | grep '"tag_name":' | sed -E 's/.*"v([^"]+)".*/\1/')
    wget "https://github.com/owasp-noir/noir/releases/download/v${VERSION}/noir-${VERSION}-x86_64.apk"
    ```

2. 설치 및 업그레이드합니다.

    ```bash
    sudo apk add --upgrade --allow-untrusted "noir-${VERSION}-x86_64.apk"
    ```

3. 설치를 확인합니다.

    ```bash
    noir --version
    ```

## 소스에서 빌드

직접 빌드하거나, 프로젝트에 기여하고 싶을 때 사용합니다.

{% alert_warning() %}
[Crystal](https://crystal-lang.org/install/) 프로그래밍 언어가 필요합니다.
{% end %}

설치:

1.  **저장소 클론:**

    ```bash
    git clone https://github.com/owasp-noir/noir
    cd noir
    ```

2.  **종속성 설치:**

    ```bash
    shards install
    ```

3.  **빌드:**

    ```bash
    shards build --release
    ```

    빌드된 바이너리는 `./bin/noir`에 위치합니다.

업데이트:

1.  **최신 변경사항 가져오기:**

    ```bash
    git pull
    ```

2.  **의존성 설치 및 재빌드:**

    ```bash
    shards install
    shards build --release
    ```

## 설치 확인

어떤 방법을 선택했든, 아래 명령으로 설치를 확인합니다.

```bash
noir --version
```

버전 번호가 표시되면 준비 완료입니다.

---

**다음**: [첫 번째 스캔](@/get_started/running/index.ko.md)
