+++
title = "Community"
description = "Resources for the OWASP Noir community, including articles, talks, and contribution guidelines."
weight = 9
sort_by = "weight"


[cascade]
toc = true

+++

OWASP Noir is a community-driven project, and we welcome contributions and feedback from everyone.

*   **[Articles & Talks](media/)**: Read articles, blog posts, and watch talks about Noir from community members.

For information on contributing to the project, please see the [Development](../development/) section.
