+++
title = "커뮤니티"
description = "기사, 발표, 기여 가이드라인을 포함한 OWASP Noir 커뮤니티 리소스입니다."
weight = 9
sort_by = "weight"


[cascade]
toc = true

+++

OWASP Noir는 커뮤니티 주도 프로젝트이며, 모든 사람의 기여와 피드백을 환영합니다.

*   **[기사 & 발표](media/)**: 커뮤니티 멤버들이 작성한 Noir에 관한 기사, 블로그 게시물, 발표를 확인하세요.

프로젝트 기여에 대한 정보는 [개발](../development/) 섹션을 참조하세요.
