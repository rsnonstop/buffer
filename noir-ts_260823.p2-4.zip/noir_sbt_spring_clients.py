"""Bounded source-only Spring HTTP client contract identification.

The host supplies its already-built Java workspace and source/provenance
helpers.  This pass identifies outbound Spring HTTP Interface declarations
and Feign interfaces without reclassifying them as inbound server handlers.
Only direct, genuinely resolved framework annotations on unique source
interfaces participate; unresolved or ambiguous endpoint identity fails
closed.
"""

from __future__ import annotations

from typing import Any, Iterable


HTTP_EXCHANGE_PACKAGE = "org.springframework.web.service.annotation"
FEIGN_CLIENT_PACKAGE = "org.springframework.cloud.openfeign"

HTTP_EXCHANGE_METHODS = {
    "GetExchange": "GET",
    "PostExchange": "POST",
    "PutExchange": "PUT",
    "DeleteExchange": "DELETE",
    "PatchExchange": "PATCH",
    "HttpExchange": None,
}

HTTP_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "method", "contentType", "accept", "headers"}
)
FIXED_EXCHANGE_ATTRIBUTES = frozenset(
    {"value", "url", "contentType", "accept", "headers"}
)


def _log(host: Any, unit: dict[str, Any], owner: str, message: str) -> None:
    host.write_log(
        f"Skipped Spring client in {unit['fname']} for {owner}: {message}"
    )


def _direct_methods(host: Any, interface_node: Any) -> list[Any]:
    body = host.child_by_field(interface_node, "body")
    if body is None:
        return []
    return sorted(
        (
            child
            for child in body.named_children
            if child.type == "method_declaration"
        ),
        key=lambda node: node.start_byte,
    )


def _usable_contract_method(host: Any, method_node: Any) -> bool:
    modifiers = host.declaration_modifier_names(method_node)
    return "private" not in modifiers and "static" not in modifiers


def _resolved_exchange_annotations(
    host: Any, unit: dict[str, Any], declaration_node: Any
) -> list[tuple[dict[str, Any], str]]:
    resolved: list[tuple[dict[str, Any], str]] = []
    for record in host.direct_annotation_records(declaration_node):
        identity = host.resolve_known_annotation(
            unit,
            record["name_node"],
            set(HTTP_EXCHANGE_METHODS),
            (HTTP_EXCHANGE_PACKAGE,),
        )
        if identity is not None:
            resolved.append((record, identity["name"]))
    return resolved


def _resolve_string_values(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    value_node: Any,
) -> tuple[str, ...] | None:
    values: list[str] = []
    for current in host.annotation_value_nodes(value_node):
        value = host.resolve_workspace_string_expression(
            unit, current, workspace, owner
        )
        if value is None:
            return None
        values.append(value)
    # Noir's Java mapping decoder fans out array-shaped annotation input even
    # for annotations whose library declaration is scalar.  Retain that
    # source-recovery behavior, but only after genuine annotation provenance.
    return tuple(dict.fromkeys(values)) if values else ("",)


def _normalize_client_path(host: Any, value: str) -> str:
    return (
        value
        if value.lower().startswith(("http://", "https://"))
        # Configuration is applied after recall.  Preserve a root placeholder
        # until then so an absolute configured base is not prefixed with `/`.
        or value.startswith("${")
        else host.normalize_spring_path(value)
    )


def _combine_client_paths(host: Any, type_path: str, method_path: str) -> str:
    # A method-level absolute client URL is already complete and must not be
    # appended to a type-level contract prefix.
    if method_path.lower().startswith(("http://", "https://")):
        return method_path
    return host.combine_paths(type_path, method_path)


def _decode_exchange_paths(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_node: Any,
) -> list[str] | None:
    positional, named = host.get_annotation_arguments(annotation_node)
    if len(positional) > 1 or (positional and "value" in named):
        _log(host, unit, owner, "invalid positional/value URL aliases")
        return None

    explicit: list[tuple[str, Any]] = []
    if positional:
        explicit.append(("value", positional[0]))
    for attribute in ("value", "url"):
        if attribute in named:
            explicit.append((attribute, named[attribute]))
    if not explicit:
        return [""]

    aliases: list[tuple[str, tuple[str, ...]]] = []
    for attribute, node in explicit:
        values = _resolve_string_values(host, unit, workspace, owner, node)
        if values is None:
            _log(
                host,
                unit,
                owner,
                f"unresolved @{attribute} client path: "
                f"{host.node_text(unit['source'], node).strip()}",
            )
            return None
        aliases.append((attribute, values))
    if len({values for _attribute, values in aliases}) != 1:
        _log(host, unit, owner, "conflicting explicit value/url aliases")
        return None
    return list(
        dict.fromkeys(
            _normalize_client_path(host, value) for value in aliases[0][1]
        )
    )


def _decode_exchange_methods(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    annotation_name: str,
    annotation_node: Any,
) -> list[str] | None:
    _positional, named = host.get_annotation_arguments(annotation_node)
    if annotation_name != "HttpExchange":
        if "method" in named:
            _log(host, unit, owner, f"invalid method on @{annotation_name}")
            return None
        return [HTTP_EXCHANGE_METHODS[annotation_name]]

    method_node = named.get("method")
    if method_node is None:
        return []
    resolved = _resolve_string_values(
        host, unit, workspace, owner, method_node
    )
    if resolved is None:
        _log(
            host,
            unit,
            owner,
            "unresolved @HttpExchange method: "
            f"{host.node_text(unit['source'], method_node).strip()}",
        )
        return None

    methods: list[str] = []
    for value in resolved:
        token = value.strip().upper()
        if not token:
            continue
        if len(token) > 128 or host.HTTP_METHOD_TOKEN.fullmatch(token) is None:
            _log(host, unit, owner, f"invalid @HttpExchange method token: {value}")
            return None
        methods.append(token)
    return list(dict.fromkeys(methods))


def _decode_exchange_mapping(
    host: Any,
    unit: dict[str, Any],
    workspace: dict[str, Any],
    owner: str,
    record: dict[str, Any],
    annotation_name: str,
) -> dict[str, Any] | None:
    _positional, named = host.get_annotation_arguments(record["node"])
    allowed = (
        HTTP_EXCHANGE_ATTRIBUTES
        if annotation_name == "HttpExchange"
        else FIXED_EXCHANGE_ATTRIBUTES
    )
    unsupported = sorted(set(named) - allowed)
    if unsupported:
        _log(
            host,
            unit,
            owner,
            "unsupported @"
            f"{annotation_name} attributes: {', '.join(unsupported)}",
        )
        return None
    paths = _decode_exchange_paths(
        host, unit, workspace, owner, record["node"]
    )
    methods = _decode_exchange_methods(
        host,
        unit,
        workspace,
        owner,
        annotation_name,
        record["node"],
    )
    if paths is None or methods is None:
        return None
    return {
        "paths": paths,
        "methods": methods,
        "annotation_node": record["node"],
        "annotation_identity": f"{HTTP_EXCHANGE_PACKAGE}.{annotation_name}",
        "annotation_family": host.METHOD_ANNOTATION_FAMILY_BY_IDENTITY[
            f"{HTTP_EXCHANGE_PACKAGE}.{annotation_name}"
        ],
    }


def _ordered_methods(host: Any, methods: Iterable[str]) -> list[str]:
    unique = set(methods)
    known = [method for method in host.SPRING_HTTP_METHODS if method in unique]
    return known + sorted(unique - set(known))


def _combine_methods(
    host: Any, type_methods: Iterable[str], method_methods: Iterable[str]
) -> list[str]:
    type_methods = list(type_methods)
    method_methods = list(method_methods)
    if not type_methods:
        return _ordered_methods(host, method_methods)
    if not method_methods:
        return _ordered_methods(host, type_methods)
    return _ordered_methods(host, [*type_methods, *method_methods])


def _endpoint(
    host: Any,
    unit: dict[str, Any],
    owner: str,
    method_node: Any,
    parameters_node: Any,
    mapping: dict[str, Any],
    path: str,
    http_method: str,
    *,
    path_layers: tuple[str, ...] | None = None,
) -> dict[str, Any]:
    mapping_node = mapping["annotation_node"]
    endpoint = {
        "uri": path,
        "method": http_method,
        "uri_params": host.get_callable_parameters_as_is(
            unit["source"], parameters_node
        ),
        "SrcFile": unit["fname"],
        "SrcLine": mapping_node.start_point.row + 1,
        "SFunction": owner,
        "RouteSrcFile": unit["fname"],
        "RouteSrcLine": mapping_node.start_point.row + 1,
        "HandlerSrcFile": unit["fname"],
        "HandlerSrcLine": method_node.start_point.row + 1,
        "ProjectSrcFile": unit["fname"],
        "technology": "spring",
        "protocol": "http",
        "surface": "client",
        "direction": "outbound",
        host.METHOD_ANNOTATION_EVIDENCE_KEY: (
            host.method_annotation_evidence_from_mapping(
                mapping,
                annotation_source_file=unit["fname"],
                endpoint_source_file=unit["fname"],
            )
        ),
        host.REPRESENTED_TARGETS_KEY: host.represented_target_evidence(
            unit["fname"], "method", method_node
        ),
    }
    if path_layers is not None:
        endpoint["_spring_client_path_layers"] = path_layers
    host.debug_log(endpoint)
    return endpoint


def _http_interface_endpoints(
    workspace: dict[str, Any], host: Any, declaration: dict[str, Any]
) -> list[dict[str, Any]]:
    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_owner = type_info["display_name"]
    type_node = type_info["node"]
    path_layers: list[tuple[str, ...]] = []
    type_methods: list[str] = []
    for layer in host.type_chain(
        host.tree_node_key(type_node), unit["type_infos"]
    ):
        type_annotations = [
            (record, name)
            for record, name in _resolved_exchange_annotations(
                host, unit, layer["node"]
            )
            if name == "HttpExchange"
        ]
        if len(type_annotations) > 1:
            _log(
                host,
                unit,
                type_owner,
                "multiple type-level @HttpExchange mappings",
            )
            return []
        if not type_annotations:
            continue
        mapping = _decode_exchange_mapping(
            host,
            unit,
            workspace,
            layer["display_name"],
            type_annotations[0][0],
            type_annotations[0][1],
        )
        if mapping is None:
            return []
        path_layers.append(tuple(mapping["paths"]))
        type_methods = _combine_methods(host, type_methods, mapping["methods"])
    if not path_layers:
        path_layers = [("",)]

    endpoints: list[dict[str, Any]] = []
    for method_node in _direct_methods(host, type_node):
        if not _usable_contract_method(host, method_node):
            continue
        name_node = host.child_by_field(method_node, "name")
        parameters_node = host.child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = host.node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        mappings = _resolved_exchange_annotations(
            host, unit, method_node
        )
        for record, annotation_name in mappings:
            mapping = _decode_exchange_mapping(
                host,
                unit,
                workspace,
                owner,
                record,
                annotation_name,
            )
            if mapping is None:
                continue
            methods = _combine_methods(
                host, type_methods, mapping["methods"]
            ) or ["ANY"]
            combinations: list[tuple[str, ...]] = [()]
            for layer_paths in [*path_layers, tuple(mapping["paths"])]:
                combinations = [
                    (*prefix, current)
                    for prefix in combinations
                    for current in layer_paths
                ]
            for layers in combinations:
                path = ""
                for current in layers:
                    path = _combine_client_paths(host, path, current)
                for http_method in methods:
                    endpoints.append(
                        _endpoint(
                            host,
                            unit,
                            owner,
                            method_node,
                            parameters_node,
                            mapping,
                            path,
                            http_method,
                            path_layers=layers,
                        )
                    )
    return endpoints


def _resolve_feign_marker(
    host: Any, unit: dict[str, Any], type_node: Any
) -> list[dict[str, Any]]:
    markers = []
    for record in host.direct_annotation_records(type_node):
        resolved = host.resolve_known_annotation(
            unit,
            record["name_node"],
            {"FeignClient"},
            (FEIGN_CLIENT_PACKAGE,),
        )
        if resolved is not None:
            markers.append(record)
    return markers


def _decode_mvc_mapping(
    workspace: dict[str, Any],
    host: Any,
    unit: dict[str, Any],
    record: dict[str, Any],
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    mapping = host.decode_spring_mapping(
        unit["fname"],
        unit["source"],
        record["name_node"],
        record["node"],
        unit["imports"],
        unit["local_annotations"],
        unit["constant_index"],
        lexical_owner,
        diagnostic_owner,
        unit,
        workspace,
    )
    if mapping is not None:
        return mapping
    return host.decode_spring_composed_mapping(
        unit["fname"],
        unit,
        record["name_node"],
        record["node"],
        lexical_owner,
        diagnostic_owner,
        workspace,
    )


def _first_mvc_mapping(
    workspace: dict[str, Any],
    host: Any,
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> dict[str, Any] | None:
    for record in host.direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            host,
            unit,
            record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            return mapping
    return None


def _all_mvc_mappings(
    workspace: dict[str, Any],
    host: Any,
    unit: dict[str, Any],
    declaration_node: Any,
    lexical_owner: str,
    diagnostic_owner: str,
) -> list[dict[str, Any]]:
    mappings = []
    for record in host.direct_annotation_records(declaration_node):
        mapping = _decode_mvc_mapping(
            workspace,
            host,
            unit,
            record,
            lexical_owner,
            diagnostic_owner,
        )
        if mapping is not None:
            mappings.append(mapping)
    return mappings


def _feign_endpoints(
    workspace: dict[str, Any], host: Any, declaration: dict[str, Any]
) -> list[dict[str, Any]]:
    unit = declaration["unit"]
    type_info = declaration["type_info"]
    type_node = type_info["node"]
    type_owner = type_info["display_name"]
    markers = _resolve_feign_marker(host, unit, type_node)
    if not markers:
        return []
    if len(markers) != 1:
        _log(host, unit, type_owner, "multiple @FeignClient annotations")
        return []

    # FeignClient.value/path are classification metadata in Noir's Spring
    # analyzer and deliberately do not contribute a container path.  Ordinary
    # MVC mappings on all lexical type layers do contribute.
    type_paths = [""]
    type_methods: list[str] = []
    for layer in host.type_chain(
        host.tree_node_key(type_node), unit["type_infos"]
    ):
        mapping = _first_mvc_mapping(
            workspace,
            host,
            unit,
            layer["node"],
            layer["display_name"],
            type_owner,
        )
        if mapping is None:
            continue
        if not mapping["valid"]:
            return []
        type_paths = [
            host.combine_paths(prefix, current)
            for prefix in type_paths
            for current in mapping["paths"]
        ]
        type_methods = host.combine_request_method_conditions(
            type_methods, mapping["methods"]
        )

    endpoints: list[dict[str, Any]] = []
    for method_node in _direct_methods(host, type_node):
        if not _usable_contract_method(host, method_node):
            continue
        name_node = host.child_by_field(method_node, "name")
        parameters_node = host.child_by_field(method_node, "parameters")
        if name_node is None or parameters_node is None:
            continue
        method_name = host.node_text(unit["source"], name_node)
        owner = f"{type_owner}.{method_name}"
        for mapping in _all_mvc_mappings(
            workspace, host, unit, method_node, type_owner, owner
        ):
            if not mapping["valid"]:
                continue
            methods = host.combine_request_method_conditions(
                type_methods, mapping["methods"]
            ) or ["ANY"]
            for type_path in type_paths:
                for method_path in mapping["paths"]:
                    path = host.combine_paths(type_path, method_path)
                    for http_method in methods:
                        endpoints.append(
                            _endpoint(
                                host,
                                unit,
                                owner,
                                method_node,
                                parameters_node,
                                mapping,
                                path,
                                http_method,
                            )
                        )
    return endpoints


def _deduplicate(
    endpoints: Iterable[dict[str, Any]], host: Any
) -> list[dict[str, Any]]:
    fields = (
        "uri",
        "method",
        "uri_params",
        "SrcFile",
        "SrcLine",
        "SFunction",
        "surface",
        "direction",
        "_spring_client_path_layers",
    )
    unique = {}
    for endpoint in endpoints:
        key = tuple(endpoint.get(field) for field in fields)
        if key not in unique:
            unique[key] = endpoint
            continue
        unique[key] = host.merge_endpoint_private_evidence(
            unique[key], endpoint
        )
    return [unique[key] for key in sorted(unique)]


def analyze_spring_clients(
    workspace: dict[str, Any], host: Any
) -> list[dict[str, Any]]:
    """Return outbound Spring HTTP Interface and Feign endpoint facts."""

    endpoints: list[dict[str, Any]] = []
    for fqn in sorted(workspace.get("type_declarations", {})):
        declarations = workspace["type_declarations"][fqn]
        # Duplicate source identities are not safe client containers.
        if len(declarations) != 1:
            continue
        declaration = declarations[0]
        type_info = declaration["type_info"]
        if (
            type_info["node"].type != "interface_declaration"
            or not type_info["workspace_visible"]
        ):
            continue
        endpoints.extend(
            _http_interface_endpoints(workspace, host, declaration)
        )
        endpoints.extend(_feign_endpoints(workspace, host, declaration))
    return _deduplicate(endpoints, host)


__all__ = ["analyze_spring_clients"]
