"""Bounded source-only Spring controller hierarchy recall.

The host supplies the already-built Java workspace and its public source
helpers.  This pass deliberately emits additions only: direct mappings remain
owned by ``SpringBoot_Analyzer`` while this module binds mappings declared on
source interfaces or abstract bases to one concrete, genuinely activated
controller implementation.
"""

from __future__ import annotations

from typing import Any

from noir_sbt_jax_recall import (
    JaxRecallAnalyzer,
    MAX_HIERARCHY_DEPTH,
    MethodRecord,
    TypeRecord,
    TypeRef,
)


SPRING_CONTROLLER_PACKAGES = (
    "org.springframework.stereotype",
    "org.springframework.web.bind.annotation",
)


class SpringHierarchyAnalyzer:
    """Bind Spring mapping contracts by source identity and erased signature."""

    def __init__(self, workspace: dict[str, Any], host: Any):
        self.workspace = workspace
        self.host = host
        # The neutral type/signature portion of the JAX recall model already
        # supplies the exact workspace identity, generic adaptation, hierarchy
        # bounds, and maximally-specific-interface machinery needed here.
        self.graph = JaxRecallAnalyzer(workspace, host)
        self._method_mapping_cache: dict[tuple[Any, ...], dict[str, Any] | None] = {}
        self._type_mapping_cache: dict[str, dict[str, Any] | None] = {}

    def _log(self, record: TypeRecord, message: str) -> None:
        self.host.write_log(
            "Skipped Spring hierarchy in "
            f"{record.unit['fname']} for {record.type_info['display_name']}: "
            f"{message}"
        )

    def _is_controller(self, record: TypeRecord) -> bool:
        if (
            record.kind != "class_declaration"
            or record.type_info["abstract"]
            or not record.type_info["workspace_visible"]
        ):
            return False
        for annotation in self.host.direct_annotation_records(
            record.type_info["node"]
        ):
            resolved = self.host.resolve_known_annotation(
                record.unit,
                annotation["name_node"],
                {"Controller", "RestController"},
                SPRING_CONTROLLER_PACKAGES,
            )
            if resolved is not None and (
                (resolved["name"] == "Controller"
                 and resolved["namespace"] == "org.springframework.stereotype")
                or (
                    resolved["name"] == "RestController"
                    and resolved["namespace"]
                    == "org.springframework.web.bind.annotation"
                )
            ):
                return True
        return False

    @staticmethod
    def _contract_owner(record: TypeRecord) -> bool:
        return record.kind == "interface_declaration" or (
            record.kind == "class_declaration" and record.type_info["abstract"]
        )

    def _type_accessible(self, declaration: TypeRecord, consumer: TypeRecord) -> bool:
        return self.host.workspace_type_fqn_accessible(
            self.workspace,
            consumer.unit,
            consumer.type_info["display_name"],
            declaration.fqn,
        )

    def _method_accessible(
        self, method: MethodRecord, consumer: TypeRecord
    ) -> bool:
        if "private" in method.modifiers or "static" in method.modifiers:
            return False
        if method.owner.kind == "interface_declaration":
            return True
        if "public" in method.modifiers or "protected" in method.modifiers:
            return True
        return method.owner.unit["package"] == consumer.unit["package"]

    def _implementation_usable(self, method: MethodRecord) -> bool:
        if (
            "private" in method.modifiers
            or "static" in method.modifiers
            or "abstract" in method.modifiers
        ):
            return False
        body = self.host.child_by_field(method.node, "body")
        if method.owner.kind == "interface_declaration":
            return "default" in method.modifiers and body is not None
        return body is not None

    def _decode_annotations(
        self,
        unit: dict[str, Any],
        annotations: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        lexical_owner: str,
        diagnostic_owner: str,
    ) -> dict[str, Any] | None:
        for annotation in sorted(
            annotations, key=lambda record: record["node"].start_byte
        ):
            mapping = self.host.decode_spring_mapping(
                unit["fname"],
                unit["source"],
                annotation["name_node"],
                annotation["node"],
                unit["imports"],
                unit["local_annotations"],
                unit["constant_index"],
                lexical_owner,
                diagnostic_owner,
                unit,
                self.workspace,
            )
            if mapping is not None:
                return mapping
            mapping = self.host.decode_spring_composed_mapping(
                unit["fname"],
                unit,
                annotation["name_node"],
                annotation["node"],
                lexical_owner,
                diagnostic_owner,
                self.workspace,
            )
            if mapping is not None:
                return mapping
        return None

    def _method_mapping(self, method: MethodRecord) -> dict[str, Any] | None:
        if method.id not in self._method_mapping_cache:
            owner = method.owner.type_info["display_name"]
            self._method_mapping_cache[method.id] = self._decode_annotations(
                method.owner.unit,
                method.annotations,
                owner,
                f"{owner}.{method.name}",
            )
        return self._method_mapping_cache[method.id]

    def _type_mapping(self, record: TypeRecord) -> dict[str, Any] | None:
        if record.fqn not in self._type_mapping_cache:
            owner = record.type_info["display_name"]
            self._type_mapping_cache[record.fqn] = self._decode_annotations(
                record.unit,
                self.host.direct_annotation_records(record.type_info["node"]),
                owner,
                owner,
            )
        return self._type_mapping_cache[record.fqn]

    def _interface_mapping_branches(
        self,
        state: tuple[TypeRecord, dict[str, TypeRef]],
        signature: tuple[str, tuple[str, ...]],
        consumer: TypeRecord,
        depth: int = 0,
        active: frozenset[str] = frozenset(),
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] | None = None,
    ) -> tuple[
        set[tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]], bool
    ]:
        if memo is None:
            memo = {}
        record, env = state
        memo_key = (record.fqn, self.graph._env_key(env), signature)
        if memo_key in memo:
            cached, invalid = memo[memo_key]
            return set(cached), invalid
        if depth > MAX_HIERARCHY_DEPTH or record.fqn in active:
            return set(), True
        if not self._type_accessible(record, consumer):
            return set(), True

        matches = self.graph._methods_for_signature(record, env, signature)
        if len(matches) > 1:
            return set(), True
        if matches:
            method = matches[0]
            mapping = self._method_mapping(method)
            if mapping is not None:
                if not self._method_accessible(method, consumer):
                    return set(), True
                result = ({(method.id, self.graph._env_key(env))}, False)
                memo[memo_key] = result
                return set(result[0]), result[1]

        if not record.interfaces_valid:
            return set(), True
        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]
        ] = set()
        blocked = False
        for edge in record.interfaces:
            following = self.graph._edge_state(edge, env)
            if following is None or following[0].kind != "interface_declaration":
                blocked = True
                continue
            found, invalid = self._interface_mapping_branches(
                following,
                signature,
                consumer,
                depth + 1,
                active | {record.fqn},
                memo,
            )
            candidates.update(found)
            blocked = blocked or invalid
        memo[memo_key] = (set(candidates), blocked)
        return candidates, blocked

    def _mapping_source(
        self,
        implementation: MethodRecord,
        signature: tuple[str, tuple[str, ...]],
        hierarchy: Any,
        implementation_index: int | None,
        root: TypeRecord,
    ) -> tuple[MethodRecord, dict[str, TypeRef]] | None:
        direct = self._method_mapping(implementation)
        if direct is not None:
            if (
                implementation.owner is not root
                and self._contract_owner(implementation.owner)
                and self._method_accessible(implementation, root)
            ):
                implementation_env = (
                    hierarchy.class_states[implementation_index][1]
                    if implementation_index is not None
                    else self.graph._default_env(implementation.owner)
                )
                return implementation, implementation_env
            # A direct mapping on the concrete root is emitted by the host and
            # suppresses the inherited declaration.  Mappings on an unsupported
            # owner also fail closed instead of being reinterpreted.
            return None

        start = (
            implementation_index + 1
            if implementation_index is not None
            else 0
        )
        for record, env in hierarchy.class_states[start:]:
            matches = self.graph._methods_for_signature(record, env, signature)
            if len(matches) > 1:
                return None
            if not matches:
                continue
            method = matches[0]
            mapping = self._method_mapping(method)
            if mapping is None:
                continue
            if (
                not self._contract_owner(record)
                or not self._type_accessible(record, root)
                or not self._method_accessible(method, root)
            ):
                return None
            return method, env

        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]
        ] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self._interface_mapping_branches(
                interface_root, signature, root, memo=memo
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self.graph._maximally_specific_candidates(
            candidates
        )
        blocked = blocked or specificity_invalid
        if blocked or len({candidate[0] for candidate in candidates}) != 1:
            return None
        return self.graph._method_from_candidate(next(iter(candidates)))

    def _all_signatures(
        self, hierarchy: Any
    ) -> tuple[set[tuple[str, tuple[str, ...]]], set[str]]:
        signatures: set[tuple[str, tuple[str, ...]]] = set()
        unresolved_names: set[str] = set()

        def add_methods(record: TypeRecord, env: dict[str, TypeRef]) -> None:
            for method in record.methods:
                signature = self.graph._signature(method, env)
                if signature is None:
                    unresolved_names.add(method.name)
                else:
                    signatures.add(signature)

        for record, env in hierarchy.class_states:
            add_methods(record, env)

        visited: set[tuple[str, tuple[tuple[str, TypeRef], ...]]] = set()

        def visit(
            state: tuple[TypeRecord, dict[str, TypeRef]], depth: int = 0
        ) -> None:
            record, env = state
            state_key = (record.fqn, self.graph._env_key(env))
            if state_key in visited or depth > MAX_HIERARCHY_DEPTH:
                return
            visited.add(state_key)
            add_methods(record, env)
            for edge in record.interfaces:
                following = self.graph._edge_state(edge, env)
                if following is not None:
                    visit(following, depth + 1)

        for interface_root in hierarchy.interface_roots:
            visit(interface_root)
        return signatures, unresolved_names

    def _implementation(
        self,
        signature: tuple[str, tuple[str, ...]],
        hierarchy: Any,
    ) -> tuple[MethodRecord, dict[str, TypeRef], int | None] | None:
        for index, (record, env) in enumerate(hierarchy.class_states):
            matches = self.graph._methods_for_signature(record, env, signature)
            if not matches:
                continue
            if len(matches) != 1 or not self._implementation_usable(matches[0]):
                return None
            return matches[0], env, index

        candidates: set[
            tuple[tuple[Any, ...], tuple[tuple[str, TypeRef], ...]]
        ] = set()
        blocked = False
        memo: dict[tuple[Any, ...], tuple[set[tuple[Any, ...]], bool]] = {}
        for interface_root in hierarchy.interface_roots:
            found, invalid = self.graph._interface_branches(
                interface_root, signature, "default", memo=memo
            )
            candidates.update(found)
            blocked = blocked or invalid
        candidates, specificity_invalid = self.graph._maximally_specific_candidates(
            candidates
        )
        if blocked or specificity_invalid or len(
            {candidate[0] for candidate in candidates}
        ) != 1:
            return None
        resolved = self.graph._method_from_candidate(next(iter(candidates)))
        if resolved is None or not self._implementation_usable(resolved[0]):
            return None
        return resolved[0], resolved[1], None

    def _mapping_conditions(
        self, mapping: dict[str, Any] | None
    ) -> tuple[list[str], list[str]] | None:
        if mapping is None:
            return [""], []
        if not mapping["valid"]:
            return None
        return list(mapping["paths"]), list(mapping["methods"])

    def _controller_endpoints(self, root: TypeRecord) -> list[dict[str, Any]]:
        root_env = self.graph._default_env(root)
        hierarchy = self.graph._hierarchy(root, root_env)
        if not hierarchy.complete:
            self._log(root, "incomplete or ambiguous type hierarchy")
            return []

        controller_conditions = self._mapping_conditions(self._type_mapping(root))
        if controller_conditions is None:
            return []
        controller_paths, controller_methods = controller_conditions
        signatures, unresolved_names = self._all_signatures(hierarchy)
        endpoints: list[dict[str, Any]] = []

        for signature in sorted(signatures):
            if signature[0] in unresolved_names:
                continue
            implementation_state = self._implementation(signature, hierarchy)
            if implementation_state is None:
                continue
            implementation, _implementation_env, implementation_index = (
                implementation_state
            )
            source_state = self._mapping_source(
                implementation,
                signature,
                hierarchy,
                implementation_index,
                root,
            )
            if source_state is None:
                continue
            source, _source_env = source_state
            mapping = self._method_mapping(source)
            if mapping is None or not mapping["valid"]:
                continue
            contract_conditions = self._mapping_conditions(
                self._type_mapping(source.owner)
            )
            if contract_conditions is None:
                continue
            contract_paths, contract_methods = contract_conditions
            effective_methods = self.host.combine_request_method_conditions(
                controller_methods, contract_methods
            )
            effective_methods = self.host.combine_request_method_conditions(
                effective_methods, mapping["methods"]
            ) or ["ANY"]
            owner_name = (
                f"{implementation.owner.type_info['display_name']}."
                f"{implementation.name}"
            )
            parameters = self.host.get_callable_parameters_as_is(
                implementation.owner.unit["source"],
                implementation.parameters_node,
            )
            for controller_path in controller_paths:
                for contract_path in contract_paths:
                    base_path = self.host.combine_paths(
                        controller_path, contract_path
                    )
                    for method_path in mapping["paths"]:
                        uri = self.host.combine_paths(base_path, method_path)
                        for http_method in effective_methods:
                            endpoint = {
                                "uri": uri,
                                "method": http_method,
                                "uri_params": parameters,
                                "SrcFile": implementation.owner.unit["fname"],
                                "SrcLine": implementation.node.start_point.row + 1,
                                "SFunction": owner_name,
                                "RouteSrcFile": source.owner.unit["fname"],
                                "RouteSrcLine": mapping["annotation_node"].start_point.row + 1,
                                "HandlerSrcFile": implementation.owner.unit["fname"],
                                "HandlerSrcLine": implementation.node.start_point.row + 1,
                                "ProjectSrcFile": root.unit["fname"],
                                "technology": "spring",
                                "protocol": "http",
                                "surface": "server",
                                "direction": "inbound",
                                self.host.METHOD_ANNOTATION_EVIDENCE_KEY: (
                                    self.host.method_annotation_evidence_from_mapping(
                                        mapping,
                                        annotation_source_file=source.owner.unit[
                                            "fname"
                                        ],
                                        endpoint_source_file=implementation.owner.unit[
                                            "fname"
                                        ],
                                    )
                                    if source.id == implementation.id
                                    else ()
                                ),
                                self.host.REPRESENTED_TARGETS_KEY: (
                                    self.host.represented_target_evidence(
                                        implementation.owner.unit["fname"],
                                        "method",
                                        implementation.node,
                                    )
                                ),
                            }
                            endpoints.append(endpoint)
                            self.host.debug_log(endpoint)
        return endpoints

    def analyze(self) -> list[dict[str, Any]]:
        endpoints: list[dict[str, Any]] = []
        for fqn in sorted(self.graph.types):
            record = self.graph.types[fqn]
            if self._is_controller(record):
                endpoints.extend(self._controller_endpoints(record))
        return endpoints


def analyze_spring_hierarchy(
    workspace: dict[str, Any], host: Any
) -> list[dict[str, Any]]:
    """Return signature-bound Spring controller hierarchy additions."""

    return SpringHierarchyAnalyzer(workspace, host).analyze()


__all__ = ["analyze_spring_hierarchy"]
