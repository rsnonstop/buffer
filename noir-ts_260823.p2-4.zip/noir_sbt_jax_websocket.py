"""Bounded Javax/Jakarta WebSocket handshake endpoint extraction.

The module is intentionally host-parameterized and import-cycle free.  It
consumes the Java workspace already built by :mod:`noir_sbt`, reusing that
workspace's annotation provenance and guarded String-expression resolver.
"""

from __future__ import annotations

from typing import Any


SERVER_ENDPOINT_PACKAGES = (
    "jakarta.websocket.server",
    "javax.websocket.server",
)


def _log(host: Any, unit: dict[str, Any], owner: str, message: str) -> None:
    host.write_log(
        f"Skipped WebSocket endpoint in {unit['fname']} for {owner}: {message}"
    )


def _direct_constructors(host: Any, type_node: Any) -> list[Any]:
    body = host.child_by_field(type_node, "body")
    if body is None:
        return []
    return [
        child for child in body.named_children if child.type == "constructor_declaration"
    ]


def _has_public_zero_arg_constructor(host: Any, type_node: Any) -> bool:
    constructors = _direct_constructors(host, type_node)
    if not constructors:
        return True
    for constructor in constructors:
        if "public" not in host.declaration_modifier_names(constructor):
            continue
        parameters = host.child_by_field(constructor, "parameters")
        if parameters is not None and not any(
            child.type in {"formal_parameter", "spread_parameter"}
            for child in parameters.named_children
        ):
            return True
    return False


def _is_zero_component_record(host: Any, type_node: Any) -> bool:
    parameters = host.child_by_field(type_node, "parameters")
    return parameters is not None and not any(
        child.type in {"formal_parameter", "spread_parameter"}
        for child in parameters.named_children
    )


def _eligible_type(host: Any, unit: dict[str, Any], type_info: dict[str, Any]) -> str | None:
    type_node = type_info["node"]
    owner = type_info["display_name"]
    modifiers = host.declaration_modifier_names(type_node)
    if not type_info.get("workspace_visible", False):
        return "type is not workspace-visible"
    if "public" not in modifiers:
        return "type is not public"
    outer = host.nearest_enclosing_type(type_node)
    while outer is not None:
        if "public" not in host.declaration_modifier_names(outer):
            return "enclosing type is not public"
        outer = host.nearest_enclosing_type(outer)
    if type_node.type == "class_declaration":
        if host.type_is_abstract(unit["source"], type_node):
            return "type is abstract"
        outer = host.nearest_enclosing_type(type_node)
        if outer is not None and "static" not in modifiers:
            return "nested class is not static"
        if not _has_public_zero_arg_constructor(host, type_node):
            return "class has no public zero-argument constructor"
        return None
    if type_node.type == "record_declaration":
        if not _is_zero_component_record(host, type_node):
            return "record has components and no zero-argument canonical constructor"
        return None
    return f"unsupported annotated {type_node.type}"


def _server_endpoint_record(
    host: Any,
    unit: dict[str, Any],
    type_node: Any,
) -> tuple[dict[str, Any] | None, str | None]:
    genuine = []
    for record in host.direct_annotation_records(type_node):
        resolved = host.resolve_known_annotation(
            unit,
            record["name_node"],
            {"ServerEndpoint"},
            SERVER_ENDPOINT_PACKAGES,
        )
        if resolved is not None:
            genuine.append((record, resolved))
    if not genuine:
        return None, None
    if len(genuine) != 1:
        return None, "multiple genuine ServerEndpoint annotations"
    record, resolved = genuine[0]
    return {**record, **resolved}, None


def _server_endpoint_value_node(host: Any, annotation_node: Any) -> tuple[Any, str | None]:
    """Return the endpoint path while ignoring unrelated annotation options.

    ``ServerEndpoint`` also accepts encoders, decoders, subprotocols, and a
    configurator.  Those options do not change handshake-route identity, so
    rejecting them would lose an otherwise statically identifiable endpoint.
    """

    positional, named = host.get_annotation_arguments(annotation_node)
    if positional and "value" in named:
        return None, "both positional and named values"
    if "value" in named:
        return named["value"], None
    if len(positional) == 1:
        return positional[0], None
    if not positional:
        return None, "missing value"
    return None, "multiple positional values"


def analyze_jax_websocket(
    workspace: dict[str, Any],
    host: Any,
) -> list[dict[str, Any]]:
    """Return one additions-only handshake row per valid source endpoint."""

    endpoints: list[dict[str, Any]] = []
    for fname in sorted(workspace.get("units", {})):
        unit = workspace["units"][fname]
        for type_key in sorted(unit.get("type_infos", {})):
            type_info = unit["type_infos"][type_key]
            type_node = type_info["node"]
            record, annotation_error = _server_endpoint_record(
                host, unit, type_node
            )
            if record is None:
                if annotation_error:
                    _log(host, unit, type_info["display_name"], annotation_error)
                continue

            owner = type_info["display_name"]
            owner_fqn = host.qualified_type_name(unit, type_info)
            declarations = workspace.get("type_declarations", {}).get(
                owner_fqn, []
            )
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                _log(host, unit, owner, "duplicate or ambiguous source type identity")
                continue
            eligibility_error = _eligible_type(host, unit, type_info)
            if eligibility_error:
                _log(host, unit, owner, eligibility_error)
                continue

            value_node, value_error = _server_endpoint_value_node(
                host, record["node"]
            )
            if value_error:
                _log(host, unit, owner, f"invalid annotation value: {value_error}")
                continue
            value = host.resolve_workspace_string_expression(
                unit,
                value_node,
                workspace,
                owner,
            )
            if value is None:
                expression = host.node_text(unit["source"], value_node).strip()
                _log(host, unit, owner, f"unresolved path: {expression}")
                continue
            value = value.strip()
            if not value or "?" in value or "#" in value:
                _log(host, unit, owner, "path is empty or contains query/fragment syntax")
                continue
            uri = host.normalize_spring_path(value)
            endpoint = {
                "uri": uri,
                "method": "GET",
                "protocol": "ws",
                "surface": "websocket",
                "direction": "inbound",
                "technology": "jax-websocket",
                "uri_params": "",
                "SrcFile": unit["fname"],
                "SrcLine": record["node"].start_point.row + 1,
                "SFunction": owner,
                "RouteSrcFile": unit["fname"],
                "RouteSrcLine": record["node"].start_point.row + 1,
                "HandlerSrcFile": unit["fname"],
                "HandlerSrcLine": type_node.start_point.row + 1,
                host.METHOD_ANNOTATION_EVIDENCE_KEY: (),
                host.REPRESENTED_TARGETS_KEY: host.represented_target_evidence(
                    unit["fname"], "type", type_node
                ),
            }
            endpoints.append(endpoint)
            host.debug_log(endpoint)
    return endpoints
