"""Project configuration and static-resource recall for :mod:`noir_sbt`.

The host analyzer passes its Java workspace and helper module into this file,
keeping the extension acyclic and reusing the host's exact Java name and
String-constant resolution.  The supported source/configuration shapes are
intentionally bounded:

* ``application.properties``, ``application.yml``, and ``application.yaml``
  at the three documented project locations;
* mapping-only YAML with String/integer leaves;
* nested Spring ``${key:default}`` path placeholders; and
* direct ``WebMvcConfigurer.addResourceHandlers`` registrations on a genuine
  ``ResourceHandlerRegistry`` parameter.

Unsupported configuration and Java control/data-flow shapes fail closed.  No
dependency metadata, runtime bean graph, profile activation, or physical
resource enumeration is attempted.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
from typing import Any, Callable, Iterable, Mapping


WEB_MVC_CONFIG_PACKAGE = "org.springframework.web.servlet.config.annotation"
CONFIGURATION_FILENAMES = (
    "application.properties",
    "application.yml",
    "application.yaml",
)
MAX_PLACEHOLDER_SUBSTITUTIONS = 100
MAX_CONFIGURED_PATH_LENGTH = 8192
ELIGIBLE_HTTP_SURFACES = frozenset(
    {"server", "proxy", "gateway", "resource", "static-handler"}
)
ELIGIBLE_WS_SURFACES = frozenset({"websocket-handshake", "message"})

_PLACEHOLDER = re.compile(r"\$\{([^{}]+)\}")
_INTEGER = re.compile(r"[+-]?[0-9]+")
_FLOATISH = re.compile(
    r"[+-]?(?:[0-9]+\.[0-9]*|[0-9]*\.[0-9]+)(?:[eE][+-]?[0-9]+)?"
)
_PLAIN_YAML_KEY = re.compile(r"[A-Za-z0-9_.-]+")
_UNSUPPORTED_YAML_SCALARS = frozenset(
    {"null", "~", "true", "false", ".nan", ".inf", "+.inf", "-.inf"}
)


@dataclass(frozen=True)
class SpringProjectConfiguration:
    """Resolved bounded configuration for one inferred source project."""

    root: str
    values: Mapping[str, str]
    base_path: str
    loaded_files: tuple[str, ...]


@dataclass(frozen=True)
class SpringConfiguration:
    """Project/configuration ownership for one analyzer invocation."""

    analysis_root: str
    projects: Mapping[str, SpringProjectConfiguration]
    source_projects: Mapping[str, str | None]


def _canonical_path(path: str | Path) -> str:
    return str(Path(path).expanduser().resolve(strict=False))


def _log(host: Any, message: str) -> None:
    if host is not None and callable(getattr(host, "write_log", None)):
        host.write_log(f"Skipped Spring configuration/resource {message}")


def _infer_project_root(source_file: str, analysis_root: Path) -> Path | None:
    """Infer one project root, rejecting repeated/ambiguous source markers."""

    source_path = Path(source_file).expanduser().resolve(strict=False)
    try:
        source_path.relative_to(analysis_root)
    except ValueError:
        return None

    parts = source_path.parts
    main_java_cuts = [
        index
        for index in range(max(0, len(parts) - 2))
        if parts[index : index + 3] == ("src", "main", "java")
    ]
    if main_java_cuts:
        if len(main_java_cuts) != 1:
            return None
        cut = main_java_cuts[0]
    else:
        src_cuts = [index for index, part in enumerate(parts[:-1]) if part == "src"]
        if len(src_cuts) > 1:
            return None
        if not src_cuts:
            return analysis_root
        cut = src_cuts[0]

    return Path(*parts[:cut]).resolve(strict=False)


def _parse_properties(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", "!")):
            continue
        separators = [
            index for index in (stripped.find("="), stripped.find(":")) if index >= 0
        ]
        if not separators:
            continue
        separator = min(separators)
        key = stripped[:separator].strip()
        if key:
            values[key] = stripped[separator + 1 :].strip()
    return values


def _strip_yaml_comment(line: str) -> str | None:
    quote: str | None = None
    escaped = False
    for index, character in enumerate(line):
        if quote == '"':
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if quote == "'":
            if character == quote:
                if index + 1 < len(line) and line[index + 1] == quote:
                    continue
                quote = None
            continue
        if character in {'"', "'"}:
            quote = character
        elif character == "#" and (index == 0 or line[index - 1].isspace()):
            return line[:index].rstrip()
    return None if quote is not None else line.rstrip()


def _split_yaml_mapping(line: str) -> tuple[str, str] | None:
    quote: str | None = None
    escaped = False
    for index, character in enumerate(line):
        if quote == '"':
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if quote == "'":
            if character == quote:
                if index + 1 < len(line) and line[index + 1] == quote:
                    continue
                quote = None
            continue
        if character in {'"', "'"}:
            quote = character
        elif character == ":":
            return line[:index].strip(), line[index + 1 :].strip()
    return None


def _yaml_string(token: str, *, key: bool = False) -> str | None:
    if token.startswith('"'):
        if not token.endswith('"') or len(token) < 2:
            return None
        try:
            value = json.loads(token)
        except (json.JSONDecodeError, TypeError):
            return None
        return value if isinstance(value, str) else None
    if token.startswith("'"):
        if not token.endswith("'") or len(token) < 2:
            return None
        return token[1:-1].replace("''", "'")
    if key:
        return token if _PLAIN_YAML_KEY.fullmatch(token) else None
    lowered = token.lower()
    if (
        not token
        or lowered in _UNSUPPORTED_YAML_SCALARS
        or _FLOATISH.fullmatch(token)
        or token.startswith(("[", "{", "&", "*", "!", "|", ">"))
    ):
        return None
    return token


def _parse_mapping_yaml(text: str) -> dict[str, str] | None:
    """Parse only the mapping/scalar subset used by Spring path settings."""

    values: dict[str, str] = {}
    stack: list[tuple[int, str]] = []
    scalar_paths: set[str] = set()
    saw_content = False

    for raw_line in text.splitlines():
        if "\t" in raw_line[: len(raw_line) - len(raw_line.lstrip())]:
            return None
        without_comment = _strip_yaml_comment(raw_line)
        if without_comment is None:
            return None
        if not without_comment.strip():
            continue
        stripped = without_comment.strip()
        if stripped in {"---", "..."} or stripped.startswith("-"):
            return None
        saw_content = True
        indent = len(without_comment) - len(without_comment.lstrip(" "))
        pair = _split_yaml_mapping(stripped)
        if pair is None:
            return None
        raw_key, raw_value = pair
        key = _yaml_string(raw_key, key=True)
        if key is None:
            return None

        while stack and indent <= stack[-1][0]:
            stack.pop()
        if stack and indent <= stack[-1][0]:
            return None
        prefix = ".".join(part for _level, part in stack)
        path = f"{prefix}.{key}" if prefix else key
        if any(path == scalar or path.startswith(f"{scalar}.") for scalar in scalar_paths):
            return None

        if not raw_value:
            stack.append((indent, key))
            continue
        if "&" in raw_value or raw_value.startswith("*"):
            return None
        value = _yaml_string(raw_value)
        if value is None:
            if _INTEGER.fullmatch(raw_value):
                value = raw_value
            else:
                # Unsupported YAML scalar kinds are ignored rather than
                # coerced into path strings.
                continue
        values[path] = value
        scalar_paths.add(path)

    if not saw_content:
        return {}
    if any(
        key == "spring.config.activate.on-profile"
        or key == "spring.profiles"
        or key.startswith("spring.profiles.")
        for key in values
    ):
        return None
    return values


def _normalize_optional_path(path: str | None) -> str:
    if path is None:
        return ""
    trimmed = path.strip()
    if not trimmed or trimmed == "/":
        return ""
    if trimmed.lower().startswith(("http://", "https://")):
        return trimmed
    return trimmed if trimmed.startswith("/") else f"/{trimmed}"


def _read_project_configuration(root: Path, host: Any) -> SpringProjectConfiguration:
    values: dict[str, str] = {}
    loaded_files: list[str] = []
    resource_dirs = (root / "src/main/resources", root / "resources", root)
    for directory in dict.fromkeys(resource_dirs):
        for filename in CONFIGURATION_FILENAMES:
            path = directory / filename
            if not path.is_file():
                continue
            try:
                text = path.read_text(encoding="utf8")
            except (OSError, UnicodeError):
                _log(host, f"unreadable file {path}")
                continue
            if filename.endswith(".properties"):
                parsed = _parse_properties(text)
            else:
                parsed = _parse_mapping_yaml(text)
                if parsed is None:
                    _log(host, f"unsupported or malformed YAML file {path}")
                    continue
            values.update(parsed)
            loaded_files.append(str(path))

    servlet = _normalize_optional_path(values.get("server.servlet.context-path"))
    webflux = _normalize_optional_path(values.get("spring.webflux.base-path"))
    return SpringProjectConfiguration(
        root=str(root),
        values=dict(values),
        base_path=webflux or servlet,
        loaded_files=tuple(loaded_files),
    )


def build_spring_configuration(
    workspace: Mapping[str, Any], analysis_root: str | Path, host: Any = None
) -> SpringConfiguration:
    """Load bounded, project-owned Spring path configuration for a workspace."""

    root = Path(analysis_root).expanduser().resolve(strict=False)
    source_projects: dict[str, str | None] = {}
    project_roots: set[str] = set()
    for fname in sorted(workspace.get("units", {})):
        project_root = _infer_project_root(fname, root)
        canonical_file = _canonical_path(fname)
        if project_root is None:
            source_projects[canonical_file] = None
            _log(host, f"ambiguous project ownership for {fname}")
            continue
        canonical_root = str(project_root)
        source_projects[canonical_file] = canonical_root
        project_roots.add(canonical_root)

    projects = {
        project_root: _read_project_configuration(Path(project_root), host)
        for project_root in sorted(project_roots)
    }
    return SpringConfiguration(str(root), projects, source_projects)


def _resolve_placeholders(path: str, values: Mapping[str, str]) -> str | None:
    result = path
    for _iteration in range(MAX_PLACEHOLDER_SUBSTITUTIONS):
        match = _PLACEHOLDER.search(result)
        if match is None:
            return result if "${" not in result else None
        expression = match.group(1)
        key, separator, default = expression.partition(":")
        if not key:
            return None
        value = values.get(key, default if separator else "")
        result = result[: match.start()] + value + result[match.end() :]
        if len(result) > MAX_CONFIGURED_PATH_LENGTH:
            return None
    return result if _PLACEHOLDER.search(result) is None and "${" not in result else None


def _collapse_path_slashes(path: str) -> str:
    """Collapse repeated path separators without damaging a URL authority."""

    return re.sub(r"(?<!:)/{2,}", "/", path)


def _join_paths(host: Any, base: str, path: str) -> str:
    if host is not None and callable(getattr(host, "combine_paths", None)):
        return host.combine_paths(base, path)
    if not base and not path:
        return "/"
    if not base:
        return path
    if not path:
        return base
    return f"{base.rstrip('/')}/{path.lstrip('/')}"


def apply_spring_path(
    path: str,
    source_file: str,
    configuration: SpringConfiguration,
    host: Any = None,
    *,
    technology: str = "spring",
    protocol: str = "http",
    surface: str = "server",
    direction: str = "inbound",
) -> str | None:
    """Apply one source project's prefix/placeholders to one eligible path.

    The helper is intentionally public so the Gateway analyzer can use the
    same project/configuration layer when it constructs raw proxy facts.
    """

    eligible_http = (
        protocol == "http"
        and direction == "inbound"
        and surface in ELIGIBLE_HTTP_SURFACES
    )
    eligible_client = (
        protocol == "http" and direction == "outbound" and surface == "client"
    )
    eligible_ws = (
        protocol == "ws"
        and direction == "inbound"
        and surface in ELIGIBLE_WS_SURFACES
    )
    if technology != "spring" or not (
        eligible_http or eligible_client or eligible_ws
    ):
        return path
    project_root = configuration.source_projects.get(_canonical_path(source_file))
    project = configuration.projects.get(project_root) if project_root else None
    values: Mapping[str, str] = project.values if project is not None else {}
    # Spring's deployment base applies to HTTP surfaces and the HTTP upgrade
    # path used by a STOMP/WebSocket handshake. Message destinations are not
    # servlet paths, but still consume the owning project's placeholders.
    base_path = (
        project.base_path
        if project is not None
        and (eligible_http or surface == "websocket-handshake")
        else ""
    )
    # Resolve before path normalization.  A client URL may be rooted in a
    # placeholder (for example ``${remote.base}/items``); adding ``/`` first
    # would corrupt an absolute value into ``/https://...``.
    resolved_path = _resolve_placeholders(path, values)
    resolved_base = _resolve_placeholders(base_path, values)
    if resolved_path is None or resolved_base is None:
        return None
    normalized = _normalize_optional_path(resolved_path)
    normalized_base = _normalize_optional_path(resolved_base)
    joined = _join_paths(host, normalized_base, normalized)
    return _collapse_path_slashes(joined)


def _apply_spring_client_paths(
    path_layers: Iterable[str],
    source_file: str,
    configuration: SpringConfiguration,
    host: Any = None,
) -> str | None:
    """Resolve HTTP-interface layers before deciding absolute precedence."""

    project_root = configuration.source_projects.get(_canonical_path(source_file))
    project = configuration.projects.get(project_root) if project_root else None
    values: Mapping[str, str] = project.values if project is not None else {}
    combined = ""
    for path_layer in path_layers:
        resolved = _resolve_placeholders(path_layer, values)
        if resolved is None:
            return None
        normalized = _normalize_optional_path(resolved)
        # Any inner absolute URL is complete and replaces all lexical outer
        # prefixes, including when its scheme came from configuration.
        combined = (
            normalized
            if normalized.lower().startswith(("http://", "https://"))
            else _join_paths(host, combined, normalized)
        )
    return _collapse_path_slashes(combined)


def spring_path_applicator(
    configuration: SpringConfiguration, host: Any = None
) -> Callable[..., str | None]:
    """Return a configuration-bound path callback for sibling analyzers.

    Callers may provide ``source_file`` directly or pass the shared Java
    ``unit`` mapping used by the Gateway analyzer.  Diagnostic-only context
    such as ``owner_name`` is accepted and ignored.
    """

    def apply(
        path: str,
        source_file: str | None = None,
        **context: Any,
    ) -> str | None:
        unit = context.pop("unit", None)
        context.pop("owner_name", None)
        if source_file is None and isinstance(unit, Mapping):
            source_file = unit.get("fname")
        if not isinstance(source_file, str) or not source_file:
            return None
        metadata = {
            key: context[key]
            for key in ("technology", "protocol", "surface", "direction")
            if key in context
        }
        return apply_spring_path(
            path, source_file, configuration, host, **metadata
        )

    return apply


def apply_spring_configuration(
    endpoints: Iterable[Mapping[str, Any]],
    configuration: SpringConfiguration,
    host: Any = None,
) -> list[dict[str, Any]]:
    """Return copied Spring facts with project configuration applied once."""

    configured: list[dict[str, Any]] = []
    for original in endpoints:
        endpoint = dict(original)
        if endpoint.get("_spring_configuration_applied"):
            configured.append(endpoint)
            continue
        technology = endpoint.get("technology", "spring")
        protocol = endpoint.get("protocol", "http")
        surface = endpoint.get("surface", "server")
        direction = endpoint.get("direction", "inbound")
        if technology != "spring":
            configured.append(endpoint)
            continue
        source_file = str(
            endpoint.get("ProjectSrcFile", endpoint.get("SrcFile", ""))
        )
        client_path_layers = endpoint.pop("_spring_client_path_layers", None)
        if (
            protocol == "http"
            and surface == "client"
            and direction == "outbound"
            and client_path_layers is not None
        ):
            resolved = _apply_spring_client_paths(
                (str(layer) for layer in client_path_layers),
                source_file,
                configuration,
                host,
            )
        else:
            resolved = apply_spring_path(
                str(endpoint.get("uri", "")),
                source_file,
                configuration,
                host,
                technology=technology,
                protocol=protocol,
                surface=surface,
                direction=direction,
            )
        if resolved is None:
            _log(
                host,
                "malformed or exhausted placeholder path in "
                f"{endpoint.get('SrcFile', '')} for {endpoint.get('SFunction', '')}",
            )
            continue
        endpoint.update(
            {
                "uri": resolved,
                "technology": technology,
                "protocol": protocol,
                "surface": surface,
                "direction": direction,
                "_spring_configuration_applied": True,
            }
        )
        configured.append(endpoint)
    return configured


def _text(unit: Mapping[str, Any], node: Any) -> str:
    return unit["source"][node.start_byte : node.end_byte].decode("utf8")


def _walk(node: Any) -> Iterable[Any]:
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


def _field(host: Any, node: Any, name: str) -> Any:
    return host.child_by_field(node, name)


def _raw_type_node(node: Any) -> Any:
    current = node
    for _depth in range(16):
        if current is None:
            return None
        if current.type == "generic_type":
            children = list(current.named_children)
            current = children[0] if children else None
            continue
        if current.type == "annotated_type":
            candidates = [
                child for child in current.named_children if child.type != "annotation"
            ]
            current = candidates[-1] if len(candidates) == 1 else None
            continue
        return current
    return None


def _known_type(
    host: Any, unit: Mapping[str, Any], node: Any, simple_name: str
) -> bool:
    raw = _raw_type_node(node)
    return bool(
        raw is not None
        and host.resolve_known_type(
            unit,
            _text(unit, raw),
            simple_name,
            (WEB_MVC_CONFIG_PACKAGE,),
            raw,
        )
        == WEB_MVC_CONFIG_PACKAGE
    )


def _direct_interface_types(host: Any, type_node: Any) -> list[Any]:
    interfaces = _field(host, type_node, "interfaces")
    if interfaces is None:
        return []
    children = list(interfaces.named_children)
    if len(children) == 1 and children[0].type == "type_list":
        return list(children[0].named_children)
    return children


def _resource_method_facts(
    workspace: Mapping[str, Any], host: Any
) -> Iterable[tuple[Mapping[str, Any], Mapping[str, Any], Any, Any, str, Any]]:
    for fname in sorted(workspace.get("units", {})):
        unit = workspace["units"][fname]
        for type_info in sorted(
            unit["type_infos"].values(), key=lambda info: info["node"].start_byte
        ):
            type_node = type_info["node"]
            if (
                type_node.type != "class_declaration"
                or type_info["abstract"]
                or not type_info["workspace_visible"]
            ):
                continue
            owner_fqn = host.qualified_type_name(unit, type_info)
            declarations = workspace["type_declarations"].get(owner_fqn, [])
            if not (
                len(declarations) == 1
                and declarations[0]["unit"] is unit
                and declarations[0]["type_info"] is type_info
            ):
                continue
            genuine_interfaces = [
                node
                for node in _direct_interface_types(host, type_node)
                if _known_type(host, unit, node, "WebMvcConfigurer")
            ]
            if len(genuine_interfaces) != 1:
                continue
            body = _field(host, type_node, "body")
            if body is None:
                continue
            for method in body.named_children:
                if method.type != "method_declaration":
                    continue
                name_node = _field(host, method, "name")
                return_type = _field(host, method, "type")
                parameters = _field(host, method, "parameters")
                method_body = _field(host, method, "body")
                if (
                    None in (name_node, return_type, parameters, method_body)
                    or _text(unit, name_node) != "addResourceHandlers"
                    or _text(unit, return_type).strip() != "void"
                    or "public" not in host.declaration_modifier_names(method)
                    or "static" in host.declaration_modifier_names(method)
                ):
                    continue
                formals = [
                    child
                    for child in parameters.named_children
                    if child.type == "formal_parameter"
                ]
                if len(formals) != 1 or len(parameters.named_children) != 1:
                    continue
                parameter_type = _field(host, formals[0], "type")
                parameter_name = _field(host, formals[0], "name")
                if (
                    parameter_type is None
                    or parameter_name is None
                    or not _known_type(
                        host, unit, parameter_type, "ResourceHandlerRegistry"
                    )
                ):
                    continue
                yield (
                    unit,
                    type_info,
                    method,
                    method_body,
                    _text(unit, parameter_name),
                    parameters,
                )


def _invocation_name(host: Any, unit: Mapping[str, Any], invocation: Any) -> str:
    name = _field(host, invocation, "name")
    return _text(unit, name) if name is not None else ""


def _direct_registration_chain(host: Any, invocation: Any, body: Any) -> bool:
    current = invocation
    while getattr(current, "parent", None) is not None:
        parent = current.parent
        if parent.type != "method_invocation":
            break
        object_node = _field(host, parent, "object")
        if object_node is None or (
            object_node.start_byte,
            object_node.end_byte,
        ) != (current.start_byte, current.end_byte):
            break
        current = parent
    statement = getattr(current, "parent", None)
    return bool(
        statement is not None
        and statement.type == "expression_statement"
        and getattr(statement, "parent", None) is not None
        and host.tree_node_key(statement.parent) == host.tree_node_key(body)
    )


def _registry_is_mutated(
    host: Any, unit: Mapping[str, Any], body: Any, registry_name: str
) -> bool:
    for node in _walk(body):
        if node.type == "assignment_expression":
            left = _field(host, node, "left")
            if (
                left is not None
                and left.type == "identifier"
                and _text(unit, left) == registry_name
            ):
                return True
        if node.type == "update_expression" and any(
            child.type == "identifier" and _text(unit, child) == registry_name
            for child in node.named_children
        ):
            return True
    return False


def _deduplicate(
    endpoints: Iterable[dict[str, Any]], host: Any
) -> list[dict[str, Any]]:
    unique: dict[tuple[Any, ...], dict[str, Any]] = {}
    for endpoint in endpoints:
        key = tuple(
            endpoint[field]
            for field in (
                "uri",
                "method",
                "uri_params",
                "SrcFile",
                "SrcLine",
                "SFunction",
            )
        )
        if key in unique:
            endpoint = host.merge_endpoint_private_evidence(
                unique[key], endpoint
            )
        unique[key] = endpoint
    return [unique[key] for key in sorted(unique)]


def analyze_spring_resource_handlers(
    workspace: Mapping[str, Any], host: Any
) -> list[dict[str, Any]]:
    """Return provenance-bound direct Spring MVC static-handler patterns."""

    endpoints: list[dict[str, Any]] = []
    for unit, owner_info, method, body, registry_name, _parameters in _resource_method_facts(
        workspace, host
    ):
        owner = owner_info["display_name"]
        function = f"{owner}.addResourceHandlers"
        if _registry_is_mutated(host, unit, body, registry_name):
            _log(host, f"mutated ResourceHandlerRegistry in {unit['fname']} for {function}")
            continue
        candidates = []
        for invocation in _walk(body):
            if (
                invocation.type != "method_invocation"
                or _invocation_name(host, unit, invocation) != "addResourceHandler"
            ):
                continue
            receiver = _field(host, invocation, "object")
            if (
                receiver is None
                or receiver.type != "identifier"
                or _text(unit, receiver) != registry_name
            ):
                continue
            candidates.append(invocation)

        for invocation in candidates:
            if not _direct_registration_chain(host, invocation, body):
                _log(host, f"nested resource registration in {unit['fname']} for {function}")
                continue
            arguments = _field(host, invocation, "arguments")
            argument_nodes = list(arguments.named_children) if arguments is not None else []
            if not argument_nodes:
                _log(host, f"resource registration without paths in {unit['fname']} for {function}")
                continue
            for argument in argument_nodes:
                value = host.resolve_workspace_string_expression(
                    unit, argument, workspace, owner
                )
                if value is None:
                    _log(
                        host,
                        "unresolved resource-handler path in "
                        f"{unit['fname']} for {function}: {_text(unit, argument).strip()}",
                    )
                    continue
                path = host.combine_paths("", host.normalize_spring_path(value))
                endpoint = {
                    "uri": path,
                    "method": "GET",
                    "uri_params": "",
                    "SrcFile": unit["fname"],
                    "SrcLine": invocation.start_point.row + 1,
                    "SFunction": function,
                    "RouteSrcFile": unit["fname"],
                    "RouteSrcLine": invocation.start_point.row + 1,
                    "HandlerSrcFile": unit["fname"],
                    "HandlerSrcLine": method.start_point.row + 1,
                    "technology": "spring",
                    "protocol": "http",
                    "surface": "static-handler",
                    "direction": "inbound",
                    host.METHOD_ANNOTATION_EVIDENCE_KEY: (),
                    host.REPRESENTED_TARGETS_KEY: host.represented_target_evidence(
                        unit["fname"], "method", method
                    ),
                }
                endpoints.append(endpoint)
                if callable(getattr(host, "debug_log", None)):
                    host.debug_log(endpoint)
    return _deduplicate(endpoints, host)


__all__ = [
    "SpringConfiguration",
    "SpringProjectConfiguration",
    "analyze_spring_resource_handlers",
    "apply_spring_configuration",
    "apply_spring_path",
    "build_spring_configuration",
    "spring_path_applicator",
]
